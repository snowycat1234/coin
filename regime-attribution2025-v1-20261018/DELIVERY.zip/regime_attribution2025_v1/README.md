# Saved 2025 DEV regime addendum

Final status: independent saved-data attribution review passed with disclosed qualifications. The 131,710 checks cover both complete daily paths, exact costs, all 88 contiguous market-regime episodes, exposure and full-year conservation. Exact daily NAV versus marked-inventory/cashflow residuals are zero. Frozen definitions, audited source and saved outputs are unchanged.

Start with REGIME_ATTRIBUTION.md. DELIVERY_RECEIPT.json records the current review outcome; REGIME_ATTRIBUTION.json intentionally retains its original calculation-time pending-review status. The reviewer pins its exact bytes.

Both strategies lost money in BULL, BEAR and REBOUND. Gains came from RANGE and CORRECTION. HELD10 reduced bull losses but earned less during corrections. Coverage includes only 11 rebound days in 4 episodes. These are descriptive results on already seen 2025 DEV, not OOS, a robust across-regime profit claim, or a long-term APR estimate. The shared actual post-boundary-funding observation phase deviation remains disclosed.

The new single BTC 200-close mean / 20-day return rule was saved and hashed, then its complete source-only labels were saved and hashed, before joining outcomes. Related prior conventions were inspected. The 2% range band and exhaustive correction bucket are explicit analyst choices, not inherited trading rules. No tuning, selector, strategy/account replay, network market download, source/output change, Library write or GitHub write occurred.

Every day, regime and episode has exact dollar NAV contributions and costs. Daily boundary exposures retain exact rational dollar notionals and weights; minute exposure/risk summaries are explicitly float64 samples. Every source funding event is accounted for, preserving (decision, next decision] right-boundary allocation. The five fresh-flat skips retain their true 15-millisecond-after-genesis clocks.

The daily and paired episode CSV files are convenience exports. Nonterminating episode return ratios are 100-digit decimal displays; JSON numerator/denominator pairs are exact. Bucket contribution is additive dollars or percentage points of the initial wallet; no disjoint-bucket compounding or annualization is performed.

Code files read the already saved source/account artifacts only. They do not import financial engines. The source-label and analysis scripts deliberately refuse overwriting existing calculation outputs. All prior data remains in its original pinned location; this addendum does not contain raw minute source arrays or engine files.

External publication is left to the designated publisher. No external upload has been performed by this task.
