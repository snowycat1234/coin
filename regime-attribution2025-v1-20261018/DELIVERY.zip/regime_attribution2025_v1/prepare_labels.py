"""Source-only label pass; creates no outcome join."""
import json,hashlib
from pathlib import Path
from fractions import Fraction as F
import numpy as np
from classifier import classify,DAY
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
EXPECTED='31c90233b335c9ce2d45f2388a844a3e4da6df814af5e88957eeca9ad57997e4'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def exact(x):return dict(numerator=str(x.numerator),denominator=str(x.denominator))
assert sha(HERE/'RULE_FREEZE.json')==EXPECTED
freeze=json.loads((HERE/'RULE_FREEZE.json').read_text())
for pin in freeze['source_pins']+[freeze['classifier']]:
 p=ROOT/pin['path'];assert p.stat().st_size==pin['bytes'] and sha(p)==pin['sha256']
review=json.loads((ROOT/'restored2025/INDEPENDENT_SOURCE_REVIEW.json').read_text())
receipt=json.loads((ROOT/'controlled_sma2025_v2r1/source_receipt.json').read_text())
assert review['status']=='PASS_SOURCE_RECOVERY_ONLY'
assert receipt['first_source_generated_marker'] is False
assert review['verified']['past_only_contiguous_inclusive_200_close_windows']==365
with np.load(ROOT/'controlled_sma2025_v2r1/source_recipe.npz',allow_pickle=False) as z:
 clocks=z['close_available_us'];close=z['source_close'];decisions=z['decision_us'];completed=z['completed_close']
with np.load(ROOT/'held_risk_sma2025_v1/source_recipe.npz',allow_pickle=False) as z:
 for k,v in [('close_available_us',clocks),('source_close',close),('decision_us',decisions),('completed_close',completed)]:assert np.array_equal(z[k],v)
with np.load(ROOT/'restored2025/SOURCE_WARMUP_200_CLOSE_ONLY.npz',allow_pickle=False) as z:
 assert np.array_equal(z['close_available_us'],clocks[:200]) and np.array_equal(z['close'],close[:200])
assert close.shape==(564,5) and np.all(np.diff(clocks)==DAY)
daily=json.loads((ROOT/'restored2025/prepared_2025/DAILY.json').read_text())
btc={x['close_us']:x['close'] for x in daily if x['symbol']=='BTCUSDT'}
for at,value in zip(decisions,completed[:,0]):assert btc[int(at)]==value
proof=json.loads((ROOT/'controlled_sma2025_v2r1/source_causality_proofs.json').read_text())
labels=[]
for i,at in enumerate(decisions):
 j=int(np.searchsorted(clocks,at,side='right'));ws=close[j-200:j,0];ts=clocks[j-200:j].tolist()
 p=proof[i];assert p['decision_us']==int(at) and p['last_close_available_us']==ts[-1]==int(at)
 assert p['oldest_direction_close_available_us']==ts[0] and p['completed_direction_closes']==200
 assert completed[i,0]==ws[-1]
 r=classify(ws,ts,int(at));r={k:(exact(v) if isinstance(v,F) else v) for k,v in r.items()}
 r.update(decision_us=int(at),interval_end_us=int(at)+DAY,date=str(np.datetime64(int(at),'us').astype('datetime64[D]')),source_window_start_available_us=ts[0],source_window_last_available_us=ts[-1],source_observation_count=200,source_status='RECOVERED_OBSERVATION_CONDITIONAL_AVAILABILITY_NOT_ACTUAL_ARRIVAL_CERTIFIED')
 labels.append(r)
p=HERE/'DAILY_LABELS.json';assert not p.exists();p.write_text(json.dumps(dict(schema='FROZEN_SOURCE_ONLY_DAILY_REGIME_LABELS_V1',rule_sha256=EXPECTED,labels=labels),indent=2,sort_keys=True)+'\n')
from collections import Counter
print(dict(Counter(x['regime'] for x in labels)))
q=HERE/'LABEL_FREEZE_RECEIPT.json';assert not q.exists();q.write_text(json.dumps(dict(schema='SOURCE_LABELS_BEFORE_OUTCOME_JOIN_V1',rule_sha256=EXPECTED,classifier_sha256=sha(HERE/'classifier.py'),labels_sha256=sha(p),days=365,first_decision_us=int(decisions[0]),last_decision_us=int(decisions[-1]),outcome_files_read_by_label_pass=0,network=0,financial_runs=0,all_source_window_proofs_checked=True),indent=2,sort_keys=True)+'\n')
print('labels SHA256',sha(p))
