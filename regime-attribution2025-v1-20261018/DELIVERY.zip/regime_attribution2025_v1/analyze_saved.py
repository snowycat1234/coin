"""Read-only saved-output regime attribution; never imports/runs financial code."""
import os
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
import calendar,csv,gzip,hashlib,json
from pathlib import Path
from collections import Counter,defaultdict
from fractions import Fraction as F
from decimal import Decimal,localcontext
import numpy as np
from classifier import DAY,LABELS
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
START=1735689600000000;END=1767225600000000;MINUTE=60_000_000
RULE_SHA='31c90233b335c9ce2d45f2388a844a3e4da6df814af5e88957eeca9ad57997e4'
LABEL_SHA='610df3ad51d44a964990fee0137d397ded4106eed8b06d15584e3fdea516ecd2'
S=('BTCUSDT','ETHUSDT','SOLUSDT','XRPUSDT','DOGEUSDT')
RUNS={'BASELINE':dict(directory='controlled_sma2025_v2r1',terminal='6793008b479ca39e5520a1390b6f7f80aa65e7cd660f803e03f7cd23c5d89815',audit='audit_sma2025_v2r1/AUDIT_RECEIPT.json',audit_sha='98eb900afed1647972e4034cf34279a455ca38382df3f1d62199ed99cfb9d778'), 'HELD10':dict(directory='held_risk_sma2025_v1',terminal='b56ae572b97406608e8de75e6bd3a5b2c8d6ea63cab814f126aa8c2052fa0c4c',audit='audit_held10_2025_r2/AUDIT_RECEIPT.json',audit_sha='5a773357560f21d476e2135213bf64549ea054bd4f22b347ff3dcd4bdee6b1a6')}
def need(v,m):
 if not v:raise ValueError(m)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def load(p):
 with (gzip.open(p,'rt') if p.suffix=='.gz' else p.open()) as f:return json.load(f)
def dec(f):
 f=F(f)
 with localcontext() as c:
  c.prec=100;return str(Decimal(f.numerator)/Decimal(f.denominator))
def encode(o):
 if isinstance(o,F):return dict(numerator=str(o.numerator),denominator=str(o.denominator),decimal_100_digits=dec(o))
 if isinstance(o,dict):return {k:encode(v) for k,v in o.items()}
 if isinstance(o,(list,tuple)):return [encode(v) for v in o]
 if isinstance(o,np.generic):return o.item()
 return o
def save(name,o):
 p=HERE/name;need(not p.exists(),'NEW_REPORT_REQUIRED:'+name);p.write_text(json.dumps(encode(o),indent=2,sort_keys=True,allow_nan=False)+'\n')
def bucket(at):
 need(type(at) is int and START<=at<=END,'FULL_PERIOD_EVENT_CLOCK')
 return max(0,(at-START-1)//DAY)
def xf(v):return F(str(float(v)))
need(sha(HERE/'RULE_FREEZE.json')==RULE_SHA and sha(HERE/'DAILY_LABELS.json')==LABEL_SHA,'FROZEN_RULE_AND_SOURCE_LABELS')
label_doc=load(HERE/'DAILY_LABELS.json');labels=label_doc['labels'];need(len(labels)==365,'ALL_365_LABELS')
need([r['decision_us'] for r in labels]==list(range(START,END,DAY)),'ORDERED_LABEL_CALENDAR')
# Prices for exact boundary marked-notional algebra use retained canonical minute
# observations decimal-rendered identically to the audited source convention.
with np.load(ROOT/'controlled_sma2025_v2r1/source_recipe.npz',allow_pickle=False) as z:
 cov=z['annual_covariance'];genesis=z['completed_close'][0]
price_rows=[tuple(xf(x) for x in genesis)];source_pins=[]
source_complete=load(ROOT/'restored2025/CANONICAL_SOURCE_COMPLETE.json')
for m in range(1,13):
 p=ROOT/f'restored2025/prepared_2025/months/2025-{m:02}.npz';pin=source_complete['months'][m-1]
 need(sha(p)==pin['SHA256'] and p.stat().st_size==pin['bytes'],'PINNED_CANONICAL_SOURCE_MONTH')
 source_pins.append(dict(path=str(p.relative_to(ROOT)),sha256=pin['SHA256']))
 with np.load(p,allow_pickle=False) as z:
  daily_marks=np.column_stack([z[s+'_mark'][1439::1440] for s in S])
  need(len(daily_marks)==calendar.monthrange(2025,m)[1],'EVERY_DAILY_BOUNDARY_MARK')
  price_rows.extend(tuple(xf(x) for x in row) for row in daily_marks)
need(len(price_rows)==366,'366_BOUNDARY_MARKS')
source_funding=load(ROOT/'restored2025/prepared_2025/EVENTS.json')
source_counts=Counter(bucket(r['event_us']) for r in source_funding)
need(len(source_funding)==5475,'5475_UNCHANGED_SOURCE_FUNDING_EVENTS')
all_pins={};data={};conservation={};all_daily={}
MONEY=('net_NAV_change_USDT','gross_mid_mark_PnL_bridge_USDT','fees_USDT','adverse_execution_USDT','signed_funding_USDT','fill_price_turnover_USDT','mid_price_turnover_USDT','inventory_mark_change_USDT','signed_fill_cashflow_USDT','exact_mark_cashflow_net_USDT','native40_boundary_minus_mark_cashflow_residual_USDT','right_boundary_signed_funding_USDT')
for name,config in RUNS.items():
 out=ROOT/config['directory']/'annual_output_once';need(sha(out/'TERMINAL_PROOF.json')==config['terminal'],'EXPECTED_COMPLETED_TERMINAL')
 audit_path=ROOT/config['audit'];need(sha(audit_path)==config['audit_sha'],'EXPECTED_COMPLETED_SAVED_AUDIT')
 audit=load(audit_path);need(audit['saved_outputs_unchanged'] and audit['expected_identities']['terminal']==config['terminal'],'AUDIT_SAME_SAVED_OUTPUTS')
 if name=='HELD10':need(audit['phase_conformity']['implementation_deviation'] and not audit['phase_conformity']['intended_contract_pass'],'EXPLICIT_HELD10_PHASE_DEVIATION')
 proof=load(out/'TERMINAL_PROOF.json');pins=[]
 for filename,pin in proof['outputs'].items():
  p=out/filename;need(p.name==filename and sha(p)==pin['SHA256'] and p.stat().st_size==pin['bytes'],'EXACT_OUTPUT_PIN:'+filename)
  pins.append(dict(path=str(p.relative_to(ROOT)),sha256=pin['SHA256'],bytes=pin['bytes']))
 all_pins[name]=pins+[dict(path=str((out/'TERMINAL_PROOF.json').relative_to(ROOT)),sha256=config['terminal']),dict(path=config['audit'],sha256=config['audit_sha'])]
 adapter=load(out/'adapter_evidence.json.gz');account=load(out/'native_account_audit.json.gz');econ=load(out/'economic_model_report.json.gz');native=load(out/'native_result_without_minute.json.gz')
 need(proof['full_calendar'] and proof['paid_flat'] and econ['paid_flat'],'COMPLETED_PAID_FLAT')
 need(not account['transfer_journal'] and not account['liquidations'] and not econ['conditional_settlements'],'NO_TRANSFER_LIQUIDATION_OR_CONDITIONAL_SETTLEMENT')
 obs=adapter['daily_observations'];need([r['decision_us'] for r in obs]==list(range(START,END,DAY)),'ALL_AUDITED_DAILY_OBSERVATIONS')
 navs=[F(r['frozen_NAV']) for r in obs]+[F(econ['decimal_strings']['NAV'])]
 need(navs[0]==10000 and navs[-1]==F(audit['performance']['terminal_paid_NAV_USDT']),'EXACT_INITIAL_AND_AUDITED_TERMINAL_NAV')
 progress=[json.loads(s) for s in (out/'progress.jsonl').read_text().splitlines()]
 need(len(progress)==365 and all(r['cursor_us']==START+(i+1)*DAY and F(r['exact_native_NAV'])==navs[i+1] for i,r in enumerate(progress)),'ALL365_AUDITED_END_CHECKPOINTS')
 with np.load(out/'native_minutes.npz',allow_pickle=False) as z:
  values=z['values'];clocks=z['close_us'];columns=z['column_order'].tolist()
 idx={s:i for i,s in enumerate(columns)}
 need(values.shape==(525600,36) and np.all(np.diff(clocks)==MINUTE) and clocks[0]==START+MINUTE and clocks[-1]==END,'COMPLETE_CONTIGUOUS_SAVED_MINUTES')
 need(np.array_equal(values[1439::1440,idx['nav']],np.array([float(n) for n in navs[1:]])),'EXACT_PRESERVED_FLOAT64_DAILY_ENDPOINTS')
 weights=np.column_stack([values[:,idx[s+'_signed_weight']] for s in S]);gross=np.abs(weights).sum(axis=1);net=weights.sum(axis=1)
 need(np.max(np.abs(gross-values[:,idx['gross_weight']]))<1e-12,'SAVED_GROSS_COLUMN')
 sigmas=np.concatenate([np.sqrt(np.maximum(np.einsum('ij,jk,ik->i',weights[i*1440:(i+1)*1440],cov[i],weights[i*1440:(i+1)*1440]),0)) for i in range(365)])
 trades=account['trades'];funds=account['funding'];need(len(funds)==5470,'ALL5470_ACCOUNT_FUNDING')
 reported={(f['symbol'],f['event_us']):f for f in native['funding']}
 need(len(reported)==5475 and set(reported)=={(r['symbol'],r['event_us']) for r in source_funding},'ALL_SOURCE_FUNDING_REPORTED')
 account_ids={(f['symbol'],f['event_us']) for f in funds};skips=[f for k,f in reported.items() if k not in account_ids]
 need(len(skips)==5 and all(f['status']=='NO_POSITION_NO_PAST_MARK' and f['quantity']==0 and not f['owned'] and f['signed_funding_USDT']==0 for f in skips),'FIVE_FRESH_FLAT_SKIP_EVENTS')
 flows=[dict(fees_USDT=F(0),adverse_execution_USDT=F(0),signed_funding_USDT=F(0),fill_price_turnover_USDT=F(0),mid_price_turnover_USDT=F(0),signed_fill_cashflow_USDT=F(0),right_boundary_signed_funding_USDT=F(0),paid_fill_legs=0,account_funding_rows=0,owned_funding_rows=0,nonzero_funding_rows=0,right_boundary_funding_rows=0,source_funding_rows=source_counts[i],fresh_flat_no_past_mark_skips=0) for i in range(365)]
 for t in trades:
  b=flows[bucket(t['event_us'])];d=t['decimal_strings'];q=F(d['quantity']);delta=F(d['position_delta']);fill=F(d['fill_price']);mid=F(d['execution_mid_price'])
  need(q>0 and q==abs(delta) and F(d['execution_cost'])==q*abs(fill-mid),'EXACT_PAID_EVENT')
  b['fees_USDT']+=F(d['fee_amount']);b['adverse_execution_USDT']+=F(d['execution_cost']);b['fill_price_turnover_USDT']+=q*fill;b['mid_price_turnover_USDT']+=q*mid;b['signed_fill_cashflow_USDT']-=delta*fill;b['paid_fill_legs']+=1
 for f in funds:
  k=bucket(f['event_us']);b=flows[k];cash=F(f['decimal_strings']['signed_funding_USDT']);b['signed_funding_USDT']+=cash;b['account_funding_rows']+=1;b['owned_funding_rows']+=int(f['owned']);b['nonzero_funding_rows']+=int(cash!=0)
  if f['event_us']==START+(k+1)*DAY:b['right_boundary_signed_funding_USDT']+=cash;b['right_boundary_funding_rows']+=1
 for f in skips:flows[bucket(f['event_us'])]['fresh_flat_no_past_mark_skips']+=1
 # Inventory reconstruction is saved paid-delta algebra only, not an account or
 # strategy replay. No cash, basis, margin, or financial clock is advanced.
 quantities=[];q={s:F(0) for s in S};ti=0
 for k in range(366):
  at=START+k*DAY
  while ti<len(trades) and trades[ti]['event_us']<=at:
   t=trades[ti];d=t['decimal_strings'];s=t['symbol'];need(q[s]==F(d['quantity_before']),'PAID_INVENTORY_CHAIN');q[s]+=F(d['position_delta']);need(q[s]==F(d['quantity_after']),'RECORDED_INVENTORY_AFTER');ti+=1
  quantities.append(tuple(q[s] for s in S))
 need(ti==len(trades) and all(x==0 for x in quantities[-1]),'ALL_PAID_EVENTS_TERMINAL_FLAT')
 rows=[]
 for i,label in enumerate(labels):
  r=dict(date=label['date'],decision_us=label['decision_us'],interval_end_us=label['interval_end_us'],regime=label['regime'],start_NAV_USDT=navs[i],end_NAV_USDT=navs[i+1],net_NAV_change_USDT=navs[i+1]-navs[i],**flows[i])
  r['initial_wallet_return_contribution_percentage_points']=r['net_NAV_change_USDT']/100
  r['gross_mid_mark_PnL_bridge_USDT']=r['net_NAV_change_USDT']+r['fees_USDT']+r['adverse_execution_USDT']-r['signed_funding_USDT']
  starts=tuple(q*p for q,p in zip(quantities[i],price_rows[i]));ends=tuple(q*p for q,p in zip(quantities[i+1],price_rows[i+1]))
  r['inventory_mark_change_USDT']=sum(ends,F(0))-sum(starts,F(0))
  r['exact_mark_cashflow_net_USDT']=r['inventory_mark_change_USDT']+r['signed_fill_cashflow_USDT']-r['fees_USDT']+r['signed_funding_USDT']
  r['native40_boundary_minus_mark_cashflow_residual_USDT']=r['net_NAV_change_USDT']-r['exact_mark_cashflow_net_USDT']
  r['start_exposure_exact']=dict(gross_marked_notional_USDT=sum(map(abs,starts),F(0)),signed_net_marked_notional_USDT=sum(starts,F(0)),gross_NAV_weight=sum(map(abs,starts),F(0))/navs[i],signed_net_NAV_weight=sum(starts,F(0))/navs[i],asset_quantities=dict(zip(S,quantities[i])),asset_signed_marked_notional_USDT=dict(zip(S,starts)))
  r['end_exposure_exact']=dict(gross_marked_notional_USDT=sum(map(abs,ends),F(0)),signed_net_marked_notional_USDT=sum(ends,F(0)),gross_NAV_weight=sum(map(abs,ends),F(0))/navs[i+1],signed_net_NAV_weight=sum(ends,F(0))/navs[i+1])
  sl=slice(i*1440,(i+1)*1440);w=weights[sl];n=values[sl,idx['nav']];sig=sigmas[sl]
  r['minute_exposure_saved_float64']=dict(samples=1440,mean_gross_NAV_weight=float(gross[sl].mean()),max_gross_NAV_weight=float(gross[sl].max()),mean_signed_net_NAV_weight=float(net[sl].mean()),mean_absolute_net_NAV_weight=float(np.abs(net[sl]).mean()),mean_long_NAV_weight=float(np.maximum(w,0).sum(axis=1).mean()),mean_short_NAV_weight=float(np.maximum(-w,0).sum(axis=1).mean()),mean_gross_marked_notional_USDT=float((np.abs(w).sum(axis=1)*n).mean()),max_gross_marked_notional_USDT=float((np.abs(w).sum(axis=1)*n).max()),mean_signed_net_marked_notional_USDT=float((w.sum(axis=1)*n).mean()),maximum_forecast_sigma=float(sig.max()),forecast_sigma_gt10pct_minutes=int(np.count_nonzero(sig>.10)),asset_mean_absolute_NAV_weight={s:float(np.abs(w[:,j]).mean()) for j,s in enumerate(S)})
  rows.append(r)
 sums={k:sum((r[k] for r in rows),F(0)) for k in MONEY};need(sums['net_NAV_change_USDT']==navs[-1]-10000,'365DAY_EXACT_NET_CONSERVATION')
 need(sums['net_NAV_change_USDT']==F(audit['performance']['net_PnL_USDT']),'AUDITED_FULL_YEAR_NET_CONSERVATION')
 for field,auditfield in [('fees_USDT','fees_USDT'),('adverse_execution_USDT','adverse_execution_cost_USDT'),('signed_funding_USDT','signed_funding_USDT'),('fill_price_turnover_USDT','turnover_USDT')]:need(sums[field]==F(audit['performance'][auditfield]),'EXACT_FULL_YEAR_COST_CONSERVATION:'+field)
 need(sum(r['source_funding_rows'] for r in rows)==5475 and sum(r['account_funding_rows'] for r in rows)==5470 and sum(r['fresh_flat_no_past_mark_skips'] for r in rows)==5,'ALL_FUNDING_EVENT_CONSERVATION')
 need(sum(r['paid_fill_legs'] for r in rows)==len(trades),'ALL_PAID_LEG_CONSERVATION')
 # Exact rational mark/cashflow residual is native40 path rounding, not a fee,
 # alpha estimate, or a fitted tolerance; retained both signed and absolute.
 conservation[name]=dict(passed=True,exact_financial_sums=sums,full_year_initial_NAV_USDT=F(10000),full_year_terminal_NAV_USDT=navs[-1],full_year_net_from_audit_USDT=F(audit['performance']['net_PnL_USDT']),paid_fill_legs=len(trades),source_funding_events=5475,account_funding_events=5470,fresh_flat_skips=5,daily_nav_boundaries=366,daily_rows=365,minute_rows=525600,max_absolute_daily_native40_vs_exact_mark_cashflow_residual_USDT=max(abs(r['native40_boundary_minus_mark_cashflow_residual_USDT']) for r in rows))
 all_daily[name]=rows
 def summarize(selected):
  out={k:sum((r[k] for r in selected),F(0)) for k in MONEY}
  out.update(days=len(selected),minute_samples=1440*len(selected),initial_wallet_return_contribution_percentage_points=out['net_NAV_change_USDT']/100)
  for k in ('paid_fill_legs','source_funding_rows','account_funding_rows','owned_funding_rows','nonzero_funding_rows','fresh_flat_no_past_mark_skips','right_boundary_funding_rows'):out[k]=sum(r[k] for r in selected)
  out['exposure_saved_float64']=dict(mean_gross_NAV_weight=float(np.mean([r['minute_exposure_saved_float64']['mean_gross_NAV_weight'] for r in selected])) if selected else None,max_gross_NAV_weight=max((r['minute_exposure_saved_float64']['max_gross_NAV_weight'] for r in selected),default=None),mean_signed_net_NAV_weight=float(np.mean([r['minute_exposure_saved_float64']['mean_signed_net_NAV_weight'] for r in selected])) if selected else None,mean_gross_marked_notional_USDT=float(np.mean([r['minute_exposure_saved_float64']['mean_gross_marked_notional_USDT'] for r in selected])) if selected else None,max_gross_marked_notional_USDT=max((r['minute_exposure_saved_float64']['max_gross_marked_notional_USDT'] for r in selected),default=None),maximum_forecast_sigma=max((r['minute_exposure_saved_float64']['maximum_forecast_sigma'] for r in selected),default=None),forecast_sigma_gt10pct_minutes=sum(r['minute_exposure_saved_float64']['forecast_sigma_gt10pct_minutes'] for r in selected))
  return out
 regimes={label:summarize([r for r in rows if r['regime']==label]) for label in LABELS}
 episodes=[];start=0
 for i in range(1,366):
  if i==365 or rows[i]['regime']!=rows[start]['regime']:
   group=rows[start:i];e=summarize(group);e.update(episode_id=len(episodes)+1,regime=group[0]['regime'],start_date=group[0]['date'],last_decision_date=group[-1]['date'],start_us=group[0]['decision_us'],end_us=group[-1]['interval_end_us'],start_NAV_USDT=group[0]['start_NAV_USDT'],end_NAV_USDT=group[-1]['end_NAV_USDT'],contiguous_episode_simple_NAV_return_fraction=e['net_NAV_change_USDT']/group[0]['start_NAV_USDT']);episodes.append(e);start=i
 for field in MONEY:
  need(sum((v[field] for v in regimes.values()),F(0))==sums[field],'EXACT_REGIME_SUM:'+field)
  need(sum((v[field] for v in episodes),F(0))==sums[field],'EXACT_EPISODE_SUM:'+field)
 need(sum(x['days'] for x in episodes)==365,'EVERY_CONTIGUOUS_EPISODE_INCLUDED')
 data[name]=dict(regimes=regimes,episodes=episodes)
 save(name+'_DAILY_ATTRIBUTION.json',dict(schema='SAVED_EXACT_DAILY_REGIME_ATTRIBUTION_V1',run=name,rule_sha256=RULE_SHA,labels_sha256=LABEL_SHA,rows=rows))
 save(name+'_ALL_EPISODES.json',dict(schema='ALL_CONTIGUOUS_REGIME_EPISODES_V1',run=name,episodes=episodes))
 # CSV is a convenience human export. Every financial decimal terminates and
 # serializes exactly; exact rational ratios remain authoritative in JSON.
 fields=['date','regime','start_NAV_USDT','end_NAV_USDT']+list(MONEY)+['initial_wallet_return_contribution_percentage_points','paid_fill_legs','account_funding_rows','owned_funding_rows','source_funding_rows']
 with (HERE/(name+'_DAILY_ATTRIBUTION.csv')).open('x',newline='') as f:
  w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
  for r in rows:w.writerow({k:dec(r[k]) if isinstance(r[k],F) else r[k] for k in fields})
 del values,weights,gross,net,sigmas
coverage={label:dict(days=sum(x['regime']==label for x in labels),calendar_fraction=F(sum(x['regime']==label for x in labels),365),contiguous_episodes=sum(e['regime']==label for e in data['BASELINE']['episodes']),first_decision_date=next((r['date'] for r in labels if r['regime']==label),None),last_decision_date=next((r['date'] for r in reversed(labels) if r['regime']==label),None)) for label in LABELS}
paired={label:dict(days=coverage[label]['days'],HELD10_minus_BASELINE_net_USDT=data['HELD10']['regimes'][label]['net_NAV_change_USDT']-data['BASELINE']['regimes'][label]['net_NAV_change_USDT'],HELD10_minus_BASELINE_fees_USDT=data['HELD10']['regimes'][label]['fees_USDT']-data['BASELINE']['regimes'][label]['fees_USDT'],HELD10_minus_BASELINE_execution_USDT=data['HELD10']['regimes'][label]['adverse_execution_USDT']-data['BASELINE']['regimes'][label]['adverse_execution_USDT'],HELD10_minus_BASELINE_signed_funding_USDT=data['HELD10']['regimes'][label]['signed_funding_USDT']-data['BASELINE']['regimes'][label]['signed_funding_USDT']) for label in LABELS}
need(sum((r['HELD10_minus_BASELINE_net_USDT'] for r in paired.values()),F(0))==conservation['HELD10']['exact_financial_sums']['net_NAV_change_USDT']-conservation['BASELINE']['exact_financial_sums']['net_NAV_change_USDT'],'PAIRED_DIFFERENCE_CONSERVATION')
summary=dict(schema='SAVED_2025_DEV_CAUSAL_REGIME_ATTRIBUTION_V1',status='CALCULATED_PENDING_INDEPENDENT_REVIEW',rule_sha256=RULE_SHA,labels_sha256=LABEL_SHA,coverage=coverage,runs={n:dict(regimes=d['regimes'],episode_count=len(d['episodes'])) for n,d in data.items()},paired_dollar_difference=paired,conservation=conservation,boundary_convention='Each decision label applies to (decision,next decision]. At exact non-genesis midnight the closing minute mark and already-paid funding belong to the PRECEDING day/regime. Rates one microsecond after midnight belong to the next interval. The five fresh-flat genesis source skips occur at START+15000 microseconds (15 milliseconds) and are assigned day0 with their actual clocks unchanged. Exact NAV is start frozen_NAV to next frozen_NAV or final paidNAV. This preserves R2 actual postfunding phase, not intended strictly prefunding conformity.',exposure_convention='Exact rational daily boundary gross/net marked notional and NAV weights use saved paid inventory with source marks decimal-rendered identically to audit. Minute exposure/risk are explicitly preserved float64 samples,1440perday; sigma uses interval covariance[i] including closing midnight. No claim of exact continuous-time or intraminute exposure.',cost_convention='Paid fees/adverse execution/turnover use exact retained decimal_strings, funding signed cash uses account rows. Gross-mid bridge equals exact netNAV+fees+execution-funding. Independent exact mark change plus fill cashflow minus fees plus funding retained separately, with native40 boundary rounding residual disclosed.',limits=['Already seen2025DEV; classifier chosen after DEV was seen and frozen only before regime-outcome join. Descriptive attribution, not OOS, optimization, learned selector, trading gate or robust-regime certification.','BTC is one market proxy, not a regime label for every asset. Range2% is a descriptive analyst choice. CORRECTION is explicit so classifications are exhaustive.','REBOUND has only11days; episode-level concentration, unequal coverage, serial dependence and threshold sensitivity are not eliminated. No significance or cross-regime robustness claim.','Disjoint bucket returns are additive dollar/initial-wallet contributions only, never CAGR or APR. Contiguous episode return is a simple unannualized NAV ratio and is path/state dependent.','Shared baseline/HELD10 midnight postfunding deviation persists. Exact arithmetic validity does not certify intended prefunding experiment.','Actual source arrival/publication, raw funding units, historical venue filters/tiers, liquidation/no-liquidation and live execution remain uncertified. No2022stitch or2026data.'],activity=dict(financial_runs=0,strategy_account_simulator_imports=0,account_constructions=0,financial_clock_advances=0,market_downloads=0,network_calls=0,Library_or_GitHub_writes=0),input_pins=all_pins,canonical_mark_source_pins=source_pins)
save('REGIME_ATTRIBUTION.json',summary)
lines=['# Saved 2025 DEV regime attribution','', 'Descriptive saved-data addendum only. This new fixed rule was chosen on already seen DEV and frozen before joining outcomes; it is not an inherited classifier, OOS result, learned gate, or financial rerun. Independent review is pending.','', '## Single fixed causal rule','', 'Use BTC latest completed daily trade close available at the decision, inclusive200-close mean and trailing20-day simple return. RANGE takes precedence when |return20|<=2%; otherwise above-or-equalSMA/positive=BULL, belowSMA/negative=BEAR, belowSMA/positive=REBOUND, above-or-equalSMA/negative=CORRECTION. Equality goes to above-or-equalSMA. Missing, generated/unqualified, nonpositive, nonfinite, stale, future or noncontiguous input stays UNKNOWN. No interpolation.','',f'Rule SHA256: {RULE_SHA}',f'Source-only daily-label SHA256: {LABEL_SHA}','', '## Coverage and additive contribution','', '| Regime | Days | Episodes | Baseline net USDT | HELD10 net USDT | HELD minus baseline USDT |','|---|---:|---:|---:|---:|---:|']
for label in LABELS:
 c=coverage[label];b=data['BASELINE']['regimes'][label]['net_NAV_change_USDT'];h=data['HELD10']['regimes'][label]['net_NAV_change_USDT'];lines.append(f'| {label} | {c["days"]} | {c["contiguous_episodes"]} | {float(b):.8f} | {float(h):.8f} | {float(h-b):.8f} |')
lines+=['','All365days and all contiguous episodes are included; no profitable-month selection. Rebound has only11days, so coverage does not establish robustness. Bucket netUSDT/100 is contribution in percentage points to the initial10000USDT wallet. No disjoint-bucket annualization.','', '## Costs, exposures and exact conservation','']
for name in RUNS:
 c=conservation[name];f=c['exact_financial_sums'];lines += [f'### {name}',f'- Exact full-year net NAV change: {dec(f["net_NAV_change_USDT"])} USDT',f'- Fees: {dec(f["fees_USDT"])}; adverse execution: {dec(f["adverse_execution_USDT"])}; signed funding: {dec(f["signed_funding_USDT"])} USDT',f'- Paid legs: {c["paid_fill_legs"]}; source funding5475, account funding5470, fresh-flat source skips5',f'- Every day, regime bucket and contiguous episode sums exactly to the audited full-year net and cost totals',f'- Exact full-year boundaryNAV minus independent mark/cashflow residual: {dec(f["native40_boundary_minus_mark_cashflow_residual_USDT"])} USDT; maximum absolute daily residual: {dec(c["max_absolute_daily_native40_vs_exact_mark_cashflow_residual_USDT"])} USDT','']
lines += ['Daily JSON files retain exact rational start/endNAV, dollar change, costs, funding, marked-notional/cashflow bridge, rounding residual, exact boundary exposure and every1440minute exposure/risk summary. CSV exports provide convenience financial rows. All-episode JSON files retain the entire contiguous partition, costs and exposure for every episode.','', '## Boundary allocation and qualifications','',summary['boundary_convention'],'',summary['exposure_convention'],'',summary['cost_convention'],'']+[f'- {v}' for v in summary['limits']]
(HERE/'REGIME_ATTRIBUTION.md').write_text('\n'.join(lines)+'\n')
print(json.dumps({'coverage':{k:v['days'] for k,v in coverage.items()},'episodes':len(data['BASELINE']['episodes']),'net':{n:dec(c['exact_financial_sums']['net_NAV_change_USDT']) for n,c in conservation.items()},'paired_net_by_regime':{k:dec(v['HELD10_minus_BASELINE_net_USDT']) for k,v in paired.items()}},indent=2))
