# Independent saved attribution review

PASS for exact saved-data attribution, subject to the disclosed DEV, source and phase qualifications.

- Recomputed all365daily NAV changes, exact fees/execution/funding/turnover and exact marked-inventory/cashflow bridges for each account. All exact daily cashflow/NAV residuals are zero.
- Checked all88contiguous episodes per account, every regime bucket and paired full-year conservation. No day, cost or episode is omitted. UNKNOWN has no observed days.
- Recomputed all525600saved-minute exposure samples per account, including per-asset exposure and held-weight forecast risk. Float64 summaries agree within machine-operation rounding; exact dollar assertions require equality.
- Verified5475source funding records,5470account records and5fresh-flat skips. Synthetic boundary tests confirm exact midnight goes to the prior interval and+1microsecond goes to the next.
- The five skipped genesis-day events are actually15ms afterSTART. Parent corrected the initial atSTART wording before final review; current wording, arithmetic and retained clocks agree.
- Frozen rule/labels, attribution deliverables and pinned source/saved account outputs are unchanged. No finance kernel, replay, account construction, model fit or network was run.

Baseline net−170.3719598005638103848USDT; HELD10 net+366.0809610143028640295USDT. The difference is536.4529208148666744143USDT. This is descriptive saved2025DEV attribution. The rebound bucket has only11days in4episodes. The shared actual postfunding midnight deviation remains; arithmetic validity does not establish intended prefunding conformity or investment validity.
