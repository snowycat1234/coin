# Convention, source and classifier review

PASS with declared source-timing qualifications. The frozen rule was not changed. No strategy outcomes were joined.

- Prior causal BTC rule: completed close relative to inclusive SMA200 and20day return, plus a crash override. It has BULL/BEAR/SIDEWAYS/HIGH_VOL_CRASH, without the requested rebound/correction and2% range split.
- Prior slow/fast map: inclusive SMA50/SMA200 sign quadrants, including a descriptively named down/rebound quadrant. It has no20day momentum range band and was an expert-weight probe.
- Prior GMM: relative training-fitted clusters, outside this no-fit task.
- INPUTS.regime: future7/30/60day volatility targets with61day maturity, unsuitable for decision-time state labels.

Exact prior commit, Git blob IDs and SHA256s are in the companion JSON. The inspected saved snapshot supports related prior causal ideas, not an inherited requested taxonomy. The frozen2% rule is a new analyst-chosen seen-DEV description.

Canonical BTC closes:365 daily records and200 inherited warmup closes, with the January1 overlap deduplicated, give564 contiguous closes and365 full inclusive200close decision windows. The BTC panels bit-match both source_recipe archives. Availability is the declared completed-close boundary; native arrival timing is uncertified. Warmup provenance is inherited and was not freshly reconstructed here.

Important old archive clock: INPUTS dates_us is observation OPEN, so completed close availability is dates_us+DAY. The2025 overlap matches canonical DAILY only after that shift. It must not be joined directly to canonical close_us.

Classifier:365 source windows match independent mutually-exclusive/exhaustive predicates; exact2% boundaries, zero, mean equality, rebound/correction, invalid closes, stale/future/noncontiguous clocks and unqualified inputs pass.200 randomized numerical inputs also agree.

The caller must supply source_observed=False for generated/unqualified sources. Numeric values cannot authenticate their own provenance. This review does not establish investment, OOS, venue or live execution validity.
