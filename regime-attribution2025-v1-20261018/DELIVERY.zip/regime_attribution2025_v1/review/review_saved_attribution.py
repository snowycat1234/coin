"""Independent saved-event algebra and fixed-partition review; no financial imports."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
from collections import Counter,defaultdict
from fractions import Fraction as Q
from bisect import bisect_left,bisect_right
from decimal import Decimal,localcontext
import csv,gzip,hashlib,json
import numpy as np
R=Path('/workspace/scratch/68ef1b82bcac/coin_recovery_20261018');H=R/'regime_attribution2025_v1';O=H/'review'
START=1735689600000000;END=1767225600000000;DAY=86400000000;MIN=60000000
SYMS=('BTCUSDT','ETHUSDT','SOLUSDT','XRPUSDT','DOGEUSDT');BOUND=list(range(START,END+DAY,DAY));ENDS=BOUND[1:]
NAMES={'BASELINE':'controlled_sma2025_v2r1','HELD10':'held_risk_sma2025_v1'}
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def read(p):
 with (gzip.open(p,'rt') if p.suffix=='.gz' else p.open()) as f:return json.load(f)
def decode(x):
 if isinstance(x,dict) and set(x)=={'numerator','denominator','decimal_100_digits'}:
  q=Q(int(x['numerator']),int(x['denominator']))
  with localcontext() as c:
   c.prec=100;assert x['decimal_100_digits']==str(Decimal(q.numerator)/Decimal(q.denominator))
  return q
 if isinstance(x,dict):return {k:decode(v) for k,v in x.items()}
 if isinstance(x,list):return [decode(v) for v in x]
 return x
checks=Counter();max_float_error=defaultdict(float)
def eq(a,b,k):
 assert a==b,(k,a,b);checks[k]+=1

def near(a,b,k):
 err=abs(a-b);max_float_error[k]=max(max_float_error[k],err)
 assert err<=max(1.,abs(a),abs(b))*2e-12,(k,a,b,err);checks[k]+=1

def bucket(t):
 assert type(t) is int and START<=t<=END
 return bisect_left(ENDS,t)
# Endpoint-side tests independent from producer floor arithmetic.
boundary_tests=[]
for name,t,want in [('genesis',START,0),('genesis+1',START+1,0),('firstend-1',START+DAY-1,0),('exactfirstend',START+DAY,0),('firstend+1',START+DAY+1,1),('final-1',END-1,364),('exactfinal',END,364)]:
 eq(bucket(t),want,'synthetic_boundary');boundary_tests.append(name)
for t in [START-1,END+1]:
 try:bucket(t)
 except AssertionError:boundary_tests.append('reject '+str(t))
 else:raise AssertionError('Out of calendar event accepted')
# One synthetic two-day inventory path, including exact-boundary costs/funding.
fake_events=[(START+1,Q(2)),(START+DAY,Q(3)),(START+DAY+1,Q(5))]
synthetic=[sum((v for t,v in fake_events if bucket(t)==k),Q(0)) for k in [0,1]]
eq(synthetic,[Q(5),Q(5)],'synthetic_boundary_cashflow')
tracked=[p for p in H.iterdir() if p.is_file()]+[R/'controlled_sma2025_v2r1/source_recipe.npz',R/'held_risk_sma2025_v1/source_recipe.npz']
before={str(p.relative_to(R)):digest(p) for p in tracked}
summary=decode(read(H/'REGIME_ATTRIBUTION.json'));labels=read(H/'DAILY_LABELS.json')['labels']
eq(digest(H/'RULE_FREEZE.json'),'31c90233b335c9ce2d45f2388a844a3e4da6df814af5e88957eeca9ad57997e4','frozen_rule')
eq(digest(H/'DAILY_LABELS.json'),'610df3ad51d44a964990fee0137d397ded4106eed8b06d15584e3fdea516ecd2','frozen_labels')
eq([x['decision_us'] for x in labels],BOUND[:-1],'label_calendar')
for x in labels:eq(x['interval_end_us'],x['decision_us']+DAY,'label_interval')
# Review the already independently verified source-only labels, not a new taxonomy.
conv=read(O/'CONVENTION_SOURCE_REVIEW.json');eq(dict(Counter(x['regime'] for x in labels)),conv['classifier_validation']['regime_counts'],'source_only_label_counts')
eq(Counter(x['regime'] for x in labels).get('UNKNOWN',0),0,'actual_unknown_count')
# Independent partition by runs of equal labels.
spans=[]
for k,x in enumerate(labels):
 if not spans or x['regime']!=spans[-1][0]:spans.append([x['regime'],k,k+1])
 else:spans[-1][2]=k+1
eq(len(spans),88,'all_88_episodes')
source=read(R/'restored2025/prepared_2025/EVENTS.json');source_keys={(x['event_us'],x['symbol']) for x in source}
eq(len(source_keys),5475,'unique_source_funding')
source_count=Counter(bucket(x['event_us']) for x in source)
# Reconstruct boundary source marks from canonical minute source bytes, not report rows.
with np.load(R/'controlled_sma2025_v2r1/source_recipe.npz',allow_pickle=False) as z:
 cov=z['annual_covariance'];gen=z['completed_close'][0]
marks=[tuple(Q(str(float(x))) for x in gen)]
for pin in summary['canonical_mark_source_pins']:
 p=R/pin['path'];eq(digest(p),pin['sha256'],'canonical_source_pin')
 with np.load(p,allow_pickle=False) as z:
  times=z['times'];eq(len(times)%1440,0,'canonical_full_days')
  for i in range(1439,len(times),1440):
   eq(int(times[i])+MIN,BOUND[len(marks)],'boundary_source_mark_clock')
   marks.append(tuple(Q(str(float(z[s+'_mark'][i]))) for s in SYMS))
eq(len(marks),366,'boundary_marks')
MONEY=('net_NAV_change_USDT','gross_mid_mark_PnL_bridge_USDT','fees_USDT','adverse_execution_USDT','signed_funding_USDT','fill_price_turnover_USDT','mid_price_turnover_USDT','inventory_mark_change_USDT','signed_fill_cashflow_USDT','exact_mark_cashflow_net_USDT','native40_boundary_minus_mark_cashflow_residual_USDT','right_boundary_signed_funding_USDT')
COUNTS=('paid_fill_legs','account_funding_rows','owned_funding_rows','nonzero_funding_rows','source_funding_rows','fresh_flat_no_past_mark_skips','right_boundary_funding_rows')
run_results={};daily_net={};used_pins={}
for name,dirname in NAMES.items():
 folder=R/dirname/'annual_output_once';proof=read(folder/'TERMINAL_PROOF.json');used_pins[name]={}
 for pin in summary['input_pins'][name]:
  p=R/pin['path'];eq(digest(p),pin['sha256'],'saved_input_pin');used_pins[name][pin['path']]=digest(p)
  if 'bytes'in pin:eq(p.stat().st_size,pin['bytes'],'saved_input_length')
 eq(proof['full_calendar'],True,'completed_full_calendar');eq(proof['paid_flat'],True,'terminal_paid_flat')
 a=read(folder/'native_account_audit.json.gz');n=read(folder/'native_result_without_minute.json.gz');e=read(folder/'economic_model_report.json.gz');ad=read(folder/'adapter_evidence.json.gz')
 audit=read(R/('audit_sma2025_v2r1/AUDIT_RECEIPT.json' if name=='BASELINE' else 'audit_held10_2025_r2/AUDIT_RECEIPT.json'))
 if name=='HELD10':eq(audit['phase_conformity']['intended_contract_pass'],False,'phase_deviation_retained')
 eq(a['transfer_journal'],[],'no_transfers');eq(a['liquidations'],[],'no_liquidations');eq(e['conditional_settlements'],[],'no_conditional_settlements')
 nav=[Q(x['frozen_NAV']) for x in ad['daily_observations']]+[Q(e['decimal_strings']['NAV'])]
 eq([x['decision_us'] for x in ad['daily_observations']],BOUND[:-1],'adapter_all_daily_clocks');eq(nav[0],10000,'initial_wallet')
 progress=[json.loads(l) for l in (folder/'progress.jsonl').read_text().splitlines()]
 eq([x['cursor_us'] for x in progress],BOUND[1:],'progress_calendar');eq([Q(x['exact_native_NAV']) for x in progress],nav[1:],'all365_exact_daily_NAV')
 trades=a['trades'];fund=a['funding'];eq(len(fund),5470,'account_funding5470')
 assert [t['event_us'] for t in trades]==sorted(t['event_us'] for t in trades)
 eq(len({t['fill_id'] for t in trades}),len(trades),'unique_trade_ids')
 rep={(f['event_us'],f['symbol']):f for f in n['funding']};eq(set(rep),source_keys,'reported_all5475_source_funding')
 ids={(f['event_us'],f['symbol']) for f in fund};eq(len(ids),5470,'account_unique_funding')
 skips=[rep[k] for k in source_keys-ids];eq(len(skips),5,'fresh_flat_skips5')
 eq({f['event_us'] for f in skips},{START+15000},'fresh_flat_actual_plus15ms_clock')
 for f in skips:
  eq((f['status'],f['owned'],f['quantity'],f['signed_funding_USDT']),('NO_POSITION_NO_PAST_MARK',False,0,0),'valid_fresh_flat_skip')
 flow=[defaultdict(Q) for _ in range(365)];trade_counts=Counter();fund_counts=Counter();owned_counts=Counter();nonzero_counts=Counter();rightcounts=Counter();skipcounts=Counter(bucket(x['event_us']) for x in skips)
 # Cumulative wallet cash change recorded as signed fill cost plus fees/funding.
 for t in trades:
  d=t['decimal_strings'];i=bucket(t['event_us']);delta=Q(d['position_delta']);q=Q(d['quantity']);fill=Q(d['fill_price']);mid=Q(d['execution_mid_price']);fee=Q(d['fee_amount']);ex=Q(d['execution_cost'])
  eq(q,abs(delta),'paid_quantity_delta');eq(ex,delta*(fill-mid),'signed_adverse_fill_cost');assert q>0 and fee>=0
  for k,v in {'fees_USDT':fee,'adverse_execution_USDT':ex,'fill_price_turnover_USDT':q*fill,'mid_price_turnover_USDT':q*mid,'signed_fill_cashflow_USDT':-delta*fill}.items():flow[i][k]+=v
  trade_counts[i]+=1
 for f in fund:
  i=bucket(f['event_us']);cash=Q(f['decimal_strings']['signed_funding_USDT']);flow[i]['signed_funding_USDT']+=cash;fund_counts[i]+=1;owned_counts[i]+=int(f['owned']);nonzero_counts[i]+=int(cash!=0)
  # Complete original account funding formula, including signed quantity.
  eq(cash,-Q(f['decimal_strings']['quantity'])*Q(f['decimal_strings']['mark_price'])*Q(f['decimal_strings']['rate_fraction']),'exact_account_funding_formula')
  if f['event_us'] in ENDS:
   flow[i]['right_boundary_signed_funding_USDT']+=cash;rightcounts[i]+=1
 # Independent boundary inventory via each symbol's cumulative paid delta and bisect.
 qbound=[]
 for at in BOUND:
  inventory=[]
  for s in SYMS:
   own=[t for t in trades if t['symbol']==s];when=[t['event_us'] for t in own];upto=bisect_right(when,at);qty=Q(0)
   for t in own[:upto]:
    d=t['decimal_strings'];eq(qty,Q(d['quantity_before']),'inventory_before_chain');qty+=Q(d['position_delta']);eq(qty,Q(d['quantity_after']),'inventory_after_chain')
   inventory.append(qty)
  qbound.append(inventory)
 eq(qbound[0],[Q(0)]*5,'genesis_flat');eq(qbound[-1],[Q(0)]*5,'paid_terminal_inventory_flat')
 values_by_day=[];doc=decode(read(H/(name+'_DAILY_ATTRIBUTION.json')));rows=doc['rows'];eq(len(rows),365,'365_daily_rows')
 for i,r in enumerate(rows):
  eq((r['decision_us'],r['interval_end_us'],r['regime'],r['date']),(BOUND[i],BOUND[i+1],labels[i]['regime'],labels[i]['date']),'daily_label_alignment')
  eq(r['start_NAV_USDT'],nav[i],'daily_start_NAV');eq(r['end_NAV_USDT'],nav[i+1],'daily_end_NAV')
  starts=[x*p for x,p in zip(qbound[i],marks[i])];ends=[x*p for x,p in zip(qbound[i+1],marks[i+1])]
  calc=dict(flow[i]);calc.update(net_NAV_change_USDT=nav[i+1]-nav[i],inventory_mark_change_USDT=sum(ends)-sum(starts))
  for f in MONEY:calc.setdefault(f,Q(0))
  calc['exact_mark_cashflow_net_USDT']=calc['inventory_mark_change_USDT']+calc['signed_fill_cashflow_USDT']+calc['signed_funding_USDT']-calc['fees_USDT']
  calc['native40_boundary_minus_mark_cashflow_residual_USDT']=calc['net_NAV_change_USDT']-calc['exact_mark_cashflow_net_USDT']
  calc['gross_mid_mark_PnL_bridge_USDT']=calc['inventory_mark_change_USDT']+calc['signed_fill_cashflow_USDT']+calc['adverse_execution_USDT']
  for f in MONEY:eq(r[f],calc[f],'daily_exact_'+f)
  eq(calc['native40_boundary_minus_mark_cashflow_residual_USDT'],0,'independent_daily_cash_inventory_NAV')
  counts=dict(paid_fill_legs=trade_counts[i],account_funding_rows=fund_counts[i],owned_funding_rows=owned_counts[i],nonzero_funding_rows=nonzero_counts[i],source_funding_rows=source_count[i],fresh_flat_no_past_mark_skips=skipcounts[i],right_boundary_funding_rows=rightcounts[i])
  for f in COUNTS:eq(r[f],counts[f],'daily_count_'+f)
  for side,notions,denom in [('start_exposure_exact',starts,nav[i]),('end_exposure_exact',ends,nav[i+1])]:
   for k,v in {'gross_marked_notional_USDT':sum(map(abs,notions)),'signed_net_marked_notional_USDT':sum(notions),'gross_NAV_weight':sum(map(abs,notions))/denom,'signed_net_NAV_weight':sum(notions)/denom}.items():eq(r[side][k],v,'boundary_'+k)
  eq(r['start_exposure_exact']['asset_quantities'],dict(zip(SYMS,qbound[i])),'boundary_asset_quantities');eq(r['start_exposure_exact']['asset_signed_marked_notional_USDT'],dict(zip(SYMS,starts)),'boundary_asset_notionals')
  eq(r['initial_wallet_return_contribution_percentage_points'],calc['net_NAV_change_USDT']/100,'initial_wallet_contribution')
  values_by_day.append(calc)
 with np.load(folder/'native_minutes.npz',allow_pickle=False) as z:val=z['values'];clock=z['close_us'];col=list(z['column_order'])
 eq(val.shape,(525600,36),'all525600_saved_minutes');assert np.array_equal(clock,np.arange(START+MIN,END+MIN,MIN,dtype=np.int64));eq(True,True,'minute_clocks_contiguous')
 w=val[:,[col.index(s+'_signed_weight') for s in SYMS]];nv=val[:,col.index('nav')];gross=np.abs(w).sum(1);net=w.sum(1)
 assert np.array_equal(nv[1439::1440],np.array([float(v) for v in nav[1:]]));eq(True,True,'saved_float64_daily_endpoints')
 sig=np.concatenate([np.sqrt(np.maximum(np.sum((w[i*1440:(i+1)*1440]@cov[i])*w[i*1440:(i+1)*1440],axis=1),0)) for i in range(365)])
 for i,r in enumerate(rows):
  ix=slice(i*1440,(i+1)*1440);ww=w[ix];gg=gross[ix];nn=net[ix];vv=nv[ix];ss=sig[ix]
  calc=dict(samples=1440,mean_gross_NAV_weight=gg.mean(),max_gross_NAV_weight=gg.max(),mean_signed_net_NAV_weight=nn.mean(),mean_absolute_net_NAV_weight=np.abs(nn).mean(),mean_long_NAV_weight=np.maximum(ww,0).sum(1).mean(),mean_short_NAV_weight=np.maximum(-ww,0).sum(1).mean(),mean_gross_marked_notional_USDT=(gg*vv).mean(),max_gross_marked_notional_USDT=(gg*vv).max(),mean_signed_net_marked_notional_USDT=(nn*vv).mean(),maximum_forecast_sigma=ss.max(),forecast_sigma_gt10pct_minutes=int((ss>.1).sum()))
  exp=r['minute_exposure_saved_float64']
  for f,v in calc.items():
   if f in ['samples','forecast_sigma_gt10pct_minutes']:eq(exp[f],v,'minute_'+f)
   else:near(exp[f],float(v),'minute_'+f)
  for j,s in enumerate(SYMS):near(exp['asset_mean_absolute_NAV_weight'][s],float(np.abs(ww[:,j]).mean()),'minute_asset_mean_abs')
 episodes=decode(read(H/(name+'_ALL_EPISODES.json')))['episodes'];eq(len(episodes),88,'all_episode_rows')
 def check_aggregate(g,ixs):
  for f in MONEY:eq(g[f],sum((values_by_day[i][f] for i in ixs),Q(0)),'aggregate_exact_'+f)
  for f in COUNTS:eq(g[f],sum(rows[i][f] for i in ixs),'aggregate_count_'+f)
  eq(g['days'],len(ixs),'aggregate_days');eq(g['minute_samples'],1440*len(ixs),'aggregate_minutes')
  eq(g['initial_wallet_return_contribution_percentage_points'],g['net_NAV_change_USDT']/100,'aggregate_contribution')
  exposure=g['exposure_saved_float64']
  if not ixs:eq(set(exposure.values()),{None,0},'empty_unknown_exposure');return
  mm=np.concatenate([np.arange(i*1440,(i+1)*1440) for i in ixs]);gn=gross[mm];nt=net[mm];na=nv[mm];sg=sig[mm]
  for f,v in {'mean_gross_NAV_weight':gn.mean(),'max_gross_NAV_weight':gn.max(),'mean_signed_net_NAV_weight':nt.mean(),'mean_gross_marked_notional_USDT':(gn*na).mean(),'max_gross_marked_notional_USDT':(gn*na).max(),'maximum_forecast_sigma':sg.max()}.items():near(exposure[f],float(v),'aggregate_exposure_'+f)
  eq(exposure['forecast_sigma_gt10pct_minutes'],int((sg>.1).sum()),'aggregate_forecast_minutes')
 for j,(lab,start,stop) in enumerate(spans):
  ep=episodes[j];eq((ep['episode_id'],ep['regime'],ep['start_us'],ep['end_us'],ep['start_date'],ep['last_decision_date']),(j+1,lab,BOUND[start],BOUND[stop],labels[start]['date'],labels[stop-1]['date']),'episode_exact_partition')
  eq(ep['start_NAV_USDT'],nav[start],'episode_start_NAV');eq(ep['end_NAV_USDT'],nav[stop],'episode_end_NAV');eq(ep['contiguous_episode_simple_NAV_return_fraction'],(nav[stop]-nav[start])/nav[start],'simple_unannualized_episode_return');check_aggregate(ep,list(range(start,stop)))
 for lab,agg in summary['runs'][name]['regimes'].items():check_aggregate(agg,[i for i,r in enumerate(rows) if r['regime']==lab])
 # Human CSV financial cells preserve exactly the authoritative rational values.
 csvrows=list(csv.DictReader((H/(name+'_DAILY_ATTRIBUTION.csv')).open()));eq(len(csvrows),365,'CSV365rows')
 for i,r in enumerate(csvrows):
  for f in MONEY+('start_NAV_USDT','end_NAV_USDT','initial_wallet_return_contribution_percentage_points'):eq(Q(r[f]),rows[i][f],'CSV_exact_'+f)
 sums={f:sum((v[f] for v in values_by_day),Q(0)) for f in MONEY}
 eq(sums,summary['conservation'][name]['exact_financial_sums'],'full_year_conservation_all_financial_fields');eq(sums['net_NAV_change_USDT'],Q(audit['performance']['net_PnL_USDT']),'audited_full_year_net')
 for f,af in [('fees_USDT','fees_USDT'),('adverse_execution_USDT','adverse_execution_cost_USDT'),('signed_funding_USDT','signed_funding_USDT'),('fill_price_turnover_USDT','turnover_USDT')]:eq(sums[f],Q(audit['performance'][af]),'audited_'+f)
 run_results[name]={'daily_rows':365,'NAV_boundaries':366,'minutes':525600,'episodes':88,'paid_legs':len(trades),'source_funding':5475,'account_funding':5470,'fresh_flat_plus15ms_skips':5,'max_exact_boundary_cashflow_residual':'0','net_USDT':str(sums['net_NAV_change_USDT']),'net_decimal':str(float(sums['net_NAV_change_USDT']))}
 daily_net[name]=[x['net_NAV_change_USDT'] for x in values_by_day]
 del val,w,gross,net,sig,nv
# Pairing conserves the difference across all365 days and all regime buckets.
for lab,p in summary['paired_dollar_difference'].items():
 ixs=[i for i,x in enumerate(labels) if x['regime']==lab]
 eq(p['HELD10_minus_BASELINE_net_USDT'],sum((daily_net['HELD10'][i]-daily_net['BASELINE'][i] for i in ixs),Q(0)),'paired_exact_'+lab)
 for key,f in [('HELD10_minus_BASELINE_fees_USDT','fees_USDT'),('HELD10_minus_BASELINE_execution_USDT','adverse_execution_USDT'),('HELD10_minus_BASELINE_signed_funding_USDT','signed_funding_USDT')]:eq(p[key],summary['runs']['HELD10']['regimes'][lab][f]-summary['runs']['BASELINE']['regimes'][lab][f],'paired_cost_'+lab)
eq(sum(v['HELD10_minus_BASELINE_net_USDT'] for v in summary['paired_dollar_difference'].values()),sum(daily_net['HELD10'])-sum(daily_net['BASELINE']),'paired_annual_conservation')
# New paired human CSV is complete and consistent with the exact episode artifacts.
paircsv=list(csv.DictReader((H/'ALL_EPISODES_PAIRED.csv').open()))
eq(len(paircsv),88,'paired_CSV_all88')
epraw={name:read(H/(name+'_ALL_EPISODES.json'))['episodes'] for name in NAMES}
for i,row in enumerate(paircsv):
 for f in ['episode_id','regime','start_date','last_decision_date','days']:
  eq(row[f],str(epraw['BASELINE'][i][f]),'paired_CSV_partition')
 for name in NAMES:
  ep=epraw[name][i]
  for f in ['net_NAV_change_USDT','start_NAV_USDT','end_NAV_USDT','fees_USDT','adverse_execution_USDT','signed_funding_USDT','gross_mid_mark_PnL_bridge_USDT','contiguous_episode_simple_NAV_return_fraction','paid_fill_legs','account_funding_rows']:
   raw=ep[f];want=raw['decimal_100_digits'] if isinstance(raw,dict) else str(raw)
   eq(row[name+'_'+f],want,'paired_CSV_financial_and_ratio')
  for f in ['mean_gross_NAV_weight','maximum_forecast_sigma']:
   eq(float(row[name+'_'+f]),ep['exposure_saved_float64'][f],'paired_CSV_exposure')
report_text=(H/'REGIME_ATTRIBUTION.md').read_text()
for name in NAMES:
 for label in ['BULL','BEAR','REBOUND']:assert summary['runs'][name]['regimes'][label]['net_NAV_change_USDT']<0
 for label in ['RANGE','CORRECTION']:assert summary['runs'][name]['regimes'][label]['net_NAV_change_USDT']>0
eq('15 milliseconds after genesis' in report_text,True,'final_text_correct_genesis_clock')
eq('Both saved runs lost money in the bull, bear and rebound buckets.' in report_text,True,'final_text_main_finding_exact')
eq('11 days in 4 episodes' in report_text,True,'final_text_rebound_limit')
for p in tracked:eq(digest(p),before[str(p.relative_to(R))],'frozen_or_output_unchanged')
for pins in used_pins.values():
 for p,sha in pins.items():eq(digest(R/p),sha,'saved_source_outputs_unchanged')
report={'schema':'INDEPENDENT_SAVED_REGIME_ATTRIBUTION_REVIEW_V1','status':'PASS_EXACT_SAVED_ATTRIBUTION_WITH_DISCLOSED_QUALIFICATIONS','scope':'Independent read-only saved-event/canonical-mark algebra. No financial kernel, strategy, simulator, finance account, replay, model fit, new signal, or network imported or run.','checks':dict(checks),'total_asserted_checks':sum(checks.values()),'synthetic_boundary_tests':boundary_tests,'runs':run_results,'paired_CSV_all88_checked':True,'final_human_report_read_and_checked':True,'all88episodes_checked_per_run':True,'all365dailyNAV_and_cost_rows_checked_per_run':True,'paired_all_regime_and_annual_conservation':True,'exact_cash_inventory_NAV_daily_residual_USDT':'0','numeric_float_exposure_max_absolute_errors':dict(max_float_error),'frozen_rule_and_label_hashes_unchanged':True,'attribution_and_source_outputs_unchanged':True,'reviewed_artifact_SHA256':before,'reviewed_saved_input_SHA256':used_pins,'observations':['All730daily net/cost/event allocations,176contiguous episode aggregates and all regime/paired differences recompute exactly. No unknown label was silently omitted; actualUNKNOWN has0days, costs and samples.','Every exact boundary residual between recorded NAV change and independent paid-fill cashflow plus marked-inventory change minus fees plus funding is zero. Gross-mid bridge is separately checked from inventory and execution-mid cashflows.','Minute exposure summaries are preserved float64 arithmetic. Recomputed sigma uses an independent matrix-multiplication expression; small floating-operation differences are disclosed separately from exact dollar checks.','Source funding has5475unique records. Each account records5470, with five fresh-flat skipped events preserving originalSTART+15000microsecond clocks. Exact non-genesis midnight events map to the preceding interval; midnight+1microsecond maps to the next.','The initial producer boundary wording described skipped events atSTART. Parent corrected this before the final reviewed artifact set to actualSTART+15000microseconds. Final JSON, report and original retained clocks agree; no arithmetic change was needed.'],'qualifications':['New analyst-selected threshold on already seenDEV; descriptive allocation of saved PnL to contemporaneous BTC-proxy states, not causal treatment effects, regime-skill proof, a trading rule, OOS, significance or robustness evidence.','REBOUND has11days in4episodes; all88episodes retained per account. No disjoint-regime annualization.','Both accounts retain the previously audited actual postfunding midnight phase deviation. This audit establishes saved arithmetic and allocation, not intended prefunding experimental conformity.','Native source arrival, funding units, venue, live execution and liquidation certification remain outside scope. The source qualification and prior convention review remain applicable.']}
(O/'SAVED_ATTRIBUTION_REVIEW.json').write_text(json.dumps(report,indent=2,sort_keys=True,allow_nan=False)+'\n')
(O/'SAVED_ATTRIBUTION_REVIEW.md').write_text('''# Independent saved attribution review\n\nPASS for exact saved-data attribution, subject to the disclosed DEV, source and phase qualifications.\n\n- Recomputed all365daily NAV changes, exact fees/execution/funding/turnover and exact marked-inventory/cashflow bridges for each account. All exact daily cashflow/NAV residuals are zero.\n- Checked all88contiguous episodes per account, every regime bucket and paired full-year conservation. No day, cost or episode is omitted. UNKNOWN has no observed days.\n- Recomputed all525600saved-minute exposure samples per account, including per-asset exposure and held-weight forecast risk. Float64 summaries agree within machine-operation rounding; exact dollar assertions require equality.\n- Verified5475source funding records,5470account records and5fresh-flat skips. Synthetic boundary tests confirm exact midnight goes to the prior interval and+1microsecond goes to the next.\n- The five skipped genesis-day events are actually15ms afterSTART. Parent corrected the initial atSTART wording before final review; current wording, arithmetic and retained clocks agree.\n- Frozen rule/labels, attribution deliverables and pinned source/saved account outputs are unchanged. No finance kernel, replay, account construction, model fit or network was run.\n\nBaseline net−170.3719598005638103848USDT; HELD10 net+366.0809610143028640295USDT. The difference is536.4529208148666744143USDT. This is descriptive saved2025DEV attribution. The rebound bucket has only11days in4episodes. The shared actual postfunding midnight deviation remains; arithmetic validity does not establish intended prefunding conformity or investment validity.\n''')
print(json.dumps({'status':report['status'],'checks':sum(checks.values()),'review_SHA256':digest(O/'SAVED_ATTRIBUTION_REVIEW.json'),'runs':run_results},sort_keys=True))
