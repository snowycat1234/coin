"""Read-only convention/source/classifier review. No strategy outcome join."""
from pathlib import Path
from fractions import Fraction as F
from collections import Counter
import hashlib,json,subprocess,zipfile,io,runpy,random
import numpy as np
ROOT=Path('/workspace/scratch/68ef1b82bcac')
BASE=ROOT/'coin_recovery_20261018'
OUT=BASE/'regime_attribution2025_v1/review'
REPO=ROOT/'coin_ef67_selector_restore_qa.git'
DAY=86400000000
START=1735689600000000
END=1767225600000000
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args): return subprocess.check_output(['git','--git-dir='+str(REPO),*args])
commit=git('rev-parse','HEAD').decode().strip()
paths=['scripts/investment/market_regime.py','scripts/investment/regime_ranking_screen.py','modules/transformer_v2/data.py','scripts/investment/shared_direction_model.py','docs/MARKET_REGIME_20261005.md','docs/RESEARCH_DECISION_LOG.md','scripts/research/patch_price_rank_inputs.py']
priors=[]
for p in paths:
 body=git('show',commit+':'+p)
 priors.append(dict(path=p,commit=commit,GitBlobSHA1=git('rev-parse',commit+':'+p).decode().strip(),SHA256=sha(body),bytes=len(body)))
freeze_path=BASE/'regime_attribution2025_v1/RULE_FREEZE.json'
freeze_raw=freeze_path.read_bytes();freeze=json.loads(freeze_raw)
assert sha(freeze_raw)=='31c90233b335c9ce2d45f2388a844a3e4da6df814af5e88957eeca9ad57997e4'
pins=[]
for pin in freeze['source_pins']:
 b=(BASE/pin['path']).read_bytes();assert sha(b)==pin['sha256'] and len(b)==pin['bytes']
 pins.append(dict(path=pin['path'],SHA256=sha(b),bytes=len(b)))
classifier=BASE/'regime_attribution2025_v1/classifier.py'
assert sha(classifier.read_bytes())==freeze['classifier']['sha256']
namespace=runpy.run_path(str(classifier));classify=namespace['classify']
with np.load(BASE/'restored2025/SOURCE_WARMUP_200_CLOSE_ONLY.npz',allow_pickle=False) as z:
 wt=z['close_available_us'];wp=z['close']
daily=json.loads((BASE/'restored2025/prepared_2025/DAILY.json').read_bytes())
assert len(daily)==1825
btc={r['close_us']:r['close'] for r in daily if r['symbol']=='BTCUSDT'}
assert len(btc)==365 and sorted(btc)==list(range(START,END,DAY))
assert wt.shape==(200,) and wp.shape==(200,5) and np.all(np.diff(wt)==DAY) and wt[-1]==START
assert np.isfinite(wp).all() and (wp>0).all() and np.float64(btc[START]).tobytes()==wp[-1,0].tobytes()
t=np.concatenate((wt,np.arange(START+DAY,END,DAY,dtype=np.int64)))
c=np.concatenate((wp[:,0],np.array([btc[i] for i in range(START+DAY,END,DAY)])))
assert len(t)==len(c)==564 and np.all(np.diff(t)==DAY) and np.isfinite(c).all() and (c>0).all()
for relative in ['controlled_sma2025_v2r1/source_recipe.npz','held_risk_sma2025_v1/source_recipe.npz']:
 with np.load(BASE/relative,allow_pickle=False) as z:
  assert np.array_equal(z['close_available_us'],t) and z['source_close'][:,0].tobytes()==c.tobytes()
  assert z['completed_close'][:,0].tobytes()==c[199:].tobytes()
# Independent explicit mutually exclusive predicates, not imported classifier branches.
def independent(w):
 q=[F(str(float(x))) for x in w];last=q[-1];mean=sum(q,F(0))/200;r=last/q[-21]-1
 checks={'RANGE':abs(r)<=F(1,50),'BULL':last>=mean and r>F(1,50),'CORRECTION':last>=mean and r<-F(1,50),'REBOUND':last<mean and r>F(1,50),'BEAR':last<mean and r<-F(1,50)}
 assert sum(checks.values())==1
 return next(k for k,v in checks.items() if v)
labels=[]
for j,decision in enumerate(range(START,END,DAY)):
 w=c[j:j+200];cl=t[j:j+200];r=classify(w,cl,int(decision))
 assert cl[-1]==decision and r['regime']==independent(w)
 assert classify(w.copy(),cl.copy(),int(decision))==r
 labels.append(r['regime'])
# Controlled numerical edge and invalid-source tests.
clock=list(range(START-199*DAY,START+DAY,DAY));tests=[]
def test(name,w,cl=clock,at=START,observed=True,expected=None):
 r=classify(w,cl,at,source_observed=observed)['regime'];assert r==expected,(name,r,expected);tests.append(name)
w=[100.0]*200
test('exact zero return range',w,expected='RANGE')
for last,expected in [(102.,'RANGE'),(98.,'RANGE'),(102.0001,'BULL'),(97.9999,'BEAR')]:
 a=w.copy();a[-1]=last;test('return boundary '+str(last),a,expected=expected)
a=[200.]*200;a[-21]=100.;a[-1]=103.;test('rebound below mean positive momentum',a,expected='REBOUND')
a=[50.]*200;a[-21]=100.;a[-1]=97.;test('correction above mean negative momentum',a,expected='CORRECTION')
# Mean equality with nonzero momentum: values sum to exactly 20000, last100.
a=[100.]*200;a[-21]=80.;a[0]=120.;test('mean equality positive momentum bull',a,expected='BULL')
a=[100.]*200;a[-21]=120.;a[0]=80.;test('mean equality negative momentum correction',a,expected='CORRECTION')
test('unqualified source',w,observed=False,expected='UNKNOWN')
test('missing close',w[:-1],expected='UNKNOWN')
test('missing clock',w,cl=clock[:-1],expected='UNKNOWN')
test('stale latest clock',w,at=START+DAY,expected='UNKNOWN')
test('future latest clock',w,at=START-DAY,expected='UNKNOWN')
cl=clock.copy();cl[2]-=1;test('noncontiguous clock',w,cl=cl,expected='UNKNOWN')
for bad in [0.,-1.,float('nan'),float('inf')]:
 a=w.copy();a[15]=bad;test('invalid close '+str(bad),a,expected='UNKNOWN')
rng=random.Random(79813)
for i in range(200):
 a=[rng.uniform(10,1000) for _ in range(200)];assert classify(a,clock,START)['regime']==independent(a)
# Verify old INPUTS clock convention without joining any strategy output.
z=zipfile.ZipFile(ROOT/'multiregime_delivery/coin_multiregime_sparse_inputs_20261008.zip')
with np.load(io.BytesIO(z.read('INPUTS.npz')),allow_pickle=False) as a:
 assert a['symbol_order'][0]=='BTCUSDT'
 old_dates=a['dates_us'];old_c=a['close'][:,0]
 assert len(old_dates)==1828 and np.isfinite(old_c).all() and a['availability'][:,0].all()
 matches=0
 for i,stamp in enumerate(old_dates):
  k=int(stamp)+DAY
  if k in btc: assert np.float64(old_c[i]).tobytes()==np.float64(btc[k]).tobytes();matches+=1
 old_summary=dict(rows=len(old_dates),btc_finite_and_available=1828,dates_are_observation_open_us=True,declared_close_available_us='dates_us+86400000000',canonical2025_overlap_bit_equal=matches,last_observation_date_us=int(old_dates[-1]),last_close=float(old_c[-1]),last_close_available_us=int(old_dates[-1])+DAY)
report=dict(schema='INDEPENDENT_REGIME_CONVENTION_SOURCE_REVIEW_V1',status='PASS_WITH_DECLARED_SOURCE_TIMING_QUALIFICATIONS',scope='Offline local convention/source/classifier review only; no strategy outcomes joined, finance imports, account construction, network, or provider downloads.',frozen_rule_SHA256=sha(freeze_raw),classifier_SHA256=sha(classifier.read_bytes()),prior_repository=str(REPO.relative_to(ROOT)),prior_commit=commit,prior_sources=priors,prior_conventions=[dict(kind='BTC_PAST_RULE_WITH_CRASH_OVERRIDE',path='scripts/investment/market_regime.py',lines='16-35',causal=True,description='Crash precedence: return1<-5% and vol30*sqrt365>80%; otherwise ma200distance>0 and return20>0 BULL, both<0 BEAR, else SIDEWAYS. Complete same-close availability calendar required.',unsuitable='No REBOUND/CORRECTION distinction or2% RANGE band. HIGH_VOL_CRASH precedence differs. Related prior, not the requested classifier.'),dict(kind='SLOW_FAST_PRICE_SIGN_MAP',path='scripts/investment/regime_ranking_screen.py',lines='19-45',causal=True,description='Inclusive SMA50/SMA200 signs with vol30>vol200. Four sign quadrants and equality CASH; decision-log calls below-slow/above-fast down/rebound and above-slow/below-fast up/pullback.',unsuitable='SMA50 rather than20d return; no requested RANGE band; a fixed expert-weight mechanism probe, not the requested descriptive label taxonomy.'),dict(kind='TRAINING_ONLY_GMM_RELATIVE_CLUSTERS',path='scripts/investment/market_regime.py',lines='37-72',causal=True,description='Past-only fitted StandardScaler and3-component GMM, named by training-center trend/breadth, with past-price crash override.',unsuitable='Relative learned clusters, no requested rebound/range partition; fitting is outside this source-only task.'),dict(kind='FUTURE_VOLATILITY_TARGETS',path='modules/transformer_v2/data.py',lines='27-39',causal=False,description='INPUTS.regime contains future7/30/60day log standard deviation of mean cross-asset daily log returns; importer applies61day maturity clock.',unsuitable='Future target, unavailable at contemporaneous decision, not bull/bear labels.')],finding='No suitable pre-existing bound requested five-way partition found in the inspected scope. New2% RANGE partition is analyst-specified seen-DEV description and is not inherited, OOS, or a trading gate.',source_pins_verified=pins,source_validation=dict(warmup_rows=200,warmup_first_close_available_us=int(wt[0]),warmup_last_close_available_us=int(wt[-1]),canonical_btc_daily_rows=365,combined_btc_source_rows=564,completed_inclusive200close_windows=365,source_recipe_BTC_panels_bit_equal=True,source_clock='At daily decision t use completed trade close available_us==t, never observation-open t as same-day close.',source_quality='Recovered genuine TRADE close values under declared completed-close availability. Warmup provenance inherited from exact published export; no fresh2024 raw verification. Actual source arrival not certified.',multiregime_clock_review=old_summary),classifier_validation=dict(actual_source_decisions=365,independent_predicate_parity=True,mutually_exclusive_exhaustive_predicates=True,controlled_tests=tests,random_numerical_predicate_tests=200,regime_counts=dict(Counter(labels)),source_observed_false_maps_UNKNOWN=True),qualifications=['Review is scoped to the named local saved archives, sourcebook metadata/code, and existing bare repository snapshot; no claim of an exhaustive global or remote historical search.','Only BTC source-close and declared-clock fields decoded from source_recipe; strategy weights, directions, return or account outputs were not joined.','Source recovery reviews do not certify arrival timing, funding units, venue, liquidation, live execution, or new financial authority.','Classifier accepts an explicit source_observed flag; the calling source qualification must set it false for generated/unqualified sources. Classifier itself cannot infer provenance from numeric values.','Malformed nonnumeric objects are outside its float64 source-array contract; numeric invalid/unavailable/stale/future/noncontiguous cases were tested.'])
(OUT/'CONVENTION_SOURCE_REVIEW.json').write_text(json.dumps(report,indent=2,sort_keys=True,allow_nan=False)+'\n')
md='''# Convention, source and classifier review\n\nPASS with declared source-timing qualifications. The frozen rule was not changed. No strategy outcomes were joined.\n\n- Prior causal BTC rule: completed close relative to inclusive SMA200 and20day return, plus a crash override. It has BULL/BEAR/SIDEWAYS/HIGH_VOL_CRASH, without the requested rebound/correction and2% range split.\n- Prior slow/fast map: inclusive SMA50/SMA200 sign quadrants, including a descriptively named down/rebound quadrant. It has no20day momentum range band and was an expert-weight probe.\n- Prior GMM: relative training-fitted clusters, outside this no-fit task.\n- INPUTS.regime: future7/30/60day volatility targets with61day maturity, unsuitable for decision-time state labels.\n\nExact prior commit, Git blob IDs and SHA256s are in the companion JSON. The inspected saved snapshot supports related prior causal ideas, not an inherited requested taxonomy. The frozen2% rule is a new analyst-chosen seen-DEV description.\n\nCanonical BTC closes:365 daily records and200 inherited warmup closes, with the January1 overlap deduplicated, give564 contiguous closes and365 full inclusive200close decision windows. The BTC panels bit-match both source_recipe archives. Availability is the declared completed-close boundary; native arrival timing is uncertified. Warmup provenance is inherited and was not freshly reconstructed here.\n\nImportant old archive clock: INPUTS dates_us is observation OPEN, so completed close availability is dates_us+DAY. The2025 overlap matches canonical DAILY only after that shift. It must not be joined directly to canonical close_us.\n\nClassifier:365 source windows match independent mutually-exclusive/exhaustive predicates; exact2% boundaries, zero, mean equality, rebound/correction, invalid closes, stale/future/noncontiguous clocks and unqualified inputs pass.200 randomized numerical inputs also agree.\n\nThe caller must supply source_observed=False for generated/unqualified sources. Numeric values cannot authenticate their own provenance. This review does not establish investment, OOS, venue or live execution validity.\n'''
(OUT/'CONVENTION_SOURCE_REVIEW.md').write_text(md)
print(json.dumps({'status':report['status'],'counts':report['classifier_validation']['regime_counts'],'source_windows':365,'controlled_tests':len(tests),'review_SHA256':sha((OUT/'CONVENTION_SOURCE_REVIEW.json').read_bytes()),'rule_unchanged':sha(freeze_path.read_bytes())==sha(freeze_raw)},sort_keys=True))
