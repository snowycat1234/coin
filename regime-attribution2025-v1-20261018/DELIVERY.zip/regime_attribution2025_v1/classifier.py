"""Descriptive source-only classifier. No strategy imports or outcome reads."""
from fractions import Fraction as F
import math
LABELS=('BULL','BEAR','REBOUND','RANGE','CORRECTION','UNKNOWN')
DAY=86_400_000_000

def classify(window,clocks,decision_us,*,source_observed=True):
    """BTC daily observations, oldest to newest; inclusive 200-day source window."""
    if not source_observed or len(window)!=200 or len(clocks)!=200:
        return dict(regime='UNKNOWN',reason='UNAVAILABLE_OR_UNQUALIFIED_200_CLOSE_WINDOW')
    if clocks[-1]>decision_us or clocks[-1]!=decision_us or any(b-a!=DAY for a,b in zip(clocks,clocks[1:])):
        return dict(regime='UNKNOWN',reason='NONCONTIGUOUS_STALE_OR_FUTURE_SOURCE_CLOCK')
    if any(not math.isfinite(float(x)) or float(x)<=0 for x in window):
        return dict(regime='UNKNOWN',reason='NONPOSITIVE_OR_NONFINITE_SOURCE_CLOSE')
    close=[F(str(float(x))) for x in window]
    last=close[-1];mean=sum(close,F(0))/200;ret=last/close[-21]-1
    if abs(ret)<=F(1,50):label='RANGE'
    elif last>=mean:label='BULL' if ret>0 else 'CORRECTION'
    else:label='REBOUND' if ret>0 else 'BEAR'
    return dict(regime=label,reason='QUALIFIED_CONTIGUOUS_DECLARED_AVAILABLE_CLOSES',close=last,sma200=mean,return20=ret)
