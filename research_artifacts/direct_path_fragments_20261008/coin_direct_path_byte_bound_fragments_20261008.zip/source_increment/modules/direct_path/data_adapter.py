"""Byte-verified small fragment loader; never fits or reads later market stores."""
from pathlib import Path
import hashlib,json,gzip
import numpy as np
from .prototype import Context,CORE5,E5
from .training import validate_fragment

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def load_fragment(root,entry):
    root=Path(root);path=root/entry['file']
    if path.name!=entry['file'] or sha(path)!=entry['sha256']:raise ValueError('Exact delivered fragment bytes')
    proof=root/entry['receipt_file']
    if proof.name!=entry['receipt_file'] or sha(proof)!=entry['receipt_sha256']:raise ValueError('Exact derivation receipt bytes')
    receipt=json.loads(gzip.decompress(proof.read_bytes()))
    if receipt['binding']!=entry['binding'] or receipt['window_id']!=entry['window_id']:raise ValueError('Source recipe/data/teacher identity')
    if len(entry['market13_order'])!=13 or len(entry['feature_names'])!=43:raise ValueError('Exact named43feature contract')
    with np.load(path,allow_pickle=False) as z:a={k:z[k].copy() for k in z.files}
    if tuple(a['symbol_order'])!=CORE5 or tuple(a['expert_order'])!=E5:raise ValueError('Frozen bank and asset order')
    d=a['decision_us'];contexts=[Context(int(t),int(a['market_state13_available_us'][i]),a['expert_targets'][i],a['expert_eligible'][i],a['past_returns30'][i],a['market_state13'][i],a['target_available_us'][i]) for i,t in enumerate(d)]
    if (a['prices'].shape!=(len(d)+1,5) or a['funding_coeff'].shape!=(len(d),5)
        or not np.isfinite(a['prices']).all() or not np.isfinite(a['funding_coeff']).all()
        or not np.array_equal(a['price_close_us'],np.r_[d,d[-1]+86400000000])):raise ValueError('Full finite price and funding outcomes')
    if np.any(a['price_available_us']>a['price_close_us']):raise ValueError('Price availability clock')
    if not np.array_equal(a['global_forced_terminal_day'],np.arange(len(d))==len(d)-1):raise ValueError('Per-fragment common paid finalcash')
    request=a['greedy_request']
    if request.shape!=(len(d),5) or not all(np.array_equal(v,np.eye(5)[int(np.argmax(v))]) for v in request):raise ValueError('Actual candidate requests, not ramped budgets')
    fragment=dict(window_id=entry['window_id'],contexts=contexts,prices=a['prices'],funding_coeff=a['funding_coeff'],greedy_request=request,
        label_available_us=a['label_available_us'],binding=entry['binding'])
    validate_fragment(fragment,entry['window_id'])
    for v in a.values():v.flags.writeable=False
    return fragment

def load_training_and_validation(root,expected_index_sha256):
    root=Path(root);index=root/'INDEX.json'
    if sha(index)!=expected_index_sha256:raise ValueError('Exact pack index supplied by producer')
    manifest=json.loads(index.read_text())
    if manifest['schema']!='BYTE_BOUND_DIRECT_PATH_FRAGMENTS_V1':raise ValueError('Exact fragment protocol')
    entries=manifest['fragments']
    if [e['window_id'] for e in entries]!=['BEAR2022NOV','RECOVERY2023JAN','H1_TRAIN','H1_VALIDATE']:raise ValueError('Predeclared separate calendar roles')
    # The caller may fit ONLY these first three. Validation is a separate wallet
    # and never contributes to standardizer, epochs, parameters or checkpoint.
    train=[load_fragment(root,e) for e in entries[:3]]
    validation=load_fragment(root,entries[3])
    return train,validation,manifest
