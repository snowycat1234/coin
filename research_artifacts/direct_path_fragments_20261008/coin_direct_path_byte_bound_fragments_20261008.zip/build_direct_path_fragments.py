"""Prepare the fixed two-arm protocol from existing complete stores only."""
from pathlib import Path
from decimal import Decimal as D
from datetime import datetime,timezone
import hashlib,json,gzip
import numpy as np
import polars as pl
from modules.native_action.e5_inputs import Inputs,mapper
from modules.direct_path.data_adapter import load_fragment
from modules.direct_path.prototype import Context,map_budget,E5,CORE5

O=Path('/workspace/scratch/68ef1b82bcac/native_history_experiment');S=O.parent
R=S/'independent_native_recovery/source';OUT=O/'direct_path_fragments';DAY=86400000000
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
stamp=lambda s:int(datetime.fromisoformat(s).replace(tzinfo=timezone.utc).timestamp()*1e6)
SPECS=[('BEAR2022NOV','BEAR2022NOV','2022-11-01','2022-12-01',S/'bear_recovery_e5_inputs',O/'e5_pilot_retry/BEAR2022NOV/teacher/teacher.jsonl',None),
       ('RECOVERY2023JAN','RECOVERY2023JAN','2023-01-01','2023-02-01',S/'bear_recovery_e5_inputs',O/'e5_pilot_retry/RECOVERY2023JAN/teacher/teacher.jsonl',None),
       ('H1_TRAIN','H1_E5','2024-01-01','2024-05-01',S/'h1_fixed_e5_inputs',O/'e5_h1/teacher/teacher.jsonl','2aa3cd49dbf5b249127a3356b06c324663fce28865af70b4af92ec03df4fda2a'),
       ('H1_VALIDATE','H1_E5','2024-05-01','2024-07-01',S/'h1_fixed_e5_inputs',O/'e5_h1/teacher/teacher.jsonl','2aa3cd49dbf5b249127a3356b06c324663fce28865af70b4af92ec03df4fda2a')]

def build(spec):
    tag,source_tag,left,right,work,teacher,expected=spec;start,end=stamp(left),stamp(right)
    inputs=Inputs(source_tag,work=work,expected_manifest_sha=expected);a=inputs.a
    idx=np.flatnonzero((a['decision_us']>=start)&(a['decision_us']<end));dates=a['decision_us'][idx]
    assert np.array_equal(dates,np.arange(start,end,DAY,np.int64))
    original={r['decision_us']:(r,line) for line in teacher.read_text().splitlines() for r in [json.loads(line)]}
    requests=[];maturity=[];teacher_sources=[]
    for t in dates:
        row,line=original[int(t)];k=row['candidate_winner'];p=row['candidates'][k];request=np.asarray(p['request'])
        assert row['action_order']==list(E5) and all(row['e5_valid'])
        assert np.array_equal(request,np.eye(5)[int(request.argmax())])
        requests.append(request);maturity.append(row['label_available_us'])
        teacher_sources.append(dict(decision_us=int(t),source_row_SHA256=hashlib.sha256(line.encode()).hexdigest(),source_state_hash=row['state_hash'],
            candidate_index=k,candidate_request=p['request'],source_label_available_us=row['label_available_us'],
            source_optimization_allowed=row['optimization_allowed'],source_forced_terminal=row['forced_terminal_day']))
    prices=[];price_clocks=[];coeff=np.zeros((len(dates),5));events=[];source_files={}
    for j,s in enumerate(CORE5):
        p=work/'data/normalized'/(s+'_daily.parquet');daily=pl.read_parquet(p);source_files[str(p)]=sha(p)
        table={r['close_us']:r for r in daily.iter_rows(named=True)};times=np.r_[dates,end]
        prices.append([table[int(t)]['close'] for t in times]);price_clocks.append([table[int(t)]['available_us'] for t in times])
        assert np.array_equal(np.asarray(prices[-1][:-1]),a['market_close'][idx,j])
        p=work/'data/normalized'/(s+'_funding_events.parquet');fund=pl.read_parquet(p);source_files[str(p)]=sha(p)
        selected=fund.filter((pl.col('calc_time_ms')*1000>=start)&(pl.col('calc_time_ms')*1000<end)).sort('calc_time_ms')
        marks=[]
        for p in sorted((work/'data/normalized/minute'/s/'markPriceKlines').glob('*.parquet')):
            m=pl.read_parquet(p).select('available_us','close').filter((pl.col('available_us')>=start)&(pl.col('available_us')<=end))
            if m.height:marks.append(m);source_files[str(p)]=sha(p)
        marks=pl.concat(marks).sort('available_us');mt=marks['available_us'].to_numpy();mp=marks['close'].to_numpy()
        for row in selected.iter_rows(named=True):
            t=int(row['calc_time_ms'])*1000;rate=float(row['last_funding_rate']);assert np.isfinite(rate)
            if t==start:
                events.append(dict(symbol=s,event_us=t,raw_rate=rate,coefficient_included=False,reason='KNOWN_FRESH_CASH_INITIAL_OWNERSHIP_ZERO'))
                continue
            k=int(np.searchsorted(mt,t,side='left'))-1
            assert k>=0 and int(mt[k])<t and t-int(mt[k])<=60000000,'Complete strictly-past actual minute mark'
            day=(t-start-1)//DAY;value=float(D(str(float(mp[k])))*D(str(rate)))
            assert 0<=day<len(dates);coeff[day,j]+=value
            events.append(dict(symbol=s,event_us=t,raw_rate=rate,mark_close_us=int(mt[k]),strictly_past_mark_price=float(mp[k]),
                coefficient_USDT_per_contract=value,day_index=int(day),coefficient_included=True))
    arrays={k:a[k][idx].copy() for k in ('decision_us','expert_targets','expert_eligible','past_returns30','market_state13','market_state13_available_us','target_available_us')}
    arrays.update(symbol_order=a['symbol_order'],expert_order=a['expert_order'],prices=np.asarray(prices).T,price_close_us=np.r_[dates,end],
        price_available_us=np.max(np.asarray(price_clocks),axis=0),funding_coeff=coeff,greedy_request=np.asarray(requests),
        label_available_us=np.asarray(maturity,np.int64),global_forced_terminal_day=np.arange(len(dates))==len(dates)-1)
    assert np.all(arrays['label_available_us'][:-1]>=dates[:-1]+DAY) and np.all(arrays['label_available_us'][:-1]<end)
    assert np.all(arrays['target_available_us']<=dates[:,None]) and np.all(arrays['market_state13_available_us']<=dates)
    f=OUT/(tag+'.npz');np.savez_compressed(f,**arrays)
    binding=dict(input_npz_sha256=inputs.manifest['inputs']['sha256'],teacher_jsonl_sha256=sha(teacher),
        expert_identity_sha256=inputs.binding['expert_identity_sha256'],mapper_sha256=inputs.binding['mapper_sha256'],market_binding_sha256=inputs.binding['market_binding_sha256'])
    receipt=dict(window_id=tag,source_window_id=source_tag,calendar=dict(start_us=start,end_exclusive_us=end,days=len(dates)),binding=binding,
        source_manifest_sha256=sha(work/'inputs'/(source_tag+'_MANIFEST.json')),source_files_SHA256=source_files,
        teacher_row_receipts=teacher_sources,funding_events=sorted(events,key=lambda r:(r['event_us'],r['symbol'])),
        outcomes_only=['prices[1:]','funding_coeff','label_available_us','teacher_candidate_request'],
        terminal_rule='Only the fragment lastday is forced zero target and paidclose. Its source teacher request is retained for provenance but excluded from CE, even if source fullH1 did not terminate atApr30.',
        first_state='Independent10k cash and100%CASH budget for EACH fragment; no discontinuous wallet splice.',
        no_fits_no_new_native_replays_no_new_downloads=True)
    proof=OUT/(tag+'_SOURCE_RECEIPT.json.gz');proof.write_bytes(gzip.compress(json.dumps(receipt,indent=2).encode(),compresslevel=6,mtime=0))
    order=a['market_state13_order'].tolist()
    feature_names=['market.'+n for n in order]+['expert.'+x+'.'+s for x in E5 for s in CORE5]+['eligible.'+x for x in E5]
    entry=dict(window_id=tag,file=f.name,sha256=sha(f),bytes=f.stat().st_size,binding=binding,receipt_file=proof.name,receipt_sha256=sha(proof),
        market13_order=order,feature_names=feature_names)
    fragment=load_fragment(OUT,entry)
    # Deterministic continuous FAMILY request checks the numerical prototype
    # mapper against the existing native mapper without any policy fitting.
    prior=np.eye(5)[0];maximum=0.
    for t,c in zip(dates,fragment['contexts'],strict=True):
        request=np.array([0.,.25,.25,.25,.25]);p=mapper(prior,request,inputs.context_at(int(t)));q=map_budget(prior,request,c)
        maximum=max(maximum,float(np.max(np.abs(np.asarray(p.targets)-q['targets']))),float(np.max(np.abs(np.asarray(p.budget)-q['budget']))))
        prior=np.asarray(p.budget)
    assert maximum<1e-12;entry['existing_mapper_maximum_error']=maximum
    return entry

def main():
    OUT.mkdir(exist_ok=False);entries=[build(spec) for spec in SPECS]
    assert len({e['binding']['expert_identity_sha256'] for e in entries})==1 and len({e['binding']['mapper_sha256'] for e in entries})==1
    index=dict(schema='BYTE_BOUND_DIRECT_PATH_FRAGMENTS_V1',protocol_source_commit='32e978f7750dfd14c1ec2683abcae33aa6271f10',fragments=entries,
        training_fragments=3,training_intervals=182,CE_learning_labels=179,validation_intervals=61,planned_cloud_fits=2,local_fits=0,
        source_full_inputs_commit='7b5b9f702f5f04d25fc8d12fa8b928fa3e604d93',separate_fresh_10k_wallets=True,
        feature_contract='Exact shared43 market13+25E5targets+5eligibility; no teacher wallet/budget input, no future outcome feature.',
        funding_contract='sum(actual strictly-past event mark*raw rate), events(decision,nextdecision], globalend excluded; initial event has verified zero fresh-cash ownership. Conditional funding scale1, no missing-mark imputation.',
        proxy_role='Daily full-fill surrogate, not native account. Native financial validation is required; known tailfailurewitness is excluded from training/validation/model selection.')
    assert all(e['market13_order']==entries[0]['market13_order'] for e in entries)
    index.update(market13_order=entries[0]['market13_order'],feature_names=entries[0]['feature_names'],
        feature_schema_SHA256=hashlib.sha256(json.dumps(entries[0]['feature_names'],sort_keys=True).encode()).hexdigest())
    (OUT/'INDEX.json').write_text(json.dumps(index,indent=2)+'\n');print(json.dumps(dict(fragments=entries,index_SHA256=sha(OUT/'INDEX.json'),total_bytes=sum(p.stat().st_size for p in OUT.iterdir()))))

if __name__=='__main__':main()
