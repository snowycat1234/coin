"""Exact five-slot continuation, causal first-X and tape-only compatibility."""
import numpy as np
import pytest
from modules.native_action.e5_teacher import E5,DayContext
from modules.native_action.e5_inputs import mapper
from modules.native_action.multiday_e5 import evaluate_candidates_7d
from scripts.investment import perpetual_directional as old
from scripts.investment.resumable_perpetual import NativeDailySimulator
from quant.bybit_isolated_account import BybitIsolatedAccount
from test_resumable_perpetual import synthetic,START,CORE5

def make(days=14):
    sim=NativeDailySimulator(synthetic(days),'LONG_SHORT',old.COSTS[0],old.UNITS[0],
        account_factory=BybitIsolatedAccount,persist_cash_close=True,final_day_target_zero=True)
    sim.budget=[1.,0.,0.,0.,0.]
    def context_at(t):
        targets=np.array([[0]*5,[.12]*5,[-.08,.08,-.08,.08,-.08],[.2,0,0,0,0],[0,.1,-.1,.1,0]],float)
        targets[1]*=1-.01*((t-START)//old.DAY)
        return DayContext(t,t,(0.,),('past_return',),targets,np.full(5,t,np.int64),np.zeros((30,5)),
            dict(expert_order=list(E5),symbol_order=list(CORE5),expert_identity_sha256='a'*64,mapper_sha256='b'*64,market_binding_sha256='c'*64),np.ones(5,bool))
    return sim,context_at

@pytest.fixture(scope='module')
def evaluated():
    sim,context_at=make();before=sim.state_hash();result=evaluate_candidates_7d(sim,context_at,mapper)
    assert sim.state_hash()==before
    return sim,context_at,result

def test_five_true_requests_no_padding_and_only_initial_features(evaluated):
    sim,context_at,result=evaluated;row=result.row
    assert row['action_order']==list(E5) and row['label_binding']['native_state_contract']==list(E5)
    assert len(row['candidates'])==5 and row['valid_mask']==[True]*5
    assert len(row['budget_before'])==5 and not any('RANK' in n for n in row['feature_names'])
    assert row['feature_available_us']==START and row['label_available_us']==START+7*old.DAY
    assert row['state_hash']==sim.state_hash() and len(sim.tape.retained)==7
    for k,c in enumerate(row['candidates']):
        assert c['request']==np.eye(5)[k].tolist() and c['days_completed']==7
        assert all(r['request']==c['request'] and r['feature_available_us']<=r['decision_us'] for r in c['daily_trace'])
        assert len(c['features'])==len(row['candidate_feature_names'])
    assert any(p.quantity for p in result.diagnostic_end_states[1].account.positions.values())
    assert not result.diagnostic_end_states[1].terminal

def test_two_segments_equal_exact_continuous_native_path(evaluated):
    _,context_at,first=evaluated
    # A second independent path test must not evict the shared fixture's first
    # retained days. Portable restore gives this path its own market tape.
    endpoint=NativeDailySimulator.from_snapshot(first.diagnostic_end_states[1].snapshot(),synthetic(14),account_class=BybitIsolatedAccount)
    second=evaluate_candidates_7d(endpoint,context_at,mapper)
    segmented=second.diagnostic_end_states[1];direct,c=make()
    while direct.cursor<direct.end:
        p=mapper(np.asarray(direct.budget),np.eye(5)[1],c(direct.cursor));direct.budget=list(p.budget)
        direct.advance_day(dict(zip(CORE5,p.targets,strict=True)))
    a,b=segmented.result(),direct.result();assert a['minute'].equals(b['minute'])
    for key in ('summary','trades','funding','rejections','breaches','extrema','liquidations'):assert a[key]==b[key]
    assert second.row['includes_global_terminal'] and all(p.quantity==0 for p in segmented.account.positions.values())

def test_retained_source_can_continue_one_day_without_future_wallet_adoption(evaluated):
    source,context_at,result=evaluated;sim=source.fork();control,c=make()
    for s,f in ((sim,context_at),(control,c)):
        p=mapper(np.asarray(s.budget),np.eye(5)[2],f(s.cursor));s.budget=list(p.budget)
        s.advance_day(dict(zip(CORE5,p.targets,strict=True)))
    assert sim.state_hash()==control.state_hash() and sim.result()['minute'].equals(control.result()['minute'])
    assert sim.cursor==START+old.DAY
