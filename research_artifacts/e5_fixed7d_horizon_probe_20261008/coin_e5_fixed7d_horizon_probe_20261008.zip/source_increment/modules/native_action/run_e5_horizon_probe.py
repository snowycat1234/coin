"""Twelve predeclared H1 teacher-state anchors; no fit or new greedy rollout."""
from pathlib import Path
from datetime import datetime,timezone
import json,time
import numpy as np
from scipy.stats import spearmanr
from .e5_inputs import Inputs,E5,mapper,sha
from .multiday_e5 import evaluate_candidates_7d
from .runner import exclusive_json,write_row
from .run_history_variant import save_audit

O=Path('/workspace/scratch/68ef1b82bcac/native_history_experiment')
WORK=O.parent/'h1_fixed_e5_inputs'
MANIFEST='2aa3cd49dbf5b249127a3356b06c324663fce28865af70b4af92ec03df4fda2a'
ANCHORS=tuple(f'2024-{m:02d}-{d:02d}' for m in range(1,7) for d in (1,16))

def stamp(value):return int(datetime.fromisoformat(value).replace(tzinfo=timezone.utc).timestamp()*1e6)

def branch_metrics(source,branch):
    directions={side:dict(gross=0.,fees=0.,execution=0.,funding=0.) for side in ('LONG','SHORT')}
    for account,sign in ((source.account,-1),(branch.account,1)):
        for s,p in account.positions.items():
            if p.quantity:
                directions['LONG' if p.quantity>0 else 'SHORT']['gross']+=sign*float(p.quantity*account.marks[s][-1]['price'])
    for r in branch.account.trades[len(source.account.trades):]:
        owner=r['quantity_before'] if r['leg']=='CLOSE' else r['position_delta'];v=directions['LONG' if owner>0 else 'SHORT']
        v['gross']-=r['position_delta']*r['mid_price'];v['fees']+=r['fee_USDT_mid'];v['execution']+=r['execution_cost']
    for r in branch.funding_journal[source.event_cursor:]:
        if r['quantity']:directions['LONG' if r['quantity']>0 else 'SHORT']['funding']+=r['signed_funding_USDT']
    for v in directions.values():v['net']=v['gross']-v['fees']-v['execution']+v['funding']
    net=float(branch.account.nav()-source.account.nav())
    error=sum(v['net'] for v in directions.values())-net
    assert abs(error)<1e-7,('Retained-inventory branch reconciliation',error)
    return dict(net_increment_USDT=net,turnover_USDT=float(branch.account.gross_fill_turnover-source.account.gross_fill_turnover),
        fees_USDT=float(branch.account.fees-source.account.fees),execution_USDT=float(branch.account.execution_cost-source.account.execution_cost),
        funding_USDT=float(branch.account.funding_cash-source.account.funding_cash),directions=directions,
        new_liquidations=branch.account.liquidations[len(source.account.liquidations):],marked_reconciliation_error_USDT=error,
        ending_positions={s:float(p.quantity) for s,p in branch.account.positions.items()})

def main():
    began=time.monotonic();deadline=began+900;out=O/'e5_horizon_probe';out.mkdir(exist_ok=False)
    teacher=O/'e5_h1/teacher/teacher.jsonl';rows=[json.loads(l) for l in teacher.read_text().splitlines()]
    by={r['decision_us']:r for r in rows};anchors={stamp(d):d for d in ANCHORS}
    inputs=Inputs('H1_E5',work=WORK,expected_manifest_sha=MANIFEST);sim=inputs.simulator(out/'source_progression')
    exclusive_json(out/'STARTED.json',dict(actual_started_unix=time.time(),wall_seconds=900,anchors=list(ANCHORS),new_fits=0,new_one_day_candidate_runs=0,
        one_day_labels='Reuse saved exact source-state-matched E5 native rewards; no E5 oracle regeneration.',
        seven_day_rule='Hold each initial onehot request7days, causal daily remap and original ramp, no intermediate close.',teacher_file_sha256=sha(teacher)))
    comparisons=[]
    with (out/'seven_day_labels.jsonl').open('x') as stream:
        while sim.cursor<sim.end:
            assert time.monotonic()<deadline,'Hard900s diagnostic budget; preserve completed anchors'
            original=by[sim.cursor]
            assert sim.state_hash()==original['state_hash'],'Saved teacher progression state changed'
            assert np.array_equal(np.asarray(sim.budget),original['budget_before'])
            if sim.cursor in anchors:
                result=evaluate_candidates_7d(sim,inputs.context_at,mapper,state_role='SAVED_H1_1D_GREEDY_SELF_STATE_ANCHOR',time_limit_seconds=min(900,deadline-time.monotonic()))
                row=result.row;assert row['state_hash']==original['state_hash'] and row['valid_mask']==[True]*5
                assert row['label_available_us']<=stamp('2024-07-01') and not row['includes_global_terminal']
                row['matched_saved_one_day_teacher_SHA256']=sha(teacher)
                one=np.asarray(original['e5_rewards_USDT']);seven=np.asarray(row['rewards_USDT']);nav=float(sim.account.nav())
                i,j=int(np.argmax(one)),int(np.argmax(seven))
                metrics=[branch_metrics(sim,b) for b in result.diagnostic_end_states]
                correlation=float(spearmanr(one,seven).statistic)
                comparison=dict(anchor=anchors[sim.cursor],decision_us=sim.cursor,state_hash=sim.state_hash(),decision_NAV=nav,
                    one_day_rewards_USDT=one.tolist(),seven_day_rewards_USDT=seven.tolist(),one_day_winner=i,seven_day_winner=j,
                    winner_changed=i!=j,rank_Spearman=correlation if np.isfinite(correlation) else None,
                    one_day_best_second_gap_USDT=float(np.sort(one)[-1]-np.sort(one)[-2]),
                    seven_day_best_second_gap_USDT=float(np.sort(seven)[-1]-np.sort(seven)[-2]),
                    seven_day_regret_of_one_day_choice_USDT=float(seven.max()-seven[i]),
                    seven_day_regret_of_one_day_choice_bps=float((seven.max()-seven[i])/nav*1e4),
                    seven_day_candidate_metrics=metrics,label_available_us=row['label_available_us'],
                    seven_day_turnover_of_one_day_choice_USDT=metrics[i]['turnover_USDT'],
                    seven_day_turnover_of_seven_day_choice_USDT=metrics[j]['turnover_USDT'],
                    seven_day_short_net_of_one_day_choice_USDT=metrics[i]['directions']['SHORT']['net'],
                    seven_day_short_net_of_seven_day_choice_USDT=metrics[j]['directions']['SHORT']['net'])
                comparisons.append(comparison);write_row(stream,row)
                exclusive_json(out/(anchors[sim.cursor]+'_COMPARISON.json'),comparison)
                print(json.dumps(dict(stage='H1_TRAIN_ONLY_FIXED_REQUEST_HORIZON',completed_anchors=len(comparisons),total_anchors=12,**comparison,elapsed_seconds=time.monotonic()-began)),flush=True)
                del result
            c=inputs.context_at(sim.cursor);selected=original['candidate_winner'];request=np.asarray(original['candidates'][selected]['request'])
            proposal=mapper(np.asarray(sim.budget),request,c)
            assert np.array_equal(proposal.budget,original['candidates'][selected]['budget'])
            assert np.array_equal(proposal.targets,original['candidates'][selected]['targets'])
            sim.budget=list(proposal.budget);done=sim.advance_day(dict(zip(sim.symbols,proposal.targets,strict=True)));assert done['completed']
        summary,audit=save_audit(sim,out/'source_progression')
        case=sim.result();previous=O/'e5_h1/teacher/account'
        for name in ('trades','funding','liquidations','rejections','breaches','extrema'):
            assert case[name]==json.loads((previous/(name+'.json')).read_text()),('Original teacher journal differs',name)
        import polars as pl
        assert case['minute'].equals(pl.read_parquet(previous/'minute_nav_inventory.parquet'))
        assert abs(summary['net_PnL']-377.34235598694363)<1e-8
    assert len(comparisons)==12
    report=dict(anchors=list(ANCHORS),states=12,winner_changes=sum(r['winner_changed'] for r in comparisons),
        mean_rank_Spearman=float(np.mean([r['rank_Spearman'] for r in comparisons if r['rank_Spearman'] is not None])),
        mean_seven_day_regret_of_one_day_choice_USDT=float(np.mean([r['seven_day_regret_of_one_day_choice_USDT'] for r in comparisons])),
        median_seven_day_regret_of_one_day_choice_USDT=float(np.median([r['seven_day_regret_of_one_day_choice_USDT'] for r in comparisons])),
        mean_seven_day_regret_of_one_day_choice_bps=float(np.mean([r['seven_day_regret_of_one_day_choice_bps'] for r in comparisons])),
        comparisons=comparisons,source_progression_exact_original_minutes_and_journals=True,source_progression_native_net=summary['net_PnL'],source_audit_status=audit['status'],
        new_fits=0,new_one_day_candidate_runs=0,elapsed_seconds=time.monotonic()-began,
        scope='Twelve predeclared independent forks of saved H1 greedy-teacher states, all matured beforeJuly1. Fixed7dayrequests are a different conditional objective; no global optimum, no portfolio PnL obtained by summing regrets, no tail labels/model selection.')
    exclusive_json(out/'RESULTS.json',report);print(json.dumps(report),flush=True)

if __name__=='__main__':main()
