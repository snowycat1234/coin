"""One fixed RANK request baseline with the exact matched native ramp and account."""
from pathlib import Path
import json,time
import numpy as np
from . import real_inputs
from .runner import exclusive_json
from .run_history_variant import save_audit,concise

O=Path('/workspace/scratch/68ef1b82bcac/native_history_experiment')

def main():
    started=time.monotonic();real_inputs.INPUT_ROOT=O/'relocated_inputs'
    e=real_inputs.build(dict(window='TAIL',state=str(O)));s=e.simulator
    exclusive_json(O/'FIXED_RANK_STARTED.json',dict(actual_started_unix=time.time(),days=142,maximum_wall_seconds=180,new_fits=0))
    proposals=[]
    for day in range(142):
        if time.monotonic()-started>180:raise ValueError('Fixed RANK wallet wall-clock limit')
        c=e.context_at(s.cursor);p=e.mapper(np.asarray(s.budget),np.eye(6)[5],c)
        proposals.append(dict(decision_us=s.cursor,budget=list(p.budget),targets=list(p.targets)))
        s.budget=list(p.budget);s.advance_day(dict(zip(s.symbols,p.targets,strict=True)))
        if day%35==0:print(json.dumps(dict(stage='FIXED_RANK_NATIVE',days=day+1,NAV=float(s.account.nav()),elapsed_seconds=time.monotonic()-started)),flush=True)
    D=O/'fixed_rank';D.mkdir(exist_ok=False)
    exclusive_json(D/'PROPOSALS.json',proposals)
    summary,audit=save_audit(s,D)
    report=dict(**concise(summary,audit),request='RANK_ONE_HOT_EVERY_DAY_THROUGH_SAME_L1_RAMP',initial_capital_USDT=10000,primary_funding_scale=1,new_fits=0,new_rank_inference=0,elapsed_seconds=time.monotonic()-started)
    exclusive_json(D/'ECONOMICS.json',report);print(json.dumps(report),flush=True)

if __name__=='__main__':main()
