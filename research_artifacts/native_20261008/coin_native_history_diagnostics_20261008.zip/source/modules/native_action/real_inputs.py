"""Explicit adapter to the verified caller-owned real E6 and native minute stores."""
from pathlib import Path
from types import SimpleNamespace
import json
import hashlib
import os
ROOT=Path(__file__).resolve().parents[2]
os.environ.setdefault('QUANT_ROOT',str(ROOT))
os.environ.setdefault('QUANT_STATE','/workspace/shared/coin_native_oracle_state')
import numpy as np
from .inputs import BoundE6Inputs
from .teacher import E6, Proposal, simplex
from .interface import NativeExperiment
from scripts.investment.regime_ranking_screen import bounded_path
from scripts.research.conditional_selector_core import shared_targets
from scripts.investment.resumable_perpetual import NativeDailySimulator
from scripts.investment import perpetual_directional as old
from quant.bybit_isolated_account import BybitIsolatedAccount

INPUT_ROOT=Path('/workspace/shared/coin_selector_oracle_inputs')

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def mapper(prior, request, context):
    import polars as pl
    prior, request=simplex(prior).copy(),simplex(request).copy()
    eligible=np.asarray(context.expert_eligible)
    if eligible.ndim==2: eligible=eligible.all(1)
    freed=float(prior[~eligible].sum())
    prior[~eligible]=0.;prior[0]+=freed
    desired=request.copy()
    released=float(desired[~eligible].sum())
    desired[~eligible]=0.;desired[0]+=released
    budget=bounded_path([desired],prior,.1)[0]
    names=tuple(E6[k] for k in np.flatnonzero(eligible))
    symbols=('BTCUSDT','ETHUSDT','SOLUSDT','XRPUSDT','DOGEUSDT')
    frames={}
    for k in np.flatnonzero(eligible):
        frames[E6[k]]=pl.DataFrame([dict(available_us=context.decision_us,symbol=s,
            target_weight=float(context.expert_targets[k,j]),raw_signed_target=float(context.expert_targets[k,j]),
            mode='LONG_SHORT',eligibility_reason='ELIGIBLE') for j,s in enumerate(symbols)])
    frame,proof=shared_targets(frames,names,np.asarray([context.decision_us],np.int64),symbols,budget[None,eligible])
    target=frame['target_weight'].to_numpy()
    covariance=np.cov(context.past_returns30,rowvar=False,ddof=1)*365
    if float(target@covariance@target)>.1**2+1e-12:
        raise ValueError('Frozen expert combination exceeds existing covariance risk budget')
    return Proposal('REQUEST',tuple(request),tuple(budget),tuple(target),'CURRENT_E6_ELIGIBILITY_RELEASE_BOUNDED_PATH_SHARED_TARGETS')

def build(options):
    tag=options.get('window','H1')
    if tag not in ('H1','TAIL'):raise ValueError('Explicit H1 or TAIL input')
    manifest=json.loads((INPUT_ROOT/(tag+'_MANIFEST.json')).read_text())
    market=manifest['native_market_binding']
    market_record=json.loads(Path(market['path']).read_text())
    from modules.transformer_v3.market_binding import verify_binding
    verify_binding(market['path'],market['sha256'])
    binding=dict(expert_order=list(E6),source_expert_order=[r['name'] for r in manifest['expert_recipes']],
        expert_identity_sha256=sha(INPUT_ROOT/'SOURCE_HASHES.json'),
        rank_checkpoint_sha256=manifest['frozen_rank_identity']['model_identity']['sha256'],
        mapper_sha256=sha(__file__),market_binding_sha256=market['sha256'],
        native_source_commit='4c0b2b8b93f6d98939f1a5d33ee11a6973418904',
        published_scheduler_commit='cc1829b3c8b5aa0bcf18ec70c1c669975b5343a5')
    fmap=dict(decision_us='decision_us',symbol_order='symbol_order',expert_targets='expert_targets',
        expert_available_us='target_available_us',expert_eligible='expert_eligible',past_returns30='past_returns30',
        market_features='market_state13',market_feature_names='market_state13_order',market_available_us='market_state13_available_us',
        action_eligible='action_eligible')
    if tag=='H1':
        fmap.update(action_desired_budgets='action_desired_budgets',original_selector_ramped_budgets='original_selector_ramped_budgets',
            original_selector_targets='original_selector_ramped_net_targets',baseline_targets='baseline_native_finaldayzero_targets',baseline_order='baseline_order')
    inputs=BoundE6Inputs(manifest['npz']['path'],manifest['npz']['sha256'],fmap,binding)
    with np.load(manifest['npz']['path'],allow_pickle=False) as z:
        if not z['market_state13_complete'].all():raise ValueError('Unavailable market13 features')
        if not np.all(z['market_covariance_available_us']<=z['decision_us']):raise ValueError('Future covariance source')
        if not np.all(z['rank_fit_completed_us']<z['decision_us']):raise ValueError('Future learned rank model')
    from modules.collector_research.validation import runtime
    work=market_record['work']
    runtime.configure(SimpleNamespace(collector_root=ROOT/'modules/collector_research',collector_work=work,
        source_run=Path(work)/'new-input-provenance',run_dir=Path(options.get('state','/workspace/shared/coin_native_oracle_state'))/(tag+'-control'),
        resource_policy='cloud',workers=1,minimum_days=30,publish_source_report=False,audit_device='cpu'))
    from modules.collector_research.validation import data
    window=data.market_window(list(inputs.symbols),manifest['calendar']['start_us'],manifest['calendar']['end_exclusive_us'])
    sim=NativeDailySimulator(window,'LONG_SHORT',old.COSTS[0],dict(id='RAW_AS_FRACTION',scale=1),
        account_factory=BybitIsolatedAccount,persist_cash_close=True,final_day_target_zero=True)
    sim.budget=[1.,0.,0.,0.,0.,0.]
    baseline_at=None
    if tag=='H1':
        if inputs.arrays['baseline_order'].tolist()[:2]!=['STATE_SELECTOR','MARKET_SELECTOR']:
            raise ValueError('Exact saved native selector target order')
        inputs.arrays['original_selector_targets']=inputs.arrays['baseline_targets'][:,:2,:]
        inputs.validation=inputs.validate_original_path(mapper,sim.budget,0)
        baseline_at=inputs.baseline_at
    result=NativeExperiment(sim,inputs.context_at,mapper,baseline_at,binding=dict(binding,npz_sha256=manifest['npz']['sha256'],window=tag))
    result.inputs=inputs
    result.manifest=manifest
    return result
