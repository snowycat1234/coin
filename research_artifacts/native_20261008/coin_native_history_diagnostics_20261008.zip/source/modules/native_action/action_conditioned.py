"""Fixed, train-only chronological validation of a shallow action-value model."""
from datetime import datetime,UTC
from pathlib import Path
import hashlib,json,pickle,time
import numpy as np
from sklearn.ensemble import HistGradientBoostingRegressor
from .reduced_history import REMOVED,transform_rows
from .train import fit

O=Path('/workspace/scratch/68ef1b82bcac/native_history_experiment')
B=O.parent/'restored_authorized_native'
PARAMETERS=dict(max_iter=64,max_depth=3,max_leaf_nodes=8,learning_rate=.05,
    min_samples_leaf=20,l2_regularization=1.,early_stopping=False,random_state=0)

def stamp(date):return int(datetime.fromisoformat(date).replace(tzinfo=UTC).timestamp()*1e6)

def action_features(row):
    """Only recorded pre-branch state and pre-branch feasible proposal fields."""
    names=row['feature_names'];keep=[i for i,n in enumerate(names) if n not in REMOVED]
    if any(names.count(n)!=1 for n in REMOVED):raise ValueError('Exact five exclusions')
    base=np.asarray(row['features'],float)[keep]
    prior=np.asarray(row['budget_before'],float)
    positions=np.asarray([row['features'][names.index('wallet.'+s+'.signed_weight')] for s in row['symbol_order']])
    out=[]
    for k,candidate in enumerate(row['candidates'][:6]):
        request=np.asarray(candidate['request'],float)
        if not np.array_equal(request,np.eye(6)[k]):raise ValueError('Stable candidate order')
        budget=np.asarray(candidate['budget'],float);target=np.asarray(candidate['targets'],float)
        if np.abs(budget-prior).sum()>.1+1e-10:raise ValueError('Feasible exact budget change')
        out.append(np.r_[base,request,budget-prior,target,target-positions])
    if len(out)!=6 or not np.isfinite(out).all():raise ValueError('Six finite proposals')
    suffix=['candidate.request.'+n for n in row['action_order']]+['candidate.delta_budget.'+n for n in row['action_order']]+['candidate.target.'+s for s in row['symbol_order']]+['candidate.delta_position.'+s for s in row['symbol_order']]
    return np.asarray(out),[names[i] for i in keep]+suffix

def metric(scores,rows,gap_scale):
    nav=np.asarray([r['wallet_before']['NAV'] for r in rows],float)
    y=np.asarray([r['e6_rewards_USDT'] for r in rows],float);a=np.asarray(scores).argmax(1)
    regret=y.max(1)-y[np.arange(len(y)),a]
    normalized=y/nav[:,None];gap=np.sort(normalized,axis=1)[:,-1]-np.sort(normalized,axis=1)[:,-2]
    weights=1+np.minimum(gap/gap_scale,5.)
    return dict(states=len(rows),tie_aware_agreement=float(np.mean(regret<=1e-9)),
        mean_native_net_regret_USDT=float(regret.mean()),mean_native_net_regret_bps=float(np.mean(regret/nav)*1e4),
        training_gap_scale_weighted_regret_USDT=float(np.average(regret,weights=weights)),
        training_gap_scale_weighted_regret_bps=float(np.average(regret/nav,weights=weights)*1e4),
        action_counts=np.bincount(a,minlength=6).tolist(),metric_scope='ONE_STEP_TEACHER_STATES_NOT_REALIZABLE_PNL')

def verify_proposals(rows):
    from .inputs import BoundE6Inputs
    from .real_inputs import mapper
    p=B/'inputs/H1_INPUTS.npz'
    fields=dict(decision_us='decision_us',symbol_order='symbol_order',expert_targets='expert_targets',
        expert_available_us='target_available_us',expert_eligible='expert_eligible',past_returns30='past_returns30',
        market_features='market_state13',market_feature_names='market_state13_order',market_available_us='market_state13_available_us')
    inputs=BoundE6Inputs(p,hashlib.sha256(p.read_bytes()).hexdigest(),fields,rows[0]['binding'])
    for r in rows:
        c=inputs.context_at(r['decision_us'])
        assert c.available_us<=c.decision_us and np.all(c.expert_available_us<=c.decision_us)
        for k,candidate in enumerate(r['candidates'][:6]):
            p=mapper(np.asarray(r['budget_before']),np.eye(6)[k],c)
            assert np.array_equal(p.budget,candidate['budget']) and np.array_equal(p.targets,candidate['targets'])
    return dict(states=len(rows),proposals_verified_byte_value_exact=6*len(rows),fields_used='Pre-branch proposal request/budget/targets only; applied_targets, winner, reward and state_after never used as inputs')

def main():
    began=time.monotonic();d=O/'hgb_validation';d.mkdir(exist_ok=False)
    raw=(B/'results/teacher/teacher.jsonl').read_bytes()
    rows=[json.loads(l) for l in raw.splitlines() if l]
    admitted=[r for r in rows if r['optimization_allowed']]
    train=[r for r in admitted if r['decision_us']<stamp('2024-04-30') and r['label_available_us']<=stamp('2024-04-30')]
    validation=[r for r in admitted if stamp('2024-05-01')<=r['decision_us']<stamp('2024-06-30')]
    assert len(train)==120 and len(validation)==60
    assert max(r['label_available_us'] for r in train)<min(r['decision_us'] for r in validation)
    assert all(r['feature_available_us']<=r['decision_us'] and all(r['e6_valid']) for r in admitted)
    provenance=verify_proposals(train+validation)
    Xt=np.asarray([action_features(r)[0] for r in train]);Xv=np.asarray([action_features(r)[0] for r in validation])
    names=action_features(train[0])[1]
    assert all(action_features(r)[1]==names for r in train+validation)
    y=np.asarray([r['e6_rewards_USDT'] for r in train])/np.asarray([r['wallet_before']['NAV'] for r in train])[:,None]
    advantages=y-y.mean(1,keepdims=True);gap=np.sort(y,axis=1)[:,-1]-np.sort(y,axis=1)[:,-2]
    gap_scale=float(np.median(gap[gap>0]));weights=1+np.minimum(gap/gap_scale,5.)
    started=dict(actual_fit_started_unix=time.time(),maximum_fit_seconds=120,exact_total_planned_fits=2,
        teacher_sha256=hashlib.sha256(raw).hexdigest(),training_states=120,validation_states=60,
        purge_decision='2024-04-30',all_actions_grouped_by_state=True,tail_labels_used=False,parameters=PARAMETERS)
    (d/'FIT_STARTED.json').write_text(json.dumps(started,indent=2)+'\n');print(json.dumps(started),flush=True)
    model=HistGradientBoostingRegressor(**PARAMETERS)
    model.fit(Xt.reshape(-1,Xt.shape[-1]),advantages.reshape(-1),sample_weight=np.repeat(weights,6))
    ridge=fit(transform_rows(train),asof_us=stamp('2024-04-30'))
    hp_train=model.predict(Xt.reshape(-1,Xt.shape[-1])).reshape(-1,6)
    hp_val=model.predict(Xv.reshape(-1,Xv.shape[-1])).reshape(-1,6)
    ridge_train=np.asarray([ridge.predict(r['features'],r['feature_names'],r['binding']) for r in transform_rows(train)])
    ridge_val=np.asarray([ridge.predict(r['features'],r['feature_names'],r['binding']) for r in transform_rows(validation)])
    rank_train=np.tile(np.eye(6)[5],(len(train),1));rank_val=np.tile(np.eye(6)[5],(len(validation),1))
    result=dict(exact_fit_count=2,hyperparameter_search=False,train= {n:metric(p,train,gap_scale) for n,p in [('HGB',hp_train),('Ridge30',ridge_train),('constant_RANK',rank_train)]},
        validation={n:metric(p,validation,gap_scale) for n,p in [('HGB',hp_val),('Ridge30',ridge_val),('constant_RANK',rank_val)]},
        feature_count=dict(HGB=len(names),Ridge30=len(ridge.feature_names)),feature_comparison='HGB additionally uses pre-branch action identity and feasible proposal geometry; model and representation jointly differ.',
        target='Action-relative native net NAV increment / decision NAV, demeaned across6 actions per state for HGB; Ridge raw NAV-normalized6 rewards; centering alone cannot change linear Ridge argmax.',
        training_gap_scale_NAV_fraction=gap_scale,parameters=PARAMETERS,source_causality=provenance,
        scaling='HGB no scaler; Ridge weighted mean/std fit on120 training states only.',
        EW='Not one of the six one-hot requests; no fabricated EW label/regret.',
        tail_labels_used=False,chronological_validation_previously_seen_history=True,
        state_distribution='Oracle self-wallet teacher states, not student self-state; this diagnostic does not establish realizable wallet economics.',
        elapsed_seconds=time.monotonic()-began)
    with (d/'HGB_TRAIN120.pkl').open('xb') as f:pickle.dump(dict(model=model,feature_names=names,parameters=PARAMETERS),f,protocol=5)
    ridge.save(d/'RIDGE30_TRAIN120.npz')
    np.savez_compressed(d/'PREDICTIONS.npz',train_decision_us=np.asarray([r['decision_us'] for r in train]),validation_decision_us=np.asarray([r['decision_us'] for r in validation]),
        HGB_train=hp_train,HGB_validation=hp_val,Ridge30_train=ridge_train,Ridge30_validation=ridge_val,training_weights=weights,feature_names=np.asarray(names))
    (d/'RESULTS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)

if __name__=='__main__':main()
