"""Own-wallet diagnostic using the already fitted train120 action-value model."""
from pathlib import Path
import json,pickle,time
import numpy as np
from . import real_inputs
from .teacher import causal_features
from .train import NativeRewardModel,frozen_identity
from .action_conditioned import action_features,PARAMETERS
from .runner import run,exclusive_json
from .run_history_variant import save_audit,concise

O=Path('/workspace/scratch/68ef1b82bcac/native_history_experiment')
B=O.parent/'restored_authorized_native/results'

class FrozenTrain120HGB:
    def __init__(self):
        with (O/'hgb_validation/HGB_TRAIN120.pkl').open('rb') as f:self.saved=pickle.load(f)
        if self.saved['parameters']!=PARAMETERS:raise ValueError('Fixed parameters required')
        self.identity=NativeRewardModel.load(O/'hgb_validation/RIDGE30_TRAIN120.npz').metadata['frozen_identity']
        self.metadata=dict(distribution_shift='H1 oracle self-wallet labels versus tail student self-wallet state; frozen train120 diagnostic, not promoted.',
            train_states=120,new_fits=0,variant='TRAIN120_FIXED_ACTION_CONDITIONED_HGB64_DEPTH3',
            prediction_output_kind='ACTION_RELATIVE_NAV_ADVANTAGE_IN_USDT')

    def request(self,sim,context):
        if frozen_identity(context.binding)!=self.identity:raise ValueError('Exact frozen expert/mapper identity')
        names,values=causal_features(sim,context)
        prior=np.asarray(sim.budget);candidates=[]
        for k in range(6):
            p=real_inputs.mapper(prior.copy(),np.eye(6)[k],context);p.validate(prior,len(sim.symbols))
            candidates.append(dict(request=list(p.request),budget=list(p.budget),targets=list(p.targets)))
        row=dict(feature_names=names,features=values,budget_before=prior.tolist(),symbol_order=list(sim.symbols),
            action_order=list(context.binding['expert_order']),candidates=candidates)
        x,feature_names=action_features(row)
        if feature_names!=self.saved['feature_names']:raise ValueError('Exact causal action schema')
        scores=self.saved['model'].predict(x)
        return np.eye(6)[int(scores.argmax())],scores*float(sim.account.nav())

def main():
    started=time.monotonic();real_inputs.INPUT_ROOT=O/'relocated_inputs'
    exclusive_json(O/'HGB_TAIL_STARTED.json',dict(actual_started_unix=time.time(),days=142,maximum_wall_seconds=180,
        new_fits=0,model_source='Frozen HGB train120; mixed validation result, own-state diagnosis only'))
    e=real_inputs.build(dict(window='TAIL',state=str(O)));m=FrozenTrain120HGB();d=O/'hgb_tail'
    s=run(e,d,'student',limit_seconds=180-(time.monotonic()-started),model=m)
    summary,audit=save_audit(s,d)
    rows=[json.loads(l) for l in (d/'predictions.jsonl').read_text().splitlines() if l]
    counts=np.bincount([int(np.argmax(r['request'])) for r in rows if r['optimization_allowed']],minlength=6).tolist()
    controls={k:json.loads(p.read_text()) for k,p in dict(fixed_rank=O/'fixed_rank/ECONOMICS.json',family_EW=B/'family/ECONOMICS.json',
        original_student=B/'student/ECONOMICS.json',corrected_student=O/'ECONOMICS.json').items()}
    report=dict(**concise(summary,audit),action_order=e.binding['expert_order'],action_counts_excluding_terminal=counts,
        long_short_contribution=summary['long_short_marked_contribution'],
        differences_USDT={k:summary['net_PnL']-v['net_PnL'] for k,v in controls.items()},
        elapsed_seconds=time.monotonic()-started,fit_count_this_replay=0,fit_count_this_HGB_recipe=2,
        model_train_states=120,no_tail_labels_train_or_tune=True,previously_seen_history=True,
        prediction_jsonl_field_semantics='Legacy predicted_next_day_reward_USDT field contains action-relative advantages, multiplied by current NAV; differences/argmax valid, not full native reward forecasts.',
        interpretation='Frozen own-wallet diagnostic following mixed validation, not promoted or independent unseen OOS')
    exclusive_json(d/'ECONOMICS.json',report);print(json.dumps(report),flush=True)

if __name__=='__main__':main()
