"""Bounded real experiment execution and independent economics verification."""
import argparse,json,time
from pathlib import Path
import numpy as np
from .real_inputs import build,sha
from .runner import run,exclusive_json
from .train import NativeRewardModel,fit,label_metrics
from scripts.investment import perpetual_directional as old
from modules.transformer_v3.isolated_audit import verify

OUT=Path('/workspace/shared/coin_native_oracle_state')

def save_audit(sim,directory):
    case=sim.result()
    saved=old.save_case(case,Path(directory)/'account')
    exclusive_json(Path(directory)/'account/summary.json',saved['summary'])
    audit=verify(Path(directory)/'account',list(sim.symbols),1)
    exclusive_json(Path(directory)/'INDEPENDENT_AUDIT.json',audit)
    return saved['summary'],audit

def concise(summary,audit):
    return dict(NAV=summary['NAV'],net_PnL=summary['net_PnL'],fees_USDT=summary['fees_USDT'],
        execution_cost_USDT=summary['execution_cost_USDT'],funding_USDT=summary['funding_USDT'],
        gross_PnL=summary['net_PnL']+summary['fees_USDT']+summary['execution_cost_USDT']-summary['funding_USDT'],
        MDD=summary['all_observation_max_drawdown'],daily_metrics=summary['daily_metrics'],
        realized_exposure=summary['realized_exposure'],liquidations=summary['liquidation_count'],
        completed_minutes=summary['completed_minutes'],terminal_cash_realized=summary['terminal_cash_realized'],
        audit_status=audit['status'])

def main():
    p=argparse.ArgumentParser();p.add_argument('mode',choices=['teacher','student','family','train','local']);a=p.parse_args()
    started=time.monotonic()
    if a.mode=='train':
        path=OUT/'teacher/teacher.jsonl'
        rows=[json.loads(l) for l in path.read_text().splitlines() if l]
        model=fit(rows)
        model.metadata['teacher_file_sha256']={str(path):sha(path)}
        model.save(OUT/'NATIVE_IMITATION_RIDGE30.npz')
        report=dict(metadata=model.metadata,diagnostic_training_label_states=label_metrics(model,rows),elapsed_seconds=time.monotonic()-started)
        exclusive_json(OUT/'FIT.json',report);print(json.dumps(report),flush=True);return
    tag='TAIL' if a.mode in ('student','family') else 'H1'
    exp=build(dict(window=tag))
    directory=OUT/a.mode
    exclusive_json(OUT/(a.mode.upper()+'_STARTED.json'),dict(actual_started_unix=time.time(),days=(exp.simulator.end-exp.simulator.start)//old.DAY,
        primary_funding_scale=1,budget_seconds=600 if tag=='TAIL' else 900,npz_sha256=exp.manifest['npz']['sha256']))
    if a.mode=='family':
        directory.mkdir(exist_ok=False)
        with np.load('/workspace/shared/coin_selector_oracle_inputs/H1_INPUTS.npz',allow_pickle=False) as z:
            index=z['baseline_order'].tolist().index('FAMILY_EW')
            desired=z['baseline_raw_desired_budgets'][0,index].copy()
            if not np.all(z['baseline_raw_desired_budgets'][:,index]==desired):raise ValueError('FAMILY_EW must be fixed H1 recipe')
        sim=exp.simulator
        target_rows=[]
        while sim.cursor<sim.end:
            if time.monotonic()-started>600:raise ValueError('Tail family benchmark wall budget')
            c=exp.context_at(sim.cursor);proposal=exp.mapper(np.asarray(sim.budget),desired,c)
            target_rows.append(dict(decision_us=sim.cursor,request=desired.tolist(),budget=list(proposal.budget),targets=list(proposal.targets)))
            sim.budget=list(proposal.budget);sim.advance_day(dict(zip(sim.symbols,proposal.targets,strict=True)))
        exclusive_json(directory/'FIXED_REQUEST_TARGETS.json',target_rows)
    else:
        model=NativeRewardModel.load(OUT/'NATIVE_IMITATION_RIDGE30.npz') if a.mode=='student' else None
        sim=run(exp,directory,a.mode,limit_seconds=600 if tag=='TAIL' else 900,model=model)
    summary,audit=save_audit(sim,directory)
    report=dict(mode=a.mode,window=tag,**concise(summary,audit),elapsed_seconds=time.monotonic()-started,
        funding_scale=1,initial_capital_USDT=10000,previously_seen_history=True,global_oracle_upper_bound=False)
    if a.mode=='teacher':
        baseline=json.loads(Path('/workspace/shared/coin_first_selector_matched_wallets_state/RESULTS.json').read_text())
        report['H1_baselines']=baseline['cases']
    exclusive_json(directory/'ECONOMICS.json',report)
    print(json.dumps(report),flush=True)

if __name__=='__main__':main()
