"""One fixed, joint feature/target ablation; original Ridge baseline stays intact."""
from copy import deepcopy
import numpy as np
from .teacher import causal_features
from .train import NativeRewardModel,fit,TRAIN_END

REMOVED=('wallet.nav_fraction','wallet.peak_fraction','wallet.drawdown',
         'wallet.cumulative_fees_fraction','wallet.cumulative_funding_fraction')
VARIANT='REDUCED_ACCOUNT_HISTORY_NAV_NORMALIZED_RIDGE30_V1'

def transform_rows(rows):
    out=[]
    for original in rows:
        row=deepcopy(original)
        names=list(row['feature_names'])
        if any(names.count(name)!=1 for name in REMOVED):
            raise ValueError('Exactly five existing account-history features required')
        nav=float(row['wallet_before']['NAV'])
        if not np.isfinite(nav) or nav<=0:raise ValueError('Positive decision-time NAV required')
        keep=[i for i,n in enumerate(names) if n not in REMOVED]
        row['feature_names']=[names[i] for i in keep]
        row['features']=[row['features'][i] for i in keep]
        row['e6_rewards_USDT']=(np.asarray(row['e6_rewards_USDT'],float)/nav).tolist()
        out.append(row)
    return out

class ReducedHistoryModel:
    def __init__(self,base):
        self.base=base
        self.metadata=base.metadata
        if self.metadata.get('variant')!=VARIANT:raise ValueError('Explicit normalized variant identity')
        if tuple(self.metadata['removed_features'])!=REMOVED:raise ValueError('Exact fixed feature exclusion')

    @classmethod
    def train(cls,rows):
        base=fit(transform_rows(rows),asof_us=TRAIN_END)
        if base.metadata['admitted_rows']!=181:raise ValueError('Exactly181 mature nonterminal H1 states')
        base.metadata.update(variant=VARIANT,removed_features=list(REMOVED),
            objective='SIX_NATIVE_NEXT_DAY_NAV_INCREMENT_DIVIDED_BY_DECISION_NAV',
            target_unit='NAV_FRACTION',prediction_output_unit='USDT_AFTER_MULTIPLYING_CURRENT_NAV',
            recipe_change_scope='JOINT_FIVE_HISTORY_FEATURE_EXCLUSION_AND_NAV_TARGET_NORMALIZATION',
            teacher_regeneration=False,new_rank_fits=0,new_rank_inference=0,
            immutable_original_baseline=True)
        base.metadata['gap_scale_NAV_fraction']=base.metadata.pop('gap_scale_USDT')
        return cls(base)

    @classmethod
    def load(cls,path):return cls(NativeRewardModel.load(path))

    def save(self,path):self.base.save(path)

    def request(self,sim,context):
        names,values=causal_features(sim,context)
        keep=[i for i,n in enumerate(names) if n not in REMOVED]
        scores=self.base.predict([values[i] for i in keep],[names[i] for i in keep],context.binding)
        rewards=scores*float(sim.account.nav())
        return np.eye(6)[int(np.argmax(scores))],rewards

    def teacher_metrics(self,rows):
        admitted=[r for r in rows if not r.get('forced_terminal_day') and r['label_available_us']<=TRAIN_END]
        normalized=transform_rows(admitted)
        predictions=np.asarray([self.base.predict(r['features'],r['feature_names'],r['binding']) for r in normalized])
        target=np.asarray([r['e6_rewards_USDT'] for r in admitted]);chosen=predictions.argmax(1)
        regret=target.max(1)-target[np.arange(len(target)),chosen]
        return dict(rows=len(admitted),feature_count=len(self.base.feature_names),
            winner_agreement=float(np.mean(target[np.arange(len(target)),chosen]==target.max(1))),
            mean_label_state_regret_USDT=float(regret.mean()),
            action_counts=np.bincount(chosen,minlength=6).tolist(),
            metric_scope='TEACHER_LABEL_STATES_ONLY_NOT_REALIZABLE_PNL')
