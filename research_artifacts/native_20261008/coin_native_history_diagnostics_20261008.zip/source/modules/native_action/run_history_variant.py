"""Fixed reduced-history experiment on the authorized restored teacher and tail."""
from pathlib import Path
import json,time,hashlib,sys
import numpy as np
from .reduced_history import ReducedHistoryModel
from .runner import run,exclusive_json

BASE=Path('/workspace/scratch/68ef1b82bcac/restored_authorized_native')
OUT=Path('/workspace/scratch/68ef1b82bcac/native_history_experiment')
ROOT=Path(__file__).resolve().parents[2]

def save_audit(sim,directory):
    from scripts.investment import perpetual_directional as old
    from modules.transformer_v3.isolated_audit import verify
    case=sim.result()
    saved=old.save_case(case,Path(directory)/'account')
    exclusive_json(Path(directory)/'account/summary.json',saved['summary'])
    audit=verify(Path(directory)/'account',list(sim.symbols),1)
    exclusive_json(Path(directory)/'INDEPENDENT_AUDIT.json',audit)
    return saved['summary'],audit

def concise(s,a):
    return dict(NAV=s['NAV'],net_PnL=s['net_PnL'],fees_USDT=s['fees_USDT'],execution_cost_USDT=s['execution_cost_USDT'],
        funding_USDT=s['funding_USDT'],MDD=s['all_observation_max_drawdown'],daily_metrics=s['daily_metrics'],
        realized_exposure=s['realized_exposure'],liquidations=s['liquidation_count'],completed_minutes=s['completed_minutes'],
        terminal_cash_realized=s['terminal_cash_realized'],audit_status=a['status'])

def sha(path):
    with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def main():
    mode=sys.argv[1];started=time.monotonic()
    if mode=='train':
        labels=BASE/'results/teacher/teacher.jsonl'
        rows=[json.loads(l) for l in labels.read_text().splitlines() if l]
        exclusive_json(OUT/'FIT_STARTED.json',dict(actual_started_unix=time.time(),teacher_sha256=sha(labels),maximum_fits=1))
        model=ReducedHistoryModel.train(rows)
        model.metadata['teacher_file_sha256']={str(labels):sha(labels)}
        model.metadata['actual_environment']=dict(python=sys.version,numpy=np.__version__)
        model.save(OUT/'REDUCED_HISTORY_NAV_RIDGE30.npz')
        report=dict(metadata=model.metadata,training_diagnostic=model.teacher_metrics(rows),elapsed_seconds=time.monotonic()-started)
        exclusive_json(OUT/'FIT.json',report);print(json.dumps(report),flush=True);return
    if mode!='student':raise ValueError('One fixed fit and one student replay only')
    from . import real_inputs
    # Runtime relocation only: immutable adapter/controller bytes stay unchanged.
    real_inputs.INPUT_ROOT=OUT/'relocated_inputs'
    exp=real_inputs.build(dict(window='TAIL',state=str(OUT)))
    model=ReducedHistoryModel.load(OUT/'REDUCED_HISTORY_NAV_RIDGE30.npz')
    exclusive_json(OUT/'REPLAY_STARTED.json',dict(actual_started_unix=time.time(),tail_npz_sha256=sha(BASE/'inputs/TAIL_INPUTS.npz'),
        days=142,primary_funding_scale=1,model_sha256=sha(OUT/'REDUCED_HISTORY_NAV_RIDGE30.npz')))
    sim=run(exp,OUT/'student','student',limit_seconds=600,model=model)
    summary,audit=save_audit(sim,OUT/'student')
    predictions=[json.loads(l) for l in (OUT/'student/predictions.jsonl').read_text().splitlines() if l]
    actions=[int(np.argmax(r['request'])) for r in predictions if not r['forced_terminal_day']]
    controls={mode:json.loads((BASE/'results'/mode/'ECONOMICS.json').read_text()) for mode in ('student','family')}
    report=dict(variant=model.metadata['variant'],**concise(summary,audit),action_order=model.metadata['action_order'],
        action_counts_excluding_terminal=np.bincount(actions,minlength=6).tolist(),
        original_student=controls['student'],frozen_family_EW=controls['family'],
        improvement_vs_original_USDT=summary['net_PnL']-controls['student']['net_PnL'],
        difference_vs_family_USDT=summary['net_PnL']-controls['family']['net_PnL'],
        elapsed_seconds=time.monotonic()-started,joint_ablation=True,previously_seen_history=True,
        controls_reused_without_rerun=True,new_rank_fits=0,new_rank_inference=0)
    exclusive_json(OUT/'ECONOMICS.json',report);print(json.dumps(report),flush=True)

if __name__=='__main__':main()
