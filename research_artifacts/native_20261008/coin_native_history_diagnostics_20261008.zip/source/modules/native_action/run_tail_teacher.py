"""Previously seen tail: six-request daily greedy diagnostic, with no model fit."""
from pathlib import Path
import json,time
import numpy as np
from . import real_inputs
from .runner import run,exclusive_json
from .run_history_variant import save_audit,concise

O=Path('/workspace/scratch/68ef1b82bcac/native_history_experiment')
B=Path('/workspace/scratch/68ef1b82bcac/restored_authorized_native/results')

def main():
    started=time.monotonic();real_inputs.INPUT_ROOT=O/'relocated_inputs'
    exclusive_json(O/'TAIL_TEACHER_STARTED.json',dict(actual_started_unix=time.time(),days=142,
        maximum_wall_seconds=900,new_fits=0,scope='SIX_ONE_HOT_REQUEST_DAILY_GREEDY_CONTINUOUS_ACCOUNT',
        previously_seen_history=True,full_horizon_oracle=False,mixture_upper_bound=False))
    e=real_inputs.build(dict(window='TAIL',state=str(O)));d=O/'tail_teacher'
    s=run(e,d,'teacher',limit_seconds=900-(time.monotonic()-started))
    summary,audit=save_audit(s,d)
    rows=[json.loads(l) for l in (d/'teacher.jsonl').read_text().splitlines() if l]
    print(json.dumps(dict(row_keys=list(rows[0]),last_row_keys=list(rows[-1]))),flush=True)
    controls={k:json.loads(p.read_text()) for k,p in dict(
        fixed_rank=O/'fixed_rank/ECONOMICS.json',family_EW=B/'family/ECONOMICS.json',
        original_student=B/'student/ECONOMICS.json',corrected_student=O/'ECONOMICS.json').items()}
    report=dict(**concise(summary,audit),scope='SIX_ONE_HOT_REQUEST_DAILY_GREEDY_CONTINUOUS_ACCOUNT',
        previously_seen_history=True,full_horizon_oracle=False,mixture_upper_bound=False,new_fits=0,
        differences_USDT={k:summary['net_PnL']-v['net_PnL'] for k,v in controls.items()},
        long_short_contribution=summary['long_short_marked_contribution'],
        elapsed_seconds=time.monotonic()-started)
    exclusive_json(d/'ECONOMICS.json',report);print(json.dumps(report),flush=True)

if __name__=='__main__':main()
