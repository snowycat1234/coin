"""Compare real daily continuation with saved unchanged native STATE economics."""
from pathlib import Path
import json,time
import numpy as np
import polars as pl
from .real_inputs import build
from .teacher import replay_candidates
from scripts.investment import perpetual_directional as old
from modules.transformer_v3.storage import hydrated_account
from modules.transformer_v3.isolated_audit import verify
from modules.collector_research.validation import runtime

OUT=Path('/workspace/shared/coin_native_oracle_state')
BASE=Path('/workspace/shared/coin_first_selector_matched_wallets_state/native/fraction/STATE_SELECTOR/attempt-1/account')

def write(path,obj):
    with Path(path).open('x') as f:json.dump(obj,f,indent=2,allow_nan=False)

def main():
    exp=build({})
    write(OUT/'MAPPER_EQUIVALENCE.json',exp.inputs.validation)
    sim=exp.simulator
    started=time.monotonic();probes=[]
    write(OUT/'BASELINE_STARTED.json',dict(actual_started_unix=time.time(),days=182,primary_funding_scale=1))
    for day in range(182):
        context=exp.context_at(sim.cursor)
        if day in (0,120):
            row,win,actual=replay_candidates(sim,context,exp.mapper,baseline=exp.baseline_at(sim,context),
                state_role='ACTUAL_SELECTOR_STATE',time_limit_seconds=120)
            write(OUT/('PROBE_DAY'+str(day)+'.json'),row)
            projected=sum(r['clone_seconds']+r['replay_seconds'] for r in row['candidates'][:6])*182
            info=dict(stage='ACTUAL_NATIVE_PROBE',day=day,e6_projection_seconds=projected,
                elapsed_seconds=row['elapsed_seconds'],clone_seconds=sum(r['clone_seconds'] for r in row['candidates'][:6]),
                replay_seconds=sum(r['replay_seconds'] for r in row['candidates'][:6]),
                peak_sampled_role='REPORT_SEPARATE_BOUNDED_RESOURCE_FILE')
            probes.append(info);print(json.dumps(info),flush=True)
            del win,actual
        p=exp.baseline_at(sim,context)
        sim.budget=list(p.budget)
        sim.advance_day(dict(zip(sim.symbols,p.targets,strict=True)))
        runtime.kernel_guard()
        if day%30==0:print(json.dumps(dict(stage='BASELINE_CONTINUATION',days=day+1,NAV=float(sim.account.nav()),elapsed_seconds=time.monotonic()-started)),flush=True)
    case=sim.result()
    with hydrated_account(BASE,OUT/'saved-audit-scratch') as hydrated:
        saved_minute=pl.read_parquet(hydrated/'minute_nav_inventory.parquet')
        if not case['minute'].equals(saved_minute):raise ValueError('Saved native minute ledger differs from daily continuation')
        for key in ('trades','funding','rejections','breaches','extrema','liquidations'):
            if case[key]!=json.loads((hydrated/(key+'.json')).read_text()):raise ValueError('Saved native journal differs: '+key)
        target=pl.read_parquet(hydrated/'targets.parquet')
        if not case['targets'].select('available_us','symbol','target_weight').equals(target.select('available_us','symbol','target_weight')):
            raise ValueError('Saved native targets differ')
        saved_summary=json.loads((hydrated/'summary.json').read_text())
        for key,value in case['summary'].items():
            if saved_summary.get(key)!=value:raise ValueError('Saved native summary differs: '+key)
    saved=old.save_case(case,OUT/'baseline-account')
    write(OUT/'baseline-account/summary.json',saved['summary'])
    audit=verify(OUT/'baseline-account',list(sim.symbols),1)
    write(OUT/'BASELINE_INDEPENDENT_AUDIT.json',audit)
    report=dict(status='PASS_REAL_FULL_WINDOW_SAVED_WHOLE_NATIVE_EQUALS_DAILY_CONTINUATION',days=182,minutes=case['minute'].height,
        NAV=saved['summary']['NAV'],net_PnL=saved['summary']['net_PnL'],exact_journals=True,exact_minute_ledger=True,
        exact_original_mapper=True,independent_audit_status=audit['status'],probes=probes,elapsed_seconds=time.monotonic()-started,
        saved_baseline_reused=True,original_simulate_unchanged=True)
    write(OUT/'REAL_EQUIVALENCE.json',report)
    print(json.dumps(report),flush=True)

if __name__=='__main__':main()
