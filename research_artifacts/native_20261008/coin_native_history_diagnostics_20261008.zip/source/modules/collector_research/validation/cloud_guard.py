"""Opt-in dot-cloud checks, without weakening existing server/WSL policies."""
import os
import resource
from pathlib import Path

MAX_ADDRESS_BYTES = 6_000_000_000


def check_cloud_limits(config):
    if config.get('workers') != 1 or config.get('audit_device') != 'cpu':
        raise RuntimeError('Cloud research requires one worker and CPU only')
    soft, hard = resource.getrlimit(resource.RLIMIT_AS)
    if soft <= 0 or hard <= 0 or max(soft, hard) > MAX_ADDRESS_BYTES:
        raise RuntimeError('Cloud requires inherited hard/soft address limit <=6GB')
    cpu_soft, cpu_hard = resource.getrlimit(resource.RLIMIT_CPU)
    if cpu_soft <= 0 or cpu_hard <= 0 or max(cpu_soft, cpu_hard) > 1800:
        raise RuntimeError('Cloud requires inherited CPU-time limit <=1800 seconds')
    if os.environ.get('CUDA_VISIBLE_DEVICES') != '':
        raise RuntimeError('Cloud requires explicit disabled CUDA visibility')
    if len(Path('/proc/swaps').read_text().splitlines()) != 1:
        raise RuntimeError('Cloud research requires no active host swap')
    if os.environ.get('COIN_CLOUD_BOUNDED') != '1':
        raise RuntimeError('Cloud requires explicit bounded launcher')
    return dict(memory_max=soft, memory_current=None,
                memory_enforcement='RLIMIT_AS_PER_PROCESS_NOT_SHARED_CGROUP',
                cpu_time_limit_seconds=cpu_soft, swap_active=False)
