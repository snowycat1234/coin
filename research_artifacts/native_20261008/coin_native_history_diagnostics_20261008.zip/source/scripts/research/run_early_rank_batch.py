"""One approved early three-fit batch using the existing CPU trainer unchanged.

This supplies missing causal expert outputs to the selector. It is not a new
investment experiment and runs no selector fits or native wallets.
"""

from __future__ import annotations

import argparse
import json
import resource
import subprocess
import time
from pathlib import Path

import numpy as np
import pandas as pd

from scripts.research.conditional_selector_inputs import CORE, require, sha
from scripts.research.patch_price_rank_cpu import freeze_sources, train
from scripts.research.patch_price_rank_inputs import DAY_US, save

ROOT = Path(__file__).resolve().parents[2]


def stamp(value):
    return int(pd.Timestamp(value).value // 1000)


def prepare(protocol, state):
    source = Path(protocol["recovered_inputs"]["path"])
    require(sha(source) == protocol["recovered_inputs"]["sha256"], "Recovered input identity")
    with np.load(source, allow_pickle=False) as f:
        d = {k: f[k].copy() for k in f.files}
    d["symbols"] = d["symbol_order"].tolist()
    core = [d["symbols"].index(s) for s in CORE]
    cutoff = stamp(protocol["targets"]["cutoff"])
    eligible = (
        d["ready"][:, core].all(1) & np.isfinite(d["relative"][:, core]).all((1, 2))
        & np.isfinite(d["regime"]).all(1) & (d["label_end_us"] < cutoff)
    )
    indices = np.flatnonzero(eligible)
    require(len(indices) == 180 and indices[0] >= 255, "Exact180 original mature dates")
    require(np.array_equal(np.diff(d["dates_us"]), np.full(len(d["x"]) - 1, DAY_US)),
            "Full ranker calendar, including all genuine gaps")
    decision = d["dates_us"] + DAY_US
    one_day = stamp(protocol["availability"]["next_day_interpretation"])
    conservative = stamp(protocol["availability"]["extra60day_interpretation"])
    require(one_day > cutoff and conservative == cutoff + 61 * DAY_US,
            "Explicit two ranker embargo/availability interpretations")
    published = max(one_day, conservative)
    predict = np.flatnonzero(
        d["ready"][:, core].all(1) & (decision >= published)
        & (decision < stamp(protocol["prediction_end_exclusive"]))
    )
    require(len(predict) and not np.intersect1d(indices, predict).size,
            "Only eligible genuinely later predictions")
    old_relative, old_regime, old_end = d["relative"], d["regime"], d["label_end_us"]
    d["relative"] = np.full_like(old_relative, np.nan)
    d["regime"] = np.full_like(old_regime, np.nan)
    d["label_end_us"] = np.full_like(old_end, np.iinfo(np.int64).max)
    d["relative"][indices], d["regime"][indices] = old_relative[indices], old_regime[indices]
    d["label_end_us"][indices] = old_end[indices]
    d["train_indices"], d["predict_indices"] = indices, predict
    d["utility"] = [np.zeros((len(decision), 10, 2), dtype=np.float32)]
    np.savez_compressed(state / "INPUTS.npz",
                        **{k: v for k, v in d.items() if k not in ("symbols", "utility")})
    save(state / "INPUT_RECEIPT.json", dict(
        status="EARLY180_TRAINING_LABEL_VIEW_NO_FUTURE_LABELS",
        input_npz_sha256=sha(state / "INPUTS.npz"),
        source_input_sha256=protocol["recovered_inputs"]["sha256"],
        training_dates=180, first_train_feature_us=int(d["dates_us"][indices[0]]),
        last_train_feature_us=int(d["dates_us"][indices[-1]]),
        maximum_training_label_available_us=int(old_end[indices].max()),
        maximum_scaler_source_available_us=int(decision[indices].max()),
        actual_first_prediction_us=int(decision[predict[0]]),
        published_model_available_us=published,
        availability_interpretations=protocol["availability"],
        published_predictions_use_more_conservative_interpretation=True,
        prediction_dates=len(predict), source_missing_masks_unchanged=True,
    ))
    return d


def run(protocol_path, state):
    protocol = json.loads(protocol_path.read_text())
    require(not state.exists(), "Fresh approved batch identity; never duplicate/refit silently")
    require(protocol["model"]["seeds"] == [20261006, 20261007, 20261008]
            and protocol["model"]["epochs_by_seed"]
            == {"20261006": 6, "20261007": 10, "20261008": 1}, "Fixed approved3 seed/epoch batch")
    for name, digest in protocol["source_hashes"].items():
        path = ROOT / name
        require(sha(path) == digest, "Actual source changed: " + name)
        committed = subprocess.check_output(["git", "show", "HEAD:" + name], cwd=ROOT)
        import hashlib

        require(hashlib.sha256(committed).hexdigest() == digest, "Uncommitted source: " + name)
    require(subprocess.check_output(
        ["git", "show", "HEAD:" + str(protocol_path.relative_to(ROOT))], cwd=ROOT
    ) == protocol_path.read_bytes(), "Complete protocol must be committed before fit")
    resource.setrlimit(resource.RLIMIT_CPU, (600, 600))
    state.mkdir(parents=True)
    began = time.monotonic()
    save(state / "STARTED.json", dict(
        protocol_sha256=sha(protocol_path), actual_started_unix=time.time(),
        deadline_monotonic=began + 600, maximum_new_fits=3,
        model_logic_is_existing_patch_price_rank_cpu_train=True,
    ))
    try:
        d = prepare(protocol, state)
        freeze_sources(protocol_path, state)
        train(d, protocol, protocol_path, state, began + 600)
        receipt = json.loads((state / "INPUT_RECEIPT.json").read_text())
        save(state / "COMPLETE.json", dict(
            status="COMPLETE3_APPROVED_EARLY_PRICE_RANK_FITS_FOR_SELECTOR_INPUTS",
            new_ranker_fits=3, selector_fits=0, native_wallets=0, downloads=0,
            protocol_sha256=sha(protocol_path), input_receipt=receipt,
            fit_results_sha256=sha(state / "FIT_RESULTS.json"),
            prediction_sha256=sha(state / "ENSEMBLE_PREDICTIONS.npz"),
            elapsed_seconds=time.monotonic() - began,
            no_investment_qualification_or_model_promotion=True,
        ))
    except BaseException as exc:
        save(state / "FAILURE.json", dict(
            error_type=type(exc).__name__, error=str(exc),
            elapsed_seconds=time.monotonic() - began, preserve_partial_artifacts=True,
            automatic_retry_or_extra_fit=False,
        ))
        raise


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--protocol", type=Path, required=True)
    p.add_argument("--state", type=Path, required=True)
    args = p.parse_args()
    run(args.protocol.resolve(), args.state.resolve())


if __name__ == "__main__":
    main()
