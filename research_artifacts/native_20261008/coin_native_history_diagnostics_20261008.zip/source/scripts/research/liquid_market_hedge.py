"""One BTC hedge of frozen CSMOM long intents; research targets, never PnL.

The conceptual alpha and hedge legs are capped before netting. The one-way
wallet executes only their net BTC target, so conceptual legs are not separate
trades or separately attributable realized PnL. No costless exit is implied.
"""
from __future__ import annotations

import numpy as np

from scripts.investment.public_sma_perpetual import signed_risk_weights
from scripts.research.public_cross_section_momentum import DAY_US, public_targets


def hedge_row(original, past_returns, market_index):
    """Size one hedge using exactly 30 completed daily simple returns.

    Inputs retain explicit asset order. Missing held-long/market history or
    near-zero market variance produces unavailable cash, never imputed beta.
    Original short gross is a ceiling, not a budget that must be spent.
    """
    base = np.asarray(original, dtype=float)
    returns = np.asarray(past_returns, dtype=float)
    if (base.ndim != 1 or not len(base) or not np.isfinite(base).all()
            or returns.shape != (30, len(base))
            or not isinstance(market_index, (int, np.integer))
            or isinstance(market_index, bool) or not 0 <= market_index < len(base)
            or np.abs(base).max() > .3 + 1e-12 or np.abs(base).sum() > .6 + 1e-12):
        raise ValueError('Ordered finite capped targets and 30 return rows required')
    longs = np.maximum(base, 0.)
    empty = np.zeros_like(base)
    info = dict(status='VALID_CASH_NO_LONG', beta=None, desired_hedge=None,
                original_long_gross=float(longs.sum()),
                original_short_gross=float(-np.minimum(base, 0.).sum()),
                original_gross=float(abs(base).sum()), market_index=int(market_index))
    if not longs.any():
        return empty, info
    required = (longs > 0)
    required[market_index] = True
    if not np.isfinite(returns[:, required]).all():
        info['status'] = 'UNAVAILABLE_REQUIRED_HISTORY'
        return empty, info
    market = returns[:, market_index]
    variance = float(np.var(market, ddof=1))
    info['market_daily_variance'] = variance
    if not np.isfinite(variance):
        info['market_daily_variance'] = None
        info['status'] = 'UNAVAILABLE_NONFINITE_MARKET_VARIANCE'
        return empty, info
    if variance <= 1e-16:
        info['status'] = 'UNAVAILABLE_DEGENERATE_MARKET_VARIANCE'
        return empty, info
    beta = np.zeros_like(base)
    centered = market - market.mean()
    beta[required] = ((returns[:, required] - returns[:, required].mean(axis=0)).T
                      @ centered / (29 * variance))
    beta[market_index] = 1.
    raw_beta = float(longs @ beta)
    if not np.isfinite(beta[required]).all() or not np.isfinite(raw_beta):
        info['status'] = 'UNAVAILABLE_NONFINITE_BETA'
        return empty, info
    desired = max(0., raw_beta)
    ceiling = max(0., min(info['original_short_gross'], .3 - longs[market_index],
                         .6 - float(longs.sum())))
    hedge = min(desired, ceiling)
    net = longs.copy()
    net[market_index] -= hedge
    held = np.flatnonzero(net)
    scale = 1.
    sigma = 0.
    if len(held):
        scaled, risk = signed_risk_weights(net[held], returns[:, held])
        sigma = risk['unscaled_signed_covariance_annual_vol']
        scale = min(1., .10 / sigma) if sigma else 1.
        net[held] = scaled
    alpha = longs * scale
    short = hedge * scale
    gross = float(alpha.sum() + short)
    usage = alpha.copy()
    usage[market_index] += short
    if gross > .6 + 1e-12 or usage.max() > .3 + 1e-12:
        raise ValueError('Conceptual legs exceed original absolute risk caps')
    info.update(status='VALID', beta=[float(beta[i]) if required[i] else None
                                    for i in range(len(base))],
                desired_hedge=desired, hedge_ceiling=ceiling, hedge_capped=bool(desired > ceiling),
                common_risk_scale=scale, conceptual_long_weights=alpha.tolist(),
                conceptual_market_short=short, conceptual_symbol_usage=usage.tolist(),
                conceptual_gross=gross, executable_gross=float(abs(net).sum()),
                executable_net=float(net.sum()), cancelled_market_notional=float(
                    min(alpha[market_index], short)),
                residual_beta=float(alpha @ beta - short),
                unscaled_signed_covariance_annual_vol=sigma)
    return net, info


def market_hedge_targets(close, available_us, decision_us, symbols, allowed_symbols):
    """Reuse unchanged public CSMOM ranking/risk; replace shorts with BTC only."""
    names = tuple(symbols)
    if 'BTCUSDT' not in names or 'BTCUSDT' not in allowed_symbols:
        raise ValueError('Fixed BTC market hedge must belong to the declared pool')
    baseline, original = public_targets(close, available_us, decision_us,
                                        names, allowed_symbols)
    prices = np.asarray(close, dtype=float)
    available = np.asarray(available_us, dtype=np.int64)
    output = np.zeros_like(baseline)
    rows = []
    for i, timestamp in enumerate(decision_us):
        j = int(np.searchsorted(available, timestamp, side='right') - 1)
        if (j < 30 or available[j] != timestamp
                or np.any(np.diff(available[j - 30:j + 1]) != DAY_US)):
            rows.append(dict(status='UNAVAILABLE_CONTIGUOUS_HISTORY',
                             decision_us=int(timestamp)))
            continue
        history = prices[j - 30:j + 1]
        with np.errstate(invalid='ignore', divide='ignore'):
            returns = np.diff(history, axis=0) / history[:-1]
        valid = np.all(np.isfinite(history) & (history > 0), axis=0)
        returns[:, ~valid] = np.nan
        output[i], info = hedge_row(baseline[i], returns, names.index('BTCUSDT'))
        rows.append(dict(info, decision_us=int(timestamp), feature_available_us=int(timestamp)))
    return output, dict(symbol_order=list(names), hedge_symbol='BTCUSDT',
                        beta_days=30, data_role='SEEN_DEVELOPMENT_ONLY',
                        qualification='NONE_CASH', rows=rows, original=original,
                        unavailable_cash_is_not_assumed_execution=True,
                        conceptual_legs_are_not_separate_wallet_PnL=True)


def long_only_targets(close, available_us, decision_us, symbols, allowed_symbols):
    """Independent-wallet ablation intents; no deletion of historical short PnL."""
    baseline, original = public_targets(close, available_us, decision_us,
                                        symbols, allowed_symbols)
    output = np.maximum(baseline, 0.)
    prices = np.asarray(close, dtype=float)
    available = np.asarray(available_us, dtype=np.int64)
    diagnostics = []
    for i, timestamp in enumerate(decision_us):
        held = np.flatnonzero(output[i])
        if not len(held):
            diagnostics.append(dict(status='CASH', decision_us=int(timestamp)))
            continue
        j = int(np.searchsorted(available, timestamp, side='right')-1)
        if (j < 30 or available[j] != timestamp
                or np.any(np.diff(available[j-30:j+1]) != DAY_US)):
            raise ValueError('Original nonzero target without contiguous causal history')
        past = prices[j-30:j+1, held]
        returns = np.diff(past, axis=0)/past[:-1]
        output[i, held], risk = signed_risk_weights(output[i, held], returns)
        diagnostics.append(dict(status='VALID', decision_us=int(timestamp), **risk))
    return output, dict(rows=diagnostics, original=original,
                        separately_simulated_full_wallet_required=True)
