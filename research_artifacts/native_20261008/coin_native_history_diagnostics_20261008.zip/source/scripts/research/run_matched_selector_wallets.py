"""Eight approved matched wallets on frozen selector/control targets; no fits."""

from __future__ import annotations

import argparse
import json
import resource
import subprocess
import time
from pathlib import Path

from modules.transformer_v3.wallet import run_tasks
from scripts.research.conditional_selector_inputs import require, sha
from scripts.research.patch_price_rank_inputs import save
from scripts.research.run_public_momentum import summary_row

ROOT = Path(__file__).resolve().parents[2]


def summarize_completed(state, spec, protocol_path, elapsed):
    record = json.loads((state / "MATCHED_SELECTOR_WALLETS.json").read_text())
    require(record["status"] == "COMPLETE" and not record["errors"]
            and len(record["cases"]) == 8, "All8 saved wallets must be complete")
    rows = []
    for case in record["cases"]:
        target = spec["targets"][case["task"]["family"]]
        require(case["task"]["target_sha256"] == target["sha256"], "Wallet target identity")
        path = state / "native" / case["task"]["id"] / "RESULT.json"
        rows.append(summary_row(case, path, "MATCHED_FROZEN_SELECTOR"))
    save(state / "RESULTS.json", dict(
        status="COMPLETE8_MATCHED_SELECTOR_WALLETS_WITH_INDEPENDENT_AUDIT",
        protocol_sha256=sha(protocol_path), cases=rows,
        completed_wallets=len(rows), elapsed_seconds=elapsed,
        ranker_fits=0, selector_fits=0, downloads=0,
        classification="SEEN_DEVELOPMENT_CONDITIONAL_ECONOMICS_NOT_QUALIFIED_INVESTMENT",
        qualification="NONE_CASH", shared_predictions_for_both_funding_interpretations=True,
        terminal_rule=spec["terminal_rule"], training_static_selection=spec["static_selection"],
        summary_adapter_sha256=sha(__file__), wallet_results_reused_without_rerun=True,
    ))


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--protocol", required=True, type=Path)
    p.add_argument("--state", required=True, type=Path)
    p.add_argument("--summarize-only", action="store_true",
                   help="Verify/aggregate completed audited wallets without another simulation")
    a = p.parse_args()
    spec = json.loads(a.protocol.read_text())
    if a.summarize_only:
        require(a.state.exists() and not (a.state / "RESULTS.json").exists(),
                "Existing completed wallets and a missing final summary required")
        from modules.transformer_v3.market_binding import verify_binding

        for ref in spec["input_refs"]:
            require(sha(ref["path"]) == ref["sha256"], "Frozen input changed during recovery")
        saved = json.loads((a.state / "MATCHED_SELECTOR_WALLETS.json").read_text())
        seen = set()
        for case in saved["cases"]:
            path = case["task"]["native_market_binding_path"]
            if path not in seen:
                verify_binding(path, case["task"]["native_market_binding_sha256"])
                seen.add(path)
        failure = json.loads((a.state / "FAILURE.json").read_text())
        summarize_completed(a.state, spec, a.protocol, failure["elapsed_seconds"])
        save(a.state / "SUMMARY_RECOVERY.json", dict(
            original_failure_preserved=True, recovery_source_sha256=sha(__file__),
            completed_wallets_reused=8, new_wallets=0, new_fits=0,
        ))
        return
    require(not a.state.exists(), "Fresh matched wallet identity required")
    committed = subprocess.check_output(
        ["git", "show", "HEAD:" + str(a.protocol.resolve().relative_to(ROOT))], cwd=ROOT
    )
    require(committed == a.protocol.read_bytes(), "Wallet protocol must be committed")
    for ref in spec["input_refs"]:
        require(sha(ref["path"]) == ref["sha256"], "Frozen wallet input changed")
    for source, digest in spec["source_hashes"].items():
        require(sha(ROOT / source) == digest, "Frozen wallet adapter changed")
    resource.setrlimit(resource.RLIMIT_CPU, (1200, 1200))
    a.state.mkdir(parents=True)
    started = time.monotonic()
    save(a.state / "STARTED.json", dict(
        protocol_sha256=sha(a.protocol), actual_started_unix=time.time(),
        maximum_wallets=8, maximum_wall_seconds=1200, no_fits_or_downloads=True,
    ))
    tasks = []
    for family, target in spec["targets"].items():
        for scale in (1, 0.01):
            tasks.append(dict(
                id=("fraction" if scale == 1 else "percent") + "/" + family,
                state=str(a.state.resolve()),
                collector_root=str(ROOT / "modules/collector_research"),
                work=spec["market_work"], source_run=spec["source_run"], family=family,
                seed="FROZEN_APPROVED_SELECTOR_PAIR", profile="FULL", mapping=family,
                window=spec["window"], funding_scale=scale,
                target_path=target["path"], target_sha256=target["sha256"],
                protocol_sha256=sha(a.protocol), noncausal=False, resource_policy="cloud",
                market_input_manifest_path=spec["market_manifest"]["path"],
                market_input_manifest_sha256=spec["market_manifest"]["sha256"],
            ))
    require(len(tasks) == 8, "Exactly approved4 cases times2 funding interpretations")
    try:
        cases = run_tasks(tasks, a.state, "MATCHED_SELECTOR_WALLETS", workers=1,
                          protocol_path=a.protocol)
        require(len(cases) == 8, "Eight completed native wallets required")
        summarize_completed(a.state, spec, a.protocol, time.monotonic() - started)
    except BaseException as exc:
        save(a.state / "FAILURE.json", dict(
            error_type=type(exc).__name__, error=str(exc),
            elapsed_seconds=time.monotonic() - started, preserved_partial_wallets=True,
            no_new_fits_or_automatic_outer_restart=True,
        ))
        raise


if __name__ == "__main__":
    main()
