"""One frozen, new price-only PATCH CPU experiment. No old checkpoint restoration."""

from __future__ import annotations

import argparse
import json
import random
import resource
import subprocess
import time
from pathlib import Path

import numpy as np
import pandas as pd
import polars as pl
import torch
from torch.utils.data import DataLoader

from modules.collector_research.validation.cloud_guard import check_cloud_limits
from modules.transformer_v2.data import train_scaler
from modules.transformer_v2.model import CrossAssetTransformer, objective
from modules.transformer_v2.portfolio import market_neutral
from modules.transformer_v2.train import Samples
from modules.transformer_v3.wallet import run_tasks
from scripts.investment.public_sma_perpetual import signed_risk_weights
from scripts.research.patch_price_rank_inputs import DAY_US, guard, save, sha
from scripts.research.run_public_momentum import summary_row

ROOT = Path(__file__).resolve().parents[2]


def freeze_sources(protocol_path, state):
    files = [
        Path(__file__),
        Path(__file__).with_name("patch_price_rank_inputs.py"),
        ROOT / "modules/transformer_v2/model.py",
        ROOT / "modules/transformer_v2/data.py",
        ROOT / "modules/transformer_v2/portfolio.py",
        ROOT / "modules/transformer_v2/train.py",
    ]
    sources = {str(p.relative_to(ROOT)): sha(p) for p in files}
    for name, digest in sources.items():
        committed = subprocess.check_output(["git", "-C", str(ROOT), "show", "HEAD:" + name])
        import hashlib

        if hashlib.sha256(committed).hexdigest() != digest:
            raise ValueError("Commit exact CPU/input sources before first fit: " + name)
    receipt = dict(
        protocol_sha256=sha(protocol_path),
        sources=sources,
        source_HEAD=subprocess.check_output(
            ["git", "-C", str(ROOT), "rev-parse", "HEAD"], text=True
        ).strip(),
    )
    path = state / "TRAIN_SOURCE_BINDING.json"
    if path.exists() and json.loads(path.read_text()) != receipt:
        raise ValueError("Frozen training source binding changed")
    save(path, receipt)
    return receipt


def get_data(state):
    with np.load(state / "INPUTS.npz", allow_pickle=False) as f:
        raw = {k: f[k].copy() for k in f.files}
    n = len(raw["x"])
    raw["symbols"] = raw["symbol_order"].tolist()
    raw["utility"] = [np.zeros((n, len(raw["symbols"]), 2), dtype="float32")]
    return raw


class PriceSamples(Samples):
    def __getitem__(self, j):
        batch = list(super().__getitem__(j))
        batch[4] = torch.zeros_like(batch[4], dtype=torch.bool)
        return tuple(batch)


def inference_features(d, index, scaler):
    mu, sd = scaler
    x = (d["x"][index - 255 : index + 1] - mu) / sd
    available = d["availability"][index - 255 : index + 1]
    mask = np.isfinite(x) & available[..., None]
    return tuple(
        torch.from_numpy(v) for v in (np.where(mask, x, 0.0).astype("float32"), mask, available)
    )


def validate_training_calendar(d, protocol):
    indices = d["train_indices"]
    cutoff_us = pd.Timestamp(protocol["targets"]["cutoff"]).value // 1000
    if len(indices) < 180 or np.any(d["label_end_us"][indices] >= cutoff_us):
        raise ValueError("Training maturity/minimum-day guard failed")
    if np.min(indices) < 255 or np.intersect1d(indices, d["predict_indices"]).size:
        raise ValueError("Training sequence/inference calendar overlap")


def train(d, protocol, protocol_path, state, deadline):
    if len(Path("/proc/swaps").read_text().splitlines()) != 1:
        raise RuntimeError("Active swap is not permitted")
    if torch.cuda.is_available():
        raise RuntimeError("This frozen experiment uses CPU only")
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    indices = d["train_indices"]
    validate_training_calendar(d, protocol)
    active = np.array([s in protocol["assets"]["allocation_pool"] for s in d["symbols"]])
    scaler = train_scaler(d["x"], d["availability"], indices)
    regime = d["regime"][indices]
    yscale = (
        np.ones(2, dtype="float32"),
        regime.mean(0).astype("float32"),
        regime.std(0).astype("float32"),
    )
    yscale = (yscale[0], yscale[1], np.where(yscale[2] > 1e-6, yscale[2], 1.0).astype("float32"))
    predictions = []
    fits = []
    for seed in protocol["model"]["seeds"]:
        guard(state, deadline, protocol["budget"])
        folder = state / "fits" / f"seed{seed}"
        folder.mkdir(parents=True, exist_ok=True)
        random.seed(seed)
        np.random.seed(seed)
        torch.manual_seed(seed)
        net = CrossAssetTransformer(features=d["x"].shape[-1], assets=10, length=256, patch=8)
        if sum(p.numel() for p in net.parameters()) != protocol["model"]["parameters"]:
            raise ValueError("Existing architecture parameter identity changed")
        opt = torch.optim.AdamW(net.parameters(), lr=0.0007, weight_decay=0.001)
        epochs = protocol["model"]["epochs_by_seed"][str(seed)]
        loader = DataLoader(
            PriceSamples(d, indices, 0, active, scaler, yscale),
            batch_size=16,
            num_workers=0,
            shuffle=True,
        )
        history = []
        began = time.monotonic()
        backward_probe = None
        for epoch in range(1, epochs + 1):
            net.train()
            losses = []
            for batch_number, batch in enumerate(loader, 1):
                guard(state, deadline, protocol["budget"])
                opt.zero_grad(set_to_none=True)
                out = net(*batch[:3])
                loss = objective(out, *batch[3:], True)
                if not torch.isfinite(loss):
                    raise RuntimeError("Nonfinite price-rank training loss")
                t = time.monotonic()
                loss.backward()
                norm = torch.nn.utils.clip_grad_norm_(net.parameters(), 1.0)
                if not torch.isfinite(norm):
                    raise RuntimeError("Nonfinite gradient")
                if backward_probe is None:
                    backward_probe = dict(
                        seed=seed,
                        batch_size=int(batch[0].shape[0]),
                        backward_seconds=time.monotonic() - t,
                        maximum_RSS_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024,
                        same_registered_first_fit=True,
                        no_extra_optimizer_or_seed=True,
                    )
                    save(state / "FIRST_BACKWARD_RESOURCE_GATE.json", backward_probe)
                    print("FIRST_BACKWARD " + json.dumps(backward_probe), flush=True)
                opt.step()
                losses.append(float(loss.detach()))
                save(
                    state / "progress.json",
                    dict(
                        stage="FIXED_CPU_FIT",
                        seed=seed,
                        epoch=epoch,
                        total_epochs=epochs,
                        batch=batch_number,
                        total_batches=len(loader),
                        loss=float(np.mean(losses)),
                        completed_seeds=len(fits),
                        total_seeds=3,
                        seconds_remaining=max(0, deadline - time.monotonic()),
                    ),
                )
            history.append(
                dict(
                    epoch=epoch,
                    loss=float(np.mean(losses)),
                    elapsed_seconds=time.monotonic() - began,
                )
            )
            torch.save(
                dict(
                    seed=seed,
                    epoch=epoch,
                    model=net.state_dict(),
                    optimizer=opt.state_dict(),
                    torch_rng=torch.get_rng_state(),
                    numpy_rng=np.random.get_state(),
                    python_rng=random.getstate(),
                    protocol_sha256=sha(protocol_path),
                    input_sha256=sha(state / "INPUTS.npz"),
                ),
                folder / "last.tmp.pt",
            )
            (folder / "last.tmp.pt").replace(folder / "last.pt")
            print(
                f"FIT seed={seed} epoch={epoch}/{epochs} loss={history[-1]['loss']:.6f}", flush=True
            )
        net.eval()
        relative = []
        with torch.no_grad():
            for start in range(0, len(d["predict_indices"]), 16):
                own = d["predict_indices"][start : start + 16]
                values = [inference_features(d, int(i), scaler) for i in own]
                batch = tuple(torch.stack([v[k] for v in values]) for k in range(3))
                relative.append(net(*batch)["relative"].numpy())
        pools = np.concatenate(relative)
        pred = dict(relative_pool=pools, relative=pools.mean(1), indices=d["predict_indices"])
        if not np.isfinite(pred["relative"]).all():
            raise ValueError("Nonfinite frozen inference score")
        np.savez_compressed(folder / "PREDICTIONS.npz", **pred)
        torch.save(net.state_dict(), folder / "weights.pt")
        np.savez(
            folder / "scaler.npz",
            mu=scaler[0],
            sd=scaler[1],
            regime_mu=yscale[1],
            regime_sd=yscale[2],
        )
        fit = dict(
            seed=seed,
            epochs=epochs,
            training_days=len(indices),
            parameters=sum(p.numel() for p in net.parameters()),
            elapsed_seconds=time.monotonic() - began,
            weights_sha256=sha(folder / "weights.pt"),
            prediction_sha256=sha(folder / "PREDICTIONS.npz"),
            scaler_sha256=sha(folder / "scaler.npz"),
            protocol_sha256=sha(protocol_path),
            input_npz_sha256=sha(state / "INPUTS.npz"),
            max_training_label_end_us=int(np.max(d["label_end_us"][indices])),
            history=history,
            source="NEW_PRICE_ONLY_CPU_FIT_NOT_OLD_CHECKPOINT",
            resource_probe=backward_probe,
        )
        save(folder / "FIT_COMPLETE.json", fit)
        fits.append(fit)
        predictions.append(pred["relative"])
        save(
            state / "FIT_RESULTS.json",
            dict(status="RUNNING" if len(fits) < 3 else "COMPLETE_ALL3_FIXED_SEEDS", fits=fits),
        )
        del net, opt, loader
    if len(fits) != 3:
        raise RuntimeError("All3 frozen seed predictions required")
    ensemble = np.mean(predictions, axis=0)
    np.savez_compressed(
        state / "ENSEMBLE_PREDICTIONS.npz",
        relative=ensemble,
        indices=d["predict_indices"],
        decision_us=d["dates_us"][d["predict_indices"]] + DAY_US,
        symbol_order=np.array(d["symbols"]),
    )
    return ensemble


def map_targets(d, pred, protocol, state):
    indices = d["predict_indices"]
    active = (
        d["ready"][indices]
        & np.array([s in protocol["assets"]["allocation_pool"] for s in d["symbols"]])[None, :]
    )
    original = market_neutral(pred[..., 1], active)
    core = protocol["assets"]["allocation_pool"]
    select = [d["symbols"].index(s) for s in core]
    if np.max(abs(original[:, [i for i in range(10) if i not in select]]), initial=0) > 0:
        raise ValueError("Unsupported nonCORE5 allocation")
    original = original[:, select]
    corrected = original.copy()
    risk = []
    # Use identical cached minute-derived daily closes for the paired wallet risk mapping.
    frames = [
        pl.read_parquet(
            Path(protocol["wallet"]["market_work"]) / "data/normalized" / (s + "_daily.parquet")
        ).sort("available_us")
        for s in core
    ]
    available = frames[0]["available_us"].to_numpy()
    for f in frames[1:]:
        if not np.array_equal(available, f["available_us"].to_numpy()):
            raise ValueError("Cached CORE5 daily clock mismatch")
    close = np.column_stack([f["close"].to_numpy() for f in frames])
    dates = d["dates_us"][indices] + DAY_US
    for row, t in enumerate(dates):
        j = int(np.searchsorted(available, t, side="right") - 1)
        if j < 30 or available[j] != t or not np.all(np.diff(available[j - 30 : j + 1]) == DAY_US):
            raise ValueError("Incomplete exactly30 past native daily returns")
        # Direct1d closes must agree on the score slice with the shared minute-source input.
        if not np.array_equal(d["close"][indices[row], select], close[j]):
            raise ValueError("New daily close differs from bound shared wallet input")
        history = close[j - 30 : j + 1]
        if not np.isfinite(history).all() or (history <= 0).any():
            raise ValueError("Missing causal covariance close history")
        corrected[row], info = signed_risk_weights(
            original[row], np.diff(history, axis=0) / history[:-1]
        )
        risk.append(dict(decision_us=int(t), **info))
    result = {}
    for name, weights in (("ORIGINAL_NEUTRAL", original), ("COVARIANCE_10PCT", corrected)):
        path = state / "targets" / (name + ".npz")
        path.parent.mkdir(exist_ok=True)
        np.savez_compressed(path, decision_us=dates, weights=weights, symbol_order=np.array(core))
        result[name] = dict(path=str(path), sha256=sha(path))
    save(
        state / "TARGETS_FROZEN.json",
        dict(
            status="FROZEN_ALL_TARGETS_BEFORE_FIRST_WALLET",
            targets=result,
            ensemble_sha256=sha(state / "ENSEMBLE_PREDICTIONS.npz"),
            risk=risk,
            ranking_unchanged=True,
            only_correction="PAST_COVARIANCE_DOWNSCALE",
            new_parameter_search=False,
        ),
    )
    return result


def wallets(protocol, protocol_path, state, targets, deadline):
    prior = json.loads(
        Path("/workspace/shared/coin_pilot_state/LIQUID_HEDGE_PILOT_TASKS.json").read_text()
    )["tasks"][0]
    tasks = []
    for scale in (1, 0.01):
        for name, target in targets.items():
            task = dict(
                prior,
                id=("fraction" if scale == 1 else "percent") + "/" + name,
                state=str(state),
                family="PATCH_PRICE_RANK_CPU_" + name,
                seed="FIXED3_ENSEMBLE",
                mapping=name,
                funding_scale=scale,
                target_path=target["path"],
                target_sha256=target["sha256"],
                protocol_sha256=sha(protocol_path),
            )
            tasks.append(task)
    guard(state, deadline, protocol["budget"])
    cases = run_tasks(
        tasks, state, "PATCH_PRICE_RANK_WALLETS", workers=1, protocol_path=protocol_path
    )
    rows = [
        summary_row(
            case,
            state / "native" / case["task"]["id"] / "RESULT.json",
            "NEW_PRICE_ONLY_FROZEN_REPLICATION",
        )
        for case in cases
    ]
    result = dict(
        status="COMPLETE_ALL3_FIXED_FITS_AND4_WALLETS",
        qualification="NONE_CASH",
        cases=rows,
        no_original_checkpoint_restoration=True,
        no_old_utility_policy_claim=True,
        no_unseen_or_significance_claim=True,
        same_frozen_scores_pair=True,
        cap_equality_is_not_risk_equality=True,
        protocol_sha256=sha(protocol_path),
        target_freeze_sha256=sha(state / "TARGETS_FROZEN.json"),
    )
    save(state / "RESULTS.json", result)
    return result


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--protocol", type=Path, required=True)
    p.add_argument("--state", type=Path, required=True)
    a = p.parse_args()
    protocol = json.loads(a.protocol.read_text())
    budget = json.loads((a.state / "RUN_BUDGET.json").read_text())
    deadline = budget["deadline_monotonic"]
    if budget["protocol_sha256"] != sha(a.protocol):
        raise ValueError("Protocol changed after first price GET")
    try:
        check_cloud_limits({"workers": 1, "audit_device": "cpu"})
        guard(a.state, deadline, protocol["budget"])
        freeze_sources(a.protocol, a.state)
        receipt = json.loads((a.state / "INPUT_RECEIPT.json").read_text())
        if receipt["input_npz_sha256"] != sha(a.state / "INPUTS.npz") or receipt[
            "protocol_sha256"
        ] != sha(a.protocol):
            raise ValueError("Frozen input identity changed")
        d = get_data(a.state)
        pred = train(d, protocol, a.protocol, a.state, deadline)
        targets = map_targets(d, pred, protocol, a.state)
        result = wallets(protocol, a.protocol, a.state, targets, deadline)
        print(
            json.dumps(
                dict(
                    status=result["status"],
                    cases=len(result["cases"]),
                    elapsed_seconds=time.monotonic() - budget["started_monotonic"],
                )
            ),
            flush=True,
        )
    except BaseException as exc:
        save(
            a.state / "FIT_OR_WALLET_FAILURE.json",
            dict(
                error_type=type(exc).__name__,
                error=str(exc),
                elapsed_seconds=time.monotonic() - budget["started_monotonic"],
                no_missing_seed_substitution=True,
            ),
        )
        raise


if __name__ == "__main__":
    main()
