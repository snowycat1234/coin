"""Bound one sequential research job and sample aggregate descendant RSS."""
import argparse
import json
import os
import resource
import signal
import subprocess
import time
from pathlib import Path


def limits():
    resource.setrlimit(resource.RLIMIT_AS, (6_000_000_000, 6_000_000_000))
    resource.setrlimit(resource.RLIMIT_CPU, (1800, 1800))


def process_rss(root):
    pending = [root]
    total = 0
    while pending:
        pid = pending.pop()
        try:
            status = Path(f'/proc/{pid}/status').read_text()
            total += next((int(x.split()[1])*1024 for x in status.splitlines()
                           if x.startswith('VmRSS:')), 0)
            pending.extend(map(int, Path(f'/proc/{pid}/task/{pid}/children').read_text().split()))
        except (FileNotFoundError, ProcessLookupError):
            pass
    return total


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--report', type=Path, required=True)
    parser.add_argument('--seconds', type=int, default=1800)
    parser.add_argument('command', nargs=argparse.REMAINDER)
    args = parser.parse_args()
    if not 1 <= args.seconds <= 1800 or not args.command:
        raise ValueError('One explicit job with at most 1800 seconds required')
    if len(Path('/proc/swaps').read_text().splitlines()) != 1:
        raise RuntimeError('Active swap is not permitted')
    env = dict(os.environ, COIN_CLOUD_BOUNDED='1', CUDA_VISIBLE_DEVICES='',
               OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1',
               POLARS_MAX_THREADS='1', PYTHONDONTWRITEBYTECODE='1')
    began = time.monotonic()
    child = subprocess.Popen(args.command, env=env, preexec_fn=limits, start_new_session=True)
    maximum = 0
    reason = None
    try:
        while child.poll() is None:
            maximum = max(maximum, process_rss(child.pid))
            if maximum > 7_500_000_000 or time.monotonic()-began > args.seconds:
                reason = 'AGGREGATE_RSS' if maximum > 7_500_000_000 else 'WALL_TIME'
                os.killpg(child.pid, signal.SIGTERM)
                try:
                    child.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid, signal.SIGKILL)
                    child.wait()
                break
            time.sleep(.25)
    finally:
        if child.poll() is None:
            os.killpg(child.pid, signal.SIGTERM)
            try:
                child.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait()
    report = dict(exit_code=child.returncode, stop_reason=reason,
                  elapsed_seconds=time.monotonic()-began,
                  maximum_sampled_descendant_RSS_bytes=maximum,
                  RSS_sampling_seconds=.25, peak_is_sampled_not_kernel_peak=True,
                  per_process_address_limit_bytes=6_000_000_000,
                  aggregate_RSS_stop_bytes=7_500_000_000,
                  shared_cgroup_enforcement=False, single_wallet_worker_required=True)
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, indent=2)+'\n')
    raise SystemExit(child.returncode or (1 if reason else 0))


if __name__ == '__main__':
    main()
