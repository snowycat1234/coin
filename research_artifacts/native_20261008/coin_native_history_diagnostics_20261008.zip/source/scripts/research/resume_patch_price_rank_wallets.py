"""Resume only admitted frozen wallets after a launcher resource-limit refusal."""

import argparse
import json
import time
from pathlib import Path

from scripts.research.patch_price_rank_cpu import wallets
from scripts.research.patch_price_rank_inputs import guard, save, sha


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--state", type=Path, required=True)
    p.add_argument("--protocol", type=Path, required=True)
    a = p.parse_args()
    budget = json.loads((a.state / "RUN_BUDGET.json").read_text())
    protocol = json.loads(a.protocol.read_text())
    if sha(a.protocol) != budget["protocol_sha256"]:
        raise ValueError("Cannot change frozen protocol during wallet admission repair")
    fits = json.loads((a.state / "FIT_RESULTS.json").read_text())
    if (
        fits["status"] != "COMPLETE_ALL3_FIXED_SEEDS"
        or [f["seed"] for f in fits["fits"]] != protocol["model"]["seeds"]
    ):
        raise ValueError("All three actual frozen fits required; no retraining/substitution")
    for fit in fits["fits"]:
        folder = a.state / "fits" / f"seed{fit['seed']}"
        for name, key in (
            ("PREDICTIONS.npz", "prediction_sha256"),
            ("weights.pt", "weights_sha256"),
            ("scaler.npz", "scaler_sha256"),
        ):
            if sha(folder / name) != fit[key]:
                raise ValueError("Frozen fit bytes changed")
    frozen = json.loads((a.state / "TARGETS_FROZEN.json").read_text())
    if sha(a.state / "ENSEMBLE_PREDICTIONS.npz") != frozen["ensemble_sha256"]:
        raise ValueError("Frozen ensemble changed")
    for target in frozen["targets"].values():
        if sha(target["path"]) != target["sha256"]:
            raise ValueError("Frozen paired target changed")
    guard(a.state, budget["deadline_monotonic"], protocol["budget"])
    failure = a.state / "FIT_OR_WALLET_FAILURE.json"
    save(
        a.state / "WALLET_ADMISSION_RECOVERY.json",
        dict(
            preserved_failure_sha256=sha(failure),
            reason="Original launcher lacked RLIMIT_CPU; existing guard refused before any wallet.",
            action="Add inherited1800s CPU limit; resume only existing four wallets.",
            actual_fit_repeats=0,
            new_parameter_search=0,
            remaining_seconds=budget["deadline_monotonic"] - time.monotonic(),
            targets_sha256=sha(a.state / "TARGETS_FROZEN.json"),
        ),
    )
    result = wallets(protocol, a.protocol, a.state, frozen["targets"], budget["deadline_monotonic"])
    print(
        json.dumps(
            dict(
                status=result["status"],
                cases=len(result["cases"]),
                original_budget_elapsed_seconds=time.monotonic() - budget["started_monotonic"],
            )
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
