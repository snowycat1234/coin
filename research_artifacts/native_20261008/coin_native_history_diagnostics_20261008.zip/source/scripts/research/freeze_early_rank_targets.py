"""Freeze eligible early/reused rank targets with exact ensemble identities.

Only reads completed fits. No fitting, new inference, archive requests or wallet
execution. Original raw ranking and covariance sizing functions are reused.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from modules.transformer_v2.data import train_scaler
from scripts.investment.public_sma_perpetual import signed_risk_weights
from scripts.research.conditional_selector_core import RankProvenance
from scripts.research.conditional_selector_inputs import CORE, require, sha
from scripts.research.patch_price_rank_inputs import DAY_US, save
from scripts.research.rank_conditioned_selector import raw_rank_weights, stamp

ROOT = Path(__file__).resolve().parents[2]
SEEDS = [20261006, 20261007, 20261008]


def completed_ensemble(state, output, name):
    binding = json.loads((state / "TRAIN_SOURCE_BINDING.json").read_text())
    for source, digest in binding["sources"].items():
        require(sha(ROOT / source) == digest, "Completed model source changed: " + source)
    result = json.loads((state / "FIT_RESULTS.json").read_text())
    require(result["status"] == "COMPLETE_ALL3_FIXED_SEEDS", "All3 completed fits required")
    fits = result["fits"]
    require([r["seed"] for r in fits] == SEEDS, "Original fixed ensemble seed order")
    require([r["epochs"] for r in fits] == [6, 10, 1], "Original fixed epochs")
    with np.load(state / "INPUTS.npz", allow_pickle=False) as f:
        d = {k: f[k].copy() for k in f.files}
    expected_scaler = train_scaler(d["x"], d["availability"], d["train_indices"])
    individual = []
    model_refs, scaler_refs = [], []
    for fit in fits:
        folder = state / "fits" / ("seed" + str(fit["seed"]))
        require(fit["input_npz_sha256"] == sha(state / "INPUTS.npz"), "Model input identity")
        require(fit["protocol_sha256"] == binding["protocol_sha256"], "Model protocol identity")
        for file, field in (("weights.pt", "weights_sha256"),
                            ("scaler.npz", "scaler_sha256"),
                            ("PREDICTIONS.npz", "prediction_sha256")):
            require(sha(folder / file) == fit[field], "Completed fit member changed: " + file)
        with np.load(folder / "scaler.npz", allow_pickle=False) as f:
            require(np.array_equal(f["mu"], expected_scaler[0])
                    and np.array_equal(f["sd"], expected_scaler[1]),
                    "Exact training-only scaler recomputation")
        with np.load(folder / "PREDICTIONS.npz", allow_pickle=False) as f:
            require(np.array_equal(f["indices"], d["predict_indices"]), "Seed prediction clock")
            individual.append(f["relative"].copy())
        model_refs.append(dict(seed=fit["seed"], weights_sha256=fit["weights_sha256"]))
        scaler_refs.append(dict(seed=fit["seed"], scaler_sha256=fit["scaler_sha256"]))
    with np.load(state / "ENSEMBLE_PREDICTIONS.npz", allow_pickle=False) as f:
        pred = {k: f[k].copy() for k in f.files}
    require(np.array_equal(pred["relative"], np.mean(individual, axis=0)),
            "Exact all3 arithmetic-mean prediction identity")
    require(np.array_equal(pred["decision_us"], d["dates_us"][d["predict_indices"]] + DAY_US),
            "Exact ensemble feature/decision clock")
    model_path, scaler_path = output / (name + "_MODEL_IDENTITY.json"), output / (
        name + "_SCALER_IDENTITY.json")
    save(model_path, dict(kind="ORDERED_MEAN_OF3_EXACT_MODEL_WEIGHT_SHA256", models=model_refs,
                          source_binding_sha256=sha(state / "TRAIN_SOURCE_BINDING.json")))
    save(scaler_path, dict(kind="ORDERED3_EXACT_TRAINING_SCALER_SHA256", scalers=scaler_refs))
    return d, pred, fits, sha(model_path), sha(scaler_path)


def freeze(protocol, output):
    require(not output.exists(), "Fresh rank target identity; preserve prior outputs")
    for source, digest in protocol["source_hashes"].items():
        require(sha(ROOT / source) == digest, "Frozen target adapter source changed: " + source)
    require(sha(Path(protocol["early_state"]) / "COMPLETE.json")
            == protocol["early_complete_sha256"], "Completed early batch receipt identity")
    output.mkdir(parents=True)
    early = Path(protocol["early_state"])
    old = Path(protocol["reused_state"])
    require(sha(old / "INPUTS.npz") == protocol["reused_inputs_sha256"], "Reused input identity")
    require(sha(old / "ENSEMBLE_PREDICTIONS.npz") == protocol["reused_predictions_sha256"],
            "Reused predictions identity")
    require(json.loads((early / "COMPLETE.json").read_text())["new_ranker_fits"] == 3,
            "Approved early batch must complete")
    early_receipt = json.loads((early / "INPUT_RECEIPT.json").read_text())
    streams = [
        ("EARLY180", early, int(early_receipt["published_model_available_us"]),
         stamp("2022-01-23T00:00:00Z"), stamp("2023-11-04T00:00:00Z")),
        ("REUSED_NOV2023", old, stamp("2023-11-04T00:00:00Z"),
         stamp("2023-11-03T00:00:00Z"), np.iinfo(np.int64).max),
    ]
    recovery = Path(protocol["recovered_inputs"])
    require(sha(recovery) == protocol["recovered_inputs_sha256"], "Recovery identity")
    with np.load(recovery, allow_pickle=False) as f:
        d = {k: f[k].copy() for k in f.files}
    core = [d["symbol_order"].tolist().index(s) for s in CORE]
    decisions = np.arange(stamp(protocol["start"]), stamp(protocol["end_exclusive"]), DAY_US)
    rows = np.searchsorted(d["dates_us"] + DAY_US, decisions)
    require(np.array_equal(d["dates_us"][rows] + DAY_US, decisions), "Full target calendar")
    n = len(decisions)
    weights, raw = np.full((n, 5), np.nan), np.full((n, 5), np.nan)
    eligible = np.zeros(n, bool)
    provenance = {k: np.zeros(n, np.int64) for k in (
        "fit_completed_us", "train_cutoff_us", "maximum_training_label_available_us",
        "maximum_scaler_source_available_us",
    )}
    model_hash, scaler_hash = np.full(n, "", dtype="U64"), np.full(n, "", dtype="U64")
    source_name = np.full(n, "NO_CAUSAL_PREDICTION", dtype="U24")
    for name, state, available_at, cutoff, end in streams:
        source, pred, fits, mh, sh = completed_ensemble(state, output, name)
        cols = [pred["symbol_order"].tolist().index(s) for s in CORE]
        lookup = {int(t): i for i, t in enumerate(pred["decision_us"])}
        for j, decision in enumerate(decisions):
            if decision < available_at or decision >= end or int(decision) not in lookup:
                continue
            i = int(rows[j])
            if not d["ready"][i, core].all():
                continue
            # Reused predictions cannot acquire different historical feature bytes.
            old_i = int(np.searchsorted(source["dates_us"] + DAY_US, decision))
            require(np.array_equal(source["x"][old_i], d["x"][i], equal_nan=True),
                    "Prediction feature bytes changed at an admitted date")
            scores = pred["relative"][lookup[int(decision)], cols, 1]
            require(np.isfinite(scores).all(), "Unknown rank score cannot become a target")
            history = d["close"][i - 30:i + 1][:, core]
            require(history.shape == (31, 5) and np.isfinite(history).all()
                    and (history > 0).all(), "Exactly30 complete past risk returns")
            raw[j] = raw_rank_weights(scores[None, :])[0]
            weights[j], _ = signed_risk_weights(raw[j], np.diff(history, axis=0) / history[:-1])
            eligible[j] = True
            provenance["fit_completed_us"][j] = available_at
            provenance["train_cutoff_us"][j] = cutoff
            provenance["maximum_training_label_available_us"][j] = max(
                r["max_training_label_end_us"] for r in fits)
            provenance["maximum_scaler_source_available_us"][j] = int(
                (source["dates_us"][source["train_indices"]] + DAY_US).max())
            model_hash[j], scaler_hash[j], source_name[j] = mh, sh, name
    RankProvenance(*(provenance[k][eligible] for k in provenance),
                   tuple(model_hash[eligible]), tuple(scaler_hash[eligible])).validate(
        decisions[eligible])
    path = output / "CAUSAL_RANK_TARGETS.npz"
    np.savez_compressed(
        path, decision_us=decisions, weights=weights, raw_weights=raw,
        symbol_order=np.array(CORE), eligible=eligible,
        asset_eligible=np.broadcast_to(eligible[:, None], (n, 5)),
        target_available_us=decisions, model_sha256=model_hash, scaler_sha256=scaler_hash,
        source_identity=source_name, **provenance,
    )
    save(output / "BINDING.json", dict(
        status="FROZEN_ELIGIBLE_EARLY_AND_IDENTITY_REUSED_RANK_TARGETS",
        target_sha256=sha(path), protocol=protocol, eligible_dates=int(eligible.sum()),
        source_counts={name: int((source_name == name).sum()) for name, *_ in streams},
        model_SHA_semantics="Canonical ordered3-weight identity manifests; exact files verified",
        new_fits_in_this_target_adapter=0, scoring_labels_consumed=False, native_wallets=0,
        first_eligible_decision_us=int(decisions[np.flatnonzero(eligible)[0]]),
        early_receipt=early_receipt,
    ))


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--protocol", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    a = p.parse_args()
    freeze(json.loads(a.protocol.read_text()), a.output)


if __name__ == "__main__":
    main()
