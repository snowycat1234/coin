"""Rebuild the fixed seen 2024 pilot from checksum-verified official archives.

Market bytes stay outside the checkout. Never overwrites a completed dataset.
Run separately from account replay: process address-space cap is 2.5 GB.
"""

import argparse
import concurrent.futures
import csv
import io
import json
import os
import resource
import shutil
import sys
import zipfile
from datetime import date
from pathlib import Path


def validate_work(root, work):
    root, work = Path(root).resolve(), Path(work).resolve()
    if work.is_relative_to(root):
        raise ValueError("Market WORK must remain outside the checkout")
    if (work / "reports/DATASET_MANIFEST.json").exists():
        raise ValueError("Completed dataset is immutable; select a new WORK directory")
    if not (root / "modules/collector_research/pipeline/normalize.py").is_file():
        raise ValueError("ROOT is not the expected COIN checkout")
    return root, work


SCOPES = {
    "pilot": ("2024-05-31", "2024-07-02", "2024-08-11", "2024-08-12"),
    "tail": ("2024-07-12", "2024-08-13", "2025-01-01", "2025-01-02"),
    "2024H1": ("2023-12-01", "2024-01-02", "2024-07-01", "2024-07-02"),
    "2025H1": ("2024-11-29", "2025-01-02", "2025-07-01", "2025-07-02"),
    "2025H2": ("2025-05-30", "2025-07-02", "2026-01-01", "2026-01-02"),
}


def scope_months(window, *, scoring=False):
    warmup, start, end, _ = SCOPES[window]
    a, b = date.fromisoformat(start if scoring else warmup), date.fromisoformat(end)
    y, m = a.year, a.month
    result = []
    while (y, m) <= (b.year, b.month):
        result.append((y, m))
        y, m = (y + 1, 1) if m == 12 else (y, m + 1)
    return result


def scope_jobs(window, symbols, job_factory):
    jobs = []
    for symbol in symbols:
        for year, month in scope_months(window):
            if window == "pilot" and (year, month) == (2024, 5):
                jobs.append(job_factory(symbol, "klines", year, month, 31))
            elif window == "2024H1" and year == 2023:
                jobs.append(job_factory(symbol, "klines", year, month))
            elif window == "2025H2" and year == 2026:
                # No later January price bytes. Monthly funding only for Jan1
                # events plus the nearest raw right-boundary witness.
                jobs += [job_factory(symbol, family, year, month, 1)
                         for family in ("klines", "markPriceKlines")]
                jobs.append(job_factory(symbol, "fundingRate", year, month))
            else:
                jobs += [job_factory(symbol, family, year, month)
                         for family in ("klines", "markPriceKlines", "fundingRate")]
    return jobs


def combined_bytes(work, priors):
    return sum(p.stat().st_size for root in (work, *priors)
               for p in root.rglob("*") if p.is_file() and not p.is_symlink())


def bounded_january_funding(path):
    """Parse only admitted Jan1 rates and the nearest Jan2 boundary witness.

    Full immutable ZIP SHA/CRC still applies. Later timestamps are checked for
    source ordering, but later rate/interval fields never become numeric views.
    """
    import numpy as np
    import pandas as pd

    hi = 1767312000000  # 2026-01-02T00:00:00Z, exclusive scoring end
    rows, previous, witness = [], None, None
    with zipfile.ZipFile(path) as archive:
        infos = archive.infolist()
        if len(infos) != 1:
            raise ValueError("Expected a single funding CSV member")
        with archive.open(infos[0]) as stream:
            reader = csv.reader(io.TextIOWrapper(stream, encoding="utf-8-sig"))
            for index, row in enumerate(reader):
                if index == 0 and row == ["calc_time", "funding_interval_hours",
                                          "last_funding_rate"]:
                    continue
                if len(row) != 3:
                    raise ValueError("Expected three funding columns")
                time_ms = int(row[0])
                if previous is not None and time_ms < previous:
                    raise ValueError("Bounded funding source is not time ordered")
                previous = time_ms
                if time_ms >= hi and witness is None:
                    witness = time_ms
                if time_ms < hi or time_ms == witness:
                    rows.append(row)
    if not rows or witness is None:
        raise ValueError("Missing admitted January funding or right witness")
    frame = pd.DataFrame(rows, columns=["calc_time_ms", "funding_interval_hours",
                                        "last_funding_rate"]).apply(pd.to_numeric, errors="raise")
    if not np.isfinite(frame.to_numpy(dtype=float)).all():
        raise ValueError("Nonfinite admitted funding data")
    return frame


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[2])
    parser.add_argument("--work", type=Path, required=True)
    parser.add_argument("--window", choices=SCOPES, default="pilot")
    parser.add_argument(
        "--prior-work",
        type=Path,
        action="append",
        help="Read-only checksum-verified archive reuse and combined disk budget",
    )
    parser.add_argument(
        "--verified-metadata", type=Path, help="Prior official HEAD/checksum receipt"
    )
    args = parser.parse_args(argv)
    ROOT, WORK = validate_work(args.root, args.work)
    warmup, start, end, end_exclusive = SCOPES[args.window]
    priors = [p.resolve() for p in (args.prior_work or [])]
    if (len(set(priors)) != len(priors) or any(p == WORK or p.is_relative_to(ROOT)
            or WORK.is_relative_to(p) or p.is_relative_to(WORK) for p in priors)
            or any(a != b and a.is_relative_to(b) for a in priors for b in priors)):
        raise ValueError("Prior WORKs must be distinct nonoverlapping paths outside checkout")
    if any(not (p / "reports/DATASET_MANIFEST.json").is_file() for p in priors):
        raise ValueError("Prior WORK must be a completed immutable dataset")
    prior_bytes = combined_bytes(WORK, priors) - combined_bytes(WORK, [])
    work_budget = 2_000_000_000 - prior_bytes
    if work_budget <= 0:
        raise ValueError("Insufficient combined data reservation")
    os.environ.update(
        WORK_DIR=str(WORK),
        CONFIG_FILE=str(ROOT / "modules/collector_research/config.env"),
        SYMBOLS="BTCUSDT,ETHUSDT,SOLUSDT,XRPUSDT,DOGEUSDT",
        WARMUP_START=warmup,
        START_DATE=start,
        END_DATE=end,
        FAMILIES="klines,markPriceKlines,fundingRate",
        TABLE_FORMAT="parquet",
        # The independent combined guard below enforces 15GiB. Native validation
        # requires this per-WORK minimum to be below the shrinking WORK budget.
        MIN_FREE_GIB="1" if args.window in ("pilot", "tail") else "0",
        MAX_WORK_GIB=str(work_budget / 2**30),
        MAX_ARCHIVE_MIB="16",
        MAX_UNCOMPRESSED_MIB="128",
        HTTP_RETRIES="2",
        DOWNLOAD_WORKERS="3",
        HTTP_CONNECT_TIMEOUT="15",
        HTTP_READ_TIMEOUT="60",
        DAILY_FALLBACK="0",
        REFRESH_CHECKSUMS="0",
        OMP_NUM_THREADS="1",
        OPENBLAS_NUM_THREADS="1",
        MKL_NUM_THREADS="1",
        POLARS_MAX_THREADS="1",
        CUDA_VISIBLE_DEVICES="",
    )
    resource.setrlimit(resource.RLIMIT_AS, (2_500_000_000, 2_500_000_000))
    sys.path.insert(0, str(ROOT))
    from modules.collector_research.pipeline import common as c
    c.init_dirs()
    c.bounds()
    native_guard = c.disk_guard

    def combined_guard(extra_bytes=0, *, scan=True):
        native_guard(extra_bytes, scan=scan)
        total = combined_bytes(WORK, priors)
        if (total + extra_bytes > 2_000_000_000
                or shutil.disk_usage(WORK).free - extra_bytes < 15 * 2**30):
            raise RuntimeError("Combined data budget or disk reserve exceeded")

    # Native downloader, normalizer and table writer import this guarded function.
    # Every stream write and normalized batch therefore shares the five-WORK cap.
    c.disk_guard = combined_guard
    from modules.collector_research.pipeline import download as d
    from modules.collector_research.pipeline import normalize as n

    if args.window == "2025H2":
        native_csv = n.numeric_csv

        def scoped_csv(path, funding=False):
            if funding and path.name.endswith("-fundingRate-2026-01.zip"):
                return bounded_january_funding(path)
            return native_csv(path, funding)

        n.numeric_csv = scoped_csv

    month_keys = scope_months(args.window)
    jobs = scope_jobs(args.window, c.symbols(), d.Job)
    combined_guard()
    metadata = []

    def head(job):
        with d.session() as s:
            r = s.head(job.url, timeout=(15, 60))
            r.raise_for_status()
            size = int(r.headers["Content-Length"])
            check = s.get(job.url + ".CHECKSUM", timeout=(15, 60))
            check.raise_for_status()
            if len(check.content) > 4096:
                raise ValueError("Checksum response too large")
            official_sha = d.parse_checksum(check.text, job.path.name)
            if not 0 < size <= 16 * 2**20:
                raise ValueError("Archive metadata over bound")
            return {
                **job.record(),
                "announced_zip_bytes": size,
                "official_sha256": official_sha,
                "last_modified": r.headers.get("Last-Modified"),
                "etag": r.headers.get("ETag"),
            }

    metadata_sha = None
    if args.verified_metadata:
        proof = json.loads(args.verified_metadata.read_text())
        source = proof.get("archives", proof.get("objects", []))
        by_url = {row["url"]: row for row in source}
        if len(source) != len(jobs) or set(by_url) != {job.url for job in jobs}:
            raise ValueError("Metadata scope differs from exact fixed archive plan")
        metadata_sha = c.sha256(args.verified_metadata)
        for job in jobs:
            row = by_url[job.url]
            if not 0 < row["announced_zip_bytes"] <= 16 * 2**20:
                raise ValueError("Metadata archive size exceeds bound")
            d.parse_checksum(row["official_sha256"] + "  " + job.stem, job.stem)
            metadata.append(
                {
                    **job.record(),
                    "announced_zip_bytes": row["announced_zip_bytes"],
                    "official_sha256": row["official_sha256"],
                }
            )
    else:
        with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
            metadata = list(pool.map(head, jobs))
    compressed = sum(x["announced_zip_bytes"] for x in metadata)
    if compressed > 250_000_000:
        raise ValueError("Compressed planned budget exceeded")
    c.dump(
        {
            "status": "HEAD_VERIFIED",
            "total_compressed_bytes": compressed,
            "prior_metadata_sha256": metadata_sha,
            "objects": metadata,
        },
        WORK / "reports/source_metadata.json",
    )
    print("METADATA", len(metadata), compressed, flush=True)
    records = []
    if priors:
        for job, metadata_row in zip(jobs, metadata, strict=True):
            old = next((p / "data/raw" / job.family / job.symbol / job.stem
                        for p in priors if (p / "data/raw" / job.family
                        / job.symbol / job.stem).exists()), None)
            if old is None or job.path.exists():
                continue
            proof = d.verify_local(old)
            if proof["sha256"] != metadata_row["official_sha256"]:
                raise ValueError("Existing archive differs from current official checksum")
            combined_guard(proof["bytes"] + 4096)
            job.path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(old, job.path)
            shutil.copyfile(Path(str(old) + ".CHECKSUM"), Path(str(job.path) + ".CHECKSUM"))
            combined_guard()

    admitted = {row["url"]: row for row in metadata}
    native_fetch = d.fetch

    def fetch(job, session, *, reserved=False):
        result = native_fetch(job, session, reserved=reserved)
        proof = admitted[job.url]
        if (result.get("sha256") != proof["official_sha256"]
                or result.get("bytes") != proof["announced_zip_bytes"]):
            raise ValueError("Downloaded archive differs from admitted metadata")
        return result

    # Preserve the native bounded scheduler and fail/drain receipts. No new
    # source requests are launched after an error; only in-flight jobs drain.
    d.planned_jobs = lambda: jobs
    d.fetch = fetch
    records = d.collect()["archives"]
    if any(r["status"] == "ARCHIVE_UNAVAILABLE_UNCLASSIFIED" for r in records):
        raise ValueError("Expected archive unavailable")
    c.dump(
        {"status": "ALL_OFFICIAL_SHA256_AND_CRC_VERIFIED", "archives": records},
        WORK / "reports/download_manifest.json",
    )
    c.disk_guard()
    combined_guard()
    n.normalize()
    n.verify_dataset()
    c.disk_guard()
    combined_guard()
    from scripts.research.audit_official_pilot_coverage import audit

    audit(ROOT, WORK, window=args.window, write=True)
    audit = []
    import numpy as np
    import pandas as pd

    for s in c.symbols():
        daily = pd.read_parquet(WORK / f"data/normalized/{s}_daily.parquet")
        fund = pd.read_parquet(WORK / f"data/normalized/{s}_funding_events.parquet")
        score = daily[
            (daily.dt >= pd.Timestamp(start, tz="UTC"))
            & (daily.dt < pd.Timestamp(end_exclusive, tz="UTC"))
        ]
        gaps = {}
        for fam in ("klines", "markPriceKlines"):
            paths = [WORK / f"data/normalized/minute/{s}/{fam}/{y}-{m:02}.parquet"
                     for y, m in month_keys]
            parts = [
                pd.read_parquet(path, columns=["timestamp_ms"])
                for path in paths if path.exists()
            ]
            t = pd.concat(parts).timestamp_ms.to_numpy()
            lo = int(
                pd.Timestamp("2024-06-01" if args.window == "pilot" else warmup, tz="UTC").value
                // 10**6
            )
            hi = int(pd.Timestamp(end_exclusive, tz="UTC").value // 10**6)
            expected = np.arange(lo, hi, 60000)
            gaps[fam] = {
                "rows": len(t),
                "missing_minutes": len(np.setdiff1d(expected, t)),
                "duplicate_times": len(t) - len(np.unique(t)),
            }
        times = fund.calc_time_ms.to_numpy()
        hours = fund.funding_interval_hours.to_numpy()
        delta = np.diff(times)
        bad = (np.abs(delta - hours[:-1] * 3600000) > 1000) & (
            np.abs(delta - hours[1:] * 3600000) > 1000
        )
        audit.append(
            {
                "symbol": s,
                "score_days": len(score),
                "score_complete_trade_days": int(score.complete_kline.sum()),
                "score_complete_mark_days": int(score.complete_mark.sum()),
                "score_complete_funding_days": int(score.complete_funding.sum()),
                "score_complete_funding_execution_intervals": int(
                    score.funding_interval_complete.sum()
                ),
                "funding_events": len(fund),
                "funding_gap_mismatches": int(bad.sum()),
                "missing_past_mark_events": int(fund.past_mark_price.isna().sum()),
                "minute_gaps": gaps,
            }
        )
    receipt = {
        "status": "NEW_REBUILT_DATASET_NOT_OLD_SHA_REUSE",
        "work": str(WORK),
        "manifest": str(WORK / "reports/DATASET_MANIFEST.json"),
        "manifest_sha256": c.sha256(WORK / "reports/DATASET_MANIFEST.json"),
        "coverage_audit_sha256": c.sha256(WORK / "reports/SCORING_COVERAGE_AUDIT.json"),
        "pipeline_code_sha256": c.code_digest(),
        "import_script_sha256": c.sha256(Path(__file__)),
        "archives": len(records),
        "compressed_bytes": sum(r["bytes"] for r in records),
        "declared_expanded_csv_bytes": sum(r["csv_bytes"] for r in records),
        "on_disk_bytes": c.owned_bytes(WORK),
        "normalized_bytes": c.owned_bytes(WORK / "data/normalized"),
        "scope": {
            "warmup_start": warmup,
            "score_start": start,
            "score_end_exclusive": end_exclusive,
        },
        "January_2026_container_extraction": (
            "Jan1 rates plus nearest Jan2 raw witness only; later rows' timestamps "
            "checked for ordering, later rates/intervals never parsed into numeric views; "
            "witness excluded from normalized features and scoring"
            if args.window == "2025H2" else "NOT_APPLICABLE"
        ),
        "audit": audit,
        "caveats": [
            "Binance USD-M proxy, not Bybit native",
            "Raw funding preserved; units conditional; charge/publication time uncertified",
            "May31 pilot warmup trade only; tail excludes August12 mark gap from scoring",
            "Final funding execution interval may lack right-boundary event; not filled with zero",
        ],
        "created_utc": pd.Timestamp.now(tz="UTC").isoformat(),
    }
    c.dump(receipt, WORK / "reports/REBUILD_RECEIPT.json")
    print(json.dumps(receipt, indent=2), flush=True)


if __name__ == "__main__":
    main()
