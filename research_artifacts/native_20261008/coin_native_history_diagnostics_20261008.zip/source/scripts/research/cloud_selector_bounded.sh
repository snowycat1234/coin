#!/usr/bin/env bash
# Cloud-only preflight/import/test entrypoint; explicit 2026-10-08 task limits.
set -euo pipefail
repo=$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)
free_bytes=$(df -PB1 "$repo" | awk 'NR==2 {print $4}')
(( free_bytes >= 16106127360 )) || { echo 'STOP: less than 15 GiB free' >&2; exit 1; }
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export POLARS_MAX_THREADS=1 NUMEXPR_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1
export PYTHONPATH="$repo/src:$repo${PYTHONPATH:+:$PYTHONPATH}"
export QUANT_ROOT="$repo"
export QUANT_STATE="${QUANT_STATE:-$(dirname "$repo")/coin_selector_integration_state}"
: "${COIN_RESOURCE_REPORT:?Set a fresh external resource-report path}"
python="${COIN_PYTHON:-python3}"
first_cpu=$(awk '/Cpus_allowed_list:/ {split($2, a, /[-,]/); print a[1]}' /proc/self/status)
cd "$repo"
# Existing cloud adapter verifies swap0, disables CUDA, applies hard/soft6GB
# address and1800s CPU limits, and samples/stops aggregate descendant RSS7.5GB.
exec taskset -c "$first_cpu" "$python" "$repo/scripts/research/cloud_bounded.py" \
  --report "$COIN_RESOURCE_REPORT" --seconds "${COIN_WALL_SECONDS:-1800}" "$@"
