"""Run only the approved, hash-frozen two-Ridge 2024H1 comparison."""

from __future__ import annotations

import argparse
import json
import resource
import subprocess
import time
from pathlib import Path

from scripts.research.conditional_selector_inputs import require, sha
from scripts.research.patch_price_rank_inputs import save
from scripts.research.run_conditional_selector import run

ROOT = Path(__file__).resolve().parents[2]


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--protocol", type=Path, required=True)
    p.add_argument("--state", type=Path, required=True)
    a = p.parse_args()
    protocol = json.loads(a.protocol.read_text())
    require(not a.state.exists(), "Fresh two-fit identity required; preserve prior outputs")
    require(subprocess.check_output(
        ["git", "show", "HEAD:" + str(a.protocol.resolve().relative_to(ROOT))], cwd=ROOT
    ) == a.protocol.read_bytes(), "Complete first-fit protocol must be committed")
    for name, digest in protocol["source_hashes"].items():
        require(sha(ROOT / name) == digest, "Frozen selector source changed: " + name)
    for ref in protocol["input_refs"]:
        require(sha(ref["path"]) == ref["sha256"], "Frozen input changed: " + ref["path"])
    for ref in protocol["preflight_refs"]:
        require(sha(ref["path"]) == ref["sha256"], "Preflight changed")
        fold = json.loads(Path(ref["path"]).read_text())
        require(fold["disjoint_training_rows"] == 40
                and fold["models"]["RIDGE"]["status"] == "PREFLIGHT_READY_NO_FIT"
                and fold["models"]["HIST_GB"]["status"] == "NOT_ADMITTED",
                "Exact40 causal disjoint intervals and Ridge-only admission required")
    resource.setrlimit(resource.RLIMIT_CPU, (600, 600))
    a.state.mkdir(parents=True)
    began = time.monotonic()
    save(a.state / "STARTED.json", dict(
        protocol_sha256=sha(a.protocol), actual_started_unix=time.time(),
        maximum_new_fits=2, maximum_overall_wall_seconds=600,
    ))
    results = []
    try:
        for variant in protocol["variants"]:
            require(time.monotonic() - began < 600, "Approved overall deadline reached")
            args = argparse.Namespace(
                operation="train", input=protocol["input"], binding=protocol["binding"],
                rank_provenance=protocol["rank_provenance"],
                features=variant.get("features"), state_only=variant["state_only"],
                mode="market", schedule=protocol["schedule"],
                output=str(a.state / variant["name"]), resume=False,
            )
            result = run(args)
            require(result["fits_attempted"] == 1
                    and result["fit_wall_seconds"] <= 150
                    and result["status"] == "COMPLETE_ENGINEERING_AND_TARGET_EXPORT",
                    "Unexpected fit count, failure or budget use; stop before any further fit")
            results.append(dict(
                variant=variant["name"], fit_wall_seconds=result["fit_wall_seconds"],
                run_sha256=sha(Path(args.output) / "run.json"),
            ))
            save(a.state / "PROGRESS.json", dict(completed_variants=results,
                                                 elapsed_seconds=time.monotonic() - began))
        require(len(results) == 2 and sum(r["fit_wall_seconds"] for r in results) <= 300,
                "Approved two-fit/300-second aggregate limit")
        save(a.state / "COMPLETE.json", dict(
            status="COMPLETE2_APPROVED_RIDGE_FITS_TARGETS_FROZEN_NO_WALLETS",
            protocol_sha256=sha(a.protocol), results=results,
            elapsed_seconds=time.monotonic() - began,
            ranker_fits=0, selector_fits=2, HistGB_fits=0, native_wallets=0,
            no_investment_qualification_or_economic_claim=True,
        ))
    except BaseException as exc:
        save(a.state / "FAILURE.json", dict(
            error_type=type(exc).__name__, error=str(exc),
            elapsed_seconds=time.monotonic() - began, completed_variants=results,
            automatic_retry_or_refit=False,
        ))
        raise


if __name__ == "__main__":
    main()
