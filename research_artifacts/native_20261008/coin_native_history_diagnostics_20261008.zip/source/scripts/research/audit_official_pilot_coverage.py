"""Verify fixed pilot price clocks and exact raw funding event coverage."""

import argparse
import json
import os
import sys
from pathlib import Path


def require(condition, message):
    if not condition:
        raise ValueError(message)


def audit(root, work, *, window="pilot", write=False):
    root, work = Path(root).resolve(), Path(work).resolve()
    require(not work.is_relative_to(root), "Market WORK must remain outside checkout")
    output = work / "reports/SCORING_COVERAGE_AUDIT.json"
    require(not write or not output.exists(), "Existing coverage evidence is immutable")
    os.environ.update(
        CONFIG_FILE=str(root / "modules/collector_research/config.env"),
        WORK_DIR=str(work),
        OPENBLAS_NUM_THREADS="1",
        OMP_NUM_THREADS="1",
    )
    sys.path.insert(0, str(root))
    import numpy as np
    import pandas as pd

    from modules.collector_research.pipeline.common import dump, sha256
    from modules.collector_research.pipeline.normalize import numeric_csv

    W = work
    from scripts.research.rebuild_official_pilot_inputs import SCOPES, scope_months

    require(window in SCOPES, "Unknown fixed window")
    warmup, start, _end, end_exclusive = SCOPES[window]
    month_keys = scope_months(window, scoring=True)
    first = pd.Timestamp(start, tz="UTC")
    rank = first - pd.Timedelta(days=first.weekday())
    manifest = json.loads((W / "reports/DATASET_MANIFEST.json").read_text())
    require(
        manifest["date_range"] == {"start": warmup, "end_inclusive": _end},
        "Manifest fixed date range differs",
    )
    for item in manifest["artifacts"]:
        path = (W / item["relative_path"]).resolve()
        require(
            path.is_relative_to(W) and sha256(path) == item["sha256"],
            "Manifest artifact hash differs",
        )
    from modules.collector_research.pipeline.download import verify_local

    checked = set()
    for receipt in manifest["source_receipts"]:
        for source in receipt.get("sources", []):
            path = Path(source["path"]).resolve()
            require(path.is_relative_to(W), "Archive outside dataset WORK")
            if path not in checked:
                require(
                    verify_local(path)["sha256"] == source["sha256"], "Raw source identity differs"
                )
                checked.add(path)
    lo = pd.Timestamp(start, tz="UTC").value // 10**6
    hi = pd.Timestamp(end_exclusive, tz="UTC").value // 10**6
    rows = []
    for s in ["BTCUSDT", "ETHUSDT", "SOLUSDT", "XRPUSDT", "DOGEUSDT"]:
        raw = (
            pd.concat(
                [
                    numeric_csv(
                        W / f"data/raw/fundingRate/{s}/{s}-fundingRate-{y}-{m:02}.zip", True
                    )
                    for y, m in month_keys
                ]
            )
            .sort_values("calc_time_ms")
            .reset_index(drop=True)
        )
        expected = raw[(raw.calc_time_ms >= lo) & (raw.calc_time_ms < hi)]
        normal = pd.read_parquet(W / f"data/normalized/{s}_funding_events.parquet")
        actual = normal[(normal.calc_time_ms >= lo) & (normal.calc_time_ms < hi)]
        same = np.array_equal(
            expected[["calc_time_ms", "funding_interval_hours", "last_funding_rate"]].to_numpy(),
            actual[["calc_time_ms", "funding_interval_hours", "last_funding_rate"]].to_numpy(),
        )
        require(same, "Funding raw/normalized event identity differs")
        before = raw[raw.calc_time_ms < lo].iloc[-1]
        after = raw[raw.calc_time_ms >= hi].iloc[0]
        context = raw[
            (raw.calc_time_ms >= before.calc_time_ms) & (raw.calc_time_ms <= after.calc_time_ms)
        ]
        times = context.calc_time_ms.to_numpy()
        h = context.funding_interval_hours.to_numpy()
        diff = np.diff(times)
        gaps = (np.abs(diff - h[:-1] * 3600000) > 1000) & (np.abs(diff - h[1:] * 3600000) > 1000)
        require(not gaps.any(), "Funding witness interval gap")
        daily = pd.read_parquet(W / f"data/normalized/{s}_daily.parquet")
        warmlo = pd.Timestamp(warmup, tz="UTC").value // 1000
        expected_days = np.arange(warmlo, hi * 1000, 86400000000)
        require(
            np.array_equal(daily.open_us.to_numpy(), expected_days), "Daily warmup grid differs"
        )
        require(daily.complete_kline.all(), "Incomplete daily trade prices")
        require(
            np.array_equal(daily.close_us.to_numpy(), expected_days + 86400000000),
            "Daily close clock differs",
        )
        require(
            np.array_equal(daily.available_us.to_numpy(), expected_days + 86400000000),
            "Daily availability clock differs",
        )
        require(
            (daily[["open", "high", "low", "close"]].to_numpy() > 0).all(), "Invalid daily prices"
        )
        require(
            len(daily[daily.available_us <= rank.value // 1000]) == 31,
            "First weekly rank lacks 31 completed closes",
        )
        counts = {}
        for f in ("klines", "markPriceKlines"):
            ts = pd.concat(
                [
                    pd.read_parquet(
                        W / f"data/normalized/minute/{s}/{f}/{y}-{m:02}.parquet",
                        columns=["timestamp_ms"],
                    )
                    for y, m in month_keys
                ]
            ).timestamp_ms.to_numpy()
            ts = ts[(ts >= lo) & (ts < hi)]
            require(
                np.array_equal(ts, np.arange(lo, hi, 60000)),
                "Scoring minute grid incomplete or duplicate",
            )
            counts[f] = len(ts)
        rows.append(
            {
                "symbol": s,
                "warmup_daily_rows": len(daily),
                "complete_trade_daily_grid": True,
                "daily_exclusive_availability_verified": True,
                "available_closes_at_first_weekly_rank": 31,
                "scoring_minute_rows": counts,
                "expected_raw_funding_events": len(expected),
                "normalized_funding_events": len(actual),
                "funding_event_set_exact_match": same,
                "left_raw_witness_ms": int(before.calc_time_ms),
                "right_raw_witness_ms": int(after.calc_time_ms),
                "witness_inclusive_gaps": int(gaps.sum()),
                "funding_rate_unit": "UNCONFIRMED_RAW_PRESERVED",
            }
        )
    result = {
        "status": "PASS_EXACT_SCORING_MINUTES_AND_FUNDING_EVENT_SET_WITH_RAW_EDGE_WITNESSES",
        "manifest_sha256": sha256(W / "reports/DATASET_MANIFEST.json"),
        "score_start_ms": int(lo),
        "score_end_exclusive_ms": int(hi),
        "assets": rows,
        "caveat": "Archive events only; funding units and charge/publication time uncertified.",
    }
    if write:
        dump(result, output)
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[2])
    parser.add_argument("--work", type=Path, required=True)
    parser.add_argument("--write", action="store_true", help="Create new audit; refuses overwrite")
    from scripts.research.rebuild_official_pilot_inputs import SCOPES

    parser.add_argument("--window", choices=SCOPES, default="pilot")
    args = parser.parse_args(argv)
    print(json.dumps(audit(args.root, args.work, window=args.window, write=args.write), indent=2))


if __name__ == "__main__":
    main()
