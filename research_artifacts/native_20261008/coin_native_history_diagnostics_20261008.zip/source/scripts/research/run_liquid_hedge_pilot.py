"""Six independent wallets on one frozen, new-provenance seen window."""
import argparse
import json
import subprocess
import time
from pathlib import Path

import numpy as np
import polars as pl

from modules.transformer_v3.market_binding import digest_file
from modules.transformer_v3.wallet import run_tasks
from scripts.research.liquid_market_hedge import long_only_targets, market_hedge_targets
from scripts.research.public_cross_section_momentum import DAY_US, public_targets
from scripts.research.run_public_momentum import summary_row

ROOT = Path(__file__).resolve().parents[2]


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(value, indent=2, allow_nan=False)+'\n')
    temp.replace(path)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--protocol', type=Path, required=True)
    parser.add_argument('--state', type=Path, required=True)
    parser.add_argument('--work', type=Path, required=True)
    args = parser.parse_args()
    began = time.monotonic()
    protocol = json.loads(args.protocol.read_text())
    state, work = args.state.resolve(), args.work.resolve()
    if state.is_relative_to(ROOT) or work.is_relative_to(ROOT):
        raise ValueError('Market and ledger artifacts must stay outside checkout')
    manifest_path = work/'reports/DATASET_MANIFEST.json'
    if digest_file(manifest_path) != protocol['data_manifest_sha256']:
        raise ValueError('New public input manifest differs from frozen pilot')
    coverage_path = work/'reports/SCORING_COVERAGE_AUDIT.json'
    if digest_file(coverage_path) != protocol['scoring_coverage_sha256']:
        raise ValueError('Frozen scoring coverage audit changed')
    coverage = json.loads(coverage_path.read_text())
    if coverage['status'] != protocol['required_coverage_status']:
        raise ValueError('Scoring coverage not accepted')
    symbols = protocol['symbols']
    window = protocol['window']
    if (coverage['manifest_sha256'] != protocol['data_manifest_sha256']
            or coverage['score_start_ms']*1000 != window['start']
            or coverage['score_end_exclusive_ms']*1000 != window['end']
            or {a['symbol'] for a in coverage['assets']} != set(symbols)):
        raise ValueError('Coverage identity differs from frozen input/window/pool')
    allowed_windows = {(1704153600000000, 1719878400000000, 182),
                       (1719878400000000, 1723420800000000, 41),
                       (1723507200000000, 1735776000000000, 142),
                       (1735776000000000, 1751414400000000, 181),
                       (1751414400000000, 1767312000000000, 184)}
    if (window['start'], window['end'], window['days']) not in allowed_windows:
        raise ValueError('Only the five pre-existing registered seen windows allowed')
    dates = np.arange(window['start'], window['end'], DAY_US, dtype=np.int64)
    if len(dates) != window['days']:
        raise ValueError('Frozen complete daily decision calendar required')
    source_paths = [Path(__file__), ROOT/'scripts/research/liquid_market_hedge.py',
                    ROOT/'scripts/research/public_cross_section_momentum.py',
                    ROOT/'modules/collector_research/validation/cloud_guard.py',
                    ROOT/'modules/collector_research/validation/runtime.py',
                    ROOT/'scripts/research/cloud_bounded.py', args.protocol.resolve()]
    for path in source_paths:
        import hashlib
        committed = subprocess.check_output(['git', '-C', str(ROOT), 'show',
                                              'HEAD:'+str(path.relative_to(ROOT))])
        if hashlib.sha256(committed).hexdigest() != digest_file(path):
            raise ValueError('Commit frozen pilot sources before economics: '+str(path))
    for name, expected in protocol.get('unchanged_target_rule_sha256', {}).items():
        if digest_file(ROOT/name) != expected:
            raise ValueError('Pre-pilot frozen target rule changed: '+name)
    manifest = json.loads(manifest_path.read_text())
    registered = {x['relative_path']: x['sha256'] for x in manifest['artifacts']}
    prices = []
    available = None
    daily_refs = []
    for symbol in symbols:
        path = work/'data/normalized'/f'{symbol}_daily.parquet'
        if digest_file(path) != registered[str(path.relative_to(work))]:
            raise ValueError('Daily source changed')
        frame = pl.read_parquet(path).sort('available_us')
        clock = frame['available_us'].to_numpy()
        if (not np.array_equal(clock, frame['open_us'].to_numpy()+DAY_US)
                or not np.array_equal(clock, frame['close_us'].to_numpy())
                or not np.all(np.diff(clock) == DAY_US)
                or not frame['complete_kline'].all()):
            raise ValueError('Complete causal daily close clock and rows required')
        if available is None:
            available = clock
        elif not np.array_equal(clock, available):
            raise ValueError('Shared daily clock mismatch')
        if not frame['symbol'].eq(symbol).all() or clock.max() > 1772323200000000:
            raise ValueError('Symbol identity or locked boundary mismatch')
        prices.append(frame['close'].to_numpy())
        daily_refs.append(dict(path=str(path), sha256=digest_file(path)))
    close = np.column_stack(prices)
    tasks = []
    diagnostics = {}
    factories = dict(ORIGINAL_CSMOM=public_targets, BTC_HEDGE=market_hedge_targets,
                     LONG_ONLY=long_only_targets)
    for family, factory in factories.items():
        weights, details = factory(close, available, dates, symbols, symbols)
        path = state/'targets'/(family+'.npz')
        path.parent.mkdir(parents=True, exist_ok=True)
        if path.exists():
            with np.load(path, allow_pickle=False) as prior:
                if (not np.array_equal(prior['weights'], weights)
                        or not np.array_equal(prior['decision_us'], dates)
                        or prior['symbol_order'].tolist() != symbols):
                    raise ValueError('Frozen pilot targets changed on resume')
        else:
            np.savez_compressed(path, weights=weights, decision_us=dates,
                                symbol_order=np.array(symbols))
        diagnostics[family] = details
        for scale in protocol['funding_scales']:
            label = 'fraction' if scale == 1 else 'percent'
            tasks.append(dict(id=label+'/'+family, state=str(state),
                collector_root=str(ROOT/'modules/collector_research'), work=str(work),
                source_run=str(work/'new-input-provenance'), family=family, seed=0,
                profile='FULL', mapping='NEUTRAL', window=window, funding_scale=scale,
                target_path=str(path), target_sha256=digest_file(path),
                protocol_sha256=digest_file(args.protocol), noncausal=False,
                resource_policy='cloud', market_input_manifest_path=str(manifest_path),
                market_input_manifest_sha256=digest_file(manifest_path)))
    save(state/'TARGET_DIAGNOSTICS.json', dict(diagnostics=diagnostics, daily_refs=daily_refs))

    def progress(completed, failed, total, detail):
        save(state/'progress.json', dict(completed=completed, failed=failed, total=total,
                                         detail=detail, elapsed_seconds=time.monotonic()-began))

    cases = run_tasks(tasks, state, protocol.get('result_name', 'LIQUID_HEDGE_PILOT'), workers=1,
                     protocol_path=args.protocol, on_progress=progress)
    rows = [summary_row(case, state/'native'/case['task']['id']/'RESULT.json',
                        'NEW_OFFICIAL_INPUT_PAIRED_REPLAY') for case in cases]
    comparisons = []
    for scale in protocol['funding_scales']:
        selected = {r['family']: r for r in rows if r['funding_scale'] == scale}
        hedge = selected['BTC_HEDGE']
        for control in ('ORIGINAL_CSMOM', 'LONG_ONLY'):
            ref = selected[control]
            delta_net = hedge['net_PnL']-ref['net_PnL']
            delta_dd = hedge['minute_MDD']-ref['minute_MDD']
            label = ('NET_AND_DRAWDOWN_DOMINANCE' if delta_net >= 0 and delta_dd <= 0
                     else 'DEFENSIVE_RETURN_TRADEOFF' if delta_dd < 0
                     else 'HIGHER_RETURN_HIGHER_DRAWDOWN' if delta_net > 0
                     else 'NO_INCREMENT_ON_NET_AND_DRAWDOWN')
            comparisons.append(dict(funding_scale=scale, control=control,
                net_difference_USDT=delta_net, minute_MDD_difference=delta_dd,
                descriptive_classification=label))
    save(state/'RESULTS.json', dict(status='COMPLETE_SEEN_SINGLE_WINDOW_PILOT',
         qualification='NONE_CASH', new_wallets=6, reused_wallets=0, new_fits=0,
         new_input_provenance=True, old_input_SHA_reused=False, locked_consumed=False,
         protocol_sha256=digest_file(args.protocol), cases=rows, comparisons=comparisons,
         elapsed_seconds=time.monotonic()-began,
         source_commit=subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse',
                                                'HEAD']).decode().strip()))


if __name__ == '__main__':
    main()
