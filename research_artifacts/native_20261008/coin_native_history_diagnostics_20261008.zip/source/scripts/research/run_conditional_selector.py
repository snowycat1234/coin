"""Finite chronological selector trainer for the main thread's SELECTOR_INPUTS.npz.

Exports budgets and net targets for ONE shared wallet. It never computes combined
PnL by averaging expert returns. Synthetic runs only validate the engineering.
Use the bounded launcher; models are trusted local joblib checkpoints, SHA-bound.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import multiprocessing as mp
import os
import platform
import time
from pathlib import Path

import numpy as np
import polars as pl

from scripts.research.conditional_selector_core import (
    DAY_US,
    RankProvenance,
    UtilitySelector,
    budget_path,
    chronological_training_mask,
    clock,
    nonoverlap_indices,
    shared_targets,
)

LATENCY_US = 120_000_001
FAMILIES = ("RIDGE", "HIST_GB")
DEFAULT_FOLDS = (
    ("2023H2", "2023-07-01", "2024-01-01"),
    ("2024H1", "2024-01-01", "2024-07-01"),
    ("2024H2", "2024-07-01", "2025-01-01"),
    ("2025H1", "2025-01-01", "2025-07-01"),
)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for data in iter(lambda: f.read(1024 * 1024), b""):
            h.update(data)
    return h.hexdigest()


def json_write(path, value):
    path = Path(path)
    tmp = path.with_suffix(path.suffix + ".partial")
    tmp.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
    os.replace(tmp, path)


def date_us(value):
    return int(np.datetime64(value, "us").astype(np.int64))


def strings(value, name):
    a = np.asarray(value)
    if a.ndim != 1 or a.dtype.kind not in "US" or not len(a):
        raise ValueError(f"{name}: nonempty string identity array required")
    out = tuple(str(x) for x in a)
    if len(set(out)) != len(out) or any(not x for x in out):
        raise ValueError(f"{name}: identities must be unique and nonempty")
    return out


def load_npz(path):
    # No object/pickle arrays or unbounded compressed payloads.
    import zipfile

    with zipfile.ZipFile(path) as z:
        if sum(i.file_size for i in z.infolist()) > 250_000_000:
            raise ValueError("NPZ uncompressed payload exceeds 250 MB")
    with np.load(path, allow_pickle=False) as data:
        return {k: data[k] for k in data.files}


class Panel:
    def __init__(self, path, binding):
        p = load_npz(path)
        self.path, self.input_sha = Path(path).resolve(), sha(path)
        self.binding = binding
        self.d = clock(p["decision_us"], "decision_us")
        if np.any(np.diff(self.d) != DAY_US):
            raise ValueError("Full daily calendar required; missing days cannot be compressed")
        self.symbols = strings(p["symbol_order"], "symbol_order")
        self.names = strings(p["expert_order"], "expert_order")
        mechanisms = np.asarray(p["mechanism_order"])
        if mechanisms.ndim != 1 or mechanisms.dtype.kind not in "US":
            raise ValueError("mechanism_order must be a string identity array")
        self.mechanisms = tuple(str(x) for x in mechanisms)
        if len(self.mechanisms) != len(self.names) or any(not x for x in self.mechanisms):
            raise ValueError("One explicit mechanism per expert required")
        self.cash = self.names.index("CASH")
        t, e, a = len(self.d), len(self.names), len(self.symbols)
        self.targets = np.asarray(p["targets"], float)
        self.raw = np.asarray(p["raw_targets"], float)
        self.y = np.asarray(p["utility"], float)
        self.feedback = np.asarray(p["net_feedback"], float)
        self.eligible = np.asarray(p["target_eligible"])
        self.complete = np.asarray(p["label_complete"])
        self.target_av = np.asarray(p["target_available_us"])
        self.feedback_av = np.asarray(p["feedback_available_us"])
        self.label_av = clock(p["label_available_us"], "label_available_us")
        for name, value, shape in (
            ("targets", self.targets, (t, e, a)),
            ("raw_targets", self.raw, (t, e, a)),
            ("utility", self.y, (t, e)),
            ("net_feedback", self.feedback, (t, e)),
            ("target_eligible", self.eligible, (t, e)),
            ("label_complete", self.complete, (t, e)),
            ("target_available_us", self.target_av, (t, e)),
            ("feedback_available_us", self.feedback_av, (t, e)),
            ("label_available_us", self.label_av, (t,)),
        ):
            if value.shape != shape:
                raise ValueError(f"{name}: expected {shape}, got {value.shape}")
        if self.eligible.dtype != bool or self.complete.dtype != bool:
            raise ValueError("Explicit Boolean eligibility and completeness required")
        for value in (self.target_av, self.feedback_av):
            if value.dtype.kind not in "iu" or np.any(value < 0):
                raise ValueError("Availability clocks must be nonnegative integer microseconds")
        if np.any(self.label_av != self.d + 7 * DAY_US + LATENCY_US):
            raise ValueError("Label clock differs from the supplied seven-day maturity contract")
        if not self.eligible[:, self.cash].all():
            raise ValueError("CASH targets must remain observable")
        if not np.all(self.targets[:, self.cash] == 0) or not np.all(
            self.y[self.complete[:, self.cash], self.cash] == 0
        ):
            raise ValueError("CASH targets and utility must be exactly zero")
        if not np.all(self.raw[:, self.cash] == 0):
            raise ValueError("CASH raw targets must be zero")
        known = self.eligible
        if np.any(self.target_av[known] > np.broadcast_to(self.d[:, None], (t, e))[known]):
            raise ValueError("An eligible target is not available at the decision")
        if not np.isfinite(self.targets[known]).all() or not np.isfinite(self.raw[known]).all():
            raise ValueError("Eligible target vectors must be finite")
        if not np.isfinite(self.y[self.complete]).all():
            raise ValueError("Complete utility labels must be finite")
        if np.any(np.abs(self.targets[known]).sum(axis=1) > 0.6 + 1e-12):
            raise ValueError("Individual expert gross exceeds 60%")
        if np.any(np.abs(self.targets[known]) > 0.3 + 1e-12):
            raise ValueError("Individual expert underlier exceeds 30%")
        self.rank_valid = np.ones(t, bool)
        self.learned_admission = {}

    def validate_rank(self, path):
        learned = tuple(self.binding.get("learned_experts", ()))
        if not learned:
            return
        if not set(learned) <= set(self.names):
            raise ValueError("Unknown learned expert identity")
        if not any(self.eligible[:, self.names.index(name)].any() for name in learned):
            self.rank_valid[:] = False
            self.learned_admission = {
                name: "NOT_ADMITTED_NO_OBSERVED_CAUSAL_TARGETS" for name in learned
            }
            return
        if not path:
            raise ValueError("Learned experts require explicit causal model/scaler provenance")
        p = load_npz(path)
        if not np.array_equal(p["decision_us"], self.d):
            raise ValueError("Rank provenance calendar mismatch")
        names = strings(p["expert_order"], "provenance expert_order")
        if set(names) != set(learned) or not set(learned) <= set(self.names):
            raise ValueError("Exact learned expert provenance identities required")
        valid = np.asarray(p["prediction_valid"])
        if valid.shape != (len(self.d), len(names)) or valid.dtype != bool:
            raise ValueError("Explicit learned prediction validity required")
        fields = (
            "fit_completed_us",
            "train_cutoff_us",
            "maximum_training_label_available_us",
            "maximum_scaler_source_available_us",
            "model_sha256",
            "scaler_sha256",
        )
        if any(p[k].shape != valid.shape for k in fields):
            raise ValueError("One model/scaler receipt per learned prediction required")
        for j, name in enumerate(names):
            use = valid[:, j]
            k = self.names.index(name)
            if np.any(self.eligible[:, k] & ~use):
                raise ValueError("Eligible learned target lacks a causal prediction receipt")
            if use.any():
                RankProvenance(
                    *(p[f][use, j] for f in fields[:4]),
                    tuple(str(x) for x in p["model_sha256"][use, j]),
                    tuple(str(x) for x in p["scaler_sha256"][use, j]),
                ).validate(self.d[use])
            self.rank_valid &= use

    def state_features(self):
        """Past strategy feedback and known multi-coin targets; no fake market bars."""
        t, e, _ = self.targets.shape
        x = np.full((t, e * (5 + len(self.symbols))), np.nan)
        f_av, r_av = np.zeros(t, np.int64), np.zeros(t, np.int64)
        names = []
        for expert in self.names:
            names.extend(
                f"{expert}:{k}" for k in ("mean7", "mean30", "std30", "downside30", "gross")
            )
            names.extend(f"{expert}:target:{s}" for s in self.symbols)
        for i, decision in enumerate(self.d):
            values = []
            for j in range(e):
                known = np.flatnonzero(
                    (self.d < decision)
                    & (self.feedback_av[:, j] < decision)
                    & np.isfinite(self.feedback[:, j])
                )[-30:]
                if (
                    len(known) != 30
                    or np.any(np.diff(self.d[known]) != DAY_US)
                    or not self.eligible[i, j]
                ):
                    break
                r = self.feedback[known, j]
                values.extend(
                    (
                        float(r[-7:].mean()),
                        float(r.mean()),
                        float(r.std()),
                        float(np.sqrt(np.square(np.minimum(r, 0)).mean())),
                        float(np.abs(self.targets[i, j]).sum()),
                    )
                )
                values.extend(self.targets[i, j].tolist())
                f_av[i] = max(f_av[i], int(self.target_av[i, j]))
                r_av[i] = max(r_av[i], int(self.feedback_av[known, j].max()))
            if len(values) == x.shape[1]:
                x[i] = values
        return x, tuple(names), f_av, r_av


def feature_inputs(panel, path, state_only):
    x, names, f_av, r_av = panel.state_features()
    mode = "STRATEGY_STATE_ONLY_CONTROL"
    if path:
        p = load_npz(path)
        market = np.asarray(p["X"], float)
        if (
            not np.array_equal(p["decision_us"], panel.d)
            or market.ndim != 2
            or len(market) != len(x)
        ):
            raise ValueError("External feature calendar/shape mismatch")
        columns = strings(p["feature_names"], "feature_names")
        av = clock(p["feature_available_us"], "feature_available_us")
        if len(columns) != market.shape[1] or av.shape != panel.d.shape or np.any(av > panel.d):
            raise ValueError("External features have wrong identities or future availability")
        x = np.column_stack((market, x))
        names = tuple("market:" + n for n in columns) + names
        f_av = np.maximum(f_av, av)
        mode = "MARKET_AND_STRATEGY_STATE"
    elif not state_only:
        raise ValueError("Provide --features, or explicitly select --state-only control")
    return dict(x=x, names=names, feature_av=f_av, feedback_av=r_av, mode=mode)


def validate_binding(binding, panel, mode):
    expected = {
        "initial_usdt": 10000,
        "one_way_cost_bps": 13.5,
        "terminal_exit_paid": True,
        "label_horizon_days": 7,
        "label_latency_us": LATENCY_US,
        "utility_definition": "log1p_net_return_minus_0.5_daily_reference_mdd",
    }
    for k, value in expected.items():
        if binding.get(k) != value:
            raise ValueError(f"Producer binding {k} differs from supplied economics contract")
    role = binding.get("dataset_role")
    if (mode == "synthetic") != (role == "SYNTHETIC_ENGINEERING"):
        raise ValueError("Synthetic/market execution role mismatch")
    if mode == "market" and role != "SEEN_DEVELOPMENT":
        raise ValueError("Existing evaluation periods must be labelled SEEN_DEVELOPMENT")
    sources = binding.get("expert_source_specs", {})
    if set(sources) != set(panel.names) or "learned_experts" not in binding:
        raise ValueError("Exact source specs and learned expert declarations required")
    for value in sources.values():
        if (
            not isinstance(value, str)
            or len(value) != 64
            or any(c not in "0123456789abcdef" for c in value)
        ):
            raise ValueError("Exact producer expert source SHA256 required")


def net_targets(panel, rows, weights, eligible):
    """Reuse core combiner on contiguous blocks of actually observable experts."""
    if weights.shape != eligible.shape or np.any(weights[~eligible] != 0):
        raise ValueError("Unavailable expert retains nonzero budget")
    frames_out, gross, asset_gross = [], [], []
    begin = 0
    while begin < len(rows):
        end = begin + 1
        while end < len(rows) and np.array_equal(eligible[end], eligible[begin]):
            end += 1
        experts = np.flatnonzero(eligible[begin])
        selected = rows[begin:end]
        names = tuple(panel.names[k] for k in experts)
        frames = {}
        for k, name in zip(experts, names, strict=True):
            frames[name] = pl.DataFrame(
                [
                    dict(
                        available_us=int(panel.d[i]),
                        symbol=s,
                        target_weight=float(panel.targets[i, k, a]),
                        raw_signed_target=float(panel.raw[i, k, a]),
                        mode="LONG_SHORT",
                        eligibility_reason="ELIGIBLE",
                    )
                    for i in selected
                    for a, s in enumerate(panel.symbols)
                ]
            )
        result, proof = shared_targets(
            frames, names, panel.d[selected], panel.symbols, weights[begin:end][:, experts]
        )
        frames_out.append(result)
        gross.extend(proof["allocated_leg_gross"])
        asset_gross.extend(proof["allocated_underlier_gross"])
        begin = end
    return pl.concat(frames_out), np.asarray(gross), np.asarray(asset_gross)


def static_scores(desired, days):
    scores = np.full(len(desired), -1000.0)
    positive = desired > 0
    scores[positive] = np.log(desired[positive])
    return np.tile(scores, (days, 1))


def controls(panel, train, binding):
    e = len(panel.names)
    cash = np.zeros(e)
    cash[panel.cash] = 1
    out = {"CASH": cash}
    if len(train):
        best = int(np.argmax(panel.y[train].mean(axis=0)))
        out["TRAIN_BEST_SINGLE"] = np.eye(e)[best]
    groups = sorted(set(panel.mechanisms[k] for k in range(e) if k != panel.cash))
    equal = np.zeros(e)
    for group in groups:
        ids = [k for k in range(e) if k != panel.cash and panel.mechanisms[k] == group]
        equal[ids] = 1 / (len(groups) * len(ids))
    out["FAMILY_EW"] = equal if groups else cash.copy()
    refs = binding.get("control_experts", {})
    missing = {}
    for label in ("SMA_ALONE", "CSMOM_ALONE", "RANK_ALONE"):
        expert = refs.get(label)
        if expert in panel.names:
            out[label] = np.eye(e)[panel.names.index(expert)]
        else:
            missing[label] = "Required registered expert is absent"
    if "SMA_ALONE" in out and "CSMOM_ALONE" in out:
        out["FIXED_HALF_SMA_CSMOM"] = (out["SMA_ALONE"] + out["CSMOM_ALONE"]) / 2
    else:
        missing["FIXED_HALF_SMA_CSMOM"] = "Required SMA/CSMOM controls are absent"
    return out, missing


def _fit_worker(args, result_path):
    # Spawned sequentially; parent enforces a hard wall bound including imports.
    import joblib
    from threadpoolctl import threadpool_limits

    started = time.monotonic()
    try:
        with threadpool_limits(limits=1):
            model = UtilitySelector(args.pop("family"), seed=20261008).fit(**args)
        joblib.dump(model, result_path, compress=3)
        json_write(
            str(result_path) + ".result.json",
            {
                "status": "COMPLETE",
                "wall_seconds": time.monotonic() - started,
            },
        )
    except Exception as exc:
        json_write(
            str(result_path) + ".result.json",
            {
                "status": "FAILED",
                "error": type(exc).__name__ + ": " + str(exc),
            },
        )


def fit_bounded(args, path, timeout):
    temp = Path(str(path) + ".partial")
    receipt = Path(str(temp) + ".result.json")
    process = mp.get_context("spawn").Process(target=_fit_worker, args=(args, temp))
    started = time.monotonic()
    process.start()
    process.join(max(0, timeout - (time.monotonic() - started)))
    if process.is_alive():
        process.terminate()
        process.join(5)
        if process.is_alive():
            process.kill()
            process.join()
        temp.unlink(missing_ok=True)
        raise TimeoutError("Finite selector fit budget exhausted")
    if not receipt.exists():
        raise RuntimeError(f"Selector worker exited {process.exitcode} without a receipt")
    result = json.loads(receipt.read_text())
    receipt.unlink()
    if result["status"] != "COMPLETE" or process.exitcode != 0:
        temp.unlink(missing_ok=True)
        raise RuntimeError(result.get("error", "Selector worker failed"))
    os.replace(temp, path)
    return time.monotonic() - started


def versions():
    import sklearn

    return dict(python=platform.python_version(), numpy=np.__version__, sklearn=sklearn.__version__)


def model_load(path, receipt):
    import joblib

    if sha(path) != receipt["model_sha256"] or versions() != receipt["versions"]:
        raise ValueError("Checkpoint hash or numerical environment differs from saved fit")
    return joblib.load(path)  # Own locally created checkpoint; never an untrusted input.


def source_hashes():
    root = Path(__file__).resolve().parents[2]
    return {
        name: sha(root / name)
        for name in (
            "scripts/research/run_conditional_selector.py",
            "scripts/research/conditional_selector_core.py",
            "scripts/investment/frozen_expert_mixture.py",
            "scripts/investment/regime_ranking_screen.py",
        )
    }


def export(panel, feat, rows, folder, scores, scale, *, valid, checkpoint=None, fixed_weights=None):
    folder.mkdir()
    eligibility = panel.eligible[rows].copy()
    eligibility[~valid] = False
    eligibility[:, panel.cash] = True
    if fixed_weights is not None:
        # Fixed controls retain their registered allocation. Unavailable shares
        # become CASH, never a different expert or a renormalized risk position.
        desired = np.tile(fixed_weights, (len(rows), 1))
        released = np.where(eligibility, 0, desired).sum(axis=1)
        desired[~eligibility] = 0
        desired[:, panel.cash] += released
        scores = np.full_like(desired, -1000.0)
        positive = desired > 0
        scores[positive] = np.log(desired[positive])
    usable = np.where(np.isfinite(scores), scores, 0)
    weights, budget_proof = budget_path(usable, scale, cash_index=panel.cash, eligible=eligibility)
    frame, gross, asset_gross = net_targets(panel, rows, weights, eligibility)
    frame.write_parquet(folder / "targets.parquet")
    np.savez_compressed(
        folder / "predictions.npz",
        decision_us=panel.d[rows],
        expert_order=np.asarray(panel.names),
        symbol_order=np.asarray(panel.symbols),
        prediction=scores,
        prediction_valid=valid,
        budgets=weights,
        target_eligible=eligibility,
        allocated_leg_gross=gross,
        allocated_underlier_gross=asset_gross,
        net_targets=frame["target_weight"].to_numpy().reshape(len(rows), -1),
    )
    meta = dict(
        status="TARGETS_EXPORTED_SHARED_WALLET_NOT_RUN",
        rows=len(rows),
        feature_mode=feat["mode"],
        feature_unavailable_cash_days=int((~valid).sum()),
        mean_budget=weights.mean(axis=0).tolist(),
        maximum_allocated_gross=float(gross.max()),
        budget_proof=budget_proof,
        initial_usdt=10000,
        gross_cap=0.6,
        underlier_cap=0.3,
        isolated_leverage=1,
        auto_add_margin=False,
        cash_start=True,
        economic_performance="NOT_COMPUTED",
        profits_from_independent_experts_added=False,
        checkpoint=checkpoint,
    )
    if checkpoint:
        complete = panel.complete[rows].all(axis=1) & valid & np.isfinite(panel.y[rows]).all(axis=1)
        if complete.any():
            error = scores[complete] - panel.y[rows][complete]
            meta["label_prediction_diagnostic"] = dict(
                rows=int(complete.sum()),
                mse=float(np.square(error).mean()),
                mae=float(np.abs(error).mean()),
                overlapping_labels=True,
                role="FORECAST_DIAGNOSTIC_NOT_PORTFOLIO_RETURN",
            )
    meta["artifacts"] = {
        name: sha(folder / name) for name in ("targets.parquet", "predictions.npz")
    }
    json_write(folder / "result.json", meta)
    return meta


def schedule_load(path):
    folds = (
        json.loads(Path(path).read_text())
        if path
        else [dict(name=n, start=s, end=e) for n, s, e in DEFAULT_FOLDS]
    )
    if not isinstance(folds, list) or not 1 <= len(folds) <= 4:
        raise ValueError("At most four finite chronological folds required")
    prior = -1
    names = set()
    for fold in folds:
        name = fold["name"]
        start, end = date_us(fold["start"]), date_us(fold["end"])
        if (
            not isinstance(name, str)
            or not name.replace("_", "").isalnum()
            or name in names
            or start < prior
            or end <= start
        ):
            raise ValueError("Unique safe names and ordered nonoverlapping folds required")
        fold["start_us"], fold["end_us"] = start, end
        names.add(name)
        prior = end
    return folds


def run(args):
    binding = json.loads(Path(args.binding).read_text())
    panel = Panel(args.input, binding)
    validate_binding(binding, panel, args.mode)
    panel.validate_rank(args.rank_provenance)
    feat = feature_inputs(panel, args.features, args.state_only)
    folds = schedule_load(args.schedule)
    if int(binding["pool_selection_available_us"]) > folds[0]["start_us"]:
        raise ValueError("Expert pool selection occurs after the first validation start")
    sources = source_hashes()
    run_id = dict(
        input_sha256=panel.input_sha,
        binding_sha256=sha(args.binding),
        features_sha256=sha(args.features) if args.features else None,
        provenance_sha256=sha(args.rank_provenance) if args.rank_provenance else None,
        folds=folds,
        mode=args.mode,
        operation=args.operation,
        feature_mode=feat["mode"],
        sources=sources,
        expert_order=panel.names,
        symbol_order=panel.symbols,
        feature_order=feat["names"],
        seed=20261008,
        versions=versions(),
    )
    # JSON normalization makes saved/reloaded tuples identical.
    run_id = json.loads(json.dumps(run_id))
    output = Path(args.output).resolve()
    if output.exists():
        if not args.resume or not (output / "run.json").exists():
            raise ValueError("Output exists; explicit --resume with matching bindings required")
        ledger = json.loads((output / "run.json").read_text())
        if ledger["identity"] != run_id:
            raise ValueError("Resume input/protocol/source/environment identity mismatch")
    else:
        output.mkdir(parents=True)
        ledger = dict(
            identity=run_id,
            status="RUNNING",
            folds=[],
            fits_attempted=0,
            fit_wall_seconds=0.0,
            maximum_fits=8,
            maximum_fit_wall_seconds=1200,
        )
    available_features = np.isfinite(feat["x"]).all(axis=1)
    complete = panel.complete.all(axis=1) & np.isfinite(panel.y).all(axis=1)
    complete &= panel.eligible.all(axis=1) & available_features & panel.rank_valid
    stopped = ledger["status"] == "FAILED_FIT_STOPPED" or any(
        model["status"] == "FAILED_FIT"
        for fold in ledger["folds"]
        for model in fold["models"].values()
    )
    for fold in folds:
        folder = output / fold["name"]
        if folder.exists() and (folder / "fold.json").exists():
            continue
        if folder.exists():
            raise ValueError(
                "Incomplete fold retained; recover checkpoints with replay, or use a new output"
            )
        rows = np.flatnonzero((panel.d >= fold["start_us"]) & (panel.d < fold["end_us"]))
        mask = chronological_training_mask(panel.d, panel.label_av, complete, fold["start_us"], 7)
        independent = nonoverlap_indices(panel.d, panel.label_av, mask)
        record = dict(
            name=fold["name"],
            start_us=fold["start_us"],
            end_us=fold["end_us"],
            role=binding["dataset_role"],
            mature_daily_rows=int(mask.sum()),
            disjoint_training_rows=len(independent),
            cutoff_us=fold["start_us"] - 7 * DAY_US,
            models={},
            controls={},
        )
        record["expert_admission"] = [
            dict(
                expert=name,
                observed_target_days_before_score=int(
                    (panel.eligible[:, k] & (panel.d < fold["start_us"])).sum()
                ),
                mature_label_days_before_embargo=int(
                    (
                        panel.complete[:, k]
                        & np.isfinite(panel.y[:, k])
                        & (panel.label_av < record["cutoff_us"])
                    ).sum()
                ),
                status=(
                    "ADMITTED_TO_DECLARED_COMMON_POOL"
                    if (
                        panel.complete[:, k]
                        & panel.eligible[:, k]
                        & (panel.label_av < record["cutoff_us"])
                    ).any()
                    else "NOT_ADMITTED_NO_MATURE_OBSERVED_TARGETS"
                ),
            )
            for k, name in enumerate(panel.names)
        ]
        folder.mkdir()
        np.savez_compressed(
            folder / "split.npz",
            train_mask=mask,
            training_indices=independent,
            score_indices=rows,
            decision_us=panel.d,
            label_available_us=panel.label_av,
        )
        if not len(rows):
            record["status"] = "NOT_RUN_NO_SCORE_DATA"
        else:
            record["partial_score_window"] = bool(
                panel.d[rows[0]] != fold["start_us"] or panel.d[rows[-1]] + DAY_US != fold["end_us"]
            )
            fixed, missing = controls(panel, independent, binding)
            record["controls_not_run"] = missing
            valid = np.ones(len(rows), bool)
            for name, desired in fixed.items():
                record["controls"][name] = export(
                    panel,
                    feat,
                    rows,
                    folder / name,
                    static_scores(desired, len(rows)),
                    1.0,
                    valid=valid,
                    fixed_weights=desired,
                )
            for family in FAMILIES:
                minimum = 40 if family == "RIDGE" else 80
                if len(independent) < minimum:
                    record["models"][family] = dict(
                        status="NOT_ADMITTED",
                        reason="INSUFFICIENT_DISJOINT_SUPPORT",
                        required=minimum,
                        actual=len(independent),
                    )
                    continue
                if args.operation == "preflight":
                    record["models"][family] = dict(
                        status="PREFLIGHT_READY_NO_FIT", required=minimum, actual=len(independent)
                    )
                    continue
                remaining = 1200 - ledger["fit_wall_seconds"]
                if stopped or ledger["fits_attempted"] >= 8 or remaining <= 0:
                    record["models"][family] = dict(status="NOT_RUN_BUDGET_EXHAUSTED")
                    continue
                model_path = folder / (family + ".joblib")
                ledger["fits_attempted"] += 1
                json_write(output / "run.json", ledger)
                started = time.monotonic()
                try:
                    elapsed = fit_bounded(
                        dict(
                            family=family,
                            x=feat["x"],
                            net_risk_utility=panel.y,
                            decisions=panel.d,
                            label_available=panel.label_av,
                            train_mask=mask,
                            cutoff_us=record["cutoff_us"],
                            fit_available_us=fold["start_us"],
                            feature_available_us=feat["feature_av"],
                            feedback_available_us=feat["feedback_av"],
                        ),
                        model_path,
                        min(150, remaining),
                    )
                except (RuntimeError, TimeoutError) as exc:
                    elapsed = time.monotonic() - started
                    record["models"][family] = dict(status="FAILED_FIT", error=str(exc))
                    stopped = True
                    ledger["fit_wall_seconds"] += elapsed
                    json_write(output / "run.json", ledger)
                    continue
                ledger["fit_wall_seconds"] += elapsed
                receipt = dict(
                    model_sha256=sha(model_path),
                    versions=versions(),
                    family=family,
                    seed=20261008,
                    input_sha256=panel.input_sha,
                    train_indices=independent.tolist(),
                    cutoff_us=record["cutoff_us"],
                    fit_available_us=fold["start_us"],
                    feature_order=feat["names"],
                    maximum_training_label_available_us=int(panel.label_av[independent].max()),
                )
                json_write(folder / (family + ".model.json"), receipt)
                model = model_load(model_path, receipt)
                score_valid = available_features[rows] & panel.rank_valid[rows]
                prediction = np.full((len(rows), len(panel.names)), np.nan)
                if score_valid.any():
                    indices = rows[score_valid]
                    prediction[score_valid] = model.predict(
                        feat["x"][indices],
                        panel.d[indices],
                        feature_available_us=feat["feature_av"][indices],
                        feedback_available_us=feat["feedback_av"][indices],
                    )
                record["models"][family] = export(
                    panel,
                    feat,
                    rows,
                    folder / family,
                    prediction,
                    model.utility_scale,
                    valid=score_valid,
                    checkpoint=receipt,
                )
                json_write(output / "run.json", ledger)
            record["status"] = "TARGETS_EXPORTED_SHARED_WALLET_NOT_RUN"
        json_write(folder / "fold.json", record)
        ledger["folds"].append(record)
        json_write(output / "run.json", ledger)
        print(
            json.dumps(
                dict(
                    fold=fold["name"],
                    status=record["status"],
                    disjoint_rows=len(independent),
                    fits_attempted=ledger["fits_attempted"],
                )
            ),
            flush=True,
        )
    ledger["status"] = (
        "FAILED_FIT_STOPPED"
        if stopped
        else "PREFLIGHT_NO_FIT"
        if args.operation == "preflight"
        else "COMPLETE_ENGINEERING_AND_TARGET_EXPORT"
    )
    ledger["economic_performance"] = "NOT_RUN_REQUIRES_SHARED_WALLET"
    json_write(output / "run.json", ledger)
    return ledger


def replay(args):
    run_path = Path(args.run).resolve()
    ledger = json.loads((run_path / "run.json").read_text())
    binding = json.loads(Path(args.binding).read_text())
    panel = Panel(args.input, binding)
    validate_binding(binding, panel, args.mode)
    panel.validate_rank(args.rank_provenance)
    feat = feature_inputs(panel, args.features, args.state_only)
    identity = ledger["identity"]
    checks = dict(
        input_sha256=panel.input_sha,
        binding_sha256=sha(args.binding),
        features_sha256=sha(args.features) if args.features else None,
        provenance_sha256=sha(args.rank_provenance) if args.rank_provenance else None,
        feature_mode=feat["mode"],
        mode=args.mode,
    )
    if any(identity[k] != v for k, v in checks.items()):
        raise ValueError("Replay input/protocol identity differs from training")
    if identity["sources"] != source_hashes() or identity["feature_order"] != list(feat["names"]):
        raise ValueError("Replay source or feature identity differs from training")
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=False)
    restored = []
    for fold in identity["folds"]:
        rows = np.flatnonzero((panel.d >= fold["start_us"]) & (panel.d < fold["end_us"]))
        for family in FAMILIES:
            receipt_path = run_path / fold["name"] / (family + ".model.json")
            if not receipt_path.exists():
                continue
            receipt = json.loads(receipt_path.read_text())
            model = model_load(receipt_path.with_name(family + ".joblib"), receipt)
            valid = np.isfinite(feat["x"][rows]).all(axis=1) & panel.rank_valid[rows]
            prediction = np.full((len(rows), len(panel.names)), np.nan)
            if valid.any():
                indices = rows[valid]
                prediction[valid] = model.predict(
                    feat["x"][indices],
                    panel.d[indices],
                    feature_available_us=feat["feature_av"][indices],
                    feedback_available_us=feat["feedback_av"][indices],
                )
            meta = export(
                panel,
                feat,
                rows,
                output / (fold["name"] + "_" + family),
                prediction,
                model.utility_scale,
                valid=valid,
                checkpoint=receipt,
            )
            restored.append(dict(fold=fold["name"], family=family, result=meta))
    json_write(
        output / "replay.json",
        dict(status="RESTORED_WITHOUT_FIT", identity=identity, restored=restored),
    )
    return restored


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("operation", choices=("preflight", "train", "replay"))
    parser.add_argument("--input", required=True, help="Main-thread SELECTOR_INPUTS.npz")
    parser.add_argument(
        "--binding", required=True, help="Producer economics/source/pool binding JSON"
    )
    parser.add_argument("--features", help="Same-calendar X/feature_names/feature_available_us NPZ")
    parser.add_argument(
        "--rank-provenance", help="Causal per-learned-expert model/scaler receipt NPZ"
    )
    parser.add_argument(
        "--state-only", action="store_true", help="Explicit strategy-state-only control"
    )
    parser.add_argument("--mode", choices=("synthetic", "market"), required=True)
    parser.add_argument(
        "--schedule",
        help="At most four ordered name/start/end folds; default preregistered half-years",
    )
    parser.add_argument(
        "--output", required=True, help="New state directory; preserves failed/negative results"
    )
    parser.add_argument(
        "--resume", action="store_true", help="Skip complete folds only under identical bindings"
    )
    parser.add_argument(
        "--run", help="Existing run directory for checkpoint replay without fitting"
    )
    args = parser.parse_args()
    if args.operation == "replay" and not args.run:
        parser.error("replay requires --run")
    if args.operation in ("preflight", "train"):
        result = run(args)
        if result["status"] == "FAILED_FIT_STOPPED":
            raise SystemExit(1)
    else:
        replay(args)


if __name__ == "__main__":
    main()
