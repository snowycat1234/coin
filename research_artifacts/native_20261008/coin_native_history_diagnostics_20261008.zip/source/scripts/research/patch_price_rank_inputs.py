"""Bounded new daily-archive inputs for the frozen CPU price-rank replication."""

from __future__ import annotations

import csv
import hashlib
import io
import json
import shutil
import time
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd
import requests

from modules.collector_research.pipeline.make_labels import BASE_FEATURES, feature_frame
from modules.collector_research.pipeline.normalize import funding_windows
from modules.collector_research.pipeline.train import market_features
from modules.transformer_v2.data import causal_future_targets

DAY_US = 86_400_000_000
START = pd.Timestamp("2022-01-01", tz="UTC")
END = pd.Timestamp("2024-08-11", tz="UTC")
CUTOFF = pd.Timestamp("2024-05-02", tz="UTC")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(".tmp")
    temp.write_text(json.dumps(data, indent=2, allow_nan=False) + "\n")
    temp.replace(path)


def guard(state, deadline, budget):
    if time.monotonic() >= deadline:
        raise TimeoutError("Fixed overall1800s execution deadline reached")
    if shutil.disk_usage(state).free < budget["minimum_free_bytes"]:
        raise RuntimeError("15GiB free disk floor reached")
    total = sum(p.stat().st_size for p in Path(state).rglob("*") if p.is_file())
    if total > budget["added_data_bytes"]:
        raise RuntimeError("500MB added-data bound reached")


def parse_price_row(row):
    # Inspect the time BEFORE parsing any price/volume, discarding out-of-slice values.
    stamp = int(row[0])
    if stamp < START.value // 1_000_000 or stamp >= (END + pd.Timedelta(days=1)).value // 1_000_000:
        return None
    if stamp % 86_400_000 or len(row) != 12 or int(row[6]) != stamp + 86_400_000 - 1:
        raise ValueError("Official UTC1d millisecond interval identity required")
    values = np.asarray([float(row[i]) for i in (1, 2, 3, 4, 5, 7)], dtype=float)
    if not np.isfinite(values).all():
        raise ValueError("Nonfinite completed daily source row")
    return dict(
        dt=pd.Timestamp(stamp, unit="ms", tz="UTC"),
        open=values[0],
        high=values[1],
        low=values[2],
        close=values[3],
        volume=values[4],
        quote_volume=values[5],
    )


def read_archive(path, family):
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        if names != [path.name.removesuffix(".zip") + ".csv"] or z.testzip() is not None:
            raise ValueError("Wrong CSV member or CRC failure")
        with z.open(names[0]) as raw:
            reader = csv.reader(io.TextIOWrapper(raw, encoding="utf-8-sig"))
            header = next(reader)
            rows = []
            if family == "fundingRate":
                if header != ["calc_time", "funding_interval_hours", "last_funding_rate"]:
                    raise ValueError("Original funding archive clock/schema required")
                for row in reader:
                    stamp = int(row[0])
                    if (
                        not START.value // 1_000_000
                        <= stamp
                        < (END + pd.Timedelta(days=1)).value // 1_000_000
                    ):
                        continue
                    interval, rate = float(row[1]), float(row[2])
                    if not np.isfinite([interval, rate]).all() or not 0 < interval <= 24:
                        raise ValueError("Funding interval/rate invalid; no zero imputation")
                    rows.append(
                        dict(
                            calc_time_ms=stamp,
                            funding_interval_hours=interval,
                            last_funding_rate=rate,
                            past_mark_price=np.nan,
                        )
                    )
            else:
                if header[0] not in ("open_time", "openTime"):
                    # Some official premium archives have no header.
                    value = parse_price_row(header)
                    if value is not None:
                        rows.append(value)
                for row in reader:
                    value = parse_price_row(row)
                    if value is not None:
                        rows.append(value)
            return rows


def fetch_inputs(protocol_path, metadata_path, state, deadline):
    protocol = json.loads(Path(protocol_path).read_text())
    metadata = json.loads(Path(metadata_path).read_text())
    if (
        metadata["status"] != "PASS_METADATA_BUDGET_ONLY"
        or metadata["protocol_sha256"] != sha(protocol_path)
        or metadata["exact_listed_download_body_bytes"] > protocol["budget"]["download_body_bytes"]
    ):
        raise ValueError("Frozen official metadata budget/identity required")
    session = requests.Session()
    session.headers["User-Agent"] = "coin-bounded-price-rank-replication/20261008"
    records, prices, premiums, events = [], {}, {}, {}
    for symbol in protocol["assets"]["input_order"]:
        prices[symbol], premiums[symbol], events[symbol] = [], [], []
    downloaded = 0
    pairs = sorted(metadata["download_pairs"], key=lambda p: (p["symbol"], p["month"], p["family"]))
    for i, pair in enumerate(pairs):
        guard(state, deadline, protocol["budget"])
        key = pair["ZIP"]["key"]
        if not pair["CHECKSUM"] or not "2022-01" <= pair["month"] <= "2024-08":
            raise ValueError("Unregistered archive or missing official checksum")
        dest = Path(state) / "raw" / pair["family"] / pair["symbol"] / Path(key).name
        dest.parent.mkdir(parents=True, exist_ok=True)
        checksum = Path(str(dest) + ".CHECKSUM")
        for obj, path in ((pair["CHECKSUM"], checksum), (pair["ZIP"], dest)):
            if path.exists() and path.stat().st_size == obj["bytes"]:
                continue
            guard(state, deadline, protocol["budget"])
            url = "https://data.binance.vision/" + obj["key"]
            response = session.get(url, timeout=(5, 10), allow_redirects=False)
            if response.status_code != 200:
                raise RuntimeError(
                    f"Official body request blockedHTTP{response.status_code}: {url}"
                )
            if len(response.content) != obj["bytes"]:
                raise ValueError("Declared official size changed after metadata freeze")
            downloaded += len(response.content)
            if downloaded > protocol["budget"]["download_body_bytes"]:
                raise RuntimeError("200MB body-byte budget reached")
            path.write_bytes(response.content)
        fields = checksum.read_text().strip().split()
        if len(fields) != 2 or fields[1].lstrip("*") != dest.name or fields[0].lower() != sha(dest):
            raise ValueError("Official checksum mismatch; preserve failed input")
        rows = read_archive(dest, pair["family"])
        container = (
            events
            if pair["family"] == "fundingRate"
            else prices
            if pair["family"] == "klines"
            else premiums
        )
        container[pair["symbol"]].extend(rows)
        records.append(
            dict(
                symbol=pair["symbol"],
                family=pair["family"],
                month=pair["month"],
                path=str(dest),
                bytes=dest.stat().st_size,
                sha256=sha(dest),
                numerical_rows=len(rows),
            )
        )
        if (i + 1) % 10 == 0 or i + 1 == len(pairs):
            save(
                Path(state) / "progress.json",
                dict(
                    stage="DOWNLOAD_PARSE_DAILY_INPUTS",
                    completed=i + 1,
                    total=len(pairs),
                    downloaded_body_bytes=downloaded,
                    seconds_remaining=max(0, deadline - time.monotonic()),
                ),
            )
            print(f"INPUTS {i + 1}/{len(pairs)} bytes={downloaded}", flush=True)
    dates = pd.date_range(START, END, tz="UTC")
    frames = {}
    for symbol in protocol["assets"]["input_order"]:
        frame = pd.DataFrame(index=dates)
        one = pd.DataFrame(prices[symbol])
        if not one.empty:
            if (
                one.dt.duplicated().any()
                or (one[["open", "high", "low", "close"]] <= 0).any().any()
            ):
                raise ValueError("Duplicate or nonpositive daily trade observations")
            one = one.set_index("dt").reindex(dates)
            for col in ("open", "high", "low", "close", "volume", "quote_volume"):
                frame[col] = one[col]
        else:
            for col in ("open", "high", "low", "close", "volume", "quote_volume"):
                frame[col] = np.nan
        frame["complete_kline"] = frame.close.notna()
        premium = pd.DataFrame(premiums[symbol])
        if not premium.empty and premium.dt.duplicated().any():
            raise ValueError("Duplicate premium observations")
        frame["premium"] = (
            premium.set_index("dt").close.reindex(dates) if not premium.empty else np.nan
        )
        frame["complete_premium"] = frame.premium.notna()
        funds = pd.DataFrame(
            events[symbol],
            columns=[
                "calc_time_ms",
                "funding_interval_hours",
                "last_funding_rate",
                "past_mark_price",
            ],
        )
        if not funds.empty:
            funds = funds.sort_values("calc_time_ms")
            if funds.calc_time_ms.duplicated().any():
                raise ValueError("Duplicate funding event clock")
        f = funding_windows(funds, dates)
        frame["funding"] = f.funding
        frame["complete_funding"] = f.complete_funding
        frame["symbol"] = symbol
        frame.index.name = "dt"
        frame = frame.reset_index()
        frames[symbol] = feature_frame(frame, 256)
        folder = Path(state) / "daily"
        folder.mkdir(exist_ok=True)
        frame.to_parquet(folder / (symbol + ".parquet"), index=False)
    market = market_features(frames).reset_index(drop=True)
    symbols = protocol["assets"]["input_order"]
    close = np.stack([frames[s].close.to_numpy(float) for s in symbols], axis=1)
    x = np.stack(
        [
            pd.concat([frames[s][BASE_FEATURES], market], axis=1).to_numpy("float32")
            for s in symbols
        ],
        axis=1,
    )
    ready = np.stack([frames[s].feature_ready.to_numpy(bool) for s in symbols], axis=1)
    relative, regime = causal_future_targets(close, ready)
    label_end = dates + pd.Timedelta(days=61) + pd.Timedelta(microseconds=60_000_001)
    core = np.array([s in protocol["assets"]["allocation_pool"] for s in symbols])
    mature = label_end < CUTOFF
    usable = (
        ready[:, core].all(axis=1)
        & np.isfinite(relative[:, core, :]).all(axis=(1, 2))
        & np.isfinite(regime).all(axis=1)
        & mature
    )
    train = np.flatnonzero(usable)
    if len(train) < 180 or np.min(train) < 255 or not (label_end[train] < CUTOFF).all():
        raise ValueError("Insufficient180 mature common training days; do not relax guards")
    decision_us = dates.as_unit("us").asi8 + DAY_US
    score = protocol["scope"]["score"]
    predict = np.flatnonzero(
        (decision_us >= score["start_us"]) & (decision_us < score["end_exclusive_us"])
    )
    if len(predict) != 41 or not ready[predict][:, core].all():
        raise ValueError("Frozen41day CORE5 inference readiness incomplete")
    np.savez_compressed(
        Path(state) / "INPUTS.npz",
        x=x,
        close=close,
        availability=np.isfinite(close),
        ready=ready,
        relative=relative,
        regime=regime,
        train_indices=train,
        predict_indices=predict,
        dates_us=dates.as_unit("us").asi8,
        label_end_us=label_end.as_unit("us").asi8,
        symbol_order=np.array(symbols),
        feature_order=np.array(BASE_FEATURES + list(market.columns)),
    )
    receipt = dict(
        status="COMPLETE_NEW_DAILY_INPUTS",
        protocol_sha256=sha(protocol_path),
        metadata_sha256=sha(metadata_path),
        source_script_sha256=sha(__file__),
        input_npz_sha256=sha(Path(state) / "INPUTS.npz"),
        archive_count=len(records),
        downloaded_body_bytes=downloaded,
        source_numerical_bounds=[str(START), str(END)],
        train_days=len(train),
        first_train_date=str(dates[train[0]]),
        last_train_date=str(dates[train[-1]]),
        max_training_label_end=str(label_end[train[-1]]),
        cutoff=str(CUTOFF),
        score_days=len(predict),
        symbol_order=symbols,
        feature_order=BASE_FEATURES + list(market.columns),
        records=records,
        raw_archive_later_August_values_discarded_before_numeric_parsing=True,
        old_teacher_restored=False,
        new_input_recipe_not_original_1440_minute_completeness=True,
    )
    save(Path(state) / "INPUT_RECEIPT.json", receipt)
    return receipt


if __name__ == "__main__":
    import argparse

    p = argparse.ArgumentParser()
    p.add_argument("--protocol", type=Path, required=True)
    p.add_argument("--metadata", type=Path, required=True)
    p.add_argument("--state", type=Path, required=True)
    a = p.parse_args()
    a.state.mkdir(parents=True, exist_ok=True)
    began = time.monotonic()
    protocol = json.loads(a.protocol.read_text())
    deadline = began + protocol["budget"]["overall_wall_seconds"]
    save(
        a.state / "RUN_BUDGET.json",
        dict(
            started_unix=time.time(),
            started_monotonic=began,
            deadline_monotonic=deadline,
            protocol_sha256=sha(a.protocol),
            metadata_sha256=sha(a.metadata),
            wall_seconds=1800,
            first_price_GET_not_before_this_receipt=True,
        ),
    )
    try:
        result = fetch_inputs(a.protocol, a.metadata, a.state, deadline)
        print(
            json.dumps(
                {
                    k: result[k]
                    for k in (
                        "status",
                        "archive_count",
                        "downloaded_body_bytes",
                        "train_days",
                        "score_days",
                        "max_training_label_end",
                    )
                }
            ),
            flush=True,
        )
    except BaseException as exc:
        save(
            a.state / "INPUT_FAILURE.json",
            dict(
                error_type=type(exc).__name__,
                error=str(exc),
                elapsed_seconds=time.monotonic() - began,
                source_numerical_end=str(END),
            ),
        )
        raise
