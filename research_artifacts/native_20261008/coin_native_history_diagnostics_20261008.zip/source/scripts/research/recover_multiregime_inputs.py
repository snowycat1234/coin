"""Bounded public sparse-economics recovery. No fits, wallets or silent gap fills."""

from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import math
import shutil
import time
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd
import requests

from modules.collector_research.pipeline.economics import interval_arrays
from modules.collector_research.pipeline.make_labels import BASE_FEATURES, feature_frame
from modules.collector_research.pipeline.normalize import funding_windows
from modules.collector_research.pipeline.train import market_features
from modules.transformer_v2.data import causal_future_targets

ROOT = Path(__file__).resolve().parents[2]
CORE = ("BTCUSDT", "ETHUSDT", "SOLUSDT", "XRPUSDT", "DOGEUSDT")
BASE = "https://data.binance.vision/"
BACKEND = "https://s3-ap-northeast-1.amazonaws.com/data.binance.vision"
DAY_MS = 86400000
DAY_US = DAY_MS * 1000
LIMIT_BYTES = 400000000
OWNED_BYTES = 250000000
RESERVE = 15 * 2**30
FUND_COLS = [
    "calc_time_ms",
    "funding_interval_hours",
    "last_funding_rate",
    "past_mark_price",
    "past_mark_available_us",
]


def sha(path):
    with Path(path).open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
    tmp.replace(path)


def month_limits(month):
    left = pd.Timestamp(month + "-01", tz="UTC")
    return left.value // 1000000, (left + pd.offsets.MonthBegin()).value // 1000000


def months(start, end):
    return [str(v)[:7] for v in pd.period_range(start, end, freq="M")]


def key_for(symbol, family, interval, month):
    stem = f"{symbol}-{interval}-{month}" if interval else f"{symbol}-fundingRate-{month}"
    middle = f"{symbol}/{interval}" if interval else symbol
    return f"data/futures/um/monthly/{family}/{middle}/{stem}.zip"


def verify_archive(path, expected_sha=None):
    path = Path(path)
    fields = Path(str(path) + ".CHECKSUM").read_text().strip().split()
    if len(fields) != 2 or fields[1].lstrip("*") != path.name or fields[0].lower() != sha(path):
        raise ValueError("Official SHA256 mismatch: " + str(path))
    if expected_sha and fields[0].lower() != expected_sha:
        raise ValueError("Frozen archive identity changed")
    with zipfile.ZipFile(path) as z:
        infos = z.infolist()
        if (
            len(infos) != 1
            or infos[0].filename != path.name[:-4] + ".csv"
            or infos[0].file_size > 128 * 2**20
            or z.testzip() is not None
        ):
            raise ValueError("Archive member/size/CRC invalid: " + str(path))
    return fields[0].lower()


def guarded_request(session, url, state, *, params=None, stream=False):
    for attempt in range(2):
        try:
            r = session.get(
                url, params=params, timeout=(15, 15), allow_redirects=False, stream=stream
            )
            if r.status_code == 200:
                return r
            raise requests.HTTPError(f"HTTP{r.status_code}: {r.url}", response=r)
        except (requests.RequestException, OSError) as exc:
            status = getattr(getattr(exc, "response", None), "status_code", None)
            with (state / "ERRORS.jsonl").open("a") as f:
                f.write(
                    json.dumps(
                        dict(
                            url=url,
                            attempt=attempt + 1,
                            error_type=type(exc).__name__,
                            error=str(exc),
                        )
                    )
                    + "\n"
                )
            transient = isinstance(exc, (requests.Timeout, requests.ConnectionError)) or status in (
                500,
                502,
                503,
                504,
            )
            if attempt or not transient:
                raise
            time.sleep(0.5)
    raise AssertionError("Unreachable")


def inventory():
    jobs = []
    starts = dict(
        BTCUSDT="2020-01",
        ETHUSDT="2020-01",
        XRPUSDT="2020-01",
        SOLUSDT="2020-09",
        DOGEUSDT="2020-07",
    )
    for s in CORE:
        for month in months(starts[s], "2021-12"):
            for family in ("klines", "premiumIndexKlines", "fundingRate"):
                interval = None if family == "fundingRate" else "1d"
                jobs.append(
                    dict(
                        symbol=s,
                        family=family,
                        interval=interval,
                        month=month,
                        key=key_for(s, family, interval, month),
                        role="DAILY_PREFIX",
                    )
                )
        for month in months("2022-01", "2023-12"):
            jobs.append(
                dict(
                    symbol=s,
                    family="klines",
                    interval="1m",
                    month=month,
                    key=key_for(s, "klines", "1m", month),
                    role="TRADE_ECONOMICS",
                )
            )
        for month in months("2021-12", "2023-12"):
            jobs.append(
                dict(
                    symbol=s,
                    family="markPriceKlines",
                    interval="1m",
                    month=month,
                    key=key_for(s, "markPriceKlines", "1m", month),
                    role="SPARSE_FUNDING_MARKS",
                )
            )
        for month in months("2022-01", "2023-12"):
            jobs.append(
                dict(
                    symbol=s,
                    family="fundingRate",
                    interval=None,
                    month=month,
                    key=key_for(s, "fundingRate", None, month),
                    role="REUSED_FUNDING_EVENTS",
                )
            )
    return jobs


def existing_path(job):
    if job["role"] == "TRADE_ECONOMICS" and job["month"] == "2023-12":
        return (
            Path("/workspace/shared/coin_2024H1_data/data/raw/klines")
            / job["symbol"]
            / Path(job["key"]).name
        )
    if job["role"] == "REUSED_FUNDING_EVENTS":
        return (
            Path("/workspace/shared/coin_ranker_price_state/raw/fundingRate")
            / job["symbol"]
            / Path(job["key"]).name
        )
    return None


def metadata(state):
    if (state / "PROTOCOL.json").exists():
        raise ValueError("Never overwrite frozen admission")
    state.mkdir(parents=True, exist_ok=True)
    if shutil.disk_usage(state).free < RESERVE:
        raise RuntimeError("15GiB reserve missing")
    session = requests.Session()
    jobs = inventory()
    reused = []
    new = []
    for job in jobs:
        local = existing_path(job)
        if local:
            digest = verify_archive(local)
            reused.append(
                dict(
                    job,
                    local_path=str(local),
                    sha256=digest,
                    bytes=local.stat().st_size,
                    checksum_bytes=Path(str(local) + ".CHECKSUM").stat().st_size,
                )
            )
        else:
            new.append(job)
    prefixes = sorted({j["key"].rsplit("/", 1)[0] + "/" for j in new})
    lookup = {}
    listing_refs = []
    ns = {"s": "http://s3.amazonaws.com/doc/2006-03-01/"}
    wanted = {j["key"] for j in new} | {j["key"] + ".CHECKSUM" for j in new}
    for index, prefix in enumerate(prefixes):
        token = None
        for page in range(2):
            params = {"list-type": "2", "prefix": prefix, "max-keys": 1000}
            if token:
                params["continuation-token"] = token
            response = guarded_request(session, BACKEND, state, params=params)
            raw = response.content
            dest = state / "listing_receipts" / f"{index:02d}-{page}.xml"
            dest.parent.mkdir(exist_ok=True)
            dest.write_bytes(raw)
            listing_refs.append(
                dict(path=str(dest.relative_to(state)), sha256=sha(dest), prefix=prefix)
            )
            xml = ET.fromstring(raw)
            for item in xml.findall("s:Contents", ns):
                key = item.findtext("s:Key", namespaces=ns)
                if key in wanted:
                    lookup[key] = dict(
                        key=key,
                        bytes=int(item.findtext("s:Size", namespaces=ns)),
                        etag=item.findtext("s:ETag", namespaces=ns),
                        last_modified=item.findtext("s:LastModified", namespaces=ns),
                    )
            if xml.findtext("s:IsTruncated", namespaces=ns) != "true":
                break
            token = xml.findtext("s:NextContinuationToken", namespaces=ns)
            if not token or page == 1:
                raise ValueError("Official listing incomplete under two-page guard")
        print(f"METADATA {index + 1}/{len(prefixes)}", flush=True)
    missing = sorted(wanted - lookup.keys())
    if missing:
        save(
            state / "ADMISSION_FAILURE.json",
            dict(status="MISSING_EXPECTED_OFFICIAL_OBJECT", missing=missing),
        )
        raise ValueError("Expected official objects absent; no recipe substitution")
    pairs = [dict(j, ZIP=lookup[j["key"]], CHECKSUM=lookup[j["key"] + ".CHECKSUM"]) for j in new]
    compressed = sum(p["ZIP"]["bytes"] + p["CHECKSUM"]["bytes"] for p in pairs)
    # All dependency body sizes are in admission even though existing bytes will not be fetched.
    dependency_bytes = sum(p["bytes"] + p["checksum_bytes"] for p in reused)
    total = compressed + dependency_bytes
    sources = [
        "scripts/research/recover_multiregime_inputs.py",
        "modules/collector_research/pipeline/economics.py",
        "modules/collector_research/pipeline/normalize.py",
        "modules/collector_research/pipeline/make_labels.py",
        "modules/collector_research/pipeline/train.py",
        "modules/transformer_v2/data.py",
    ]
    protocol = dict(
        status="PASS_FROZEN_METADATA_ADMISSION"
        if total <= LIMIT_BYTES
        else "BLOCKED_400MB_ADMISSION",
        new_download_bytes=compressed,
        dependency_bytes=dependency_bytes,
        exact_admission_bytes=total,
        new_ZIPs=len(pairs),
        reused_ZIPs=len(reused),
        pairs=pairs,
        reused=reused,
        listing_receipts=listing_refs,
        sources={p: sha(ROOT / p) for p in sources},
        prior_daily_frames={
            symbol: dict(
                path=f"/workspace/shared/coin_ranker_tail_state/daily/{symbol}.parquet",
                sha256=sha(f"/workspace/shared/coin_ranker_tail_state/daily/{symbol}.parquet"),
            )
            for symbol in np.load(
                "/workspace/shared/coin_ranker_tail_state/INPUTS.npz", allow_pickle=False
            )["symbol_order"].tolist()
        },
        prior_daily_inputs=dict(
            path="/workspace/shared/coin_ranker_tail_state/INPUTS.npz",
            sha256=sha("/workspace/shared/coin_ranker_tail_state/INPUTS.npz"),
        ),
        H1_manifest=dict(
            path="/workspace/shared/coin_2024H1_data/reports/DATASET_MANIFEST.json",
            sha256=sha("/workspace/shared/coin_2024H1_data/reports/DATASET_MANIFEST.json"),
        ),
        budget=dict(
            download_bytes=LIMIT_BYTES,
            added_data_bytes=OWNED_BYTES,
            reserve_bytes=RESERVE,
            wall_seconds=1800,
            address_space_bytes=6000000000,
            cpu_seconds=1800,
            workers=1,
            GPU=0,
            swap=0,
        ),
        semantics=dict(
            funding="RAW_UNCONFIRMED; original calc_time/interval/rate; no8h assumption",
            marks="most recent strictly-past CLOSED minute; <=60s age",
            execution="actual00:01 trade open; available after completed00:01 bar",
            reference=(
                "quantity-accounted economics.interval_arrays/replay;13.5bp each side;paid exit"
            ),
            gaps="UNKNOWN NaN; no prefix/internal-gap imputation",
            role="SEEN_DEVELOPMENT; NOT_NEW_OOS; NO_FITS_OR_WALLETS",
        ),
    )
    save(state / "PROTOCOL.json", protocol)
    if total > LIMIT_BYTES:
        raise ValueError("400MB frozen admission exceeded")
    print(
        json.dumps(
            {
                k: protocol[k]
                for k in (
                    "status",
                    "new_download_bytes",
                    "dependency_bytes",
                    "exact_admission_bytes",
                    "new_ZIPs",
                    "reused_ZIPs",
                )
            }
        ),
        flush=True,
    )


def raw_rows(path, family):
    with zipfile.ZipFile(path) as archive:
        with archive.open(archive.infolist()[0]) as f:
            reader = csv.reader(io.TextIOWrapper(f, encoding="utf-8-sig"))
            first = next(reader)
            if family == "fundingRate":
                if first != ["calc_time", "funding_interval_hours", "last_funding_rate"]:
                    raise ValueError("Original funding schema required")
            elif first[0].lower() not in ("open_time", "opentime", "open_timestamp"):
                yield first
            yield from reader


def parse_funding(path, month):
    lo, hi = month_limits(month)
    result = []
    previous = -1
    for row in raw_rows(path, "fundingRate"):
        if len(row) != 3:
            raise ValueError("Funding width invalid")
        t, h, r = int(row[0]), float(row[1]), float(row[2])
        if not (
            lo <= t < hi and t > previous and math.isfinite(h) and math.isfinite(r) and 0 < h <= 24
        ):
            raise ValueError("Funding chronology/interval/rate invalid")
        result.append((t, h, r, np.nan, np.nan))
        previous = t
    return pd.DataFrame(result, columns=FUND_COLS)


def price_value(row, family, step, lo, hi, previous):
    if len(row) != 12:
        raise ValueError("Kline width invalid")
    t, ct = int(row[0]), int(row[6])
    if not (lo <= t < hi and t % step == 0 and t > previous and ct == t + step - 1):
        raise ValueError("Kline timestamp/duplicate/close-time invalid")
    values = [float(row[i]) for i in (1, 2, 3, 4, 5, 7, 8, 9, 10, 11)]
    if not all(math.isfinite(v) for v in values):
        raise ValueError("Nonfinite kline value")
    o, h, low, c = values[:4]
    if not (low <= min(o, c) <= max(o, c) <= h):
        raise ValueError("OHLC envelope invalid")
    if family != "premiumIndexKlines" and min(o, h, low, c) <= 0:
        raise ValueError("Nonpositive trade/mark OHLC")
    if family == "klines" and (min(values[4:9]) < 0 or values[6] != math.floor(values[6])):
        raise ValueError("Negative trade volume/count or fractional count")
    return t, values


def parse_daily(path, family, month):
    lo, hi = month_limits(month)
    rows = []
    previous = -1
    for row in raw_rows(path, family):
        t, v = price_value(row, family, DAY_MS, lo, hi, previous)
        rows.append(
            dict(
                dt=pd.Timestamp(t, unit="ms", tz="UTC"),
                open=v[0],
                high=v[1],
                low=v[2],
                close=v[3],
                volume=v[4],
                quote_volume=v[5],
                trades=v[6],
                complete=True,
            )
        )
        previous = t
    return pd.DataFrame(rows)


def finish_day(day, agg):
    complete = (
        agg["rows"] == 1440 and agg["first_ms"] == day and agg["last_ms"] == day + DAY_MS - 60000
    )
    result = dict(dt=pd.Timestamp(day, unit="ms", tz="UTC"), complete=complete, **agg)
    if not complete:
        for col in ("open", "high", "low", "close", "volume", "quote_volume", "trades"):
            result[col] = np.nan
    result["unique_minutes"] = result["rows"]
    return result


def stream_minute(path, family, month, events=None, carry=None):
    """Validate every row sequentially, retaining only daily bars/event marks."""
    lo, hi = month_limits(month)
    previous = -1
    day = None
    agg = None
    out = []
    count = 0
    gaps = 0
    previous_marks = list(carry or [])
    assignments = []
    event_times = [] if events is None else events.calc_time_ms.to_numpy(np.int64) * 1000
    cursor = 0
    for row in raw_rows(path, family):
        t, v = price_value(row, family, 60000, lo, hi, previous)
        if previous >= 0:
            gaps += (t - previous) // 60000 - 1
        previous = t
        count += 1
        own_day = t // DAY_MS * DAY_MS
        if own_day != day:
            if agg is not None:
                out.append(finish_day(day, agg))
            day = own_day
            agg = dict(
                open=v[0],
                high=v[1],
                low=v[2],
                close=v[3],
                volume=0.0,
                quote_volume=0.0,
                trades=0.0,
                rows=0,
                first_ms=t,
                last_ms=t,
                exec_price=np.nan,
            )
        agg["high"] = max(agg["high"], v[1])
        agg["low"] = min(agg["low"], v[2])
        agg["close"] = v[3]
        agg["volume"] += v[4]
        agg["quote_volume"] += v[5]
        agg["trades"] += v[6]
        agg["rows"] += 1
        agg["last_ms"] = t
        if t - own_day == 60000:
            agg["exec_price"] = v[0]
        if family == "markPriceKlines":
            available = (t + 60000) * 1000
            while cursor < len(event_times) and event_times[cursor] <= available:
                event = int(event_times[cursor])
                past = next((v for v in reversed(previous_marks) if v[0] < event), None)
                if past and 0 < event - past[0] <= 60000000:
                    assignments.append((int(events.index[cursor]), past[1], past[0]))
                cursor += 1
            previous_marks = (previous_marks + [(available, v[3])])[-2:]
    if agg is not None:
        out.append(finish_day(day, agg))
    # A jittered event after the final availability may still have the last valid mark.
    while cursor < len(event_times):
        event = int(event_times[cursor])
        past = next((v for v in reversed(previous_marks) if v[0] < event), None)
        if past and 0 < event - past[0] <= 60000000:
            assignments.append((int(events.index[cursor]), past[1], past[0]))
        cursor += 1
    expected = (hi - lo) // 60000
    return (
        pd.DataFrame(out),
        previous_marks,
        assignments,
        dict(
            rows=count,
            expected_minutes=expected,
            missing_minutes=expected - count,
            internal_gap_minutes=gaps,
        ),
    )


def run(state, resume=False):
    p = json.loads((state / "PROTOCOL.json").read_text())
    if p["status"] != "PASS_FROZEN_METADATA_ADMISSION" or p["exact_admission_bytes"] > LIMIT_BYTES:
        raise ValueError("Frozen byte admission required")
    for name, digest in p["sources"].items():
        if sha(ROOT / name) != digest:
            raise ValueError("Frozen code changed: " + name)
    if resume:
        original = json.loads((state / "STARTED.json").read_text())
        if not (state / "READINESS_ATTEMPT.json").exists():
            raise ValueError("Explicit authorized readiness receipt required")
        elapsed = time.time() - original["started_epoch"]
        if not 0 <= elapsed < 1800:
            raise TimeoutError("Original deadline expired; no reset")
        if (state / "SOURCE_RECEIPTS.json").exists():
            raise ValueError("This narrow zero-body resume cannot repeat verified objects")
        started = time.monotonic() - elapsed
        deadline = started + 1800
        save(
            state / "RESUMED.json",
            dict(
                original_started_epoch=original["started_epoch"],
                original_deadline_epoch=original["started_epoch"] + 1800,
                remaining_seconds=1800 - elapsed,
            ),
        )
    else:
        if (state / "STARTED.json").exists():
            raise ValueError("One run only; no silent budget/deadline reset")
        started = time.monotonic()
        deadline = started + 1800
        save(
            state / "STARTED.json",
            dict(
                started_epoch=time.time(),
                protocol_sha256=sha(state / "PROTOCOL.json"),
                deadline_seconds=1800,
            ),
        )

    def guard():
        if time.monotonic() >= deadline:
            raise TimeoutError("Original1800s deadline reached")
        if shutil.disk_usage(state).free < RESERVE:
            raise RuntimeError("15GiB reserve floor reached")
        if sum(x.stat().st_size for x in state.rglob("*") if x.is_file()) > OWNED_BYTES:
            raise RuntimeError("250MB retained+temporary spool limit reached")

    session = requests.Session()
    downloaded = (
        json.loads((state / "READINESS_ATTEMPT.json").read_text())["response_bytes"]
        if resume
        else 0
    )
    receipts = []

    def archive(job):
        nonlocal downloaded
        guard()
        if "local_path" in job:
            path = Path(job["local_path"])
            digest = verify_archive(path, job["sha256"])
            reused = True
        else:
            path = state / "spool" / Path(job["key"]).name
            path.parent.mkdir(exist_ok=True)
            for obj, dest in ((job["CHECKSUM"], Path(str(path) + ".CHECKSUM")), (job["ZIP"], path)):
                for attempt in range(2):
                    size = 0
                    try:
                        response = session.get(
                            BASE + obj["key"], timeout=(15, 15), allow_redirects=False, stream=True
                        )
                        if response.status_code != 200:
                            raise requests.HTTPError(
                                f"HTTP{response.status_code}: {response.url}", response=response
                            )
                        with dest.open("wb") as f:
                            for chunk in response.iter_content(1 << 16):
                                guard()
                                size += len(chunk)
                                downloaded += len(chunk)
                                if size > obj["bytes"] or downloaded > LIMIT_BYTES:
                                    raise RuntimeError("Frozen body-byte limit exceeded")
                                f.write(chunk)
                        response.close()
                        if size != obj["bytes"]:
                            raise ValueError("Frozen official size changed")
                        break
                    except requests.RequestException as exc:
                        status = getattr(getattr(exc, "response", None), "status_code", None)
                        failed_sha = sha(dest) if dest.exists() else None
                        with (state / "ERRORS.jsonl").open("a") as log:
                            log.write(
                                json.dumps(
                                    dict(
                                        url=BASE + obj["key"],
                                        attempt=attempt + 1,
                                        received_bytes=size,
                                        partial_sha256=failed_sha,
                                        error_type=type(exc).__name__,
                                        error=str(exc),
                                    )
                                )
                                + "\n"
                            )
                        transient = isinstance(
                            exc,
                            (
                                requests.Timeout,
                                requests.ConnectionError,
                                requests.exceptions.ChunkedEncodingError,
                            ),
                        ) or status in (500, 502, 503, 504)
                        if attempt or not transient:
                            raise
                        if dest.exists():
                            dest.rename(dest.with_suffix(dest.suffix + ".failed"))
                        time.sleep(0.5)
            digest = verify_archive(path)
            reused = False
        return path, dict(
            symbol=job["symbol"],
            family=job["family"],
            interval=job["interval"],
            month=job["month"],
            role=job["role"],
            key=job["key"],
            sha256=digest,
            bytes=path.stat().st_size,
            reused=reused,
            official_sha=True,
            ZIP_CRC=True,
        )

    jobs = p["pairs"] + p["reused"]
    events = {s: [] for s in CORE}
    prefix_trade = {s: [] for s in CORE}
    prefix_premium = {s: [] for s in CORE}
    # Funding rows must be available before mark streaming. No daily-sum reconstruction.
    early = sorted(
        [j for j in jobs if j["interval"] != "1m"],
        key=lambda j: (j["symbol"], j["month"], j["family"]),
    )
    daily_folder = state / "checkpoints"
    daily_folder.mkdir()

    def checkpoint(job, path, receipt, frame, suffix):
        target = daily_folder / (
            f"{job['symbol']}-{job['family']}-{job['interval'] or 'event'}-"
            f"{job['month']}-{suffix}.parquet"
        )
        frame.to_parquet(target, index=False)
        receipt.update(
            derived_path=str(target.relative_to(state)),
            derived_sha256=sha(target),
            numerical_rows=len(frame),
        )
        receipts.append(receipt)
        save(
            state / "SOURCE_RECEIPTS.json",
            dict(status="PARTIAL_VERIFIED", downloaded_body_bytes=downloaded, objects=receipts),
        )
        if not receipt["reused"]:
            path.unlink()
            Path(str(path) + ".CHECKSUM").unlink()
        if len(receipts) % 20 == 0:
            print(f"VERIFIED {len(receipts)}/{len(jobs)} bytes={downloaded}", flush=True)
        guard()

    for job in early:
        path, receipt = archive(job)
        if job["family"] == "fundingRate":
            f = parse_funding(path, job["month"])
            events[job["symbol"]].append(f)
        else:
            f = parse_daily(path, job["family"], job["month"])
            container = prefix_trade if job["family"] == "klines" else prefix_premium
            container[job["symbol"]].append(f)
        checkpoint(job, path, receipt, f, "daily")
    funds = {
        s: pd.concat(events[s], ignore_index=True)
        .sort_values("calc_time_ms")
        .reset_index(drop=True)
        for s in CORE
    }
    # Recover the year-end funding mark fromDec2023 minutes, rather than leave
    # the H1Jan1 event unknown because that source had noDecember mark archive.
    h1_manifest = json.loads(Path(p["H1_manifest"]["path"]).read_text())
    h1_root = Path(p["H1_manifest"]["path"]).parents[1]
    h1_refs = {v["relative_path"]: v["sha256"] for v in h1_manifest["artifacts"]}
    boundary_ms = pd.Timestamp("2024-01-01", tz="UTC").value // 1000000
    for symbol in CORE:
        relative = f"data/normalized/{symbol}_funding_events.parquet"
        event_path = h1_root / relative
        if sha(event_path) != h1_refs[relative]:
            raise ValueError("Frozen H1 boundary-event dependency changed")
        original_events = pd.read_parquet(event_path)
        boundary = original_events[
            (original_events.calc_time_ms >= boundary_ms)
            & (original_events.calc_time_ms < boundary_ms + 60000)
        ][FUND_COLS]
        funds[symbol] = pd.concat([funds[symbol], boundary], ignore_index=True)
    economic_parts = {s: [] for s in CORE}
    marks_parts = {s: [] for s in CORE}
    for s in CORE:
        carry = None
        mark_jobs = sorted(
            [j for j in jobs if j["symbol"] == s and j["family"] == "markPriceKlines"],
            key=lambda j: j["month"],
        )
        for job in mark_jobs:
            path, receipt = archive(job)
            lo, hi = month_limits(job["month"])
            # Midnight events need the prior month's penultimate minute.
            own = funds[s][(funds[s].calc_time_ms >= lo) & (funds[s].calc_time_ms < hi + 60000)]
            frame, carry, assigned, coverage = stream_minute(
                path, job["family"], job["month"], own, carry
            )
            for index, mark, available in assigned:
                funds[s].loc[index, ["past_mark_price", "past_mark_available_us"]] = (
                    mark,
                    available,
                )
            marks_parts[s].append(frame)
            receipt.update(coverage=coverage, marked_events=len(assigned))
            checkpoint(job, path, receipt, frame, "sparse_mark_daily")
            # Store marked event checkpoint after each month, preserving original times/rates.
            funds[s].to_parquet(state / f"{s}_funding_events.parquet", index=False)
        trade_jobs = sorted(
            [
                j
                for j in jobs
                if j["symbol"] == s and j["interval"] == "1m" and j["family"] == "klines"
            ],
            key=lambda j: j["month"],
        )
        for job in trade_jobs:
            path, receipt = archive(job)
            frame, _, _, coverage = stream_minute(path, job["family"], job["month"])
            economic_parts[s].append(frame)
            receipt["coverage"] = coverage
            checkpoint(job, path, receipt, frame, "trade_daily")
    guard()
    result = build_outputs(
        state, p, prefix_trade, prefix_premium, funds, economic_parts, marks_parts
    )
    result.update(
        status="COMPLETE_VERIFIED_PUBLIC_SPARSE_RECOVERY",
        downloaded_body_bytes=downloaded,
        protocol_sha256=sha(state / "PROTOCOL.json"),
        verified_objects=len(receipts),
        reused_objects=sum(r["reused"] for r in receipts),
        elapsed_seconds=time.monotonic() - started,
        fits=0,
        wallets=0,
        role="SEEN_DEVELOPMENT_NOT_UNSEEN_OOS",
    )
    save(state / "COVERAGE.json", result)
    save(
        state / "SOURCE_RECEIPTS.json",
        dict(status="COMPLETE", downloaded_body_bytes=downloaded, objects=receipts),
    )
    print(json.dumps(result, indent=2), flush=True)


def build_outputs(state, p, trade, premium, funds, economic, marks):
    original_dir = Path("/workspace/shared/coin_ranker_tail_state/daily")
    with np.load(p["prior_daily_inputs"]["path"], allow_pickle=False) as z:
        order = z["symbol_order"].tolist()
        feature_order = z["feature_order"].tolist()
    dates = pd.date_range("2020-01-01", "2025-01-01", tz="UTC")
    features = {}
    daily_refs = []
    audit = []
    out = state / "daily_features"
    out.mkdir()
    econ_out = state / "economics"
    econ_out.mkdir()
    h1manifest = json.loads(Path(p["H1_manifest"]["path"]).read_text())
    h1_root = Path(p["H1_manifest"]["path"]).parents[1]
    h1lookup = {a["relative_path"]: a["sha256"] for a in h1manifest["artifacts"]}

    def h1_read(rel):
        path = h1_root / rel
        if sha(path) != h1lookup[rel]:
            raise ValueError("H1 bound dependency changed")
        return pd.read_parquet(path)

    for s in order:
        old_path = original_dir / (s + ".parquet")
        if sha(old_path) != p["prior_daily_frames"][s]["sha256"]:
            raise ValueError("Frozen existing daily frame changed")
        old = pd.read_parquet(old_path)
        if old.dt.duplicated().any() or not np.all(
            np.diff(pd.DatetimeIndex(old.dt).as_unit("us").asi8) == DAY_US
        ):
            raise ValueError("Existing daily calendar/schema invalid")
        # Revalidate daily trade/premium source bytes before the prefix merge.
        revalidated = []
        if s in CORE:
            for month in months("2022-01", "2024-08"):
                path = (
                    Path("/workspace/shared/coin_ranker_price_state/raw/klines")
                    / s
                    / f"{s}-1d-{month}.zip"
                )
                verify_archive(path)
                source = parse_daily(path, "klines", month).set_index("dt")
                overlap = old.set_index("dt").index.intersection(source.index)
                for col in ("open", "high", "low", "close", "volume", "quote_volume"):
                    if not np.array_equal(
                        old.set_index("dt").loc[overlap, col],
                        source.loc[overlap, col],
                        equal_nan=True,
                    ):
                        raise ValueError("Original daily values differ from verified source")
                revalidated.append(
                    dict(month=month, key=key_for(s, "klines", "1d", month), sha256=sha(path))
                )
        d = old.set_index("dt").reindex(dates)
        for flag in ("complete_kline", "complete_premium", "complete_funding"):
            d[flag] = d[flag].fillna(False).astype(bool)
        d["symbol"] = s
        if s in CORE:
            prefix = pd.concat(trade[s]).set_index("dt")
            pre = pd.concat(premium[s]).set_index("dt")
            if prefix.index.duplicated().any() or pre.index.duplicated().any():
                raise ValueError("Daily-prefix duplicate")
            for col in ("open", "high", "low", "close", "volume", "quote_volume"):
                d.loc[prefix.index, col] = prefix[col]
            d.loc[prefix.index, "complete_kline"] = True
            d.loc[pre.index, "premium"] = pre.close
            d.loc[pre.index, "complete_premium"] = True
            # Events acrossJan2022 boundary are present; daily feature completeness stays causal.
            fwin = funding_windows(funds[s], dates)
            prefix_dates = dates[dates < pd.Timestamp("2022-01-01", tz="UTC")]
            d.loc[prefix_dates, ["funding", "complete_funding"]] = fwin.loc[
                prefix_dates, ["funding", "complete_funding"]
            ]
            raw = pd.concat(economic[s]).set_index("dt")
            mark_daily = pd.concat(marks[s]).set_index("dt")
            calendar_dates = pd.date_range("2022-01-01", "2023-12-31", tz="UTC")
            raw = raw.reindex(calendar_dates)
            e = raw.rename(columns={"complete": "complete_kline"})
            e["complete_kline"] = e.complete_kline.fillna(False).astype(bool)
            e["symbol"] = s
            e["available_us"] = calendar_dates.as_unit("us").asi8 + DAY_US
            e["mark"] = mark_daily.close.reindex(calendar_dates)
            e["complete_mark"] = (
                mark_daily.complete.reindex(calendar_dates).fillna(False).astype(bool)
            )
            e = e.reset_index(names="dt")
            # Verify all complete minute-derived daily closes against observed1d inputs.
            complete = e.complete_kline.to_numpy(bool)
            direct = d.loc[calendar_dates, "close"].to_numpy(float)
            if not np.array_equal(e.close.to_numpy(float)[complete], direct[complete]):
                raise ValueError("Minute/day close identity conflict")
            late_events = h1_read(f"data/normalized/{s}_funding_events.parquet")
            late_events = late_events[
                late_events.calc_time_ms >= pd.Timestamp("2024-01-01", tz="UTC").value // 1000000
            ][FUND_COLS]
            late_events = late_events[~late_events.calc_time_ms.isin(funds[s].calc_time_ms)]
            full_events = pd.concat([funds[s], late_events], ignore_index=True).sort_values(
                "calc_time_ms"
            )
            if full_events.calc_time_ms.duplicated().any():
                raise ValueError("Funding seam duplicate")
            h1 = h1_read(f"data/normalized/{s}_daily.parquet")
            h1 = h1[h1.dt >= pd.Timestamp("2024-01-01", tz="UTC")]
            e = pd.concat([e, h1], ignore_index=True).sort_values("dt").reset_index(drop=True)
            # Reuse H1 minute-derived prices; rebuild funding windows at the seam.
            windows = funding_windows(full_events, pd.DatetimeIndex(e.dt))
            for col in windows:
                e[col] = windows[col].to_numpy()
            ep = econ_out / (s + "_daily.parquet")
            e.to_parquet(ep, index=False)
            fp = econ_out / (s + "_funding_events.parquet")
            full_events.to_parquet(fp, index=False)
            for ep0 in (ep, fp):
                daily_refs.append(
                    dict(
                        path=str(ep0.relative_to(state)), sha256=sha(ep0), bytes=ep0.stat().st_size
                    )
                )
            a = interval_arrays(e, np.arange(len(e) - 2), 1)
            valid = a[3] & np.isfinite(a[0]) & np.isfinite(a[1]) & np.isfinite(a[2])
            audit.append(
                dict(
                    symbol=s,
                    first_observed_day=str(prefix.index.min().date()),
                    minute_complete_days=int(e.complete_kline.sum()),
                    economic_valid_intervals=int(valid.sum()),
                    economics_days=len(e),
                    missing_event_marks=int(full_events.past_mark_price.isna().sum()),
                    daily_source_revalidation=revalidated,
                    funding_interval_values=sorted(
                        full_events.funding_interval_hours.unique().tolist()
                    ),
                    funding_interval_changes=int(
                        (full_events.funding_interval_hours.diff().fillna(0) != 0).sum()
                    ),
                    invalid_interval_decision_days=[
                        str(e.dt.iloc[i].date()) for i in np.flatnonzero(~valid)
                    ],
                )
            )
        # Check the original DAILY observations retain exactly the same cells on all old dates.
        compare = d.loc[pd.DatetimeIndex(old.dt), old.columns.drop("dt")]
        same = compare.eq(old.set_index("dt")) | (compare.isna() & old.set_index("dt").isna())
        if not same.all().all():
            raise ValueError("Existing daily observations changed by prefix extension")
        d = d.reset_index(names="dt")
        target = out / (s + ".parquet")
        d.to_parquet(target, index=False)
        features[s] = feature_frame(d, 256)
        daily_refs.append(
            dict(
                path=str(target.relative_to(state)), sha256=sha(target), bytes=target.stat().st_size
            )
        )
    market = market_features(features).reset_index(drop=True)
    close = np.stack([features[s].close.to_numpy(float) for s in order], axis=1)
    x = np.stack(
        [
            pd.concat([features[s][BASE_FEATURES], market], axis=1).to_numpy("float32")
            for s in order
        ],
        axis=1,
    )
    ready = np.stack([features[s].feature_ready.to_numpy(bool) for s in order], axis=1)
    relative, regime = causal_future_targets(close, ready)
    label_end = dates + pd.Timedelta(days=61) + pd.Timedelta(microseconds=60000001)
    core_columns = [order.index(s) for s in CORE]
    eligible = (
        ready[:, core_columns].all(1)
        & np.isfinite(relative[:, core_columns]).all((1, 2))
        & np.isfinite(regime).all(1)
    )
    candidates = np.flatnonzero(eligible)
    feasibility = {}
    for required in (180, 263):
        if len(candidates) >= required:
            last = int(candidates[required - 1])
            feasibility[str(required)] = dict(
                last_required_feature_day=str(dates[last]),
                earliest_strict_cutoff_us=int(label_end[last].value // 1000 + 1),
                earliest_strict_cutoff=str(label_end[last] + pd.Timedelta(microseconds=1)),
            )
        else:
            feasibility[str(required)] = dict(status="INSUFFICIENT_ACTUAL_ELIGIBLE_ROWS")
    jan2022 = int(np.sum(eligible & (label_end < pd.Timestamp("2022-01-01", tz="UTC"))))
    if BASE_FEATURES + list(market.columns) != feature_order:
        raise ValueError("Existing feature schema changed")
    np.savez_compressed(
        state / "INPUTS.npz",
        x=x,
        close=close,
        availability=np.isfinite(close),
        ready=ready,
        relative=relative,
        regime=regime,
        dates_us=dates.as_unit("us").asi8,
        label_end_us=label_end.as_unit("us").asi8,
        symbol_order=np.array(order),
        feature_order=np.array(feature_order),
        eligible_ranker_indices=candidates,
    )
    return dict(
        symbol_order=order,
        feature_order=feature_order,
        dates=len(dates),
        daily_observations_preserved=True,
        daily_prefix_and_source_validated=True,
        earliest_common_ready_feature_day=str(
            dates[np.flatnonzero(ready[:, core_columns].all(1))[0]]
        ),
        jan2022_strict_mature_ranker_dates=jan2022,
        ranker_cutoff_feasibility=feasibility,
        ranker_actual_eligible_rows=len(candidates),
        economic_coverage=audit,
        files=daily_refs,
        inputs_sha256=sha(state / "INPUTS.npz"),
        full_minute_wallet_MDD_or_liquidation_available=False,
        reference_semantics=(
            "Reuse economics.interval_arrays/replay;13.5bp each side;"
            "paid terminal exit;no labels fitted"
        ),
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=["metadata", "run", "resume"])
    parser.add_argument("--state", type=Path, required=True)
    args = parser.parse_args()
    if args.mode == "metadata":
        metadata(args.state)
    else:
        try:
            run(args.state, resume=args.mode == "resume")
        except Exception as exc:
            save(
                args.state / "FAILURE.json",
                dict(
                    status="PARTIAL_STOPPED",
                    error_type=type(exc).__name__,
                    error=str(exc),
                    no_budget_reset=True,
                ),
            )
            raise


if __name__ == "__main__":
    main()
