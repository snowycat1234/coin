"""Frozen-weight forward transfer on the registered 142-day seen CORE5 tail."""

from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import resource
import subprocess
import time
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd
import requests
import torch

from modules.collector_research.pipeline.make_labels import BASE_FEATURES, feature_frame
from modules.collector_research.pipeline.normalize import funding_windows
from modules.collector_research.pipeline.train import market_features
from modules.collector_research.validation.cloud_guard import check_cloud_limits
from modules.transformer_v2.model import CrossAssetTransformer
from modules.transformer_v3.market_binding import verify_binding
from modules.transformer_v3.wallet import frozen_sources, run_tasks
from scripts.research.patch_price_rank_cpu import inference_features, map_targets
from scripts.research.patch_price_rank_inputs import DAY_US, guard, save, sha
from scripts.research.run_public_momentum import summary_row

ROOT = Path(__file__).resolve().parents[2]
APPEND_START = pd.Timestamp("2024-08-12", tz="UTC")
APPEND_END_EXCLUSIVE = pd.Timestamp("2025-01-02", tz="UTC")
LO_MS = APPEND_START.value // 1_000_000
HI_MS = APPEND_END_EXCLUSIVE.value // 1_000_000
LISTING = "https://s3-ap-northeast-1.amazonaws.com/data.binance.vision"
BODY = "https://data.binance.vision/"
MONTHS = ["2024-08", "2024-09", "2024-10", "2024-11", "2024-12"]


def parse_tail_price(row):
    stamp = int(row[0])
    if not LO_MS <= stamp < HI_MS:
        return None
    if len(row) != 12 or stamp % 86_400_000 or int(row[6]) != stamp + 86_400_000 - 1:
        raise ValueError("Exact daily millisecond clock required")
    values = np.asarray([float(row[i]) for i in (1, 2, 3, 4, 5, 7)])
    if not np.isfinite(values).all():
        raise ValueError("Nonfinite daily value")
    return dict(
        dt=pd.Timestamp(stamp, unit="ms", tz="UTC"),
        open=values[0],
        high=values[1],
        low=values[2],
        close=values[3],
        volume=values[4],
        quote_volume=values[5],
    )


def parse_tail_funding(row):
    stamp = int(row[0])
    if stamp < LO_MS - 86_400_000 or stamp >= HI_MS:
        return None
    interval, rate = float(row[1]), float(row[2])
    if not np.isfinite([interval, rate]).all() or not 0 < interval <= 24:
        raise ValueError("Invalid funding observation")
    return dict(
        calc_time_ms=stamp,
        funding_interval_hours=interval,
        last_funding_rate=rate,
        past_mark_price=np.nan,
    )


def source_identity(protocol, protocol_path, state):
    for name, digest in protocol["frozen_sources"].items():
        p = ROOT / name
        if sha(p) != digest:
            raise ValueError("Frozen source changed: " + name)
        if (
            hashlib.sha256(
                subprocess.check_output(["git", "-C", str(ROOT), "show", "HEAD:" + name])
            ).hexdigest()
            != digest
        ):
            raise ValueError("Commit exact frozen source before input bodies: " + name)
    committed = subprocess.check_output(
        ["git", "-C", str(ROOT), "show", "HEAD:" + str(protocol_path.relative_to(ROOT))]
    )
    if hashlib.sha256(committed).hexdigest() != sha(protocol_path):
        raise ValueError("Commit frozen tail protocol before input bodies")
    previous = Path(protocol["previous_state"])
    for ref in protocol["prior_identity"].values():
        if sha(previous / ref["relative_path"]) != ref["sha256"]:
            raise ValueError("Frozen prior input/fit receipt changed")
    for fit in protocol["frozen_fits"]:
        for name, key in [
            ("weights.pt", "weights_sha256"),
            ("scaler.npz", "scaler_sha256"),
            ("PREDICTIONS.npz", "prediction_sha256"),
        ]:
            if sha(previous / "fits" / f"seed{fit['seed']}" / name) != fit[key]:
                raise ValueError("Frozen model/scaler/prediction bytes changed")
    save(
        state / "SOURCE_BINDING.json",
        dict(
            protocol_sha256=sha(protocol_path),
            sources=protocol["frozen_sources"],
            source_HEAD=subprocess.check_output(
                ["git", "-C", str(ROOT), "rev-parse", "HEAD"], text=True
            ).strip(),
        ),
    )


def metadata(protocol, protocol_path, state, deadline, session):
    pairs, receipts = [], []
    ns = {"s": "http://s3.amazonaws.com/doc/2006-03-01/"}
    for symbol in protocol["assets"]["input_order"]:
        for family in ("klines", "premiumIndexKlines", "fundingRate"):
            prefix = f"data/futures/um/monthly/{family}/{symbol}/"
            if family != "fundingRate":
                prefix += "1d/"
            prefixes = [(prefix, MONTHS + (["2025-01"] if family == "fundingRate" else []))]
            if family != "fundingRate":
                prefixes.append(
                    (
                        f"data/futures/um/daily/{family}/{symbol}/1d/{symbol}-1d-2025-01-01.zip",
                        ["2025-01-01"],
                    )
                )
            for prefix, stamps in prefixes:
                objects, marker = {}, None
                for page in range(2):
                    guard(state, deadline, protocol["budget"])
                    params = {"prefix": prefix, "max-keys": "1000"}
                    if marker:
                        params["marker"] = marker
                    response = session.get(
                        LISTING, params=params, timeout=(5, 15), allow_redirects=False
                    )
                    if response.status_code != 200:
                        raise RuntimeError(f"Official listing HTTP{response.status_code}; stop")
                    tree = ET.fromstring(response.content)
                    if tree.findtext("s:Prefix", namespaces=ns) != prefix:
                        raise ValueError("Official directory prefix identity mismatch")
                    entries = tree.findall("s:Contents", ns)
                    for entry in entries:
                        key = entry.findtext("s:Key", namespaces=ns)
                        for stamp in stamps:
                            filename = (
                                f"{symbol}-fundingRate-{stamp}.zip"
                                if family == "fundingRate"
                                else f"{symbol}-1d-{stamp}.zip"
                            )
                            if key.endswith("/" + filename) or key.endswith(
                                "/" + filename + ".CHECKSUM"
                            ):
                                objects[key] = dict(
                                    key=key,
                                    bytes=int(entry.findtext("s:Size", namespaces=ns)),
                                    ETag=entry.findtext("s:ETag", namespaces=ns),
                                )
                    truncated = tree.findtext("s:IsTruncated", namespaces=ns) == "true"
                    receipts.append(
                        dict(
                            prefix=prefix,
                            page=page,
                            bytes=len(response.content),
                            sha256=hashlib.sha256(response.content).hexdigest(),
                            truncated=truncated,
                            metadata_only=True,
                        )
                    )
                    if not truncated:
                        break
                    marker = tree.findtext("s:NextMarker", namespaces=ns)
                    if not marker and entries:
                        marker = entries[-1].findtext("s:Key", namespaces=ns)
                    if page == 1 or not marker:
                        raise ValueError("Official listing exceeded frozen two-page bound")
                for stamp in stamps:
                    filename = (
                        f"{symbol}-fundingRate-{stamp}.zip"
                        if family == "fundingRate"
                        else f"{symbol}-1d-{stamp}.zip"
                    )
                    base = (
                        prefix if not stamp.endswith("-01-01") else prefix.rsplit("/", 1)[0] + "/"
                    )
                    key = base + filename
                    if key not in objects or key + ".CHECKSUM" not in objects:
                        raise ValueError("Required official object unavailable: " + key)
                    pairs.append(
                        dict(
                            symbol=symbol,
                            family=family,
                            stamp=stamp,
                            ZIP=objects[key],
                            CHECKSUM=objects[key + ".CHECKSUM"],
                        )
                    )
        print("METADATA " + symbol, flush=True)
    total = sum(p[k]["bytes"] for p in pairs for k in ("ZIP", "CHECKSUM"))
    if total > protocol["budget"]["download_body_bytes"]:
        raise ValueError("Listed archive/checksum total exceeds admitted100MB")
    result = dict(
        status="PASS_METADATA_BUDGET_ONLY",
        protocol_sha256=sha(protocol_path),
        exact_listed_total_bytes=total,
        pairs=pairs,
        receipts=receipts,
        price_or_rate_bodies_read_before_freeze=0,
    )
    save(state / "ARCHIVE_METADATA.json", result)
    save(
        state / "INPUT_ADMISSION.json",
        dict(
            protocol_sha256=sha(protocol_path),
            source_binding_sha256=sha(state / "SOURCE_BINDING.json"),
            metadata_sha256=sha(state / "ARCHIVE_METADATA.json"),
            scoring_window=protocol["window"],
            frozen_before_first_body=True,
        ),
    )
    return result


def append_inputs(protocol, protocol_path, state, deadline, session, meta):
    previous = Path(protocol["previous_state"])
    tables = {s: {} for s in protocol["assets"]["input_order"]}
    records, downloaded = [], 0
    for number, pair in enumerate(meta["pairs"], 1):
        guard(state, deadline, protocol["budget"])
        old = previous / "raw" / pair["family"] / pair["symbol"] / Path(pair["ZIP"]["key"]).name
        dest = (
            old
            if pair["stamp"] == "2024-08"
            else (state / "raw" / pair["family"] / pair["symbol"] / old.name)
        )
        dest.parent.mkdir(parents=True, exist_ok=True)
        for item, path in [(pair["CHECKSUM"], Path(str(dest) + ".CHECKSUM")), (pair["ZIP"], dest)]:
            if path.exists():
                if path.stat().st_size != item["bytes"]:
                    raise ValueError("Cached source size mismatch")
                continue
            response = session.get(BODY + item["key"], timeout=(5, 15), allow_redirects=False)
            if response.status_code != 200:
                raise RuntimeError(f"Official body HTTP{response.status_code}; stop dependent step")
            if len(response.content) != item["bytes"]:
                raise ValueError("Official listed size changed")
            downloaded += len(response.content)
            if downloaded > protocol["budget"]["download_body_bytes"]:
                raise ValueError("100MB download budget reached")
            path.write_bytes(response.content)
        check = Path(str(dest) + ".CHECKSUM").read_text().split()
        if len(check) != 2 or check[1].lstrip("*") != dest.name or check[0].lower() != sha(dest):
            raise ValueError("Official archive SHA mismatch")
        rows, witness = [], None
        with zipfile.ZipFile(dest) as z:
            if z.namelist() != [dest.name.removesuffix(".zip") + ".csv"] or z.testzip() is not None:
                raise ValueError("CSV member/ZIP CRC mismatch")
            with z.open(z.namelist()[0]) as stream:
                for row in csv.reader(io.TextIOWrapper(stream, encoding="utf-8-sig")):
                    if row[0] in ("open_time", "openTime", "calc_time"):
                        continue
                    stamp = int(row[0])
                    if pair["family"] == "fundingRate" and stamp >= HI_MS:
                        witness = stamp
                        break  # Never parse rate or interval of this/right-later row.
                    value = (
                        parse_tail_funding(row)
                        if pair["family"] == "fundingRate"
                        else parse_tail_price(row)
                    )
                    if value is not None:
                        rows.append(value)
        tables[pair["symbol"]].setdefault(pair["family"], []).extend(rows)
        records.append(
            dict(
                symbol=pair["symbol"],
                family=pair["family"],
                stamp=pair["stamp"],
                path=str(dest),
                bytes=dest.stat().st_size,
                sha256=sha(dest),
                reused_august_bytes=dest == old,
                parsed_rows=len(rows),
                nearest_right_witness_ms=witness,
                witness_rate_interval_parsed=False,
            )
        )
        save(
            state / "progress.json",
            dict(
                stage="APPEND_OFFICIAL_DAILY",
                completed=number,
                total=len(meta["pairs"]),
                downloaded_bytes=downloaded,
                seconds_remaining=deadline - time.monotonic(),
            ),
        )
        if number % 10 == 0:
            print(f"APPEND {number}/{len(meta['pairs'])} bytes={downloaded}", flush=True)
    dates = pd.date_range(APPEND_START, APPEND_END_EXCLUSIVE - pd.Timedelta(days=1), tz="UTC")
    frames, daily_refs = {}, []
    for symbol in protocol["assets"]["input_order"]:
        past_path = previous / "daily" / (symbol + ".parquet")
        if sha(past_path) != protocol["past_daily_sha256"][symbol]:
            raise ValueError("Past daily observations changed")
        past = pd.read_parquet(past_path)
        frame = pd.DataFrame(index=dates)
        price = pd.DataFrame(tables[symbol]["klines"]).set_index("dt")
        premium = pd.DataFrame(tables[symbol]["premiumIndexKlines"]).set_index("dt")
        if price.index.duplicated().any() or premium.index.duplicated().any():
            raise ValueError("Duplicate appended daily observations")
        price = price.reindex(dates)
        for col in ("open", "high", "low", "close", "volume", "quote_volume"):
            frame[col] = price[col]
        if (frame[["open", "high", "low", "close"]].dropna() <= 0).any().any():
            raise ValueError("Nonpositive trade observation")
        frame["complete_kline"] = frame.close.notna()
        frame["premium"] = premium.close.reindex(dates)
        frame["complete_premium"] = frame.premium.notna()
        events = pd.DataFrame(tables[symbol]["fundingRate"]).sort_values("calc_time_ms")
        if events.calc_time_ms.duplicated().any():
            raise ValueError("Duplicate raw funding timestamps")
        funding = funding_windows(events, dates)
        frame["funding"] = funding.funding
        frame["complete_funding"] = funding.complete_funding
        frame["symbol"] = symbol
        frame.index.name = "dt"
        full = pd.concat([past, frame.reset_index()], ignore_index=True)
        if (
            full.dt.duplicated().any()
            or not (np.diff(pd.DatetimeIndex(full.dt).as_unit("us").asi8) == DAY_US).all()
        ):
            raise ValueError("Complete contiguous causal feature calendar required")
        frames[symbol] = feature_frame(full, 256)
        output = state / "daily" / (symbol + ".parquet")
        output.parent.mkdir(exist_ok=True)
        full.to_parquet(output, index=False)
        daily_refs.append(
            dict(
                symbol=symbol,
                path=str(output),
                sha256=sha(output),
                append_observed_closes=int(frame.close.notna().sum()),
                append_complete_funding=int(frame.complete_funding.sum()),
            )
        )
    market = market_features(frames).reset_index(drop=True)
    symbols = protocol["assets"]["input_order"]
    all_dates = pd.DatetimeIndex(frames[symbols[0]].dt).as_unit("us").asi8
    d = dict(
        x=np.stack(
            [
                pd.concat([frames[s][BASE_FEATURES], market], axis=1).to_numpy("float32")
                for s in symbols
            ],
            axis=1,
        ),
        close=np.stack([frames[s].close.to_numpy(float) for s in symbols], axis=1),
        ready=np.stack([frames[s].feature_ready.to_numpy(bool) for s in symbols], axis=1),
        dates_us=all_dates,
        symbols=symbols,
    )
    d["availability"] = np.isfinite(d["close"])
    d["predict_indices"] = np.flatnonzero(
        (all_dates + DAY_US >= protocol["window"]["start"])
        & (all_dates + DAY_US < protocol["window"]["end"])
    )
    with np.load(previous / "INPUTS.npz", allow_pickle=False) as original:
        n = len(original["x"])
        for key in ("x", "close", "ready", "availability", "dates_us"):
            if not np.array_equal(d[key][:n], original[key], equal_nan=True):
                raise ValueError("Appending future context altered past input: " + key)
        if original["symbol_order"].tolist() != symbols:
            raise ValueError("Symbol order changed")
        feature_order = original["feature_order"]
    if (
        len(d["predict_indices"]) != 142
        or not d["ready"][d["predict_indices"]][
            :, [symbols.index(s) for s in protocol["assets"]["allocation_pool"]]
        ].all()
    ):
        raise ValueError("Frozen142day CORE5 readiness failed")
    np.savez_compressed(
        state / "INPUTS.npz",
        **{k: v for k, v in d.items() if k != "symbols"},
        symbol_order=np.array(symbols),
        feature_order=feature_order,
    )
    receipt = dict(
        status="COMPLETE_CAUSAL_APPEND_PAST_PREFIX_UNCHANGED",
        protocol_sha256=sha(protocol_path),
        input_sha256=sha(state / "INPUTS.npz"),
        metadata_sha256=sha(state / "ARCHIVE_METADATA.json"),
        records=records,
        daily_refs=daily_refs,
        downloaded_body_bytes=downloaded,
        prior_prefix_equal=True,
        feature_source="SAME_OFFICIAL_DIRECT1D_RECIPE_AS_PRIOR_CPU_FIT",
        source_numerical_bounds=[str(APPEND_START), str(APPEND_END_EXCLUSIVE)],
        new_fits=0,
        new_labels=0,
        scaler_reestimated=False,
        January_afterJan1_rate_interval_parsed=False,
        score_days=142,
    )
    save(state / "INPUT_RECEIPT.json", receipt)
    return d


def infer(d, protocol, state, deadline):
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    all_predictions, identities = [], []
    for fit in protocol["frozen_fits"]:
        guard(state, deadline, protocol["budget"])
        folder = Path(protocol["previous_state"]) / "fits" / f"seed{fit['seed']}"
        with np.load(folder / "scaler.npz", allow_pickle=False) as f:
            scaler = (f["mu"].copy(), f["sd"].copy())
        net = CrossAssetTransformer(features=24, assets=10, length=256, patch=8)
        net.load_state_dict(
            torch.load(folder / "weights.pt", map_location="cpu", weights_only=True)
        )
        net.eval()
        pools = []
        with torch.inference_mode():
            for start in range(0, len(d["predict_indices"]), 16):
                guard(state, deadline, protocol["budget"])
                values = [
                    inference_features(d, int(i), scaler)
                    for i in d["predict_indices"][start : start + 16]
                ]
                batch = tuple(torch.stack([v[k] for v in values]) for k in range(3))
                pools.append(net(*batch)["relative"].numpy())
        pool = np.concatenate(pools)
        prediction = pool.mean(1)
        if not np.isfinite(prediction).all():
            raise ValueError("Nonfinite frozen scores")
        output = state / "predictions" / f"seed{fit['seed']}.npz"
        output.parent.mkdir(exist_ok=True)
        np.savez_compressed(
            output, relative_pool=pool, relative=prediction, indices=d["predict_indices"]
        )
        all_predictions.append(prediction)
        identities.append(
            dict(
                seed=fit["seed"],
                epochs=fit["epochs"],
                weights_sha256=sha(folder / "weights.pt"),
                scaler_sha256=sha(folder / "scaler.npz"),
                prediction_path=str(output),
                prediction_sha256=sha(output),
                new_fits=0,
            )
        )
        print(f"FROZEN_INFERENCE seed={fit['seed']} days=142", flush=True)
        del net
    pred = np.mean(all_predictions, axis=0)
    np.savez_compressed(
        state / "ENSEMBLE_PREDICTIONS.npz",
        relative=pred,
        indices=d["predict_indices"],
        decision_us=d["dates_us"][d["predict_indices"]] + DAY_US,
        symbol_order=np.array(d["symbols"]),
    )
    save(
        state / "INFERENCE_RECEIPT.json",
        dict(
            status="COMPLETE_ALL3_FROZEN_MODELS",
            fits=identities,
            new_fits=0,
            scaler_fit_count=0,
            parameter_search_count=0,
            ensemble_sha256=sha(state / "ENSEMBLE_PREDICTIONS.npz"),
            maximum_RSS_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024,
        ),
    )
    return pred


def verify_controls(protocol, state):
    source = frozen_sources(state)
    if source != json.loads(
        (Path(protocol["reference_state"]) / "WALLET_SOURCE_BINDING.json").read_text()
    ):
        raise ValueError("Matched control financial source identity changed")
    work = Path(protocol["wallet"]["market_work"])
    for name, expected in [
        ("DATASET_MANIFEST.json", protocol["data_manifest_sha256"]),
        ("SCORING_COVERAGE_AUDIT.json", protocol["coverage_sha256"]),
    ]:
        if sha(work / "reports" / name) != expected:
            raise ValueError("Tail shared market/coverage identity changed")
    controls = []
    for ref in protocol["control_results"]:
        path = Path(ref["path"])
        if sha(path) != ref["sha256"]:
            raise ValueError("Control receipt changed")
        case = json.loads(path.read_text())
        if case["task"]["window"] != protocol["window"] or case["task"]["work"] != str(work):
            raise ValueError("Control input calendar identity mismatch")
        if case["binding"]["market_input_manifest_sha256"] != protocol["data_manifest_sha256"]:
            raise ValueError("Control market manifest mismatch")
        verify_binding(
            case["task"]["native_market_binding_path"], case["task"]["native_market_binding_sha256"]
        )
        controls.append(summary_row(case, path, "REUSED_EXACT_SAME_INPUT_CSMOM_CONTROL"))
    save(state / "REUSED_CONTROLS.json", controls)
    return controls


def wallets(protocol, protocol_path, state, targets, controls, deadline):
    prior = json.loads(Path(protocol["control_results"][0]["path"]).read_text())["task"]
    tasks = []
    for scale in (1, 0.01):
        for name, target in targets.items():
            tasks.append(
                dict(
                    prior,
                    id=("fraction" if scale == 1 else "percent") + "/" + name,
                    state=str(state),
                    family="PATCH_PRICE_RANK_CPU_" + name,
                    seed="FIXED3_ENSEMBLE",
                    mapping=name,
                    funding_scale=scale,
                    target_path=target["path"],
                    target_sha256=target["sha256"],
                    protocol_sha256=sha(protocol_path),
                )
            )
    guard(state, deadline, protocol["budget"])
    cases = run_tasks(
        tasks, state, "PATCH_PRICE_RANK_TAIL_WALLETS", workers=1, protocol_path=protocol_path
    )
    rows = []
    for case in cases:
        control = next(r for r in controls if r["funding_scale"] == case["task"]["funding_scale"])
        old = json.loads(Path(control["result_path"]).read_text())
        for name in ("contract", "cost_scenario", "unit_scenario"):
            if case["summary"][name] != old["summary"][name]:
                raise ValueError("Paired financial assumptions changed")
        rows.append(
            summary_row(
                case,
                state / "native" / case["task"]["id"] / "RESULT.json",
                "NEW_FROZEN_WEIGHTS_FORWARD_TRANSFER",
            )
        )
    return rows


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--state", type=Path, required=True)
    args = parser.parse_args()
    began = time.monotonic()
    protocol = json.loads(args.protocol.read_text())
    state = args.state.resolve()
    state.mkdir(parents=True, exist_ok=True)
    deadline = began + protocol["budget"]["overall_wall_seconds"]
    check_cloud_limits({"workers": 1, "audit_device": "cpu"})
    if (state / "RUN_BUDGET.json").exists():
        raise ValueError("New module cannot reset its execution budget")
    save(
        state / "RUN_BUDGET.json",
        dict(
            started_monotonic=began,
            started_unix=time.time(),
            deadline_monotonic=deadline,
            protocol_sha256=sha(args.protocol),
            first_price_body_not_before_freeze=True,
        ),
    )
    try:
        source_identity(protocol, args.protocol.resolve(), state)
        controls = verify_controls(protocol, state)
        with requests.Session() as session:
            session.headers["User-Agent"] = "coin-bounded-frozen-tail/20261008"
            meta = metadata(protocol, args.protocol, state, deadline, session)
            d = append_inputs(protocol, args.protocol, state, deadline, session, meta)
        pred = infer(d, protocol, state, deadline)
        targets = map_targets(d, pred, protocol, state)
        rows = wallets(protocol, args.protocol, state, targets, controls, deadline)
        guard(state, deadline, protocol["budget"])
        result = dict(
            status="COMPLETE_FROZEN142DAY_FORWARD_TRANSFER_4WALLETS",
            qualification="NONE_CASH",
            cases=rows,
            reused_controls=controls,
            new_fits=0,
            new_parameter_search=0,
            scaler_reestimated=False,
            protocol_sha256=sha(args.protocol),
            elapsed_seconds=time.monotonic() - began,
            historical_seen_window=True,
            unseen_OOS=False,
            past_input_prefix_unchanged=True,
            old_price_recipe_not_restored=True,
            maximum_RSS_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024,
            owned_bytes=sum(p.stat().st_size for p in state.rglob("*") if p.is_file()),
            prior_result_sha256=protocol["prior_identity"]["results"]["sha256"],
            target_freeze_sha256=sha(state / "TARGETS_FROZEN.json"),
            input_receipt_sha256=sha(state / "INPUT_RECEIPT.json"),
            inference_receipt_sha256=sha(state / "INFERENCE_RECEIPT.json"),
        )
        save(state / "RESULTS.json", result)
        print(
            json.dumps(
                {k: result[k] for k in ("status", "elapsed_seconds", "owned_bytes", "new_fits")}
            ),
            flush=True,
        )
    except BaseException as exc:
        save(
            state / "FAILURE.json",
            dict(
                error_type=type(exc).__name__,
                error=str(exc),
                elapsed_seconds=time.monotonic() - began,
                fit_repeats=0,
            ),
        )
        raise


if __name__ == "__main__":
    main()
