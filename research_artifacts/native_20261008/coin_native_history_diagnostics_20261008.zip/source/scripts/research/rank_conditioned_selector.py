"""One frozen rank-sleeve selector mechanism check on already-seen history.

The 60-day targets are explicit quantity-accounted reference utilities with
paid entry/rebalancing/exit, not native-wallet teachers or spliced PnLs.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import time
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import polars as pl
from scipy.special import softmax
from sklearn.linear_model import Ridge
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

from modules.collector_research.pipeline.economics import interval_arrays, replay
from modules.collector_research.validation.cloud_guard import check_cloud_limits
from modules.transformer_v2.data import train_scaler
from modules.transformer_v2.portfolio import market_neutral
from modules.transformer_v3.wallet import frozen_sources, run_tasks
from scripts.investment.public_sma_perpetual import signed_risk_weights
from scripts.research.patch_price_rank_inputs import DAY_US, guard, save, sha
from scripts.research.public_cross_section_momentum import public_targets
from scripts.research.run_public_momentum import summary_row

ROOT = Path(__file__).resolve().parents[2]
CORE = ("BTCUSDT", "ETHUSDT", "SOLUSDT", "XRPUSDT", "DOGEUSDT")
FEATURES = ("normalized_rank_gap", "past_rank_turnover7", "market_volatility30", "breadth20")
ACTIONS = ("LEARNED_RANK", "FIXED_CSMOM", "CASH")
CASES = ("RANK_ALONE", "FIXED_50_50", "CONDITIONAL_SELECTOR")


def stamp(value):
    return pd.Timestamp(value).value // 1000


def require(value, message):
    if not bool(value):
        raise ValueError(message)


def bounded_path(desired, initial, max_l1=0.1):
    """Minimal portable adapter of the existing fixed convex L1 transition.

    Importing regime_ranking_screen triggers unrelated WSL-only source IO;
    the adapter retains its arithmetic, with explicit malformed-input guards.
    """
    require(np.isfinite(max_l1) and 0 < max_l1 <= 0.1, "Registered L1 bound cannot increase")
    previous = np.asarray(initial, float)
    require(
        previous.shape == (3,)
        and np.isfinite(previous).all()
        and (previous >= 0).all()
        and abs(previous.sum() - 1) < 1e-12,
        "Initial simplex allocation required",
    )
    result = []
    for value in np.asarray(desired, float):
        require(
            value.shape == previous.shape
            and np.isfinite(value).all()
            and (value >= 0).all()
            and abs(value.sum() - 1) < 1e-12,
            "Desired simplex allocation required",
        )
        distance = float(np.abs(value - previous).sum())
        scale = min(1.0, max_l1 / distance) if distance else 1.0
        current = previous + scale * (value - previous)
        result.append(current)
        previous = current
    return np.asarray(result)


def check_refs(protocol):
    for ref in protocol["input_refs"]:
        require(sha(ref["path"]) == ref["sha256"], "Registered input changed: " + ref["path"])
    for name, digest in protocol["source_refs"].items():
        require(sha(ROOT / name) == digest, "Registered source changed: " + name)


def load_inputs(protocol):
    check_refs(protocol)
    with np.load(protocol["daily_extension"], allow_pickle=False) as f:
        d = {k: f[k].copy() for k in f.files}
    with np.load(protocol["original_inputs"], allow_pickle=False) as f:
        original = {k: f[k].copy() for k in f.files}
    n, prefix = len(d["x"]), len(original["x"])
    for key in ("x", "close", "availability", "ready", "dates_us"):
        require(
            np.array_equal(d[key][:prefix], original[key], equal_nan=True),
            "Extended input changed the past prefix: " + key,
        )
    require(
        d["symbol_order"].tolist() == protocol["assets"]["input_order"],
        "Explicit ten-asset order changed",
    )
    require(np.all(np.diff(d["dates_us"]) == DAY_US), "Contiguous daily feature calendar")
    d["symbols"] = d["symbol_order"].tolist()
    columns = [d["symbols"].index(s) for s in CORE]
    cutoff = stamp(protocol["targets"]["cutoff"])
    usable = (
        original["ready"][:, columns].all(1)
        & np.isfinite(original["relative"][:, columns]).all((1, 2))
        & np.isfinite(original["regime"]).all(1)
        & (original["label_end_us"] < cutoff)
    )
    d["train_indices"] = np.flatnonzero(usable)
    require(
        len(d["train_indices"]) == 263 and d["train_indices"][0] >= 255,
        "Exact263 mature ranker dates required; no shortening",
    )
    # Do not compute or expose new scoring labels. Only admitted training labels
    # are populated; PriceSamples masks the utility supervision entirely.
    d["relative"] = np.full((n, 10, 3), np.nan, dtype="float32")
    d["regime"] = np.full((n, 3), np.nan, dtype="float32")
    ti = d["train_indices"]
    d["relative"][ti], d["regime"][ti] = original["relative"][ti], original["regime"][ti]
    d["label_end_us"] = np.full(n, np.iinfo(np.int64).max, dtype=np.int64)
    d["label_end_us"][ti] = original["label_end_us"][ti]
    decision = d["dates_us"] + DAY_US
    d["predict_indices"] = np.flatnonzero(
        (decision >= stamp(protocol["rank_predict_start"])) & (decision < protocol["window"]["end"])
    )
    require(
        decision[d["predict_indices"][0]] > cutoff
        and not np.intersect1d(ti, d["predict_indices"]).size,
        "Same earlier frozen ranker must precede every selector sample",
    )
    d["utility"] = [np.zeros((n, 10, 2), dtype="float32")]
    return d


def native_context(protocol, key):
    root = Path(protocol[key]["market_work"])
    frames = {
        s: pl.read_parquet(root / "data/normalized" / (s + "_daily.parquet"))
        .sort("available_us")
        .to_pandas()
        for s in CORE
    }
    available = frames[CORE[0]].available_us.to_numpy(np.int64)
    close = np.column_stack([frames[s].close.to_numpy(float) for s in CORE])
    require(np.all(np.diff(available) == DAY_US), "Native daily calendar has a gap")
    for s in CORE:
        require(np.array_equal(frames[s].available_us, available), "CORE5 native clock mismatch")
    with np.load(protocol[key]["csmom_target"], allow_pickle=False) as f:
        dates, weights = f["decision_us"].copy(), f["weights"].copy()
        require(f["symbol_order"].tolist() == list(CORE), "CSMOM allocation order changed")
    generated, _ = public_targets(close, available, dates, CORE, CORE)
    require(np.array_equal(weights, generated), "CSMOM is not byte-matched to its causal recipe")
    return frames, available, close, dates, weights


def reference_maturity(decisions, horizon=60):
    require(horizon == 60, "Fixed60day label horizon cannot change")
    # End execution boundary + completed00:01 source bar + strict microsecond.
    return np.asarray(decisions, dtype=np.int64) + 60 * DAY_US + 120_000_001


def selector_calendar(protocol):
    dates = np.arange(
        stamp(protocol["selector"]["train_start"]),
        stamp(protocol["selector"]["train_end_exclusive"]),
        DAY_US,
        dtype=np.int64,
    )
    maturity = reference_maturity(dates)
    cutoff = protocol["window"]["start"] - 60 * DAY_US
    require(
        len(dates) == 104 and np.all(maturity < cutoff),
        "Exact104 complete labels must mature strictly before60day embargo",
    )
    return dates, maturity, cutoff


def admit(protocol, protocol_path, state):
    d = load_inputs(protocol)
    indices = d["train_indices"]
    scaler = train_scaler(d["x"], d["availability"], indices)
    dates, maturity, cutoff = selector_calendar(protocol)
    native = {}
    columns = [d["symbols"].index(s) for s in CORE]
    for key in ("training_wallet", "wallet"):
        frames, available, close, own, _ = native_context(protocol, key)
        direct_rows = np.searchsorted(d["dates_us"] + DAY_US, own)
        native_rows = np.searchsorted(available, own)
        require(np.array_equal(d["dates_us"][direct_rows] + DAY_US, own), "Exact direct clock")
        require(
            np.array_equal(d["close"][direct_rows][:, columns], close[native_rows]),
            "Direct daily closes differ from bound native minute-source closes",
        )
        native[key] = dict(
            byte_exact_CSMOM=True,
            direct_native_close_equal=True,
            daily_dates=len(available),
            decision_dates=len(own),
        )
        if key == "training_wallet":
            rows = np.searchsorted(available, dates)
            require(np.array_equal(available[rows], dates), "Selector dates absent from H1 source")
            # Require every day, asset, funding interval and future executable
            # endpoint of every overlapping block, before any model is fitted.
            whole = np.arange(rows[0], rows[-1] + 60)
            for s in CORE:
                arrays = interval_arrays(frames[s], whole, 1)
                require(
                    all(np.isfinite(a).all() for a in arrays[:3]) and arrays[3].all(),
                    "Missing exact60day held price/funding interval: " + s,
                )
            native[key]["last_execution_endpoint_day"] = str(frames[CORE[0]].dt.iloc[whole[-1] + 2])
    result = dict(
        status="PASS_FROZEN_CALENDAR_AND_COST_INPUT_ADMISSION_NO_FITS",
        protocol_sha256=sha(protocol_path),
        ranker_training_days=len(indices),
        first_ranker_feature_day=str(
            pd.Timestamp(int(d["dates_us"][indices[0]]), unit="us", tz="UTC")
        ),
        last_ranker_feature_day=str(
            pd.Timestamp(int(d["dates_us"][indices[-1]]), unit="us", tz="UTC")
        ),
        ranker_max_label_end_us=int(d["label_end_us"][indices].max()),
        ranker_scaler_max_feature_available_us=int(d["dates_us"][indices].max() + DAY_US),
        ranker_scaler_columns=len(scaler[0]),
        scaler_finite=bool(np.isfinite(scaler).all()),
        selector_training_rows=len(dates),
        selector_first_decision_us=int(dates[0]),
        selector_last_decision_us=int(dates[-1]),
        selector_max_label_mature_us=int(maturity[-1]),
        selector_label_cutoff_exclusive_us=int(cutoff),
        native=native,
        features=list(FEATURES),
        ridge_alpha=30,
        new_fits=0,
        new_downloads=0,
        independent_60day_nonoverlapping_blocks_at_most=2,
        warning="104 overlapping rows are not104 independent observations; very few regimes",
        same_earlier_frozen_ranker_for_selector_train_and_score=True,
        no_scoring_labels_computed=True,
    )
    save(state / "ADMISSION.json", result)
    return result


def raw_rank_weights(scores):
    values = np.asarray(scores, dtype=float)
    require(
        values.ndim == 2 and values.shape[1] == 5 and np.isfinite(values).all(),
        "Five ordered finite ranking scores required",
    )
    return market_neutral(values, np.ones(values.shape, bool), k=2, gross=0.6)


def causal_features(d, scores):
    indices = d["predict_indices"]
    require(scores.shape == (len(indices), 5), "Prediction/feature row alignment")
    raw = raw_rank_weights(scores)
    ordered = np.sort(scores, axis=1)
    gap = ordered[:, -2:].mean(1) - ordered[:, :2].mean(1)
    sd = scores.std(1, ddof=0)
    gap = np.divide(gap, sd, out=np.zeros_like(gap), where=sd > 1e-12)
    out = np.full((len(indices), len(FEATURES)), np.nan)
    core = [d["symbols"].index(s) for s in CORE]
    for row in range(7, len(indices)):
        i = int(indices[row])
        require(np.all(np.diff(indices[row - 7 : row + 1]) == 1), "Past rank turnover calendar gap")
        history = d["close"][i - 30 : i + 1][:, core]
        require(
            history.shape == (31, 5) and np.isfinite(history).all() and (history > 0).all(),
            "Exactly30 past CORE5 daily returns required",
        )
        returns = np.diff(history, axis=0) / history[:-1]
        turnover = np.abs(np.diff(raw[row - 7 : row + 1], axis=0)).sum(1).mean() / 1.2
        volatility = returns.mean(1).std(ddof=1) * np.sqrt(365)
        breadth = np.mean(history[-1] / history[-21] - 1 > 0)
        out[row] = (gap[row], turnover, volatility, breadth)
    return out, raw


def map_sleeves(d, scores, protocol, key):
    frames, available, close, dates, csmom = native_context(protocol, key)
    pred_dates = d["dates_us"][d["predict_indices"]] + DAY_US
    own = np.searchsorted(pred_dates, dates)
    require(np.array_equal(pred_dates[own], dates), "Every native sleeve date needs frozen scores")
    rank = raw_rank_weights(scores[own])
    result = np.zeros((len(dates), 3, 5))
    result[:, 1] = csmom
    for row, decision in enumerate(dates):
        j = int(np.searchsorted(available, decision))
        require(j >= 30 and available[j] == decision, "Exact30 past native risk returns")
        history = close[j - 30 : j + 1]
        returns = np.diff(history, axis=0) / history[:-1]
        result[row, 0], _ = signed_risk_weights(rank[row], returns)
    return frames, available, close, dates, result


def reference_utilities(frames, available, dates, sleeves, training_dates, side_cost=0.00135):
    require(side_cost == 0.00135, "BASE27 half-side cost cannot change")
    labels = np.zeros((len(training_dates), 3))
    for row, decision in enumerate(training_dates):
        i = int(np.searchsorted(dates, decision))
        j = int(np.searchsorted(available, decision))
        require(
            dates[i] == available[j] == decision and i + 60 <= len(dates),
            "Complete60day reference follow path required",
        )
        for sleeve in (0, 1):
            metrics, _ = replay(
                frames,
                np.arange(j, j + 60),
                sleeves[i : i + 60, sleeve],
                scale=1,
                cost=side_cost,
                capital=10000.0,
            )
            require(
                metrics["final_positions"] == 0 and metrics["terminal_fee"] >= 0,
                "Reference utility must charge and close owned quantity",
            )
            labels[row, sleeve] = metrics["net_return"]
    require(np.isfinite(labels).all(), "Unknown utility labels cannot be imputed or dropped")
    return labels


def allocation_paths(prediction):
    require(
        prediction.ndim == 2 and prediction.shape[1] == 3 and np.isfinite(prediction).all(),
        "Three finite utility outputs required",
    )
    n = len(prediction)
    desired = {
        "RANK_ALONE": np.tile((1.0, 0.0, 0.0), (n, 1)),
        "FIXED_50_50": np.tile((0.5, 0.5, 0.0), (n, 1)),
        "CONDITIONAL_SELECTOR": softmax(prediction / 0.02, axis=1),
    }
    return {
        name: bounded_path(value, np.array((0.0, 0.0, 1.0)), 0.1) for name, value in desired.items()
    }


def final_targets(allocations, sleeves, available, close, dates):
    require(allocations.shape == sleeves.shape[:2], "Common three-sleeve allocation shape")
    weights = np.einsum("ij,ijk->ik", allocations, sleeves)
    for row, decision in enumerate(dates):
        j = int(np.searchsorted(available, decision))
        require(j >= 30 and available[j] == decision, "Final risk map exact past clock")
        history = close[j - 30 : j + 1]
        weights[row], _ = signed_risk_weights(weights[row], np.diff(history, axis=0) / history[:-1])
    require(
        np.isfinite(weights).all()
        and np.abs(weights).max() <= 0.3 + 1e-12
        and np.abs(weights).sum(1).max() <= 0.6 + 1e-12,
        "Financial target cap breach",
    )
    return weights


def freeze_code(protocol_path, state):
    paths = [Path(__file__), protocol_path]
    refs = {}
    for path in paths:
        name = str(path.relative_to(ROOT))
        raw = subprocess.check_output(["git", "-C", str(ROOT), "show", "HEAD:" + name])
        require(
            hashlib.sha256(raw).hexdigest() == sha(path), "Commit exact selector sources: " + name
        )
        refs[name] = sha(path)
    save(
        state / "SELECTOR_SOURCE_BINDING.json",
        dict(
            source_HEAD=subprocess.check_output(
                ["git", "-C", str(ROOT), "rev-parse", "HEAD"], text=True
            ).strip(),
            sources=refs,
        ),
    )


def run(protocol, protocol_path, state):
    check_cloud_limits({"workers": 1, "audit_device": "cpu"})
    require(
        not (state / "STARTED.json").exists(), "Inspect partial/completed run; no duplicate fits"
    )
    admission = admit(protocol, protocol_path, state)
    freeze_code(protocol_path, state)
    began = time.monotonic()
    deadline = began + 1800
    save(
        state / "RUN_BUDGET.json",
        dict(
            started_monotonic=began,
            deadline_monotonic=deadline,
            protocol_sha256=sha(protocol_path),
            wall_seconds=1800,
        ),
    )
    save(state / "STARTED.json", dict(protocol_sha256=sha(protocol_path), started_unix=time.time()))
    try:
        from scripts.research.patch_price_rank_cpu import freeze_sources, train

        freeze_sources(protocol_path, state)
        d = load_inputs(protocol)
        np.savez_compressed(
            state / "INPUTS.npz", **{k: v for k, v in d.items() if k not in ("symbols", "utility")}
        )
        save(
            state / "INPUT_RECEIPT.json",
            dict(
                status="REUSED_DIRECT_DAILY_INPUTS_WITH_PAST_ONLY_EARLIER_TRAINING_LABEL_VIEW",
                input_npz_sha256=sha(state / "INPUTS.npz"),
                protocol_sha256=sha(protocol_path),
                source_inputs=protocol["input_refs"],
                training_labels_only=True,
                no_new_scoring_labels=True,
            ),
        )
        fits_started = time.monotonic()
        ensemble = train(d, protocol, protocol_path, state, min(deadline, fits_started + 600))
        guard(state, min(deadline, fits_started + 600), protocol["budget"])
        core = [d["symbols"].index(s) for s in CORE]
        scores = ensemble[:, core, 1]
        features, _ = causal_features(d, scores)
        training_dates, maturity, cutoff = selector_calendar(protocol)
        pred_dates = d["dates_us"][d["predict_indices"]] + DAY_US
        train_rows = np.searchsorted(pred_dates, training_dates)
        require(
            np.array_equal(pred_dates[train_rows], training_dates)
            and np.isfinite(features[train_rows]).all(),
            "Every registered training feature required",
        )
        context = map_sleeves(d, scores, protocol, "training_wallet")
        labels = reference_utilities(context[0], context[1], context[3], context[4], training_dates)
        guard(state, deadline, protocol["budget"])
        estimator = make_pipeline(StandardScaler(), Ridge(alpha=30))
        estimator.fit(features[train_rows], labels)
        joblib.dump(estimator, state / "SELECTOR.joblib")
        np.savez_compressed(
            state / "SELECTOR_TRAINING.npz",
            features=features[train_rows],
            labels=labels,
            decision_us=training_dates,
            label_mature_us=maturity,
            feature_order=np.array(FEATURES),
            actions=np.array(ACTIONS),
        )
        frames, available, close, dates, sleeves = map_sleeves(d, scores, protocol, "wallet")
        score_rows = np.searchsorted(pred_dates, dates)
        require(
            np.array_equal(pred_dates[score_rows], dates)
            and len(dates) == 142
            and np.isfinite(features[score_rows]).all(),
            "Full142day frozen score features required",
        )
        prediction = estimator.predict(features[score_rows])
        np.savez_compressed(
            state / "SELECTOR_PREDICTIONS.npz",
            features=features[score_rows],
            prediction=prediction,
            decision_us=dates,
            sleeves=sleeves,
            feature_order=np.array(FEATURES),
            actions=np.array(ACTIONS),
        )
        scaler, head = estimator.steps[0][1], estimator.steps[1][1]
        np.savez_compressed(
            state / "SELECTOR_PARAMETERS.npz",
            scaler_mean=scaler.mean_,
            scaler_scale=scaler.scale_,
            coef=head.coef_,
            intercept=head.intercept_,
        )
        paths = allocation_paths(prediction)
        targets = {}
        for name, allocation in paths.items():
            path = state / "targets" / (name + ".npz")
            path.parent.mkdir(exist_ok=True)
            weights = final_targets(allocation, sleeves, available, close, dates)
            np.savez_compressed(
                path,
                weights=weights,
                decision_us=dates,
                symbol_order=np.array(CORE),
                sleeve_allocation=allocation,
            )
            targets[name] = dict(path=str(path), sha256=sha(path))
        save(
            state / "TARGETS_FROZEN.json",
            dict(
                status="ALL3_TARGETS_BEFORE_FIRST_WALLET",
                targets=targets,
                common_prediction_sha256=sha(state / "SELECTOR_PREDICTIONS.npz"),
            ),
        )
        frozen_sources(state)
        prior = json.loads(Path(protocol["control_results"][0]["path"]).read_text())["task"]
        tasks = [
            dict(
                prior,
                id=("fraction" if scale == 1 else "percent") + "/" + name,
                state=str(state),
                family=name,
                seed="FIXED3_RANK_PLUS_RIDGE30",
                mapping=name,
                funding_scale=scale,
                target_path=target["path"],
                target_sha256=target["sha256"],
                protocol_sha256=sha(protocol_path),
            )
            for scale in (1, 0.01)
            for name, target in targets.items()
        ]
        guard(state, deadline, protocol["budget"])
        cases = run_tasks(
            tasks, state, "RANK_SELECTOR_WALLETS", workers=1, protocol_path=protocol_path
        )
        guard(state, deadline, protocol["budget"])
        rows = [
            summary_row(
                c,
                state / "native" / c["task"]["id"] / "RESULT.json",
                "NEW_INTEGRATED_SELECTOR_SEEN_HISTORY",
            )
            for c in cases
        ]
        controls = [
            summary_row(
                json.loads(Path(ref["path"]).read_text()),
                Path(ref["path"]),
                "REUSED_BYTE_MATCHED_CSMOM",
            )
            for ref in protocol["control_results"]
        ]
        for case in cases:
            control = json.loads(
                Path(
                    next(
                        r["result_path"]
                        for r in controls
                        if r["funding_scale"] == case["task"]["funding_scale"]
                    )
                ).read_text()
            )
            for field in ("contract", "cost_scenario", "unit_scenario"):
                require(
                    case["summary"][field] == control["summary"][field],
                    "Paired wallet assumptions changed",
                )
        result = dict(
            status="COMPLETE3_FIXED_RANK_FITS1_SELECTOR_FIT6_WALLETS",
            qualification="NONE_CASH",
            admission=admission,
            cases=rows,
            controls=controls,
            selector_fit_count=1,
            ranker_fit_count=3,
            parameter_search_count=0,
            new_downloads=0,
            protocol_sha256=sha(protocol_path),
            elapsed_seconds=time.monotonic() - began,
            shared_primary_selector_for_both_funding_scales=True,
            allocation_summary={
                name: dict(
                    mean=path.mean(0).tolist(),
                    minimum=path.min(0).tolist(),
                    maximum=path.max(0).tolist(),
                    total_L1=float(
                        np.abs(np.diff(np.vstack(((0.0, 0.0, 1.0), path)), axis=0)).sum()
                    ),
                )
                for name, path in paths.items()
            },
        )
        save(state / "RESULTS.json", result)
        return result
    except BaseException as exc:
        save(
            state / "FAILURE.json",
            dict(
                error_type=type(exc).__name__,
                error=str(exc),
                elapsed_seconds=time.monotonic() - began,
                preserved_partial_artifacts=True,
                no_automatic_refit=True,
            ),
        )
        raise


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--state", type=Path, required=True)
    parser.add_argument("--admit-only", action="store_true")
    args = parser.parse_args()
    protocol = json.loads(args.protocol.read_text())
    require(
        protocol["selector"]["features"] == list(FEATURES)
        and protocol["selector"]["ridge_alpha"] == 30,
        "Exact four columns/alpha30 required",
    )
    args.state.mkdir(parents=True, exist_ok=True)
    result = (
        admit(protocol, args.protocol, args.state)
        if args.admit_only
        else run(protocol, args.protocol, args.state)
    )
    print(
        json.dumps(
            result
            if args.admit_only
            else {k: result[k] for k in ("status", "elapsed_seconds", "allocation_summary")}
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
