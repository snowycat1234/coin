"""One same-source metadata interruption retry, retaining the original deadline."""

import argparse
import json
import time
from pathlib import Path

import requests

from modules.collector_research.validation.cloud_guard import check_cloud_limits
from scripts.research.patch_price_rank_inputs import guard, save, sha
from scripts.research.patch_price_rank_tail import (
    append_inputs,
    infer,
    map_targets,
    metadata,
    source_identity,
    verify_controls,
    wallets,
)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--protocol", type=Path, required=True)
    p.add_argument("--state", type=Path, required=True)
    a = p.parse_args()
    protocol = json.loads(a.protocol.read_text())
    budget = json.loads((a.state / "RUN_BUDGET.json").read_text())
    failure = json.loads((a.state / "FAILURE.json").read_text())
    if (
        failure["error_type"] != "ReadTimeout"
        or (a.state / "INPUT_ADMISSION.json").exists()
        or (a.state / "METADATA_RETRY.json").exists()
        or sha(a.protocol) != budget["protocol_sha256"]
    ):
        raise ValueError("Only one pre-body metadata ReadTimeout retry allowed")
    deadline = budget["deadline_monotonic"]
    check_cloud_limits({"workers": 1, "audit_device": "cpu"})
    guard(a.state, deadline, protocol["budget"])
    save(
        a.state / "METADATA_RETRY.json",
        dict(
            original_failure_sha256=sha(a.state / "FAILURE.json"),
            original_deadline_monotonic=deadline,
            budget_reset=False,
            same_source_only=True,
            retry_launcher_sha256=sha(__file__),
            additional_fits=0,
        ),
    )
    source_identity(protocol, a.protocol.resolve(), a.state)
    controls = verify_controls(protocol, a.state)
    try:
        with requests.Session() as session:
            session.headers["User-Agent"] = "coin-bounded-frozen-tail/20261008"
            meta = metadata(protocol, a.protocol, a.state, deadline, session)
            d = append_inputs(protocol, a.protocol, a.state, deadline, session, meta)
        pred = infer(d, protocol, a.state, deadline)
        targets = map_targets(d, pred, protocol, a.state)
        rows = wallets(protocol, a.protocol, a.state, targets, controls, deadline)
        guard(a.state, deadline, protocol["budget"])
        result = dict(
            status="COMPLETE_FROZEN142DAY_FORWARD_TRANSFER_4WALLETS",
            qualification="NONE_CASH",
            cases=rows,
            reused_controls=controls,
            new_fits=0,
            new_parameter_search=0,
            scaler_reestimated=False,
            protocol_sha256=sha(a.protocol),
            elapsed_seconds=time.monotonic() - budget["started_monotonic"],
            historical_seen_window=True,
            unseen_OOS=False,
            past_input_prefix_unchanged=True,
            old_price_recipe_not_restored=True,
            owned_bytes=sum(p.stat().st_size for p in a.state.rglob("*") if p.is_file()),
            prior_result_sha256=protocol["prior_identity"]["results"]["sha256"],
            target_freeze_sha256=sha(a.state / "TARGETS_FROZEN.json"),
            input_receipt_sha256=sha(a.state / "INPUT_RECEIPT.json"),
            inference_receipt_sha256=sha(a.state / "INFERENCE_RECEIPT.json"),
        )
        save(a.state / "RESULTS.json", result)
        print(
            json.dumps({k: result[k] for k in ("status", "elapsed_seconds", "owned_bytes")}),
            flush=True,
        )
    except BaseException as exc:
        save(
            a.state / "RETRY_FAILURE.json",
            dict(
                error_type=type(exc).__name__,
                error=str(exc),
                elapsed_seconds=time.monotonic() - budget["started_monotonic"],
                fit_repeats=0,
            ),
        )
        raise


if __name__ == "__main__":
    main()
