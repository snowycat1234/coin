"""Read-only economic decision and compact publication for a completed fit."""
import argparse, hashlib, json
from pathlib import Path
from datetime import UTC, datetime
from quant.paths import ROOT

def sha(p):
    with Path(p).open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()

def write(p,v):
    with Path(p).open('x',encoding='utf-8') as f:
        json.dump(v,f,indent=2,ensure_ascii=False,allow_nan=False); f.write('\n')

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--actual',type=Path,required=True)
    ap.add_argument('--output',type=Path,required=True)
    ap.add_argument('--document',type=Path,required=True)
    a=ap.parse_args(); r=json.loads(a.actual.read_bytes())
    is_anchor=r['status']=='COMPLETE_FIXED_PAST_TREND_GATE_NEW4_REUSED16_CONDITIONAL_PROXY'
    is_short=is_anchor and r['protocol']['regime'].get('direction_mode')=='SHORT_ONLY'
    is_retry=is_short and 'cash_close_retry' in r['protocol']
    short_strategy='XGB_TREND_SHORT_PERSISTENT_CASH' if is_retry else 'XGB_TREND_SHORT_ONLY'
    is_regime=is_anchor or r['status']=='COMPLETE_FIXED_DIRECTION_REGIME_PAIRED_ECONOMICS_CONDITIONAL_PROXY'
    assert is_regime or r['status']=='COMPLETE_ONE_SHARED_FIT_MATCHED_DIRECTION_AND_RULE_ECONOMICS_CONDITIONAL_PROXY'
    new_accounts=len(r['cases']); control_proof=None
    if is_anchor:
        assert new_accounts==r['required_accounts']==4
        control_proof=dict(r['control_reuse'])
        assert control_proof['probability_golden']=='PASS_EXACT_1220_ROWS'
        assert sha(control_proof['path'])==control_proof['sha256']
        prior=json.loads(Path(control_proof['path']).read_bytes())
        for c in prior['cases']: c['account_evidence']='REUSED_ACCEPTED_D086_BY_SHA_NO_RESIMULATION'
        if is_short:
            extra=r['extra_control_reuse']
            assert sha(extra['path'])==extra['sha256']
            additional=json.loads(Path(extra['path']).read_bytes())
            assert len(additional['cases'])==4
            for c in additional['cases']: c['account_evidence']='REUSED_ACCEPTED_D087_BY_SHA_NO_RESIMULATION'
            prior['cases']+=additional['cases'];control_proof['additional_fixed_trend_report']=extra
        if is_retry:
            extra=r['execution_control_reuse']
            assert sha(extra['path'])==extra['sha256']
            additional=json.loads(Path(extra['path']).read_bytes())
            assert len(additional['cases'])==4
            for c in additional['cases']: c['account_evidence']='REUSED_ACCEPTED_D088_BY_SHA_ONLY_CASH_RETRY_DIFFERS'
            prior['cases']+=additional['cases'];control_proof['original_cash_retry_control']=extra
        # Preserve old evidence; only regroup its recorded daily contributions.
        import polars as pl
        states_by_day={row['available_us']:row['regime'] for row in
            pl.read_parquet(Path(r['run_dir'])/'market_regimes.parquet').iter_rows(named=True)}
        for c in prior['cases']:
            check=c['independent']
            if c['account_evidence']=='REUSED_ACCEPTED_D086_BY_SHA_NO_RESIMULATION':
                check['original_GMM_state_contributions']=check['by_learned_regime']
            grouped={}
            for day in check['daily_direction_contributions']:
                label=states_by_day[day['day_end_us']-86_400_000_000]
                v=grouped.setdefault(label,dict(days=0,LONG=0.,SHORT=0.,CASH=0.,net=0.))
                v['days']+=1
                for key in ('LONG','SHORT','CASH'): v[key]+=day[key]
                v['net']+=day['LONG']+day['SHORT']
            check['by_learned_regime']=grouped
        r['cases']=prior['cases']+r['cases']
    accounts=28 if is_retry else 24 if is_short else 20 if is_anchor else 16 if is_regime else 20
    days=122 if is_regime else 61
    assert len(r['cases'])==accounts and (is_anchor or r['required_accounts']==accounts)
    if is_regime:
        assert r['models_fit']==0 and r['regime_fit']['regime_fits']==r['regime_fit']['normalizer_fits']==(0 if is_anchor else 1)
        assert r['default_prediction_golden']=='PASS_EXACT_D085_MAY_JUNE_PROBABILITIES_AND_LABELS'
        assert len(r['default_target_golden'])==3
        import numpy as np
        import polars as pl
        states=pl.read_parquet(Path(r['run_dir'])/'market_regimes.parquet')
        regime_by_day=dict(zip(states['available_us'],states['regime'],strict=True))
    for p,digest in r['binding']['source_hashes'].items(): assert sha(ROOT/p)==digest,p
    rows=[]; byid={}
    for c in r['cases']:
        for artifact in c['artifacts'].values(): assert sha(artifact['path'])==artifact['sha256']
        s=c['summary']; check=c['independent']
        assert s['completed_minutes']==s['required_minutes']==days*1440 and check['minutes']==days*1440
        assert check['status']=='PASS_INDEPENDENT_SIGNED_JOURNAL_MINUTE_MARKED_NAV_FUNDING_AND_WALLET_IDENTITY'
        assert s['cost_scenario']['provenance']['fee_source_sha256']=='a406d4bd0e47ff4ae4895fda0a2f2698b5763667d82b22b7f264d6220e27e8bd'
        assert abs(sum(v['net'] for v in check['by_past_regime'].values())-s['net_PnL'])<1e-7
        dm=s['daily_metrics']; ex=s['realized_exposure']
        row=dict(id=c['id'],strategy=c['strategy'],cost=c['cost_id'],unit=c['unit_id'],
            net_USDT=s['net_PnL'],gross_USDT=s['gross_PnL_same_quantities'],fee_USDT=s['fees_USDT'],
            spread_USDT=s['spread_cost_USDT'],slippage_USDT=s['slippage_cost_USDT'],funding_USDT=s['funding_USDT'],
            LONG_USDT=s['long_short_marked_contribution']['LONG']['net_contribution'],
            SHORT_USDT=s['long_short_marked_contribution']['SHORT']['net_contribution'],CASH_USDT=0.,
            turnover=s['normalized_total_turnover'],fill_legs=s['trade_legs'],short_open_legs=check['actual_short_open_legs'],
            daily_annualized_volatility=dm['annual_volatility'],daily_sharpe=dm['sharpe'],
            minute_max_drawdown=s['minute_max_drawdown'],mean_gross=ex['minute_mean_gross_weight'],
            mean_net=ex['minute_mean_net_signed_weight'],max_gross=s['maximum_actual_gross_weight'],
            mean_collateral_over_initial_capital=ex['minute_mean_isolated_collateral_over_initial_capital'],
            max_collateral_over_initial_capital=ex['minute_max_isolated_collateral_over_initial_capital'],
            liquidated=s['terminal_cash_realized'],residual_marked_notional=s['terminal_marked_notional'],
            by_past_regime=check['by_past_regime'],by_learned_regime=check.get('by_learned_regime'),
            account_evidence=c.get('account_evidence','NEW_COMPLETE_REPLAY'),
            original_GMM_state_contributions=check.get('original_GMM_state_contributions'),
            daily_gain_concentration=s['daily_net_gain_concentration'])
        if is_regime:
            assert abs(sum(v['net'] for v in check['by_learned_regime'].values())-s['net_PnL'])<1e-7
            if c['strategy'].startswith('XGB'):
                assert check['target_reference']['status'].startswith('PASS')
            minute=pl.read_parquet(c['artifacts']['minute_nav_inventory.parquet']['path'])
            notionals=minute.select([symbol+'_signed_marked_notional' for symbol in r['protocol']['symbols']]).to_numpy()
            if c['strategy'] in ('XGB_TREND_SHORT_ONLY','XGB_TREND_SHORT_PERSISTENT_CASH'):
                assert (minute.select([symbol+'_quantity' for symbol in r['protocol']['symbols']]).to_numpy()<=0).all()
                assert row['LONG_USDT']==0
                row['short_only_inventory_reference']='PASS_ALL_MINUTES_NO_POSITIVE_BASE_QUANTITY'
            nav=minute['nav'].to_numpy()
            gross=np.abs(notionals).sum(axis=1)/nav; net=notionals.sum(axis=1)/nav
            day_start=((minute['close_us'].to_numpy()-1)//86_400_000_000)*86_400_000_000
            labels=np.asarray([regime_by_day[int(day)] for day in day_start])
            row['actual_exposure_by_learned_regime']={}
            for label in r['regime_counts']:
                mask=labels==label
                if not mask.any(): continue
                row['actual_exposure_by_learned_regime'][label]=dict(minutes=int(mask.sum()),
                    mean_gross=float(gross[mask].mean()),max_gross=float(gross[mask].max()),
                    mean_net=float(net[mask].mean()),min_net=float(net[mask].min()),max_net=float(net[mask].max()),
                    exactly_flat_minutes=int((gross[mask]==0).sum()))
            if is_retry and c['strategy'] in ('XGB_TREND_SHORT_ONLY','XGB_TREND_SHORT_PERSISTENT_CASH'):
                targets=pl.read_parquet(c['artifacts']['targets.parquet']['path'])
                zeros={(v['available_us'],v['symbol']) for v in targets.iter_rows(named=True) if v['target_weight']==0}
                quantities=minute.select([s+'_quantity' for s in r['protocol']['symbols']]).to_numpy()
                requested_cash_unflat=sum(int(((quantities[:,i]!=0)&np.isin(day_start,[t for t,s in zeros if s==symbol])).sum())
                    for i,symbol in enumerate(r['protocol']['symbols']))
                trades=json.loads(Path(c['artifacts']['trades.json']['path']).read_bytes())
                close_legs=[v for v in trades if v['leg']=='CLOSE' and (v['signal_us'],v['symbol']) in zeros]
                row['cash_close_diagnostics']=dict(zero_target_unflat_asset_minutes=requested_cash_unflat,
                    zero_target_close_legs=len(close_legs),
                    close_legs_after_five_minutes=sum(v['event_us']-v['signal_us']>300_000_001 for v in close_legs),
                    max_signal_to_close_fill_minutes=max(((v['event_us']-v['signal_us'])/60_000_000 for v in close_legs),default=None),
                    scope='RECORDED_DAILY_ZERO_TARGETS_AND_ACTUAL_Q/FILLS; TERMINAL_AND_RISK_SUPERSESSION_REMAIN_POSSIBLE')
                if c['strategy']==short_strategy:
                    assert s['cash_close_retry_policy']==r['protocol']['cash_close_retry']['policy']
            del minute,notionals,nav,gross,net,labels
            if is_short and c['strategy'] in ('XGB_TREND_SHORT_ONLY','XGB_TREND_SHORT_PERSISTENT_CASH'):
                rejections=json.loads(Path(c['artifacts']['rejections.json']['path']).read_bytes())
                expired=[v for v in rejections if v.get('reason')=='FIVE_ATTEMPTS_EXPIRED']
                targets=pl.read_parquet(c['artifacts']['targets.parquet']['path'])
                target_by_time={(v['available_us'],v['symbol']):v['target_weight'] for v in targets.iter_rows(named=True)}
                cash_expired=[]
                for v in expired:
                    day=((v['event_us']-1)//86_400_000_000)*86_400_000_000
                    if (v.get('kind')=='DAILY_TARGET' and 0<v['event_us']-day<=300_000_001
                            and target_by_time.get((day,v['symbol']))==0
                            and v['remaining_signed_quantity']>0):
                        cash_expired.append(v)
                row['expired_target_attempts']=dict(total=len(expired),
                    by_symbol={s:sum(v.get('symbol')==s for v in expired) for s in r['protocol']['symbols']},
                    zero_target_short_close_expiries=len(cash_expired),
                    zero_target_expiry_events=cash_expired,
                    semantics='RECORDED_FIVE_ATTEMPT_EXPIRY; NOT_EACH_RECORD_A_CASH_EXIT')
        assert abs(row['LONG_USDT']+row['SHORT_USDT']-row['net_USDT'])<1e-7
        assert abs(row['gross_USDT']-row['fee_USDT']-row['spread_USDT']-row['slippage_USDT']+row['funding_USDT']-row['net_USDT'])<1e-7
        rows.append(row); byid[(c['strategy'],c['cost_id'],c['unit_id'])]=row
    # Asset PnL attribution uses the real signed legs and remaining marked
    # inventory; this is neither independent full-capital coin accounts nor a
    # claim that the strategy cause of each profit is identified.
    asset_rows=[]
    symbols=r['protocol']['symbols']
    for c in r['cases']:
        ledger={s:dict(gross=0.,fee=0.,execution=0.,funding=0.,legs=0) for s in symbols}
        trades=json.loads(Path(c['artifacts']['trades.json']['path']).read_bytes())
        funds=json.loads(Path(c['artifacts']['funding.json']['path']).read_bytes())
        for t in trades:
            v=ledger[t['symbol']]; v['gross']-=t['position_delta']*t['mid_price']
            v['fee']+=t['fee_USDT_mid']; v['execution']+=t['execution_cost']; v['legs']+=1
        for f in funds: ledger[f['symbol']]['funding']+=f['signed_funding_USDT']
        for s,v in ledger.items():
            v['gross']+=c['summary']['terminal_signed_marked_notional'][s]
            v['net']=v['gross']-v['fee']-v['execution']+v['funding']
            asset_rows.append(dict(case_id=c['id'],symbol=s,**v))
        assert abs(sum(v['net'] for v in ledger.values())-c['summary']['net_PnL'])<1e-7
    comparisons=[]
    for cost in ('BASE27','STRESS43'):
        for unit in ('RAW_AS_FRACTION','RAW_AS_PERCENT'):
            ls=byid[(short_strategy if is_short else 'XGB_TREND_GATED' if is_anchor else 'XGB_REGIME_GATED' if is_regime else 'XGB_LONG_SHORT',cost,unit)]
            lo=byid[('XGB_TREND_SHORT_ONLY' if is_retry else 'XGB_TREND_GATED' if is_short else 'XGB_REGIME_GATED' if is_anchor else 'XGB_LONG_SHORT' if is_regime else 'XGB_LONG_ONLY',cost,unit)]
            benefit=(ls['net_USDT']>lo['net_USDT']+1e-7 or ls['minute_max_drawdown']<lo['minute_max_drawdown']-1e-10
                or ls['daily_sharpe'] is not None and lo['daily_sharpe'] is not None and ls['daily_sharpe']>lo['daily_sharpe']+1e-10)
            comparisons.append(dict(cost=cost,unit=unit,net_delta_USDT=ls['net_USDT']-lo['net_USDT'],
                DD_delta=ls['minute_max_drawdown']-lo['minute_max_drawdown'],vol_delta=ls['daily_annualized_volatility']-lo['daily_annualized_volatility'],
                either_predeclared_benefit=benefit,short_contribution_positive=ls['SHORT_USDT']>0,
                comparator=lo['strategy'],challenger=ls['strategy'],
                bear_short_contribution_USDT=ls['by_learned_regime'].get('BEAR',{}).get('SHORT',0.) if is_regime else None,
                scope='PAIRED_MARKED_NAV_NOT_SUM_OF_INDEPENDENT_LONG_AND_SHORT_WALLETS'))
    decision='RETAIN_FOR_RESEARCH_NOT_INVESTMENT' if all(c['either_predeclared_benefit'] for c in comparisons) else 'PAUSE_THIS_FIXED_RECIPE'
    if is_short and not all(x['net_USDT']>0 for x in rows if x['strategy']==short_strategy):
        decision='PAUSE_THIS_FIXED_RECIPE'
    if is_retry:
        # Testing exit fidelity does not require beating delayed closures.
        decision=('RETAIN_FOR_RESEARCH_NOT_INVESTMENT' if all(x['net_USDT']>0 for x in rows if x['strategy']==short_strategy)
                  else 'PAUSE_THIS_FIXED_RECIPE')
    secondary=[]
    if is_anchor:
        for c in comparisons:
            challenger=byid[(short_strategy if is_short else 'XGB_TREND_GATED',c['cost'],c['unit'])]
            raw=byid[('XGB_LONG_SHORT',c['cost'],c['unit'])]
            secondary.append(dict(cost=c['cost'],unit=c['unit'],comparator='XGB_LONG_SHORT',
                challenger=challenger['strategy'],net_delta_USDT=challenger['net_USDT']-raw['net_USDT'],
                DD_delta=challenger['minute_max_drawdown']-raw['minute_max_drawdown'],
                vol_delta=challenger['daily_annualized_volatility']-raw['daily_annualized_volatility']))
    model_path=Path(r['direction_model_reused']['path']) if is_regime else Path(r['run_dir'])/'xgb_shared.json'
    native_model=json.loads(model_path.read_bytes())
    actual_tree_count=len(native_model['learner']['gradient_booster']['model']['trees'])
    accepted=dict(status='ACCEPTED_ECONOMIC_COMPARISON_MARKED_AND_LIQUIDATED_SCOPES_SEPARATE',
        actual_path=str(a.actual),actual_sha256=sha(a.actual),binding=r['binding'],actual_days=days,full_capital_USDT=10000,
        one_shared_fit_total=1 if is_regime else r.get('fit_reused',{}).get('actual_models_fit_total',r['models_fit']),
        new_direction_fits=r['models_fit'],regime_fit=r.get('regime_fit'),regime_counts=r.get('regime_counts'),
        default_prediction_golden=r.get('default_prediction_golden'),default_target_golden=r.get('default_target_golden'),
        direction_model_reused=r.get('direction_model_reused'),
        accepted_accounts=accounts,actual_short_open_legs=sum(x['short_open_legs'] for x in rows),rows=rows,
        new_actual_short_open_legs=sum(x['short_open_legs'] for x in rows if x['account_evidence']=='NEW_COMPLETE_REPLAY'),
        new_accounts=new_accounts,reused_accounts=24 if is_retry else 20 if is_short else 16 if is_anchor else 0,control_reuse=control_proof,
        cash_close_retry_evidence=r.get('cash_close_retry_evidence'),
        booster_rounds=120,actual_fitted_tree_count=actual_tree_count,configurations=1,
        comparisons=comparisons,secondary_raw_comparisons=secondary,asset_contributions=asset_rows,decision=decision,qualified_investment='NONE/CASH',long_term_APR='NOT_EVALUABLE',
        bear_short_positive_in_all_conditional_scenarios=all(c['bear_short_contribution_USDT']>0 for c in comparisons) if is_regime else None,
        short_alpha_qualified=False,
        learned_regime_HMM='NOT_RUN',learned_regime_clustering='REUSED_GMM_CONTROL_NO_NEW_FIT' if is_anchor else 'ONE_GMM_TRAIN_ONLY' if is_regime else 'NOT_RUN',
        meta_labeling='NOT_RUN',new_unseen_evidence=False,
        derivative_features=r['protocol']['feature_missing'],classification=r['classification'],
        resources={k:r[k] for k in ('elapsed_seconds','peak_RSS_bytes','shared_RAM_sampled_peak_bytes','owned_bytes','GPU_hours','disk_before')},
        resource_peak_scope='PROCESS_RSS_AND_PER_RUN_SHARED_SAMPLES_NOT_RESET_KERNEL_LIFETIME_PEAK',
        maximum_independent_NAV_error_USDT=max(c['independent']['maximum_NAV_error_USDT'] for c in r['cases']),
        maximum_independent_wallet_error_USDT=max(c['independent']['maximum_wallet_error_USDT'] for c in r['cases']),
        original_failure_preserved=r.get('fit_reused'),created_utc=datetime.now(UTC).isoformat())
    write(a.output,accepted)
    lines=['# D089：零目标平仓持续重试的完整账户对照' if is_retry else '# D088：同规则short-only完整资本反事实' if is_short else '# D087：固定过去趋势状态与相对分群门控对照' if is_anchor else '# D086：训练期状态门控与同窗真实账户对照' if is_regime else '# D085：共享三分类方向基线与真实账户对照','',
        f'决定：**{decision}**。投资候选仍 NONE/CASH，长期APR NOT_EVALUABLE。', '',
        f'一套10币共享XGBoost（120轮boosting、实际{actual_tree_count}棵分类树、depth3、CPU2、seed20261005），没有搜索、阈值挑选或逐币训练。',
        ('复用同一固定SHORT_ONLY XGB预测、状态与目标，仅DAILY_TARGET零目标持续重试至成交或被更新决策/风险/终止替代。4个新完整账户，24个旧账户SHA复用；金融/数据源码仅声明的调度器差异由改动前默认golden与4项实际回归绑定，其他原样。不删除旧成交/成本，不免费成交。' if is_retry else
         '复用同一固定XGB预测与BTC趋势规则，仅方向mask由LONG_SHORT改为SHORT_ONLY；重新运行4个Mar–Jun2025完整资本122日账户，旧20个账户按SHA复用。零新拟合/搜索，不将D087方向归因当作本轮收益；原GMM桶保留，已有历史不称unseen。' if is_short else
         '复用D085固定模型，全部1220行概率和标签与D086精确一致；固定过去BTC SMA200/20d规则，无方向/状态/标准化拟合。只新增4个Mar–Jun2025连续122日账户，16个D086同窗对照按SHA复用。旧GMM状态桶保留，报告统一按固定规则重新分桶；回溯已见研究，不声称历史部署。' if is_anchor else
         '复用D085固定模型，实际fit与标签成熟均早于2025-03-01；训练期一套GMM与标准化，连续经济账户Mar–Jun2025共122日。回溯研究复用，不声称当时已部署；所有币相同时间切分。'
         if is_regime else '训练Sep2024–Feb2025、诊断Mar–Apr2025、经济May–Jun2025共61日；所有币相同时间切分，5日标签严格成熟。'),
        '数据已见开发筛选；Binance USD-M价格/mark/资金费配用户Bybit手续费，是跨场所代理。',
        '5日trade-open价格收益与37bp带比较，成本只进入边界一次；标签不含资金费/实际一分钟延迟。真实账户另外完整计费、容量、资金费与风险减仓。',
        '同资本10k、单币abs30%/gross60%、过去30日协方差最多10%年vol目标、逐仓1x；相同caps不代表实际风险相同。', '',
        '## 完整成本与方向账本', '',
        '|策略|成本|资金费解释|净USDT|毛USDT|LONG|SHORT|费|点差+滑点|资金费|换手|年vol%|分钟DD%|日Sharpe|残仓USDT|',
        '|---|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|']
    for x in rows:
        sh='UNKNOWN' if x['daily_sharpe'] is None else f"{x['daily_sharpe']:.2f}"
        lines.append(f"|{x['strategy']}|{x['cost']}|{x['unit']}|{x['net_USDT']:.2f}|{x['gross_USDT']:.2f}|{x['LONG_USDT']:.2f}|{x['SHORT_USDT']:.2f}|{x['fee_USDT']:.2f}|{x['spread_USDT']+x['slippage_USDT']:.2f}|{x['funding_USDT']:.2f}|{x['turnover']:.3f}|{x['daily_annualized_volatility']*100:.2f}|{x['minute_max_drawdown']*100:.2f}|{sh}|{x['residual_marked_notional']:.2f}|")
    lines += ['', 'CASH解析基准：净0、风险0、成本0，完整资本10k；不冒充模拟运行。上述净值包含全部残仓mark，残仓未删除；没有完成付费清仓的账户 **liquidated return NOT_EVALUABLE**。', '',
        '## 持续平仓重试相对五次过期的增量' if is_retry else '## short-only相对同规则long-short的增量' if is_short else '## 固定趋势门控相对同窗GMM门控的增量' if is_anchor else '## 状态门控相对同窗未门控的增量' if is_regime else '## 双向相对同模型多头的增量', '', '|成本|资金费解释|净增量USDT|DD变化百分点|vol变化百分点|预先任一改善|', '|---|---|---:|---:|---:|---|']
    for c in comparisons: lines.append(f"|{c['cost']}|{c['unit']}|{c['net_delta_USDT']:.2f}|{c['DD_delta']*100:.2f}|{c['vol_delta']*100:.2f}|{c['either_predeclared_benefit']}|")
    if is_anchor:
        lines += ['', '## 相对未门控方向的次要对照', '', '|成本|资金费解释|净增量USDT|DD变化百分点|vol变化百分点|', '|---|---|---:|---:|---:|']
        for c in secondary: lines.append(f"|{c['cost']}|{c['unit']}|{c['net_delta_USDT']:.2f}|{c['DD_delta']*100:.2f}|{c['vol_delta']*100:.2f}|")
    lines += ['', ('本轮SHORT_ONLY门控只在BEAR保留原short，BULL/SIDEWAYS/前一完成日崩盘状态与原long均请求零目标；不反转、不重分配被过滤预算。四种情景配对，不能拿旧61日独立账户净值当本轮增量。' if is_short else
        '门控只保留原方向或置零：BULL允许long、BEAR允许short、SIDEWAYS/前一完成日崩盘状态请求零目标；不反转、不重分配被过滤预算。四种情景配对，不能拿旧61日独立账户净值当本轮增量。' if is_regime else
        'SHORT_ONLY、LONG_ONLY为同预测消融，独立账户不得相加成为伪组合；LONG_SHORT是唯一同步共享资本双向账户。'), '',
        '## 过去可得的行情分层（描述性，不是HMM）','',
        'BTC close>SMA200且20d return>0为BULL，两者负为BEAR；单日<-5%且30d年vol>80%为HIGH_VOL_CRASH，其他SIDEWAYS。不使用未来行情定义状态。', '',
        '|策略(BASE27, RAW_AS_PERCENT)|状态|日数|LONG USDT|SHORT USDT|净 USDT|', '|---|---|---:|---:|---:|---:|']
    strategies=('XGB_LONG_SHORT','XGB_REGIME_GATED','XGB_TREND_GATED','HOLD','DONCHIAN_EXIT10') if is_anchor else ('XGB_LONG_SHORT','XGB_REGIME_GATED','HOLD','DONCHIAN_EXIT10') if is_regime else ('XGB_LONG_SHORT','XGB_LONG_ONLY','XGB_SHORT_ONLY','HOLD','DONCHIAN_EXIT10')
    if is_short: strategies=('XGB_TREND_SHORT_ONLY',*strategies)
    if is_retry: strategies=('XGB_TREND_SHORT_PERSISTENT_CASH',*strategies)
    for strategy in strategies:
        x=byid[(strategy,'BASE27','RAW_AS_PERCENT')]
        for label,v in x['by_past_regime'].items():
            lines.append(f"|{strategy}|{label}|{v['days']}|{v['LONG']:.2f}|{v['SHORT']:.2f}|{v['net']:.2f}|")
    if is_regime and not is_anchor:
        lines += ['', '## 训练期拟合状态（相对趋势分群）', '',
            '状态仅按训练中心过去20日收益、SMA200距离与breadth的标准化趋势排序命名；不是绝对牛熊真值、未来预测标签或未来收益选状态。', '',
            '|状态|20d收益中心|SMA200距离中心|日vol中心|breadth中心|评价日数|', '|---|---:|---:|---:|---:|---:|']
        for label,v in r['regime_fit']['centre_features'].items():
            lines.append(f"|{label}|{v['return_20d']:.5f}|{v['ma200_distance']:.5f}|{v['vol_30d']:.5f}|{v['market_breadth']:.5f}|{r['regime_counts'][label]}|")
        lines += ['', '|策略(BASE27, RAW_AS_PERCENT)|拟合状态|日数|LONG USDT|SHORT USDT|净 USDT|', '|---|---|---:|---:|---:|---:|']
        for strategy in strategies:
            for label,v in byid[(strategy,'BASE27','RAW_AS_PERCENT')]['by_learned_regime'].items():
                lines.append(f"|{strategy}|{label}|{v['days']}|{v['LONG']:.2f}|{v['SHORT']:.2f}|{v['net']:.2f}|")
        lines += ['', '状态分桶按收益日开始时上一已完成日状态，包含既有仓位和退出成本，不是入场状态的因果收益。CASH是零目标请求；容量/精度限制可能使实际持仓延续，不声称立即逃过崩盘或立即现金。HIGH_VOL_CRASH实际日数 '+str(r['regime_counts']['HIGH_VOL_CRASH'])+'，没有伪造第四拟合类。']
        lines += ['', '|策略(BASE27, RAW_AS_PERCENT)|状态|实际平均gross%|实际峰值gross%|实际平均net%|精确零仓分钟/总分钟|', '|---|---|---:|---:|---:|---|']
        for strategy in ('XGB_LONG_SHORT','XGB_REGIME_GATED'):
            for label,v in byid[(strategy,'BASE27','RAW_AS_PERCENT')]['actual_exposure_by_learned_regime'].items():
                lines.append(f"|{strategy}|{label}|{v['mean_gross']*100:.2f}|{v['max_gross']*100:.2f}|{v['mean_net']*100:.2f}|{v['exactly_flat_minutes']}/{v['minutes']}|")
    if is_anchor:
        lines += ['', '## 固定状态覆盖与真实敞口', '',
            '固定规则只描述上一闭合日当前趋势，不是未来牛熊收益真值；收益分桶含旧持仓与退出成本，不是因果贡献。零目标不保证容量受限时立即现金。', '',
            '状态日数：'+json.dumps(r['regime_counts'],ensure_ascii=False), '',
            '|策略(BASE27, RAW_AS_PERCENT)|状态|平均gross%|峰值gross%|平均net%|精确零仓分钟/总分钟|', '|---|---|---:|---:|---:|---|']
        for strategy in (('XGB_TREND_SHORT_ONLY',short_strategy) if is_retry else ('XGB_TREND_GATED','XGB_TREND_SHORT_ONLY') if is_short else ('XGB_REGIME_GATED','XGB_TREND_GATED')):
            for label,v in byid[(strategy,'BASE27','RAW_AS_PERCENT')]['actual_exposure_by_learned_regime'].items():
                lines.append(f"|{strategy}|{label}|{v['mean_gross']*100:.2f}|{v['max_gross']*100:.2f}|{v['mean_net']*100:.2f}|{v['exactly_flat_minutes']}/{v['minutes']}|")
    lines += ['', '## 资产贡献与成交成本（双向BASE27、RAW_AS_PERCENT）','',
        '|币|毛USDT|净USDT|手续费USDT|执行USDT|资金费USDT|成交腿|','|---|---:|---:|---:|---:|---:|---:|']
    for v in asset_rows:
        if v['case_id']=='XGB_LONG_SHORT_BASE27_RAW_AS_PERCENT':
            lines.append(f"|{v['symbol']}|{v['gross']:.2f}|{v['net']:.2f}|{v['fee']:.2f}|{v['execution']:.2f}|{v['funding']:.2f}|{v['legs']}|")
    lines += ['', '日方向贡献是资金流+当日持仓mark变化的净增量，不把平仓整笔利润任意归给订单原因；按状态分层是关联描述，不是因果证明。缺少的状态没有造样本。', '',
        '## 实际验证与局限', '',
        f'所有分钟signed数量、现金流净值桥、资金费归属/正负/严格过去mark、手续费与已实现钱包=free+逐仓抵押物独立复算；检查全部{days}日，不只是期末。数量仍精确Decimal，独立gross/net统计见结构化验收。',
        '独立验证是记录成交的会计，不是独立重建订单选择、原生保证金层级或全盘价格来源认证；瞬时风险/跳空及历史规则未认证范围沿用原账户。',
        'funding物理单位仍UNKNOWN，两种情景均报告，不能挑更盈利解释。资金费/basis/OI未作为特征；日线可得性是已闭合时间代理，非原生发布认证。',
        f"末尾{r['classification']['ECONOMICS']['missing_future_labels']}个未知5日标签保留缺失；重叠标签不是独立交易；原方向模型CASH预测{r['classification']['ECONOMICS']['predictions']['CASH']}，状态门控的零目标不等同模型学会现金择时。HMM/MLP/meta未跑。",
        ('本轮新fit=0；4项相关退出/容量/费用/资金费/未来扰动/风险停止和旧默认golden回归实际通过。第一次2失败为合成风险例尚未满仓及旧test stub遗漏N资产symbols关键字，保留V1失败，修正输入/接口后V2通过，未迁就测试更改风险。24个旧账户按SHA复用，新4目标/全部分钟NAV/钱包/费用/funding独立复算。' if is_retry else
         '本轮所有新fit=0、无新增模型/规则测试；已有三方向默认golden在实际入口精确重验，新4个SHORT_ONLY目标/全部分钟NAV/钱包/费用/funding独立复算。20旧账户只按SHA和相同金融/状态输入绑定复用，不称重新运行。' if is_short else
         '本轮所有新fit=0；2个相关趋势状态回归无拟合，既有GMM回归未重跑。新4账户各自独立复算目标、全部分钟NAV/钱包/费用/funding；16对照仅按原证据SHA与相同金融/数据源码绑定复用，不称重新运行。' if is_anchor else
         '本轮新direction fit=0，GMM=1、StandardScaler=1；相关因果回归额外2个GMM+2个Scaler拟合均计入，不作经济参数选择。原共同窗口概率和三个方向目标精确golden通过；独立目标审计另算状态过滤、标的顺序和过去协方差。'
         if is_regime else '首次账户因为严格全额平仓断言而停止：原模型/成交/负结果/225USDT残仓与原退出码保存；修正的是验收范围，模型与原预测逐字一致并复用，首账户未重跑。'), '',
        f"共享RAM采样峰值 {r['shared_RAM_sampled_peak_bytes']/1e9:.3f}GB，进程RSS峰值 {r['peak_RSS_bytes']/1e9:.3f}GB，输出增长 {r['owned_bytes']/1e6:.2f}MB，GPU0，swap0。磁盘实际扫描 {r['disk_before']['measured_utc']}：{r['disk_before']['total_bytes']/1e9:.3f}GB，不能当收尾扫描。", '',
        '## 复现', '', '```sh',
        'scripts/with_task_progress.sh --title "共享方向模型" -- env POLARS_MAX_THREADS=2 OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 MKL_NUM_THREADS=2 PYTHONPATH=/mnt/d/codex/coin/src:/mnt/d/codex/coin /home/xflops/coin-state/v8-clean-env-20261002-v2/bin/python -B scripts/investment/run_shared_direction.py --protocol protocols/SHARED_XGB_DIRECTION_20261005_V1.json --run-dir /home/xflops/coin-state/d085-independent-reproduction --output reports/fast_research/SHARED_DIRECTION_INDEPENDENT_REPRODUCTION.json',
        '```', '',
        f'从WSL项目ROOT运行；新独占目录，新运行{new_accounts}账户，不覆盖原证据。所有实际工件位置/SHA、贡献/暴露/保证金/集中度与假设见结构化验收。',
        f'验收：`{a.output}`，SHA `{sha(a.output)}`。实际运行：`{a.actual}`，SHA `{sha(a.actual)}`。']
    if is_regime:
        lines=[line.replace('protocols/SHARED_XGB_DIRECTION_20261005_V1.json','protocols/MARKET_REGIME_GATE_20261005_V1.json').replace('d085-independent-reproduction','d086-independent-reproduction').replace('SHARED_DIRECTION_INDEPENDENT_REPRODUCTION.json','MARKET_REGIME_INDEPENDENT_REPRODUCTION.json') for line in lines]
    if is_anchor:
        lines=[line.replace('protocols/MARKET_REGIME_GATE_20261005_V1.json','protocols/PAST_TREND_GATE_20261005_V1.json').replace('d086-independent-reproduction','d087-independent-reproduction').replace('MARKET_REGIME_INDEPENDENT_REPRODUCTION.json','PAST_TREND_INDEPENDENT_REPRODUCTION.json') for line in lines]
    if is_short:
        lines=[line.replace('protocols/PAST_TREND_GATE_20261005_V1.json','protocols/TREND_SHORT_COUNTERFACTUAL_20261005_V1.json').replace('d087-independent-reproduction','d088-independent-reproduction').replace('PAST_TREND_INDEPENDENT_REPRODUCTION.json','TREND_SHORT_INDEPENDENT_REPRODUCTION.json') for line in lines]
    if is_retry:
        lines=[line.replace('protocols/TREND_SHORT_COUNTERFACTUAL_20261005_V1.json','protocols/CASH_CLOSE_RETRY_20261005_V1.json').replace('d088-independent-reproduction','d089-independent-reproduction').replace('TREND_SHORT_INDEPENDENT_REPRODUCTION.json','CASH_CLOSE_RETRY_INDEPENDENT_REPRODUCTION.json') for line in lines]
        lines+=['','## 现金目标与实际平仓诊断','',
            '|策略(BASE27/PCT)|零目标仍有仓位的资产分钟|零目标平仓成交腿|超过五分钟的平仓腿|最长signal至成交分钟|',
            '|---|---:|---:|---:|---:|']
        for name in ('XGB_TREND_SHORT_ONLY',short_strategy):
            v=byid[(name,'BASE27','RAW_AS_PERCENT')]['cash_close_diagnostics']
            lines.append(f"|{name}|{v['zero_target_unflat_asset_minutes']}|{v['zero_target_close_legs']}|{v['close_legs_after_five_minutes']}|{v['max_signal_to_close_fill_minutes']}|")
    with a.document.open('x',encoding='utf-8') as f: f.write('\n'.join(lines)+'\n')
    print(json.dumps(dict(status=accepted['status'],decision=decision,short_open_legs=accepted['actual_short_open_legs'],comparisons=comparisons)))

if __name__=='__main__': main()
