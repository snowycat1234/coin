# Completed-minute mark/trade dislocation: 2025 seen-development result

## Bottom line

The fixed direction-toward-mark recipe has a positive full-sample mean price proxy after the fixed 27bp diagnostic, but this does **not establish a repeatable cost-sized signal**. Only 46 disjoint per-asset events occur over 26 UTC dates. Five simultaneous-market events on 2025-10-10 contribute more than the entire positive event-proxy sum. The median event does not cover 27bp; fewer than half do. No wallet/capacity/lot execution was run. Keep this as crash-concentrated, insufficient independent evidence rather than a validated trading candidate.

## Fixed experiment and source coverage

- Entire natural 2025, BTCUSDT/ETHUSDT/SOLUSDT/XRPUSDT/DOGEUSDT. All 525,600 minutes per asset are valid: 2,628,000 asset-minutes, no source gaps, invalid rows or censoring.
- Signal = 10000 × (completed-minute mark close / trade close − 1). Absolute threshold fixed at 50bp; direction fixed toward mark. No recipe/threshold/horizon/asset/month/direction change after results.
- Source times are minute OPEN. Restored source normalizer verifies original inclusive close = OPEN+59,999ms, the same trade/mark grid, and retains mark CLOSE. Completion = OPEN+60s. Availability proxy = completion+1µs; readiness = availability+3 full minutes. The first eligible future trade OPEN is therefore feature OPEN+5min. This is a convention, not a measured arrival certificate.
- Exit is the actual trade OPEN exactly 60 minutes after entry. Earliest chronological qualifying feature is retained per asset if its proposed entry is at/after the prior retained exit. Every qualifying feature and overlap rejection is saved; no return-dependent eligibility.
- 131 threshold candidates; 85 overlap rejections; 46 retained events; 0 right-censored events. BTC/ETH/SOL/XRP/DOGE retained counts: 1/8/9/10/18.
- Mark is an exchange reference, not fair value, index, a tradable quote or spot/perp basis. Convergence is the hypothesis; smoothing, asynchronous last trades and source behavior can produce dislocations.

## Both fixed directions, identical events

All numbers below are entry-notional linear OPEN price proxies in basis points, with short return defined as the negative arithmetic trade return. They are not annualized, compounded portfolio returns or wallet PnL.

| Metric | Toward mark | Reverse placebo |
| --- | ---: | ---: |
| Events | 46 | 46 |
| Mean gross | 177.219422 | -177.219422 |
| Mean minus fixed 27bp | 150.219422 | -204.219422 |
| Median gross | 5.686500 | -5.686500 |
| Median minus fixed 27bp | -21.313500 | -32.686500 |
| Gross greater than 27bp | 21/46 (45.65%) | 17/46 (36.96%) |
| Gross range | [-1406.174626, 6086.305592] | [-6086.305592, 1406.174626] |

The frozen descriptive sample floor (at least30 events and20 dates) is met, but it was explicitly not statistical proof. No confirmatory confidence interval or independent outcome sample was pre-registered/run. The machine-readable point-estimate classification is POSITIVE_SEEN_DEV_PRICE_PROXY_REQUIRES_INDEPENDENT_EVIDENCE. Neither the sign of a placebo nor asset/month differences are used to select a new strategy.

## Concentration, with every event retained

This is post-result descriptive attribution, not another performance recipe or event deletion. Sums below add equal-entry-notional event proxies and are not an invested portfolio return.

- The five 2025-10-10 events sum to +9,915.054242bp versus +8,152.093403bp across all46 events: 121.63% of the entire gross sum. Their net27bp contribution is +9,780.054242 versus +6,910.093403 across all46.
- DOGE 2025-10-10 21:15 feature: gap+129.455912bp, availability21:16:00.000001, readiness21:19:00.000001, entry21:20 at0.11355, exit22:20 at0.18266. This single +6,086.305592bp event is74.66% of the entire gross sum. Such a crash OPEN is a particularly strong capacity/spread/slippage concern that a fixed27bp diagnostic cannot certify.
- March02 contributes −2,396.330292bp over three events. Per-asset and all12 months are shown below, including December with zero events. No month is removed or promoted.

## Per-asset coverage and results

| Asset | Valid minutes | Candidates | Rejected overlap | Events | All-signal min/max bp | Mean gross bp | Mean minus27bp | Reverse minus27bp |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: |
| BTCUSDT | 525600 | 3 | 2 | 1 | [-49.996259, 92.023205] | 861.221039 | 834.221039 | -888.221039 |
| ETHUSDT | 525600 | 18 | 10 | 8 | [-110.450413, 276.144260] | 131.243540 | 104.243540 | -158.243540 |
| SOLUSDT | 525600 | 29 | 20 | 9 | [-224.978448, 323.536994] | 9.785047 | -17.214953 | -36.785047 |
| XRPUSDT | 525600 | 32 | 22 | 10 | [-295.007369, 124.344522] | -35.752721 | -62.752721 | 8.752721 |
| DOGEUSDT | 525600 | 49 | 31 | 18 | [-425.371531, 403.349142] | 361.688101 | 334.688101 | -388.688101 |

All feature and threshold-candidate absolute signal quantiles (min,50%,90%,99%,99.9%,max) are in RESULT.json. The largest absolute full-year gap is425.371531bp in DOGE. Most minute dislocations are tiny; per-asset99.9% absolute quantiles are7.956615/13.168084/14.840891/15.286620/16.866114bp.

## Every calendar month

| Month | Candidates | Events | Mean gross bp | Mean minus27bp | Reverse minus27bp |
| --- | ---: | ---: | ---: | ---: | ---: |
| 2025-01 | 7 | 6 | 140.024630 | 113.024630 | -167.024630 |
| 2025-02 | 29 | 7 | -22.105013 | -49.105013 | -4.894987 |
| 2025-03 | 3 | 3 | -798.776764 | -825.776764 | 771.776764 |
| 2025-04 | 2 | 2 | 1.218888 | -25.781112 | -28.218888 |
| 2025-05 | 8 | 7 | -59.906729 | -86.906729 | 32.906729 |
| 2025-06 | 2 | 2 | -2.830638 | -29.830638 | -24.169362 |
| 2025-07 | 4 | 4 | -11.996174 | -38.996174 | -15.003826 |
| 2025-08 | 1 | 1 | 27.496028 | 0.496028 | -54.496028 |
| 2025-09 | 6 | 6 | -13.286497 | -40.286497 | -13.713503 |
| 2025-10 | 68 | 7 | 1454.263992 | 1427.263992 | -1481.263992 |
| 2025-11 | 1 | 1 | 205.941316 | 178.941316 | -232.941316 |
| 2025-12 | 0 | 0 | N/A (zero events) | N/A (zero events) | N/A (zero events) |

## Raw funding, kept separate

Exactly5,475 literal source funding rows are pinned and retain the original unrounded calc_time_ms×1000 clocks. Seven retained event intervals contain one raw source event each under [entry,exit). Each event row reports the raw-rate sum and −direction×raw-rate-sum coefficient; the aggregate coefficient is+0.00033534. This is dimensionless raw source attribution only. It is not converted to bp, multiplied into a funding cashflow, or added to the price proxy. Historical rate units, settlement/charge-mark/position ownership and arrival remain uncertified. Coincident calc timestamps do not establish actual payable funding.

## Deduplication and prior results

Before arrays/returns, the209 branchheads in the existing remote_heads.json and relevant public histories/manifests were checked. Complete recursive trees at5e020665 (prior scientific modules) andbae934ff (8,914 latest recovered paths, not truncated) were examined; selected protocol/report/manifest bodies were read. Bounded search is not an exhaustive compressed-history absence proof.

- [Prior same-contract mark/trade daily OLS](https://github.com/snowycat1234/coin/blob/5e02066526d9accad56915991600f2ac5c31aab0/research/mark-trade-dislocation-20261012/REPORT.md) used only the preceding day final-minute gap, own-price control, and next-day OPEN label. 2025 normalized-MSE improvement+0.276934%, CI crossed zero;2023 −0.536955%. Both frozen information gates failed; no conditional economics ran. That is not this fixed50bp all-minute/60min event design.
- [Composite-mark replay](https://github.com/snowycat1234/coin/blob/cc2f78840d81867c11e1adae1eacb93ed877254b/research/composite-mark-replay-20261011/README.md) is source-union/compatibility QA with old BASE targets, no new signal recipe. Its paid-flat gate remained stopped with residual marked notional.
- Completed-day minute selector uses RV/semivariance/crosscov, causal mark overlay is generated-only missingness/provenance, Guard50 is paid-exit protection, and older basis risk is mark-minus-spot valuation. These were not treated as predictive dislocation event trials. Exact body identities and links are in DEDUP.json and PRIOR_EVIDENCE.json.

## Freeze, checks, resource use and deliverables

- Protocol SHA256: deeda6e5aa8914513f7b96157e15213cad5c688a5b683482b43bbe3aaec15cce. Actual freeze receipt confirmed09:02:11UTC before arrays; embedded09:01:16 is design-start time. PRE_RUN_PINS records source/test freeze09:04:11UTC; the study then ran once.
- Six synthetic tests passed before any source-array read: completion/availability boundary, delayed/future availability masks, future-value perturbation invariance, rejection of elapsed OPEN, exact60minute/missing endpoint, earliest nonoverlap/reverse identity and literal funding boundaries.
- Actual source-array study: 0.675077s, one CPU affinity[0], peak RSS196,571,136B. Zero provider downloads, GitHub writes, Library actions or financial-account imports/constructors/advances. No2026 source body reads or deletions.
- EVENTS.csv contains every46 retained event with source feature prices, all clocks, entry/exit OPEN prices, both price directions/cost diagnostics and literal funding attribution. ALL_CANDIDATES.json contains every131 qualifying feature and rejection. FEATURE_SELECTION.json was saved before calculating returns. RESULT.json includes complete asset/month/coverage/signal distributions; CONCENTRATION.json includes all26 date contributions.
- This result does not certify arrival, executable spreads/slippage/capacity, lots, fees, margin/liquidation, wallet settlement, or a fair-value model. No new outcome calendar was opened. No alternative horizon/threshold/direction or financial rerun is proposed from this result.

## Final review and reusable source locators

Independent read-only review found no material implementation defect: all434 source/clock/candidate/return/funding checks passed, without importing or rerunning the author module. Its interpretation remains insufficient repeatable cost-sized evidence. Review files are supplied separately as mark_trade_minute_event2025_REVIEW.md and mark_trade_minute_event2025_REVIEW_CHECKS.json. Freeze chronology is supported by contemporaneous receipts and messages; hashes alone cannot independently prove timing.

EVENT_SOURCE_LOCATORS.json provides every46 event with canonical month/hash/array/row locators for feature CLOSE/mark and entry/exit OPEN. It also gives immediately-prior-bar and as-of-safe quote-volume locators. At exact OPEN u under the frozen +1µs completion convention, the immediately preceding bar is available only at u+1µs; the last safely available completed-volume bar is u−2min. A later separately specified engine must bind its own fill/information clocks. These are locators only; no quote-volume capacity, lot, fee/funding cashflow or shared-wallet diagnostic was run.
