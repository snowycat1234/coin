import json
from pathlib import Path
import unittest
import numpy as np
import event_study as e

class ClockTests(unittest.TestCase):
    def setUp(self):
        self.t=np.arange(300,dtype=np.int64)*e.MINUTE
        self.close=np.full(300,100.0)
        self.mark=np.full(300,101.0)
        self.available=self.t+e.MINUTE+1

    def test_feature_completion_and_availability(self):
        for clock in [e.MINUTE-1000,e.MINUTE,e.MINUTE+0]:
            idx,_=e.visible_signal(self.t,self.close,self.mark,self.available,clock)
            self.assertEqual(len(idx),0)
        idx,x=e.visible_signal(self.t,self.close,self.mark,self.available,e.MINUTE+1)
        np.testing.assert_array_equal(idx,[0]);self.assertAlmostEqual(x[0],100)
        late=self.available.copy();late[0]=20*e.MINUTE
        idx,_=e.visible_signal(self.t,self.close,self.mark,late,10*e.MINUTE)
        self.assertNotIn(0,idx)

    def test_future_masks_and_future_perturbation(self):
        clock=10*e.MINUTE+1
        idx,x=e.visible_signal(self.t,self.close,self.mark,self.available,clock)
        c,m=self.close.copy(),self.mark.copy()
        c[self.available>clock]=np.nan;m[self.available>clock]=1e20
        jj,y=e.visible_signal(self.t,c,m,self.available,clock)
        np.testing.assert_array_equal(jj,idx);np.testing.assert_array_equal(y,x)
        self.assertTrue(np.all(self.available[jj]<=clock))
        a=e.select(self.t,idx,x)
        b=e.select(self.t,jj,y)
        self.assertEqual(a,b)

    def test_no_phantom_elapsed_open(self):
        ready,en,ex=e.proposal(self.t,e.MINUTE+1)
        self.assertEqual(ready,4*e.MINUTE+1)
        self.assertEqual(en,5);self.assertEqual(ex,65)
        self.assertGreater(self.t[en],4*e.MINUTE)
        ready,en,ex=e.proposal(self.t,10*e.MINUTE+1)
        self.assertEqual(en,14);self.assertEqual(ex,74)

    def test_exact_horizon_missing_endpoint(self):
        t=np.delete(self.t,65)
        _,en,ex=e.proposal(t,e.MINUTE+1)
        self.assertEqual(t[en],5*e.MINUTE);self.assertIsNone(ex)

    def test_earliest_nonoverlap_and_reverse(self):
        rows=e.select(self.t,[0,1,59,60,61,235],[50,-50,70,80,90,60])
        self.assertEqual([r['status'] for r in rows],['SELECTED','REJECT_OVERLAP','REJECT_OVERLAP','SELECTED','REJECT_OVERLAP','CENSORED_EXACT_60MIN_EXIT_UNAVAILABLE'])
        retained=[r for r in rows if r['status']=='SELECTED']
        self.assertGreaterEqual(self.t[retained[1]['entry_index']],self.t[retained[0]['exit_index']])
        gross=np.array([100,-20.0]);rev=-gross
        np.testing.assert_array_equal(rev,-gross)
        np.testing.assert_array_equal((gross-27)+(rev-27),[-54,-54])

    def test_literal_funding_boundaries(self):
        t=np.array([5*e.MINUTE-1,5*e.MINUTE,5*e.MINUTE+15000,65*e.MINUTE-1,65*e.MINUTE],dtype=np.int64)
        rates=np.array([1,2,3,4,5.0])
        n,r,clocks=e.funding_events(t,rates,5*e.MINUTE,65*e.MINUTE)
        self.assertEqual(n,3);self.assertEqual(r,9)
        self.assertEqual(clocks,[int(t[1]),int(t[2]),int(t[3])])

if __name__=='__main__':
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(ClockTests)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    if not result.wasSuccessful():raise SystemExit(1)
    e.write_json(Path(__file__).parent/'SYNTHETIC_TESTS.json',dict(status='PASS',tests=result.testsRun,
                  failures=0,errors=0,real_source_array_reads=0,financial_execution=0))
