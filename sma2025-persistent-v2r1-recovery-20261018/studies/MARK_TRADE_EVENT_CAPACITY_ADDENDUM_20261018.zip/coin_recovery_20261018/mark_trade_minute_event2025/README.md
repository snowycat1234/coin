# Completed-minute mark/trade dislocation, 2025 seen-development event study

Work in progress. Frozen protocol and the bounded history dedup precede source-array scans and return calculation. This module reads existing 2025 canonical source arrays only. It does not import or advance a financial account.
