"""One frozen source-array event study. No repository or financial imports."""
import csv
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import resource
import sys
import time
import numpy as np

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent / 'restored2025' / 'prepared_2025'
MINUTE = 60_000_000
THRESHOLD_BP = 50.0
HOLD = 60 * MINUTE
SYMBOLS = ('BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'XRPUSDT', 'DOGEUSDT')

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def utc(us):
    return dt.datetime.fromtimestamp(int(us) / 1_000_000, dt.timezone.utc).isoformat()

def write_json(p, value):
    with p.open('x') as f:
        json.dump(value, f, indent=2, sort_keys=True, allow_nan=False)
        f.write('\n')

def visible_signal(times, trade_close, mark_close, available_us, as_of_us):
    """Return only completed AND available feature rows, without future values."""
    mask = (times + MINUTE < as_of_us) & (available_us <= as_of_us)
    idx = np.flatnonzero(mask)
    trade, mark = trade_close[idx], mark_close[idx]
    good = np.isfinite(trade) & (trade > 0) & np.isfinite(mark) & (mark > 0)
    idx = idx[good]
    return idx, 10000.0 * (mark[good] / trade[good] - 1.0)

def proposal(times, feature_available_us):
    ready = int(feature_available_us) + 3 * MINUTE
    entry_idx = int(np.searchsorted(times, ready, side='left'))
    if entry_idx == len(times):
        return ready, None, None
    entry = int(times[entry_idx])
    assert entry >= ready and entry > feature_available_us
    exit_idx = int(np.searchsorted(times, entry + HOLD, side='left'))
    if exit_idx == len(times) or times[exit_idx] != entry + HOLD:
        return ready, entry_idx, None
    return ready, entry_idx, exit_idx

def select(times, feature_indices, signals_bp, availability=None):
    """Chronological earliest disjoint entry/exit intervals; returns audit rows."""
    previous_exit = -1
    out = []
    for i, gap in zip(feature_indices, signals_bp):
        available = int(times[i]) + MINUTE + 1 if availability is None else int(availability[i])
        ready, en, ex = proposal(times, available)
        r = dict(feature_index=int(i), signal_bp=float(gap), feature_available_us=available,
                 order_ready_us=ready, entry_index=en, exit_index=ex)
        if en is None:
            r['status'] = 'CENSORED_ENTRY_OUTSIDE_2025'
        elif times[en] < previous_exit:
            r['status'] = 'REJECT_OVERLAP'
        elif ex is None:
            r['status'] = 'CENSORED_EXACT_60MIN_EXIT_UNAVAILABLE'
        else:
            r['status'] = 'SELECTED'
            previous_exit = int(times[ex])
        out.append(r)
    return out

def funding_events(times, rates, start, end):
    a, b = np.searchsorted(times, [start, end], side='left')
    return int(b-a), float(np.sum(rates[a:b], dtype=np.float64)), [int(x) for x in times[a:b]]

def stats(values):
    a = np.asarray(values, dtype=float)
    if not len(a):
        return dict(n=0, mean_bp=None, median_bp=None, minimum_bp=None, maximum_bp=None,
                    mean_minus_27bp=None, positive_after_27bp_fraction=None)
    return dict(n=len(a), mean_bp=float(a.mean()), median_bp=float(np.median(a)),
                minimum_bp=float(a.min()), maximum_bp=float(a.max()),
                mean_minus_27bp=float(a.mean()-27), positive_after_27bp_fraction=float(np.mean(a>27)))

def distribution(a):
    if not len(a):
        return dict(n=0, min_bp=None, max_bp=None, abs_quantiles_bp=None)
    return dict(n=len(a), min_bp=float(np.min(a)), max_bp=float(np.max(a)),
                abs_quantiles_bp={str(q):float(np.quantile(np.abs(a), q)) for q in [0,.5,.9,.99,.999,1]})

def main():
    begin = time.monotonic()
    os.sched_setaffinity(0, {min(os.sched_getaffinity(0))})
    protocol_sha = sha(HERE/'PROTOCOL.json')
    protocol = json.loads((HERE/'PROTOCOL.json').read_text())
    freeze = json.loads((HERE/'FREEZE_RECEIPT.json').read_text())
    assert protocol_sha == freeze['protocol_SHA256']
    tests = json.loads((HERE/'SYNTHETIC_TESTS.json').read_text())
    assert tests['status'] == 'PASS' and tests['real_source_array_reads'] == 0
    assert sha(SOURCE/'SOURCE_INDEX.json') == protocol['inputs']['source_index_SHA256']
    index = json.loads((SOURCE/'SOURCE_INDEX.json').read_text())
    assert tuple(index['symbol_order']) == SYMBOLS
    start, end = index['calendar']
    chunks_t, chunks_open, chunks_close, chunks_mark = [], [], [], []
    pins = []
    for row in protocol['inputs']['canonical_months']:
        p = SOURCE/'months'/(row['month']+'.npz')
        assert p.stat().st_size == row['source_NPZ_bytes']
        assert sha(p) == row['source_NPZ_SHA256']
        with np.load(p, allow_pickle=False) as a:
            t = a['times'].copy()
            assert t.dtype == np.int64 and len(t) == row['minutes']
            assert np.all(np.diff(t) == MINUTE)
            oo = np.column_stack([a[s+'_open'] for s in SYMBOLS])
            cc = np.column_stack([a[s+'_close'] for s in SYMBOLS])
            mm = np.column_stack([a[s+'_mark'] for s in SYMBOLS])
        assert all(np.all(np.isfinite(x) & (x>0)) for x in (oo,cc,mm))
        chunks_t.append(t); chunks_open.append(oo); chunks_close.append(cc); chunks_mark.append(mm)
        pins.append(dict(month=row['month'], SHA256=sha(p), bytes=p.stat().st_size, minutes=len(t)))
    t = np.concatenate(chunks_t)
    oo, cc, mm = [np.concatenate(parts) for parts in (chunks_open,chunks_close,chunks_mark)]
    assert np.array_equal(t, np.arange(start,end,MINUTE,dtype=np.int64))
    assert len(t) == 525600 and all(a.shape==(525600,5) for a in (oo,cc,mm))
    # Feature scan is complete before entry/exit returns are read/calculated.
    availability = t + MINUTE + 1
    features = []
    coverage = {}
    for j,s in enumerate(SYMBOLS):
        ii, signal = visible_signal(t,cc[:,j],mm[:,j],availability,end+1)
        assert len(ii) == len(t)
        keep = np.abs(signal) >= THRESHOLD_BP
        selected = select(t,ii[keep],signal[keep])
        features.append((j,s,selected))
        coverage[s] = dict(source_minutes=len(t), valid_signal_minutes=len(ii),
                           feature_distribution=distribution(signal),
                           threshold_candidate_distribution=distribution(signal[keep]),
                           candidates=int(keep.sum()),
                           selected=sum(r['status']=='SELECTED' for r in selected),
                           overlap_rejects=sum(r['status']=='REJECT_OVERLAP' for r in selected),
                           censored=sum(r['status'].startswith('CENSORED') for r in selected))
    # This durable event-clock/selection receipt precedes return calculations.
    write_json(HERE/'FEATURE_SELECTION.json',dict(protocol_SHA256=protocol_sha,source_pins=pins,
               coverage=coverage,selection=[dict(symbol=s,rows=rows) for _,s,rows in features],
               returns_read_or_computed=False,actual_arrival_certified=False))
    # Literal raw source rates only: no funding unit conversion or net integration.
    funding_pin = protocol['inputs']['funding']
    assert (SOURCE/'EVENTS.json').stat().st_size==funding_pin['bytes']
    assert sha(SOURCE/'EVENTS.json')==funding_pin['SHA256']
    fund = json.loads((SOURCE/'EVENTS.json').read_text())
    assert len(fund)==5475 and all(r['symbol'] in SYMBOLS and start<=r['event_us']<end for r in fund)
    funds = {}
    for s in SYMBOLS:
        rows = [r for r in fund if r['symbol']==s]
        ft = np.array([r['event_us'] for r in rows],dtype=np.int64)
        fr = np.array([r['raw_rate'] for r in rows],dtype=float)
        assert len(ft)==1095 and np.all(np.diff(ft)>0) and np.isfinite(fr).all()
        funds[s]=(ft,fr)
    audit, events = [], []
    for j,s,rows in features:
        for r in rows:
            i,en,ex = r['feature_index'],r['entry_index'],r['exit_index']
            x=dict(symbol=s,feature_open_us=int(t[i]),feature_completion_us=int(t[i])+MINUTE,
                   feature_available_us=r['feature_available_us'],order_ready_us=r['order_ready_us'],
                   feature_utc=utc(t[i]),signal_bp=r['signal_bp'],direction=1 if r['signal_bp']>0 else -1,
                   status=r['status'],feature_trade_close=float(cc[i,j]),feature_mark_close=float(mm[i,j]),
                   entry_us=None if en is None else int(t[en]),exit_us=None if ex is None else int(t[ex]))
            audit.append(x.copy())
            if r['status'] != 'SELECTED':continue
            p0,p1=float(oo[en,j]),float(oo[ex,j])
            gross=x['direction']*10000*(p1/p0-1)
            nf,raw,ft=funding_events(*funds[s],int(t[en]),int(t[ex]))
            x.update(entry_utc=utc(t[en]),exit_utc=utc(t[ex]),entry_trade_open=p0,exit_trade_open=p1,
                     gross_price_bp=gross,net_27bp_diagnostic=gross-27,
                     reverse_gross_price_bp=-gross,reverse_net_27bp_diagnostic=-gross-27,
                     raw_funding_events=nf,raw_rate_sum=raw,
                     signed_raw_rate_coefficient=-x['direction']*raw,
                     reverse_signed_raw_rate_coefficient=x['direction']*raw,
                     raw_funding_event_us=';'.join(str(u) for u in ft))
            assert x['entry_us']>=x['order_ready_us']>x['feature_available_us']
            assert x['exit_us']-x['entry_us']==HOLD
            events.append(x)
    events.sort(key=lambda x:(x['feature_open_us'],SYMBOLS.index(x['symbol'])))
    audit.sort(key=lambda x:(x['feature_open_us'],SYMBOLS.index(x['symbol'])))
    write_json(HERE/'ALL_CANDIDATES.json',audit)
    with (HERE/'EVENTS.csv').open('x',newline='') as f:
        names=list(events[0]) if events else ['symbol','feature_open_us','signal_bp','status']
        w=csv.DictWriter(f,fieldnames=names);w.writeheader();w.writerows(events)
    by_asset={s:dict(toward_mark=stats([e['gross_price_bp'] for e in events if e['symbol']==s]),
                    reverse=stats([e['reverse_gross_price_bp'] for e in events if e['symbol']==s])) for s in SYMBOLS}
    by_month={f'2025-{m:02d}':dict(candidate_signals=sum(e['feature_utc'].startswith(f'2025-{m:02d}') for e in audit),
                    toward_mark=stats([e['gross_price_bp'] for e in events if e['feature_utc'].startswith(f'2025-{m:02d}')]),
                    reverse=stats([e['reverse_gross_price_bp'] for e in events if e['feature_utc'].startswith(f'2025-{m:02d}')])) for m in range(1,13)}
    days=len({e['feature_utc'][:10] for e in events})
    gross=[e['gross_price_bp'] for e in events]
    n=len(events)
    classification='INSUFFICIENT_SAMPLE' if n<30 or days<20 else ('NEGATIVE_NET_COST_DIAGNOSTIC' if np.mean(gross)<=27 else 'POSITIVE_SEEN_DEV_PRICE_PROXY_REQUIRES_INDEPENDENT_EVIDENCE')
    report=dict(schema='MARK_TRADE_MINUTE_EVENT2025_RESULT_V1',status='COMPLETE',classification=classification,
                protocol_SHA256=protocol_sha,calendar=[utc(start),utc(end)],sample_role='SEEN_DEVELOPMENT',
                selected_events=n,distinct_event_UTC_days=days,coverage=coverage,
                toward_mark=stats(gross),reverse_placebo=stats([-x for x in gross]),by_asset=by_asset,by_month=by_month,
                raw_funding_attribution=dict(source_events=5475,event_clock='Unrounded calc_time_ms*1000 preserved exactly',
                    selected_event_intervals_with_raw_event=sum(e['raw_funding_events']>0 for e in events),
                    selected_raw_events=sum(e['raw_funding_events'] for e in events),
                    summed_signed_raw_rate_coefficient=sum(e['signed_raw_rate_coefficient'] for e in events),
                    unit_charge_mark_ownership_arrival_certified=False,added_to_price_return=False),
                limitations=['Mark is an exchange reference, not fair value/index or executable price.',
                    'Completed boundary plus1us and three full minutes is an assumed availability/delay convention; actual arrival is uncertified.',
                    'Gross is an entry-notional linear OPEN price proxy. Gross minus27bp is a fixed-cost diagnostic, not executable wallet/capacity/lot PnL.',
                    'One seen-DEV recipe, no threshold/horizon/asset/month/direction selection or rescue. No independent validation or trading-readiness claim.'],
                resources=dict(CPU_affinity=sorted(os.sched_getaffinity(0)),seconds=time.monotonic()-begin,
                               peak_RSS_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,
                               new_provider_downloads=0,GitHub_writes=0,Library=0,financial_imports_constructors_advances=0))
    write_json(HERE/'RESULT.json',report)
    assert sum(p.stat().st_size for p in HERE.rglob('*') if p.is_file())<=2_000_000
    print(json.dumps({k:report[k] for k in ('status','classification','selected_events','distinct_event_UTC_days','toward_mark','reverse_placebo','resources')},indent=2))

if __name__=='__main__':main()
