"""Independent scalar-only event selection and arithmetic review, no financial engine.

Reads pinned 2025 canonical arrays. Does not import or run the author's study.
Production helpers are imported only after the independent reference is complete,
for synthetic, non-financial mutation/clock tests.
"""
import bisect
import csv
import datetime as dt
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import statistics
import sys
import time
import numpy as np

HERE = Path(__file__).resolve().parent
AUTHOR = HERE.parent / 'mark_trade_minute_event2025'
SOURCE = HERE.parent / 'restored2025' / 'prepared_2025'
M = 60_000_000
EXPECTED_PROTOCOL = 'deeda6e5aa8914513f7b96157e15213cad5c688a5b683482b43bbe3aaec15cce'
SYMS = ('BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'XRPUSDT', 'DOGEUSDT')
sys.dont_write_bytecode = True

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def save(name, obj):
    with (HERE/name).open('x') as f:
        json.dump(obj, f, indent=2, sort_keys=True, allow_nan=False)
        f.write('\n')

def utc(t):
    return dt.datetime.fromtimestamp(t/1_000_000, dt.timezone.utc).isoformat()

def stats(vals):
    return {'n': len(vals), 'mean_bp': statistics.mean(vals) if vals else None,
            'median_bp': statistics.median(vals) if vals else None,
            'minimum_bp': min(vals) if vals else None,
            'maximum_bp': max(vals) if vals else None,
            'mean_minus_27bp': statistics.mean(vals)-27 if vals else None,
            'positive_after_27bp_fraction': sum(x > 27 for x in vals)/len(vals) if vals else None}

def close(a, b):
    if a is None or b is None:
        assert a is b, (a,b)
    else:
        assert math.isclose(float(a), float(b), rel_tol=1e-12, abs_tol=1e-10), (a,b)

def ref_signal(open_us, trade, mark, arrival_us, asof_us):
    # Availability proxy is a separate condition from completed-minute time.
    if not (asof_us > open_us+M and arrival_us <= asof_us):
        return None
    if not (math.isfinite(trade) and trade > 0 and math.isfinite(mark) and mark > 0):
        return None
    return 10000.0*(mark/trade-1.0)

def ref_proposal(grid, available_us):
    ready = available_us + 3*M
    j = bisect.bisect_left(grid, ready)
    if j == len(grid):
        return ready, None, None
    k = bisect.bisect_left(grid, grid[j]+60*M)
    return ready, j, k if k < len(grid) and grid[k] == grid[j]+60*M else None

def compare_stats(actual, expected):
    assert actual.keys() == expected.keys()
    for k,v in expected.items():
        close(actual[k],v)

def main():
    begin = time.monotonic()
    os.sched_setaffinity(0, {min(os.sched_getaffinity(0))})
    original_pins = {p.name:sha(p) for p in AUTHOR.iterdir() if p.is_file()}
    protocol = json.loads((AUTHOR/'PROTOCOL.json').read_text())
    assert sha(AUTHOR/'PROTOCOL.json') == EXPECTED_PROTOCOL
    assert tuple(protocol['assets']) == SYMS
    assert protocol['signal']['threshold_abs_bp'] == 50.0
    assert sha(SOURCE/'SOURCE_INDEX.json') == protocol['inputs']['source_index_SHA256']
    index = json.loads((SOURCE/'SOURCE_INDEX.json').read_text())
    assert tuple(index['symbol_order']) == SYMS
    start,end = index['calendar']
    assert (utc(start),utc(end)) == ('2025-01-01T00:00:00+00:00','2026-01-01T00:00:00+00:00')
    arrays = []
    monthly = {}
    source_pins = []
    for p in protocol['inputs']['canonical_months']:
        month = p['month']
        assert month.startswith('2025-')
        path = SOURCE/'months'/(month+'.npz')
        assert sha(path) == p['source_NPZ_SHA256']
        assert path.stat().st_size == p['source_NPZ_bytes']
        with np.load(path, allow_pickle=False) as z:
            t = z['times'].copy()
            assert t.dtype == np.int64 and len(t) == p['minutes']
            assert np.array_equal(t, np.arange(t[0],t[0]+len(t)*M,M,dtype=np.int64))
            a = {s: {f:z[s+'_'+f].copy() for f in ('open','close','mark')} for s in SYMS}
            for s in SYMS:
                for f,v in a[s].items():
                    assert v.shape == t.shape and np.all(np.isfinite(v) & (v > 0))
        arrays.append((t,a))
        monthly[month] = {'source_minutes_per_asset':len(t),'valid_assetminutes':0,'candidates':0,'selected':0,'overlap_rejects':0,'censored':0}
        source_pins.append({'month':month,'sha256':sha(path),'bytes':path.stat().st_size})
    times = [int(v) for t,_ in arrays for v in t]
    assert len(times) == 525600 and times == list(range(start,end,M))
    fields = {s: {f:np.concatenate([a[s][f] for _,a in arrays]) for f in ('open','close','mark')} for s in SYMS}
    candidates = []
    selected = []
    by_symbol = {}
    # Exhaustive scalar iteration: every asset-minute, no selection by returns.
    for symbol in SYMS:
        previous_exit = -1
        counts = {'source_minutes':0,'valid_signal_minutes':0,'candidates':0,'selected':0,'overlap_rejects':0,'censored':0}
        for i,t in enumerate(times):
            counts['source_minutes'] += 1
            trade,mark = float(fields[symbol]['close'][i]),float(fields[symbol]['mark'][i])
            available = t+M+1
            signal = ref_signal(t,trade,mark,available,end+1)
            month = utc(t)[:7]
            if signal is None:
                continue
            counts['valid_signal_minutes'] += 1
            monthly[month]['valid_assetminutes'] += 1
            if abs(signal) < 50:
                continue
            counts['candidates'] += 1
            monthly[month]['candidates'] += 1
            ready,en,ex = ref_proposal(times,available)
            if en is None:
                status='CENSORED_ENTRY_OUTSIDE_2025'
            elif times[en] < previous_exit:
                status='REJECT_OVERLAP'
            elif ex is None:
                status='CENSORED_EXACT_60MIN_EXIT_UNAVAILABLE'
            else:
                status='SELECTED'
                previous_exit=times[ex]
            key = 'selected' if status == 'SELECTED' else 'overlap_rejects' if status == 'REJECT_OVERLAP' else 'censored'
            counts[key] += 1
            monthly[month][key] += 1
            record = dict(symbol=symbol,feature_open_us=t,feature_completion_us=t+M,
                          feature_available_us=available,order_ready_us=ready,
                          feature_utc=utc(t),signal_bp=signal,direction=1 if signal>0 else -1,
                          status=status,feature_trade_close=trade,feature_mark_close=mark,
                          entry_us=None if en is None else times[en],
                          exit_us=None if ex is None else times[ex])
            candidates.append(record.copy())
            if status=='SELECTED':
                # Entire event identity selected before any return observation.
                record.update(entry_index=en,exit_index=ex)
                selected.append(record)
        by_symbol[symbol]=counts
    sortkey=lambda r:(r['feature_open_us'],SYMS.index(r['symbol']))
    candidates.sort(key=sortkey)
    selected.sort(key=sortkey)
    author_candidates=json.loads((AUTHOR/'ALL_CANDIDATES.json').read_text())
    assert len(candidates)==len(author_candidates)==131
    for mine,theirs in zip(candidates,author_candidates):
        assert mine.keys()==theirs.keys()
        for k,v in mine.items():
            if isinstance(v,float): close(v,theirs[k])
            else: assert v==theirs[k],(k,v,theirs[k])
    # Independent direct scan of literal funding events, no unit conversion.
    funding_path=SOURCE/'EVENTS.json'
    assert sha(funding_path)==protocol['inputs']['funding']['SHA256']
    assert funding_path.stat().st_size==protocol['inputs']['funding']['bytes']
    funding=json.loads(funding_path.read_text())
    assert len(funding)==5475
    assert all(start <= f['event_us'] < end and f['symbol'] in SYMS for f in funding)
    author_events=list(csv.DictReader((AUTHOR/'EVENTS.csv').open()))
    assert len(selected)==len(author_events)==46
    receipt=[]
    funding_matches=0
    for mine,theirs in zip(selected,author_events):
        for k,v in mine.items():
            if k in ('entry_index','exit_index'):continue
            if isinstance(v,(int,float)):close(v,theirs[k])
            else:assert v==theirs[k]
        s=mine['symbol']; en=mine.pop('entry_index'); ex=mine.pop('exit_index')
        p0,p1=float(fields[s]['open'][en]),float(fields[s]['open'][ex])
        gross=mine['direction']*(p1-p0)/p0*10000.0
        # Distinct algebraic evaluation checks unit and short-return convention.
        close(gross,float(theirs['gross_price_bp']))
        close(-gross,float(theirs['reverse_gross_price_bp']))
        close(gross-27,float(theirs['net_27bp_diagnostic']))
        close(-gross-27,float(theirs['reverse_net_27bp_diagnostic']))
        close(p0,theirs['entry_trade_open']);close(p1,theirs['exit_trade_open'])
        included=[f for f in funding if f['symbol']==s and mine['entry_us']<=f['event_us']<mine['exit_us']]
        raw=sum(f['raw_rate'] for f in included)
        close(raw,theirs['raw_rate_sum'])
        close(-mine['direction']*raw,theirs['signed_raw_rate_coefficient'])
        close(mine['direction']*raw,theirs['reverse_signed_raw_rate_coefficient'])
        assert len(included)==int(theirs['raw_funding_events'])
        assert ';'.join(str(f['event_us']) for f in included)==theirs['raw_funding_event_us']
        funding_matches+=len(included)
        assert mine['entry_us']==mine['feature_open_us']+5*M
        assert mine['entry_us']>=mine['order_ready_us']>mine['feature_available_us']>mine['feature_completion_us']
        assert mine['exit_us']==mine['entry_us']+60*M
        mine.update(entry_trade_open=p0,exit_trade_open=p1,gross_price_bp=gross,
                    included_raw_funding=included,signed_raw_rate_coefficient=-mine['direction']*raw)
        receipt.append(mine)
    result=json.loads((AUTHOR/'RESULT.json').read_text())
    values=[r['gross_price_bp'] for r in selected]
    compare_stats(result['toward_mark'],stats(values))
    compare_stats(result['reverse_placebo'],stats([-x for x in values]))
    for s in SYMS:
        for key,v in by_symbol[s].items(): assert result['coverage'][s][key]==v
        compare_stats(result['by_asset'][s]['toward_mark'],stats([r['gross_price_bp'] for r in selected if r['symbol']==s]))
        compare_stats(result['by_asset'][s]['reverse'],stats([-r['gross_price_bp'] for r in selected if r['symbol']==s]))
    for month in monthly:
        assert result['by_month'][month]['candidate_signals']==monthly[month]['candidates']
        compare_stats(result['by_month'][month]['toward_mark'],stats([r['gross_price_bp'] for r in selected if r['feature_utc'].startswith(month)]))
        compare_stats(result['by_month'][month]['reverse'],stats([-r['gross_price_bp'] for r in selected if r['feature_utc'].startswith(month)]))
    assert len({r['feature_utc'][:10] for r in selected})==26
    assert funding_matches==7
    close(sum(r['signed_raw_rate_coefficient'] for r in selected),result['raw_funding_attribution']['summed_signed_raw_rate_coefficient'])
    # Nonoverlap across calendar boundaries; concurrent different symbols retained.
    for s in SYMS:
        rr=[r for r in selected if r['symbol']==s]
        assert all(b['entry_us']>=a['exit_us'] for a,b in zip(rr,rr[1:]))
    # Clock/mutation tests against author's helpers, no main execution or writes.
    spec=importlib.util.spec_from_file_location('author_event_study',AUTHOR/'event_study.py')
    e=importlib.util.module_from_spec(spec);spec.loader.exec_module(e)
    tests=[]
    grid=np.arange(300,dtype=np.int64)*M
    prices=np.full(300,100.0);marks=np.full(300,101.0);arrivals=grid+M+1
    for clock in (M-1000,M,M+1,4*M,4*M+1,10*M+1):
        idx,val=e.visible_signal(grid,prices,marks,arrivals,clock)
        expected=[i for i,t in enumerate(grid) if ref_signal(int(t),100,101,int(arrivals[i]),clock) is not None]
        assert list(idx)==expected
        for x in val:close(x,100)
    tests.append('completed-minute and availability masks against independent scalar reference')
    idx,val=e.visible_signal(grid,prices,marks,arrivals,10*M+1)
    m2=marks.copy();p2=prices.copy();future=arrivals>10*M+1
    m2[future]=1e30;p2[future]=float('nan')
    idx2,val2=e.visible_signal(grid,p2,m2,arrivals,10*M+1)
    assert np.array_equal(idx,idx2) and np.array_equal(val,val2)
    delayed=arrivals.copy();delayed[0]=20*M
    idx,_=e.visible_signal(grid,prices,marks,delayed,10*M+1)
    assert 0 not in idx
    tests.append('future values and delayed arrivals cannot enter visible feature set')
    for available in (M+1,10*M+1,235*M+1,295*M+1):
        assert e.proposal(grid,available)==ref_proposal(list(grid),available)
    gapped=np.delete(grid,65)
    assert e.proposal(gapped,M+1)==ref_proposal(list(gapped),M+1)
    assert e.proposal(grid,M+1)==(4*M+1,5,65)
    tests.append('strict ready-time first future open, exact 60-minute missing endpoint, year-end censoring')
    test_indices=[0,1,59,60,61,235]
    expected_status=['SELECTED','REJECT_OVERLAP','REJECT_OVERLAP','SELECTED','REJECT_OVERLAP','CENSORED_EXACT_60MIN_EXIT_UNAVAILABLE']
    assert [r['status'] for r in e.select(grid,test_indices,[50,-50,70,80,90,60])]==expected_status
    tests.append('earliest nonoverlap admits touching endpoints and censors unavailable exact exit')
    ft=np.array([5*M-1,5*M,5*M+15000,65*M-1,65*M],dtype=np.int64)
    nf,raw,clocks=e.funding_events(ft,np.array([1.,2.,3.,4.,5.]),5*M,65*M)
    assert (nf,raw,clocks)==(3,9.,[5*M,5*M+15000,65*M-1])
    tests.append('literal raw funding entry-inclusive exit-exclusive boundaries preserve unrounded clocks')
    # Descriptive influence only: each row algebraically decomposes the fixed mean.
    total=math.fsum(values);n=len(values);mean=total/n
    influence=[]
    for r in selected:
        g=r['gross_price_bp']
        influence.append({'symbol':r['symbol'],'feature_utc':r['feature_utc'],
                          'gross_price_bp':g,'fraction_of_signed_total':g/total,
                          'contribution_to_fixed_46_event_mean_bp':g/n,
                          'leave_one_event_mean_influence_bp':(g-mean)/(n-1),
                          'leave_one_event_algebraic_mean_bp':(total-g)/(n-1)})
    influence.sort(key=lambda r:abs(r['leave_one_event_mean_influence_bp']),reverse=True)
    october=[r for r in selected if r['feature_utc'].startswith('2025-10')]
    oct10=[r for r in selected if r['feature_utc'].startswith('2025-10-10')]
    concentration={'method':'Descriptive decomposition of the unchanged fixed event sample only. Leave-one-event figures quantify estimator influence, not an exclusion strategy or investable performance. No new threshold, horizon, direction, asset or month recipe is run.',
                   'sum_equal_entry_notional_event_proxy_bp':total,
                   'october_event_count':len(october),'october_fraction_of_signed_total':math.fsum(r['gross_price_bp'] for r in october)/total,
                   'oct10_event_count':len(oct10),'oct10_fraction_of_signed_total':math.fsum(r['gross_price_bp'] for r in oct10)/total,
                   'positive_gross_events':sum(x>0 for x in values),'positive_after_27bp_events':sum(x>27 for x in values),
                   'all_event_influence':influence}
    # Verify author pins still unchanged for files captured on entry.
    assert all(sha(AUTHOR/name)==digest for name,digest in original_pins.items())
    save('INDEPENDENT_EVENT_RECEIPT.json',receipt)
    save('INDEPENDENT_CANDIDATE_RECEIPT.json',candidates)
    save('INDEPENDENT_INFLUENCE.json',concentration)
    report={'status':'PASS_SCALAR_CANONICAL_SOURCE_ARITHMETIC_AND_CLOCKS',
            'protocol_sha256':EXPECTED_PROTOCOL,'author_files_pinned_on_review_entry':original_pins,
            'source_pins':source_pins,'calendar':[utc(start),utc(end)],
            'scalar_valid_assetminutes':sum(v['valid_signal_minutes'] for v in by_symbol.values()),
            'candidates':len(candidates),'selected_events':len(selected),
            'overlap_rejects':sum(v['overlap_rejects'] for v in by_symbol.values()),
            'censored':sum(v['censored'] for v in by_symbol.values()),
            'event_utc_days':26,'toward_mark':stats(values),'reverse_placebo':stats([-v for v in values]),
            'by_symbol':by_symbol,'all_calendar_months':monthly,'synthetic_tests':tests,
            'selected_literal_raw_funding_events':funding_matches,
            'raw_rate_sum_direction_coefficient':sum(r['signed_raw_rate_coefficient'] for r in selected),
            'raw_funding_added_to_price_return':False,'financial_simulation':False,
            'new_source_downloads':0,'author_main_executed':False,
            'source_protocol_ordering_note':'Protocol hash and pre-run pins match. Review validates consistent recorded freeze receipts, not independent wall-clock attestation of all historical read ordering.',
            'pending':'Separate raw-provider field/price check is a required companion to this canonical-array review.',
            'seconds':time.monotonic()-begin}
    save('SCALAR_REVIEW.json',report)
    print(json.dumps({k:report[k] for k in ('status','scalar_valid_assetminutes','candidates','selected_events','overlap_rejects','censored','event_utc_days','toward_mark','seconds')},indent=2))

if __name__=='__main__':main()
