# Independent review: completed-minute mark/trade event study

## Decision

**PASS for the frozen 2025 seen-development event-study arithmetic, source fields, timing, sample selection and reporting. This is not a validated executable signal.** No selected raw price, unit, clock, nonoverlap, calendar-mask or return-arithmetic mismatch was found. The unusually large mean is crash-concentrated and the most influential event does not demonstrate entry-time convergence toward mark.

Reviewed protocol SHA256: `deeda6e5aa8914513f7b96157e15213cad5c688a5b683482b43bbe3aaec15cce`.

## Independent checks

1. The reference implementation did not import or run the author's study during its real-source calculation. It scanned each of the 2,628,000 asset-minutes with scalar feature arithmetic and used independent integer clocks and Python bisect for entry/exit scheduling. The author's helper functions were imported only afterward for synthetic comparisons; its main was never called.
2. All 12 pinned canonical month NPZ hashes and byte sizes, source-index hash, five-asset order, exact continuous UTC minute grid, positive finite trade OPEN/CLOSE and mark CLOSE, and complete natural-year coverage match. All full-calendar and threshold-candidate signal ranges/quantiles match independently.
3. The scalar reference exactly reproduces all 131 candidate records, 85 overlap rejects, 46 selected events on 26 UTC dates, zero censoring, every selected feature/availability/readiness/entry/exit clock, price and direction. Per-asset counts are BTC/ETH/SOL/XRP/DOGE = 1/8/9/10/18. All 12 month counts and both-direction summary statistics match, including December's zero events.
4. The source clock is minute BAR OPEN. A feature completes at OPEN+60 seconds and becomes available under the declared proxy at completion+1 microsecond. Three more full minutes makes readiness OPEN+4 minutes+1 microsecond, so the first eligible scheduled future OPEN is OPEN+5 minutes. All exits are exactly entry+60 minutes. Same-asset intervals do not overlap; touching endpoints and concurrent different assets are retained.
5. All 184 selected raw price fields match exactly: 46 trade feature CLOSE, 46 mark feature CLOSE, 46 trade entry OPEN and 46 trade exit OPEN. The separate raw audit verifies 60 exact cached 2025 price archives against pinned SHA/bytes, official checksum text and inner CSV CRC, including full-month ordered minute grids, inclusive raw close=OPEN+59,999ms, OHLC and applicable trade-volume invariants. Field positions and original strings/line numbers are retained in `raw_check/RAW_ROW_RECEIPT.json`.
6. Synthetic checks cover completed-minute and availability boundaries, unavailable future-value perturbations, delayed arrival, rejection of elapsed OPEN, exact endpoint censoring, earliest nonoverlap and literal funding interval boundaries. The real selection only depends on completed feature prices and clocks; future entry/exit OPEN prices enter only after event identity is fixed.
7. All seven selected funding inclusions match prepared EVENTS.json and exact cached raw funding members with original calc-time offsets, including ETH May 9 +6ms. The aggregate signed raw-rate coefficient is +0.00033534. It remains separate from price returns; no funding-rate-to-bp conversion or settlement claim is made.
8. All recorded pre-run file hashes still match. Recorded protocol/freezing receipts are internally consistent. Their existence is not independent wall-clock proof of every earlier source-read ordering.

## Fixed-sample result and descriptive influence

- Mean gross price proxy: +177.2194218bp; median +5.6865000bp
- Mean minus fixed 27bp diagnostic: +150.2194218bp; median minus 27bp: -21.3135000bp
- 24/46 have positive gross; 21/46 exceed 27bp
- Reverse placebo uses exactly the same 46 events and exactly negative gross returns, with mean -177.2194218bp. Applying the same 27bp cost to both directions produces the expected per-event sum of -54bp
- Seven October events account for 124.874% of the signed full-sample gross proxy sum; five October 10 events account for 121.626%
- DOGE October 10 alone accounts for 74.659% of the signed sum and contributes 132.3109911bp to the fixed 46-event mean
- Its leave-one-event mean influence is 131.3130260bp. The corresponding algebraic mean is 45.9063958bp; this is an estimator-sensitivity diagnostic, not a tested exclusion strategy or a proposed filter. All events remain in the result

The complete 46-row influence decomposition is in `INDEPENDENT_INFLUENCE.json`. Its sums are sums of equal-entry-notional event proxies, not an invested portfolio return. No asset, event, direction, month, threshold or horizon was selected or removed on outcome.

### Funding interval convention is not native charge reconciliation

The original study's `[entry,exit)` convention is literal raw timestamp attribution only. The +177.2194218bp mean and +150.2194218bp mean-minus-27bp do not contain funding. A separate native funding-before-fill model may require `(entry,exit]` instead. An independent scan of all 46 fixed events finds **zero funding rows exactly at any selected entry or exit**, so the seven attributed rows are unchanged under that alternate boundary convention for this sample. This equality does not certify historical units, charge mark, position ownership or actual settlement. All event boundary checks are retained in `FUNDING_BOUNDARY_REVIEW.json`.

## DOGE extreme: raw-valid, mechanism and execution uncertified

The 2025-10-10 21:15 feature has raw trade CLOSE 0.188940 and mark CLOSE 0.19138594, signal +129.4559119bp. Availability is 21:16:00.000001; readiness 21:19:00.000001; entry is 21:20 trade OPEN 0.113550; exit is 22:20 trade OPEN 0.182660. This exactly produces +6086.3055923bp.

The entry bar is O/H/L/C = 0.113550/0.113750/0.083850/0.088560, with 266,531,353 base volume and 35,527 trades. The prior minute closes at 0.112570. Raw OHLCV and the paired neighborhood support an extreme-valued crash/rebound bar, rather than an accidental OPEN/CLOSE or timestamp swap. They do not prove executable capacity or independently validate the original exchange source.

The paired entry-minute mark OPEN is already 0.11171000, approximately **-162.043153bp relative to trade OPEN**, while the frozen feature direction is positive from five minutes earlier. Trade price has fallen approximately 39.90% from feature CLOSE to entry OPEN. These paired bar fields are descriptive source references, not certified arrival-time quotes. The large winner therefore cannot be described as demonstrated convergence of the entry-time trade price toward an above-market mark. The study correctly measures a delayed fixed-feature-sign price proxy, amid a crash/rebound.

## Limits and smallest useful next test

The event study is valid as a seen-development descriptive proxy. Its sample-count floor does not establish independent evidence. Event clustering, adaptive prior research, uncertain feature publication/arrival, raw mark construction, first-print versus tradable quotes and the fixed 27bp diagnostic remain material. Actual capacity, bid/ask spread, adverse selection, latency, slippage, historical fees, minimum lot/notional filters, margin/liquidation, concurrent shared-wallet capital and raw funding units/charge-mark/ownership/settlement are not certified. No annualization is justified.

The smallest useful next test is a **read-only execution-feasibility audit of these same 46 frozen events**, with one tiny, predeclared notional and unchanged direction/clocks/horizon. Obtain or locate historical side-specific quotes/trades around the already-fixed entry/exit timestamps and historical contract filters/fees; verify first realistically available fill, lot/min-notional orderability, spread/slippage and simultaneous capital demand. Include every fixed event, including the DOGE crash and missing-data cases, and report infeasible/unverifiable events explicitly. Do not infer fills or depth from minute volume, replace an event, tune a delay, or convert unknown funding units. If the necessary quote/filter/arrival data are unavailable, stop with that coverage blocker before running an account model. This is a data/orderability test, not another recipe or a portfolio simulation.

## Reproduction and artifact boundary

`independent_scalar_review.py` and `supplement_pins_and_distributions.py` are the independent reference/check scripts. Their real-source calculations read only pinned local 2025 canonical arrays; `raw_check/verify_raw_event_prices.py` uses exact existing raw caches. No provider downloads, 2026 source bodies, financial account constructors/advances, Library or GitHub writes, modifications to pre-existing author source/data/results, or deletions were used. Importing author helpers for synthetic tests created the ordinary Python bytecode cache under the author directory; it was left intact under the no-deletes boundary, and the review script now disables future bytecode writes. Each script is single-threaded and pins one allowed CPU. Outputs are below the 2MB review budget.

The author appended final review/source-locator prose to its REPORT.md while this review was in progress. All other files pinned on initial review entry, including protocol, source code, events, candidates, selection and numerical results, remain unchanged. The final manifest records the appended report hash separately.

The existing author archive `mark_trade_minute_event2025_artifacts.zip` was read back without modification. It already contains the current 10,968-byte author report, SHA256 `53fcdddc3ce0656034199583f69414d8152f7ab1a9a61de0cf43d03493f091e5`, rather than the earlier review-start report. The archive has no `__pycache__` or `.pyc` members. Full archive/member version evidence is in `AUTHOR_REPORT_ARCHIVE_VERSION.json`; no re-packaging was performed.

`SCALAR_REVIEW.json` was written before the separate raw audit completed, so its pending-companion field describes that intermediate snapshot. The final decision here includes the completed raw audit and is summarized in `REVIEW_RESULT.json`.
