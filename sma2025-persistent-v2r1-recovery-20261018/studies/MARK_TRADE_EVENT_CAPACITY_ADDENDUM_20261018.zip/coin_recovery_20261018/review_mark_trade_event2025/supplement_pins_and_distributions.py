"""Independent frozen pin and full-calendar feature-distribution checks."""
import hashlib
import json
import math
from pathlib import Path
import os
import numpy as np

here=Path(__file__).resolve().parent
author=here.parent/'mark_trade_minute_event2025'
source=here.parent/'restored2025'/'prepared_2025'
os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pins=json.loads((author/'PRE_RUN_PINS.json').read_text())
checked={name:sha(author/name)==value for name,value in pins['files'].items()}
assert all(checked.values())
assert json.loads((author/'FREEZE_RECEIPT.json').read_text())['protocol_SHA256']==sha(author/'PROTOCOL.json')
result=json.loads((author/'RESULT.json').read_text())
protocol=json.loads((author/'PROTOCOL.json').read_text())
all_signals={s:[] for s in protocol['assets']}
for m in protocol['inputs']['canonical_months']:
    with np.load(source/'months'/(m['month']+'.npz'),allow_pickle=False) as z:
        for s in protocol['assets']:
            # Scalar feature arithmetic independent from author's vector operation.
            all_signals[s].extend(10000.0*(float(mark)/float(trade)-1.0) for trade,mark in zip(z[s+'_close'],z[s+'_mark']))
distributions={}
for s,vals in all_signals.items():
    distributions[s]={}
    for key,arr in [('feature_distribution',vals),('threshold_candidate_distribution',[v for v in vals if abs(v)>=50.])]:
        ref={'n':len(arr),'min_bp':min(arr),'max_bp':max(arr),
             'abs_quantiles_bp':{str(q):float(np.quantile(np.abs(arr),q)) for q in [0,.5,.9,.99,.999,1]}}
        expected=result['coverage'][s][key]
        assert expected['n']==ref['n']
        for field in ('min_bp','max_bp'):
            assert math.isclose(expected[field],ref[field],rel_tol=1e-12,abs_tol=1e-10)
        for q,v in ref['abs_quantiles_bp'].items():
            assert math.isclose(v,expected['abs_quantiles_bp'][q],rel_tol=1e-12,abs_tol=1e-10)
        distributions[s][key]=ref
out={'status':'PASS','pre_run_pin_matches':checked,
     'all_five_full_calendar_and_candidate_distributions_match':True,
     'distributions':distributions,'new_hyperparameter_recipes':0,
     'financial_simulation':False,'source_scope':'pinned 2025 canonical only'}
with (here/'PINS_AND_DISTRIBUTIONS.json').open('x') as f:
    json.dump(out,f,indent=2,sort_keys=True,allow_nan=False);f.write('\n')
print('PASS: all pre-run pins, full-calendar and candidate signal distributions')
