"""Independent source-only event receipt. Reads cached 2025 members, writes review only."""
import calendar
import csv
import datetime as dt
import hashlib
import io
import json
import math
import os
from pathlib import Path
import resource
import time
import zipfile

for name in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[name] = '1'
import numpy as np

BASE = Path('/workspace/scratch/68ef1b82bcac/coin_recovery_20261018')
ROOT = BASE / 'restored2025'
EVENT = BASE / 'mark_trade_minute_event2025'
OUT = BASE / 'review_mark_trade_event2025/raw_check'
PROTOCOL_SHA = 'deeda6e5aa8914513f7b96157e15213cad5c688a5b683482b43bbe3aaec15cce'
PRICE_HEADER = ['open_time', 'open', 'high', 'low', 'close', 'volume', 'close_time', 'quote_volume', 'count', 'taker_buy_volume', 'taker_buy_quote_volume', 'ignore']
FUN_HEADER = ['calc_time', 'funding_interval_hours', 'last_funding_rate']
START_US, END_US = 1735689600000000, 1767225600000000
UTC = dt.timezone.utc

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def stamp(us):
    return dt.datetime.fromtimestamp(us / 1_000_000, UTC).isoformat()

def read_json(path):
    return json.loads(path.read_bytes())

def month_bounds(month):
    y, m = map(int, month.split('-'))
    start = int(dt.datetime(y, m, 1, tzinfo=UTC).timestamp() * 1000)
    return start, start + calendar.monthrange(y, m)[1] * 86_400_000

def single_csv(raw):
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        infos = z.infolist()
        assert len(infos) == 1 and not infos[0].flag_bits & 1
        body = z.read(infos[0])  # Fully read one allowed CSV; zipfile verifies its CRC.
        return infos[0].filename, sha(body), body.decode('utf-8-sig')

def close_enough(a, b, tol=1e-10):
    return abs(a - b) <= tol

began = time.monotonic()
os.sched_setaffinity(0, {min(os.sched_getaffinity(0))})
protocol_raw = (EVENT / 'PROTOCOL.json').read_bytes()
assert sha(protocol_raw) == PROTOCOL_SHA
protocol = json.loads(protocol_raw)
index_raw = (ROOT / 'prepared_2025/SOURCE_INDEX.json').read_bytes()
assert sha(index_raw) == protocol['inputs']['source_index_SHA256']
index = json.loads(index_raw)
event_raw = (EVENT / 'EVENTS.csv').read_bytes()
events = list(csv.DictReader(io.StringIO(event_raw.decode())))
assert len(events) == 46 and all(r['status'] == 'SELECTED' for r in events)
assert all(START_US <= int(r['feature_open_us']) < int(r['entry_us']) < int(r['exit_us']) < END_US for r in events)

source_by_key = {}
for month in index['months']:
    for s in month['sources']:
        source_by_key[(month['month'], s['symbol'], s['family'])] = s
h2 = read_json(BASE / 'remote_map/raw2025_h2_index.json')
h2_by_path = {r['raw_path']: (i, r) for i, r in enumerate(h2['archives'])}
h1_path = ROOT / 'h1/coin_frozen_e5_2025h1_increment_20261008.zip'
h1 = zipfile.ZipFile(h1_path)
tails = [(p, zipfile.ZipFile(p)) for p in sorted((ROOT / 'tail').glob('*.zip'))]
fund_path = ROOT / 'funding/PRIMITIVES.zip'
fund = zipfile.ZipFile(fund_path)
opened_wrappers = [(h1_path, h1), *tails, (fund_path, fund)]
assert all(len(z.namelist()) == len(set(z.namelist())) for _, z in opened_wrappers)

required = {}
for event_id, r in enumerate(events, 1):
    sym = r['symbol']
    for role, clock, family in [('feature_trade', 'feature_open_us', 'klines'), ('feature_mark', 'feature_open_us', 'markPriceKlines'), ('entry_trade', 'entry_us', 'klines'), ('exit_trade', 'exit_us', 'klines')]:
        us = int(r[clock])
        key = (stamp(us)[:7], sym, family)
        required.setdefault(key, set()).add(us // 1000)

doge_feature_ms = 1760130900000
doge_entry_ms = 1760131200000
doge_exit_ms = 1760134800000
neighborhood_times = set(range(doge_entry_ms - 15 * 60000, doge_entry_ms + 16 * 60000, 60000))
neighborhood_times |= set(range(doge_exit_ms - 2 * 60000, doge_exit_ms + 3 * 60000, 60000))
for family in ['klines', 'markPriceKlines']:
    required[('2025-10', 'DOGEUSDT', family)] |= neighborhood_times

archive_receipts = []
rows_by_key = {}
for key in sorted(required):
    month, symbol, family = key
    assert month.startswith('2025-')
    pin = source_by_key[key]
    stem = f'{symbol}-1m-{month}.zip'
    if month == '2025-01':
        member = f'tail_data/data/raw/{family}/{symbol}/{stem}'
        matches = [(p, z) for p, z in tails if member in z.namelist()]
        assert len(matches) == 1
        path, z = matches[0]
        raw = z.read(member)
        checksum = z.read(member + '.CHECKSUM')
        location = {'wrapper': str(path.relative_to(BASE)), 'member': member}
    elif month <= '2025-06':
        member = f'market/data/raw/{family}/{symbol}/{stem}'
        raw = h1.read(member)
        checksum = h1.read(member + '.CHECKSUM')
        location = {'wrapper': str(h1_path.relative_to(BASE)), 'member': member}
    else:
        h2_id, h2pin = h2_by_path[f'raw/{family}/{symbol}/{stem}']
        path = ROOT / f'h2/archive{h2_id:03d}.zip'
        raw = path.read_bytes()
        checksum = (ROOT / f'h2/archive{h2_id:03d}.CHECKSUM').read_bytes()
        assert sha(raw) == h2pin['SHA256'] and len(raw) == h2pin['bytes']
        assert sha(checksum) == h2pin['checksum_SHA256']
        location = {'archive': str(path.relative_to(BASE)), 'indexed_raw_path': h2pin['raw_path']}
    assert sha(raw) == pin['original_SHA256'] and len(raw) == pin['bytes']
    tokens = checksum.decode().strip().split()
    assert len(tokens) == 2 and tokens[0].lower() == sha(raw) and tokens[1].lstrip('*') == stem
    inner_member, csv_sha, text = single_csv(raw)
    reader = csv.reader(io.StringIO(text))
    header = next(reader)
    assert header == PRICE_HEADER
    lo, hi = month_bounds(month)
    selected = {}
    count = 0
    volume_checks = {'negative_values': 0, 'noninteger_count': 0, 'taker_exceeds_total': 0, 'volume_vwap_outside_ohlc': 0}
    special_month_rows = []
    for line_number, row in enumerate(reader, 2):
        assert len(row) == 12
        t = int(row[0])
        assert t == lo + count * 60000 and int(row[6]) == t + 59999
        values = [float(x) for x in row]
        assert all(math.isfinite(x) for x in values)
        o, h, l, c = values[1:5]
        assert min(o, h, l, c) > 0 and l <= min(o, c) <= max(o, c) <= h
        if family == 'klines':
            v, q, n, tb, tq = [values[i] for i in [5, 7, 8, 9, 10]]
            volume_checks['negative_values'] += int(min(v, q, n, tb, tq) < 0)
            volume_checks['noninteger_count'] += int(n != int(n))
            volume_checks['taker_exceeds_total'] += int(tb > v + 1e-8 or tq > q + max(1e-8, q * 1e-12))
            if v:
                volume_checks['volume_vwap_outside_ohlc'] += int(not (l - max(1e-10, h * 1e-10) <= q / v <= h + max(1e-10, h * 1e-10)))
        if t in required[key]:
            selected[t] = {'line_number_1_based': line_number, 'fields': row}
        if key == ('2025-10', 'DOGEUSDT', 'klines'):
            special_month_rows.append((t, o, h, l, c, float(row[5]), float(row[7]), int(row[8])))
        count += 1
    assert count == (hi - lo) // 60000 and lo + count * 60000 == hi
    assert set(selected) == required[key]
    assert not any(volume_checks.values()), (key, volume_checks)
    rows_by_key[key] = selected
    archive_receipts.append({'month': month, 'symbol': symbol, 'family': family, 'raw_zip_sha256': sha(raw), 'raw_zip_bytes': len(raw), 'official_checksum_text': checksum.decode().strip(), 'checksum_sha256': sha(checksum), 'csv_member': inner_member, 'csv_sha256': csv_sha, 'csv_header': header, 'data_rows': count, 'full_month_exact_minute_grid': True, 'full_month_inclusive_close_open_plus_59999ms': True, 'full_month_positive_ohlc_envelope': True, 'trade_volume_checks': volume_checks if family == 'klines' else 'mark volume/count fields are non-tradable reference fields', 'selected_raw_rows_retained': len(selected), **location})
    if special_month_rows:
        doge_month = special_month_rows

canonical = {}
canonical_receipts = []
for month in sorted(set(r['feature_utc'][:7] for r in events) | set(r['entry_utc'][:7] for r in events) | set(r['exit_utc'][:7] for r in events)):
    path = ROOT / 'prepared_2025/months' / (month + '.npz')
    raw = path.read_bytes()
    pin = next(x for x in index['months'] if x['month'] == month)
    assert sha(raw) == pin['source_NPZ_SHA256'] and len(raw) == pin['source_NPZ_bytes']
    with np.load(io.BytesIO(raw), allow_pickle=False) as z:
        canonical[month] = {k: z[k].copy() for k in z.files}
    canonical_receipts.append({'month': month, 'path': str(path.relative_to(BASE)), 'sha256': sha(raw), 'bytes': len(raw)})

event_receipts = []
def raw_for(symbol, us, family):
    return rows_by_key[(stamp(us)[:7], symbol, family)][us // 1000]

for event_id, r in enumerate(events, 1):
    s = r['symbol']
    f, completion, avail, ready, entry, exit = [int(r[k]) for k in ['feature_open_us', 'feature_completion_us', 'feature_available_us', 'order_ready_us', 'entry_us', 'exit_us']]
    assert completion == f + 60_000_000 and avail == completion + 1 and ready == avail + 180_000_000
    assert entry == ((ready + 59_999_999) // 60_000_000) * 60_000_000 == f + 300_000_000
    assert exit == entry + 3_600_000_000
    assert [r['feature_utc'], r['entry_utc'], r['exit_utc']] == [stamp(t) for t in [f, entry, exit]]
    checks = []
    for role, us, family, offset, event_field, canonical_suffix in [('feature_trade', f, 'klines', 4, 'feature_trade_close', 'close'), ('feature_mark', f, 'markPriceKlines', 4, 'feature_mark_close', 'mark'), ('entry_trade', entry, 'klines', 1, 'entry_trade_open', 'open'), ('exit_trade', exit, 'klines', 1, 'exit_trade_open', 'open')]:
        raw_row = raw_for(s, us, family)
        fields = raw_row['fields']
        assert int(fields[0]) * 1000 == us and int(fields[6]) == us // 1000 + 59999
        value = float(fields[offset])
        assert value == float(r[event_field])
        month = stamp(us)[:7]
        arrays = canonical[month]
        n = int(np.searchsorted(arrays['times'], us))
        assert int(arrays['times'][n]) == us and value == float(arrays[s + '_' + canonical_suffix][n])
        checks.append({'role': role, 'archive_key': [month, s, family], 'requested_open_us': us, 'raw_open_time_ms': int(fields[0]), 'raw_inclusive_close_time_ms': int(fields[6]), 'raw_open_utc': stamp(int(fields[0]) * 1000), 'raw_inclusive_close_utc': stamp(int(fields[6]) * 1000), 'price_field_offset_zero_based': offset, 'price_field_name': PRICE_HEADER[offset], 'event_price_field': event_field, 'exact_float_match_event_and_canonical': True, 'canonical_row_offset_zero_based': n, **raw_row})
    raw_signal = 10000 * (float(checks[1]['fields'][4]) / float(checks[0]['fields'][4]) - 1)
    assert close_enough(raw_signal, float(r['signal_bp'])) and abs(raw_signal) >= 50
    assert int(r['direction']) == (1 if raw_signal > 0 else -1)
    gross = int(r['direction']) * 10000 * (float(checks[3]['fields'][1]) / float(checks[2]['fields'][1]) - 1)
    assert close_enough(gross, float(r['gross_price_bp']))
    assert close_enough(gross - 27, float(r['net_27bp_diagnostic']))
    assert close_enough(-gross, float(r['reverse_gross_price_bp']))
    assert close_enough(-gross - 27, float(r['reverse_net_27bp_diagnostic']))
    event_receipts.append({'event_id_1_based': event_id, 'symbol': s, 'feature_utc': r['feature_utc'], 'independent_signal_bp': raw_signal, 'independent_gross_price_bp': gross, 'exact_clock_and_field_checks': True, 'raw_rows': checks})

funding_receipts = []
for event_id, r in enumerate(events, 1):
    if int(r['raw_funding_events']) == 0:
        continue
    times = [int(x) for x in r['raw_funding_event_us'].split(';')]
    assert len(times) == int(r['raw_funding_events'])
    matches = []
    for us in times:
        month = stamp(us)[:7]
        pin = next(x for x in index['funding'] if x['month'] == month and x['symbol'] == r['symbol'])
        raw = fund.read(pin['member'])
        assert sha(raw) == pin['raw_SHA256']
        inner_member, csv_sha, text = single_csv(raw)
        reader = csv.reader(io.StringIO(text))
        assert next(reader) == FUN_HEADER
        found = []
        all_times = []
        for line_number, row in enumerate(reader, 2):
            assert len(row) == 3
            t = int(row[0]) * 1000
            assert START_US <= t < END_US and stamp(t)[:7] == month
            all_times.append(t)
            if t == us:
                found.append({'raw_event_us': t, 'raw_event_utc': stamp(t), 'millisecond_offset_after_whole_second': int(row[0]) % 1000, 'fields': row, 'line_number_1_based': line_number, 'wrapper': str(fund_path.relative_to(BASE)), 'member': pin['member'], 'raw_zip_sha256': sha(raw), 'csv_member': inner_member, 'csv_sha256': csv_sha})
        assert len(all_times) == pin['events'] and len(set(all_times)) == len(all_times) and len(found) == 1
        assert int(r['entry_us']) <= us < int(r['exit_us'])
        matches.extend(found)
    raw_sum = sum(float(x['fields'][2]) for x in matches)
    assert raw_sum == float(r['raw_rate_sum'])
    assert -int(r['direction']) * raw_sum == float(r['signed_raw_rate_coefficient'])
    assert int(r['direction']) * raw_sum == float(r['reverse_signed_raw_rate_coefficient'])
    funding_receipts.append({'event_id_1_based': event_id, 'symbol': r['symbol'], 'exact_raw_rate_sum': raw_sum, 'exact_clock_rate_and_attribution_match': True, 'raw_rows': matches})

neighborhood = []
for t in sorted(neighborhood_times):
    trade = raw_for('DOGEUSDT', t * 1000, 'klines')
    mark = raw_for('DOGEUSDT', t * 1000, 'markPriceKlines')
    fields = trade['fields']
    neighborhood.append({'open_utc': stamp(t * 1000), 'trade_row': trade, 'mark_row': mark, 'trade_vwap_quote_over_base': float(fields[7]) / float(fields[5]) if float(fields[5]) else None, 'mark_minus_trade_close_bp': 10000 * (float(mark['fields'][4]) / float(fields[4]) - 1)})
entry_row = raw_for('DOGEUSDT', doge_entry_ms * 1000, 'klines')['fields']
feature_row = raw_for('DOGEUSDT', doge_feature_ms * 1000, 'klines')['fields']
exit_row = raw_for('DOGEUSDT', doge_exit_ms * 1000, 'klines')['fields']
entry_mark_row = raw_for('DOGEUSDT', doge_entry_ms * 1000, 'markPriceKlines')['fields']
prior_row = raw_for('DOGEUSDT', (doge_entry_ms - 60000) * 1000, 'klines')['fields']
doge_notes = {
    'feature_trade_close': feature_row[4], 'feature_mark_close': raw_for('DOGEUSDT', doge_feature_ms * 1000, 'markPriceKlines')['fields'][4],
    'entry_open': entry_row[1], 'entry_high': entry_row[2], 'entry_low': entry_row[3], 'entry_close': entry_row[4],
    'entry_base_volume': entry_row[5], 'entry_quote_volume': entry_row[7], 'entry_trade_count': entry_row[8],
    'entry_vwap': float(entry_row[7]) / float(entry_row[5]),
    'entry_minute_raw_mark_ohlc': dict(zip(['open', 'high', 'low', 'close'], entry_mark_row[1:5])),
    'entry_minute_mark_open_vs_trade_open_bp': 10000 * (float(entry_mark_row[1]) / float(entry_row[1]) - 1),
    'trade_entry_open_vs_feature_trade_close_bp': 10000 * (float(entry_row[1]) / float(feature_row[4]) - 1),
    'previous_minute_close': prior_row[4],
    'entry_open_vs_previous_close_bp': 10000 * (float(entry_row[1]) / float(prior_row[4]) - 1),
    'exit_open': exit_row[1], 'fixed_open_to_open_price_proxy_bp': 10000 * (float(exit_row[1]) / float(entry_row[1]) - 1),
    'october_month_low': min(x[3] for x in doge_month), 'october_month_low_utc': stamp(min(doge_month, key=lambda x: x[3])[0] * 1000),
    'entry_minute_volume_rank_in_october_desc': 1 + sum(x[5] > float(entry_row[5]) for x in doge_month),
    'entry_minute_trade_count_rank_in_october_desc': 1 + sum(x[7] > int(entry_row[8]) for x in doge_month),
    'interpretation': 'The +6086.30559225011bp proxy is reproduced by pinned raw trade OPEN values at exactly 21:20 and 22:20 UTC. The feature mark and trade use CLOSE at exactly 21:15. Trade price fell about 40 percent from feature close to entry open; the entry-minute mark OPEN is below the trade OPEN, opposite to the earlier positive feature sign. This is a stale-feature-direction rebound proxy, not demonstrated convergence of a positive mark/trade gap at entry. The extreme is accompanied by a contiguous, high-volume crash-and-rebound neighborhood with valid OHLC and plausible volume-weighted prices. This rules out these field/time/schema mismatch hypotheses; archived OHLCV cannot establish simultaneous executable liquidity, latency, spread, outages, liquidation or raw-source correctness. No event is excluded or alternative performance computed.',
    'neighborhood': neighborhood,
}

for _, z in opened_wrappers:
    z.close()
assert (EVENT / 'EVENTS.csv').read_bytes() == event_raw
assert sha((EVENT / 'PROTOCOL.json').read_bytes()) == PROTOCOL_SHA
receipt = {
    'schema': 'INDEPENDENT_RAW_EVENT_SOURCE_CHECK_V1', 'status': 'PASS_RAW_FIELDS_CLOCKS_AND_PINNED_CACHE',
    'protocol_sha256': PROTOCOL_SHA, 'events_csv_sha256': sha(event_raw), 'source_index_sha256': sha(index_raw),
    'selected_events': len(events), 'selected_feature_trade_closes': 46, 'selected_feature_mark_closes': 46,
    'selected_entry_trade_opens': 46, 'selected_exit_trade_opens': 46, 'selected_raw_price_rows_checked': 184,
    'price_archives_checked': len(archive_receipts), 'all_184_event_prices_match_raw_and_canonical_exactly': True,
    'all_original_raw_clocks_match_exactly': True, 'all_event_signal_and_price_proxy_arithmetic_match': True,
    'funding_selected_events_verified': len(funding_receipts), 'funding_raw_rows_verified': sum(len(x['raw_rows']) for x in funding_receipts),
    'funding_rate_unit_conversion': 'NONE; literal dimensionless raw rates only',
    'source_boundary': {'provider_requests': 0, 'network_requests': 0, 'outside2025_raw_members_read': 0, 'financial_simulation_or_accounts': 0, 'library_or_github_writes_or_deletes': 0, 'author_outputs_changed': 0, 'threads': 1, 'cpu_affinity': sorted(os.sched_getaffinity(0))},
    'field_offsets_zero_based': dict(enumerate(PRICE_HEADER)), 'canonical_month_pins': canonical_receipts,
    'raw_archive_pins_and_integrity': archive_receipts, 'event_row_receipts': event_receipts,
    'funding_row_receipts': funding_receipts, 'doge_october10_extreme': doge_notes,
    'peak_rss_bytes': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024, 'elapsed_seconds': time.monotonic() - began,
}
body = (json.dumps(receipt, indent=2, sort_keys=True) + '\n').encode()
assert len(body) < 900_000
receipt_path = OUT / 'RAW_ROW_RECEIPT.json'
receipt_path.write_bytes(body)
summary = f'''# Independent raw event source check

PASS: all 46 selected events match the exact pinned cached 2025 raw archives and canonical month arrays. No source mismatch was found.

- Protocol SHA256: {PROTOCOL_SHA}
- EVENTS.csv SHA256: {sha(event_raw)}
- SOURCE_INDEX.json SHA256: {sha(index_raw)}
- {len(archive_receipts)} price archives: exact SHA256/bytes, official checksum text, inner CSV CRC; all rows checked for header, complete ordered one-minute grid, original inclusive close=open+59999ms, positive OHLC envelope and applicable trade-volume invariants.
- 184 selected raw price rows: 46 trade feature closes, 46 mark feature closes, 46 trade entry opens, 46 trade exit opens. Exact float equality to EVENTS.csv and pinned canonical arrays. Original field strings and CSV line numbers retained in RAW_ROW_RECEIPT.json.
- Zero-based raw offsets: open_time=0, OPEN=1, HIGH=2, LOW=3, CLOSE=4, volume=5, inclusive close_time=6, quote volume=7, count=8, taker base=9, taker quote=10, ignore=11. Headers verified for each archive.
- All feature completion/availability/readiness, next eligible entry clocks and exact 60-minute exits independently checked; signal and open-to-open proxy arithmetic matches.
- Seven selected funding event clocks/rates verified against seven exact cached raw funding members. ETH May 9 clock is 1746777600006000 microseconds, preserving the original +6ms source offset. No funding unit conversion performed.

## DOGE October 10 extreme

Feature 2025-10-10 21:15 UTC: raw trade CLOSE {feature_row[4]}; raw mark CLOSE {doge_notes['feature_mark_close']}. Entry 21:20 raw trade OPEN {entry_row[1]}; exit 22:20 raw trade OPEN {exit_row[1]}. These reproduce +6086.30559225011bp exactly.

The entry raw bar is O={entry_row[1]}, H={entry_row[2]}, L={entry_row[3]}, C={entry_row[4]}, base volume={entry_row[5]}, quote volume={entry_row[7]}, trade count={entry_row[8]}. Its VWAP is {doge_notes['entry_vwap']:.12g}, inside its OHLC bounds. The previous minute CLOSE is {prior_row[4]}; entry OPEN change is {doge_notes['entry_open_vs_previous_close_bp']:.8f}bp. The month low is {doge_notes['october_month_low']} at {doge_notes['october_month_low_utc']}.

Trade archive restored2025/h2/archive051.zip SHA256 c2e2ef77ee80bd0d0fef438a5f24dc2f4765de6e3ef0ab36797d1bfb20731bd5; mark archive restored2025/h2/archive057.zip SHA256 8fee745a3a7a3a42b6eb5884398630dad891505fd7d3f785fb1237d428f4e941. Receipt retains 36 paired trade/mark neighborhood rows, covering 21:05–21:35 and 22:18–22:22 UTC.

At the entry minute, raw mark OHLC is O={entry_mark_row[1]}, H={entry_mark_row[2]}, L={entry_mark_row[3]}, C={entry_mark_row[4]}. Mark OPEN is {doge_notes['entry_minute_mark_open_vs_trade_open_bp']:.8f}bp below trade OPEN, opposite to the earlier positive feature sign. Trade entry OPEN has fallen {doge_notes['trade_entry_open_vs_feature_trade_close_bp']:.8f}bp from the feature trade CLOSE. Thus the fixed historical feature direction survives a roughly 40% pre-entry drop; the reported gain is a rebound price proxy, not demonstrated convergence of a positive entry mark/trade gap. Minute OPENs do not certify synchronous observed quotes.

The neighborhood supports an extreme-valued cached crash/rebound rather than a field/time/schema swap. Raw OHLCV cannot certify executable liquidity or eliminate original-source artifacts. No event excluded; no alternative performance recipe evaluated.

## Boundaries

Local source arithmetic only: no network/provider downloads, no non-2025 raw members, no financial simulation/account, no author-output edits, no Library/GitHub mutations or deletes. One CPU and one thread. Full raw receipt SHA256: {sha(body)}.
'''
(OUT / 'RAW_CHECK_REPORT.md').write_text(summary)
assert sum(p.stat().st_size for p in OUT.rglob('*') if p.is_file()) <= 1_000_000
print(json.dumps({'status': receipt['status'], 'events': len(events), 'price_archives': len(archive_receipts), 'price_rows': 184, 'funding_rows': receipt['funding_raw_rows_verified'], 'receipt_bytes': len(body), 'receipt_sha256': sha(body), 'elapsed_seconds': receipt['elapsed_seconds'], 'doge': {k: v for k, v in doge_notes.items() if k != 'neighborhood'}}, indent=2))
