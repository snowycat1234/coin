# Independent raw event source check

PASS: all 46 selected events match the exact pinned cached 2025 raw archives and canonical month arrays. No source mismatch was found.

- Protocol SHA256: deeda6e5aa8914513f7b96157e15213cad5c688a5b683482b43bbe3aaec15cce
- EVENTS.csv SHA256: 9a8a96b267ccbaa3a6dbb6fffa01b048dc392b8694cc28beb52034f4fc371ccf
- SOURCE_INDEX.json SHA256: 8a0235e428902f7a0ea4ec1893343abae6ccc23715080771796b54fb58f1f3c4
- 60 price archives: exact SHA256/bytes, official checksum text, inner CSV CRC; all rows checked for header, complete ordered one-minute grid, original inclusive close=open+59999ms, positive OHLC envelope and applicable trade-volume invariants.
- 184 selected raw price rows: 46 trade feature closes, 46 mark feature closes, 46 trade entry opens, 46 trade exit opens. Exact float equality to EVENTS.csv and pinned canonical arrays. Original field strings and CSV line numbers retained in RAW_ROW_RECEIPT.json.
- Zero-based raw offsets: open_time=0, OPEN=1, HIGH=2, LOW=3, CLOSE=4, volume=5, inclusive close_time=6, quote volume=7, count=8, taker base=9, taker quote=10, ignore=11. Headers verified for each archive.
- All feature completion/availability/readiness, next eligible entry clocks and exact 60-minute exits independently checked; signal and open-to-open proxy arithmetic matches.
- Seven selected funding event clocks/rates verified against seven exact cached raw funding members. ETH May 9 clock is 1746777600006000 microseconds, preserving the original +6ms source offset. No funding unit conversion performed.

## DOGE October 10 extreme

Feature 2025-10-10 21:15 UTC: raw trade CLOSE 0.188940; raw mark CLOSE 0.19138594. Entry 21:20 raw trade OPEN 0.113550; exit 22:20 raw trade OPEN 0.182660. These reproduce +6086.30559225011bp exactly.

The entry raw bar is O=0.113550, H=0.113750, L=0.083850, C=0.088560, base volume=266531353, quote volume=25419571.878020, trade count=35527. Its VWAP is 0.0953717886917, inside its OHLC bounds. The previous minute CLOSE is 0.112570; entry OPEN change is 87.05694235bp. The month low is 0.08385 at 2025-10-10T21:20:00+00:00.

Trade archive restored2025/h2/archive051.zip SHA256 c2e2ef77ee80bd0d0fef438a5f24dc2f4765de6e3ef0ab36797d1bfb20731bd5; mark archive restored2025/h2/archive057.zip SHA256 8fee745a3a7a3a42b6eb5884398630dad891505fd7d3f785fb1237d428f4e941. Receipt retains 36 paired trade/mark neighborhood rows, covering 21:05–21:35 and 22:18–22:22 UTC.

At the entry minute, raw mark OHLC is O=0.11171000, H=0.11296864, L=0.08867096, C=0.09213206. Mark OPEN is -162.04315280bp below trade OPEN, opposite to the earlier positive feature sign. Trade entry OPEN has fallen -3990.15560495bp from the feature trade CLOSE. Thus the fixed historical feature direction survives a roughly 40% pre-entry drop; the reported gain is a rebound price proxy, not demonstrated convergence of a positive entry mark/trade gap. Minute OPENs do not certify synchronous observed quotes.

The neighborhood supports an extreme-valued cached crash/rebound rather than a field/time/schema swap. Raw OHLCV cannot certify executable liquidity or eliminate original-source artifacts. No event excluded; no alternative performance recipe evaluated.

## Boundaries

Local source arithmetic only: no network/provider downloads, no non-2025 raw members, no financial simulation/account, no author-output edits, no Library/GitHub mutations or deletes. One CPU and one thread. Full raw receipt SHA256: 6024c15e386cf27c6c74abe342672894d60726b31f832162c1b9a5da14a22fca.
