"""Independent verification of existing saved outputs; never invokes screen.py.

Reads only fixed screen artifacts and their bound local 2025 canonical sources.
Writes only new REVIEW files in this directory, using exclusive creation.
"""
from pathlib import Path
from decimal import Decimal, ROUND_FLOOR, getcontext
import ast
import csv
import datetime
import hashlib
import json
import os
import statistics
import time

os.sched_setaffinity(0, {min(os.sched_getaffinity(0))})
os.environ['OPENBLAS_NUM_THREADS'] = '1'
os.environ['OMP_NUM_THREADS'] = '1'
os.environ['MKL_NUM_THREADS'] = '1'
import numpy as np

getcontext().prec = 50
D = Decimal
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
INPUT = ROOT / 'mark_trade_minute_event2025'
SOURCE = ROOT / 'restored2025/prepared_2025'
MINUTE = 60_000_000
STEPS = dict(BTCUSDT=D('.001'), ETHUSDT=D('.01'), SOLUSDT=D('1'),
             XRPUSDT=D('100'), DOGEUSDT=D('1000'))
checks = {}
failures = []
start = time.monotonic()


def check(category, name, ok):
    checks[category] = checks.get(category, 0) + 1
    if not ok:
        failures.append(dict(category=category, check=name))


def same(category, name, actual, expected):
    check(category, name, actual == expected)


def number(category, name, actual, expected):
    if actual is None:
        same(category, name, actual, expected)
    else:
        same(category, name, D(actual), expected)


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for data in iter(lambda: f.read(1024 * 1024), b''):
            h.update(data)
    return h.hexdigest()


def read(path):
    return json.loads(path.read_text())


def floor(value, step):
    return (value / step).to_integral_value(rounding=ROUND_FLOOR) * step


def stat(values):
    return dict(n=len(values), mean=None if not values else str(sum(values, D(0)) / len(values)),
                median=None if not values else str(statistics.median(values)),
                minimum=None if not values else str(min(values)),
                maximum=None if not values else str(max(values)),
                positive_count=sum(x > 0 for x in values))


def summary(rows):
    closed = [r for r in rows if r['full_paid_close_of_entry_proxy_feasible']]
    return dict(n=len(rows),
        full_requested_entry_count=sum(r['full_coarse_request_entry_proxy_feasible'] for r in rows),
        partial_entry_count=sum(r['entry_size_status'] == 'PARTIAL_ENTRY' for r in rows),
        no_entry_count=sum(r['status'] == 'NO_ENTRY' for r in rows),
        fully_closed_entry_count=len(closed),
        unpriced_residual_count=sum(r['status'] == 'OPEN_UNPRICED_RESIDUAL' for r in rows),
        full_desired_coarse_roundtrip_count=sum(r['full_desired_coarse_roundtrip_proxy_feasible'] for r in rows),
        counterfactual_full_coarse_aftercost_bp=stat([D(r['counterfactual_full_coarse_after_cost_bp']) for r in rows if r['counterfactual_full_coarse_after_cost_bp'] is not None]),
        counterfactual_exact_cost_bp=stat([D(r['counterfactual_full_coarse_exact_cost_bp']) for r in rows if r['counterfactual_full_coarse_exact_cost_bp'] is not None]),
        conditional_completed_aftercost_bp=stat([D(r['completed_roundtrip_after_cost_bp_on_entry_observed_notional']) for r in closed]),
        diagnostic_paid_entry_fees_USDT=str(sum((D(r['actual_paid_entry_fee_USDT']) for r in rows), D(0))),
        diagnostic_paid_exit_fees_USDT=str(sum((D(r['actual_paid_exit_fee_USDT']) for r in rows), D(0))),
        diagnostic_unfilled_desired_observed_entry_notional_USDT=str(sum((D(r['unused_desired_observed_entry_notional_USDT']) for r in rows), D(0))))


protocol = read(HERE / 'PROTOCOL.json')
amendment = read(HERE / 'PRE_SCAN_AMENDMENT.json')
freeze = read(HERE / 'FREEZE_RECEIPT.json')
afreeze = read(HERE / 'AMENDMENT_FREEZE_RECEIPT.json')
pins = read(HERE / 'PRE_SCAN_PINS.json')
result = read(HERE / 'RESULT.json')
rows = read(HERE / 'EVENT_CAPACITY_ROWS.json')
receipt = read(HERE / 'SOURCE_READ_RECEIPT.json')
overlap = read(HERE / 'OVERLAP_REFERENCE_CAPITAL.json')
synthetic = read(HERE / 'SYNTHETIC_TESTS.json')
original = read(INPUT / 'PROTOCOL.json')
locators = read(INPUT / 'EVENT_SOURCE_LOCATORS.json')
events = list(csv.DictReader((INPUT / 'EVENTS.csv').open()))
fund = read(SOURCE / 'EVENTS.json')
index = read(SOURCE / 'SOURCE_INDEX.json')

same('bindings', 'protocol freeze', sha(HERE / 'PROTOCOL.json'), freeze['protocol_SHA256'])
same('bindings', 'amendment protocol freeze', sha(HERE / 'PROTOCOL.json'), afreeze['protocol_SHA256'])
same('bindings', 'amendment freeze', sha(HERE / 'PRE_SCAN_AMENDMENT.json'), afreeze['amendment_SHA256'])
for key in ('screen_protocol_SHA256', 'amendment_SHA256'):
    expected = sha(HERE / ('PROTOCOL.json' if key == 'screen_protocol_SHA256' else 'PRE_SCAN_AMENDMENT.json'))
    same('bindings', 'result ' + key, result[key], expected)
    same('bindings', 'pins ' + key, pins[key], expected)
same('bindings', 'saved result/stdout byte identity', sha(HERE / 'RESULT.json'), sha(HERE / 'scan_stdout.json'))
same('bindings', 'synthetic receipt hash', sha(HERE / 'SYNTHETIC_TESTS.json'), pins['synthetic_SHA256'])
for rel, expected in protocol['input_bindings'].items():
    same('bindings', rel, sha(ROOT / rel), expected)
same('bindings', 'result fixed csv', result['events_input_SHA256'], sha(INPUT / 'EVENTS.csv'))
same('bindings', 'locator fixed csv', locators['EVENTS_csv_SHA256'], sha(INPUT / 'EVENTS.csv'))
same('bindings', 'source index', sha(SOURCE / 'SOURCE_INDEX.json'), original['inputs']['source_index_SHA256'])
for pin in pins['pins']:
    p = ROOT / pin['file']
    same('bindings', pin['file'] + ' sha256', sha(p), pin['SHA256'])
    same('bindings', pin['file'] + ' bytes', p.stat().st_size, pin['bytes'])
monthly = {m['month']: m for m in original['inputs']['canonical_months']}
for month, meta in monthly.items():
    p = SOURCE / 'months' / (month + '.npz')
    same('bindings', month + ' original hash', sha(p), meta['source_NPZ_SHA256'])
    same('bindings', month + ' original bytes', p.stat().st_size, meta['source_NPZ_bytes'])
same('bindings', 'funding original hash', sha(SOURCE / 'EVENTS.json'), original['inputs']['funding']['SHA256'])
same('bindings', 'funding original bytes', (SOURCE / 'EVENTS.json').stat().st_size, original['inputs']['funding']['bytes'])
same('identity', 'all46 lengths', (len(rows), len(events), len(locators['events'])), (46, 46, 46))
same('identity', 'symbol order', index['symbol_order'], list(STEPS))
same('funding', 'source count', len(fund), 5475)
for symbol in STEPS:
    f = [x for x in fund if x['symbol'] == symbol]
    same('funding', symbol + ' count', len(f), 1095)
    check('funding', symbol + ' ordered exact timestamps', all(type(x['event_us']) is int and x['event_us'] < y['event_us'] for x, y in zip(f, f[1:])))
for x in fund:
    check('funding', '2025 finite raw schema', type(x['event_us']) is int and index['calendar'][0] <= x['event_us'] < index['calendar'][1] and x['symbol'] in STEPS and D(str(x['raw_rate'])).is_finite())

# Refuse to interpret the original full arrays as a new event scan. Decode only
# bound columns needed to corroborate the saved exact event prices/safe volumes.
arrays = {}
expected_receipt = []
source_points = 0


def source_value(locator, symbol, field, clock=None):
    global source_points
    p = ROOT / locator['source_file']
    month = p.stem
    check('source', 'canonical2025 locator path', month in monthly and p.resolve() == (SOURCE / 'months' / (month + '.npz')).resolve())
    same('source', 'locator month binding', locator['source_SHA256'], monthly[month]['source_NPZ_SHA256'])
    same('source', 'locator array', locator['array'], symbol + '_' + field)
    if month not in arrays:
        z = np.load(p, allow_pickle=False)
        t = z['times']
        arrays[month] = (z, t, {})
        same('source', month + ' int64 time dtype', t.dtype, np.dtype('int64'))
        same('source', month + ' minute length', len(t), monthly[month]['minutes'])
        check('source', month + ' complete exact time grid', bool(np.all(np.diff(t) == MINUTE)))
        dt = datetime.datetime.fromisoformat(month + '-01T00:00:00+00:00')
        same('source', month + ' first timestamp', int(t[0]), int(dt.timestamp()) * 1_000_000)
    z, t, columns = arrays[month]
    i = locator['row_0_based']
    check('source', 'integer inbounds row', type(i) is int and 0 <= i < len(t))
    u = int(t[i])
    same('source', 'raw row time', u, locator['bar_open_us'])
    same('source', 'completion time', u + MINUTE, locator['bar_completion_us'])
    same('source', 'availability time', u + MINUTE + 1, locator['availability_proxy_us'])
    if clock is not None:
        same('causal_capacity', 'safe row u-2min', u, clock - 2 * MINUTE)
        check('causal_capacity', 'safe availability <=exactOPEN', u + MINUTE + 1 <= clock)
        same('causal_capacity', 'adjacent prior actual grid availability OPEN+1us', int(t[i + 1]) + MINUTE + 1, clock + 1)
        check('causal_capacity', 'adjacent prior rejected at OPEN', int(t[i + 1]) + MINUTE + 1 > clock)
    if locator['array'] not in columns:
        columns[locator['array']] = z[locator['array']]
    raw = columns[locator['array']][i]
    source_points += 1
    expected_receipt.append(dict(source_file=locator['source_file'], array=locator['array'], row_0_based=i,
        bar_open_us=u, availability_proxy_us=u + MINUTE + 1,
        screen_information_clock_us=clock, used_as_capacity=clock is not None))
    return D(str(raw))


residual_details = []
rounding_tolerance_max = D(0)
membership_changes = []
for n, (r, e, loc) in enumerate(zip(rows, events, locators['events']), 1):
    eid = f'E{n:03}'
    symbol, direction = e['symbol'], int(e['direction'])
    en, ex, feature = int(e['entry_us']), int(e['exit_us']), int(e['feature_open_us'])
    same('identity', eid + ' order/id', (r['event_id'], loc['event_id']), (eid, eid))
    same('identity', eid + ' symbol', (r['symbol'], loc['symbol']), (symbol, symbol))
    same('identity', eid + ' direction', r['direction'], direction)
    check('identity', eid + ' direction sign retained', direction in (-1, 1) and direction == (1 if D(e['signal_bp']) > 0 else -1))
    same('identity', eid + ' original signal', r['original_signal_bp'], e['signal_bp'])
    for k, val in [('feature_open_us', feature), ('entry_us', en), ('exit_us', ex)]:
        same('identity', eid + ' ' + k, (r[k], loc[k]), (val, val))
    for side in ('entry', 'exit'):
        same('identity', eid + side + ' utc original', r[side + '_utc'], e[side + '_utc'])
        actual_us = int(datetime.datetime.fromisoformat(r[side + '_utc']).timestamp()) * 1_000_000
        same('identity', eid + side + ' utc clock', actual_us, r[side + '_us'])
    same('identity', eid + ' selected', e['status'], 'SELECTED')
    same('identity', eid + ' completion', int(e['feature_completion_us']), feature + MINUTE)
    same('identity', eid + ' availability', int(e['feature_available_us']), feature + MINUTE + 1)
    same('identity', eid + ' ready', int(e['order_ready_us']), feature + 4 * MINUTE + 1)
    same('identity', eid + ' exact 5minute entry', en, feature + 5 * MINUTE)
    same('identity', eid + ' exact60minute exit', ex - en, 60 * MINUTE)
    p0 = source_value(loc['entry_trade_OPEN'], symbol, 'open')
    p1 = source_value(loc['exit_trade_OPEN'], symbol, 'open')
    same('source', eid + ' entry exactOPEN', loc['entry_trade_OPEN']['bar_open_us'], en)
    same('source', eid + ' exit exactOPEN', loc['exit_trade_OPEN']['bar_open_us'], ex)
    same('source', eid + ' original prices', (p0, p1), (D(e['entry_trade_open']), D(e['exit_trade_open'])))
    number('source', eid + ' saved entry price', r['entry_observed_OPEN'], p0)
    number('source', eid + ' saved exit price', r['exit_observed_OPEN'], p1)
    volumes = []
    for side, clock in [('entry', en), ('exit', ex)]:
        safe = loc[side + '_latest_bar_quote_volume_available_at_exact_OPEN_under_plus1us']
        v = source_value(safe, symbol, 'quote_volume', clock)
        available = v.is_finite() and v >= 0
        volumes.append(v if available else D(0))
        same('source', eid + side + ' saved safe locator', r[side + '_safe_volume_source'], safe)
        same('causal_capacity', eid + side + ' available mask', r[side + '_volume_available_mask'], available)
        expected_reason = 'NONFINITE_OR_NEGATIVE_SAFE_VOLUME_MASKED_ZERO' if not available else 'AVAILABLE_ZERO_VOLUME' if v == 0 else 'AVAILABLE'
        same('causal_capacity', eid + side + ' volume reason', r[side + '_volume_mask_reason'], expected_reason)
        if available:
            number('source', eid + side + ' volume value', r[side + '_safe_volume'], v)
        else:
            same('source', eid + side + ' unavailable volume', r[side + '_safe_volume'], None)
        adjacent = loc[side + '_immediately_prior_bar_quote_volume']
        same('causal_capacity', eid + side + ' adjacent prior declared open', adjacent['bar_open_us'], clock - MINUTE)
        same('causal_capacity', eid + side + ' adjacent prior declared available', adjacent['availability_proxy_us'], clock + 1)
        same('causal_capacity', eid + side + ' adjacent next index', adjacent['row_0_based'], safe['row_0_based'] + 1)
        same('causal_capacity', eid + side + ' adjacent same source/array/hash', (adjacent['source_file'], adjacent['array'], adjacent['source_SHA256']), (safe['source_file'], safe['array'], safe['source_SHA256']))
    v0, v1 = volumes
    step = STEPS[symbol]
    desired = D(1200) / p0
    request = floor(desired, step)
    cap0, cap1 = v0 * D('.001') / p0, v1 * D('.001') / p1
    before = floor(min(request, cap0), step)
    fill0 = p0 * (1 + direction * D('.0008'))
    fill1 = p1 * (1 - direction * D('.0008'))
    qe = before if before * fill0 >= 10 else D(0)
    qx = floor(min(qe, cap1), step)
    residual = qe - qx
    complete = qe > 0 and qx == qe
    fullrequest = qe == request and qe > 0
    scalar = dict(coarse_step=step, desired_quantity=desired, coarse_requested_quantity=request,
        coarse_entry_observed_notional_USDT=request * p0,
        coarse_rounding_unused_desired_USDT=D(1200) - request * p0,
        entry_capacity_observed_quote_notional_USDT=v0 * D('.001'),
        exit_capacity_observed_quote_notional_USDT=v1 * D('.001'),
        entry_capacity_quantity=cap0, exit_capacity_quantity=cap1,
        entry_capacity_coarse_quantity=floor(cap0, step), exit_capacity_coarse_quantity=floor(cap1, step),
        entry_quantity_before_opening_minimum=before, entry_feasible_quantity=qe, exit_feasible_quantity=qx,
        open_unpriced_residual_quantity=residual, entry_feasible_observed_notional_USDT=qe * p0,
        unused_desired_observed_entry_notional_USDT=D(1200) - qe * p0,
        entry_unused_capacity_observed_quote_notional_USDT=v0 * D('.001') - qe * p0,
        exit_unused_capacity_observed_quote_notional_USDT=v1 * D('.001') - qx * p1)
    for k, val in scalar.items():
        number('decimal_quantity', eid + ' ' + k, r[k], val)
    check('decimal_quantity', eid + ' nonnegative ordered quantities', 0 <= qx <= qe <= request <= desired)
    check('decimal_quantity', eid + ' coarse multiples', all(x == floor(x, step) for x in [request, before, qe, qx]))
    check('decimal_quantity', eid + ' independent side capacities', qe * p0 <= v0 * D('.001') and qx * p1 <= v1 * D('.001'))
    check('decimal_quantity', eid + ' actual entry minimum', qe == 0 or qe * fill0 >= 10)
    status = 'NO_ENTRY' if qe == 0 else 'OPEN_UNPRICED_RESIDUAL' if residual else 'FULL_PAID_CLOSE_PROXY'
    size_status = 'NO_ENTRY' if qe == 0 else 'FULL_COARSE_REQUEST' if fullrequest else 'PARTIAL_ENTRY'
    for k, val in dict(status=status, entry_size_status=size_status,
        entry_minimum_pass=before > 0 and before * fill0 >= 10,
        full_coarse_request_entry_proxy_feasible=fullrequest,
        full_paid_close_of_entry_proxy_feasible=complete,
        full_desired_coarse_roundtrip_proxy_feasible=fullrequest and complete).items():
        same('classification', eid + ' ' + k, r[k], val)
    entry_fee = qe * fill0 * D('.00055')
    exit_fee = qx * fill1 * D('.00055')
    gross = D(direction) * qx * (fill1 - fill0)
    fullgross = D(direction) * request * (fill1 - fill0)
    fullef, fullxf = request * fill0 * D('.00055'), request * fill1 * D('.00055')
    fullafter = fullgross - fullef - fullxf
    mid = D(direction) * request * (p1 - p0)
    costs = dict(entry_adverse_fill_price=fill0, exit_adverse_fill_price=fill1,
        actual_entry_fill_notional_USDT=qe * fill0, actual_exit_fill_notional_USDT=qx * fill1,
        actual_paid_entry_fee_USDT=entry_fee, actual_paid_exit_fee_USDT=exit_fee,
        closed_piece_gross_adverse_fill_PnL_USDT=gross,
        closed_piece_realized_less_all_paid_fees_USDT=gross - entry_fee - exit_fee,
        residual_entry_fill_basis_USDT=residual * fill0,
        residual_allocated_paid_entry_fee_USDT=residual * fill0 * D('.00055'),
        completed_roundtrip_after_cost_USDT=gross - entry_fee - exit_fee if complete else None,
        completed_roundtrip_after_cost_bp_on_entry_observed_notional=(gross - entry_fee - exit_fee) / (qe * p0) * 10000 if complete else None,
        counterfactual_full_coarse_mid_gross_USDT=mid,
        counterfactual_full_coarse_execution_price_cost_USDT=request * (p0 + p1) * D('.0008'),
        counterfactual_full_coarse_entry_fee_USDT=fullef,
        counterfactual_full_coarse_exit_fee_USDT=fullxf,
        counterfactual_full_coarse_after_cost_USDT=fullafter,
        counterfactual_full_coarse_after_cost_bp=fullafter / (request * p0) * 10000 if request else None,
        counterfactual_full_coarse_exact_cost_bp=(mid - fullafter) / (request * p0) * 10000 if request else None)
    for k, val in costs.items():
        number('decimal_costs', eid + ' ' + k, r[k], val)
    check('decimal_costs', eid + ' side adverse directions', direction * (fill0 - p0) > 0 and direction * (fill1 - p1) < 0)
    same('decimal_costs', eid + ' exact slippage identity', mid - fullgross, request * (p0 + p1) * D('.0008'))
    same('decimal_costs', eid + ' no extra fixed27bp', D(r['counterfactual_full_coarse_after_cost_USDT']), mid - request * (p0 + p1) * D('.0008') - fullef - fullxf)
    if residual:
        residual_details.append(dict(event_id=eid, symbol=symbol, entry_quantity=str(qe), closed_quantity=str(qx), residual_quantity=str(residual), residual_entry_basis_USDT=str(residual * fill0), residual_paid_entry_fee_USDT=str(residual * fill0 * D('.00055'))))
        same('classification', eid + ' residual null completed PnL', r['completed_roundtrip_after_cost_USDT'], None)
        check('classification', eid + ' no residual exit marking field', not any('mark' in k.lower() and 'residual' in k.lower() for k in r))
    fs = [x for x in fund if x['symbol'] == symbol]
    old_owned = [x for x in fs if en <= x['event_us'] < ex]
    native_owned = [x for x in fs if en < x['event_us'] <= ex]
    old_times = [x['event_us'] for x in old_owned]
    native_times = [x['event_us'] for x in native_owned]
    csv_times = [] if not e['raw_funding_event_us'] else list(map(int, e['raw_funding_event_us'].split(';')))
    same('funding', eid + ' original CSV clocks', csv_times, old_times)
    same('funding', eid + ' original saved clocks', r['original_attribution_funding_event_us'], old_times)
    same('funding', eid + ' native saved clocks', r['native_owned_funding_event_us'], native_times)
    same('funding', eid + ' original count', int(e['raw_funding_events']), len(old_owned))
    same('funding', eid + ' native count', r['native_funding_event_count'], len(native_owned))
    old_sum = sum((D(str(x['raw_rate'])) for x in old_owned), D(0))
    native_sum = sum((D(str(x['raw_rate'])) for x in native_owned), D(0))
    for csv_key, expected in [('raw_rate_sum', old_sum), ('signed_raw_rate_coefficient', -D(direction) * old_sum)]:
        difference = abs(D(e[csv_key]) - expected)
        rounding_tolerance_max = max(rounding_tolerance_max, difference)
        check('funding', eid + csv_key + ' original CSV float-format tolerance<1e-15', difference < D('1e-15'))
    number('funding', eid + ' original raw coefficient', r['original_signed_raw_rate_coefficient'], -D(direction) * old_sum)
    number('funding', eid + ' native raw coefficient', r['native_signed_raw_rate_coefficient'], -D(direction) * native_sum)
    number('funding', eid + ' native raw sum', r['native_raw_rate_sum'], native_sum)
    same('funding', eid + ' native literal rates', r['native_raw_rates'], [str(x['raw_rate']) for x in native_owned])
    same('funding', eid + ' membership difference flag', r['funding_membership_changed'], old_times != native_times)
    if old_times != native_times:
        membership_changes.append(dict(event_id=eid, removed=sorted(set(old_times) - set(native_times)), added=sorted(set(native_times) - set(old_times))))
    for k, val in dict(actual_funding_cashflow_USDT=None, funding_units_certified=False, real_execution_certified=False, conditional_proxy_only=True).items():
        same('classification', eid + ' ' + k, r[k], val)

for z, _, _ in arrays.values():
    z.close()
same('source_receipts', 'exact saved lookup list/order', receipt['rows'], expected_receipt)
same('source_receipts', 'lookup count', receipt['array_value_lookups'], source_points)
same('source_receipts', 'all46 four points each', source_points, 184)
same('source_receipts', 'future capacity lookup count', receipt['future_volume_values_used'], 0)
same('source_receipts', 'safe capacity lookups', sum(x['used_as_capacity'] for x in expected_receipt), 92)

# Independently reconstruct every serialized CSV field from verified JSON.
csvrows = list(csv.DictReader((HERE / 'EVENT_CAPACITY_ROWS.csv').open()))
same('csv_consistency', 'row count', len(csvrows), 46)
for r, cr in zip(rows, csvrows):
    same('csv_consistency', r['event_id'] + ' field set', set(cr), set(r))
    for k, value in r.items():
        expected = json.dumps(value, sort_keys=True, separators=(',', ':')) if isinstance(value, (dict, list)) else '' if value is None else str(value)
        same('csv_consistency', r['event_id'] + ' ' + k, cr[k], expected)

# Independent interval sweep: remove exits first, then add entries at each time.
all_clocks = sorted({r['entry_us'] for r in rows} | {r['exit_us'] for r in rows})
active = set()
segments = []
for n, clock in enumerate(all_clocks):
    active.difference_update(r['event_id'] for r in rows if r['exit_us'] == clock)
    active.update(r['event_id'] for r in rows if r['entry_us'] == clock)
    cohort = [r for r in rows if r['event_id'] in active]
    for r in rows:
        if r['entry_us'] == clock:
            same('overlap', r['event_id'] + ' at-entry count', r['fixed_interval_overlap_at_entry_count'], len(active))
            number('overlap', r['event_id'] + ' at-entry desired', r['fixed_interval_desired_reference_at_entry_USDT'], D(1200) * len(active))
    if active and n + 1 < len(all_clocks):
        end = all_clocks[n + 1]
        seg = dict(start_us=clock, end_us=end, duration_us=end-clock, count=len(active), event_ids=[r['event_id'] for r in cohort],
            desired_reference_notional_USDT=str(D(1200) * len(active)),
            desired_reference_wallet_fraction=str(D(1200) * len(active) / D(10000)),
            coarse_observed_entry_notional_USDT=str(sum((D(r['coarse_entry_observed_notional_USDT']) for r in cohort), D(0))),
            entry_feasible_observed_entry_notional_USDT=str(sum((D(r['entry_feasible_observed_notional_USDT']) for r in cohort), D(0))))
        segments.append(seg)
same('overlap', 'every segment/footprint/time', overlap['segments'], segments)
durations = {str(n):sum(s['duration_us'] for s in segments if s['count'] == n) for n in range(1, 6)}
same('overlap', 'duration histogram', overlap['fixed_interval_microseconds_by_concurrency'], durations)
same('overlap', 'max concurrency', overlap['max_fixed_interval_concurrency'], max(s['count'] for s in segments))
same('overlap', 'reference exceeds wallet segments', overlap['segments_exceeding_reference_wallet'], sum(D(s['desired_reference_notional_USDT']) > D(10000) for s in segments))
same('overlap', 'result summary equal saved overlap', result['overlap'], {k:v for k, v in overlap.items() if k != 'segments'})
same('overlap', 'total interval quantity conservation', sum(int(k) * v for k, v in durations.items()), 46 * 60 * MINUTE)
same('overlap', 'all intervals closed in sweep', len(active), 0)

same('summary', 'overall every field', result['overall'], summary(rows))
for symbol in STEPS:
    same('summary', symbol + ' every field', result['per_asset'][symbol], summary([r for r in rows if r['symbol'] == symbol]))
for month in monthly:
    same('summary', month + ' every field', result['per_month'][month], summary([r for r in rows if r['entry_utc'].startswith(month)]))
same('summary', 'all12 months', set(result['per_month']), set(monthly))
same('summary', 'residual list', result['residual_event_ids'], [r['event_id'] for r in rows if r['status'] == 'OPEN_UNPRICED_RESIDUAL'])
same('funding', 'result membership changes', result['funding']['membership_change_event_ids'], [x['event_id'] for x in membership_changes])
same('funding', 'result nonempty native events', result['funding']['events_with_native_owned_funding'], sum(bool(r['native_funding_event_count']) for r in rows))
same('funding', 'result native occurrence total', result['funding']['native_owned_funding_occurrences'], sum(r['native_funding_event_count'] for r in rows))
for boundary in ('native', 'original'):
    number('funding', 'result ' + boundary + ' coefficient sum', result['funding'][boundary + '_signed_raw_rate_coefficient_sum'], sum((D(r[boundary + '_signed_raw_rate_coefficient']) for r in rows), D(0)))
expected_masks = dict(entry_available=46, exit_available=46, entry_zero_volumes=0, exit_zero_volumes=0, future_adjacent_prior_volume_values_used=0, safe_volume_rows_used=92)
same('summary', 'actual saved masks', result['capacity_masks'], expected_masks)
same('summary', 'all46 preserved flags', (result['all46_preserved'], result['fixed_clocks_directions_preserved']), (True, True))

# Independent arithmetic edge cases corroborate the dormant policy branches.
for symbol, step in STEPS.items():
    same('edge_cases', symbol + ' coarse floor', floor(step * D('5.999999'), step), step * 5)
for direction in (-1, 1):
    a = D(100) * (1 + D(direction) * D('.0008'))
    b = D(100) * (1 - D(direction) * D('.0008'))
    same('edge_cases', 'flat price gross ' + str(direction), D(direction) * 2 * (b-a), D('-.32'))
    same('edge_cases', 'flat price total actual-notional fees ' + str(direction), 2 * (a+b) * D('.00055'), D('.22'))
    same('edge_cases', 'flat price after cost ' + str(direction), D(direction) * 2 * (b-a) - 2*a*D('.00055') - 2*b*D('.00055'), D('-.54'))
    for rate in (D('.001'), D('-.001')):
        cashflow = -D(direction) * 2 * D(100) * rate
        same('edge_cases', 'synthetic funding direction/rate ' + str((direction, rate)), cashflow > 0, direction * rate < 0)
same('edge_cases', 'native boundary entry excludes exit owns', [t for t in (99,100,150,200,201) if 100 < t <= 200], [150,200])
same('edge_cases', 'original boundary entry owns exit excludes', [t for t in (99,100,150,200,201) if 100 <= t < 200], [100,150])
same('edge_cases', 'native funding before fill tie inventory', ((0, 'entry funding before fill'), (2, 'exit funding before close')), ((0, 'entry funding before fill'), (2, 'exit funding before close')))
check('edge_cases', 'opening10 actual adverse amount', D('9.999') * D('1.0008') >= 10 and D('9.999') * D('.9992') < 10)
check('edge_cases', 'opening below10 rejected', D(9) * D('1.0008') < 10)
check('edge_cases', 'closing below10 allowed', floor(min(D(20), D(1)), D(1)) == 1 and 1 * D(2) < 10)
same('edge_cases', 'partial residual not cleared', D(20) - floor(min(D(20), D(1)), D(1)), D(19))
u = 10 * MINUTE
times = [u - 3*MINUTE, u - 2*MINUTE, u - MINUTE, u]
eligible = [i for i,t in enumerate(times) if t + MINUTE + 1 <= u]
same('edge_cases', 'exactOPEN causal latest index', eligible[-1], 1)
v = [D(20), D(30), D('1e9'), D('1e9')]
capacity = v[eligible[-1]] * D('.001')
v[2:] = [D('1e40'), D('1e50')]
same('edge_cases', 'future-volume mutation cannot change safe capacity', v[eligible[-1]] * D('.001'), capacity)
same('edge_cases', 'adjacent becomes eligible only plus1us', [i for i,t in enumerate(times) if t + MINUTE + 1 <= u+1][-1], 2)
same('edge_cases', 'overlap ties exit before entry', max(sum(a <= t < b for a,b in [(0,10), (10,20)]) for t in [0,10,20]), 1)
same('edge_cases', 'bad binding differs and must reject', hashlib.sha256(b'good').digest() != hashlib.sha256(b'bad').digest(), True)

same('implementation', 'saved synthetic pass', synthetic['status'], 'PASS')
same('implementation', 'saved synthetic count/name unique', synthetic['tests'], len(set(synthetic['test_names'])))
same('implementation', 'saved synthetic pre-array', (synthetic['actual_market_arrays_decoded'], synthetic['actual_scan_run']), (0, False))
same('implementation', 'both freeze zero counts', (freeze['actual_market_arrays_decoded'], freeze['capacity_calculations_performed'], afreeze['actual_market_arrays_decoded'], afreeze['capacity_calculations_performed']), (0,0,0,0))
check('implementation', 'freeze precedes amendment precedes saved synthetic', datetime.datetime.fromisoformat(freeze['frozen_utc']) <= datetime.datetime.fromisoformat(afreeze['frozen_utc']) <= datetime.datetime.fromisoformat(synthetic['test_utc']))
tree = ast.parse((HERE / 'screen.py').read_text())
imports = set()
for node in ast.walk(tree):
    if isinstance(node, ast.Import):
        imports.update(alias.name.split('.')[0] for alias in node.names)
    if isinstance(node, ast.ImportFrom):
        imports.add(node.module.split('.')[0])
same('implementation', 'bounded stdlib/numpy imports', imports, {'__future__','csv','datetime','decimal','hashlib','json','os','pathlib','resource','statistics','sys','time','numpy'})
same('implementation', 'recorded one CPU/one thread', (len(result['resources']['CPU_affinity']), result['resources']['threads']), (1,1))
same('implementation', 'recorded decoded month count', result['resources']['actual_2025_month_arrays_decoded'], len(arrays))
for k in ('financial_account_constructors', 'financial_advances', 'provider_downloads', 'source2026_reads', 'Library_writes', 'GitHub_writes', 'deletes'):
    same('implementation', 'recorded zero ' + k, result['resources'][k], 0)
same('implementation', 'review current one CPU', len(os.sched_getaffinity(0)), 1)
check('implementation', 'directory before review<2MB', sum(p.stat().st_size for p in HERE.iterdir() if p.is_file()) < 2_000_000)

limitations = [
    'This is a saved-output and bound-source-point verification, not a rerun of screen.main, a signal scan, or a new backtest.',
    'Freeze receipts and resource counters are self-reported artifacts; hash consistency and timestamp ordering do not independently prove historical execution chronology or system-call absence.',
    'screen.py was not hash-bound in the freeze receipts; this review records its current hash. Saved arithmetic/source matches cannot prove that this exact file produced the saved outputs.',
    'All 92 safe quote-volume points are causally available only under the declared completion+1us proxy. Source OPEN prices remain future outcome proxies, not certified executable quotes.',
    'The opening minimum is tested on actual adverse fill notional. Coarse steps and 0.1% historical quote-volume participation are research conventions, not native venue filters or order-book depth.',
    'Native funding ownership entry<clock<=exit and original CSV entry<=clock<exit agree on these 46 events only because none has a boundary funding occurrence; independent boundary edge cases distinguish them.',
    'Raw funding coefficients remain dimensionless. No actual funding cashflow, post-exit residual funding, cash ledger, affordability, portfolio return, or execution proof is established.',
    'Five unpriced residuals persist beyond fixed exit; fixed-interval overlap does not assert account flatness. Conditional 41-event completed statistics are a feasibility-selected subset.',
    'The largest DOGE outcome and original frozen direction are retained. No revised signal, entry-gap recipe, or residual economic mark is computed.'
]
report = dict(schema='INDEPENDENT_SAVED_EVENT_CAPACITY_REVIEW_V1',
    status='PASS_WITH_QUALIFICATIONS' if not failures else 'FAIL',
    check_count=sum(checks.values()), checks_by_category=checks, failed_checks=failures,
    review_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    screen_code_SHA256=sha(HERE/'screen.py'), verifier_code_SHA256=sha(Path(__file__)),
    artifacts_SHA256={name:sha(HERE/name) for name in ['PROTOCOL.json','PRE_SCAN_AMENDMENT.json','FREEZE_RECEIPT.json','AMENDMENT_FREEZE_RECEIPT.json','PRE_SCAN_PINS.json','SYNTHETIC_TESTS.json','RESULT.json','EVENT_CAPACITY_ROWS.json','EVENT_CAPACITY_ROWS.csv','SOURCE_READ_RECEIPT.json','OVERLAP_REFERENCE_CAPITAL.json']},
    verified_events=46, independently_verified_source_points=source_points,
    independently_decoded_2025_months=len(arrays), source_hash_months=12,
    scalar_decimal_precision=50, original_csv_max_raw_funding_rounding_difference=str(rounding_tolerance_max),
    outcomes=result['overall'], unpriced_residuals=residual_details,
    native_funding=result['funding'], native_membership_changes=membership_changes,
    maximum_concurrency=max(s['count'] for s in segments), overlap_segments=len(segments),
    peak_desired_reference_fraction=str(max(D(s['desired_reference_wallet_fraction']) for s in segments)),
    limitations=limitations,
    resources=dict(review_CPU_affinity=sorted(os.sched_getaffinity(0)), threads=1,
        wall_seconds=time.monotonic()-start, screen_main_reruns=0, new_backtests=0,
        account_constructors=0, financial_advances=0, provider_downloads=0,
        source2026_reads=0, Library_writes=0, GitHub_writes=0, deletes=0))
with (HERE/'REVIEW.json').open('x') as f:
    json.dump(report, f, indent=2, sort_keys=True, allow_nan=False)
    f.write('\n')
text = ['# Independent saved-output review', '', report['status'], '',
    f"{report['check_count']:,} checks; {len(failures)} failures. Decimal precision 50. No screen.main rerun.",
    f"screen.py SHA256: {report['screen_code_SHA256']}",
    f"REVIEW_VERIFY.py SHA256: {report['verifier_code_SHA256']}", '',
    '## Findings',
    '- All 46 event identities, directions, fixed entry/exit clocks, and observed source OPEN prices match the bound CSV and locators.',
    '- All protocol/amendment receipts, fixed inputs, source index, 12 canonical month byte/hash bindings, funding byte/hash bindings, and saved JSON/CSV fields match.',
    '- Independently checked 184 source points: 92 OPENs and 92 safe quote volumes. Safe volume opens u-2min; adjacent prior is unavailable until u+1us. No adjacent future volume values were read.',
    '- Coarse quantity floor, actual-adverse-fill opening minimum10, 0.1% independent entry/exit capacity, adverse8bp each side, and fee5.5bp on actual fill notional match every saved scalar.',
    '- 45 full coarse entries, one partial entry, zero no-entries; 41 full paid closes, 5 open unpriced residuals; 40 full-size complete roundtrips.',
    '- Residuals: E013 DOGE 3000; E017 XRP 100; E024 DOGE 2000; E027 DOGE 5000; E033 DOGE 1000. Entry basis and allocated paid entry fees persist, completed PnL is null.',
    '- Native funding entry<clock<=exit yields seven occurrences, raw signed-coefficient sum0.00033534. Original CSV interval is separately verified; there are no membership changes.',
    f'- Independent exit-first sweep matches all {len(segments)} overlap segments, maximum concurrency5 and peak desired reference footprint6000/10000=60%. This omits residual tails by design.',
    '- All46 desired-coarse counterfactual exact-cost mean149.826694bp, median-21.321174bp, positives21/46; exact roundtrip cost range26.441826–35.213835bp.',
    '- Conditional41 completed-entry proxies mean168.089558bp, median-14.516366bp, positives20/41. These are seen-development diagnostics only.', '',
    '## Check counts']
text += [f'- {k}: {v}' for k,v in checks.items()]
text += ['', '## Qualifications'] + ['- '+x for x in limitations]
if failures:
    text += ['', '## Failures'] + [str(x) for x in failures]
with (HERE/'REVIEW.md').open('x') as f:
    f.write('\n'.join(text)+'\n')
print(json.dumps(dict(status=report['status'], check_count=report['check_count'], failures=failures,
    screen_code_SHA256=report['screen_code_SHA256'], verifier_code_SHA256=report['verifier_code_SHA256'],
    directory_bytes=sum(p.stat().st_size for p in HERE.iterdir() if p.is_file()),
    review_report=str(HERE/'REVIEW.json')), indent=2))
