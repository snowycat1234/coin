# Independent saved-output review

PASS_WITH_QUALIFICATIONS

15,911 checks; 0 failures. Decimal precision 50. No screen.main rerun.
screen.py SHA256: 9ec5789b37ddccd7c51d108e23c5a8b320bef9a8e5ea1c6bf32ac7d42e2664d0
REVIEW_VERIFY.py SHA256: d04d42480d8bef3308df25305579cf7709ca583628c51842d476b2e211d68405

## Findings
- All 46 event identities, directions, fixed entry/exit clocks, and observed source OPEN prices match the bound CSV and locators.
- All protocol/amendment receipts, fixed inputs, source index, 12 canonical month byte/hash bindings, funding byte/hash bindings, and saved JSON/CSV fields match.
- Independently checked 184 source points: 92 OPENs and 92 safe quote volumes. Safe volume opens u-2min; adjacent prior is unavailable until u+1us. No adjacent future volume values were read.
- Coarse quantity floor, actual-adverse-fill opening minimum10, 0.1% independent entry/exit capacity, adverse8bp each side, and fee5.5bp on actual fill notional match every saved scalar.
- 45 full coarse entries, one partial entry, zero no-entries; 41 full paid closes, 5 open unpriced residuals; 40 full-size complete roundtrips.
- Residuals: E013 DOGE 3000; E017 XRP 100; E024 DOGE 2000; E027 DOGE 5000; E033 DOGE 1000. Entry basis and allocated paid entry fees persist, completed PnL is null.
- Native funding entry<clock<=exit yields seven occurrences, raw signed-coefficient sum0.00033534. Original CSV interval is separately verified; there are no membership changes.
- Independent exit-first sweep matches all 46 overlap segments, maximum concurrency5 and peak desired reference footprint6000/10000=60%. This omits residual tails by design.
- All46 desired-coarse counterfactual exact-cost mean149.826694bp, median-21.321174bp, positives21/46; exact roundtrip cost range26.441826–35.213835bp.
- Conditional41 completed-entry proxies mean168.089558bp, median-14.516366bp, positives20/41. These are seen-development diagnostics only.

## Check counts
- bindings: 73
- identity: 830
- funding: 6043
- source: 1746
- causal_capacity: 920
- decimal_quantity: 1058
- classification: 470
- decimal_costs: 1012
- source_receipts: 5
- csv_consistency: 3589
- overlap: 99
- summary: 22
- edge_cases: 27
- implementation: 17

## Qualifications
- This is a saved-output and bound-source-point verification, not a rerun of screen.main, a signal scan, or a new backtest.
- Freeze receipts and resource counters are self-reported artifacts; hash consistency and timestamp ordering do not independently prove historical execution chronology or system-call absence.
- screen.py was not hash-bound in the freeze receipts; this review records its current hash. Saved arithmetic/source matches cannot prove that this exact file produced the saved outputs.
- All 92 safe quote-volume points are causally available only under the declared completion+1us proxy. Source OPEN prices remain future outcome proxies, not certified executable quotes.
- The opening minimum is tested on actual adverse fill notional. Coarse steps and 0.1% historical quote-volume participation are research conventions, not native venue filters or order-book depth.
- Native funding ownership entry<clock<=exit and original CSV entry<=clock<exit agree on these 46 events only because none has a boundary funding occurrence; independent boundary edge cases distinguish them.
- Raw funding coefficients remain dimensionless. No actual funding cashflow, post-exit residual funding, cash ledger, affordability, portfolio return, or execution proof is established.
- Five unpriced residuals persist beyond fixed exit; fixed-interval overlap does not assert account flatness. Conditional 41-event completed statistics are a feasibility-selected subset.
- The largest DOGE outcome and original frozen direction are retained. No revised signal, entry-gap recipe, or residual economic mark is computed.
