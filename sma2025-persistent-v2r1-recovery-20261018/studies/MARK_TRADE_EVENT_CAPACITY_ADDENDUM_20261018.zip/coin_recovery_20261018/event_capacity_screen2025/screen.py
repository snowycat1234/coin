"""Bounded fixed-event arithmetic only. No account/engine/provider imports."""
from __future__ import annotations
import csv
import datetime as dt
from decimal import Decimal as D, ROUND_FLOOR, getcontext
import hashlib
import json
import os
from pathlib import Path
import resource
import statistics
import sys
import time

getcontext().prec = 50
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
INPUT = ROOT / 'mark_trade_minute_event2025'
SOURCE = ROOT / 'restored2025' / 'prepared_2025'
MINUTE = 60_000_000
STEPS = {'BTCUSDT':D('.001'),'ETHUSDT':D('.01'),'SOLUSDT':D('1'),
         'XRPUSDT':D('100'),'DOGEUSDT':D('1000')}
FEE, ADVERSE, PARTICIPATION = D('.00055'), D('.0008'), D('.001')
DESIRED, WALLET = D('1200'), D('10000')

def need(ok, message):
    if not ok:
        raise ValueError(message)

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def write_json(p, x):
    with p.open('x') as f:
        json.dump(x, f, indent=2, sort_keys=True, allow_nan=False)
        f.write('\n')

def utc(us):
    return dt.datetime.fromtimestamp(us / 1_000_000, dt.timezone.utc).isoformat()

def dec(x):
    a = D(str(x))
    need(a.is_finite(), 'nonfinite numeric input')
    return a

def floor(q, step):
    need(q >= 0 and step > 0, 'invalid floor')
    return (q / step).to_integral_value(rounding=ROUND_FLOOR) * step

def latest_available(open_times, at_us):
    # No market value is inspected until its time/availability mask is selected.
    eligible = [i for i,t in enumerate(open_times) if int(t) + MINUTE + 1 <= at_us]
    return None if not eligible else eligible[-1]

def fill_prices(d, p0, p1):
    return p0*(1+D(d)*ADVERSE), p1*(1-D(d)*ADVERSE)

def costs(d, p0, p1, q):
    a,b = fill_prices(d,p0,p1)
    gross = D(d)*q*(b-a)
    ef,xf = q*a*FEE,q*b*FEE
    return dict(entry_fill=a,exit_fill=b,gross=gross,entry_fee=ef,exit_fee=xf,
                after_cost=gross-ef-xf,mid_gross=D(d)*q*(p1-p0),
                execution_price_cost=q*(p0+p1)*ADVERSE)

def quantities(p0,p1,d,step,v0,v1):
    desired = DESIRED/p0
    request = floor(desired,step)
    cap0,cap1 = v0*PARTICIPATION/p0,v1*PARTICIPATION/p1
    before_min = floor(min(request,cap0),step)
    fill0,_ = fill_prices(d,p0,p1)
    qe = before_min if before_min*fill0 >= D('10') else D('0')
    qx = floor(min(qe,cap1),step)
    return desired,request,cap0,cap1,before_min,qe,qx

def fund_select(rows, start, end, native=True):
    if native:
        return [r for r in rows if start < r['event_us'] <= end]
    return [r for r in rows if start <= r['event_us'] < end]

def coefficient(rows,d):
    return -D(d)*sum((dec(r['raw_rate']) for r in rows),D('0'))

def reference_overlap(rows):
    stamps=sorted({r['entry_us'] for r in rows}|{r['exit_us'] for r in rows})
    segments=[]
    for a,b in zip(stamps,stamps[1:]):
        active=[r for r in rows if r['entry_us']<=a<r['exit_us']]
        if not active:
            continue
        segments.append(dict(start_us=a,end_us=b,duration_us=b-a,count=len(active),
            event_ids=[r['event_id'] for r in active],
            desired_reference_notional_USDT=str(DESIRED*len(active)),
            desired_reference_wallet_fraction=str(DESIRED*len(active)/WALLET),
            coarse_observed_entry_notional_USDT=str(sum((dec(r['coarse_entry_observed_notional_USDT']) for r in active),D('0'))),
            entry_feasible_observed_entry_notional_USDT=str(sum((dec(r['entry_feasible_observed_notional_USDT']) for r in active),D('0')))))
    durations={str(n):sum(s['duration_us'] for s in segments if s['count']==n) for n in range(1,6)}
    return dict(interval='[entry,exit); exits before entries at ties',
        max_fixed_interval_concurrency=max((s['count'] for s in segments),default=0),
        reference_wallet_USDT=str(WALLET),per_event_reference_USDT=str(DESIRED),
        fixed_interval_microseconds_by_concurrency=durations,
        segments_exceeding_reference_wallet=sum(dec(s['desired_reference_notional_USDT'])>WALLET for s in segments),
        segments=segments,
        caveat='Fixed interval reference count only. Unclosed residuals persist beyond these intervals and are not an account-flat assertion; no cash ledger or affordability proof.')

def run_synthetic():
    tests=[]
    def check(name, ok):
        need(ok, 'synthetic failure: '+name)
        tests.append(name)
    u=10*MINUTE
    ts=[u-3*MINUTE,u-2*MINUTE,u-MINUTE,u]
    i=latest_available(ts,u)
    check('exact_OPEN_selects_u_minus_2min',i==1 and ts[i]+MINUTE+1<=u)
    check('adjacent_prior_bar_future_at_exact_OPEN',ts[2]+MINUTE+1==u+1)
    vv=[D('20'),D('30'),D('999999999'),D('888888888')]
    selected=vv[i]
    vv[2]=D('1e40');vv[3]=D('1e50')
    check('future_volume_mutation_does_not_change_capacity',vv[i]==selected)
    check('adjacent_prior_becomes_eligible_at_OPEN_plus1us',latest_available(ts,u+1)==2)
    for d in (1,-1):
        c=costs(d,D('100'),D('100'),D('2'))
        check('flat_price_exact_adverse_and_fees_'+str(d),
              c['entry_fee']+c['exit_fee']==D('.22') and c['after_cost']==D('-.54'))
        check('both_sides_adverse_'+str(d),
              D(d)*(c['entry_fill']-D('100'))>0 and D(d)*(c['exit_fill']-D('100'))<0)
        for rate in (D('.001'),D('-.001')):
            cf=-D(d)*D('2')*D('100')*rate
            check('synthetic_funding_cashflow_sign_'+str(d)+'_'+str(rate),
                  (cf<0)==(D(d)*rate>0))
    short=costs(-1,D('100'),D('80'),D('2'))
    check('short_is_linear_not_reciprocal',short['mid_gross']==D('40'))
    check('fees_use_actual_adverse_notionals',short['entry_fee']==D('199.84')*FEE and short['exit_fee']==D('160.128')*FEE)
    for s,step in STEPS.items():
        q=step*D('5.999999')
        check('coarse_floor_'+s,floor(q,step)==step*5 and floor(q,step)<=q)
    q=quantities(D('1'),D('2'),1,D('1'),D('9000'),D('1000'))
    check('opening_minimum_bars_sub10',q[4]==9 and q[5]==0)
    q=quantities(D('1'),D('2'),1,D('1'),D('20000'),D('2000'))
    check('partial_exit_keeps_residual',q[5]==20 and q[6]==1 and q[5]-q[6]==19)
    check('closing_sub10_exempt',q[6]*D('2')<10 and q[6]>0)
    start,end=100,200
    f=[{'event_us':u,'raw_rate':'.001'} for u in (99,100,150,200,201)]
    check('native_funding_before_fill_entry_excluded_exit_owned',[r['event_us'] for r in fund_select(f,start,end)]==[150,200])
    check('original_attribution_boundary_preserved',[r['event_us'] for r in fund_select(f,start,end,False)]==[100,150])
    check('positive_and_negative_rate_coefficient',coefficient([{'raw_rate':'.002'},{'raw_rate':'-.003'}],1)==D('.001') and coefficient([{'raw_rate':'.002'},{'raw_rate':'-.003'}],-1)==D('-.001'))
    rr=[dict(event_id='A',entry_us=0,exit_us=10,coarse_entry_observed_notional_USDT='1200',entry_feasible_observed_notional_USDT='1000'),
        dict(event_id='B',entry_us=10,exit_us=20,coarse_entry_observed_notional_USDT='1200',entry_feasible_observed_notional_USDT='1000')]
    check('overlap_boundary_exit_before_entry',reference_overlap(rr)['max_fixed_interval_concurrency']==1)
    try:
        need('x'=='y','binding mismatch')
    except ValueError:
        check('binding_mismatch_fails_closed',True)
    else:
        raise ValueError('binding failopen')
    return dict(status='PASS',tests=len(tests),test_names=tests,actual_market_arrays_decoded=0,
                actual_scan_run=False,test_utc=dt.datetime.now(dt.timezone.utc).isoformat())

def stats(values):
    return dict(n=len(values),mean=None if not values else str(sum(values,D('0'))/len(values)),
                median=None if not values else str(statistics.median(values)),
                minimum=None if not values else str(min(values)),maximum=None if not values else str(max(values)),
                positive_count=sum(v>0 for v in values))

def main():
    start=time.monotonic()
    os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
    need(len(os.sched_getaffinity(0))==1,'CPU affinity')
    protocol=json.loads((HERE/'PROTOCOL.json').read_text())
    freeze=json.loads((HERE/'FREEZE_RECEIPT.json').read_text())
    amend=json.loads((HERE/'AMENDMENT_FREEZE_RECEIPT.json').read_text())
    need(sha(HERE/'PROTOCOL.json')==freeze['protocol_SHA256']==amend['protocol_SHA256'],'screen protocol binding')
    need(sha(HERE/'PRE_SCAN_AMENDMENT.json')==amend['amendment_SHA256'],'amendment binding')
    synthetic=json.loads((HERE/'SYNTHETIC_TESTS.json').read_text())
    need(synthetic['status']=='PASS' and synthetic['actual_market_arrays_decoded']==0,'synthetic prerequisite')
    pins=[]
    for rel,expected in protocol['input_bindings'].items():
        p=ROOT/rel
        need(sha(p)==expected,'input binding mismatch '+rel)
        pins.append(dict(file=rel,SHA256=expected,bytes=p.stat().st_size))
    old=json.loads((INPUT/'PROTOCOL.json').read_text())
    loc=json.loads((INPUT/'EVENT_SOURCE_LOCATORS.json').read_text())
    need(loc['EVENTS_csv_SHA256']==protocol['input_bindings']['mark_trade_minute_event2025/EVENTS.csv'],'locator events binding')
    with (INPUT/'EVENTS.csv').open() as f:
        events=list(csv.DictReader(f))
    need(len(events)==len(loc['events'])==46,'fixed all46 count')
    need(sha(SOURCE/'SOURCE_INDEX.json')==old['inputs']['source_index_SHA256'],'source index binding')
    index=json.loads((SOURCE/'SOURCE_INDEX.json').read_text())
    need(tuple(index['symbol_order'])==tuple(STEPS),'source symbol order')
    monthly={r['month']:r for r in old['inputs']['canonical_months']}
    # Verify all12 canonical byte bindings before decoding any numeric array.
    for month,row in monthly.items():
        p=SOURCE/'months'/(month+'.npz')
        need(p.stat().st_size==row['source_NPZ_bytes'] and sha(p)==row['source_NPZ_SHA256'],'month source binding '+month)
        pins.append(dict(file=str(p.relative_to(ROOT)),SHA256=row['source_NPZ_SHA256'],bytes=p.stat().st_size))
    fp=old['inputs']['funding']
    need((SOURCE/'EVENTS.json').stat().st_size==fp['bytes'] and sha(SOURCE/'EVENTS.json')==fp['SHA256'],'funding binding')
    pins.append(dict(file=str((SOURCE/'EVENTS.json').relative_to(ROOT)),SHA256=fp['SHA256'],bytes=fp['bytes']))
    write_json(HERE/'PRE_SCAN_PINS.json',dict(status='PASS',pins=pins,screen_protocol_SHA256=sha(HERE/'PROTOCOL.json'),
                amendment_SHA256=sha(HERE/'PRE_SCAN_AMENDMENT.json'),synthetic_SHA256=sha(HERE/'SYNTHETIC_TESTS.json'),actual_market_arrays_decoded=0))
    # Only numpy is imported here, after tests, freeze and pin verification.
    import numpy as np
    fund=json.loads((SOURCE/'EVENTS.json').read_text())
    need(len(fund)==5475,'funding source count')
    for r in fund:
        need(type(r['event_us']) is int and r['symbol'] in STEPS and index['calendar'][0]<=r['event_us']<index['calendar'][1],'funding clock/schema')
        dec(r['raw_rate'])
    funds={s:[r for r in fund if r['symbol']==s] for s in STEPS}
    for s,rows in funds.items():
        need(len(rows)==1095 and all(a['event_us']<b['event_us'] for a,b in zip(rows,rows[1:])),'funding source order '+s)
    cache={}
    source_reads=[]
    def value(locator,symbol,field,clock=None,volume=False):
        p=ROOT/locator['source_file']
        month=p.stem
        need(month in monthly and p.resolve()==(SOURCE/'months'/(month+'.npz')).resolve(),'source locator path')
        need(locator['source_SHA256']==monthly[month]['source_NPZ_SHA256'],'locator hash')
        need(locator['array']==symbol+'_'+field,'locator array')
        if month not in cache:
            a=np.load(p,allow_pickle=False)
            t=a['times'].copy()
            need(t.dtype==np.int64 and len(t)==monthly[month]['minutes'] and np.all(np.diff(t)==MINUTE),'source exact minute grid')
            cache[month]=(a,t,{})
        a,t,columns=cache[month]
        i=locator['row_0_based']
        need(type(i) is int and 0<=i<len(t),'locator index')
        need(int(t[i])==locator['bar_open_us'] and locator['bar_completion_us']==int(t[i])+MINUTE and locator['availability_proxy_us']==int(t[i])+MINUTE+1,'locator timestamp')
        if volume:
            need(clock is not None and int(t[i])==clock-2*MINUTE and locator['availability_proxy_us']<=clock,'future volume masked')
            need(i+1<len(t) and int(t[i+1])+MINUTE+1==clock+1,'adjacent prior volume future')
        if field not in columns.get(symbol,{}):
            columns.setdefault(symbol,{})[field]=a[symbol+'_'+field]
        raw=columns[symbol][field][i]
        source_reads.append(dict(source_file=locator['source_file'],array=locator['array'],row_0_based=i,
                                  bar_open_us=int(t[i]),availability_proxy_us=locator['availability_proxy_us'],
                                  screen_information_clock_us=clock,used_as_capacity=volume))
        if volume and (not np.isfinite(raw) or raw<0):
            return D('0'),False,'NONFINITE_OR_NEGATIVE_SAFE_VOLUME_MASKED_ZERO'
        x=dec(raw)
        need(x>=0 if volume else x>0,'invalid source price/volume')
        return x,True,'AVAILABLE_ZERO_VOLUME' if volume and x==0 else 'AVAILABLE'
    out=[]
    for n,(e,l) in enumerate(zip(events,loc['events']),1):
        s=e['symbol'];d=int(e['direction']);en=int(e['entry_us']);ex=int(e['exit_us'])
        need(l['event_id']==f'E{n:03}' and l['symbol']==s and l['entry_us']==en and l['exit_us']==ex and l['feature_open_us']==int(e['feature_open_us']),'event locator identity')
        need(e['status']=='SELECTED' and d in(-1,1) and ex-en==60*MINUTE and en>=int(e['order_ready_us'])>int(e['feature_available_us']),'fixed event clock')
        p0,_,_=value(l['entry_trade_OPEN'],s,'open')
        p1,_,_=value(l['exit_trade_OPEN'],s,'open')
        need(p0==dec(e['entry_trade_open']) and p1==dec(e['exit_trade_open']),'event observed OPEN mismatch')
        need(l['entry_trade_OPEN']['bar_open_us']==en and l['exit_trade_OPEN']['bar_open_us']==ex,'exactOPEN price locator')
        v0,m0,r0=value(l['entry_latest_bar_quote_volume_available_at_exact_OPEN_under_plus1us'],s,'quote_volume',en,True)
        v1,m1,r1=value(l['exit_latest_bar_quote_volume_available_at_exact_OPEN_under_plus1us'],s,'quote_volume',ex,True)
        for side,u in [('entry',en),('exit',ex)]:
            adjacent=l[side+'_immediately_prior_bar_quote_volume']
            need(adjacent['bar_open_us']==u-MINUTE and adjacent['availability_proxy_us']==u+1,'adjacent prior clock binding')
        desired,request,cap0,cap1,before_min,qe,qx=quantities(p0,p1,d,STEPS[s],v0,v1)
        residual=qe-qx
        fullclose=qe>0 and qx==qe
        fullrequest=qe==request and qe>0
        cf=costs(d,p0,p1,request)
        closed=costs(d,p0,p1,qx)
        entry_fee=qe*cf['entry_fill']*FEE
        paid_exit_fee=closed['exit_fee']
        original=fund_select(funds[s],en,ex,False)
        native=fund_select(funds[s],en,ex,True)
        oldtimes=[] if not e['raw_funding_event_us'] else [int(x) for x in e['raw_funding_event_us'].split(';')]
        need(oldtimes==[r['event_us'] for r in original] and len(original)==int(e['raw_funding_events']),'original funding event clocks')
        origsum=sum((dec(r['raw_rate']) for r in original),D('0'))
        need(abs(origsum-dec(e['raw_rate_sum']))<D('1e-15') and abs(coefficient(original,d)-dec(e['signed_raw_rate_coefficient']))<D('1e-15'),'original funding arithmetic')
        row=dict(event_id=f'E{n:03}',symbol=s,direction=d,feature_open_us=int(e['feature_open_us']),
            original_signal_bp=e['signal_bp'],entry_us=en,exit_us=ex,entry_utc=e['entry_utc'],exit_utc=e['exit_utc'],
            entry_observed_OPEN=str(p0),exit_observed_OPEN=str(p1),coarse_step=str(STEPS[s]),
            desired_quantity=str(desired),coarse_requested_quantity=str(request),
            coarse_entry_observed_notional_USDT=str(request*p0),coarse_rounding_unused_desired_USDT=str(DESIRED-request*p0),
            entry_safe_volume=str(v0) if m0 else None,exit_safe_volume=str(v1) if m1 else None,
            entry_volume_available_mask=m0,exit_volume_available_mask=m1,entry_volume_mask_reason=r0,exit_volume_mask_reason=r1,
            entry_safe_volume_source=l['entry_latest_bar_quote_volume_available_at_exact_OPEN_under_plus1us'],
            exit_safe_volume_source=l['exit_latest_bar_quote_volume_available_at_exact_OPEN_under_plus1us'],
            entry_capacity_observed_quote_notional_USDT=str(v0*PARTICIPATION),exit_capacity_observed_quote_notional_USDT=str(v1*PARTICIPATION),
            entry_capacity_quantity=str(cap0),exit_capacity_quantity=str(cap1),
            entry_capacity_coarse_quantity=str(floor(cap0,STEPS[s])),exit_capacity_coarse_quantity=str(floor(cap1,STEPS[s])),
            entry_quantity_before_opening_minimum=str(before_min),entry_minimum_pass=(before_min>0 and before_min*cf['entry_fill']>=10),
            entry_feasible_quantity=str(qe),exit_feasible_quantity=str(qx),open_unpriced_residual_quantity=str(residual),
            entry_feasible_observed_notional_USDT=str(qe*p0),unused_desired_observed_entry_notional_USDT=str(DESIRED-qe*p0),
            entry_unused_capacity_observed_quote_notional_USDT=str(v0*PARTICIPATION-qe*p0),exit_unused_capacity_observed_quote_notional_USDT=str(v1*PARTICIPATION-qx*p1),
            full_coarse_request_entry_proxy_feasible=fullrequest,full_paid_close_of_entry_proxy_feasible=fullclose,
            full_desired_coarse_roundtrip_proxy_feasible=fullrequest and fullclose,
            status=('NO_ENTRY' if qe==0 else 'OPEN_UNPRICED_RESIDUAL' if residual else 'FULL_PAID_CLOSE_PROXY'),
            entry_size_status=('NO_ENTRY' if qe==0 else 'FULL_COARSE_REQUEST' if fullrequest else 'PARTIAL_ENTRY'),
            entry_adverse_fill_price=str(cf['entry_fill']),exit_adverse_fill_price=str(cf['exit_fill']),
            actual_entry_fill_notional_USDT=str(qe*cf['entry_fill']),actual_exit_fill_notional_USDT=str(qx*cf['exit_fill']),
            actual_paid_entry_fee_USDT=str(entry_fee),actual_paid_exit_fee_USDT=str(paid_exit_fee),
            closed_piece_gross_adverse_fill_PnL_USDT=str(closed['gross']),
            closed_piece_realized_less_all_paid_fees_USDT=str(closed['gross']-entry_fee-paid_exit_fee),
            residual_entry_fill_basis_USDT=str(residual*cf['entry_fill']),residual_allocated_paid_entry_fee_USDT=str(residual*cf['entry_fill']*FEE),
            completed_roundtrip_after_cost_USDT=str(closed['gross']-entry_fee-paid_exit_fee) if fullclose else None,
            completed_roundtrip_after_cost_bp_on_entry_observed_notional=str((closed['gross']-entry_fee-paid_exit_fee)/(qe*p0)*10000) if fullclose else None,
            counterfactual_full_coarse_mid_gross_USDT=str(cf['mid_gross']),counterfactual_full_coarse_execution_price_cost_USDT=str(cf['execution_price_cost']),
            counterfactual_full_coarse_entry_fee_USDT=str(cf['entry_fee']),counterfactual_full_coarse_exit_fee_USDT=str(cf['exit_fee']),
            counterfactual_full_coarse_after_cost_USDT=str(cf['after_cost']),
            counterfactual_full_coarse_after_cost_bp=str(cf['after_cost']/(request*p0)*10000) if request else None,
            counterfactual_full_coarse_exact_cost_bp=str((cf['mid_gross']-cf['after_cost'])/(request*p0)*10000) if request else None,
            original_attribution_funding_event_us=[r['event_us'] for r in original],
            native_owned_funding_event_us=[r['event_us'] for r in native],
            original_signed_raw_rate_coefficient=str(coefficient(original,d)),native_signed_raw_rate_coefficient=str(coefficient(native,d)),
            native_funding_event_count=len(native),native_raw_rate_sum=str(sum((dec(r['raw_rate']) for r in native),D('0'))),
            native_raw_rates=[str(r['raw_rate']) for r in native],funding_membership_changed=oldtimes!=[r['event_us'] for r in native],
            actual_funding_cashflow_USDT=None,funding_units_certified=False,
            real_execution_certified=False,conditional_proxy_only=True)
        need(qx<=qe<=request and all(floor(q,STEPS[s])==q for q in(qx,qe,request)),'quantity invariant')
        need(qe*p0<=v0*PARTICIPATION and qx*p1<=v1*PARTICIPATION,'capacity overshoot')
        need(row['completed_roundtrip_after_cost_USDT'] is None if residual or not qe else row['completed_roundtrip_after_cost_USDT'] is not None,'residual completedPnL guard')
        out.append(row)
    for a,t,c in cache.values():
        a.close()
    overlap=reference_overlap(out)
    for r in out:
        active=[x for x in out if x['entry_us']<=r['entry_us']<x['exit_us']]
        r['fixed_interval_overlap_at_entry_count']=len(active)
        r['fixed_interval_desired_reference_at_entry_USDT']=str(DESIRED*len(active))
    full=[r for r in out if r['full_paid_close_of_entry_proxy_feasible']]
    def group(rows):
        complete=[r for r in rows if r['full_paid_close_of_entry_proxy_feasible']]
        return dict(n=len(rows),full_requested_entry_count=sum(r['full_coarse_request_entry_proxy_feasible'] for r in rows),
            partial_entry_count=sum(r['entry_size_status']=='PARTIAL_ENTRY' for r in rows),no_entry_count=sum(r['status']=='NO_ENTRY' for r in rows),
            fully_closed_entry_count=len(complete),unpriced_residual_count=sum(r['status']=='OPEN_UNPRICED_RESIDUAL' for r in rows),
            full_desired_coarse_roundtrip_count=sum(r['full_desired_coarse_roundtrip_proxy_feasible'] for r in rows),
            counterfactual_full_coarse_aftercost_bp=stats([dec(r['counterfactual_full_coarse_after_cost_bp']) for r in rows if r['counterfactual_full_coarse_after_cost_bp'] is not None]),
            counterfactual_exact_cost_bp=stats([dec(r['counterfactual_full_coarse_exact_cost_bp']) for r in rows if r['counterfactual_full_coarse_exact_cost_bp'] is not None]),
            conditional_completed_aftercost_bp=stats([dec(r['completed_roundtrip_after_cost_bp_on_entry_observed_notional']) for r in complete]),
            diagnostic_paid_entry_fees_USDT=str(sum((dec(r['actual_paid_entry_fee_USDT']) for r in rows),D('0'))),
            diagnostic_paid_exit_fees_USDT=str(sum((dec(r['actual_paid_exit_fee_USDT']) for r in rows),D('0'))),
            diagnostic_unfilled_desired_observed_entry_notional_USDT=str(sum((dec(r['unused_desired_observed_entry_notional_USDT']) for r in rows),D('0'))))
    result=dict(schema='FIXED_EVENT_CAPACITY_EXACT_COST_SCREEN2025_RESULT_V1',status='PASS_CONDITIONAL_PROXY_ONLY',
        screen_protocol_SHA256=sha(HERE/'PROTOCOL.json'),amendment_SHA256=sha(HERE/'PRE_SCAN_AMENDMENT.json'),
        events_input_SHA256=sha(INPUT/'EVENTS.csv'),all46_preserved=True,fixed_clocks_directions_preserved=True,
        overall=group(out),per_asset={s:group([r for r in out if r['symbol']==s]) for s in STEPS},
        per_month={m:group([r for r in out if r['entry_utc'].startswith(m)]) for m in monthly},
        funding=dict(native_boundary='entry<funding_clock<=exit; funding before fills',original_boundary='entry<=funding_clock<exit',
            all46_clock_alignment_verified=True,events_with_native_owned_funding=sum(bool(r['native_funding_event_count']) for r in out),
            native_owned_funding_occurrences=sum(r['native_funding_event_count'] for r in out),
            native_signed_raw_rate_coefficient_sum=str(sum((dec(r['native_signed_raw_rate_coefficient']) for r in out),D('0'))),
            original_signed_raw_rate_coefficient_sum=str(sum((dec(r['original_signed_raw_rate_coefficient']) for r in out),D('0'))),
            membership_change_event_ids=[r['event_id'] for r in out if r['funding_membership_changed']],
            units='raw dimensionless only; actual cashflow unknown; no bp/cash conversion',
            residual_post_exit_funding='not evaluated'),
        overlap={k:v for k,v in overlap.items() if k!='segments'},
        capacity_masks=dict(entry_available=sum(r['entry_volume_available_mask'] for r in out),exit_available=sum(r['exit_volume_available_mask'] for r in out),
            entry_zero_volumes=sum(r['entry_safe_volume']=='0.0' or r['entry_safe_volume']=='0' for r in out),exit_zero_volumes=sum(r['exit_safe_volume']=='0.0' or r['exit_safe_volume']=='0' for r in out),
            future_adjacent_prior_volume_values_used=0,safe_volume_rows_used=92),
        residual_event_ids=[r['event_id'] for r in out if r['status']=='OPEN_UNPRICED_RESIDUAL'],
        mechanism_caveat='Independent raw review: largest DOGE winner tradeOPEN0.11355 and markOPEN0.11171 at fixed21:20 entry had -162.04bp gap, opposite frozen +129.46bp21:15 feature. Original direction retained; rebound does not prove entry markconvergence.',
        qualification='Historical volume participation and fixed adverse cost are research proxies. No native venue filters, orderbook, receipt/arrival, fundingcash, risk admission, sharedwallet, portfolio return or execution proof.',
        resources=dict(CPU_affinity=sorted(os.sched_getaffinity(0)),threads=1,wall_seconds=time.monotonic()-start,
            CPU_seconds=resource.getrusage(resource.RUSAGE_SELF).ru_utime+resource.getrusage(resource.RUSAGE_SELF).ru_stime,
            max_rss_KiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,actual_2025_month_arrays_decoded=len(cache),
            financial_account_constructors=0,financial_advances=0,provider_downloads=0,source2026_reads=0,Library_writes=0,GitHub_writes=0,deletes=0))
    write_json(HERE/'EVENT_CAPACITY_ROWS.json',out)
    csvrows=[]
    for row in out:
        csvrows.append({k:(json.dumps(v,sort_keys=True,separators=(',',':')) if isinstance(v,(list,dict)) else v) for k,v in row.items()})
    with (HERE/'EVENT_CAPACITY_ROWS.csv').open('x',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(csvrows[0]));w.writeheader();w.writerows(csvrows)
    write_json(HERE/'OVERLAP_REFERENCE_CAPITAL.json',overlap)
    write_json(HERE/'SOURCE_READ_RECEIPT.json',dict(rows=source_reads,array_value_lookups=len(source_reads),future_volume_values_used=0))
    write_json(HERE/'RESULT.json',result)
    print(json.dumps(result,indent=2,sort_keys=True))

if __name__=='__main__':
    if len(sys.argv)==2 and sys.argv[1]=='--synthetic':
        write_json(HERE/'SYNTHETIC_TESTS.json',run_synthetic())
        print((HERE/'SYNTHETIC_TESTS.json').read_text())
    elif len(sys.argv)==1:
        main()
    else:
        raise SystemExit('usage: screen.py [--synthetic]')
