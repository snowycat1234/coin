# Fixed-event one-shot capacity and exact-cost screen, 2025

## Bottom line

Under the frozen historical-volume participation proxy, **40 of all46 fixed events** can enter the full coarse request and pay for a complete exit at the fixed60-minute endpoint. There is **one partial entry** that can fully close and **five partial exits** with explicit open, unpriced inventory. None is dropped or force-cleared.

The original price-result mean is not an achievable portfolio result. Replacing the flat27bp subtraction with exact adverse fills and fees gives an **all46 full-coarse-size counterfactual** after-cost mean149.8267bp, median−21.3212bp and21/46 positive outcomes. Its feasibility is not assumed. Excluding incomplete events would change the sample and is not a new strategy or evidence of an advantage.

## Frozen scope and ordering

- Original protocol, all46 event CSV rows and source locators retain their exact bound SHA256 identities. Event direction, assets, months, threshold, five-minute entry schedule and fixed60-minute exit are unchanged.
- Reference wallet10000USDT; desired observed-entry-OPEN notional1200USDT per event (.12raw).
- Coarse quantity floors: BTC.001, ETH.01, SOL1, XRP100, DOGE1000. Opening minimum10USDT is tested on the adverse entry-fill notional. Paid closes are exempt from that minimum.
- Each side gets one independent capacity attempt: historical safe quote_volume×.001/observedOPEN, then coarse floor. No retries or clock shifts.
- At exactOPENu, the adjacent completed minute becomes available only at u+1us. The safe volume row opens u−2minutes and is available at u−1minute+1us. All92 safe volume values are finite, nonnegative and available under this convention; no adjacent-prior future volume is used.
- Prices remain observed tradeOPEN outcome proxies. The screen applies8bp adverse movement per side and5.5bp fees on each actual adverse fill notional. There is no extra27bp subtraction.
- The initial screen protocol was frozen before source-array decoding/capacity calculations. A separate pre-scan amendment, also frozen before decoding/calculation, applies funding-before-fill ownership and open/unpriced residual treatment. Both immutable documents and receipts are retained.

## Capacity classifications, all46

| Classification | Count |
|---|---:|
| Full coarse request at entry |45|
| Partial entry |1|
| No entry |0|
| Complete paid close of the entered quantity |41|
| Open, unpriced residual after fixed exit |5|
| Both full coarse entry and full close |40|

Full-size complete roundtrips by asset: BTC1/1, ETH8/8, SOL9/9, XRP9/10, DOGE13/18. These are feasibility descriptions of the unchanged sample, not outcome-based selection.

Coarse rounding leaves4326.05320USDT of the55200USDT summed event reference requests unused; entry capacity adds226.93000USDT unused. These summed request/rounding diagnostics are not simultaneous capital, NAV or portfolio returns.

### All incomplete full-size events

| Event | Asset | EntryUTC | Coarse requested | Entered | Closed | Open residual |
|---|---|---|---:|---:|---:|---:|
|E013|DOGE|Feb25 07:31|5000|5000|2000|3000|
|E017|XRP|Apr02 11:13|500|500|400|100|
|E022|DOGE|May15 08:36|5000|4000|4000|0|
|E024|DOGE|May15 20:12|5000|5000|3000|2000|
|E027|DOGE|Jun21 21:29|7000|7000|2000|5000|
|E033|DOGE|Sep13 17:18|4000|4000|3000|1000|

For all five residual events, the detailed table preserves full paid entry fees, fees on the actual closed portion, remaining entry-fill basis and allocated entry fees. A completed-roundtrip after-cost result is null. Remaining inventory has no assigned exit price, future fee or future funding. Its final outcome is unknown. Even after the nominal fixed exit, this inventory has not become cash or disappeared.

## Exact costs and the October10 concentration

Across all46 full-coarse-size counterfactuals, the exact roundtrip cost is26.4418–35.2138bp of observed entry notional, mean27.3927bp. It varies with exit notional and direction. In particular, fees and adverse exit movement are charged on the actual exit price; a large winner does not have a constant27bp cash charge.

All five October10 events pass the proxy at both ends:

| Event | Asset | Entered=closed quantity | Safe entry capacityUSDT | Safe exit capacityUSDT | Counterfactual after-costbp |
|---|---|---:|---:|---:|---:|
|E039|SOL|6|127498.69|14963.01|889.01|
|E040|XRP|500|63389.52|12181.71|922.43|
|E041|DOGE|10000|53881.81|14713.67|6051.09|
|E042|BTC|.011|1006184.30|66012.79|833.06|
|E043|ETH|.34|828640.90|70604.11|1071.09|

The largest DOGE winner E041 remains in the sample with its original long direction. Independent raw review found that at its21:20 entry the tradeOPEN was.11355 and markOPEN.11171: the gap was already−162.04bp, opposite the frozen21:15 feature of+129.46bp. A later rebound is not demonstrated entry-time mark convergence. This screen does not recompute an entry-gap signal or repair the strategy after seeing outcomes.

Large prior traded volume during the crash does not establish executable depth at that exactOPEN, actual arrival, spread or8bp slippage. Passing this participation proxy does not validate those October10 fills.

## Funding attribution and reference capital

All46 literal funding clocks are checked. Primary screen ownership uses **entry<fundingclock≤exit**, funding before fills. The original CSV attribution **entry≤fundingclock<exit** is independently checked and preserved. No actual sample membership changes between these boundaries: seven events contain seven occurrences, with signed raw-rate coefficient sum+0.00033534. The ETH May9 event retains its actual timestamp1746777600006000, including the6ms offset.

These are raw dimensionless coefficients only. Certified historical rate units, charge marks and actual ownership are unknown. No raw-rate multiplication by10000, funding cash conversion or integration into after-cost cash results is made. Positive/negative rate cashflow signs and both long/short positions are checked only in synthetic examples. No funding after an unresolved fixed exit is assumed.

Nominal fixed holding-interval concurrency peaks at five events:6000USDT desired reference notional,60% of the10000USDT reference wallet. No nominal interval exceeds that wallet. This is a count diagnostic, not a shared-wallet simulation, affordability or margin-risk proof. Open residuals persist beyond nominal intervals, so this count must not be read as actual post-exit exposure.

## Economic implication and limits

The simple all46 full-size event arithmetic silently assumes complete fixed-horizon exits that fail even this modest one-shot volume proxy in five cases. DOGE contributes four of those residuals and the only partial entry. A later paid-exit/inventory policy would be necessary before account economics could even be defined; this module does not invent one.

Exact cost accounting leaves the median negative and21/46 outcomes positive. The largest crash-day winner and concentration remain. There is no learned advantage, trading-ready signal, execution proof, portfolioAPR/CAGR, shared-wallet PnL or new financial backtest in this module.

## Evidence and reproducibility

- PROTOCOL.json and PRE_SCAN_AMENDMENT.json, with independent freeze receipts
- SYNTHETIC_TESTS.json:27 checks passed before the actual scan
- PRE_SCAN_PINS.json: original three input hashes and all12 canonical source-month bindings checked before decoding
- EVENT_CAPACITY_ROWS.json / .csv: all46 rows, exact Decimal strings, masks, sources, partial quantities, costs and raw funding
- OVERLAP_REFERENCE_CAPITAL.json: all fixed-interval segments, ties and reference footprints
- SOURCE_READ_RECEIPT.json:184 selected scalar lookups, including92 causal volume uses
- RESULT.json: complete all46, all-five-asset and all12-month classifications, including zero-event months
- Independent review and final author checks are supplied alongside this report

One allowed CPU, one thread;11 relevant2025 monthly array files decoded after pinning all12. No account constructors, finance advances, provider downloads,2026 sources, Library/GitHub writes or deletes.

### Audit qualification

Freeze chronology and resource counters are locally recorded/self-reported; the receipts do not independently attest process history or absence of system calls. The rule protocol and amendment were hash-bound, but screen.py itself was not included in the pre-scan freeze hashes. Independent review identifies and checks the current code and saved source/arithmetic; this is not historical executable provenance proof. FINAL_AUTHOR_CHECKS.json retains its earlier report hash; the final manifest and FINAL_SEAL.json bind this qualified final report.
