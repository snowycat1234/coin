"""Supplemental read-only report-claim checks; writes a new REVIEW file only."""
from pathlib import Path
from decimal import Decimal as D, getcontext, ROUND_HALF_EVEN
import hashlib
import json
import os

os.sched_setaffinity(0, {min(os.sched_getaffinity(0))})
getcontext().prec = 50
P = Path(__file__).resolve().parent
load = lambda n: json.loads((P/n).read_text())
sha = lambda n: hashlib.sha256((P/n).read_bytes()).hexdigest()
rows = load('EVENT_CAPACITY_ROWS.json')
result = load('RESULT.json')
report = (P/'REPORT.md').read_text()
prior = load('REVIEW.json')
author = load('FINAL_AUTHOR_CHECKS.json')
checks = []
failed = []


def check(name, ok):
    checks.append(name)
    if not ok:
        failed.append(name)


check('unchanged screen code binding since independent audit', sha('screen.py') == prior['screen_code_SHA256'])
check('author report binding', sha('REPORT.md') == author['report_SHA256'])
check('author result binding', sha('RESULT.json') == author['result_SHA256'])
check('author check count and unique names', author['checks'] == len(set(author['check_names'])) == 148)
check('saved independent audit no failures', prior['check_count'] == 15911 and not prior['failed_checks'])
october = [r for r in rows if r['entry_utc'].startswith('2025-10-10')]
check('October10 exactly five frozen events', [r['event_id'] for r in october] == ['E039','E040','E041','E042','E043'])
check('October10 all five assets full-sized completed proxy', {r['symbol'] for r in october} == {'BTCUSDT','ETHUSDT','SOLUSDT','XRPUSDT','DOGEUSDT'} and all(r['full_desired_coarse_roundtrip_proxy_feasible'] for r in october))
check('report explicitly labels all46 counterfactual', '**all46 full-coarse-size counterfactual**' in report)
check('report does not assume counterfactual feasibility', 'Its feasibility is not assumed.' in report)
for key, text in [('mean','149.8267'),('median','-21.3212')]:
    actual = D(result['overall']['counterfactual_full_coarse_aftercost_bp'][key]).quantize(D('.0001'))
    check('all46 full-size counterfactual rounded '+key, actual == D(text))
check('all46 positive21/46', result['overall']['counterfactual_full_coarse_aftercost_bp']['positive_count'] == 21 and result['overall']['counterfactual_full_coarse_aftercost_bp']['n'] == 46)
e41 = next(r for r in rows if r['event_id'] == 'E041')
check('E041 direction long retained', e41['direction'] == 1)
check('E041 observed entry0.11355 retained', D(e41['entry_observed_OPEN']) == D('.11355'))
check('E041 exact cost35.2138bp', D(e41['counterfactual_full_coarse_exact_cost_bp']).quantize(D('.0001')) == D('35.2138'))
check('E041 is maximum exact cost', D(e41['counterfactual_full_coarse_exact_cost_bp']) == max(D(r['counterfactual_full_coarse_exact_cost_bp']) for r in rows))
for key, expected in [('minimum','26.4418'),('maximum','35.2138'),('mean','27.3927')]:
    check('cost range rounded '+key, D(result['overall']['counterfactual_exact_cost_bp'][key]).quantize(D('.0001')) == D(expected))
tables = {}
for line in report.splitlines():
    if line.startswith('|E'):
        cells = [x.strip() for x in line.strip('|').split('|')]
        tables[cells[0]] = cells
expected_incomplete = {'E013':('5000','5000','2000','3000'), 'E017':('500','500','400','100'),
    'E022':('5000','4000','4000','0'), 'E024':('5000','5000','3000','2000'),
    'E027':('7000','7000','2000','5000'), 'E033':('4000','4000','3000','1000')}
for eid, quantities in expected_incomplete.items():
    check(eid+' report incomplete quantities', tuple(tables[eid][3:]) == quantities)
for r in october:
    cells = tables[r['event_id']]
    check(r['event_id']+' October table quantity', D(cells[2]) == D(r['entry_feasible_quantity']) == D(r['exit_feasible_quantity']))
    check(r['event_id']+' October table safe entry capacity', D(cells[3]) == D(r['entry_capacity_observed_quote_notional_USDT']).quantize(D('.01'), rounding=ROUND_HALF_EVEN))
    check(r['event_id']+' October table safe exit capacity', D(cells[4]) == D(r['exit_capacity_observed_quote_notional_USDT']).quantize(D('.01'), rounding=ROUND_HALF_EVEN))
    check(r['event_id']+' October table aftercost', D(cells[5]) == D(r['counterfactual_full_coarse_after_cost_bp']).quantize(D('.01'), rounding=ROUND_HALF_EVEN))
residuals = [r for r in rows if r['status'] == 'OPEN_UNPRICED_RESIDUAL']
check('five residuals never have completed net', len(residuals) == 5 and all(r['completed_roundtrip_after_cost_USDT'] is None and r['completed_roundtrip_after_cost_bp_on_entry_observed_notional'] is None for r in residuals))
check('report explicitly residual completed null', 'A completed-roundtrip after-cost result is null.' in report)
check('report no residual terminal economics', 'Its final outcome is unknown.' in report and 'Remaining inventory has no assigned exit price, future fee or future funding.' in report)
unused_rounding = sum((D(r['coarse_rounding_unused_desired_USDT']) for r in rows),D(0))
unused_capacity = sum((D(r['unused_desired_observed_entry_notional_USDT'])-D(r['coarse_rounding_unused_desired_USDT']) for r in rows),D(0))
check('rounding unused4326.05320', unused_rounding == D('4326.05320'))
check('additional entry capacity unused226.93000', unused_capacity == D('226.93000'))
check('summed reference55200', 46 * 1200 == 55200)
expected_full = {'BTCUSDT':1,'ETHUSDT':8,'SOLUSDT':9,'XRPUSDT':9,'DOGEUSDT':13}
for symbol, count in expected_full.items():
    check(symbol+' full-size closed reported count', sum(r['full_desired_coarse_roundtrip_proxy_feasible'] for r in rows if r['symbol'] == symbol) == count)
funding = result['funding']
check('native funding seven events seven occurrences', funding['events_with_native_owned_funding'] == funding['native_owned_funding_occurrences'] == 7)
check('native funding no membership changes', funding['membership_change_event_ids'] == [])
check('native funding signed raw coefficient0.00033534', D(funding['native_signed_raw_rate_coefficient_sum']) == D('.00033534'))
check('actual offset6ms retained', any(1746777600006000 in r['native_owned_funding_event_us'] for r in rows if r['symbol'] == 'ETHUSDT'))
check('maximum reference concurrency5 desired6000 60percent', result['overlap']['max_fixed_interval_concurrency'] == 5 and 5 * D(1200) / D(10000) == D('.6'))
check('no nominal interval exceeds wallet', result['overlap']['segments_exceeding_reference_wallet'] == 0)
check('report distinguishes residual exposure tails', 'Open residuals persist beyond nominal intervals' in report)
check('original synthetic27', load('SYNTHETIC_TESTS.json')['tests'] == 27)
check('report disclaims execution proof', 'Passing this participation proxy does not validate those October10 fills.' in report)

# Explicit synthetic funding-before-fill event ordering, including both ties.
# No actual market data or account objects are involved.
for direction in (-1, 1):
    for rate in (D('.001'), D('-.001')):
        events = [(100,1,'entry'),(100,0,'funding'),(150,0,'funding'),(200,1,'exit'),(200,0,'funding')]
        position = D(0)
        observed = []
        for stamp, _, kind in sorted(events):
            if kind == 'funding':
                observed.append((stamp, position, -position * D(100) * rate))
            elif kind == 'entry':
                position += D(direction) * 2
            else:
                position -= D(direction) * 2
        expected = [(100,D(0),D(0)), (150,D(direction)*2,-D(direction)*2*D(100)*rate), (200,D(direction)*2,-D(direction)*2*D(100)*rate)]
        check('synthetic funding-before-fill tie positions/rate '+str((direction, rate)), observed == expected and position == 0)

out = dict(status='PASS' if not failed else 'FAIL', check_count=len(checks),
    check_names=checks, failed_checks=failed, prior_review_check_count=prior['check_count'],
    combined_check_count=prior['check_count']+len(checks),
    report_SHA256=sha('REPORT.md'), screen_code_SHA256=sha('screen.py'),
    verifier_code_SHA256=sha('REVIEW_REPORT_CLAIMS.py'),
    qualification='Gap/markOPEN independent-raw-review claim is inherited context and was not reconstructed from raw mark source here. The screen arithmetic, frozen original direction, and observed entry price are independently corroborated. Review does not establish historical execution chronology.',
    resources=dict(CPU_affinity=sorted(os.sched_getaffinity(0)),screen_reruns=0,new_backtests=0,source2026_reads=0))
with (P/'REVIEW_REPORT_CLAIMS.json').open('x') as f:
    json.dump(out,f,indent=2,sort_keys=True)
    f.write('\n')
print(json.dumps(dict(status=out['status'], check_count=out['check_count'], combined_check_count=out['combined_check_count'], failures=failed,report_SHA256=out['report_SHA256'], verifier_code_SHA256=out['verifier_code_SHA256']),indent=2))
