"""Offline package integrity and source-target checks; never create an account."""
from pathlib import Path
import hashlib
import json
import numpy as np
import legacy_core_adapter as adapter
import prepare_2023 as preparation

HERE=Path(__file__).resolve().parent

def sha(raw):return hashlib.sha256(raw).hexdigest()

def verify():
    inventory=json.loads((HERE/'FILES.json').read_bytes())
    expected=set(inventory['files'])
    actual={path.relative_to(HERE).as_posix() for path in HERE.rglob('*')
        if path.is_file() and '__pycache__' not in path.parts and path.name!='FILES.json'}
    if actual!=expected:raise ValueError('EXACT_PUBLIC_PACKET_FILE_SET_REQUIRED')
    for name,rec in inventory['files'].items():
        path=HERE/name;raw=path.read_bytes()
        if path.is_symlink() or len(raw)!=rec['bytes'] or sha(raw)!=rec['SHA256']:
            raise ValueError('EXACT_PUBLIC_PACKET_FILE_HASH_REQUIRED:'+name)
    adapter.verify_sources();preparation._common()
    folder=HERE/'source_2023_attempt003'
    prep_raw=(folder/'PREPARATION.json').read_bytes();prep=json.loads(prep_raw)
    review_raw=(HERE/'INDEPENDENT_REVIEW.json').read_bytes();review=json.loads(review_raw)
    if (prep['code_identity']!=preparation.code_identity() or review['code_identity']!=prep['code_identity']
            or review['preparation_SHA256']!=sha(prep_raw) or review['artifacts']!=prep['artifacts']
            or review['status']!='PASS_SOURCE_AND_GENERATED_GATES_NO_FINANCIAL_RUN'
            or review['source_identity']!=prep['source_identity'] or review['financial_runs']!=0):
        raise ValueError('EXACT_BOUND_SOURCE_ONLY_INDEPENDENT_REVIEW_REQUIRED')
    for name,rec in prep['artifacts'].items():
        raw=(folder/name).read_bytes()
        if len(raw)!=rec['bytes'] or sha(raw)!=rec['SHA256']:raise ValueError('EXACT_SOURCE_PREPARATION_ARTIFACT_REQUIRED')
    with np.load(folder/'TARGETS.npz',allow_pickle=False) as z:
        decisions=z['decision_us'];covariance=z['annual_covariance']
        targets={key:z[key] for key in prep['configs']}
        if (not np.array_equal(decisions,np.arange(preparation.START,preparation.END,adapter.DAY,dtype=np.int64))
                or covariance.shape!=(365,5,5)
                or adapter.target_identities(decisions,targets)!=prep['target_identity']):
            raise ValueError('EXACT365_SIX_TARGET_CALENDAR_AND_IDENTITY_REQUIRED')
    comparison=json.loads((folder/'CURRENT_DIFFERENCE_AND_EQUIVALENCE.json').read_bytes())
    if comparison['same_tier_exact_current_reuse_candidates']:
        raise ValueError('UNEXPECTED_COMPLETED_CURRENT_EXECUTION_REUSE')
    if any(path.name=='ROOT_GO.json' for path in HERE.rglob('*')):
        raise ValueError('PUBLIC_SOURCE_PACKET_MUST_NOT_CONTAIN_FINANCIAL_ROOT_GO')
    return dict(schema='OFFLINE_SOURCE_ONLY_LEGACY_PACKET_VALIDATION_V1',status='PASS',files=len(expected),
        preparation_SHA256=sha(prep_raw),independent_review_SHA256=sha(review_raw),
        financial_accounts_created=0,financial_runs=0,network_requests=0,publications=0)

if __name__=='__main__':print(json.dumps(verify(),indent=2))
