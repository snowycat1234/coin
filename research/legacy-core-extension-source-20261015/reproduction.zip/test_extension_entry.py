"""Source-only/fictional gate tests. No generated fixture grants financial GO."""
from copy import deepcopy
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import extension_entry_2023 as e
import prepare_2023 as p
import run_extension_2023 as driver


def raw(value):return (json.dumps(value,sort_keys=True,allow_nan=False)+'\n').encode()

def fixture():
    prep=json.loads((p.HERE/'source_2023_attempt002/PREPARATION.json').read_bytes())
    prep['code_identity']=e.code_identity()
    review={key:prep[key] for key in ('code_identity','source_identity','execution_binding_SHA256','artifacts',
        'calendar','configs','resource_limits','pure_adapter_review_SHA256')}
    prep_raw=raw(prep)
    review.update(schema=e.REVIEW_SCHEMA,status=e.REVIEW_STATUS,preparation_SHA256=p.sha(prep_raw),
        controller_reporting_identity=driver.reporting_identity(),all365_original200_windows_verified=True,
        lower_only_original_intrinsic_targets_verified=True,unchanged_common_V3_finance_verified=True,
        tier_identity_and_no_cross_tier_reuse_verified=True,recognized_economic_HALT_is_partial_unpaid_not_annual=True,
        exact_root_GO_gate_verified=True,financial_runs=0,locked_or_holdout_consumed=False,
        economic_terminal_policy_version=driver.TERMINAL_POLICY_VERSION,
        fixture_scope='FICTIONAL_UNIT_GATE_NOT_FINANCIAL_AUTHORIZATION')
    review_raw=raw(review)
    go={key:prep[key] for key in ('calendar','code_identity','source_identity','execution_binding_SHA256','resource_limits','cost')}
    go.update(schema='ROOT_GO_FINITE2023_LEGACY_CORE5_EXTENSION_V1',
        action='RUN_FRESH_APPROVED_2023_LEGACY_EXTENSION_JOBS_ONLY',preparation_SHA256=p.sha(prep_raw),
        controller_reporting_identity=driver.reporting_identity(),serial_execution=True,
        independent_review_SHA256=p.sha(review_raw),permitted_configs=list(e.CONFIGS),other_years_authorized=False,
        locked_or_holdout_consumed=False,financial_policy_changes=False,prior_completed_cases=[],prior_economic_terminal_cases=[],
        continue_after_recognized_economic_terminal=False,economic_terminal_policy_version=driver.TERMINAL_POLICY_VERSION,
        fixture_scope='FICTIONAL_UNIT_GATE_NOT_FINANCIAL_AUTHORIZATION')
    return prep,go,review


def validate(prep,go,review,config=None):
    prep_raw,review_raw=raw(prep),raw(review);go=deepcopy(go)
    go['independent_review_SHA256']=p.sha(review_raw)
    go_raw=raw(go)
    return e.validate_root_go(prep_raw,go_raw,p.sha(go_raw),config=config or e.CONFIGS[0],
        review_raw=review_raw,expected_review_sha256=p.sha(review_raw))


class GateTests(unittest.TestCase):
    def test_fictional_validation_creates_no_account(self):
        prep,go,review=fixture()
        for config in e.CONFIGS:self.assertEqual(validate(prep,go,review,config)['configs'],list(e.CONFIGS))
        self.assertNotIn('STATIC50_LOW',e.CONFIGS)

    def test_missing_or_wrong_go_digest_rejected_before_source(self):
        prep,go,review=fixture()
        with self.assertRaisesRegex(ValueError,'BYTES_REQUIRED'):
            e.validate_root_go(raw(prep),raw(go),'0'*64,config=e.CONFIGS[0],review_raw=raw(review),expected_review_sha256=p.sha(raw(review)))

    def test_missing_report_identity_is_not_none_equality(self):
        prep,go,review=fixture();go.pop('controller_reporting_identity');review.pop('controller_reporting_identity')
        with self.assertRaises(ValueError):validate(prep,go,review)

    def test_any_current_core_or_unknown_version_rejected(self):
        for key in ('STATIC50_LOW','VOL_MANAGED_HOLD_MID','H090_HIGH','UNKNOWN'):
            prep,go,review=fixture();go['permitted_configs']=[key]
            with self.assertRaises(ValueError):validate(prep,go,review,key)

    def test_all_six_tier_identities_retained_despite_target_alias(self):
        prep,go,review=fixture()
        self.assertIn('STATIC50_OLD_NO_REEXPANSION_MID',go['permitted_configs'])
        self.assertIn('STATIC50_OLD_NO_REEXPANSION_HIGH',go['permitted_configs'])
        validate(prep,go,review)

    def test_duplicate_configs_rejected(self):
        prep,go,review=fixture();go['permitted_configs']=[e.CONFIGS[0]]*2
        with self.assertRaises(ValueError):validate(prep,go,review)

    def test_2024_and_other_year_scope_rejected(self):
        for field,value in [('calendar',[1704067200000000,1735689600000000]),('other_years_authorized',True),
                ('locked_or_holdout_consumed',True),('financial_policy_changes',True)]:
            prep,go,review=fixture();go[field]=value
            with self.assertRaises(ValueError):validate(prep,go,review)

    def test_prior_current_or_2024_terminal_cannot_enter_scope(self):
        for field in ('prior_completed_cases','prior_economic_terminal_cases'):
            prep,go,review=fixture();go[field]=[{'config':'STATIC50_MID','year':2024}]
            with self.assertRaises(ValueError):validate(prep,go,review)

    def test_review_flags_code_source_artifacts_and_pure_review_are_required(self):
        changes={'all365_original200_windows_verified':False,'lower_only_original_intrinsic_targets_verified':False,
            'unchanged_common_V3_finance_verified':False,'tier_identity_and_no_cross_tier_reuse_verified':False,
            'recognized_economic_HALT_is_partial_unpaid_not_annual':False,'exact_root_GO_gate_verified':False,
            'financial_runs':1,'pure_adapter_review_SHA256':'0'*64,'source_identity':'0'*64,
            'artifacts':{},'code_identity':{}}
        for key,value in changes.items():
            prep,go,review=fixture();review[key]=value
            with self.assertRaises(ValueError,msg=key):validate(prep,go,review)

    def test_each_go_source_code_target_policy_binding_rejected_if_changed(self):
        for key,value in {'source_identity':'0'*64,'execution_binding_SHA256':'0'*64,'code_identity':{},
                'preparation_SHA256':'0'*64,'serial_execution':False,'resource_limits':{},'cost':'STRESS43',
                'continue_after_recognized_economic_terminal':None}.items():
            prep,go,review=fixture();go[key]=value
            with self.assertRaises(ValueError,msg=key):validate(prep,go,review)

    def test_controller_policy_and_reporting_gates(self):
        prep,go,review=fixture();review_raw=raw(review);go_raw=raw(go)
        self.assertEqual(driver.validate_controller_go(raw(prep),go_raw,p.sha(go_raw),review_raw,p.sha(review_raw))['permitted_configs'],list(e.CONFIGS))
        for field in ('economic_terminal_policy_version','controller_reporting_identity'):
            changed=deepcopy(go);changed.pop(field);body=raw(changed)
            with self.assertRaises(ValueError):driver.validate_controller_go(raw(prep),body,p.sha(body),review_raw,p.sha(review_raw))

    def test_no_actual_root_go_is_saved_by_tests(self):
        self.assertFalse((p.HERE/'ROOT_GO.json').exists())


class SourceSeamTests(unittest.TestCase):
    def test_full365_source_rebuild_reaches_only_mocked_account_seam(self):
        prep,go,review=fixture();prep_raw=raw(prep);review['preparation_SHA256']=p.sha(prep_raw)
        review_raw=raw(review);go['independent_review_SHA256']=p.sha(review_raw);go['preparation_SHA256']=p.sha(prep_raw);go_raw=raw(go)
        with tempfile.TemporaryDirectory() as tmp:
            directory=Path(tmp)
            for name in prep['artifacts']:(directory/name).write_bytes((p.HERE/'source_2023_attempt003'/name).read_bytes())
            (directory/'PREPARATION.json').write_bytes(prep_raw)
            common,_,_=p._common()
            with patch.object(common.n,'_construct_case',side_effect=RuntimeError('MOCK_ACCOUNT_SEAM_NO_ACCOUNT')) as seam:
                with self.assertRaisesRegex(RuntimeError,'MOCK_ACCOUNT_SEAM_NO_ACCOUNT'):
                    e.make_extension_case(p.HERE.parent/'native_2023_source_restore_20261015',directory,go_raw,p.sha(go_raw),
                        config=e.CONFIGS[0],review_raw=review_raw,expected_review_sha256=p.sha(review_raw))
                self.assertEqual(seam.call_count,1)
                self.assertEqual(seam.call_args.kwargs['tier_name'],'LOW')
                self.assertEqual(seam.call_args.kwargs['cost_name'],'BASE27')
                self.assertIn('LEGACY_SIGNAL_COMMON_EXECUTION_VARIANT',seam.call_args.kwargs['source_scope'])

    def test_changed_preparation_during_rebuild_fails_before_account_seam(self):
        prep,go,review=fixture();prep_raw=raw(prep);review['preparation_SHA256']=p.sha(prep_raw)
        review_raw=raw(review);go['independent_review_SHA256']=p.sha(review_raw);go['preparation_SHA256']=p.sha(prep_raw);go_raw=raw(go)
        with tempfile.TemporaryDirectory() as tmp:
            directory=Path(tmp)
            for name in prep['artifacts']:(directory/name).write_bytes((p.HERE/'source_2023_attempt003'/name).read_bytes())
            (directory/'PREPARATION.json').write_bytes(prep_raw)
            common,_,_=p._common();original=e.adapter.build_target_grid
            def changed(*args,**kwargs):
                output=original(*args,**kwargs)
                (directory/'PREPARATION.json').write_bytes(prep_raw+b' ')
                return output
            with patch.object(e.adapter,'build_target_grid',side_effect=changed),patch.object(common.n,'_construct_case') as seam:
                with self.assertRaisesRegex(ValueError,'BEFORE_ACCOUNT'):
                    e.make_extension_case(p.HERE.parent/'native_2023_source_restore_20261015',directory,go_raw,p.sha(go_raw),
                        config=e.CONFIGS[0],review_raw=review_raw,expected_review_sha256=p.sha(review_raw))
                seam.assert_not_called()

if __name__=='__main__':unittest.main()
