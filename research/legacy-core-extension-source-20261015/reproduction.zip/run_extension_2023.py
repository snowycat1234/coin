"""Exact-GO/review-only bounded serial controller for six 2023 signal extensions.

Unknown failures stop the queue. A recognized native economic HALT is retained
as partial/unpaid and may advance only when the exact GO explicitly allows it.
No prior cases from any year are imported, retried, repaired or resumed.
"""
from __future__ import annotations
import argparse
from datetime import datetime,timezone
from decimal import Decimal
from io import BytesIO
import json
import os
from pathlib import Path
import resource
import subprocess
import sys
import threading
import time
import traceback
import extension_entry_2023 as entry
import prepare_2023 as preparation

HERE=Path(__file__).resolve().parent
LIMITS=entry.LIMITS
TERMINAL_POLICY_VERSION='FINITE2023_NATIVE_ECONOMIC_HALT_PARTIAL_UNPAID_V1'

def sha(raw):return preparation.sha(raw)
def utc():return time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
def write_bytes(path,body):
    path=Path(path);temporary=path.with_name(path.name+'.partial')
    if path.exists():raise FileExistsError(path)
    with temporary.open('xb') as stream:
        stream.write(body);stream.flush();os.fsync(stream.fileno())
    os.link(temporary,path);temporary.unlink()
    directory=os.open(path.parent,os.O_RDONLY|os.O_DIRECTORY)
    try:os.fsync(directory)
    finally:os.close(directory)
def save(path,value):write_bytes(path,(json.dumps(value,indent=2,allow_nan=False)+'\n').encode())
def own_bytes(path):return sum(p.stat().st_size for p in Path(path).rglob('*') if p.is_file())
def reporting_identity():
    return {'run_extension_2023.py':sha(Path(__file__).read_bytes()),
        'common_v3/annual_reporting.py':sha((HERE/'common_v3/annual_reporting.py').read_bytes()),
        'TERMINAL_POLICY_PROVENANCE.json':sha((HERE/'TERMINAL_POLICY_PROVENANCE.json').read_bytes())}

def validate_controller_go(preparation_raw,go_raw,go_sha,review_raw,review_sha):
    if not isinstance(go_raw,bytes) or sha(go_raw)!=go_sha:
        raise ValueError('EXACT_EXTERNAL_CONTROLLER_ROOT_GO_REQUIRED')
    go=json.loads(go_raw);review=json.loads(review_raw)
    if (go.get('controller_reporting_identity')!=reporting_identity()
            or review.get('controller_reporting_identity')!=reporting_identity()
            or go.get('economic_terminal_policy_version')!=TERMINAL_POLICY_VERSION
            or review.get('economic_terminal_policy_version')!=TERMINAL_POLICY_VERSION
            or go.get('resource_limits')!=LIMITS or go.get('serial_execution') is not True
            or not isinstance(go.get('permitted_configs'),list) or not go['permitted_configs']):
        raise ValueError('EXACT_REVIEWED_SERIAL_EXTENSION_CONTROLLER_REPORTING_POLICY_REQUIRED')
    for config in go['permitted_configs']:
        entry.validate_root_go(preparation_raw,go_raw,go_sha,config=config,
            review_raw=review_raw,expected_review_sha256=review_sha)
    return go
def economic_terminal_record(receipt,result):
    """Classify an unchanged native HALT; never invent closure or annual PnL."""
    e=result['economics'];s=result['summary'];stop=receipt['account_stop_us']
    halt=('LIQUIDATION_REQUIRED_HALT' if e['liquidation_required_halt'] is True
        and e['bankruptcy_halt'] is False else 'BANKRUPT_HALT' if e['bankruptcy_halt'] is True
        and e['liquidation_required_halt'] is False else None)
    if (halt is None or s['account_status']!=halt or type(stop) is not int
            or not 1672531200000000<stop<=1704067200000000
            or s['clock_us']!=stop or s['halt_witness']['event_us']!=stop
            or s['completed_minutes']!=receipt['completed_minutes'] or s['required_minutes']!=525600
            or s['stop_us']!=stop or s['completion']!='NOT_EVALUABLE_ACCOUNT_HALT_NO_LIQUIDATION_SIMULATED'
            or receipt['completed_minutes']!=(stop-1672531200000000-1)//60000000
            or receipt['paid_comparison_eligible'] is not False or e['paid_flat'] is not False
            or e['paid_net_return'] is not None or e['full_calendar'] is not False
            or e['actual_liquidation_fills']!=0
            or e['liquidation_fill_model']!='NOT_IMPLEMENTED_NATIVE_ACCOUNT_STOPS_WITH_WITNESS'
            or receipt['required_minutes']!=525600 or not 0<receipt['completed_minutes']<=525600
            or receipt['calendar']!=[1672531200000000,1704067200000000]
            or e['calendar']!=receipt['calendar']):
        raise ValueError('UNRECOGNIZED_INCOMPLETE_PATH_OR_NATIVE_ECONOMIC_TERMINAL')
    witness=s['halt_witness']
    def exact(key):
        value=Decimal(str(witness.get('decimal_strings',{}).get(key,witness.get(key))))
        if not value.is_finite():raise ValueError('FINITE_EXACT_NATIVE_HALT_WITNESS_REQUIRED')
        return value
    nav,debt=exact('NAV'),exact('unpaid_liability')
    if debt<0 or debt!=Decimal(str(e['unpaid_liability'])):raise ValueError('EXACT_NATIVE_HALT_DEBT_REQUIRED')
    if 'symbol' in witness:
        equity,maintenance,mark,quantity=(exact(k) for k in ('isolated_equity','maintenance_margin','mark_price','quantity'))
        if (witness['symbol'] not in s['positions'] or mark<=0 or maintenance<0 or quantity==0
                or halt=='LIQUIDATION_REQUIRED_HALT' and not (0<equity<=maintenance and nav>0 and debt==0)
                or halt=='BANKRUPT_HALT' and not (equity<=0 or nav<=0 or debt>0)):
            raise ValueError('EXACT_NATIVE_ISOLATED_HALT_PREDICATE_REQUIRED')
    elif halt!='BANKRUPT_HALT' or not (nav<=0 or debt>0):
        raise ValueError('EXACT_NATIVE_GLOBAL_BANKRUPTCY_PREDICATE_REQUIRED')
    for key in ('residual_marked_notional','unpaid_liability'):
        value=Decimal(str(e[key]))
        if not value.is_finite() or value<0:raise ValueError('FINITE_RETAINED_ECONOMIC_STATE_REQUIRED')
    for symbol,pos in s['positions'].items():
        if not Decimal(str(pos['quantity'])).is_finite():raise ValueError('FINITE_RETAINED_POSITION_REQUIRED')
    return dict(schema='NATIVE_ECONOMIC_HALT_TERMINAL_NOT_ANNUAL_RESULT_V1',
        classification='NATIVE_ECONOMIC_HALT_UNPAID_PARTIAL',account_status=halt,
        stop_us=stop,stop_UTC=datetime.fromtimestamp(stop/1000000,timezone.utc).isoformat(),
        completed_minutes=receipt['completed_minutes'],required_minutes=525600,
        halt_witness=s['halt_witness'],retained_positions=s['positions'],
        residual_marked_notional=e['residual_marked_notional'],unpaid_liability=e['unpaid_liability'],
        partial_marked_net_return=e['marked_net_return'],partial_all_observation_MDD=e['all_observation_max_drawdown'],
        annual_paid_net_return=None,annual_APR=None,paid_comparison_eligible=False,
        observed_risk_scope='PARTIAL_TO_NATIVE_HALT_NOT_FULL_ANNUAL',partial_risk_file='OBSERVED_RISK.json',
        fees_USDT=e['fees_USDT'],execution_cost_USDT=e['execution_cost_USDT'],funding_USDT=e['funding_USDT'],
        actual_liquidation_fills=0,liquidation_fill_model=e['liquidation_fill_model'],
        financial_policy_changed=False,automatic_retry_authorized=False,
        next_distinct_case_requires_separately_bound_root_GO=True)


PRIMARY_ARTIFACTS=('MINUTE.npz','GUARD_RECEIPTS.json','NATIVE_REJECTIONS.json','FUNDING_JOURNAL.json')

def validate_primary_evidence(directory,checkpoint,receipt):
    import numpy as np
    hashes=checkpoint.get('retained_artifact_SHA256')
    if not isinstance(hashes,dict) or set(hashes)!=set(PRIMARY_ARTIFACTS):
        raise ValueError('EXACT_PRIMARY_EVIDENCE_FILE_SET_REQUIRED')
    for name in PRIMARY_ARTIFACTS:
        path=Path(directory)/name
        if path.is_symlink() or not path.is_file() or sha(path.read_bytes())!=hashes[name]:
            raise ValueError('EXACT_RETAINED_PRIMARY_EVIDENCE_HASH_REQUIRED')
    symbols=entry.adapter.SYMBOLS
    expected=['nav','free_cash','isolated_balance','gross_notional','net_signed_notional','cumulative_fees',
        'cumulative_execution_costs','cumulative_funding','cumulative_turnover',
        *[symbol+'_quantity' for symbol in symbols],*[symbol+'_signed_marked_notional' for symbol in symbols],
        *[symbol+'_isolated_balance' for symbol in symbols],*[symbol+'_isolated_equity' for symbol in symbols],
        *[symbol+'_signed_weight' for symbol in symbols],'gross_weight','net_signed_weight','close_us']
    with np.load(Path(directory)/'MINUTE.npz',allow_pickle=False) as archive:
        if set(archive.files)!={'values','columns'}:
            raise ValueError('EXACT_NATIVE_MINUTE_ARCHIVE_REQUIRED')
        values=archive['values'];columns=archive['columns']
        if (columns.ndim!=1 or columns.tolist()!=expected or values.dtype!=np.dtype('float64')
                or values.shape!=(receipt['completed_minutes'],len(expected))
                or not np.isfinite(values).all()
                or not np.array_equal(values[:,-1],np.arange(entry.START+60000000,
                    entry.START+(receipt['completed_minutes']+1)*60000000,60000000,dtype=np.int64))):
            raise ValueError('EXACT_NATIVE_MINUTE_ROWS_COLUMNS_AND_RETAINED_CALENDAR_REQUIRED')
    for name in PRIMARY_ARTIFACTS[1:]:
        if not isinstance(json.loads((Path(directory)/name).read_bytes()),list):
            raise ValueError('EXACT_NATIVE_PRIMARY_JOURNAL_ARRAY_REQUIRED')


def validate_saved_terminal(directory,go,preparation_raw,*,expected_go_sha256,config):
    directory=Path(directory);body=(directory/'CASE_RECEIPT.json').read_bytes();r=json.loads(body)
    prep=json.loads(preparation_raw);checkpoint=json.loads((directory/'TERMINAL_CHECKPOINT.json').read_bytes())
    result_body=(directory/'RESULT.json').read_bytes();result=json.loads(result_body)
    account_body=(directory/'ACCOUNT_FINANCIAL_AUDIT_SNAPSHOT.json').read_bytes();account=json.loads(account_body)
    if (r['schema']!='FINITE2023_LEGACY_EXTENSION_CASE_RECEIPT_V1' or r['config']!=config
            or result['config']!=config or config not in entry.CONFIGS or config not in go['permitted_configs']
            or r['root_GO_SHA256']!=expected_go_sha256 or r['preparation_SHA256']!=sha(preparation_raw)
            or r['code_identity']!=prep['code_identity'] or r['source_identity']!=prep['source_identity']
            or r['execution_binding_SHA256']!=prep['execution_binding_SHA256']
            or r['controller_reporting_identity']!=reporting_identity()
            or r['independent_review_SHA256']!=go['independent_review_SHA256'] or r['limits']!=LIMITS
            or r['calendar']!=[entry.START,entry.END] or r['required_minutes']!=entry.MINUTES
            or checkpoint['case_receipt_SHA256']!=sha(body) or checkpoint['result_SHA256']!=sha(result_body)
            or checkpoint['observed_risk_SHA256']!=sha((directory/'OBSERVED_RISK.json').read_bytes())
            or checkpoint['account_financial_audit_SHA256']!=sha(account_body)
            or checkpoint['completed_minutes']!=r['completed_minutes']
            or checkpoint['all_evidence_fsynced_before_checkpoint'] is not True
            or checkpoint['paid_comparison_eligible'] is not r['paid_comparison_eligible']
            or own_bytes(directory)>LIMITS['output_bytes']):
        raise ValueError('EXACT_2023_EXTENSION_TERMINAL_SCOPE_AND_EVIDENCE_REQUIRED')
    validate_primary_evidence(directory,checkpoint,r)
    summary=result['summary']
    if (account['status']!=summary['account_status'] or account['clock_us']!=summary['clock_us']
            or account['halt_witness']!=summary.get('halt_witness')
            or set(account['positions'])!=set(summary['positions'])):
        raise ValueError('ACTUAL_SAVED_ACCOUNT_TERMINAL_MUST_MATCH_RESULT')
    for symbol,pos in account['positions'].items():
        expected=summary['positions'][symbol]
        for key in ('quantity','entry_price','isolated_balance'):
            if Decimal(pos[key])!=Decimal(str(expected.get('decimal_strings',{}).get(key,expected[key]))):
                raise ValueError('ACTUAL_SAVED_RETAINED_POSITION_MUST_MATCH_RESULT')
        if pos['opened_us']!=expected['opened_us']:
            raise ValueError('ACTUAL_POSITION_ORIGIN_CLOCK_MUST_MATCH_RESULT')
    if r['paid_comparison_eligible'] is True:
        economics=result['economics'];risk=json.loads((directory/'OBSERVED_RISK.json').read_bytes())
        nav=Decimal(str(summary.get('decimal_strings',{}).get('NAV',summary.get('NAV'))))
        debt=Decimal(str(account['unpaid_liability']));cash=Decimal(str(account['free_cash']))
        paid=economics['paid_net_return'];marked=economics['marked_net_return']
        numeric=lambda value: isinstance(value,(int,float)) and not isinstance(value,bool) and __import__('math').isfinite(value)
        flat=(set(account['positions'])==set(entry.adapter.SYMBOLS) and
            all(Decimal(str(position['quantity']))==0 and Decimal(str(position['isolated_balance']))==0
                and Decimal(str(position['entry_price']))==0 and position['opened_us'] is None
                for position in account['positions'].values()))
        if (account['status']!='ACTIVE' or summary['account_status']!='ACTIVE'
                or account['clock_us']!=entry.END or summary['clock_us']!=entry.END
                or account['halt_witness'] is not None or summary.get('halt_witness') is not None
                or not nav.is_finite() or not cash.is_finite() or nav<=0 or nav!=cash
                or not debt.is_finite() or debt!=0 or not flat
                or Decimal(str(summary.get('decimal_strings',{}).get('unpaid_liability',summary.get('unpaid_liability'))))!=0
                or Decimal(str(economics['unpaid_liability']))!=0
                or Decimal(str(economics['residual_marked_notional']))!=0
                or Decimal(str(summary['terminal_marked_notional']))!=0
                or summary['terminal_cash_realized'] is not True
                or summary['stop_us'] is not None or summary['completed_minutes']!=entry.MINUTES
                or summary['required_minutes']!=entry.MINUTES or summary['completion']!='COMPLETE_CONDITIONAL_ACCOUNT'
                or economics['calendar']!=[entry.START,entry.END]
                or economics['liquidation_required_halt'] is not False or economics['bankruptcy_halt'] is not False
                or economics['actual_liquidation_fills']!=0
                or not numeric(paid) or not numeric(marked) or paid!=marked or paid!=float(nav/Decimal(10000)-1)
                or risk['complete_calendar_days']!=365 or risk['observation_count']!=entry.MINUTES):
            raise ValueError('EXACT_ACTIVE_FLAT_ZERO_DEBT_FULL2023_PAID_STATE_REQUIRED')
        if (r['status']!='COMPLETED_NATIVE_PATH' or r['completed_minutes']!=entry.MINUTES
                or r['account_stop_us'] is not None or r['actual_complete_calendar_days']!=365
                or result['economics']['paid_flat'] is not True or result['economics']['full_calendar'] is not True
                or checkpoint['economic_terminal_SHA256'] is not None):
            raise ValueError('EXACT_PAID_FULL2023_EXTENSION_TERMINAL_REQUIRED')
        return 'PAID_FULL_YEAR'
    expected=economic_terminal_record(r,result);terminal=(directory/'ECONOMIC_TERMINAL.json').read_bytes()
    if (r['status']!='NATIVE_ECONOMIC_HALT_UNPAID_PARTIAL' or json.loads(terminal)!=expected
            or checkpoint['economic_terminal_SHA256']!=sha(terminal)):
        raise ValueError('EXACT_NATIVE_ECONOMIC_HALT_EVIDENCE_REQUIRED')
    return 'NATIVE_ECONOMIC_HALT_UNPAID_PARTIAL'


def limits():
    for which,value in ((resource.RLIMIT_AS,LIMITS['AS_bytes']),(resource.RLIMIT_CPU,600),
            (resource.RLIMIT_RSS,LIMITS['RSS_stop_bytes'])):
        resource.setrlimit(which,(value,value))
    if hasattr(os,'sched_getaffinity'):os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})

def case(args):
    limits()
    for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','POLARS_MAX_THREADS'):
        os.environ[key]='1'
    import numpy as np
    prep_raw=(Path(args.preparation)/'PREPARATION.json').read_bytes()
    go_raw=Path(args.go).read_bytes();review_raw=Path(args.review).read_bytes()
    go=validate_controller_go(prep_raw,go_raw,args.go_sha,review_raw,args.review_sha)
    if args.config not in go['permitted_configs']:raise ValueError('EXACT_APPROVED_EXTENSION_CONFIG_REQUIRED')
    out=Path(args.case_output);out.mkdir(exist_ok=False)
    began=time.monotonic();started=utc();stopped=threading.Event()
    def watch():
        while not stopped.wait(.05):
            rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024
            reason=('RSS_LIMIT' if rss>LIMITS['RSS_stop_bytes'] else
                'WALL_LIMIT' if time.monotonic()-began>600 else
                'OUTPUT_LIMIT' if own_bytes(out)>LIMITS['output_bytes'] else None)
            if reason:
                save(out/'RESOURCE_STOP.json',dict(reason=reason,UTC=utc(),RSS_bytes=rss));os._exit(137)
    threading.Thread(target=watch,daemon=True).start()
    try:
        sim,guard=entry.make_extension_case(args.source,args.preparation,go_raw,args.go_sha,
            config=args.config,review_raw=review_raw,expected_review_sha256=args.review_sha)
        common,_,_=preparation._common();report=__import__('annual_reporting')
        construction=time.monotonic()-began;loop=time.monotonic()
        while sim.cursor<sim.end and sim.stop is None:
            sim.advance_day()
            print(json.dumps(dict(event='DAY_COMPLETE',config=args.config,UTC=utc(),
                completed_minutes=sim.rows_written,stop_us=sim.stop)),flush=True)
        loop_seconds=time.monotonic()-loop;result=common.n.case_result(sim,guard);owned=common.n.runtime()[4]
        data=result['minute'].to_numpy();columns=result['minute'].columns;prep=json.loads(prep_raw)
        target_record=prep['artifacts']['TARGETS.npz']
        target_raw=common.h._read_exact(Path(args.preparation)/'TARGETS.npz',target_record['SHA256'],target_record['bytes'])
        with np.load(BytesIO(target_raw),allow_pickle=False) as z:
            risk=report.risk_diagnostics(data,columns,z['decision_us'],z['annual_covariance'],z[args.config],guard.tier_name,guard.receipts)
        np.savez_compressed(out/'MINUTE.npz',values=data,columns=np.asarray(columns))
        with (out/'MINUTE.npz').open('rb') as handle:os.fsync(handle.fileno())
        save(out/'ACCOUNT_FINANCIAL_AUDIT_SNAPSHOT.json',sim.account.snapshot())
        save(out/'GUARD_RECEIPTS.json',guard.receipts)
        save(out/'NATIVE_REJECTIONS.json',owned.export_tree(sim.rejections))
        save(out/'FUNDING_JOURNAL.json',owned.export_tree(sim.funding_journal))
        save(out/'OBSERVED_RISK.json',risk)
        compact=dict(config=args.config,summary=result['summary'],economics=result['economics'],
            common_execution_policy=result['common_execution_policy'],target_meta=result['target_meta'])
        save(out/'RESULT.json',compact)
        if reporting_identity()!=go['controller_reporting_identity'] or entry.code_identity()!=prep['code_identity']:
            raise ValueError('EXTENSION_EXECUTABLE_CHANGED_DURING_CASE')
        economic_halt=bool(result['economics']['liquidation_required_halt'] or result['economics']['bankruptcy_halt'])
        receipt=dict(schema='FINITE2023_LEGACY_EXTENSION_CASE_RECEIPT_V1',
            status='NATIVE_ECONOMIC_HALT_UNPAID_PARTIAL' if economic_halt else 'COMPLETED_NATIVE_PATH',
            config=args.config,start_UTC=started,end_UTC=utc(),PID=os.getpid(),construction_seconds=construction,
            native_loop_seconds=loop_seconds,total_wall_seconds=time.monotonic()-began,
            max_RSS_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,
            CPU_seconds=resource.getrusage(resource.RUSAGE_SELF).ru_utime+resource.getrusage(resource.RUSAGE_SELF).ru_stime,
            limits=LIMITS,observed_output_bytes=own_bytes(out),completed_minutes=sim.rows_written,
            required_minutes=entry.MINUTES,calendar=[entry.START,entry.END],account_stop_us=sim.stop,
            paid_comparison_eligible=result['economics']['paid_flat'],root_GO_SHA256=args.go_sha,
            preparation_SHA256=sha(prep_raw),code_identity=entry.code_identity(),
            source_identity=prep['source_identity'],execution_binding_SHA256=prep['execution_binding_SHA256'],
            controller_reporting_identity=reporting_identity(),independent_review_SHA256=args.review_sha,
            actual_complete_calendar_days=risk['complete_calendar_days'],holdout_consumed=False,other_years_run=0)
        terminal=economic_terminal_record(receipt,compact) if economic_halt else None
        if terminal is None and not receipt['paid_comparison_eligible']:
            raise RuntimeError('UNKNOWN_INCOMPLETE_OR_RESIDUAL_PATH_NOT_RECOGNIZED_ECONOMIC_HALT')
        if terminal is not None:save(out/'ECONOMIC_TERMINAL.json',terminal)
        save(out/'CASE_RECEIPT.json',receipt)
        save(out/'TERMINAL_CHECKPOINT.json',dict(config=args.config,UTC=utc(),
            case_receipt_SHA256=sha((out/'CASE_RECEIPT.json').read_bytes()),
            result_SHA256=sha((out/'RESULT.json').read_bytes()),
            account_financial_audit_SHA256=sha((out/'ACCOUNT_FINANCIAL_AUDIT_SNAPSHOT.json').read_bytes()),
            observed_risk_SHA256=sha((out/'OBSERVED_RISK.json').read_bytes()),
            economic_terminal_SHA256=sha((out/'ECONOMIC_TERMINAL.json').read_bytes()) if terminal is not None else None,
            paid_comparison_eligible=receipt['paid_comparison_eligible'],completed_minutes=sim.rows_written,
            all_evidence_fsynced_before_checkpoint=True,
            retained_artifact_SHA256={name:sha((out/name).read_bytes()) for name in PRIMARY_ARTIFACTS}))
        if own_bytes(out)>LIMITS['output_bytes']:raise RuntimeError('OUTPUT_LIMIT_AFTER_TERMINAL_CHECKPOINT')
        print(json.dumps(dict(event='CASE_TERMINAL',config=args.config,UTC=utc(),status=receipt['status'])),flush=True)
    except BaseException as error:
        if 'sim' in locals():
            try:
                save(out/'FAILED_ACCOUNT_FINANCIAL_AUDIT_SNAPSHOT.json',sim.account.snapshot())
                save(out/'FAILED_GUARD_RECEIPTS.json',guard.receipts)
                save(out/'FAILED_PROGRESS.json',dict(completed_minutes=sim.rows_written,cursor_us=sim.cursor,
                    stop_us=sim.stop,policy_restart_certified=False))
            except BaseException as audit_error:
                save(out/'FAILED_PARTIAL_AUDIT_UNAVAILABLE.json',dict(error=repr(audit_error)))
        save(out/'CASE_FAILURE.json',dict(status='FAILED_NO_AUTOMATIC_RETRY',UTC=utc(),config=args.config,
            error=repr(error),traceback=traceback.format_exc(),wall_seconds=time.monotonic()-began))
        raise
    finally:stopped.set()


def controller(args):
    prep_raw=(Path(args.preparation)/'PREPARATION.json').read_bytes()
    go_raw=Path(args.go).read_bytes();review_raw=Path(args.review).read_bytes()
    go=validate_controller_go(prep_raw,go_raw,args.go_sha,review_raw,args.review_sha)
    out=Path(args.output);out.mkdir(exist_ok=False)
    write_bytes(out/'ROOT_GO.json',go_raw);write_bytes(out/'INDEPENDENT_REVIEW.json',review_raw)
    started=utc();began=time.monotonic();statuses=[]
    save(out/'CONTROLLER_START.json',dict(UTC=started,PID=os.getpid(),status='STARTED',
        permitted_configs=go['permitted_configs'],root_GO_SHA256=args.go_sha,limits=LIMITS))
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',
        MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',POLARS_MAX_THREADS='1')
    for config in go['permitted_configs']:
        command=[sys.executable,str(Path(__file__).resolve()),'--case','--source',str(Path(args.source).resolve()),
            '--preparation',str(Path(args.preparation).resolve()),'--go',str((out/'ROOT_GO.json').resolve()),
            '--go-sha',args.go_sha,'--review',str((out/'INDEPENDENT_REVIEW.json').resolve()),
            '--review-sha',args.review_sha,'--config',config,'--case-output',str((out/config).resolve())]
        with (out/(config+'.log')).open('x') as log:
            try:
                process=subprocess.Popen(command,cwd=HERE,env=env,stdout=log,stderr=subprocess.STDOUT,preexec_fn=limits)
                try:code=process.wait(timeout=600)
                except subprocess.TimeoutExpired:
                    process.kill();process.wait();code=124
                    save(out/(config+'_CONTROLLER_TIMEOUT.json'),dict(UTC=utc(),status='STOPPED_600S_WALL'))
            except BaseException as error:
                save(out/'CONTROLLER_FAILURE.json',dict(status='SPAWN_FAILED_NO_AUTOMATIC_RETRY',UTC=utc(),
                    config=config,error=repr(error),cases=statuses));raise
        statuses.append(dict(config=config,PID=process.pid,exit_code=code))
        if code:
            save(out/'CONTROLLER_FAILURE.json',dict(status='STOPPED_NO_AUTOMATIC_RERUN',UTC=utc(),cases=statuses))
            raise RuntimeError('Extension case failed; retained with no retry: '+config)
        try:
            kind=validate_saved_terminal(out/config,go,prep_raw,expected_go_sha256=args.go_sha,config=config)
        except BaseException as error:
            save(out/'CONTROLLER_FAILURE.json',dict(status='TERMINAL_EVIDENCE_FAILED_NO_AUTOMATIC_RETRY',UTC=utc(),
                error=repr(error),cases=statuses));raise
        statuses[-1]['terminal_classification']=kind
        save(out/('CASE_TERMINAL_'+config+'.json'),dict(UTC=utc(),config=config,classification=kind,
            receipt_SHA256=sha((out/config/'CASE_RECEIPT.json').read_bytes()),publication_approved=False))
        if kind=='NATIVE_ECONOMIC_HALT_UNPAID_PARTIAL' and not go['continue_after_recognized_economic_terminal']:
            save(out/'CONTROLLER_RECEIPT.json',dict(status='STOPPED_AFTER_RECOGNIZED_ECONOMIC_TERMINAL_AS_GO_REQUIRES',
                start_UTC=started,end_UTC=utc(),cases=statuses,remaining_configs=go['permitted_configs'][len(statuses):],
                root_GO_SHA256=args.go_sha,no_automatic_retry=True));return
    save(out/'CONTROLLER_RECEIPT.json',dict(status='ALL_APPROVED_EXTENSION_JOBS_TERMINAL',start_UTC=started,
        end_UTC=utc(),wall_seconds=time.monotonic()-began,cases=statuses,root_GO_SHA256=args.go_sha,
        requested_matrix_cells=6,approved_job_count=len(statuses),holdout_consumed=False,other_years_run=0,
        total_output_bytes=own_bytes(out),publication_approved=False))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--case',action='store_true')
    for name in ('source','preparation','go','go-sha','review','review-sha'):parser.add_argument('--'+name,required=True)
    for name in ('output','config','case-output'):parser.add_argument('--'+name)
    args=parser.parse_args();case(args) if args.case else controller(args)
