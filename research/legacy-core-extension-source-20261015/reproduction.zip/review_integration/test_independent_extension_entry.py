"""Independent source/entry/controller checks. Never construct an account.

All positive constructor tests replace the unchanged financial constructor with
an exception sentinel. Synthetic GO/review documents exist only in tests and do
not authorize a financial job.
"""
from copy import deepcopy
from functools import lru_cache
import hashlib
from io import BytesIO
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

import numpy as np
ROOT = Path(__file__).resolve().parent.parent
B = ROOT / 'legacy_core_extension_20261015'
SOURCE = ROOT / 'native_2023_source_restore_20261015'
P = B / 'source_2023_attempt001'

def sha(value): return hashlib.sha256(value).hexdigest()
def raw(value): return (json.dumps(value, sort_keys=True, allow_nan=False) + '\n').encode()

class IndependentSourceBinding(unittest.TestCase):
    def test_unchanged_complete_common_v3_snapshot(self):
        original = ROOT / 'traditional_three_tier_freeze_20261015'
        count = 0
        for path in (B/'common_v3').rglob('*'):
            if not path.is_file() or '__pycache__' in path.parts:
                continue
            other = original / path.relative_to(B/'common_v3')
            self.assertFalse(path.is_symlink())
            self.assertEqual(path.read_bytes(), other.read_bytes(), str(path))
            count += 1
        self.assertGreaterEqual(count, 29)

    def test_six_saved_target_configs_and_no_same_tier_current_reuse(self):
        prep = json.loads((P/'PREPARATION.json').read_bytes())
        comparison = json.loads((P/'CURRENT_DIFFERENCE_AND_EQUIVALENCE.json').read_bytes())
        self.assertEqual(len(prep['configs']), 6)
        self.assertEqual(prep['financial_accounts_created'], 0)
        self.assertEqual(prep['financial_runs'], 0)
        self.assertEqual(comparison['same_tier_exact_current_reuse_candidates'], [])
        self.assertFalse(comparison['financial_outcomes_read'])
        self.assertEqual(len(comparison['comparisons']), 6)
        self.assertTrue(all(not c['entire_target_path_byte_exact'] for c in comparison['comparisons']))
        self.assertEqual(len(prep['same_tier_exact_execution_groups']), 6)
        self.assertTrue(all(len(group)==1 for group in prep['same_tier_exact_execution_groups']))
        with np.load(BytesIO((P/'TARGETS.npz').read_bytes()), allow_pickle=False) as z:
            self.assertEqual(z['decision_us'].dtype, np.dtype('int64'))
            self.assertEqual(z['decision_us'].shape, (365,))
            for config in prep['configs']:
                self.assertEqual(z[config].dtype, np.dtype('float64'))
                self.assertEqual(z[config].shape, (365,5))
            mid='STATIC50_OLD_NO_REEXPANSION_MID'; high='STATIC50_OLD_NO_REEXPANSION_HIGH'
            self.assertEqual(z[mid].tobytes(), z[high].tobytes())
            self.assertFalse(any(mid in group and high in group for group in prep['same_tier_exact_execution_groups']))


sys.path.insert(0,str(B))
import extension_entry_2023 as entry
import prepare_2023 as preparation
import run_extension_2023 as driver

REVIEW_FLAGS = (
    'all365_original200_windows_verified', 'lower_only_original_intrinsic_targets_verified',
    'unchanged_common_V3_finance_verified', 'tier_identity_and_no_cross_tier_reuse_verified',
    'recognized_economic_HALT_is_partial_unpaid_not_annual', 'exact_root_GO_gate_verified')


def synthetic_authority(prep_raw, configs=None, continue_halt=False):
    """A generated in-memory gate fixture, never a production authorization."""
    p=json.loads(prep_raw)
    review=dict(schema=entry.REVIEW_SCHEMA,status=entry.REVIEW_STATUS,
        fixture_scope='GENERATED_GATE_TEST_ONLY_NOT_FINANCIAL_AUTHORIZATION',
        preparation_SHA256=sha(prep_raw),code_identity=p['code_identity'],
        source_identity=p['source_identity'],execution_binding_SHA256=p['execution_binding_SHA256'],
        artifacts=p['artifacts'],calendar=[entry.START,entry.END],configs=list(entry.CONFIGS),
        resource_limits=entry.LIMITS,pure_adapter_review_SHA256=p['pure_adapter_review_SHA256'],
        controller_reporting_identity=driver.reporting_identity(),
        economic_terminal_policy_version=driver.TERMINAL_POLICY_VERSION,
        financial_runs=0,locked_or_holdout_consumed=False,**dict.fromkeys(REVIEW_FLAGS,True))
    rb=raw(review)
    go=dict(schema='ROOT_GO_FINITE2023_LEGACY_CORE5_EXTENSION_V1',
        action='RUN_FRESH_APPROVED_2023_LEGACY_EXTENSION_JOBS_ONLY',
        fixture_scope='GENERATED_GATE_TEST_ONLY_NOT_FINANCIAL_AUTHORIZATION',
        preparation_SHA256=sha(prep_raw),calendar=[entry.START,entry.END],cost='BASE27',
        code_identity=p['code_identity'],source_identity=p['source_identity'],
        execution_binding_SHA256=p['execution_binding_SHA256'],resource_limits=entry.LIMITS,
        serial_execution=True,independent_review_SHA256=sha(rb),
        controller_reporting_identity=driver.reporting_identity(),other_years_authorized=False,
        locked_or_holdout_consumed=False,financial_policy_changes=False,
        prior_completed_cases=[],prior_economic_terminal_cases=[],
        continue_after_recognized_economic_terminal=continue_halt,
        permitted_configs=list(entry.CONFIGS if configs is None else configs),
        economic_terminal_policy_version=driver.TERMINAL_POLICY_VERSION)
    return raw(go),rb


def latest_preparation():
    candidates=sorted(B.glob('source_2023_attempt*/PREPARATION.json'))
    return candidates[-1].parent


class IndependentExtensionGates(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.directory=latest_preparation()
        cls.prep_raw=(cls.directory/'PREPARATION.json').read_bytes()
        cls.prep=json.loads(cls.prep_raw)
        if cls.prep['code_identity']!=entry.code_identity():
            raise unittest.SkipTest('Await final preparation bound to final reviewed executable bytes')
        cls.go_raw,cls.review_raw=synthetic_authority(cls.prep_raw)

    def validate(self,go=None,review=None,config=None):
        gb=self.go_raw if go is None else raw(go)
        rb=self.review_raw if review is None else raw(review)
        if review is not None:
            value=json.loads(gb);value['independent_review_SHA256']=sha(rb);gb=raw(value)
        return driver.validate_controller_go(self.prep_raw,gb,sha(gb),rb,sha(rb))

    def test_valid_six_job_gate_without_account_runtime(self):
        common,_,_=preparation._common()
        self.assertIsNone(common.n._RUNTIME)
        self.assertEqual(self.validate()['permitted_configs'],list(entry.CONFIGS))
        self.assertIsNone(common.n._RUNTIME)
        self.assertEqual(common.g.CONFIGS,tuple((s,t.name) for s in ('STATIC50','H090','VOL_MANAGED_HOLD') for t in common.g.TIERS))
        self.assertEqual(entry.MINUTES,365*1440)
        self.assertEqual(entry.LIMITS['maximum_cases'],6)

    def test_exact_code_and_reporting_identity_complete(self):
        for path,digest in entry.code_identity().items():
            self.assertEqual(sha((B/path).read_bytes()),digest,path)
        self.assertEqual(entry.controller_reporting_identity(),driver.reporting_identity())
        self.assertEqual(self.prep['pure_adapter_review_SHA256'],sha((B/'review_signal/REVIEW.json').read_bytes()))
        self.assertIn('extension_entry_2023.py',entry.code_identity())
        self.assertIn('run_extension_2023.py',entry.code_identity())
        self.assertIn('common_v3/annual_reporting.py',entry.code_identity())

    def test_go_rejects_changed_scope_hash_limits_duplicates_and_prior_year(self):
        base=json.loads(self.go_raw)
        mutations=[('calendar',[1704067200000000,1735689600000000]),('cost','STRESS43'),
            ('preparation_SHA256','0'*64),('code_identity',{}),('source_identity','0'*64),
            ('execution_binding_SHA256','0'*64),('resource_limits',dict(entry.LIMITS,maximum_cases=7)),
            ('permitted_configs',[entry.CONFIGS[0],entry.CONFIGS[0]]),
            ('permitted_configs',['STATIC50_MID']),('permitted_configs',[]),
            ('serial_execution',False),('other_years_authorized',True),('locked_or_holdout_consumed',True),
            ('financial_policy_changes',True),('prior_completed_cases',[{'config':'STATIC50_MID'}]),
            ('prior_economic_terminal_cases',[{'config':'STATIC50_MID'}]),
            ('continue_after_recognized_economic_terminal',1),('economic_terminal_policy_version','unreviewed')]
        for key,value in mutations:
            with self.subTest(key=key,value=value):
                bad=deepcopy(base);bad[key]=value
                with self.assertRaises((ValueError,KeyError,TypeError)):self.validate(go=bad)
        with self.assertRaises(ValueError):
            driver.validate_controller_go(self.prep_raw,self.go_raw,'0'*64,self.review_raw,sha(self.review_raw))
        with self.assertRaises(ValueError):
            driver.validate_controller_go(self.prep_raw,self.go_raw,sha(self.go_raw),self.review_raw,'0'*64)

    def test_missing_or_wrong_reporting_and_required_review_evidence_fail(self):
        for identity in (None,{}):
            go=json.loads(self.go_raw);review=json.loads(self.review_raw)
            if identity is None:
                go.pop('controller_reporting_identity');review.pop('controller_reporting_identity')
            else:go['controller_reporting_identity']=identity;review['controller_reporting_identity']=identity
            with self.assertRaises(ValueError):self.validate(go=go,review=review)
        base=json.loads(self.review_raw)
        for key in REVIEW_FLAGS+('pure_adapter_review_SHA256',):
            bad=deepcopy(base);bad.pop(key)
            with self.subTest(key=key),self.assertRaises((ValueError,KeyError)):self.validate(review=bad)

    def test_full_original_source_rebuild_stops_at_only_constructor_seam(self):
        common,_,_=preparation._common()
        class BoundaryReached(Exception):pass
        original_configs=common.g.CONFIGS
        with patch.object(common.n,'_construct_case',side_effect=BoundaryReached) as seam:
            with self.assertRaises(BoundaryReached):
                entry.make_extension_case(SOURCE,self.directory,self.go_raw,sha(self.go_raw),
                    config=entry.CONFIGS[2],review_raw=self.review_raw,expected_review_sha256=sha(self.review_raw))
        self.assertEqual(seam.call_count,1)
        args,kwargs=seam.call_args
        self.assertEqual(kwargs['tier_name'],'HIGH')
        self.assertEqual(kwargs['cost_name'],'BASE27')
        self.assertEqual(args[2].shape,(365,));self.assertEqual(args[3].shape,(365,5))
        self.assertEqual(args[0]['start'],entry.START);self.assertEqual(args[0]['end'],entry.END)
        # Consume only captured, original source blocks, with no simulator.
        blocks=list(args[0]['minute_blocks']())
        self.assertEqual(len(blocks),365)
        self.assertEqual(sum(len(b['times']) for b in blocks),525600)
        self.assertEqual(blocks[0]['times'][0],entry.START)
        self.assertEqual(blocks[-1]['times'][-1]+60_000_000,entry.END)
        self.assertTrue(all(not a.flags.writeable for b in blocks for f in b['market'].values() for a in f.values()))
        self.assertEqual(common.g.CONFIGS,original_configs)
        self.assertIsNone(common.n._RUNTIME)

    def test_static_alias_still_enters_distinct_mid_high_tiers_without_config_rebinding(self):
        from types import SimpleNamespace
        common,_,_=preparation._common()
        validated=entry.load_validated_targets(SOURCE,self.directory,self.go_raw,sha(self.go_raw),
            config=entry.CONFIGS[1],review_raw=self.review_raw,expected_review_sha256=sha(self.review_raw))
        def fake(*args,**kwargs):return SimpleNamespace(meta={}),SimpleNamespace(tier_name=kwargs['tier_name'])
        original=common.g.CONFIGS
        with patch.object(entry,'load_validated_targets',return_value=validated),\
                patch.object(common.n,'_construct_case',side_effect=fake) as seam:
            outputs=[]
            for key in entry.CONFIGS[1:3]:
                outputs.append(entry.make_extension_case(SOURCE,self.directory,self.go_raw,sha(self.go_raw),
                    config=key,review_raw=self.review_raw,expected_review_sha256=sha(self.review_raw)))
        self.assertEqual(seam.call_count,2)
        self.assertEqual([call.kwargs['tier_name'] for call in seam.call_args_list],['MID','HIGH'])
        self.assertEqual(seam.call_args_list[0].args[3].tobytes(),seam.call_args_list[1].args[3].tobytes())
        self.assertEqual([sim.meta['config'] for sim,guard in outputs],list(entry.CONFIGS[1:3]))
        self.assertTrue(all(sim.meta['common_execution_variant'] and not sim.meta['legacy_account_replication']
            for sim,guard in outputs))
        self.assertEqual(common.g.CONFIGS,original);self.assertIsNone(common.n._RUNTIME)

    def test_final_preparation_keeps_exact_reviewed_signal_artifacts(self):
        old=json.loads((P/'PREPARATION.json').read_bytes())
        self.assertEqual(self.prep['source_identity'],old['source_identity'])
        self.assertEqual(self.prep['execution_binding_SHA256'],old['execution_binding_SHA256'])
        self.assertEqual(self.prep['target_identity'],old['target_identity'])
        for name in ('TARGETS.npz','TARGET_PROOFS.json','CURRENT_DIFFERENCE_AND_EQUIVALENCE.json'):
            self.assertEqual((self.directory/name).read_bytes(),(P/name).read_bytes(),name)
            self.assertEqual(self.prep['artifacts'][name],old['artifacts'][name])

    def test_changed_preparation_at_final_seam_stops_before_constructor(self):
        common,_,_=preparation._common()
        validated=entry.load_validated_targets(SOURCE,self.directory,self.go_raw,sha(self.go_raw),
            config=entry.CONFIGS[0],review_raw=self.review_raw,expected_review_sha256=sha(self.review_raw))
        original_read=Path.read_bytes
        def changed(path):
            body=original_read(path)
            return body+b' ' if path.resolve()==(self.directory/'PREPARATION.json').resolve() else body
        with patch.object(entry,'load_validated_targets',return_value=validated),patch.object(Path,'read_bytes',changed),\
                patch.object(common.n,'_construct_case') as seam:
            with self.assertRaisesRegex(ValueError,'BOUND_PREPARATION_OR_CODE_CHANGED'):
                entry.make_extension_case(SOURCE,self.directory,self.go_raw,sha(self.go_raw),
                    config=entry.CONFIGS[0],review_raw=self.review_raw,expected_review_sha256=sha(self.review_raw))
            seam.assert_not_called()

    def test_changed_target_artifact_never_reaches_account_constructor(self):
        common,_,_=preparation._common()
        with tempfile.TemporaryDirectory() as temp:
            copied=Path(temp)
            for path in self.directory.iterdir():
                if path.is_file():(copied/path.name).write_bytes(path.read_bytes())
            target=copied/'TARGETS.npz';target.write_bytes(target.read_bytes()+b'x')
            with patch.object(common.n,'_construct_case') as seam:
                with self.assertRaisesRegex(ValueError,'EXACT_SOURCE_HASH_OR_SIZE_MISMATCH'):
                    entry.make_extension_case(SOURCE,copied,self.go_raw,sha(self.go_raw),
                        config=entry.CONFIGS[0],review_raw=self.review_raw,expected_review_sha256=sha(self.review_raw))
                seam.assert_not_called()


@lru_cache(maxsize=2)
def generated_minute_archive(completed):
    symbols=entry.adapter.SYMBOLS
    columns=['nav','free_cash','isolated_balance','gross_notional','net_signed_notional',
        'cumulative_fees','cumulative_execution_costs','cumulative_funding','cumulative_turnover',
        *[s+'_quantity' for s in symbols],*[s+'_signed_marked_notional' for s in symbols],
        *[s+'_isolated_balance' for s in symbols],*[s+'_isolated_equity' for s in symbols],
        *[s+'_signed_weight' for s in symbols],'gross_weight','net_signed_weight','close_us']
    values=np.zeros((completed,len(columns)),dtype=np.float64);values[:,0:2]=10000.
    values[:,-1]=np.arange(entry.START+60_000_000,entry.START+(completed+1)*60_000_000,
        60_000_000,dtype=np.int64)
    stream=BytesIO();np.savez_compressed(stream,values=values,columns=np.asarray(columns))
    return stream.getvalue()


def saved_fixture(directory, *, paid=True):
    """Entirely fictional flat or isolated-HALT metadata, not an account run."""
    pp=(latest_preparation()/'PREPARATION.json').read_bytes();p=json.loads(pp)
    gb,rb=synthetic_authority(pp);go=json.loads(gb);key=entry.CONFIGS[0]
    stop=None if paid else entry.START+10*60_000_000
    clock=entry.END if paid else stop
    completed=entry.MINUTES if paid else 9
    positions={symbol:dict(quantity=0,entry_price=0,isolated_balance=0,opened_us=None)
        for symbol in entry.adapter.SYMBOLS}
    witness=None
    if not paid:
        positions['BTCUSDT']=dict(quantity=1,entry_price=99,isolated_balance=2,opened_us=entry.START+60_000_001)
        witness=dict(event_us=stop,symbol='BTCUSDT',isolated_equity='1',maintenance_margin='2',
            mark_price='100',quantity='1',NAV='10000',unpaid_liability='0')
    status='ACTIVE' if paid else 'LIQUIDATION_REQUIRED_HALT'
    summary=dict(account_status=status,clock_us=clock,halt_witness=witness,positions=positions,
        completed_minutes=completed,required_minutes=entry.MINUTES,stop_us=stop,
        completion='COMPLETE_CONDITIONAL_ACCOUNT' if paid else 'NOT_EVALUABLE_ACCOUNT_HALT_NO_LIQUIDATION_SIMULATED',
        NAV=10000,unpaid_liability=0,terminal_marked_notional=0 if paid else 100,terminal_cash_realized=paid)
    economics=dict(calendar=[entry.START,entry.END],full_calendar=paid,paid_flat=paid,
        paid_net_return=0.0 if paid else None,marked_net_return=0.0,
        liquidation_required_halt=not paid,bankruptcy_halt=False,actual_liquidation_fills=0,
        liquidation_fill_model='NOT_IMPLEMENTED_NATIVE_ACCOUNT_STOPS_WITH_WITNESS',
        residual_marked_notional='0' if paid else '100',unpaid_liability='0',
        all_observation_max_drawdown=0.0,fees_USDT='0',execution_cost_USDT='0',funding_USDT='0')
    account=dict(status=status,clock_us=clock,halt_witness=witness,
        positions={s:{k:str(v) if k!='opened_us' else v for k,v in pos.items()} for s,pos in positions.items()},
        free_cash='10000',unpaid_liability='0')
    r=dict(schema='FINITE2023_LEGACY_EXTENSION_CASE_RECEIPT_V1',
        status='COMPLETED_NATIVE_PATH' if paid else 'NATIVE_ECONOMIC_HALT_UNPAID_PARTIAL',
        config=key,root_GO_SHA256=sha(gb),preparation_SHA256=sha(pp),code_identity=p['code_identity'],
        source_identity=p['source_identity'],execution_binding_SHA256=p['execution_binding_SHA256'],
        controller_reporting_identity=driver.reporting_identity(),independent_review_SHA256=sha(rb),
        limits=entry.LIMITS,calendar=[entry.START,entry.END],required_minutes=entry.MINUTES,
        completed_minutes=completed,account_stop_us=stop,paid_comparison_eligible=paid,
        actual_complete_calendar_days=365 if paid else 0)
    result=dict(config=key,summary=summary,economics=economics,common_execution_policy={},target_meta={})
    values={'CASE_RECEIPT.json':r,'RESULT.json':result,'ACCOUNT_FINANCIAL_AUDIT_SNAPSHOT.json':account,
        'OBSERVED_RISK.json':dict(complete_calendar_days=365 if paid else 0,observation_count=completed),
        'GUARD_RECEIPTS.json':[],'NATIVE_REJECTIONS.json':[],'FUNDING_JOURNAL.json':[]}
    if not paid:values['ECONOMIC_TERMINAL.json']=driver.economic_terminal_record(r,result)
    for name,value in values.items():(directory/name).write_bytes(raw(value))
    (directory/'MINUTE.npz').write_bytes(generated_minute_archive(completed))
    checkpoint=dict(config=key,case_receipt_SHA256=sha((directory/'CASE_RECEIPT.json').read_bytes()),
        result_SHA256=sha((directory/'RESULT.json').read_bytes()),
        account_financial_audit_SHA256=sha((directory/'ACCOUNT_FINANCIAL_AUDIT_SNAPSHOT.json').read_bytes()),
        observed_risk_SHA256=sha((directory/'OBSERVED_RISK.json').read_bytes()),
        economic_terminal_SHA256=sha((directory/'ECONOMIC_TERMINAL.json').read_bytes()) if not paid else None,
        completed_minutes=completed,paid_comparison_eligible=paid,all_evidence_fsynced_before_checkpoint=True,
        retained_artifact_SHA256={name:sha((directory/name).read_bytes()) for name in
            ('MINUTE.npz','GUARD_RECEIPTS.json','NATIVE_REJECTIONS.json','FUNDING_JOURNAL.json')})
    (directory/'TERMINAL_CHECKPOINT.json').write_bytes(raw(checkpoint))
    return pp,go,sha(gb),key


def rewrite_generated_evidence(directory,name,change):
    value=json.loads((directory/name).read_bytes());change(value);(directory/name).write_bytes(raw(value))
    checkpoint=json.loads((directory/'TERMINAL_CHECKPOINT.json').read_bytes())
    field={'CASE_RECEIPT.json':'case_receipt_SHA256','RESULT.json':'result_SHA256',
        'ACCOUNT_FINANCIAL_AUDIT_SNAPSHOT.json':'account_financial_audit_SHA256',
        'OBSERVED_RISK.json':'observed_risk_SHA256'}[name]
    checkpoint[field]=sha((directory/name).read_bytes())
    (directory/'TERMINAL_CHECKPOINT.json').write_bytes(raw(checkpoint))


class IndependentTerminalEvidence(unittest.TestCase):
    def check_saved(self,directory,authority):
        pp,go,gs,key=authority
        return driver.validate_saved_terminal(directory,go,pp,expected_go_sha256=gs,config=key)

    def test_generated_paid_and_economic_partial_are_distinct(self):
        for paid,expected in [(True,'PAID_FULL_YEAR'),(False,'NATIVE_ECONOMIC_HALT_UNPAID_PARTIAL')]:
            with self.subTest(paid=paid),tempfile.TemporaryDirectory() as temp:
                d=Path(temp);authority=saved_fixture(d,paid=paid)
                self.assertEqual(self.check_saved(d,authority),expected)
                if not paid:
                    record=json.loads((d/'ECONOMIC_TERMINAL.json').read_bytes())
                    self.assertIsNone(record['annual_paid_net_return']);self.assertIsNone(record['annual_APR'])
                    self.assertFalse(record['paid_comparison_eligible']);self.assertFalse(record['financial_policy_changed'])
                    self.assertFalse(record['automatic_retry_authorized'])

    def test_paid_flags_cannot_promote_halt_debt_inventory_or_partial_calendar(self):
        mutations=[
            ('ACCOUNT_FINANCIAL_AUDIT_SNAPSHOT.json',lambda v:v.update(unpaid_liability='1')),
            ('ACCOUNT_FINANCIAL_AUDIT_SNAPSHOT.json',lambda v:v.update(free_cash='9999')),
            ('RESULT.json',lambda v:v['summary'].update(completion='NOT_EVALUABLE_ACCOUNT_HALT_NO_LIQUIDATION_SIMULATED')),
            ('RESULT.json',lambda v:v['economics'].update(residual_marked_notional='1')),
            ('RESULT.json',lambda v:v['economics'].update(calendar=[1704067200000000,1735689600000000])),
            ('RESULT.json',lambda v:v['economics'].update(paid_net_return=None)),
            ('RESULT.json',lambda v:v['economics'].update(paid_net_return=.1)),
            ('OBSERVED_RISK.json',lambda v:v.update(complete_calendar_days=364)),
            ('OBSERVED_RISK.json',lambda v:v.update(observation_count=entry.MINUTES-1))]
        for name,mutation in mutations:
            with self.subTest(file=name,mutation=mutation),tempfile.TemporaryDirectory() as temp:
                d=Path(temp);authority=saved_fixture(d,paid=True)
                rewrite_generated_evidence(d,name,mutation)
                with self.assertRaises((ValueError,KeyError,TypeError)):self.check_saved(d,authority)
        with tempfile.TemporaryDirectory() as temp:
            d=Path(temp);authority=saved_fixture(d,paid=True)
            rewrite_generated_evidence(d,'ACCOUNT_FINANCIAL_AUDIT_SNAPSHOT.json',
                lambda v:v.update(status='LIQUIDATION_REQUIRED_HALT',halt_witness={'event_us':entry.END}))
            rewrite_generated_evidence(d,'RESULT.json',lambda v:v['summary'].update(
                account_status='LIQUIDATION_REQUIRED_HALT',halt_witness={'event_us':entry.END}))
            with self.assertRaises((ValueError,KeyError)):self.check_saved(d,authority)

    def test_economic_classifier_rejects_wrong_year_minute_count_and_non_native_predicate(self):
        with tempfile.TemporaryDirectory() as temp:
            d=Path(temp);saved_fixture(d,paid=False)
            r=json.loads((d/'CASE_RECEIPT.json').read_bytes());result=json.loads((d/'RESULT.json').read_bytes())
            for key,value in [('calendar',[1704067200000000,1735689600000000]),('completed_minutes',10),
                ('paid_comparison_eligible',True),('required_minutes',527040)]:
                bad=deepcopy(r);bad[key]=value
                with self.subTest(key=key),self.assertRaises(ValueError):driver.economic_terminal_record(bad,result)
            for key,value in [('isolated_equity','3'),('maintenance_margin','-1'),('quantity','0'),('mark_price','0'),('NAV','NaN')]:
                bad=deepcopy(result);bad['summary']['halt_witness'][key]=value
                with self.subTest(witness=key),self.assertRaises(ValueError):driver.economic_terminal_record(r,bad)

    def test_checkpoint_hash_and_primary_evidence_cannot_disappear(self):
        with tempfile.TemporaryDirectory() as temp:
            d=Path(temp);authority=saved_fixture(d,paid=True)
            (d/'RESULT.json').write_bytes((d/'RESULT.json').read_bytes()+b' ')
            with self.assertRaises(ValueError):self.check_saved(d,authority)
        for name in ('MINUTE.npz','GUARD_RECEIPTS.json','NATIVE_REJECTIONS.json','FUNDING_JOURNAL.json'):
            with self.subTest(name=name),tempfile.TemporaryDirectory() as temp:
                d=Path(temp);authority=saved_fixture(d,paid=True);(d/name).unlink()
                with self.assertRaises((ValueError,FileNotFoundError,KeyError)):self.check_saved(d,authority)

    def test_self_consistent_primary_hash_cannot_hide_wrong_clocks_shape_or_journal_type(self):
        for corruption in ('clock','rowcount','journal'):
            with self.subTest(corruption=corruption),tempfile.TemporaryDirectory() as temp:
                d=Path(temp);authority=saved_fixture(d,paid=False)
                checkpoint=json.loads((d/'TERMINAL_CHECKPOINT.json').read_bytes())
                if corruption=='journal':
                    name='GUARD_RECEIPTS.json';(d/name).write_bytes(raw({'wrong':'object'}))
                else:
                    name='MINUTE.npz'
                    with np.load(BytesIO((d/name).read_bytes()),allow_pickle=False) as z:
                        values=z['values'].copy();columns=z['columns'].copy()
                    if corruption=='clock':values[0,-1]+=60_000_000
                    else:values=values[:-1]
                    np.savez_compressed(d/name,values=values,columns=columns)
                checkpoint['retained_artifact_SHA256'][name]=sha((d/name).read_bytes())
                (d/'TERMINAL_CHECKPOINT.json').write_bytes(raw(checkpoint))
                with self.assertRaises(ValueError):self.check_saved(d,authority)

    def test_atomic_evidence_writer_cannot_overwrite_or_adopt_partial(self):
        with tempfile.TemporaryDirectory() as temp:
            d=Path(temp);target=d/'EVIDENCE.json';driver.write_bytes(target,b'first')
            with self.assertRaises(FileExistsError):driver.write_bytes(target,b'second')
            self.assertEqual(target.read_bytes(),b'first')
            target=d/'OTHER.json';partial=d/'OTHER.json.partial';partial.write_bytes(b'old partial')
            with self.assertRaises(FileExistsError):driver.write_bytes(target,b'fresh')
            self.assertFalse(target.exists());self.assertEqual(partial.read_bytes(),b'old partial')


class IndependentQueuePolicy(unittest.TestCase):
    def run_mock_queue(self, *, continue_halt=False, exit_code=0, invalid_evidence=False, timeout=False):
        from types import SimpleNamespace
        from subprocess import TimeoutExpired
        temporary=tempfile.TemporaryDirectory();base=Path(temporary.name)
        p=latest_preparation();prep_raw=(p/'PREPARATION.json').read_bytes()
        configs=[entry.CONFIGS[0],entry.CONFIGS[1]]
        gb,rb=synthetic_authority(prep_raw,configs,continue_halt)
        (base/'go.json').write_bytes(gb);(base/'review.json').write_bytes(rb)
        args=SimpleNamespace(preparation=str(p),go=str(base/'go.json'),review=str(base/'review.json'),
            go_sha=sha(gb),review_sha=sha(rb),source=str(SOURCE),output=str(base/'output'))
        events=[]
        class FakeProcess:
            pid=12345
            def __init__(self,command,**kwargs):
                self.command=command;self.calls=0
                key=command[command.index('--config')+1];events.append(('spawn',key))
                target=Path(command[command.index('--case-output')+1]);target.mkdir()
                (target/'CASE_RECEIPT.json').write_bytes(raw({'fixture':True,'config':key}))
            def wait(self,timeout=None):
                self.calls+=1;events.append(('wait',self.command[self.command.index('--config')+1]))
                if timeout is not None and globals_timeout:raise TimeoutExpired(self.command,timeout)
                return exit_code
            def kill(self):events.append(('kill',self.command[self.command.index('--config')+1]))
        globals_timeout=timeout
        evidence=ValueError('FICTIONAL_TERMINAL_EVIDENCE_FAILURE') if invalid_evidence else 'NATIVE_ECONOMIC_HALT_UNPAID_PARTIAL'
        try:
            with patch.object(driver,'validate_controller_go',return_value=json.loads(gb)),\
                    patch.object(driver.subprocess,'Popen',side_effect=FakeProcess) as spawn,\
                    patch.object(driver,'validate_saved_terminal',side_effect=evidence if invalid_evidence else None,
                        return_value=None if invalid_evidence else evidence):
                raised=None
                try:driver.controller(args)
                except (RuntimeError,ValueError) as error:raised=error
                out=base/'output'
                data={f.name:json.loads(f.read_bytes()) for f in out.glob('*.json')}
                return temporary,events,spawn.call_count,data,raised
        except BaseException:
            temporary.cleanup();raise

    def test_economic_halt_stops_queue_when_go_requires(self):
        temp,events,calls,data,raised=self.run_mock_queue(continue_halt=False)
        try:
            self.assertIsNone(raised);self.assertEqual(calls,1)
            self.assertEqual(data['CONTROLLER_RECEIPT.json']['remaining_configs'],[entry.CONFIGS[1]])
            self.assertEqual(data['CONTROLLER_RECEIPT.json']['status'],'STOPPED_AFTER_RECOGNIZED_ECONOMIC_TERMINAL_AS_GO_REQUIRES')
        finally:temp.cleanup()

    def test_explicit_economic_queue_permission_advances_distinct_jobs_serially(self):
        temp,events,calls,data,raised=self.run_mock_queue(continue_halt=True)
        try:
            self.assertIsNone(raised);self.assertEqual(calls,2)
            self.assertEqual([kind for kind,_ in events],['spawn','wait','spawn','wait'])
            self.assertEqual([key for kind,key in events if kind=='spawn'],list(entry.CONFIGS[:2]))
            self.assertEqual(data['CONTROLLER_RECEIPT.json']['status'],'ALL_APPROVED_EXTENSION_JOBS_TERMINAL')
            self.assertFalse(data['CONTROLLER_RECEIPT.json']['publication_approved'])
        finally:temp.cleanup()

    def test_technical_exit_unknown_evidence_and_timeout_stop_without_retry(self):
        for options in (dict(exit_code=1),dict(invalid_evidence=True),dict(timeout=True)):
            temp,events,calls,data,raised=self.run_mock_queue(continue_halt=True,**options)
            try:
                self.assertIsNotNone(raised);self.assertEqual(calls,1)
                self.assertIn('CONTROLLER_FAILURE.json',data)
                self.assertNotIn('CONTROLLER_RECEIPT.json',data)
                if options.get('timeout'):self.assertIn(('kill',entry.CONFIGS[0]),events)
            finally:temp.cleanup()

if __name__ == '__main__': unittest.main(verbosity=2)
