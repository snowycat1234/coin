# Independent legacy signal adapter review

Result: PASS WITH LIMITATIONS, frozen legacy_core_adapter.py, its exact sources and original source_2023_attempt001 target/proof preparation only.

- 28/28 generated tests and 6/6 independent review checks passed.
- Exact two strategies, six LOWER_ONLY risk paths and eight-file public-source closure verified. STATIC uses .5 CS_MATCHED + .5 VOL_MATCHED with no final scale. HOLD is canonical VOL_MATCHED.
- All 365 target/covariance bytes and proof JSON independently rebuilt from pinned local 2023 source closes. Full-five original 200-close and explicit finite-SMA projection checked; future and missing-data causality tests pass.
- Common V3 execution-core hashes equal their frozen/saved-current identities. No production edits, financial account/run/outcome read, network request, source download, holdout, denied-2025 path access or publication was performed.
- No same-tier saved-current reuse candidate exists. STATIC MID/HIGH are byte-identical targets but cross-tier execution reuse remains forbidden. HOLD MID/HIGH differ in ULP-scale downward adjustments.

The preparation wrapper is being extended after attempt001. Its historical hash is retained as evidence, but wrapper, entry, driver, root-GO and attempt002 integration changes are outside this review.

No blocking source-adapter issue found. This receipt does not approve an execution entry or financial run. The 2023 inputs are seen development data, use completed-boundary proxy availability, and do not certify provider arrival/completeness or funding units. Target ceilings alone are not realized-risk matching or persistent-inventory invariants.

The first independent HOLD reference used an algebraically equivalent contiguous slice; its ULP failure is retained. Preserving the original advanced-indexing layout made the independent original-formula check byte-exact without changing production code.

Detailed hashes, cohorts, comparisons and qualifications: REVIEW.json. Logs: GENERATED_RERUN.log and INDEPENDENT_RERUN.log.
