"""Independent review checks. Reads only local source/target/proof inputs."""
import hashlib
import json
from pathlib import Path
import sys
import unittest

import numpy as np

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))
import legacy_core_adapter as a

PREP = HERE/'source_2023_attempt001'
SOURCE = HERE.parent/'native_2023_source_restore_20261015'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def original_inputs():
    manifest = json.loads((PREP/'PREPARATION.json').read_bytes())
    path = SOURCE/'SOURCE_WARMUP_CLOSE_ONLY.npz'
    raw = path.read_bytes()
    assert sha(raw) == manifest['warmup_SHA256']
    with np.load(path, allow_pickle=False) as z:
        assert set(z.files) == {'close_available_us','close'}
        return z['close'].copy(), z['close_available_us'].copy()


class IndependentReview(unittest.TestCase):
    def test_preparation_artifact_and_code_hashes(self):
        prep = json.loads((PREP/'PREPARATION.json').read_bytes())
        for name,rec in prep['artifacts'].items():
            raw = (PREP/name).read_bytes()
            self.assertEqual(sha(raw),rec['SHA256'])
            self.assertEqual(len(raw),rec['bytes'])
        for name in ('legacy_core_adapter.py','SOURCE_PINS.json','SAVED_CURRENT_PINS.json'):
            self.assertEqual(sha((HERE/name).read_bytes()),prep['code_identity'][name])
        # prepare_2023.py snapshot hash is historical attempt001 evidence only.
        # Entry/driver integration now being developed is outside this review.
        for name, digest in prep['execution_binding']['common_V3_code'].items():
            self.assertEqual(sha((HERE/'common_v3'/name).read_bytes()),digest)
        binding=prep['execution_binding']
        self.assertEqual(sha(json.dumps(binding,sort_keys=True,separators=(',',':'),allow_nan=False).encode()),prep['execution_binding_SHA256'])

    def test_rebuild365_exact_targets_covariance_and_proofs_from_pinned_closes(self):
        p,t=original_inputs()
        d=np.arange(1672531200000000,1704067200000000,a.DAY,dtype=np.int64)
        outd,x,c,proof=a.build_target_grid(p,t,t,d)
        with np.load(PREP/'TARGETS.npz',allow_pickle=False) as z:
            self.assertEqual(set(z.files),set(x)|{'decision_us','annual_covariance'})
            self.assertEqual(outd.tobytes(),z['decision_us'].tobytes())
            self.assertEqual(c.tobytes(),z['annual_covariance'].tobytes())
            for key in x:self.assertEqual(x[key].tobytes(),z[key].tobytes())
        self.assertEqual(proof,json.loads((PREP/'TARGET_PROOFS.json').read_bytes()))
        self.assertEqual(a.target_identities(d,x),json.loads((PREP/'PREPARATION.json').read_bytes())['target_identity'])

    def test_independent_original_hold_and_static_formulas365(self):
        p,t=original_inputs()
        proof=json.loads((PREP/'TARGET_PROOFS.json').read_bytes())
        d=np.array([r['decision_us'] for r in proof],np.int64)
        # Build original HOLD independently from signed_intents projection and
        # then call canonical original match, with explicit all-five admission.
        o=a.originals();hold=[]
        for k in np.searchsorted(t,d):
            window=p[k-199:k+1]
            self.assertTrue(np.isfinite(window).all() and (window>0).all())
            # Preserve canonical advanced column-indexing memory layout as well
            # as arithmetic; np.cov reduction order can otherwise differ in ULPs.
            columns=np.flatnonzero(np.all(np.isfinite(window)&(window>0),axis=0))
            past=p[k-30:k+1,columns]
            hold.append(o.signed_risk_weights((.6/len(columns))*np.ones(len(columns)),np.diff(past,axis=0)/past[:-1])[0])
        original,mp,_,diag=o.match(t,p,d,np.array(hold),np.ones((365,5),bool))
        for i,row in enumerate(proof):
            self.assertEqual(row['intrinsic'][a.STRATEGIES[1]],original['VOL_MATCHED'][i].tolist())
            self.assertEqual(row['intrinsic'][a.STRATEGIES[0]],(.5*original['CS_MATCHED'][i]+.5*original['VOL_MATCHED'][i]).tolist())
            self.assertEqual(row['source_match'],mp[i])
            self.assertEqual(row['oldest_completed_close_us'],row['decision_us']-199*a.DAY)
            self.assertEqual(row['last_completed_close_us'],row['decision_us'])
            self.assertEqual(row['completed_close_count'],200)
            self.assertEqual(row['HOLD_200_finite_mask'],[True]*5)
            self.assertEqual(row['CS_current_eligible'],[True]*5)
            self.assertLessEqual(row['CS_weekly_rank_us'],row['decision_us'])
            self.assertLess(row['decision_us']-row['CS_weekly_rank_us'],7*a.DAY)

    def test_all365_lower_only_independent_formula_and_limits(self):
        proof=json.loads((PREP/'TARGET_PROOFS.json').read_bytes())
        with np.load(PREP/'TARGETS.npz',allow_pickle=False) as z:
            cov=z['annual_covariance']
            for strategy,tiername in a.CONFIGS:
                key=strategy+'_'+tiername;tier=a.tier_named(tiername)
                for i,row in enumerate(proof):
                    w=np.array(row['intrinsic'][strategy]);c=cov[i]
                    sigma=float(np.sqrt(max(0.,w@c@w)))
                    factors=[1.,tier.gross_cap/np.abs(w).sum(),tier.asset_cap/np.abs(w).max()]
                    if sigma>0:factors.append(tier.annual_vol_ceiling/sigma)
                    factor=min(factors)
                    expected=w.copy() if factor==1. else w*factor
                    self.assertEqual(expected.tobytes(),z[key][i].tobytes())
                    self.assertEqual(factor,row['tiers'][key]['factor'])
                    self.assertLessEqual(factor,1.)
                    self.assertTrue((np.abs(z[key][i])<=np.abs(w)+1e-15).all())
                    self.assertLessEqual(np.abs(z[key][i]).sum(),tier.gross_cap+1e-12)
                    self.assertLessEqual(np.abs(z[key][i]).max(),tier.asset_cap+1e-12)
                    self.assertLessEqual(np.sqrt(max(0.,z[key][i]@c@z[key][i])),tier.annual_vol_ceiling+1e-12)

    def test_same_tier_saved_comparisons_are_recomputable_and_no_reuse(self):
        cmp=json.loads((PREP/'CURRENT_DIFFERENCE_AND_EQUIVALENCE.json').read_bytes())
        prep=json.loads((PREP/'PREPARATION.json').read_bytes())
        savedprep=json.loads((HERE/'saved_current2023/PREPARATION.json').read_bytes())
        self.assertEqual(prep['source_identity'],savedprep['source_identity'])
        self.assertEqual(prep['calendar'],savedprep['calendar'])
        self.assertEqual(prep['cost'],savedprep['cost'])
        with np.load(PREP/'TARGETS.npz',allow_pickle=False) as z, np.load(HERE/'saved_current2023/TARGETS.npz',allow_pickle=False) as s:
            self.assertEqual(z['decision_us'].tobytes(),s['decision_us'].tobytes())
            self.assertEqual(z['annual_covariance'].tobytes(),s['annual_covariance'].tobytes())
            for row in cmp['comparisons']:
                left,right=z[row['config']],s[row['current_comparator']]
                self.assertEqual(left.tobytes()==right.tobytes(),row['entire_target_path_byte_exact'])
                self.assertEqual(int(np.count_nonzero(left!=right)),row['different_float64_cells'])
                dates=np.any(left!=right,axis=1)
                self.assertEqual(z['decision_us'][dates].tolist(),row['different_decision_us'])
                self.assertEqual(int(dates.sum()),row['different_decision_dates'])
                self.assertEqual(float(np.abs(left-right).max()),row['maximum_absolute_target_difference'])
                self.assertEqual(sha(left.tobytes()),row['left_raw_SHA256'])
                self.assertEqual(sha(right.tobytes()),row['right_raw_SHA256'])
            candidates=[]
            for key in prep['configs']:
                tier=key.rsplit('_',1)[1]
                for current in savedprep['configs']:
                    if current.endswith('_'+tier) and z[key].tobytes()==s[current].tobytes():candidates.append((key,current))
            self.assertEqual(candidates,[])
            self.assertEqual(cmp['same_tier_exact_current_reuse_candidates'],[])

    def test_prefix_equivalence_and_explicit_alltrue_gate(self):
        p,t=original_inputs()
        d=np.arange(1672531200000000,1672531200000000+40*a.DAY,a.DAY,dtype=np.int64)
        _,x,c,proof=a.build_target_grid(p,t,t,d)
        _,y,cc,pf=a.build_target_grid(p,t,t,d,sma_finite_mask=np.ones(p.shape,bool))
        for key in x:self.assertEqual(x[key].tobytes(),y[key].tobytes())
        self.assertEqual(c.tobytes(),cc.tobytes());self.assertEqual(proof,pf)
        fullproof=json.loads((PREP/'TARGET_PROOFS.json').read_bytes())
        self.assertEqual(proof,fullproof[:len(d)])
        with np.load(PREP/'TARGETS.npz',allow_pickle=False) as z:
            for key in x:self.assertEqual(x[key].tobytes(),z[key][:len(d)].tobytes())


if __name__=='__main__':unittest.main(verbosity=2)
