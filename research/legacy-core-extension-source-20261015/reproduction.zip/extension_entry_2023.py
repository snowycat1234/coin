"""Separate source/review/GO-bound constructor for six finite 2023 extension jobs.

No account is created on import or validation. Targets never masquerade as a
current-core strategy. The unchanged V3 native runtime receives explicit new
version metadata and the reviewed tier; no configuration monkeypatch is used.
"""
from __future__ import annotations
from io import BytesIO
import json
from pathlib import Path
import numpy as np
import legacy_core_adapter as adapter
import prepare_2023 as preparation

HERE=Path(__file__).resolve().parent
START,END=preparation.START,preparation.END
MINUTES=525600
CONFIGS=tuple(strategy+'_'+tier for strategy,tier in adapter.CONFIGS)
LIMITS={'per_case_wall_seconds':600,'CPU_threads':1,'RSS_stop_bytes':2000000000,
    'AS_bytes':4000000000,'output_bytes':250000000,'maximum_cases':6}
REVIEW_SCHEMA='INDEPENDENT_FINITE2023_LEGACY_EXTENSION_REVIEW_V1'
REVIEW_STATUS='PASS_SOURCE_AND_GENERATED_GATES_NO_FINANCIAL_RUN'


def code_identity():
    return preparation.code_identity()


def controller_reporting_identity():
    return {'run_extension_2023.py':preparation.sha((HERE/'run_extension_2023.py').read_bytes()),
        'common_v3/annual_reporting.py':preparation.sha((HERE/'common_v3/annual_reporting.py').read_bytes()),
        'TERMINAL_POLICY_PROVENANCE.json':preparation.sha((HERE/'TERMINAL_POLICY_PROVENANCE.json').read_bytes())}

def validate_root_go(preparation_raw,go_raw,expected_go_sha256,*,config,review_raw,expected_review_sha256):
    if (not isinstance(go_raw,bytes) or preparation.sha(go_raw)!=expected_go_sha256
            or not isinstance(review_raw,bytes) or preparation.sha(review_raw)!=expected_review_sha256):
        raise ValueError('EXACT_EXTERNAL_EXTENSION_ROOT_GO_AND_REVIEW_BYTES_REQUIRED')
    prep,go,review=(json.loads(raw) for raw in (preparation_raw,go_raw,review_raw))
    allowed=go.get('permitted_configs')
    if (prep.get('schema')!='FIXED2023_TWO_LEGACY_CORE5_SIX_PATH_SOURCE_ONLY_V1'
            or prep.get('calendar')!=[START,END] or prep.get('configs')!=list(CONFIGS)
            or prep.get('resource_limits')!=LIMITS or prep.get('cost')!='BASE27'
            or prep.get('risk_adapter')!='LOWER_ONLY_AFTER_EXACT_INTRINSIC_NO_REEXPANSION'
            or prep.get('code_identity')!=code_identity()
            or go.get('schema')!='ROOT_GO_FINITE2023_LEGACY_CORE5_EXTENSION_V1'
            or go.get('action')!='RUN_FRESH_APPROVED_2023_LEGACY_EXTENSION_JOBS_ONLY'
            or go.get('preparation_SHA256')!=preparation.sha(preparation_raw)
            or go.get('calendar')!=[START,END] or go.get('cost')!='BASE27'
            or go.get('code_identity')!=prep['code_identity']
            or go.get('source_identity')!=prep['source_identity']
            or go.get('execution_binding_SHA256')!=prep['execution_binding_SHA256']
            or go.get('resource_limits')!=LIMITS or go.get('serial_execution') is not True
            or go.get('independent_review_SHA256')!=expected_review_sha256
            or go.get('controller_reporting_identity')!=controller_reporting_identity()
            or go.get('other_years_authorized') is not False
            or go.get('locked_or_holdout_consumed') is not False
            or go.get('financial_policy_changes') is not False
            or go.get('prior_completed_cases',[])!=[]
            or go.get('prior_economic_terminal_cases',[])!=[]
            or type(go.get('continue_after_recognized_economic_terminal')) is not bool
            or not isinstance(allowed,list) or not 0<len(allowed)<=6
            or len(set(allowed))!=len(allowed) or any(key not in CONFIGS for key in allowed)
            or config not in allowed):
        raise ValueError('EXACT_FINITE2023_NEW_VERSION_SIX_JOB_ROOT_SCOPE_REQUIRED')
    if (review.get('schema')!=REVIEW_SCHEMA or review.get('status')!=REVIEW_STATUS
            or review.get('preparation_SHA256')!=preparation.sha(preparation_raw)
            or review.get('code_identity')!=prep['code_identity']
            or review.get('source_identity')!=prep['source_identity']
            or review.get('execution_binding_SHA256')!=prep['execution_binding_SHA256']
            or review.get('artifacts')!=prep['artifacts']
            or review.get('calendar')!=[START,END] or review.get('configs')!=list(CONFIGS)
            or review.get('resource_limits')!=LIMITS
            or review.get('pure_adapter_review_SHA256')!=prep['pure_adapter_review_SHA256']
            or review.get('controller_reporting_identity')!=go.get('controller_reporting_identity')
            or review.get('all365_original200_windows_verified') is not True
            or review.get('lower_only_original_intrinsic_targets_verified') is not True
            or review.get('unchanged_common_V3_finance_verified') is not True
            or review.get('tier_identity_and_no_cross_tier_reuse_verified') is not True
            or review.get('recognized_economic_HALT_is_partial_unpaid_not_annual') is not True
            or review.get('exact_root_GO_gate_verified') is not True
            or review.get('financial_runs')!=0 or review.get('locked_or_holdout_consumed') is not False):
        raise ValueError('EXACT_INDEPENDENT_FINITE2023_SOURCE_ENTRY_DRIVER_REVIEW_REQUIRED')
    return prep


def load_validated_targets(source_root,preparation_directory,go_raw,expected_go_sha256,*,
        config,review_raw,expected_review_sha256):
    """All scope/review/code/source/target checks precede any account creation."""
    directory=Path(preparation_directory)
    prep_raw=(directory/'PREPARATION.json').read_bytes()
    prep=validate_root_go(prep_raw,go_raw,expected_go_sha256,config=config,
        review_raw=review_raw,expected_review_sha256=expected_review_sha256)
    common,_,common_identity=preparation._common()
    for name,record in prep['artifacts'].items():
        common.h._read_exact(directory/name,record['SHA256'],record['bytes'])
    index,files,t,p,rows,quality,payloads,months=common._source(source_root)
    if (files!=prep['source_files'] or quality!=prep['original200_quality']
            or common._source_identity(files,quality)!=prep['source_identity']
            or common_identity!=prep['execution_binding']['common_V3_code']):
        raise ValueError('EXACT_EXTENSION_SOURCE_AND_COMMON_EXECUTION_IDENTITY_REQUIRED')
    target_record=prep['artifacts']['TARGETS.npz']
    raw=common.h._read_exact(directory/'TARGETS.npz',target_record['SHA256'],target_record['bytes'])
    with np.load(BytesIO(raw),allow_pickle=False) as z:
        if set(z.files)!=set(CONFIGS)|{'decision_us','annual_covariance'}:
            raise ValueError('EXACT_SIX_EXTENSION_TARGET_ARCHIVE_KEYS_REQUIRED')
        d=z['decision_us'].copy();c=z['annual_covariance'].copy()
        targets={key:z[key].copy() for key in CONFIGS}
    if (d.dtype!=np.dtype('int64') or not np.array_equal(d,np.arange(START,END,adapter.DAY,dtype=np.int64))
            or c.dtype!=np.dtype('float64') or c.shape!=(365,5,5)
            or any(w.dtype!=np.dtype('float64') or w.shape!=(365,5) for w in targets.values())):
        raise ValueError('EXACT365_EXTENSION_TARGET_DTYPE_SHAPE_CALENDAR_REQUIRED')
    rebuilt_d,rebuilt,rebuilt_c,_=adapter.build_target_grid(p,t,t.copy(),d)
    if (rebuilt_d.tobytes()!=d.tobytes() or rebuilt_c.tobytes()!=c.tobytes()
            or any(rebuilt[key].tobytes()!=targets[key].tobytes() for key in CONFIGS)
            or adapter.target_identities(d,targets)!=prep['target_identity']
            or preparation.sha(c.tobytes())!=prep['execution_binding']['covariance_raw_SHA256']
            or preparation.json_sha(prep['execution_binding'])!=prep['execution_binding_SHA256']):
        raise ValueError('EXACT_ORIGINAL_REBUILT_EXTENSION_TARGET_AND_COVARIANCE_BYTES_REQUIRED')
    comparison=preparation._compare_current(d,targets,c,prep['source_identity'],common_identity)
    if json.loads((directory/'CURRENT_DIFFERENCE_AND_EQUIVALENCE.json').read_bytes())!=comparison:
        raise ValueError('EXACT_SAVED_CURRENT2023_DIFFERENCE_COHORT_REQUIRED')
    return prep,common,index,rows,payloads,months,d,c,targets


def make_extension_case(source_root,preparation_directory,go_raw,expected_go_sha256,*,
        config,review_raw,expected_review_sha256):
    result=load_validated_targets(source_root,preparation_directory,go_raw,expected_go_sha256,
        config=config,review_raw=review_raw,expected_review_sha256=expected_review_sha256)
    prep,common,index,rows,payloads,months,d,c,targets=result
    def blocks():
        expected=START
        for record in index['months']:
            with np.load(BytesIO(months[record['month']]),allow_pickle=False) as z:
                stamps=z['times'].copy()
                if (stamps.dtype!=np.dtype('int64') or len(stamps)!=record['minutes']
                        or not np.array_equal(stamps,np.arange(expected,expected+len(stamps)*common.n.MINUTE,
                            common.n.MINUTE,dtype=np.int64))):
                    raise ValueError('EXACT_CAPTURED_2023_MONTH_MINUTE_CALENDAR_REQUIRED')
                market={symbol:{key:z[symbol+'_'+key].copy() for key in ('open','close','quote_volume','mark')}
                    for symbol in adapter.SYMBOLS}
                for fields in market.values():
                    for key,values in fields.items():
                        if (values.dtype!=np.dtype('float64') or values.shape!=stamps.shape
                                or not np.isfinite(values).all()
                                or ((values<0).any() if key=='quote_volume' else (values<=0).any())):
                            raise ValueError('EXACT_FINITE_ACTUAL_2023_MONTH_FIELDS_REQUIRED')
                        values.setflags(write=False)
            for offset in range(0,len(stamps),1440):
                yield {'times':stamps[offset:offset+1440],'market':{
                    symbol:{key:values[offset:offset+1440] for key,values in fields.items()}
                    for symbol,fields in market.items()}}
            expected+=len(stamps)*common.n.MINUTE
        if expected!=END:raise ValueError('EXACT_FULL2023_EXTENSION_PROVIDER_END_REQUIRED')
    window={'start':START,'end':END,'symbols':adapter.SYMBOLS,
        'daily':common.pl.DataFrame(json.loads(payloads['DAILY.json'])),
        'events':json.loads(payloads['EVENTS.json']),'minute_blocks':blocks}
    strategy,tier=next((strategy,tier) for strategy,tier in adapter.CONFIGS if strategy+'_'+tier==config)
    # Recheck mutable executable/preparation files immediately before the sole
    # account seam. Captured original source bytes are already immutable.
    bound_preparation=(Path(preparation_directory)/'PREPARATION.json').read_bytes()
    if preparation.sha(bound_preparation)!=json.loads(go_raw)['preparation_SHA256'] or code_identity()!=prep['code_identity']:
        raise ValueError('BOUND_PREPARATION_OR_CODE_CHANGED_BEFORE_ACCOUNT_CONSTRUCTION')
    preparation._common()  # Reverify the complete unchanged public native closure.
    # All validations above are complete. This is the sole real-account seam.
    sim,guard=common.n._construct_case(window,rows,d,targets[config],tier_name=tier,
        cost_name='BASE27',source_scope='ROOT_ADMITTED_FINITE_SEEN2023_LEGACY_SIGNAL_COMMON_EXECUTION_VARIANT')
    sim.meta.update(grid_version=adapter.VERSION,signal_version=strategy,config=config,
        legacy_account_replication=False,common_execution_variant=True,
        risk_adapter='LOWER_ONLY_AFTER_EXACT_INTRINSIC_NO_REEXPANSION',
        source_identity=prep['source_identity'],execution_binding_SHA256=prep['execution_binding_SHA256'],
        target_identity=prep['target_identity']['SHA256_by_config'][config],
        preparation_SHA256=preparation.sha(bound_preparation),
        root_GO_SHA256=expected_go_sha256,independent_review_SHA256=expected_review_sha256,
        unchanged_common_execution_version=common.n.VERSION,requested_matrix_cells=6,
        riskmatched_excess_method='NOT_PREREGISTERED_NOT_CLAIMED')
    return sim,guard
