"""Fictional saved-terminal tests only: no native account or financial loop."""
from copy import deepcopy
from decimal import Decimal
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import numpy as np
from io import BytesIO
import extension_entry_2023 as e
import prepare_2023 as p
import run_extension_2023 as driver
from test_extension_entry import fixture,raw


def evidence(paid=False,halt='LIQUIDATION_REQUIRED_HALT'):
    prep,go,_=fixture();config=e.CONFIGS[0]
    stop=e.START+100*60000000+1
    positions={symbol:dict(quantity=0.,entry_price=0.,isolated_balance=0.,opened_us=None,
        decimal_strings={'quantity':'0','entry_price':'0','isolated_balance':'0'}) for symbol in e.adapter.SYMBOLS}
    if not paid:positions['BTCUSDT']=dict(quantity=1.,entry_price=100.,isolated_balance=30.,opened_us=e.START,
        decimal_strings={'quantity':'1','entry_price':'100','isolated_balance':'30'})
    witness=None if paid else dict(event_us=stop,phase='MARK',symbol='BTCUSDT',isolated_equity=.01,
        maintenance_margin=1.,mark_price=100.,quantity=1.,NAV=1000.,unpaid_liability=0.,
        decimal_strings={'isolated_equity':'.01','maintenance_margin':'1','mark_price':'100',
            'quantity':'1','NAV':'1000','unpaid_liability':'0'})
    if not paid and halt=='BANKRUPT_HALT':witness['isolated_equity']=0;witness['decimal_strings']['isolated_equity']='0'
    minutes=e.MINUTES if paid else 100
    summary=dict(account_status='ACTIVE' if paid else halt,clock_us=e.END if paid else stop,
        halt_witness=witness,completed_minutes=minutes,required_minutes=e.MINUTES,stop_us=None if paid else stop,
        completion='COMPLETE_CONDITIONAL_ACCOUNT' if paid else 'NOT_EVALUABLE_ACCOUNT_HALT_NO_LIQUIDATION_SIMULATED',
        positions=positions,NAV=10000. if paid else 1000.,unpaid_liability=0.,terminal_marked_notional=0. if paid else 100.,
        terminal_cash_realized=paid,decimal_strings={'NAV':'10000' if paid else '1000','unpaid_liability':'0'})
    economics=dict(calendar=[e.START,e.END],paid_flat=paid,full_calendar=paid,paid_net_return=0. if paid else None,
        marked_net_return=0. if paid else -.9,liquidation_required_halt=not paid and halt=='LIQUIDATION_REQUIRED_HALT',
        bankruptcy_halt=not paid and halt=='BANKRUPT_HALT',actual_liquidation_fills=0,
        liquidation_fill_model='NOT_IMPLEMENTED_NATIVE_ACCOUNT_STOPS_WITH_WITNESS',
        residual_marked_notional=0. if paid else 100.,unpaid_liability='0',all_observation_max_drawdown=.1,
        fees_USDT='1',execution_cost_USDT='1',funding_USDT='0')
    account=dict(status=summary['account_status'],clock_us=summary['clock_us'],halt_witness=witness,
        positions={symbol:{key:(str(pos[key]) if key in ('quantity','entry_price','isolated_balance') else pos[key])
            for key in ('quantity','entry_price','isolated_balance','opened_us')} for symbol,pos in positions.items()},
        unpaid_liability='0',free_cash='10000' if paid else '970')
    receipt=dict(schema='FINITE2023_LEGACY_EXTENSION_CASE_RECEIPT_V1',config=config,
        status='COMPLETED_NATIVE_PATH' if paid else 'NATIVE_ECONOMIC_HALT_UNPAID_PARTIAL',
        root_GO_SHA256='a'*64,preparation_SHA256=p.sha(raw(prep)),code_identity=prep['code_identity'],
        source_identity=prep['source_identity'],execution_binding_SHA256=prep['execution_binding_SHA256'],
        controller_reporting_identity=driver.reporting_identity(),independent_review_SHA256=go['independent_review_SHA256'],
        limits=driver.LIMITS,calendar=[e.START,e.END],required_minutes=e.MINUTES,completed_minutes=minutes,
        actual_complete_calendar_days=365 if paid else 0,paid_comparison_eligible=paid,account_stop_us=None if paid else stop)
    result=dict(config=config,summary=summary,economics=economics)
    risk=dict(complete_calendar_days=365 if paid else 0,observation_count=minutes)
    return prep,go,receipt,result,account,risk


def save_evidence(directory,items):
    prep,go,receipt,result,account,risk=items
    files={'CASE_RECEIPT.json':raw(receipt),'RESULT.json':raw(result),
        'ACCOUNT_FINANCIAL_AUDIT_SNAPSHOT.json':raw(account),'OBSERVED_RISK.json':raw(risk)}
    files.update({name:raw([]) for name in driver.PRIMARY_ARTIFACTS[1:]})
    # Fictional rows, never financial simulation. The primary-file validator is
    # independently tested below; other tests isolate terminal-state predicates.
    files['MINUTE.npz']=b'FICTIONAL_MINUTE_NOT_AN_ACCOUNT_OUTPUT'
    if not receipt['paid_comparison_eligible']:
        files['ECONOMIC_TERMINAL.json']=raw(driver.economic_terminal_record(receipt,result))
    checkpoint=dict(case_receipt_SHA256=p.sha(files['CASE_RECEIPT.json']),result_SHA256=p.sha(files['RESULT.json']),
        observed_risk_SHA256=p.sha(files['OBSERVED_RISK.json']),
        account_financial_audit_SHA256=p.sha(files['ACCOUNT_FINANCIAL_AUDIT_SNAPSHOT.json']),
        completed_minutes=receipt['completed_minutes'],paid_comparison_eligible=receipt['paid_comparison_eligible'],
        all_evidence_fsynced_before_checkpoint=True,
        economic_terminal_SHA256=p.sha(files['ECONOMIC_TERMINAL.json']) if 'ECONOMIC_TERMINAL.json' in files else None,
        retained_artifact_SHA256={name:p.sha(files[name]) for name in driver.PRIMARY_ARTIFACTS})
    files['TERMINAL_CHECKPOINT.json']=raw(checkpoint)
    for name,body in files.items():(Path(directory)/name).write_bytes(body)
    with patch.object(driver,'validate_primary_evidence'):
        return driver.validate_saved_terminal(directory,go,raw(prep),expected_go_sha256='a'*64,config=receipt['config'])


class TerminalTests(unittest.TestCase):
    def test_liquidation_halt_is_retained_partial_unpaid(self):
        values=evidence();terminal=driver.economic_terminal_record(values[2],values[3])
        self.assertIsNone(terminal['annual_paid_net_return']);self.assertIsNone(terminal['annual_APR'])
        self.assertEqual(terminal['retained_positions']['BTCUSDT']['quantity'],1)
        with tempfile.TemporaryDirectory() as directory:
            self.assertEqual(save_evidence(directory,values),'NATIVE_ECONOMIC_HALT_UNPAID_PARTIAL')

    def test_bankrupt_is_retained_not_simulated_liquidation(self):
        values=evidence(halt='BANKRUPT_HALT')
        terminal=driver.economic_terminal_record(values[2],values[3])
        self.assertEqual(terminal['account_status'],'BANKRUPT_HALT')
        self.assertEqual(terminal['actual_liquidation_fills'],0)

    def test_global_bankruptcy_without_symbol_is_valid_only_for_bankrupt(self):
        values=evidence(halt='BANKRUPT_HALT');w=values[3]['summary']['halt_witness'];w.pop('symbol');w['NAV']=-1;w['decimal_strings']['NAV']='-1'
        driver.economic_terminal_record(values[2],values[3])
        values[3]['economics']['bankruptcy_halt']=False;values[3]['economics']['liquidation_required_halt']=True
        values[3]['summary']['account_status']='LIQUIDATION_REQUIRED_HALT'
        with self.assertRaises(ValueError):driver.economic_terminal_record(values[2],values[3])

    def test_exact_decimal_witness_takes_priority_over_rounded_float(self):
        values=evidence();w=values[3]['summary']['halt_witness'];w['isolated_equity']=0.;w['decimal_strings']['isolated_equity']='1e-400'
        driver.economic_terminal_record(values[2],values[3])

    def test_unknown_incomplete_state_year_and_predicates_rejected(self):
        changes=[('calendar',[1704067200000000,1735689600000000]),('paid_comparison_eligible',True),
            ('account_stop_us',None),('completed_minutes',99)]
        for key,value in changes:
            values=evidence();values[2][key]=value
            with self.assertRaises((ValueError,TypeError)):driver.economic_terminal_record(values[2],values[3])
        values=evidence();values[3]['summary']['halt_witness']['decimal_strings']['isolated_equity']='2'
        with self.assertRaises(ValueError):driver.economic_terminal_record(values[2],values[3])

    def test_valid_paid_state_requires_fullyear_active_flat_and_exact_nav_return(self):
        with tempfile.TemporaryDirectory() as directory:
            self.assertEqual(save_evidence(directory,evidence(paid=True)),'PAID_FULL_YEAR')

    def test_paid_flags_cannot_mask_halt_debt_retained_positions_or_bad_return(self):
        modifications=[lambda v:v[3]['economics'].__setitem__('unpaid_liability','1'),
            lambda v:v[3]['economics'].__setitem__('residual_marked_notional',1),
            lambda v:v[3]['economics'].__setitem__('paid_net_return',.1),
            lambda v:v[3]['economics'].__setitem__('paid_net_return',float('inf')),
            lambda v:v[3]['summary'].__setitem__('completion','UNKNOWN'),
            lambda v:v[3]['summary'].__setitem__('completed_minutes',100),
            lambda v:v[5].__setitem__('complete_calendar_days',364),
            lambda v:v[4].__setitem__('free_cash','9999')]
        for modify in modifications:
            values=evidence(paid=True);modify(values)
            with tempfile.TemporaryDirectory() as directory:
                with self.assertRaises(ValueError):save_evidence(directory,values)
        values=evidence(paid=True)
        values[3]['summary']['account_status']=values[4]['status']='LIQUIDATION_REQUIRED_HALT'
        values[3]['summary']['halt_witness']=values[4]['halt_witness']={'event_us':e.END}
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaises(ValueError):save_evidence(directory,values)
        values=evidence(paid=True)
        values[3]['summary']['positions']['BTCUSDT']['quantity']=1.
        values[3]['summary']['positions']['BTCUSDT']['decimal_strings']['quantity']='1'
        values[4]['positions']['BTCUSDT']['quantity']='1'
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaises(ValueError):save_evidence(directory,values)


    def test_primary_files_hash_minute_rows_and_clock_are_verified(self):
        values=evidence();receipt=values[2]
        with tempfile.TemporaryDirectory() as directory:
            save_evidence(directory,values);root=Path(directory)
            symbols=e.adapter.SYMBOLS
            columns=['nav','free_cash','isolated_balance','gross_notional','net_signed_notional','cumulative_fees',
                'cumulative_execution_costs','cumulative_funding','cumulative_turnover',
                *[s+'_quantity' for s in symbols],*[s+'_signed_marked_notional' for s in symbols],
                *[s+'_isolated_balance' for s in symbols],*[s+'_isolated_equity' for s in symbols],
                *[s+'_signed_weight' for s in symbols],'gross_weight','net_signed_weight','close_us']
            data=np.zeros((receipt['completed_minutes'],len(columns)),dtype=np.float64)
            data[:,0]=10000;data[:,-1]=np.arange(e.START+60000000,e.START+(len(data)+1)*60000000,60000000,dtype=np.int64)
            def install():
                np.savez_compressed(root/'MINUTE.npz',values=data,columns=np.asarray(columns))
                return {'retained_artifact_SHA256':{name:p.sha((root/name).read_bytes()) for name in driver.PRIMARY_ARTIFACTS}}
            checkpoint=install();driver.validate_primary_evidence(root,checkpoint,receipt)
            for name in driver.PRIMARY_ARTIFACTS:
                original=(root/name).read_bytes();(root/name).write_bytes(original+b' ')
                with self.assertRaises(ValueError):driver.validate_primary_evidence(root,checkpoint,receipt)
                (root/name).write_bytes(original)
            data[0,-1]+=1;checkpoint=install()
            with self.assertRaisesRegex(ValueError,'CALENDAR'):driver.validate_primary_evidence(root,checkpoint,receipt)
            data=data[:-1];checkpoint=install()
            with self.assertRaisesRegex(ValueError,'CALENDAR'):driver.validate_primary_evidence(root,checkpoint,receipt)

    def test_corrupt_snapshot_or_checkpoint_cannot_advance_queue(self):
        with tempfile.TemporaryDirectory() as directory:
            values=evidence();save_evidence(directory,values)
            path=Path(directory)/'ACCOUNT_FINANCIAL_AUDIT_SNAPSHOT.json';path.write_bytes(path.read_bytes()+b' ')
            with self.assertRaises(ValueError):driver.validate_saved_terminal(directory,values[1],raw(values[0]),expected_go_sha256='a'*64,config=e.CONFIGS[0])

if __name__=='__main__':unittest.main()
