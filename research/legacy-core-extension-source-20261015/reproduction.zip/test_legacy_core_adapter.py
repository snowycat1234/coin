"""Generated-only target/source tests. No account, outcome or market data reads."""
import ast
import hashlib
import json
from pathlib import Path
import shutil
import tempfile
import unittest
import numpy as np
import legacy_core_adapter as a


def fixture(n=265):
    t=(19000+np.arange(n,dtype=np.int64))*a.DAY
    rng=np.random.default_rng(441209)
    changes=rng.normal(0,.007,(n,5))+np.array([.002,.001,-.0015,-.0007,.0003])
    p=100*np.exp(np.cumsum(changes,axis=0))
    return p,t,t[205:255].copy()


class SourceTests(unittest.TestCase):
    def test_exact_eight_file_six_reference_closure(self):
        pins=a.verify_sources()
        self.assertEqual(len(pins),8)
        refs=json.loads((a.HERE/'sources/ORIGINAL_REFERENCE.json').read_bytes())
        self.assertEqual(len(refs),6)
        self.assertTrue(callable(a.originals().match))
        self.assertTrue(callable(a.originals().signed_intents))

    def test_reference_mutation_fails_closed(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            shutil.copy2(a.HERE/'SOURCE_PINS.json',root/'SOURCE_PINS.json')
            shutil.copytree(a.HERE/'sources',root/'sources')
            path=root/'sources/reference/match_core.py'
            path.write_bytes(path.read_bytes()+b'\n')
            with self.assertRaisesRegex(ValueError,'BYTES_CHANGED'):
                a.verify_sources(root)

    def test_manifest_mutation_fails_closed(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            (root/'SOURCE_PINS.json').write_bytes((a.HERE/'SOURCE_PINS.json').read_bytes()+b' ')
            with self.assertRaisesRegex(ValueError,'CLOSURE'):
                a.verify_sources(root)

    def test_loader_selects_no_outcome_or_fitting_function(self):
        o=a.originals()
        self.assertEqual(set(vars(o)),{'require','symbol_order','signed_risk_weights','market_neutral',
            'public_targets','signed_intents','match','scale','allocate'})

    def test_no_financial_runner_or_account_constructor(self):
        for name in ('legacy_core_adapter.py','prepare_2023.py'):
            tree=ast.parse((a.HERE/name).read_text())
            for node in ast.walk(tree):
                if isinstance(node,ast.Call):
                    call=node.func
                    label=call.attr if isinstance(call,ast.Attribute) else call.id if isinstance(call,ast.Name) else ''
                    self.assertNotIn(label,('_construct_case','make_account','make_annual_case','run'))

    def test_exact_six_configurations(self):
        self.assertEqual(len(a.CONFIGS),6)
        self.assertEqual(len(set(a.CONFIGS)),6)
        self.assertEqual([(t.gross_cap,t.annual_vol_ceiling,t.asset_cap) for t in a.TIERS],
            [(.3,.05,.3),(.6,.1,.3),(.9,.15,.3)])


class RiskTests(unittest.TestCase):
    def test_no_reexpansion_below_all_ceilings(self):
        w=np.array([.02,.03,-.01,0,.02]);c=np.eye(5)*.01
        for t in a.TIERS:
            out,proof=a.lower_only(w,c,t.name)
            self.assertEqual(out.tobytes(),w.tobytes())
            self.assertEqual(proof['factor'],1.)
            self.assertFalse(proof['reexpanded'])

    def test_low_gross_shrink_only(self):
        w=np.full(5,.12);out,proof=a.lower_only(w,np.eye(5)*.0001,'LOW')
        np.testing.assert_array_equal(out,w*.5)
        self.assertEqual(proof['factor'],.5)

    def test_high_does_not_request_higher_intrinsic_risk(self):
        w=np.full(5,.08);c=np.eye(5)*.01
        out,proof=a.lower_only(w,c,'HIGH')
        np.testing.assert_array_equal(out,w)
        self.assertGreater(proof['shortfall'],0)

    def test_volatility_ceiling_shrinks_uniformly(self):
        w=np.array([.15,.12,-.14,-.1,.09]);c=np.eye(5)*2
        for tier in a.TIERS:
            out,proof=a.lower_only(w,c,tier.name)
            self.assertLess(proof['factor'],1)
            np.testing.assert_array_equal(out,w*proof['factor'])
            self.assertLessEqual(np.sqrt(out@c@out),tier.annual_vol_ceiling+1e-12)
            np.testing.assert_array_equal(np.sign(out),np.sign(w))

    def test_intrinsic_cash_is_preserved(self):
        for tier in a.TIERS:
            out,proof=a.lower_only(np.zeros(5),np.zeros((5,5)),tier.name)
            np.testing.assert_array_equal(out,0)
            self.assertEqual(proof['binding'],['INTRINSIC_CASH'])

    def test_singular_psd_nonzero_intent_is_not_reexpanded(self):
        w=np.array([.15,-.15,0,0,0]);c=np.ones((5,5))
        out,proof=a.lower_only(w,c,'MID')
        np.testing.assert_array_equal(out,w)
        self.assertEqual(proof['raw_sigma'],0.)

    def test_bad_covariance_rejected(self):
        bad=[-np.eye(5),np.zeros((4,4)),np.full((5,5),np.nan)]
        nonsymmetric=np.eye(5);nonsymmetric[0,1]=.01;bad.append(nonsymmetric)
        for c in bad:
            with self.assertRaises(ValueError):a.lower_only(np.full(5,.1),c,'MID')

    def test_bad_intent_and_unknown_tier_rejected(self):
        for w in (np.full(5,.2),np.ones(4),np.array([.31,0,0,0,0]),np.full(5,np.nan)):
            with self.assertRaises(ValueError):a.lower_only(w,np.eye(5),'MID')
        with self.assertRaises(ValueError):a.lower_only(np.zeros(5),np.eye(5),'CUSTOM')

    def test_no_mutation(self):
        w=np.full(5,.12);c=np.eye(5);wc=w.copy();cc=c.copy()
        a.lower_only(w,c,'LOW')
        np.testing.assert_array_equal(w,wc);np.testing.assert_array_equal(c,cc)


class FormulaAndCausalityTests(unittest.TestCase):
    def test_all_six_paths_exact_original_match_equations(self):
        p,t,d=fixture();outd,targets,cov,proofs=a.build_target_grid(p,t,t,d)
        o=a.originals();end=int(np.searchsorted(t,d[-1]))+1
        gate=np.full((end,5),np.nan);gate[199:]=1.
        original=o.signed_intents(p[:end],gate,t[:end],a.SYMBOLS)
        ids=np.searchsorted(t,d)
        components,mp,_,diag=o.match(t[:end],p[:end],d,original[ids,2,:],np.ones((len(d),5),bool))
        for i,k in enumerate(ids):
            r=np.diff(p[k-30:k+1],axis=0)/p[k-30:k]
            np.testing.assert_array_equal(cov[i],np.cov(r,rowvar=False,ddof=1)*365)
            old=.5*components['CS_MATCHED'][i]+.5*components['VOL_MATCHED'][i]
            np.testing.assert_array_equal(proofs[i]['intrinsic'][a.STRATEGIES[0]],old)
            np.testing.assert_array_equal(proofs[i]['intrinsic'][a.STRATEGIES[1]],components['VOL_MATCHED'][i])
            self.assertEqual(proofs[i]['source_match'],mp[i])
            self.assertTrue(all(proofs[i]['HOLD_200_finite_mask']))
            self.assertEqual(proofs[i]['CS_weekly_rank_us'],diag['rank_us'][i])
            for strategy,tier in a.CONFIGS:
                intrinsic=old if strategy==a.STRATEGIES[0] else components['VOL_MATCHED'][i]
                expected,_=a.lower_only(intrinsic,cov[i],tier)
                np.testing.assert_array_equal(targets[strategy+'_'+tier][i],expected)
        np.testing.assert_array_equal(outd,d)

    def test_old_static_is_distinct_from_later_risk_retarget(self):
        p,t,d=fixture();_,targets,cov,proofs=a.build_target_grid(p,t,t,d)
        old=np.array([r['intrinsic'][a.STRATEGIES[0]] for r in proofs])
        retarget=np.stack([a.originals().scale(w,c)[0] for w,c in zip(old,cov)])
        self.assertTrue(np.any(old!=retarget))
        np.testing.assert_array_equal(targets[a.STRATEGIES[0]+'_HIGH'],old)
        self.assertTrue(np.any(targets[a.STRATEGIES[0]+'_HIGH']!=retarget))

    def test_matched_hold_is_not_original_or_retargeted_hold(self):
        p,t,d=fixture();_,targets,cov,proofs=a.build_target_grid(p,t,t,d)
        matched=np.array([r['intrinsic'][a.STRATEGIES[1]] for r in proofs])
        hold=[]
        for k in np.searchsorted(t,d):
            r=np.diff(p[k-30:k+1],axis=0)/p[k-30:k]
            hold.append(a.originals().signed_risk_weights(np.full(5,.12),r)[0])
        self.assertTrue(np.any(matched!=hold))
        np.testing.assert_array_equal(targets[a.STRATEGIES[1]+'_HIGH'],matched)

    def test_future_perturbation_does_not_change_past_targets_or_proofs(self):
        p,t,d=fixture();d1,x,c,pf=a.build_target_grid(p,t,t,d)
        future=p.copy();cut=235;future[cut:]*=np.exp(np.linspace(.1,2,len(future)-cut))[:,None]
        d2,y,cc,pff=a.build_target_grid(future,t,t,d)
        keep=d<t[cut]
        for key in x:np.testing.assert_array_equal(x[key][keep],y[key][keep])
        np.testing.assert_array_equal(c[keep],cc[keep])
        self.assertEqual(pf[:sum(keep)],pff[:sum(keep)])
        self.assertTrue(any(np.any(x[k][~keep]!=y[k][~keep]) for k in x))

    def test_irrelevant_future_suffix_is_ignored(self):
        p,t,d=fixture();d=d[:10];_,x,c,pf=a.build_target_grid(p,t,t,d)
        p[np.searchsorted(t,d[-1])+1:]=np.nan
        _,y,cc,pff=a.build_target_grid(p,t,t,d)
        for key in x:np.testing.assert_array_equal(x[key],y[key])
        np.testing.assert_array_equal(c,cc);self.assertEqual(pf,pff)

    def test_constant_prices_preserve_exact_original_zero_common_semantics(self):
        p,t,d=fixture();p[:]=100
        _,targets,cov,proofs=a.build_target_grid(p,t,t,d)
        for value in targets.values():np.testing.assert_array_equal(value,0)
        self.assertTrue(all(r['source_match']['common_sigma']==0 for r in proofs))
        np.testing.assert_array_equal(cov,0)

    def test_original200_mask_rejects_hole_outside_cs31_window(self):
        p,t,d=fixture();p[20,1]=np.nan
        with self.assertRaisesRegex(ValueError,'200_CLOSE'):
            a.build_target_grid(p,t,t,d)

    def test_explicit_sma_finite_mask_preserved_and_rejected_when_unready(self):
        p,t,d=fixture();mask=np.ones(p.shape,bool);mask[205,2]=False
        with self.assertRaisesRegex(ValueError,'SMA_FINITE'):
            a.build_target_grid(p,t,t,d,sma_finite_mask=mask)
        with self.assertRaisesRegex(ValueError,'BOOLEAN'):
            a.build_target_grid(p,t,t,d,sma_finite_mask=mask.astype(int))

    def test_readiness_not_relaxed_to_cs31_or_match64(self):
        p,t,d=fixture()
        for k in (31,63,198):
            with self.assertRaisesRegex(ValueError,'200_COMPLETED'):
                a.build_target_grid(p,t,t,t[k:k+2])

    def test_symbol_availability_shape_and_clock_fail_closed(self):
        p,t,d=fixture()
        bad=[(p,t,t,d,{'symbols':a.SYMBOLS[::-1]}),(p[:,:4],t,t,d,{}),
            (p,t,t+a.DAY,d,{}),(p,t.astype(float),t,d,{}),
            (p,t,t,d[::2],{}),(p,t,t,d.astype(bool),{})]
        for prices,clocks,available,decisions,kwargs in bad:
            with self.assertRaises(ValueError):a.build_target_grid(prices,clocks,available,decisions,**kwargs)

    def test_intrinsic_mask_and_shapes(self):
        p,t,d=fixture();_,targets,c,proofs=a.build_target_grid(p,t,t,d)
        self.assertEqual(c.shape,(len(d),5,5));self.assertEqual(len(proofs),len(d))
        for key,value in targets.items():self.assertEqual(value.shape,(len(d),5))
        for proof in proofs:
            for info in proof['tiers'].values():self.assertLessEqual(info['factor'],1.)

    def test_target_hash_is_exact_and_cross_tier_alias_is_not_execution_go(self):
        p,t,d=fixture();_,targets,_,_=a.build_target_grid(p,t,t,d)
        identity=a.target_identities(d,targets)
        self.assertFalse(identity['execution_reuse_authorized'])
        self.assertFalse(identity['independent_alpha_families_claimed'])
        changed={key:value.copy() for key,value in targets.items()}
        key=next(iter(changed));changed[key][0,0]=np.nextafter(changed[key][0,0],np.inf)
        nextid=a.target_identities(d,changed)
        self.assertNotEqual(identity['SHA256_by_config'][key],nextid['SHA256_by_config'][key])

    def test_no_input_mutation(self):
        p,t,d=fixture();pc=p.copy();tc=t.copy();dc=d.copy()
        a.build_target_grid(p,t,t,d)
        np.testing.assert_array_equal(p,pc);np.testing.assert_array_equal(t,tc);np.testing.assert_array_equal(d,dc)

if __name__=='__main__':unittest.main()
