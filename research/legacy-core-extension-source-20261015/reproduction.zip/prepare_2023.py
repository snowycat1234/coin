"""Finite six-path source preparation. No financial case constructor or runner.

Requires existing locally restored original 2023 inputs. It never downloads,
opens 2024/2025 data, loads financial outcomes, runs an account, or publishes.
"""
from __future__ import annotations
import argparse
import hashlib
import importlib
from io import BytesIO
import json
from pathlib import Path
import sys
import numpy as np
import legacy_core_adapter as adapter

HERE = Path(__file__).resolve().parent
START, END = 1672531200000000, 1704067200000000
COMMON_FILES = ('frozen_grid.py', 'native_runtime.py', 'historical_entry.py',
    'SOURCE_PROVENANCE.json', 'NATIVE_SOURCE_PROVENANCE.json', 'FROZEN_SPEC.json')
CURRENT_PUBLIC = {
    'commit': '884c22c55d5911f3f3ee956b73297a411e7a519a',
    'report_url': 'https://github.com/snowycat1234/coin/blob/884c22c55d5911f3f3ee956b73297a411e7a519a/research/traditional-nine-cell-2023-20261015/REPORT.md',
    'archive_SHA256': '8271b61c7dcf387cb8e3021475c5283cf989df70328b82f96b4410899f335c8d',
    'preparation_transport_commit': '07480c3b69654f075ce86f78f978f5bd38d8e912',
    'common_V3_commit': '8e613c13be04ec9c724d0f52f699dfb0c1fcaff8',
    'catalogue_commit': '1f41e0776da64b7e1fcb8e9abc9d36ce0f00d9c3',
    'role': 'Reuse completed current comparison; no current financial rerun.'}

def sha(body):
    return hashlib.sha256(body).hexdigest()

def json_sha(value):
    return sha(json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode())

def _json(path):
    return json.loads(Path(path).read_bytes())

def _common():
    common = HERE/'common_v3'
    sys.path.insert(0, str(common))
    for name in ('frozen_grid', 'native_runtime', 'historical_entry', 'annual_entry_2023'):
        loaded = sys.modules.get(name)
        if loaded is not None and Path(loaded.__file__).resolve().parent != common.resolve():
            raise ValueError('ISOLATED_UNCHANGED_COMMON_V3_MODULE_NAMESPACE_REQUIRED')
    entry = importlib.import_module('annual_entry_2023')
    protocol = _json(common/'ANNUAL_2023_PROTOCOL.json')
    identity = entry.h.code_identity()
    saved = _json(HERE/'saved_current2023/PREPARATION.json')
    if entry.code_identity() != saved['code_identity']:
        raise ValueError('UNCHANGED_CURRENT2023_SOURCE_ENTRY_CLOSURE_REQUIRED')
    if identity != protocol['frozen_V3_core_identity']:
        raise ValueError('UNCHANGED_COMMON_V3_EXECUTION_CLOSURE_REQUIRED')
    return entry, protocol, identity

def code_identity():
    names = ('legacy_core_adapter.py','prepare_2023.py','extension_entry_2023.py',
        'run_extension_2023.py','SOURCE_PINS.json','SAVED_CURRENT_PINS.json',
        'TERMINAL_POLICY_PROVENANCE.json','review_signal/REVIEW.json')
    identity = {name: sha((HERE/name).read_bytes()) for name in names}
    for name in COMMON_FILES + ('annual_entry_2023.py','ANNUAL_2023_PROTOCOL.json','annual_reporting.py'):
        identity['common_v3/'+name] = sha((HERE/'common_v3'/name).read_bytes())
    return identity

def _difference(a, b, decisions):
    if a.dtype != b.dtype or a.shape != b.shape:
        raise ValueError('SAME_DTYPE_SHAPE_TARGET_COMPARISON_REQUIRED')
    equal = a.tobytes() == b.tobytes()
    different = np.any(a != b, axis=1)
    diff = np.abs(a-b)
    return dict(entire_target_path_byte_exact=equal,
        different_float64_cells=int(np.count_nonzero(a != b)),
        different_decision_dates=int(np.count_nonzero(different)),
        different_decision_us=decisions[different].tolist(),
        maximum_absolute_target_difference=float(diff.max()),
        left_raw_SHA256=sha(a.tobytes()), right_raw_SHA256=sha(b.tobytes()))

def _compare_current(decisions, targets, covariance, source_identity, core_identity):
    saved = HERE/'saved_current2023'
    prep_raw = (saved/'PREPARATION.json').read_bytes()
    prep = json.loads(prep_raw)
    target_raw = (saved/'TARGETS.npz').read_bytes()
    pin = _json(HERE/'SAVED_CURRENT_PINS.json')
    for name in ('PREPARATION.json', 'TARGETS.npz', 'EXACT_EXECUTION_EQUALITY.json'):
        raw = (saved/name).read_bytes()
        if sha(raw) != pin[name]['SHA256'] or len(raw) != pin[name]['bytes']:
            raise ValueError('EXACT_SAVED_CURRENT2023_BYTES_REQUIRED')
    if (prep['source_identity'] != source_identity or prep['calendar'] != [START, END]
            or prep['cost'] != 'BASE27'
            or any(prep['code_identity'].get(key) != value for key,value in core_identity.items())
            or prep['artifacts']['TARGETS.npz']['SHA256'] != sha(target_raw)):
        raise ValueError('SAME_CURRENT2023_SOURCE_EXECUTION_AND_COST_REQUIRED')
    with np.load(BytesIO(target_raw), allow_pickle=False) as z:
        if (z['decision_us'].tobytes() != decisions.tobytes()
                or z['annual_covariance'].tobytes() != covariance.tobytes()):
            raise ValueError('EXACT_CURRENT2023_CALENDAR_AND_COVARIANCE_REQUIRED')
        baseline = {key: z[key].copy() for key in prep['configs']}
    all_comparisons, eligible = [], []
    for strategy, tier in adapter.CONFIGS:
        key = strategy+'_'+tier
        current_key = ('STATIC50_' if strategy == adapter.STRATEGIES[0] else 'VOL_MANAGED_HOLD_')+tier
        row = dict(config=key, current_comparator=current_key,
            same_tier_source_cost_capital_quantity_funding_terminal_and_common_execution=True,
            **_difference(targets[key], baseline[current_key], decisions))
        row['completed_current_execution_reuse_eligible_after_entry_review'] = row['entire_target_path_byte_exact']
        all_comparisons.append(row)
        # Any same-tier current path can be reused only after every execution
        # binding is reviewed, never because of approximate target similarity.
        for baseline_key, weights in baseline.items():
            if baseline_key.endswith('_'+tier) and targets[key].tobytes() == weights.tobytes():
                eligible.append(dict(config=key, current_config=baseline_key,
                    same_tier=True, exact_target_bytes=True, native_execution_reuse_requires_entry_review=True))
    return dict(schema='PRE_OUTCOME_LEGACY_CURRENT2023_EXACT_DIFFERENCE_V1',
        current_public=CURRENT_PUBLIC, current_preparation_SHA256=sha(prep_raw),
        current_target_archive_SHA256=sha(target_raw),
        comparisons=all_comparisons, same_tier_exact_current_reuse_candidates=eligible,
        no_cross_tier_reuse=True, financial_outcomes_read=False,
        current_financial_reruns=0, independent_alpha_families_claimed=False)

def prepare_source_only(source_root, output_directory):
    output = Path(output_directory)
    if output.exists():
        raise ValueError('EXCLUSIVE_NEW_SOURCE_ONLY_PREPARATION_DIRECTORY_REQUIRED')
    adapter.verify_sources()
    entry, common_protocol, common_identity = _common()
    code = code_identity()
    index, files, t, p, source_rows, quality, payloads, months = entry._source(source_root)
    source_identity = entry._source_identity(files, quality)
    decisions = np.arange(START, END, adapter.DAY, dtype=np.int64)
    d, targets, covariance, proofs = adapter.build_target_grid(p, t, t.copy(), decisions)
    if len(d) != 365 or any(w.shape != (365, 5) for w in targets.values()):
        raise ValueError('EXACT365_SIX_CASE_SOURCE_TARGET_PREPARATION_REQUIRED')
    comparison = _compare_current(d, targets, covariance, source_identity, common_identity)
    identity = adapter.target_identities(d, targets)
    groups = []
    for tier in adapter.TIERS:
        by_hash = {}
        for strategy in adapter.STRATEGIES:
            key = strategy+'_'+tier.name
            by_hash.setdefault(identity['SHA256_by_config'][key], []).append(key)
        groups.extend(by_hash.values())
    execution_binding = dict(common_V3_code=common_identity, source_identity=source_identity,
        calendar=[START, END], covariance_raw_SHA256=sha(covariance.tobytes()),
        cost='BASE27', funding='RAW_AS_FRACTION_CONDITIONAL_UNCERTIFIED',
        initial_cash_USDT='10000', leverage=1, free_cash_floor_USDT='1000',
        isolated_margin_ceiling_USDT='8500', quantity_profile='UNCHANGED_COMMON_V3',
        partial_ladder=['1','.75','.5','.25','0'], terminal='UNCHANGED_PAID_TERMINAL60')
    limits = dict(common_protocol['resource_limits'], maximum_cases=6)
    manifest = dict(schema='FIXED2023_TWO_LEGACY_CORE5_SIX_PATH_SOURCE_ONLY_V1',
        status='PREPARED_NO_FINANCIAL_GO_ENTRY_ADAPTATION_REQUIRES_REVIEW',
        calendar=[START, END], days=365, required_native_minutes=525600,
        source_scope='SEEN_DEVELOPMENT_2023_NOT_UNTOUCHED_OOS', symbol_order=list(adapter.SYMBOLS),
        strategies=list(adapter.STRATEGIES), configs=[s+'_'+tier for s,tier in adapter.CONFIGS],
        risk_adapter='LOWER_ONLY_AFTER_EXACT_INTRINSIC_NO_REEXPANSION',
        pure_adapter_review_SHA256=sha((HERE/'review_signal/REVIEW.json').read_bytes()),
        tiers=[vars(tier) for tier in adapter.TIERS], code_identity=code,
        source_index_SHA256=entry.h.INDEX_SHA, warmup_SHA256=entry.h.WARMUP_SHA,
        source_files=files, original200_quality=quality, source_identity=source_identity,
        source_quality_rows=len(source_rows), all365_original200_windows_admitted=True,
        HOLD_readiness='ORIGINAL_200_POSITIVE_FINITE_CLOSES_WITH_FINITE_SMA_GATE_PROJECTION_FULL5',
        matching='EXACT_PINNED_MATCH_CORE_MATCH_FULL64_CLOCK_AND_CURRENT5_MASK_GATE',
        target_identity=identity, same_tier_exact_execution_groups=groups,
        cross_tier_exact_target_aliases_may_exist_but_execution_reuse_forbidden=True,
        execution_binding=execution_binding, execution_binding_SHA256=json_sha(execution_binding),
        comparison='NEW_COMMON_EXECUTION_VARIANT_NOT_LITERAL_LEGACY_ACCOUNT_REPLICATION',
        changed_component='TWO_SIGNAL_INTRINSIC_TARGETS_AND_LOWER_ONLY_TIER_ADAPTER_ONLY',
        resource_limits=limits, cost='BASE27',
        riskmatched_excess_method='NOT_PREREGISTERED_NOT_CLAIMED',
        financial_accounts_created=0, financial_runs=0, financial_outcomes_read=False,
        current_financial_reruns=0, locked_or_holdout_consumed=False,
        downloads=0, network_requests=0, publications=0,
        other_years_authorized=False, year2024_not_accessed=True, year2025_denied403_STOP=True,
        current_completed_comparison=CURRENT_PUBLIC,
        execution_entry='SEPARATE_EXTENSION_ENTRY_REQUIRES_INDEPENDENT_REVIEW_AND_EXACT_ROOT_GO',
        root_GO_required_for_each_financial_job=True)
    output.mkdir()
    np.savez_compressed(output/'TARGETS.npz',decision_us=d,annual_covariance=covariance,**targets)
    (output/'TARGET_PROOFS.json').write_text(json.dumps(proofs,indent=2,allow_nan=False)+'\n')
    (output/'CURRENT_DIFFERENCE_AND_EQUIVALENCE.json').write_text(json.dumps(comparison,indent=2,allow_nan=False)+'\n')
    manifest['artifacts'] = {name: dict(SHA256=sha((output/name).read_bytes()),bytes=(output/name).stat().st_size)
        for name in ('TARGETS.npz','TARGET_PROOFS.json','CURRENT_DIFFERENCE_AND_EQUIVALENCE.json')}
    if code_identity() != code:
        raise ValueError('EXTENSION_CODE_CHANGED_DURING_SOURCE_PREPARATION')
    (output/'PREPARATION.json').write_text(json.dumps(manifest,indent=2,allow_nan=False)+'\n')
    return manifest

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-root',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    result=prepare_source_only(args.source_root,args.output)
    print(json.dumps({key: result[key] for key in ('status','configs','financial_runs','publications')},indent=2))
