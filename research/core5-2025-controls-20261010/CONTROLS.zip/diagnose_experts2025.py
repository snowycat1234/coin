"""Four predeclared independent shared-wallet controls; no selector or fitting."""
from pathlib import Path
import json,hashlib,csv
import numpy as np,torch
from modules.temporal_two_expert.exact import load_prototype
from modules.temporal_risk_proxy_v2.proxy import BoundaryPlan
from modules.temporal_q4_reserved.terminal import charged_terminal_path
from modules.temporal_july_transfer.evaluate import cost
R=Path(__file__).resolve().parent;O=R/'controls2025';O.mkdir(exist_ok=False)
a=np.load(R/'features2025/EXPERTS.npz');b=np.load(R/'economics2025/ECONOMICS.npz');dec=a['decision_us'];np.testing.assert_array_equal(dec,b['decision_us']);n=len(dec)
p=load_prototype(R.parent/'recovery/source/modules/direct_path/prototype.py');contexts=[]
for i,t in enumerate(dec):
 targets=np.zeros((5,5));eligible=np.zeros(5,bool);targets[[0,1,3,4]]=a['expert_targets'][i];eligible[[0,1,3,4]]=a['expert_eligible'][i];c=p.Context(int(t),int(t),targets,eligible,a['past_returns30'][i],np.zeros(13),np.full(5,t,dtype=np.int64));c.validate();contexts.append(c)
policies={'VOL':[0,1,0,0,0],'CS':[0,0,0,1,0],'SHORT':[0,0,0,0,1],'STATIC_VOL_CS_50':[0,.5,0,.5,0]}
(O/'PLAN.json').write_text(json.dumps({'policies':policies,'no_selection':True,'starting_capital_each':10000,'independent_wallets_not_added':True,'costs_each_side_bps':{'fee':5.5,'half_spread':4,'slippage':4},'funding':'actual signed archival events','ending':'paid flat2025Dec31','role':'development controls, daily full-fill not native minute replay'},indent=2))
results={}
for name,weight in policies.items():
 request=np.tile(weight,(n,1));targets,mapped=p.mapped_path(request,contexts)
 with torch.no_grad():q=charged_terminal_path(torch.tensor(targets,dtype=torch.float64),b['prices'],b['funding_coeff'],plan=BoundaryPlan.full_fill_diagnostic(n))
 nav=q['nav'].numpy();qty=q['quantity'].numpy();held=q['boundary_held_quantity'].numpy();carry=np.zeros(5);residual=0.;rows=[];sums=np.zeros(5)
 for i in range(n):
  price=b['prices'][i];nextprice=b['prices'][min(i+1,n-1)];opening=np.array(cost(qty[i]-carry,price));reduce=np.array(cost(held[i]-qty[i],nextprice));pricep=float(qty[i]@(nextprice-price));fund=-float(qty[i]@b['funding_coeff'][i]) if i<n-1 else 0.;components=np.r_[pricep,fund,opening+reduce];sums+=components;expected=nav[i]+pricep+fund-(opening+reduce).sum();residual=max(residual,abs(expected-nav[i+1]));gross=float((abs(qty[i])*price).sum()/(nav[i]-opening.sum()));net=float(qty[i]@price/(nav[i]-opening.sum()));assert gross<=.600000001
  rows.append(dict(decision_us=int(dec[i]),start_nav=float(nav[i]),end_nav=float(nav[i+1]),price_PnL=pricep,funding_PnL=fund,fees=float(components[2]),spread=float(components[3]),slippage=float(components[4]),actual_gross=gross,actual_net=net,paid_terminal=i==n-1));carry=held[i]
 assert residual<1e-8 and not qty[-1].any() and not held[-1].any();np.testing.assert_allclose(sums[2:],[float(q[k]) for k in ['fees','spread','slippage']],atol=1e-9,rtol=1e-12);np.testing.assert_allclose(sums[1],float(q['funding']),atol=1e-9,rtol=1e-12)
 np.savez_compressed(O/(name+'_PATH.npz'),decision_us=dec,request=request,targets=targets,nav=nav,quantity=qty,boundary_held_quantity=held,budget=np.stack([x['budget'] for x in mapped]))
 with (O/(name+'_DAILY.csv')).open('w') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 results[name]={'net_PnL':float(nav[-1]-10000),'cumulative_return':float(nav[-1]/10000-1),'maximum_daily_drawdown':float(np.max(1-nav/np.maximum.accumulate(nav))),'mean_actual_gross':float(np.mean([x['actual_gross'] for x in rows[:-1]])),'mean_actual_net':float(np.mean([x['actual_net'] for x in rows[:-1]])),'price_PnL':float(sums[0]),'funding_PnL':float(sums[1]),'fees':float(sums[2]),'spread':float(sums[3]),'slippage':float(sums[4]),'max_independent_PnL_error':residual,'risk_event_count':len(q['risk_events'])}
 print(name,results[name],flush=True)
(O/'RESULTS.json').write_text(json.dumps({'policies':results,'optimizer_steps':0,'new_wallets':4,'no_APR_or_Bybit_population_claim':True,'period':'2025Jan1-Dec31 paid close','source_commit':'818bb756453aed6ce82aeb572362baecb27bb9e6'},indent=2)+'\n')
