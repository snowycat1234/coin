import tempfile,unittest
from pathlib import Path
import numpy as np
import verify_recovered_2024_source as v
class SourceChecks(unittest.TestCase):
 def good(self):
  return dict(times=np.array([0,60000000],dtype=np.int64),**{'BTCUSDT_'+x:np.ones(2,dtype=np.float64) for x in ('open','close','quote_volume','mark')})
 def test_exact_grid(self):v.check_month(self.good(),('BTCUSDT',),0,2)
 def test_missing_grid_stops(self):
  x=self.good();x['times'][1]+=60000000
  with self.assertRaisesRegex(ValueError,'COMPLETE_ORIGINAL_MINUTE_GRID'):v.check_month(x,('BTCUSDT',),0,2)
 def test_nonfinite_stops(self):
  x=self.good();x['BTCUSDT_mark'][0]=np.nan
  with self.assertRaisesRegex(ValueError,'FINITE_ORIGINAL_FLOAT64'):v.check_month(x,('BTCUSDT',),0,2)
 def test_changed_source_stops(self):
  with tempfile.TemporaryDirectory() as t:
   p=Path(t)/'source';p.write_bytes(b'changed')
   with self.assertRaisesRegex(ValueError,'EXACT_SOURCE_BYTES'):v.checked_bytes(p,dict(bytes=7,SHA256='0'*64))
 def test_full_warmup_and_windows(self):
  r=v.verify_warmup_and_proof(Path(__file__).parent/'SOURCE_WARMUP_CLOSE_ONLY.npz',Path(__file__).parent)
  self.assertEqual((r['decisions'],r['window_days'],r['actual_source_close_cells']),(366,200,2830))
if __name__=='__main__':unittest.main()
