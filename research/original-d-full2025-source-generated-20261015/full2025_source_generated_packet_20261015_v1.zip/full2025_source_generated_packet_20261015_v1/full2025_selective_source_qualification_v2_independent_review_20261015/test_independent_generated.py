"""Independent generated-only adversarial review. No historical body fixtures."""
import os
for _k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[_k]='1'
import sys
sys.dont_write_bytecode=True
import copy
import hashlib
import io
import json
from pathlib import Path
import stat
import struct
import tempfile
import types
import unittest
from unittest.mock import patch
import zipfile

ROOT=Path(__file__).resolve().parent.parent
PACKAGE=ROOT/'full2025_selective_source_qualification_20261015_v2'
sys.path.insert(0,str(PACKAGE))
import numpy as np
import pandas as pd
import contracts as c
import selection as s
import source_reader as r
import source_guard as g
import launch_source as launch
import qualify as q

BOUNDARY_OBSERVATIONS=[]


def archive_bytes(items, compression=zipfile.ZIP_STORED):
    out=io.BytesIO()
    with zipfile.ZipFile(out,'w',compression=compression) as z:
        for name, body in items:
            z.writestr(name,body)
    return out.getvalue()


def generated_npz(**arrays):
    out=io.BytesIO();np.savez_compressed(out,**arrays);return out.getvalue()


class MetadataAndScopeTests(unittest.TestCase):
    def test_exact_frozen_plan_load_is_metadata_only(self):
        contract,checks,cache,_=c.load_plan()
        self.assertEqual(len(contract['selectors']),180)
        self.assertEqual(len(cache['objects']),217)
        self.assertEqual(sum(p['bytes'] for p in checks['canonical_expected_source_files']),46269167)

    def test_scope_wrong_issuer_stops_without_source(self):
        class Guard:active=True
        with self.assertRaises(c.QualificationStop):
            c.StageScope(object(),'0'*64,PACKAGE/'source_runs'/('0'*64)/'unadmitted',Guard(),[])

    def test_fake_scope_cache_cannot_reach_opaque_reader(self):
        class Fake:
            def check(self):pass
        with patch.object(s,'opaque_identity',side_effect=AssertionError('FORBIDDEN_ACTUAL_BODY_REACHED')) as op:
            with self.assertRaises(c.QualificationStop):s.ExactCache(Fake(),{}, {}, {})
        self.assertEqual(op.call_count,0)

    def test_fake_scope_selected_cannot_reach_metadata_or_reassembly(self):
        class Fake:
            def check(self):pass
        with patch.object(s,'read_exact',side_effect=AssertionError('FORBIDDEN_ACTUAL_BODY_REACHED')) as op:
            with self.assertRaises(c.QualificationStop):s.SelectedSources(Fake(),{},None)
        self.assertEqual(op.call_count,0)

    def test_fake_scope_reader_cannot_reach_source_index(self):
        class Fake:
            output=Path('/generated')
            def check(self):pass
        with patch.object(r,'read_exact',side_effect=AssertionError('FORBIDDEN_ACTUAL_BODY_REACHED')) as op:
            with self.assertRaises(c.QualificationStop):r.ImmutableSourceReader(Fake(),Path('/generated/prepared_2025'),{})
        self.assertEqual(op.call_count,0)

    def test_actual_entry_fake_scope_stops_before_pure_or_source(self):
        class Fake:
            def check(self):pass
        with patch.object(q,'pure_normalizer',side_effect=AssertionError('FORBIDDEN_ACTUAL_ENTRY_REACHED')) as op:
            with self.assertRaises(c.QualificationStop):q.run_source_qualification(Fake(),{}, {}, {}, {}, {})
        self.assertEqual(op.call_count,0)

    def test_invalid_generated_origin_never_satisfies_actual_authority(self):
        auth={'generated_origin':True,'root_source_qualification_authorized':False}
        with self.assertRaises(c.QualificationStop):
            launch.validate_authorization(auth,code_sha='a'*64,review_sha='b'*64,transport_sha='c'*64,cache_sha='d'*64)

    def test_changed_external_sha_fails_before_any_source(self):
        with tempfile.TemporaryDirectory(prefix='independent2025-') as d:
            p=Path(d)/'metadata.json';p.write_text('{}')
            with self.assertRaises(c.QualificationStop):launch.pinned_input(p,'a'*64,[])

    def test_regular_hash_capture_changed_and_symlink_paths(self):
        with tempfile.TemporaryDirectory(prefix='independent2025-') as d:
            p=Path(d)/'generated.bin';p.write_bytes(b'generated')
            expected=c.digest(b'generated')
            self.assertEqual(c.read_exact(p,9,expected),b'generated')
            p.write_bytes(b'GENERATED')
            with self.assertRaises(c.QualificationStop):c.read_exact(p,9,expected)
            link=Path(d)/'alias';link.symlink_to(p)
            with self.assertRaises(c.QualificationStop):c.read_exact(link,9,c.digest(b'GENERATED'))

    def test_frozen_selector_field_year_clock_hash_authority_mutations(self):
        original=c.frozen_metadata('EXACT_SELECTION_CONTRACT.json')
        for field,value in [('selected_fields',['timestamp_ms','close','model']),('calendar_year_us',[c.START,c.END+c.DAY]),('month','2026-03'),('member','holdout/2026-03.npz'),('SHA256','0'*64),('wrapper','/generated/other.zip')]:
            altered=copy.deepcopy(original);altered['selectors'][0][field]=value
            with self.subTest(field=field),self.assertRaises(c.QualificationStop):c.require_frozen_contract(altered,'EXACT_SELECTION_CONTRACT.json')
    def test_frozen_cache_path_hash_commit_authority_mutations(self):
        original=c.frozen_metadata('CACHE_BINDING_SPEC.json')
        for field,value in [('cache_path','/generated/other'),('original_commit','0'*40),('original_path','unknown')]:
            altered=copy.deepcopy(original);altered['objects'][0][field]=value
            with self.subTest(field=field),self.assertRaises(c.QualificationStop):c.require_frozen_contract(altered,'CACHE_BINDING_SPEC.json')
        altered=copy.deepcopy(original);altered['objects'][0]['expected']['SHA256']='0'*64
        with self.assertRaises(c.QualificationStop):c.require_frozen_contract(altered,'CACHE_BINDING_SPEC.json')
    def test_frozen_output_schema_and_pin_mutations(self):
        original=c.frozen_metadata('QUALIFICATION_CHECKS.json')
        altered=copy.deepcopy(original);altered['schema']['monthly_keys'].append('model')
        with self.assertRaises(c.QualificationStop):c.require_frozen_contract(altered,'QUALIFICATION_CHECKS.json')
        altered=copy.deepcopy(original);altered['canonical_expected_source_files'][0]['SHA256']='0'*64
        with self.assertRaises(c.QualificationStop):c.require_frozen_contract(altered,'QUALIFICATION_CHECKS.json')
    def test_exact_month_clock_predicate_prebody(self):
        c.exact_month_predicate('2025-01',c.START,44640)
        for stamp,lo,minutes in [('2026-03',c.END,44640),('2025-1',c.START,44640),('2025-01',c.START+1,44640),('2025-01',c.START,44639),('2025-13',c.START,44640)]:
            with self.subTest(stamp=stamp,lo=lo,minutes=minutes),self.assertRaises(c.QualificationStop):c.exact_month_predicate(stamp,lo,minutes)
    def test_external_authorization_scope_mutations(self):
        auth=dict(schema=c.SCHEMA,action=c.ACTION,stage=c.STAGE,status='APPROVED_SOURCE_ONLY',root_source_qualification_authorized=True,
            historical_execution_authorized=False,financial_execution_authorized=False,
            bindings=dict(frozen_plan_SHA256=c.PLAN_SHA,independent_plan_review_SHA256=c.PLAN_REVIEW_SHA,code_manifest_SHA256='a'*64,independent_code_review_SHA256='b'*64,
                complete_transport_receipt_SHA256='c'*64,opaque_cache_index_SHA256='d'*64,source_index_SHA256=c.INDEX_SHA,
                raw_selection_manifest_SHA256='f47338cba170f4f98223a4df43fc01ae30988cedede64424b69fda17a57228d2'),calendar_us=[c.START,c.END],symbols=list(c.SYMBOLS),
            limits=dict(CPU_seconds=300,wall_seconds=900,additional_disk_bytes=268435456,CPU_affinity=[8],workers=1,new_network_requests=0),
            permitted_actions=['REHASH_EXACT_217_OPAQUE_CACHE_IDENTITIES','REASSEMBLE_EXACT_PINNED_H1_AND_H2','INSPECT_SELECTED_CENTRAL_DIRECTORIES','READ_EXACT_180_SOURCE_ARCHIVES_AND_120_CHECKSUMS',
                'READ_EXACT_QUALIFIED_2024_PAST_ONLY_CLOSE_WARMUP','WRITE_EXACT_15_CANONICAL_SOURCE_FILES','WRITE_SOURCE_ONLY_365_WINDOW_ENDPOINT_UNIT_CLOCK_PROOFS'],
            priority_release='ROOT_RELEASED_CPU8_FOR_SOURCE_QUALIFICATION')
        args=dict(code_sha='a'*64,review_sha='b'*64,transport_sha='c'*64,cache_sha='d'*64)
        launch.validate_authorization(auth,**args)
        for field,value in [('status','GENERATED'),('historical_execution_authorized',True),('financial_execution_authorized',True),('calendar_us',[c.START,c.END+c.DAY]),('symbols',list(reversed(c.SYMBOLS))),('permitted_actions',[]),('priority_release','UNRELEASED')]:
            altered=copy.deepcopy(auth);altered[field]=value
            with self.subTest(field=field),self.assertRaises(c.QualificationStop):launch.validate_authorization(altered,**args)
        altered=copy.deepcopy(auth);altered['limits']['new_network_requests']=1
        with self.assertRaises(c.QualificationStop):launch.validate_authorization(altered,**args)
        altered=copy.deepcopy(auth);altered['bindings']['source_index_SHA256']='0'*64
        with self.assertRaises(c.QualificationStop):launch.validate_authorization(altered,**args)

    def test_month_fields_and_clock_fail_before_read(self):
        checks=c.frozen_metadata('QUALIFICATION_CHECKS.json')
        pin=checks['canonical_expected_source_files'][0]
        fake=types.SimpleNamespace(output=Path('/generated'))
        path=Path('/generated/prepared_2025/months/2025-01.npz')
        with patch.object(r,'require_actual_scope'),patch.object(r,'read_exact',side_effect=AssertionError('ACTUAL_BODY')) as read:
            for lo,minutes in [(c.START+1,44640),(c.START,44639)]:
                with self.assertRaises(c.QualificationStop):r.monthly_arrays(path,pin,checks['schema']['monthly_keys'],month_lo=lo,minutes=minutes,scope=fake)
            with self.assertRaises(c.QualificationStop):r.monthly_arrays(path,pin,checks['schema']['monthly_keys']+['model'],month_lo=c.START,minutes=44640,scope=fake)
            self.assertEqual(read.call_count,0)

    def test_injected_generated_partial_failure_never_admits_batch(self):
        # Only the launcher control flow is exercised. No StageScope is issued;
        # actual qualification is replaced by a generated in-temp failure.
        class FakeScope:
            def __init__(self,token,sha,output,guard,closure):
                self.output,self.guard,self.active,self.observed=output,guard,True,{}
            def check(self):pass
            def close(self):self.active=False
        def generated_failure(scope,*args):
            self.assertTrue(scope.guard.active)
            (scope.output/'GENERATED_PARTIAL.json').write_text('{"status":"UNADMITTED_GENERATED_PARTIAL"}')
            raise ValueError('INJECTED_GENERATED_FAILURE_BEFORE_BATCH_COMPLETE')
        def metadata(path,sha,closure):
            name=Path(path).name
            if name=='review':return {'status':'PASS_GENERATED_ONLY','code_manifest_SHA256':'a'*64,'actual_source_body_reads':0,'FAIL_count':0}
            if name=='FINAL_OPAQUE_TRANSPORT_RECEIPT.json':return {'opaque_cache_index_SHA256':launch.CACHE_INDEX_SHA}
            if name=='REVIEW.json':return {'PASS_count':124,'FAIL_count':0}
            return {}
        with tempfile.TemporaryDirectory(prefix='independent2025-launch-') as d:
            here=Path(d)
            with patch.object(launch,'HERE',here),patch.object(launch,'pinned_input',side_effect=metadata),patch.object(launch,'verify_code_manifest'),patch.object(launch,'validate_authorization'),patch.object(launch,'StageScope',FakeScope),patch.object(launch,'_register_reviewed_launch'),patch.object(launch,'run_source_qualification',side_effect=generated_failure),patch.object(launch.os,'sched_getaffinity',return_value={8}),patch.object(launch.os,'sched_setaffinity'),patch.object(launch.resource,'setrlimit'),patch.object(launch.signal,'signal'),patch.object(launch.signal,'setitimer'):
                with self.assertRaisesRegex(RuntimeError,'INJECTED_GENERATED_FAILURE'):
                    launch.launch(authorization_path='auth',authorization_sha='e'*64,code_manifest_path='manifest',code_manifest_sha='a'*64,code_review_path='review',code_review_sha='b'*64)
            base=here/'source_runs'/('e'*64)
            self.assertTrue((base/'unadmitted/GENERATED_PARTIAL.json').exists())
            self.assertFalse((base/'qualified_source_only_pending_review').exists())
            self.assertFalse((base/'SOURCE_STAGE_COMPLETION.json').exists())
            stop=json.loads((base/'STOP_SOURCE_QUALIFICATION.json').read_text())
            self.assertEqual(stop['status'],'FAIL_CLOSED_NO_CANONICAL_ADMISSION')
            observed=json.loads((base/'OBSERVED_SOURCE_GUARD_RECEIPT.json').read_text())
            self.assertTrue(observed['scope_revoked'])
            self.assertEqual(observed['status'],'SOURCE_STAGE_STOPPED')
            self.assertFalse(any(observed['forbidden_attempts'].values()))

    def test_private_token_without_one_shot_review_registration_denied(self):
        with tempfile.TemporaryDirectory(prefix='independent2025-') as d:
            guard=g.SourceOnlyGuard(write_roots=(Path(d),))
            with guard:
                with self.assertRaisesRegex(c.QualificationStop,'ONE_SHOT'):
                    c.StageScope(c._ISSUER_TOKEN,'0'*64,PACKAGE/'source_runs'/('0'*64)/'unadmitted',guard,[])
            self.assertFalse(c._ACTIVE_SCOPES)
    def test_empty_external_scope_registration_denied_before_metadata_reads(self):
        with patch.object(c,'read_exact',side_effect=AssertionError('SOURCE_OR_METADATA_READ')) as read:
            with self.assertRaises(c.QualificationStop):c._register_reviewed_launch('0'*64,Path('/generated'),types.SimpleNamespace(active=True),[])
            self.assertEqual(read.call_count,0)

    def test_metadata_compact_fallback_retains_fields_and_hard_cap(self):
        with tempfile.TemporaryDirectory(prefix='independent2025-json-') as d:
            original={'sample':'data'};p=Path(d)/'pretty.json'
            c.save_new(p,original)
            self.assertEqual(p.read_bytes(),(json.dumps(original,sort_keys=True,indent=2,allow_nan=False)+'\n').encode())
            large={'data':[0]*60};p=Path(d)/'compact.json'
            self.assertGreater(len((json.dumps(large,sort_keys=True,indent=2)+'\n').encode()),256)
            with patch.object(c,'META_CAP',256):c.save_new(p,large)
            self.assertEqual(json.loads(p.read_bytes()),large);self.assertLessEqual(p.stat().st_size,256)
            p=Path(d)/'too_large.json'
            with patch.object(c,'META_CAP',32):
                with self.assertRaises(c.QualificationStop):c.save_new(p,{'data':'x'*64})
            self.assertFalse(p.exists())

    def test_unsafe_relative_paths_fail_before_open(self):
        for value in ('../x','/x','a/../x','a//x','a\\x','C:x','a/./x','a\0x'):
            with self.subTest(value=value),self.assertRaises(c.QualificationStop):c.relative_path('/generated',value)


class ZipAndSchemaTests(unittest.TestCase):
    def test_selected_only_crc_read_and_excluded_prebody(self):
        raw=archive_bytes([('raw/source.zip',b'good'),('models/excluded.pkl',b'never')])
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            opened=[];original=z.open
            def op(*args,**kwargs):opened.append(args[0].filename if hasattr(args[0],'filename') else args[0]);return original(*args,**kwargs)
            with patch.object(z,'open',side_effect=op):
                with self.assertRaises(c.QualificationStop):s.selected_read(z,{'raw/source.zip'},'models/excluded.pkl',cap=64)
                self.assertEqual(opened,[])
                self.assertEqual(s.selected_read(z,{'raw/source.zip'},'raw/source.zip',cap=64,size=4),b'good')
                self.assertEqual(opened,['raw/source.zip'])

    def test_zip_duplicate_names_stops_before_body(self):
        raw=archive_bytes([('source',b'a'),('source',b'b')])
        with zipfile.ZipFile(io.BytesIO(raw)) as z,patch.object(z,'open',side_effect=AssertionError('BODY')) as op:
            with self.assertRaises(c.QualificationStop):s.selected_read(z,{'source'},'source',cap=32)
            self.assertEqual(op.call_count,0)

    def test_all_selected_zip_metadata_negatives(self):
        for name in ('../raw','/raw','a\\raw','C:raw','a//raw','a/./raw','a/../raw'):
            info=zipfile.ZipInfo(name);info.file_size=1;info.compress_size=1
            with self.subTest(name=name),self.assertRaises(c.QualificationStop):s.safe_zip_info(info,expected_name=name,cap=10)
        cases=[('symlink',lambda z:setattr(z,'external_attr',(stat.S_IFLNK|0o777)<<16)),
            ('encrypted',lambda z:setattr(z,'flag_bits',1)),
            ('compression',lambda z:setattr(z,'compress_type',zipfile.ZIP_BZIP2)),
            ('expanded',lambda z:setattr(z,'file_size',11)),
            ('compressed',lambda z:setattr(z,'compress_size',11))]
        for label,mutate in cases:
            info=zipfile.ZipInfo('source');info.file_size=1;info.compress_size=1;mutate(info)
            with self.subTest(label=label),self.assertRaises(c.QualificationStop):s.safe_zip_info(info,expected_name='source',cap=10)

    def test_selected_crc_corruption_fails(self):
        raw=bytearray(archive_bytes([('source.csv',b'generated-csv')]))
        body=raw.find(b'generated-csv');self.assertGreater(body,0);raw[body]^=1
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            with self.assertRaises(zipfile.BadZipFile):s.selected_read(z,{'source.csv'},'source.csv',cap=64)

    def test_raw_hash_stops_before_inner_central_directory(self):
        with patch.object(s.zipfile,'ZipFile',side_effect=AssertionError('CENTRAL_DIRECTORY')) as op:
            with self.assertRaises(c.QualificationStop):s.inner_metadata(b'bad',{'bytes':3,'SHA256':'0'*64},'source.csv')
            self.assertEqual(op.call_count,0)

    def test_wrong_inner_basename_or_multiple_members(self):
        for members in [[('wrong.csv',b'1')],[('source.csv',b'1'),('future.csv',b'2')]]:
            raw=archive_bytes(members)
            with self.assertRaises(c.QualificationStop):s.inner_metadata(raw,{'bytes':len(raw),'SHA256':c.digest(raw)},'source.csv')

    def test_npz_unknown_future_field_stops_before_array_loader(self):
        raw=generated_npz(close=np.ones(2),model=np.ones(2))
        with patch.object(r.np,'load',side_effect=AssertionError('ARRAY_BODY')) as op:
            with self.assertRaises(c.QualificationStop):r.numeric_npz_bytes(raw,['close'],shapes={'close':(2,)},dtypes={'close':'float64'})
            self.assertEqual(op.call_count,0)

    def test_npz_exact_schema_and_readonly_capture(self):
        raw=generated_npz(times=np.array([1,2],dtype=np.int64),close=np.ones(2,dtype=np.float64))
        arrays=r.numeric_npz_bytes(raw,['times','close'],shapes={'times':(2,),'close':(2,)},dtypes={'times':'int64','close':'float64'})
        self.assertFalse(arrays['close'].flags.writeable)
        with self.assertRaises(ValueError):arrays['close'][0]=2
        for shapes,dtypes in [({'times':(3,),'close':(2,)},{'times':'int64','close':'float64'}),({'times':(2,),'close':(2,)},{'times':'float64','close':'float64'})]:
            with self.assertRaises(c.QualificationStop):r.numeric_npz_bytes(raw,['times','close'],shapes=shapes,dtypes=dtypes)

    def test_warmup_future_declaration_stops_before_array_loader(self):
        raw=b'generated'
        contract={'bytes':len(raw),'SHA256':c.digest(raw),'exact_array_keys':['close_available_us','close'],
            'container_source_available_us_bounds':[1686873600000000,c.END],
            'forbidden_future_or_holdout_rows_in_container':1}
        with patch.object(r.np,'load',side_effect=AssertionError('ARRAY_BODY')) as op:
            with self.assertRaises(c.QualificationStop):r.warmup_projection(raw,contract)
            self.assertEqual(op.call_count,0)


class ClockAndUnitTests(unittest.TestCase):
    def test_generated_365_windows_and_each_clock(self):
        clocks=np.arange(c.START-199*c.DAY,c.START+c.DAY,c.DAY,dtype=np.int64)
        close=np.ones((200,5),dtype=np.float64)
        completed={int(t):[1.,2.,3.,4.,5.] for t in range(c.START+c.DAY,c.END+c.DAY,c.DAY)}
        proof=r.window_proof(clocks,close,completed)
        self.assertEqual(len(proof),365)
        self.assertEqual(proof[0]['last_available_us'],c.START)
        self.assertEqual(proof[-1]['last_available_us'],c.END-c.DAY)
        self.assertTrue(all(v['last_available_us']<=v['decision_us'] for v in proof))
        bad=clocks.copy();bad[-1]+=1
        with self.assertRaises(c.QualificationStop):r.window_proof(bad,close,completed)
        completed.pop(c.END)
        with self.assertRaises(c.QualificationStop):r.window_proof(clocks,close,completed)

    def test_generated_strict_past_mark_and_initial_unknown(self):
        marks={symbol:np.ones(525600,dtype=np.float64) for symbol in c.SYMBOLS}
        events=[{'symbol':c.SYMBOLS[0],'event_us':v} for v in [c.START,c.START+1,c.START+8*60*c.MINUTE,c.START+8*60*c.MINUTE+123000]]
        proof=q.strict_past_mark_proof(events,marks)
        self.assertEqual(proof[0]['status'],'BOUNDARY_PRIOR_MARK_UNKNOWN')
        self.assertEqual(proof[1]['status'],'BOUNDARY_PRIOR_MARK_UNKNOWN')
        self.assertEqual(proof[2]['gap_us'],c.MINUTE)
        self.assertEqual(proof[3]['gap_us'],123000)
        self.assertTrue(all(not v.get('financial_charge_created',False) for v in proof))

    def test_generated_funding_units_and_calendar_unchanged(self):
        contract,_,_,_=c.load_plan()
        events=[dict(symbol=symbol,event_us=int(at),raw_rate=0.0001,reported_interval_hours=8.0)
            for at in range(c.START,c.END,8*60*c.MINUTE) for symbol in c.SYMBOLS]
        summary=q.funding_check(events,contract['selectors'])
        self.assertEqual(sum(v['events'] for v in summary),5475)
        self.assertTrue(all(v['raw_rate_unit']=='UNCONFIRMED' for v in summary))
        self.assertTrue(all(v['raw_rate']==0.0001 for v in events))
        events[5]['event_us']+=1000001
        with self.assertRaises(c.QualificationStop):q.funding_check(events,contract['selectors'])

    def test_h2_gap_outer_crc_is_not_applicable_and_inner_crc_preserved(self):
        expected=np.array([c.START,c.START+c.MINUTE,c.START+2*c.MINUTE],dtype=np.int64)
        frame=pd.DataFrame({'timestamp_ms':np.array([c.START,c.START+2*c.MINUTE],dtype=np.int64)//1000,'open':[1.,1.],'close':[1.,1.],'quote_volume':[1.,1.]})
        selector={'selection_id':'GENERATED','symbol':'BTCUSDT','family':'klines','month':'2025-01','SHA256':'a'*64,'bytes':100,'transport':'H2_RAW_PARTS'}
        diagnostic=q.gap_classification(frame,expected,selector,{'source_commit':'generated'})
        self.assertEqual(diagnostic['selected_outer_CRC_status'],'NOT_APPLICABLE_RAW_PART_REASSEMBLY')
        self.assertEqual(diagnostic['selected_inner_CRC_status'],'PASS_SELECTED_EOF')

    def test_new_gap_fails_and_reports_exact_missing_clock(self):
        expected=np.array([c.START,c.START+c.MINUTE,c.START+2*c.MINUTE],dtype=np.int64)
        frame=pd.DataFrame({'timestamp_ms':np.array([c.START,c.START+2*c.MINUTE],dtype=np.int64)//1000,'open':[1.,1.],'close':[1.,1.],'quote_volume':[1.,1.]})
        selector={'selection_id':'GENERATED','symbol':'BTCUSDT','family':'klines','month':'2025-01','SHA256':'a'*64,'bytes':100}
        with self.assertRaises(ValueError) as caught:q.exact_price_grid(frame,expected,selector=selector)
        self.assertEqual(caught.exception.classification['exact_missing_expected_minute_open_us'],[c.START+c.MINUTE])
        self.assertEqual(caught.exception.classification['affected_asset_minute_cells'],1)
        self.assertEqual(caught.exception.classification['affected_field_cells'],3)
        self.assertEqual(len(caught.exception.classification['contiguous_missing_runs']),1)
        self.assertFalse(caught.exception.classification['imputation_or_2022_policy_reuse'])
        self.assertIn('FAIL_CLOSED',str(caught.exception))


class NarrowH1ResolverTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.contract=c.frozen_metadata('CACHE_BINDING_SPEC.json')
        cls.index=s.pinned_h1_index()
        cls.name='coin_frozen_e5_2025h1_increment_20261008.zip.bytepart004'
        cls.original_path=s.H1_ORIGINAL_DIRECTORY+cls.name
        cls.row=next(v for v in cls.contract['objects'] if v['original_path']==cls.original_path)
    def test_all_nine_canonical_metadata_routes_without_body_opens(self):
        with patch.object(s,'read_exact',side_effect=AssertionError('BODY_OPEN_FORBIDDEN')):
            routes=s.exact_h1_cache_routes(self.contract,self.index)
        self.assertEqual(len(routes),9)
        self.assertEqual(routes[self.name],'source_network_readonly_diagnosis_20261015/part004_original_route_probe/'+self.name)
        mapped={v['cache_path']:v for v in self.contract['objects']}
        for part in self.index['parts']:
            row=mapped[routes[part['file_name']]]
            self.assertEqual(row['original_commit'],s.H1_ORIGINAL_COMMIT)
            self.assertEqual(row['original_path'],s.H1_ORIGINAL_DIRECTORY+part['file_name'])
            self.assertEqual(row['expected'],{'bytes':part['bytes'],'SHA256':part['sha256'],'GitBlobSHA1':part['git_blob_sha1']})
    def test_all_nine_h1_calls_only_exact_joined_paths(self):
        routes=s.exact_h1_cache_routes(self.contract,self.index)
        cache=s.ExactCache.__new__(s.ExactCache);cache._h1_routes=routes;cache._check=lambda:None
        calls=[];cache.bytes=lambda path:calls.append(path) or b'GENERATED_ONLY'
        for part in self.index['parts']:self.assertEqual(cache.h1_part(part['file_name']),b'GENERATED_ONLY')
        self.assertEqual(calls,[routes[v['file_name']] for v in self.index['parts']])
        self.assertNotIn('native_2025_source_restore_20261015/transport/H1/'+self.name,calls)
    def test_wrong_hash_bytes_git_and_commit_stop_without_body_opens(self):
        for field in ['SHA256','bytes','GitBlobSHA1','original_commit']:
            modified=copy.deepcopy(self.contract);row=next(v for v in modified['objects'] if v['original_path']==self.original_path)
            if field=='original_commit':row[field]='0'*40
            elif field=='bytes':row['expected'][field]+=1
            else:row['expected'][field]='0'*(64 if field=='SHA256' else 40)
            with self.subTest(field=field),patch.object(s,'read_exact',side_effect=AssertionError('BODY_OPEN_FORBIDDEN')):
                with self.assertRaises(c.QualificationStop):s.exact_h1_cache_routes(modified,self.index)
    def test_duplicate_and_no_match_stop_without_body_opens(self):
        values=[]
        missing=copy.deepcopy(self.contract);missing['objects']=[v for v in missing['objects'] if v['original_path']!=self.original_path];values.append(missing)
        duplicate=copy.deepcopy(self.contract);duplicate['objects'].append(copy.deepcopy(self.row));values.append(duplicate)
        alias=copy.deepcopy(self.contract);row=next(v for v in alias['objects'] if v['original_path']==self.original_path);row['original_path']='alias/'+row['original_path'];values.append(alias)
        for modified in values:
            with patch.object(s,'read_exact',side_effect=AssertionError('BODY_OPEN_FORBIDDEN')):
                with self.assertRaises(c.QualificationStop):s.exact_h1_cache_routes(modified,self.index)
    def test_index_missing_duplicate_or_extra_part_rejected(self):
        missing=copy.deepcopy(self.index);missing['parts'].pop()
        duplicate=copy.deepcopy(self.index);duplicate['parts'][0]=copy.deepcopy(duplicate['parts'][1])
        extra=copy.deepcopy(self.index);extra['parts'][0]['file_name']='coin_frozen_e5_2025h1_increment_20261008.zip.bytepart009'
        for index in [missing,duplicate,extra]:
            with self.assertRaises(c.QualificationStop):s.exact_h1_cache_routes(self.contract,index)
    def test_filename_aliases_never_reach_cache_bytes(self):
        cache=s.ExactCache.__new__(s.ExactCache);cache._h1_routes=s.exact_h1_cache_routes(self.contract,self.index);cache._check=lambda:None
        with patch.object(cache,'bytes',side_effect=AssertionError('CACHE_READ')) as read:
            for name in ['../'+self.name,'/tmp/'+self.name,'x/'+self.name,self.name+'.extra',self.name.replace('004','009'),self.name+'\\bad',None]:
                with self.assertRaises(c.QualificationStop):cache.h1_part(name)
            self.assertEqual(read.call_count,0)
    def test_old_wrong_part004_cache_path_rejected_before_read(self):
        cache=s.ExactCache.__new__(s.ExactCache);cache._objects={v['cache_path']:v for v in self.contract['objects']};cache._check=lambda:None
        wrong='native_2025_source_restore_20261015/transport/H1/'+self.name
        with patch.object(s,'read_exact',side_effect=AssertionError('ACTUAL_BODY_OPEN')) as read:
            with self.assertRaisesRegex(c.QualificationStop,'NONALLOWLISTED_CACHE_PATH'):cache.bytes(wrong)
            self.assertEqual(read.call_count,0)
    def test_changed_declared_cache_path_cannot_become_actual_authority(self):
        altered=copy.deepcopy(self.contract);row=next(v for v in altered['objects'] if v['original_path']==self.original_path)
        row['cache_path']='native_2025_source_restore_20261015/transport/H1/'+self.name
        with self.assertRaises(c.QualificationStop):c.require_frozen_contract(altered,'CACHE_BINDING_SPEC.json')


class DynamicGuardTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.fixture=types.ModuleType('independent_generated_source_guard_fixture')
        cls.fixture.__source_guard_fixture__=True
        exec('''class GeneratedAccount:\n def __init__(self): pass\n def execute_fill(self): pass\nclass GeneratedSimulator:\n def __init__(self): pass\n def advance_day(self): pass\nclass CaseExecutionScope:\n def __init__(self): pass\nclass ActualProvider:\n def __call__(self): pass\n def __iter__(self): return self\ndef claim_launch(): pass\n''',cls.fixture.__dict__)
        sys.modules[cls.fixture.__name__]=cls.fixture
        cls.account=cls.fixture.GeneratedAccount()
    @classmethod
    def tearDownClass(cls):sys.modules.pop(cls.fixture.__name__,None)
    def denied(self,category,callback):
        with tempfile.TemporaryDirectory(prefix='independent2025-') as d:
            guard=g.SourceOnlyGuard(write_roots=(Path(d),))
            with self.assertRaises(g.SourceBoundaryViolation):
                with guard:
                    try:callback(Path(d))
                    except g.SourceBoundaryViolation:pass
                    guard.checkpoint('CAUGHT_ATTEMPT_MUST_REMAIN_FATAL')
            self.assertGreater(guard.attempts[category],0)
            self.assertFalse(guard.active)
            BOUNDARY_OBSERVATIONS.append(guard.receipt('PASS_GENERATED_DENIAL_'+category))
            return guard
    def test_account_constructor_observed(self):self.denied('financial_constructors',lambda _:self.fixture.GeneratedAccount())
    def test_existing_account_advance_observed(self):self.denied('financial_account_advance',lambda _:self.account.execute_fill())
    def test_simulator_constructor_observed(self):self.denied('native_simulator_construct_or_advance',lambda _:self.fixture.GeneratedSimulator())
    def test_case_execution_scope_mint_observed(self):self.denied('historical_scope_mints',lambda _:self.fixture.CaseExecutionScope())
    def test_provider_call_observed(self):self.denied('actual_provider_calls',lambda _:self.fixture.ActualProvider()())
    def test_process_launch_observed_before_launch(self):self.denied('process_launches',lambda _:__import__('subprocess').run(['GENERATED_MUST_NOT_RUN']))
    def test_network_call_observed_before_network(self):self.denied('network_calls',lambda _:__import__('socket').create_connection(('generated.invalid',1)))
    def test_financial_import_observed_before_import(self):self.denied('financial_imports',lambda _:__import__('native_runtime'))
    def test_claim_helper_observed(self):self.denied('canonical_financial_claims_or_leases',lambda _:self.fixture.claim_launch())
    def test_claim_path_observed(self):self.denied('canonical_financial_claims_or_leases',lambda p:(p/'EXECUTION_CLAIMS').mkdir())
    def test_financial_go_filename_observed(self):self.denied('financial_GO_writes',lambda p:(p/'ROOT_GO.json').write_text('{}'))
    def test_financial_go_content_without_action_observed(self):self.denied('financial_GO_writes',lambda p:(p/'harmless.json').write_text('{"schema":"EXECUTABLE_FINANCIAL_GO"}'))
    def test_financial_authority_flag_observed(self):self.denied('financial_GO_writes',lambda p:json.dumps({'historical_execution_authorized':True}))
    def test_outside_source_write_observed(self):self.denied('outside_source_writes',lambda p:(p.parent/'generated_must_not_exist.txt').write_text('never'))
    def test_nonallowlisted_holdout_read_observed_before_open(self):self.denied('nonallowlisted_file_reads',lambda p:(ROOT/'holdout/2026-03.npz').read_bytes())
    def test_raw_writable_descriptor_observed_before_creation(self):self.denied('outside_source_writes',lambda p:os.open(p/'harmless.json',os.O_WRONLY|os.O_CREAT,0o600))
    def test_json_stream_buffer_escape_observed(self):
        def write(p):
            with (p/'harmless.json').open('w') as stream:stream.buffer.write(b'{"schema":"EXECUTABLE_FINANCIAL_GO"}')
        self.denied('financial_GO_writes',write)
    def test_clean_guard_has_observed_checkpoints_and_zero_attempts(self):
        with tempfile.TemporaryDirectory(prefix='independent2025-') as d:
            guard=g.SourceOnlyGuard(write_roots=(Path(d),))
            with guard:
                (Path(d)/'source_only.json').write_text('{"status":"SOURCE_ONLY","financial_execution_authorized":false}')
                guard.checkpoint('GENERATED_CLEAN_SOURCE_RUN')
            receipt=guard.receipt('GENERATED_ONLY')
            BOUNDARY_OBSERVATIONS.append(receipt)
            self.assertTrue(receipt['installed_blockers'])
            self.assertTrue(receipt['checkpoints'])
            self.assertFalse(any(receipt['forbidden_attempts'].values()))
            self.assertFalse(receipt['guard_active'])


if __name__=='__main__':
    os.sched_setaffinity(0,{3})
    unittest.main(verbosity=2)
