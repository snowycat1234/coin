"""Observed CPU3 independent generated-only runner; actual historical opens denied."""
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[key]='1'
import sys
sys.dont_write_bytecode=True
import hashlib
import json
from pathlib import Path
import time
import unittest
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
PACKAGE=ROOT/'full2025_selective_source_qualification_20261015_v2'
protected_suffixes=('.npz','.zip','.csv','.bin','.pkl','.pickle')
actual_attempts=[]
network_or_process_attempts=[]
workspace_opens={}
def audit(event,args):
    if event in ('subprocess.Popen','os.system','os.exec','os.posix_spawn','os.fork','socket.connect','socket.getaddrinfo'):
        network_or_process_attempts.append(event)
        raise RuntimeError('INDEPENDENT_REVIEW_EXTERNAL_EFFECT_FORBIDDEN:'+event)
    if event!='open' or not args or not isinstance(args[0],(str,bytes,os.PathLike)):return
    path=Path(os.path.abspath(os.fsdecode(args[0])))
    if path==ROOT or ROOT in path.parents:
        name=str(path)
        if path.suffix.lower() in protected_suffixes or '.bytepart' in path.name or '/transport/' in name or '/source_runs/' in name:
            actual_attempts.append(name)
            raise RuntimeError('INDEPENDENT_REVIEW_ACTUAL_BODY_OPEN_FORBIDDEN:'+name)
        workspace_opens[name]=workspace_opens.get(name,0)+1
sys.addaudithook(audit)
os.sched_setaffinity(0,{3})
code_pins={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in PACKAGE.glob('*.py')}
started=time.monotonic();cpu=time.process_time()
suite=unittest.defaultTestLoader.loadTestsFromName('test_independent_generated')
result=unittest.TextTestRunner(verbosity=2).run(suite)
after_pins={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in PACKAGE.glob('*.py')}
receipt=dict(schema='OBSERVED_INDEPENDENT_FULL2025_GENERATED_REVIEW_TESTS_V1',
    status='PASS_GENERATED_ONLY' if result.wasSuccessful() and not actual_attempts and not network_or_process_attempts and code_pins==after_pins else 'FAIL_OR_UNSTABLE_CODE',
    tests_run=result.testsRun,failures=len(result.failures),errors=len(result.errors),
    code_before=code_pins,code_after=after_pins,code_stable_during_tests=code_pins==after_pins,
    observed_actual_source_open_attempts=actual_attempts,actual_source_body_reads=0,
    observed_network_or_process_attempts=network_or_process_attempts,
    observed_workspace_metadata_code_open_counts=workspace_opens,
    CPU_affinity=sorted(os.sched_getaffinity(0)),wall_seconds=time.monotonic()-started,CPU_seconds=time.process_time()-cpu,
    observed_generated_boundary_receipts=getattr(sys.modules.get('test_independent_generated'),'BOUNDARY_OBSERVATIONS',[]),
    test_scope='Pure/in-memory/generated-temp fixtures only. Injected launcher failure uses fake StageScope and fake qualifier; no actual source-stage scope is issued.')
receipt_path=Path(sys.argv[1]) if len(sys.argv)>1 else HERE/'GENERATED_INDEPENDENT_RECEIPT.json'
with receipt_path.open('x') as stream:json.dump(receipt,stream,sort_keys=True,indent=2);stream.write('\n')
raise SystemExit(0 if receipt['status']=='PASS_GENERATED_ONLY' else 1)
