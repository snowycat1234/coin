"""Finalize the narrow metadata/code/generated-only v2 review."""
from pathlib import Path
import datetime,hashlib,json
ROOT=Path(__file__).resolve().parent.parent
OUT=Path(__file__).resolve().parent
SOURCE=ROOT/'full2025_selective_source_qualification_20261015_v2'
OLD=ROOT/'full2025_selective_source_qualification_20261015'
OLD_REVIEW=ROOT/'full2025_selective_source_qualification_independent_review_20261015'
CODE='52e60cc8fa748b333f56eee7f28bc466b6342a1ff222ecf91f7fbc6dfa51a25d'
PACKAGE='c80b01eba58053c8d8d484e544467cccbdd2140a43ecda5d30027abcc63b2c1f'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(name,value):(OUT/name).write_text(json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n')
assert sha(SOURCE/'CODE_MANIFEST.json')==CODE and sha(SOURCE/'FROZEN_PACKAGE_MANIFEST.json')==PACKAGE
assert sha(SOURCE/'NARROW_V2_FIX_AND_PRESERVATION_RECEIPT.json')=='894fc1dc0709a57aa1aea8fcd856e27cd787dd24036312daa94220b5f8b5d17e'
manifest=json.loads((SOURCE/'CODE_MANIFEST.json').read_text())
for file in manifest['files']:
 p=SOURCE/file['file'];assert sha(p)==file['SHA256'] and p.stat().st_size==file['bytes']
tests=json.loads((OUT/'GENERATED_INDEPENDENT_RECEIPT.json').read_text())
assert tests['status']=='PASS_GENERATED_ONLY' and tests['tests_run']==60 and tests['failures']==tests['errors']==0
assert tests['code_before']==tests['code_after']=={r['file']:r['SHA256'] for r in manifest['files']}
assert not tests['observed_actual_source_open_attempts'] and not tests['observed_network_or_process_attempts']
delta=json.loads((OUT/'PIN_DELTA_CAUSE_REVIEW.json').read_text())
for row in delta['cause_receipt_pins']:
 p=ROOT/row['path'];assert sha(p)==row['SHA256'] and p.stat().st_size==row['bytes']
assert sha(OLD_REVIEW/'REVIEW.json')=='30022751f22b86afc3c508a20ab51341403b487f8841272dae9da72adc995295'
cache=json.loads((ROOT/'full2025_selective_source_qualification_plan_20261015/CACHE_BINDING_SPEC.json').read_text())
index=json.loads((ROOT/'native_2025_source_restore_20261015/metadata/H1_INDEX.json').read_text())
routes=[]
for part in index['parts']:
 original='research_artifacts/frozen_e5_2025h1_20261008/'+part['file_name']
 matches=[v for v in cache['objects'] if v['original_path']==original and v['original_commit']=='d69e9ac94478c5be54cb46c622afec7aaf3c61f7']
 assert len(matches)==1
 row=matches[0];assert row['expected']==dict(bytes=part['bytes'],SHA256=part['sha256'],GitBlobSHA1=part['git_blob_sha1'])
 routes.append(dict(file_name=part['file_name'],cache_path=row['cache_path'],original_path=original,original_commit=row['original_commit'],expected=row['expected']))
save('H1_NINE_ROUTE_METADATA_REVIEW.json',dict(status='PASS_METADATA_ONLY_NINE_EXACT_ROUTES',routes=routes,body_reads=0,opaque_bytes_reverified=False))
checks=[
 ('EXACT_V2_CLOSURE','The eight code files and sixteen frozen package members match all 24 size/hash pin rows. Exact code hashes are stable before and after independent tests.'),
 ('NARROW_TWO_FILE_DELTA','Only selection.py and test_generated_seams.py differ from v1. The other six code files, all eight prior seams, allowlists, pins, budgets, dynamic guards and authority boundaries remain unchanged.'),
 ('EXACT_NINE_H1_ROUTES','All nine actual metadata routes join canonical original repository path and fixed H1 commit to one unique frozen cache row, with exact bytes/SHA256/GitBlobSHA1 equality before a declared cache path is returned.'),
 ('RECOVERED_PART004','Part004 resolves to its recovered probe cache path already in the frozen 217-object map. The old numeric part-location heuristic, basename trust, aliases, discovery and alternate-path fallback are absent.'),
 ('ADVERSARIAL_RESOLVER','Independent generated negatives reject wrong hash, bytes, Git identity, commit, duplicate/no-match, malformed index inventories, filename aliases, mutated declared authority and old incorrect part004 path before any body helper call.'),
 ('SOURCE_STAGE_CAUSE_AND_PRESERVATION','The prior stopped stage is hash-bound and preserved: NONALLOWLISTED_CACHE_PATH after four H1 parts. Its receipt records all 217 opaque identities verified, zero selected 2025 bodies/canonical files and zero forbidden counters, with scope revoked. Review reads only metadata.'),
 ('GENERATED_ONLY_SCOPE','Independent 60/60 tests pass on CPU 3. Audit observes zero actual source/cache/archive opens and zero external process/network events. Eighteen generated boundary receipts retain observed denial/clean counters. No actual v2 source scope or run is issued.'),
 ('UNCHANGED_ADMISSION_AND_FAILURE_GATES','The launcher still requires fresh exact external source authority and a new authorization-derived output root. The invalid template remains invalid. No old code/review/STOP is edited; source completeness, actual v2 runtime counters and any later target/account/provider/finance remain pending.')]
review=dict(schema='INDEPENDENT_FULL2025_SELECTIVE_SOURCE_QUALIFIER_CODE_REVIEW_V1',status='PASS_SOURCE_ONLY_GENERATED_NO_FINANCIAL_GO',
 UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),code_manifest_SHA256=CODE,frozen_implementation_package_manifest_SHA256=PACKAGE,
 original_v1_code_manifest_SHA256='30aabbc0adbcb31f28e9ba222cf79a3dc0582aaf91ee9c4bcea3e0d81b1e0f96',
 original_v1_review_SHA256='30022751f22b86afc3c508a20ab51341403b487f8841272dae9da72adc995295',
 narrow_fix_receipt_SHA256='894fc1dc0709a57aa1aea8fcd856e27cd787dd24036312daa94220b5f8b5d17e',
 frozen_plan_SHA256='43d55792b548442a8e5d8fce56aade148c7f73ec668bf6400d9788df33b236c2',
 independent_plan_review_SHA256='993aead4dae9e9cbcc1346beba49d6346f38d5700c847bb80ad0070cb40d28b7',
 source_index_SHA256='8a0235e428902f7a0ea4ec1893343abae6ccc23715080771796b54fb58f1f3c4',
 complete_transport_receipt_SHA256='ab527c785ed1292cd90d866ef8f13ed9d17f2b11a5a52c1992e41a4670f5fbe9',
 opaque_cache_index_SHA256='a68b86a3bdf542625c8356b928e23ffea15eee53e11cd18d930b577a96313a4b',
 invalid_source_authorization_template_SHA256=sha(SOURCE/'SOURCE_AUTHORIZATION_TEMPLATE_INVALID.json'),
 cause_receipt_pins=delta['cause_receipt_pins'],prior_stopped_authority_SHA256='7b788d09bd45b8307bcef20d3dfd63e9239957179cc442c6a24720aa12ba19da',
 checks=[dict(id=i,status='PASS',finding=f) for i,f in checks],PASS_count=len(checks),FAIL_count=0,check_count=len(checks),
 inherited_original_semantic_checks=16,
 independent_generated_tests=dict(tests=60,failures=0,errors=0,CPU_affinity=[3],code_stable_before_after=True,
  observed_receipt='GENERATED_INDEPENDENT_RECEIPT.json',observed_receipt_SHA256=sha(OUT/'GENERATED_INDEPENDENT_RECEIPT.json'),
  actual_source_open_attempts=0,external_network_process_events=0,generated_boundary_receipts=18,
  wall_seconds=tests['wall_seconds'],CPU_seconds=tests['CPU_seconds']),
 author_generated_tests=50,actual_source_body_reads=0,opaque_transport_body_reads=0,historical_archive_central_directory_reads=0,
 historical_member_decompressions=0,historical_reassemblies=0,historical_normalizations=0,financial_runs=0,accounts_constructed=0,
 targets_generated=0,provider_iteration=0,claims_created=0,network_requests=0,
 actual_source_completeness_proved=False,actual_v2_qualifier_observed_counters=None,
 actual_v2_qualifier_observed_counters_status='NOT_RUN_REQUIRE_FRESH_ROOT_SOURCE_AUTHORIZATION',
 source_stage_authorization_granted_by_this_receipt=False,historical_execution_authorized=False,financial_execution_authorized=False,
 pending_gates=['Fresh exact external root source-only authorization for v2 and CPU8 release. Do not reuse the stopped v1 authorization.',
  'Bounded guarded actual v2 qualification and independent actual-source review.',
  'Any actual 2025 target/D/account/provider/financial work requires later separate exact authority.'],
 stopping_condition='Narrow v2 code/generated review complete. No actual source run was taken or authorized by this review.')
save('REVIEW.json',review)
(OUT/'REPORT.md').write_text('''# Narrow v2 H1 resolver review

PASS_SOURCE_ONLY_GENERATED_NO_FINANCIAL_GO.

The exact code manifest is 52e60cc8fa748b333f56eee7f28bc466b6342a1ff222ecf91f7fbc6dfa51a25d. Only selection.py and its generated tests differ from v1; the other six code files and prior safety seams remain exact. All 24 new code/package pin rows pass. The original package, review and stopped source-stage receipts are preserved.

Independent generated tests: 60/60 PASS on CPU 3, with exact stable code before/after and audit-observed actual source opens/network/process events zero. All nine real metadata routes were exercised with body helpers blocked. Recovered part004 resolves through the exact canonical original path + H1 commit + bytes/SHA256/Git identity join to the frozen cache map. Wrong identities, duplicate/no-match, aliases and the old incorrect part004 path reject before body access. The author separately supplied 50 passing generated tests.

The previous authorized v1 attempt stopped fail-closed at NONALLOWLISTED_CACHE_PATH after four H1 parts. Its preserved receipt records all 217 opaque identities verified, zero selected 2025 source bodies/canonical files, zero forbidden counters and revoked scope. This review opened only its metadata receipts and checked partial-file size without reading the partial wrapper or warmup body.

This is a code/generated-only PASS. No actual v2 source scope or run was issued. Source completeness and actual v2 observed runtime counters remain unproved. The included authorization template is invalid. A fresh exact root source-only authorization is required; no historical or financial authority is granted.
''')
record=dict(schema='INDEPENDENT_FULL2025_SOURCE_QUALIFIER_REVIEW_RECEIPT_V1',status=review['status'],REVIEW_SHA256=sha(OUT/'REVIEW.json'),
 code_manifest_SHA256=CODE,frozen_implementation_package_manifest_SHA256=PACKAGE,
 independent_generated_receipt_SHA256=sha(OUT/'GENERATED_INDEPENDENT_RECEIPT.json'),invalid_source_template_SHA256=review['invalid_source_authorization_template_SHA256'],
 PASS_count=8,FAIL_count=0,independent_generated_tests=60,actual_source_body_reads=0,actual_source_completeness_proved=False,
 source_stage_authorization_granted=False,historical_execution_authorized=False,financial_execution_authorized=False)
save('INDEPENDENT_REVIEW_RECEIPT.json',record)
files=[dict(file=p.name,bytes=p.stat().st_size,SHA256=sha(p)) for p in sorted(OUT.iterdir()) if p.is_file() and p.name!='FROZEN_MANIFEST.json']
save('FROZEN_MANIFEST.json',dict(schema='FROZEN_INDEPENDENT_FULL2025_SOURCE_QUALIFIER_CODE_REVIEW_V1',status=review['status'],code_manifest_SHA256=CODE,files=files,
 actual_source_completeness_proved=False,financial_execution_authorized=False))
print(json.dumps(dict(status=review['status'],REVIEW_SHA256=sha(OUT/'REVIEW.json'),receipt_SHA256=sha(OUT/'INDEPENDENT_REVIEW_RECEIPT.json'),
 frozen_manifest_SHA256=sha(OUT/'FROZEN_MANIFEST.json'),invalid_source_template_SHA256=review['invalid_source_authorization_template_SHA256'],review_files=len(files)),indent=2))
