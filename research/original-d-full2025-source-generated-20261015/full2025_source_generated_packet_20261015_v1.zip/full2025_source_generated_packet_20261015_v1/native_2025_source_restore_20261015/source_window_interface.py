"""Exact 2025 source reader. Never load the risk/target files named in old provenance."""
from pathlib import Path
import hashlib,json
import numpy as np
INDEX_SHA256='8a0235e428902f7a0ea4ec1893343abae6ccc23715080771796b54fb58f1f3c4'
S=('BTCUSDT','ETHUSDT','SOLUSDT','XRPUSDT','DOGEUSDT')
def _verify(p,size,digest):
 b=p.read_bytes()
 if len(b)!=size or hashlib.sha256(b).hexdigest()!=digest:raise ValueError('Changed source bytes: '+p.name)
 return b

def verified_source_window(source_root):
 root=Path(source_root);index=json.loads(_verify(root/'SOURCE_INDEX.json',83031,INDEX_SHA256))
 if index['calendar']!=[1735689600000000,1767225600000000] or tuple(index['symbol_order'])!=S or index['funding_events']!=5475:raise ValueError('Unexpected2025 source contract')
 for m in index['months']:_verify(root/'months'/(m['month']+'.npz'),m['source_NPZ_bytes'],m['source_NPZ_SHA256'])
 records={n:json.loads(_verify(root/n,index['files'][n]['bytes'],index['files'][n]['SHA256'])) for n in ('DAILY.json','EVENTS.json')}
 def minute_blocks():
  for m in index['months']:
   p=root/'months'/(m['month']+'.npz');_verify(p,m['source_NPZ_bytes'],m['source_NPZ_SHA256'])
   with np.load(p,allow_pickle=False) as z:
    for i in range(0,m['minutes'],1440):yield dict(times=z['times'][i:i+1440].copy(),market={s:{f:z[s+'_'+f][i:i+1440].copy() for f in ('open','close','quote_volume','mark')} for s in S})
 return dict(start=index['calendar'][0],end=index['calendar'][1],symbols=S,daily=records['DAILY.json'],events=records['EVENTS.json'],minute_blocks=minute_blocks,derived_mark_cells=0,role='ALREADY_SEEN_2025_DEVELOPMENT_EXACT_RAW_SOURCE',original_initial_trade_boundary=index['initial_trade_boundary'],original_initial_mark_boundary=index['initial_mark_boundary'])
