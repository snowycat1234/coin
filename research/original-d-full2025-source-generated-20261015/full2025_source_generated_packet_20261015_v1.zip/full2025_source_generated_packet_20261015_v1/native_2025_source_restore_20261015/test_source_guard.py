"""Synthetic guard and source-reader static tests; no source or financial runs."""
import ast,hashlib,json,unittest
from pathlib import Path
R=Path(__file__).resolve().parent
class GuardTests(unittest.TestCase):
 def test_exact_read_allowlist(self):
  t=ast.parse((R/'normalize_source_only.py').read_text());f=next(x for x in t.body if isinstance(x,ast.FunctionDef) and x.name=='guarded_read');m=ast.fix_missing_locations(ast.Module(body=[f],type_ignores=[]));calls=[]
  class Fake:
   def read(self,name):calls.append(name);return b'raw-source'
  n=dict(wrapper_allowed={'wrapper':{'raw/allowed.zip'}},wrappers={'wrapper':Fake()},body_reads=[],digest=lambda b:hashlib.sha256(b).hexdigest());exec(compile(m,'guard_only','exec'),n)
  self.assertEqual(n['guarded_read']('wrapper','raw/allowed.zip'),b'raw-source')
  for path in ['models/model.pkl','accounts/STATE.json.gz','Y2025.npz','features2025/EXPERTS.npz','../raw/allowed.zip']:
   with self.assertRaisesRegex(ValueError,'EXCLUDED_MEMBER_BODY_REQUEST'):n['guarded_read']('wrapper',path)
  self.assertEqual(calls,['raw/allowed.zip'])
 def test_pure_normalizer_functions(self):
  t=ast.parse((R/'metadata/original_normalize.py').read_text());names={'PRICE_COLUMNS','FUND_COLUMNS','month_limits','numeric_csv','deduplicate','validate_price','validate_funding'};self.assertEqual(len([x for x in t.body if getattr(x,'name',None) in names]),5)
 def test_input_allowlist_source_only(self):
  a=json.loads((R/'metadata/SOURCE_MEMBER_ALLOWLIST.json').read_text());self.assertEqual(len(a),180);self.assertEqual({x['symbol'] for x in a},{'BTCUSDT','ETHUSDT','SOLUSDT','XRPUSDT','DOGEUSDT'});self.assertEqual({x['family'] for x in a},{'klines','markPriceKlines','fundingRate'});self.assertTrue(all(x['month'].startswith('2025-') for x in a))
 def test_reader_excludes_old_outputs(self):
  text=(R/'source_window_interface.py').read_text();self.assertIn("for n in ('DAILY.json','EVENTS.json')",text);self.assertNotIn("for n,r in index['files'].items()",text)
if __name__=='__main__':unittest.main()
