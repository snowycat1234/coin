"""2025 raw-source restoration only. No target, risk, account, or model imports."""
from pathlib import Path
import ast,collections,datetime,hashlib,io,json,os,resource,time,zipfile
import numpy as np
import pandas as pd
R=Path(__file__).resolve().parent;M=R/'metadata';OUT=R/'prepared_2025';S=('BTCUSDT','ETHUSDT','SOLUSDT','XRPUSDT','DOGEUSDT');DAY=86400000000;MINUTE=60000000;START=1735689600000000;END=1767225600000000
os.sched_setaffinity(0,{min(os.sched_getaffinity(0))});resource.setrlimit(resource.RLIMIT_AS,(2000000000,2000000000));resource.setrlimit(resource.RLIMIT_CPU,(300,300));began=time.monotonic()
def digest(b):return hashlib.sha256(b).hexdigest()
def sha(p):return digest(Path(p).read_bytes())
def read(n):return json.loads((M/n).read_text())
def save(p,v):Path(p).write_text(json.dumps(v,sort_keys=True,indent=2,allow_nan=False)+'\n')
index=read('SOURCE_INDEX.json');plan=read('TRANSFER_PLAN.json');allow=read('SOURCE_MEMBER_ALLOWLIST.json');h2=read('H2_INDEX.json');h1=read('H1_INDEX.json');assert sha(M/'SOURCE_INDEX.json')==plan['source_index_SHA256'];assert not OUT.exists()
assert sha(M/'original_normalize.py')=='ee394086066c96bc23e83b45bf0bc2777264ab4eb57128886394fee47fecd4ff'
download=json.loads((R/'DOWNLOAD_RECEIPT.json').read_text())
assert download['status']=='PASS_ALL_PART_IDENTITIES' and download['verified_bytes']==156670939, 'SOURCE_TRANSPORT_INCOMPLETE_NO_NORMALIZATION'
# Load only immutable, pure numeric source transforms. No original module imports.
tree=ast.parse((M/'original_normalize.py').read_text());names={'PRICE_COLUMNS','FUND_COLUMNS','month_limits','numeric_csv','deduplicate','validate_price','validate_funding'};nodes=[];found=set()
for node in tree.body:
 n=getattr(node,'name',None)
 if isinstance(node,ast.Assign) and len(node.targets)==1:n=getattr(node.targets[0],'id',None)
 if n in names:nodes.append(node);found.add(n)
assert found==names
mod=ast.Module(body=[ast.ImportFrom(module='__future__',names=[ast.alias(name='annotations')],level=0),*nodes],type_ignores=[]);ns=dict(np=np,pd=pd,Path=Path,zipfile=zipfile);exec(compile(ast.fix_missing_locations(mod),'PINNED_NORMALIZER_PURE_AST_ONLY','exec'),ns)
normalizer_sha=sha(M/'original_normalize.py');extracted=ast.unparse(mod);(R/'PURE_NORMALIZER_AST.py').write_text(extracted+'\n')
# Reconstitute only the already hash-verified mixed market-source wrapper.
W=R/'wrappers';W.mkdir(exist_ok=True);hp=W/'H1_2025.zip'
if not hp.exists():
 with hp.open('xb') as f:
  for p in h1['parts']:f.write((R/'transport/H1'/p['file_name']).read_bytes())
assert hp.stat().st_size==h1['original_bytes'] and sha(hp)==h1['original_sha256']
fundpath=R/'transport/PRIMITIVES.zip';assert sha(fundpath)==read('FUNDING_MANIFEST.json')['SHA256']
wrapper_allowed=collections.defaultdict(set)
for a in allow:
 if 'member' not in a:continue
 p=hp if a['transport']=='H1_WRAPPER' else fundpath if a['transport']=='FUNDING_PRIMITIVES' else Path(a['wrapper'])
 wrapper_allowed[p].add(a['member'])
 if 'checksum_member' in a:wrapper_allowed[p].add(a['checksum_member'])
wrappers={};body_reads=[]
for p,names in wrapper_allowed.items():
 if p not in [hp,fundpath]:
  expected=next(a['wrapper_SHA256'] for a in allow if a.get('wrapper')==str(p));assert sha(p)==expected
 z=zipfile.ZipFile(p);allnames=z.namelist();assert len(allnames)==len(set(allnames));assert names.issubset(allnames);wrappers[p]=z

def guarded_read(p,name):
 if p not in wrapper_allowed or name not in wrapper_allowed[p]:raise ValueError('EXCLUDED_MEMBER_BODY_REQUEST:'+name)
 b=wrappers[p].read(name);body_reads.append(dict(wrapper=str(p),member=name,bytes=len(b),SHA256=digest(b)));return b

def raw(a):
 if a['transport']=='H2_RAW_PARTS':
  x=next(v for v in h2['archives'] if v['raw_path']==a['raw_path']);b=b''.join((R/'transport/H2'/p['file']).read_bytes() for p in x['parts']);c=(R/'transport/H2'/x['checksum_file']).read_bytes();assert digest(c)==x['checksum_SHA256'];assert c.decode().split()[0]==a['SHA256']
 else:
  p=hp if a['transport']=='H1_WRAPPER' else fundpath if a['transport']=='FUNDING_PRIMITIVES' else Path(a['wrapper']);b=guarded_read(p,a['member'])
  if 'checksum_member' in a:assert guarded_read(p,a['checksum_member']).decode().split()[0]==a['SHA256']
 assert len(b)==a['bytes'] and digest(b)==a['SHA256']
 # A single inner CSV is a selected raw-source member, never a mixed wrapper scan.
 with zipfile.ZipFile(io.BytesIO(b)) as z:assert len(z.infolist())==1
 f=io.BytesIO(b);f.name=a.get('raw_path',a.get('member','source.zip'));return f

OUT.mkdir();(OUT/'months').mkdir();daily=[];trade_daily={};prior={};proof=[]
# This is a genuine prior source close, replacing the original mixed feature cube.
p24=R.parent/'native_2024_source_restore_20261015/prepared_2024';ix24=json.loads((p24/'SOURCE_INDEX.json').read_text());dec24=next(x for x in ix24['months'] if x['month']=='2024-12');zpath=p24/'months/2024-12.npz';assert sha(zpath)==dec24['source_NPZ_SHA256']
with np.load(zpath,allow_pickle=False) as z:initial={s:float(z[s+'_close'][-1]) for s in S}
for m in range(1,13):
 stamp=f'2025-{m:02d}';lo,hi=ns['month_limits'](2025,m);times=np.arange(lo*1000,hi*1000,MINUTE,dtype=np.int64);arrays=dict(times=times);old=next(x for x in index['months'] if x['month']==stamp)
 for s in S:
  for family in ('klines','markPriceKlines'):
   a=next(x for x in allow if (x['month'],x['symbol'],x['family'])==(stamp,s,family));f,dups=ns['validate_price'](ns['numeric_csv'](raw(a)),family,lo,hi);assert dups==0;np.testing.assert_array_equal(f.timestamp_ms.to_numpy()*1000,times)
   if family=='klines':
    for k in ('open','close','quote_volume'):arrays[s+'_'+k]=f[k].to_numpy()
    for i,at in enumerate(range(lo*1000,hi*1000,DAY)):
     actual=initial[s] if at==START else prior[s] if i==0 else float(f.close.iloc[i*1440-1]);daily.append(dict(symbol=s,close_us=at,close=actual));trade_daily[s,at+DAY]=float(f.close.iloc[(i+1)*1440-1])
    prior[s]=float(f.close.iloc[-1])
   else:arrays[s+'_mark']=f.close.to_numpy()
   proof.append(dict(month=stamp,symbol=s,family=family,bytes=a['bytes'],SHA256=a['SHA256'],rows=len(f),exact_grid=True,selected_inner_CRC=True))
 np.savez_compressed(OUT/'months'/(stamp+'.npz'),**arrays);path=OUT/'months'/(stamp+'.npz');assert path.stat().st_size==old['source_NPZ_bytes'] and sha(path)==old['source_NPZ_SHA256'],('MONTHLY_HASH',stamp,sha(path));print(json.dumps(dict(month=stamp,status='EXACT_ORIGINAL_MONTH_HASH_PASS',elapsed_seconds=round(time.monotonic()-began,3))),flush=True)
 del f,arrays
# Original funding normalizer, raw rates and event clocks preserved.
events=[]
for s in S:
 for m in range(1,13):
  stamp=f'2025-{m:02d}';a=next(x for x in allow if (x['month'],x['symbol'],x['family'])==(stamp,s,'fundingRate'));lo,hi=ns['month_limits'](2025,m);f,dups=ns['validate_funding'](ns['numeric_csv'](raw(a),funding=True),lo,hi);assert dups==0
  for row in f.itertuples(index=False):events.append(dict(symbol=s,event_us=int(row.calc_time_ms)*1000,raw_rate=float(row.last_funding_rate),reported_interval_hours=float(row.funding_interval_hours)))
  proof.append(dict(month=stamp,symbol=s,family='fundingRate',bytes=a['bytes'],SHA256=a['SHA256'],rows=len(f),selected_inner_CRC=True))
events.sort(key=lambda x:(x['event_us'],x['symbol']));assert len(events)==5475
save(OUT/'DAILY.json',daily);save(OUT/'EVENTS.json',events)
for name in ('DAILY.json','EVENTS.json'):
 old=index['files'][name];p=OUT/name;assert p.stat().st_size==old['bytes'] and sha(p)==old['SHA256'],('SOURCE_FILE_HASH',name,sha(p))
(OUT/'SOURCE_INDEX.json').write_bytes((M/'SOURCE_INDEX.json').read_bytes())
for z in wrappers.values():z.close()
save(R/'RAW_SOURCE_RESTORE_RECEIPT.json',dict(status='PASS_EXACT_180_RAW_SOURCE_ARCHIVES',raw_archives=proof,wrapper_member_body_reads=body_reads,read_guard='ONLY_EXACT_180_RAW_ARCHIVES_AND120_PRICE_CHECKSUMS',excluded_body_reads=0,whole_wrapper_testzip_calls=0,original_normalizer_SHA256=normalizer_sha,pure_AST_SHA256=sha(R/'PURE_NORMALIZER_AST.py'),provider_requests=0,accounts_constructed=0,financial_runs=0))
files=[dict(file='months/'+x['month']+'.npz',bytes=x['source_NPZ_bytes'],SHA256=x['source_NPZ_SHA256']) for x in index['months']]+[dict(file=n,**index['files'][n]) for n in ('DAILY.json','EVENTS.json')]+[dict(file='SOURCE_INDEX.json',bytes=83031,SHA256=plan['source_index_SHA256'])]
save(R/'VERIFIED_SOURCE_RECEIPT.json',dict(status='PASS_EXACT_2025_SOURCE_BYTES',calendar_us=[START,END],symbols=list(S),days=365,minutes_per_asset=525600,daily_records=len(daily),funding_events=len(events),derived_mark_cells=0,normalization_bytes=sum(x['bytes'] for x in files),exact_normalized_files=files,initial_daily_close=dict(source_month='2024-12',source_NPZ_SHA256=dec24['source_NPZ_SHA256'],values=initial,actual_trade_source=True),excluded_original_index_files_not_restored=['Y2025.npz','Y2025_RISK.json'],original_source_provenance_preserved=True,source_only_adapter_changes=['Pure normalizer AST only; no financial import graph','Raw allowlist excludes all outcome/model/account/target/risk bodies','DAILY initial source uses actual2024 terminal trade closes; subsequent actual2025 closes','Original SOURCE_INDEX bytes retained; old risk/target files named therein excluded'],elapsed_seconds=round(time.monotonic()-began,3),provider_requests=0,accounts_constructed=0,financial_runs=0))
print('PASS_EXACT_2025_SOURCE_BYTES',round(time.monotonic()-began,3),flush=True)
