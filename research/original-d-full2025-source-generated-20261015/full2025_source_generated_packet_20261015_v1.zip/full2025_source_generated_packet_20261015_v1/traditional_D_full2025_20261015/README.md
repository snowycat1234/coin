# Original D full2025 source and driver scaffold

This package is generated-only until a fresh exact source-stage authority is
supplied after independent review. The source-only actual-source audit is PASS;
it authorizes neither targets nor historical financial execution.

The adapter uses the reviewed canonical 12 monthly NPZ files, DAILY/EVENTS/INDEX,
saved 200-close warmup and genuine Dec31 witness directly. It never opens raw
archives or reruns source normalization. Inputs are captured once per process,
immutable byte-backed numeric arrays retain exact bits, and providers only
iterate after a separate exact historical scope. Financial cases load saved
review-bound targets/covariances without rebuilding them in callbacks.

The fixed nine-cell manifest precedes outcomes. Original frozen D finance,
GUARD50 paidreduce, no-transfer/topup rule, native scheduler, source latency,
BASE27 and coarse profile are reused. The year is already-seen DEV. There is no
OOS, exchange liquidation, venue-filter, arrival, funding-unit or 2026 claim.

Source preparation is a guarded distinct stage: 300 CPU seconds, 900 wall,
256MiB output. It may save365 decisions, nine deterministic paths/covariances and
nine ephemeral metadata callbacks, which are revoked before return. It must
observe zero finance constructors/advance, provider iteration, historical
scope mints, process/network launch, canonical claims and financial GO writes.

The financial runner is dormant until new source/generated financial review and
external root GO, with max2 workers,600s/2GB RSS/4GB AS/250MB percase and3.5GB
aggregate. Permanent claims, inherited flock, no retries/resume, paidflat versus
conditional/HALT taxonomy and authoritative chronological native40 proof remain
required. Stored-delta raw100 residuals are retained separately.

Use run_generated_checks.py for generated-only tests. Prior failed generated
logs remain explicitly superseded; no prior source or financial artifact changed.
No publication is authorized. INVALID templates do not authorize any work.
