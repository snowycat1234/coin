"""Direct exact canonical NPZ/JSON transport; no raw archive or normalization route.
Pure generated seams share all schema and original deterministic target functions.
Actual capture requires separate source authority. Saved target loading never
rebuilds strategies/covariances during a case or provider callback.
"""
from io import BytesIO
import calendar,datetime,json,sys,zipfile
from pathlib import Path
from types import MappingProxyType
import numpy as np
import polars as pl
import full_source as s
_MONTHS={};_CAPTURED={};_BASE={}
def frozen_array(a):return np.frombuffer(a.tobytes(),dtype=a.dtype).reshape(a.shape)

def numeric_archive(raw,shapes,dtypes):
    """Validate every exact NPY header and payload length before allocating."""
    if type(raw) is not bytes:raise ValueError('EXACT_NUMERIC_ARCHIVE_BYTES_REQUIRED')
    try:
        with zipfile.ZipFile(BytesIO(raw)) as archive:
            infos=archive.infolist();names=[i.filename for i in infos]
            if len(names)!=len(set(names)) or set(names)!={k+'.npy' for k in shapes}:raise ValueError('EXACT_NUMERIC_ARRAY_NAMESPACE_REQUIRED')
            for info in infos:
                key=info.filename[:-4]
                if info.is_dir() or info.flag_bits&1 or info.file_size>67108864:raise ValueError('EXACT_BOUNDED_NUMERIC_MEMBER_REQUIRED')
                with archive.open(info) as stream:
                    version=np.lib.format.read_magic(stream)
                    if version not in ((1,0),(2,0)):raise ValueError('SUPPORTED_NUMPY_HEADER_REQUIRED')
                    reader=np.lib.format.read_array_header_1_0 if version==(1,0) else np.lib.format.read_array_header_2_0
                    shape,fortran,dtype=reader(stream,max_header_size=4096)
                    if shape!=shapes[key] or dtype!=np.dtype(dtypes[key]) or dtype.hasobject or fortran:raise ValueError('EXACT_NUMERIC_HEADER_SCHEMA_REQUIRED')
                    if stream.tell()+int(np.prod(shape))*dtype.itemsize!=info.file_size:raise ValueError('EXACT_NUMERIC_PAYLOAD_LENGTH_REQUIRED')
        with np.load(BytesIO(raw),allow_pickle=False) as z:return {k:z[k].copy() for k in shapes}
    except (zipfile.BadZipFile,EOFError,OSError) as exc:raise ValueError('EXACT_NUMERIC_ARCHIVE_REQUIRED') from exc

def month_arrays(raw,start,count,quality_cells=()):
    if type(raw) is not bytes or type(start) is not int or type(count) is not int or not 0<count<=44640 or quality_cells:raise ValueError('EXACT_GENUINE_MONTH_SOURCE_REQUIRED')
    key=(s.sha(raw),start,count)
    if key in _MONTHS:return _MONTHS[key],()
    needed={'times'}|{symbol+'_'+k for symbol in s.S for k in ('open','close','quote_volume','mark')}
    arrays=numeric_archive(raw,{k:(count,) for k in needed},{k:'int64' if k=='times' else 'float64' for k in needed})
    for k,a in arrays.items():
        dtype=np.dtype('int64' if k=='times' else 'float64')
        if a.dtype!=dtype or a.shape!=(count,) or not np.isfinite(a).all():raise ValueError('EXACT_FINITE_MONTH_SCHEMA_REQUIRED')
        if k!='times' and ((a<0).any() or not k.endswith('_quote_volume') and (a<=0).any()):raise ValueError('GENUINE_POSITIVE_PRICES_NONNEGATIVE_VOLUME_REQUIRED')
        arrays[k]=np.frombuffer(a.tobytes(),dtype=a.dtype).reshape(a.shape)
    if not np.array_equal(arrays['times'],np.arange(start,start+count*s.MINUTE,s.MINUTE,dtype=np.int64)):raise ValueError('EXACT_NATIVE_OPEN_COMPLETION_CLOCKS_REQUIRED')
    _MONTHS[key]=MappingProxyType(arrays);return _MONTHS[key],()

def daily_inputs(warmup_raw,daily_raw):
    warm=numeric_archive(warmup_raw,{'close_available_us':(200,),'close':(200,5)},{'close_available_us':'int64','close':'float64'})
    wt,wc=warm['close_available_us'],warm['close']
    if (wt.dtype!=np.dtype('int64') or wt.shape!=(200,) or wc.dtype!=np.dtype('float64') or wc.shape!=(200,5)
        or not np.array_equal(wt,np.arange(s.START-199*s.DAY,s.START+s.DAY,s.DAY,dtype=np.int64))
        or not np.isfinite(wc).all() or (wc<=0).any()):raise ValueError('EXACT200_PAST_ONLY_WARMUP_SCHEMA_REQUIRED')
    daily=s.object_json(daily_raw)
    if type(daily) is not list or len(daily)!=1825:raise ValueError('EXACT365_DAILY_CORE5_ROWS_REQUIRED')
    by={}
    for row in daily:
        if (type(row) is not dict or set(row)!={'symbol','close_us','close'} or row['symbol'] not in s.S
            or type(row['close_us']) is not int or not s.START<=row['close_us']<s.END or row['close_us']%s.DAY
            or type(row['close']) not in (int,float) or not np.isfinite(row['close']) or row['close']<=0):raise ValueError('EXACT_PAST_ONLY_DAILY_SCHEMA_VALUES_REQUIRED')
        key=row['close_us'],row['symbol']
        if key in by:raise ValueError('DUPLICATE_DAILY_SOURCE_CELL')
        by[key]=float(row['close'])
    times=np.arange(s.START,s.END,s.DAY,dtype=np.int64)
    if set(by)!={(int(t),symbol) for t in times for symbol in s.S}:raise ValueError('COMPLETE_DAILY_CORE5_GRID_REQUIRED')
    prices=np.array([[by[int(t),symbol] for symbol in s.S] for t in times],dtype=np.float64)
    if prices[0].tobytes()!=wc[-1].tobytes():raise ValueError('EXACT_WARMUP_JAN1_NATIVE_PRIOR_CLOSE_PARITY_REQUIRED')
    clocks=np.concatenate((wt[:-1],times));close=np.vstack((wc[:-1],prices))
    rows=tuple(MappingProxyType(dict(symbol=symbol,close_us=int(t),available_us=int(t),close=float(close[i,j]))) for i,t in enumerate(clocks) for j,symbol in enumerate(s.S))
    frame=pl.DataFrame([dict(symbol=symbol,close_us=int(t),close=float(prices[i,j])) for i,t in enumerate(times) for j,symbol in enumerate(s.S)])
    projection=dict(schema='FULL2025_PAST_ONLY_564_PROJECTED_CLOSES_V1',fields=['close_available_us','close'],rows=564,
        calendar=[s.ALLOWED_START,s.END-s.DAY],strictly_before_us=s.END,selected_2026_daily_cube_rows=0,
        decisions=365,ready_200close_windows=365,endpoint_origin='GENUINE_DEC31_2359_NATIVE_BAR_ONLY')
    clocks,close,times=(frozen_array(a) for a in (clocks,close,times))
    return clocks,close,times,rows,frame,projection

def original_grid():
    if str(s.FROZEN) not in sys.path:sys.path.insert(0,str(s.FROZEN))
    import frozen_grid as g
    if Path(g.__file__).resolve()!=s.FROZEN/'frozen_grid.py':raise ValueError('EXACT_FROZEN_ORIGINAL_TARGET_MODULE_REQUIRED')
    # Pin is in the reviewed dependency closure, independent of ambient import.
    pins=json.loads((s.HERE/'DEPENDENCY_PINS.json').read_bytes());pin=pins[str((s.FROZEN/'frozen_grid.py').relative_to(s.ROOT))]
    s.exact(g.__file__,pin['SHA256'],pin['bytes'])
    return g

def project_daily_grid(warmup_raw,daily_raw):
    clocks,close,decisions,rows,daily,projection=daily_inputs(warmup_raw,daily_raw)
    d,targets,covariance,proofs=original_grid().build_target_grid(close,clocks,clocks.copy(),decisions)
    if len(d)!=365 or set(targets)!=set(s.CONFIGS):raise ValueError('EXACT365_NINE_ORIGINAL_TARGET_PATHS_REQUIRED')
    d=frozen_array(d);covariance=frozen_array(covariance);targets={k:frozen_array(a) for k,a in targets.items()}
    return d,targets,covariance,proofs,rows,daily,projection

def capture(root,*,source_authorization_raw,expected_source_authorization_sha256):
    s.require_source_stage_authority(source_authorization_raw,expected_source_authorization_sha256)
    root=Path(root).resolve()
    if root!=s.SOURCE_ROOT.resolve():raise ValueError('EXACT_PINNED_QUALIFIED_2025_SOURCE_ROOT_REQUIRED')
    metadata=s.metadata_pins();pins=metadata['files'];key=(str(root),s.METADATA_PINS_SHA256)
    if key not in _CAPTURED:
        raw={name:s.exact(s.ROOT/name,p['SHA256'],p['bytes']) for name,p in pins.items()}
        _CAPTURED[key]=MappingProxyType(raw)
    captured=_CAPTURED[key]
    for name,pin in pins.items():
        if s.sha(captured[name])!=pin['SHA256'] or len(captured[name])!=pin['bytes']:raise ValueError('IMMUTABLE_CAPTURE_SOURCE_IDENTITY_CHANGED')
    return captured,pins

def validate_captured_files(pins):
    available={name:raw for capture in _CAPTURED.values() for name,raw in capture.items()}
    for name,sha,size in pins:
        if name not in available or len(available[name])!=size or s.sha(available[name])!=sha:raise ValueError('CURRENT_IMMUTABLE_CANONICAL_CAPTURE_REQUIRED')
    return True

def base_projection(root,*,source_authorization_raw,expected_source_authorization_sha256):
    captured,pins=capture(root,source_authorization_raw=source_authorization_raw,expected_source_authorization_sha256=expected_source_authorization_sha256)
    if s.METADATA_PINS_SHA256 in _BASE:return _BASE[s.METADATA_PINS_SHA256]
    prefix=str(s.SOURCE_ROOT.relative_to(s.ROOT))+'/'
    get=lambda n:captured[prefix+n]
    qraw=get('SOURCE_QUALIFICATION_RECEIPT.json');q=s.SourceQualificationBinding.validate(s.object_json(qraw),qualification_sha256=s.sha(qraw))
    clocks,close,decisions,rows,daily,projection=daily_inputs(get('SOURCE_WARMUP_200_CLOSE_ONLY.npz'),get('prepared_2025/DAILY.json'))
    events=s.object_json(get('prepared_2025/EVENTS.json'))
    if type(events) is not list or len(events)!=5475 or len({(e.get('event_us'),e.get('symbol')) for e in events})!=5475:raise ValueError('EXACT5475_ORIGINAL_RAW_FUNDING_EVENTS_REQUIRED')
    for e in events:
        if (set(e)!={'symbol','event_us','raw_rate','reported_interval_hours'} or e['symbol'] not in s.S
            or type(e['event_us']) is not int or not s.START<=e['event_us']<s.END
            or type(e['raw_rate']) not in (int,float) or not np.isfinite(e['raw_rate'])
            or type(e['reported_interval_hours']) not in (int,float) or e['reported_interval_hours']!=8):raise ValueError('RAW_FUNDING_SCHEMA_UNIT_CLOCK_PRESERVATION_REQUIRED')
    if events!=sorted(events,key=lambda e:(e['event_us'],e['symbol'])):raise ValueError('ORIGINAL_FUNDING_CLOCK_AND_SYMBOL_ORDER_REQUIRED')
    provider=[];final=None
    for month in range(1,13):
        start=int(datetime.datetime(2025,month,1,tzinfo=datetime.timezone.utc).timestamp())*1000000
        count=calendar.monthrange(2025,month)[1]*1440;name='prepared_2025/months/2025-%02d.npz'%month;raw=get(name)
        a,_=month_arrays(raw,start,count,())
        for at in range(start+s.DAY,start+count*s.MINUTE+1,s.DAY):
            if at==s.END:continue
            k=(at-s.ALLOWED_START)//s.DAY
            for j,symbol in enumerate(s.S):
                if np.float64(a[symbol+'_close'][(at-start)//s.MINUTE-1]).tobytes()!=np.float64(close[k,j]).tobytes():raise ValueError('GENUINE_NATIVE_TO_DAILY_CLOSE_PARITY_REQUIRED')
        provider.append((name,start,count,raw,0,count));final=a
    endpoint=s.object_json(get('SOURCE_DEC31_ENDPOINT_WITNESS.json'))
    if endpoint.get('no_2026_daily_cube_row') is not True or endpoint.get('no_execution_authority') is not True or len(endpoint.get('endpoints',[]))!=5:raise ValueError('GENUINE_DEC31_ONLY_ENDPOINT_REQUIRED')
    for row in endpoint['endpoints']:
        symbol=row.get('symbol')
        if (symbol not in s.S or row.get('native_minute_open_us')!=s.END-s.MINUTE or row.get('source_available_us')!=s.END
            or row.get('feature_row_created') is not False or row['trade_close']!=float(final[symbol+'_close'][-1])
            or row['mark_close']!=float(final[symbol+'_mark'][-1])):raise ValueError('EXACT_GENUINE_DEC31_ENDPOINT_PARITY_REQUIRED')
    sidecar=dict(schema='FULL2025_GENUINE_COMPLETE_SOURCE_CLOCK_V1',calendar=[s.START,s.END],cells=[],quality_intervals=[],derived_mark_cells=0,
        arrival_status='UNKNOWN_NOT_CERTIFIED',quality='GENUINE_COMPLETE_VALUES_ARRIVAL_UNCERTIFIED',funding_units='RAW_AS_FRACTION_CONDITIONAL_UNCERTIFIED',
        final_endpoint_close={symbol:float(final[symbol+'_close'][-1]) for symbol in s.S},endpoint_origin='GENUINE_DEC31_2359_NATIVE_BAR',
        endpoint_open_us=s.END-s.MINUTE,endpoint_completed_us=s.END,selected_2026_daily_cube_rows=0,
        source_completion_SHA256=s.FINAL_PINS,source_identity=q.source_identity,source_funding_coverage_is_not_ownership=True,
        earliest_native_coldstart_increase_us=s.START+s.MINUTE+1,funding_ownership='CURRENT_NATIVE_ACTUAL_QUANTITY_ONLY_AFTER_PAID_FILLS',
        terminal_signal_us=s.END-61*s.MINUTE,terminal_eligible_open_range=[s.END-60*s.MINUTE,s.END-s.MINUTE],
        availability_clock_semantics='OFFLINE_MODEL_COMPLETION_BOUNDARY',installation_clock_semantics='OFFLINE_MODEL_REPLAY_INSTALLATION',
        actual_publication_arrival_installation='UNKNOWN_NOT_CERTIFIED',certifies_liquidation=False,certifies_no_liquidation=False)
    window=MappingProxyType(dict(start=s.START,end=s.END,symbols=s.S,daily=daily,events=s.immutable(events),minute_blocks=s.CapturedMinuteProvider(2025,tuple(provider)),
        derived_mark_cells=0,original_missing_mark_open_ms=(),original_overlay_future_looking=False,original_overlay_execution_admitted=False,causal_mark_adapter=s.immutable(sidecar)))
    result=dict(source_files=pins,captured=captured,source_identity=q.source_identity,source_qualification=s.object_json(qraw),window=window,source_rows=rows,
        sidecar=sidecar,sidecar_raw=s.canonical(sidecar)+b'\n',projection=projection,quality_cells=(),quality_intervals=(),
        quality=dict(fullfive200_decisions=365,derived_mark_cells=0,actual_source=True,quality='GENUINE_COMPLETE_VALUES_ARRIVAL_UNCERTIFIED',arrival_status='UNKNOWN_NOT_CERTIFIED',publication_arrival_certified=False,funding_units_certified=False,native_venue_certified=False))
    _BASE[s.METADATA_PINS_SHA256]=result
    return result

def project(root,*,source_scope=None,source_authorization_raw=None,expected_source_authorization_sha256=None):
    from source_guard import current_guard
    if current_guard() is None or not current_guard().active:raise ValueError('WHOLE_INVOCATION_SOURCE_ONLY_GUARD_REQUIRED')
    s.require_source_stage_authority(source_authorization_raw,expected_source_authorization_sha256)
    base=base_projection(root,source_authorization_raw=source_authorization_raw,expected_source_authorization_sha256=expected_source_authorization_sha256)
    prefix=str(s.SOURCE_ROOT.relative_to(s.ROOT))+'/'
    d,targets,covariance,proofs,_,_,_=project_daily_grid(base['captured'][prefix+'SOURCE_WARMUP_200_CLOSE_ONLY.npz'],base['captured'][prefix+'prepared_2025/DAILY.json'])
    return dict(base,decisions=d,targets=targets,covariance=covariance,proofs=proofs)

def load_prepared_projection(root,artifacts):
    go=artifacts['SOURCE_PREP_GO.json']
    base=base_projection(root,source_authorization_raw=go,expected_source_authorization_sha256=s.sha(go))
    keys=set(s.CONFIGS)|{'decision_us','annual_covariance'}
    shapes={k:(365,) if k=='decision_us' else (365,5,5) if k=='annual_covariance' else (365,5) for k in keys}
    arrays=numeric_archive(artifacts['TARGETS.npz'],shapes,{k:'int64' if k=='decision_us' else 'float64' for k in keys})
    for k,a in arrays.items():
        shape=(365,) if k=='decision_us' else (365,5,5) if k=='annual_covariance' else (365,5)
        if a.dtype!=np.dtype('int64' if k=='decision_us' else 'float64') or a.shape!=shape or not np.isfinite(a).all():raise ValueError('EXACT_SAVED_TARGET_SCHEMA_REQUIRED')
        arrays[k]=frozen_array(a)
    if not np.array_equal(arrays['decision_us'],np.arange(s.START,s.END,s.DAY,dtype=np.int64)):raise ValueError('EXACT365_SAVED_DECISION_CLOCKS_REQUIRED')
    if s.object_json(artifacts['DAILY_SOURCE_PROJECTION.json'])!=base['projection'] or artifacts['MINUTE_MARK_PROVENANCE.json']!=base['sidecar_raw']:raise ValueError('EXACT_SAVED_SOURCE_PROJECTION_PROOFS_REQUIRED')
    return dict(base,decisions=arrays['decision_us'],targets={k:arrays[k] for k in s.CONFIGS},covariance=arrays['annual_covariance'],proofs=s.object_json(artifacts['TARGET_PROOFS.json']))
