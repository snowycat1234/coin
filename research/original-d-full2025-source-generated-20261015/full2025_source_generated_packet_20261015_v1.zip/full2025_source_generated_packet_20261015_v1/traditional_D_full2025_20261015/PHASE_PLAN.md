# Portable original D full2025 plan

Initial scope: new source/admission/finite-driver code plus generated-only tests.
No actual source-body decoding, actual targets, history, finance, claims or GO.
Expected review-ready time: 2026-10-15 14:13 UTC, subject to independent findings.

1. Pin exact final source-only receipt and independent actual-source review.
2. Reuse immutable qualified canonical NPZ/JSON directly. One capture per process;
   never raw ZIP replay or source normalization. Pure generated schema seams use
   exactly the same original deterministic strategy functions.
3. Separate source stage after independent new-code PASS and external root stage
   authority: all365 decisions, past200 closes, nine original targets/covariances,
   genuine Dec31 endpoint, funding raw units/owned-neutral clock caveats. Nine
   metadata-only scopes are individually revoked; all forbidden finance/provider
   iteration/process/claims/financialGO calls must be observed zero.
4. New financial source/generated review and external rootGO are required later.
   Original D GUARD50_EXIT_ONLY, BASE27, coarseprofile, fixedcash1000/isolated8500,
   no transfer/topup/newcapital, fresh10000, native markfirst/fullfundingbatch,
   32corners, latency/nativecaps and paidreduce/terminal behavior remain identical.
5. Fixed STATIC50/H090/VOL_MANAGED_HOLD x LOW/MID/HIGH manifest precedes outcomes.
   Full2025 is already-seen DEV, never OOS. No aliases/performance selection,
   no other years, no holdouts. Annual calendar Jan1 through Dec31 paid terminal.
6. Financial runner later: max2 distinctCPU workers, numericpool1 each,600s CPU/wall,
   2GB RSS/4GB AS/250MB percase/3.5GB aggregate, no retries, permanent dedupeclaims,
   inherited globalflock. All helper affinities observed; hostquota uncertified.
7. Native40 chronological saved-event reconstruction is authoritative. Raw100
   stored-delta residual retained separately. Strict paidflat/conditional/HALT/
   incomplete taxonomy, true debt and no HALT resume. Expected GO/review/prep
   bytes are supplied externally by caller. No publication currently authorized.
