"""Full2025 source metadata, direct canonical capture and separate authority.
Import has no market-body I/O. Canonical data is captured once per process,
immutable and hash-bound. The source stage never constructs or advances finance.
"""
from dataclasses import dataclass,field
from hashlib import sha256
import json,os,stat
from pathlib import Path
from types import MappingProxyType
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
FROZEN=ROOT/'traditional_three_tier_freeze_20261015'
S=('BTCUSDT','ETHUSDT','SOLUSDT','XRPUSDT','DOGEUSDT')
DAY=86400000000;MINUTE=60000000;YEAR=2025;START=1735689600000000;END=1767225600000000
DAYS=365;MINUTES=525600;ALLOWED_START=START-199*DAY;FULL_START=START
CONFIGS=tuple(s+'_'+t for s in ('STATIC50','H090','VOL_MANAGED_HOLD') for t in ('LOW','MID','HIGH'))
SOURCE_ROOT=ROOT/'full2025_selective_source_qualification_20261015_v2/source_runs/165270343bcc5c8ff8e54e9b6a0728e45e1a8643ae02bb7a59d6c03a446c7f44/qualified_source_only_pending_review'
FINAL_PINS=SOURCE_QUALIFICATION_SHA256='286c10b27e88da6fabf61d1c93f1375693b807183c132238dbcbb8f76d327cbb'
SOURCE_INDEPENDENT_REVIEW_SHA256='ed38099a903e003db750015f38cd92db0fccd2d090d96ca910f06144f90f8ee1'
SOURCE_REVIEW_PATH=ROOT/'full2025_qualified_source_v2_independent_review_20261015/REVIEW.json'
SOURCE_PREP_ACTION='PREPARE_EXACT_FULL2025_SOURCE_TARGETS_ONLY_NO_HISTORY'
METADATA_PINS_SHA256='aa00e8e97160609b633d9a7805ac26b6cd6bb9247d65fa51253fd61a46e68113'
SOURCE_STAGE_SCHEMA='ROOT_SOURCE_PREP_FULL2025_V1'

def sha(b):return sha256(b).hexdigest()
def plain(v):
    if hasattr(v,'items'):return {k:plain(x) for k,x in v.items()}
    if isinstance(v,(tuple,list)):return [plain(x) for x in v]
    return v
def canonical(v):return json.dumps(plain(v),sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def jsha(v):return sha(canonical(v))
def immutable(v):
    if isinstance(v,dict):return MappingProxyType({k:immutable(x) for k,x in v.items()})
    if isinstance(v,(tuple,list)):return tuple(immutable(x) for x in v)
    return v
def digest(v):
    if type(v) is not str or len(v)!=64 or any(c not in '0123456789abcdef' for c in v):raise ValueError('EXACT_LOWERCASE_SHA256_REQUIRED')
    return v
def object_json(raw):
    def pairs(rows):
        out={}
        for k,v in rows:
            if k in out:raise ValueError('DUPLICATE_JSON_KEY')
            out[k]=v
        return out
    return json.loads(raw,object_pairs_hook=pairs,parse_constant=lambda _:(_ for _ in ()).throw(ValueError('NONFINITE_JSON')))
def exact(path,expected,size=None):
    digest(expected);p=Path(os.path.abspath(path))
    if p.is_symlink() or any(x.is_symlink() for x in p.parents):raise ValueError('ORDINARY_EXACT_SOURCE_FILE_REQUIRED')
    fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW)
    with os.fdopen(fd,'rb') as f:
        st=os.fstat(f.fileno())
        if not stat.S_ISREG(st.st_mode) or size is not None and (type(size) is not int or st.st_size!=size):raise ValueError('SOURCE_PIN_CHANGED')
        raw=f.read()
    if sha(raw)!=expected or size is not None and len(raw)!=size:raise ValueError('SOURCE_PIN_CHANGED')
    return raw
def metadata_pins():return object_json(exact(HERE/'OBSERVED_SOURCE_METADATA_PINS.json',METADATA_PINS_SHA256))
def require_full_source_pins():
    for v in (FINAL_PINS,SOURCE_QUALIFICATION_SHA256,SOURCE_INDEPENDENT_REVIEW_SHA256,METADATA_PINS_SHA256):digest(v)
def _external(raw,expected,pinned,error):
    if type(raw) is not bytes or expected is None or expected!=pinned or sha(raw)!=digest(expected):raise ValueError(error)
    value=object_json(raw)
    if type(value) is not dict:raise ValueError(error)
    return value

@dataclass(frozen=True,slots=True)
class SourceQualificationBinding:
    source_identity:str
    qualification_SHA256:str
    @classmethod
    def validate(cls,m,*,qualification_sha256=None):
        expected=metadata_pins()['source_qualification']
        if type(m) is not dict or canonical(m)!=canonical(expected):raise ValueError('EXACT_FULL2025_COMPLETE_SOURCE_METADATA_REQUIRED')
        # JSON equality alone treats True as 1: require the exact serialized types.
        for k in ('days','minutes_per_asset_per_family','raw_archive_selections','canonical_bytes'):
            if type(m.get(k)) is not int:raise ValueError('EXACT_FULL2025_INTEGER_METADATA_REQUIRED')
        qsha=jsha(m) if qualification_sha256 is None else digest(qualification_sha256)
        return cls(jsha(m['canonical_source_files']),qsha)

def require_source_stage_authority(raw,expected):
    require_full_source_pins();a=_external(raw,expected,expected,'EXACT_EXTERNAL_SOURCE_PREP_ROOT_AUTHORITY_REQUIRED')
    import sys
    e=sys.modules.get('full_entry')
    if e is None or Path(e.__file__).resolve()!=HERE/'full_entry.py':raise ValueError('EXACT_CURRENT_FULL2025_ENTRY_REQUIRED')
    required=dict(schema=SOURCE_STAGE_SCHEMA,action=SOURCE_PREP_ACTION,source_completion_SHA256=FINAL_PINS,
        source_independent_review_SHA256=SOURCE_INDEPENDENT_REVIEW_SHA256,metadata_pins_SHA256=METADATA_PINS_SHA256,
        manifest_SHA256=e.MANIFEST_SHA256,code_identity=e.code_identity(),calendar=[START,END],year=2025,
        target_generation_authorized=True,canonical_source_capture_authorized=True,ephemeral_recording_metadata_scopes=9,
        raw_archive_reads_authorized=False,raw_normalization_authorized=False,historical_execution_authorized=False,
        account_construction_authorized=False,financial_execution_authorized=False,provider_iteration_authorized=False,process_launch_authorized=False,
        canonical_claims_authorized=False,financial_GO_authorized=False,publication_authorized=False,
        source_limits=dict(CPU_seconds=300,wall_seconds=900,output_bytes=268435456))
    if any(type(a.get(k)) is not type(v) or canonical(a[k])!=canonical(v) for k,v in required.items()):raise ValueError('EXACT_SOURCE_PREP_ONLY_SCOPE_REQUIRED')
    digest(a.get('actual_source_adapter_review_SHA256'))
    if a['actual_source_adapter_review_SHA256'] in (SOURCE_INDEPENDENT_REVIEW_SHA256,'7b028890541a3320651efaa3a53eeb7e97307207ddfdf2149bd9929fc478ad6f'):raise ValueError('FRESH_FULL2025_ADAPTER_REVIEW_REQUIRED')
    review=object_json(exact(SOURCE_REVIEW_PATH,SOURCE_INDEPENDENT_REVIEW_SHA256))
    if review.get('status')!='PASS_SOURCE_ONLY_NO_FINANCIAL_GO':raise ValueError('ACTUAL_SOURCE_AUDIT_PASS_REQUIRED')
    return a

def require_historical_authority(raw,expected):
    require_full_source_pins()
    return _external(raw,expected,expected,'EXACT_NEW_EXTERNAL_FULL2025_ROOT_GO_REQUIRED')

_SOURCE_SEAL=object();_ACTIVE_SOURCE=set()
@dataclass(frozen=True,slots=True)
class ActualSourceApplicationScope:
    qualification:SourceQualificationBinding
    root_source_GO_SHA256:str
    _go_raw:bytes=field(repr=False)
    _token:object=field(repr=False)
    _seal:object=field(repr=False)
    def __post_init__(self):
        if self._seal is not _SOURCE_SEAL:raise ValueError('SOURCE_SCOPE_REQUIRES_FRESH_EXACT_STAGE_AUTHORITY')
    def validate_current(self):
        if self._token not in _ACTIVE_SOURCE:raise ValueError('SOURCE_STAGE_SCOPE_REVOKED')
        require_source_stage_authority(self._go_raw,self.root_source_GO_SHA256);return True
    def revoke(self):_ACTIVE_SOURCE.discard(self._token)
def admit_actual_source_stage(qualification_raw,raw_go,expected_go_sha256):
    require_source_stage_authority(raw_go,expected_go_sha256)
    if type(qualification_raw) is not bytes or sha(qualification_raw)!=SOURCE_QUALIFICATION_SHA256:raise ValueError('EXACT_PINNED_SOURCE_QUALIFICATION_BODY_REQUIRED')
    q=SourceQualificationBinding.validate(object_json(qualification_raw),qualification_sha256=sha(qualification_raw))
    token=object();_ACTIVE_SOURCE.add(token)
    return ActualSourceApplicationScope(q,expected_go_sha256,raw_go,token,_SOURCE_SEAL)

# Genuine 2025 is complete: quality overlay and imputation are never permitted.
ACTUAL27_OPEN_POINTS_US=()
class QualityCell:
    def __init__(self,*args,**kwargs):raise ValueError('NO_2025_DERIVED_OR_IMPUTED_SOURCE_CELLS_ADMITTED')

@dataclass(frozen=True,slots=True)
class CapturedMinuteProvider:
    year:int
    months:tuple
    quality_cells:tuple=()
    _historical_scope:object=field(default=None,repr=False,compare=False)
    def _bind_historical_scope(self,scope):
        from full_entry import FreshHistoricalExecutionScope
        if type(scope) is not FreshHistoricalExecutionScope or self._historical_scope is not None or scope._bound_window['minute_blocks'] is not self:raise ValueError('EXACT_FRESH_HISTORICAL_PROVIDER_ADMISSION_REQUIRED')
        scope.validate_current();object.__setattr__(self,'_historical_scope',scope)
    @property
    def identity(self):return dict(months=[[n,at,count,sha(raw),len(raw),lo,hi] for n,at,count,raw,lo,hi in self.months],quality_SHA256=jsha([]))
    def __call__(self):
        from full_entry import FreshHistoricalExecutionScope
        if type(self._historical_scope) is not FreshHistoricalExecutionScope:raise ValueError('HISTORICAL_PROVIDER_REQUIRES_SEPARATE_ROOT_GO')
        self._historical_scope.validate_current()
        if self.year!=2025 or self.quality_cells:raise ValueError('EXACT_FULL2025_GENUINE_PROVIDER_REQUIRED')
        from source_projection import month_arrays
        cursor=START
        for name,start,count,raw,lo,hi in self.months:
            if start+lo*MINUTE!=cursor:raise ValueError('EXACT_CHRONOLOGICAL_SOURCE_PROVIDER_REQUIRED')
            a,_=month_arrays(raw,start,count,())
            for off in range(lo,hi,1440):
                stop=min(off+1440,hi)
                yield dict(times=a['times'][off:stop],market={symbol:{k:a[symbol+'_'+k][off:stop] for k in ('open','close','quote_volume','mark')} for symbol in S})
            cursor=start+hi*MINUTE
        if cursor!=END:raise ValueError('EXACT_FULL2025_PROVIDER_END_REQUIRED')

def project(source_root=SOURCE_ROOT,*,source_scope=None,source_authorization_raw=None,expected_source_authorization_sha256=None):
    require_source_stage_authority(source_authorization_raw,expected_source_authorization_sha256)
    from source_projection import project as apply
    return apply(source_root,source_scope=source_scope,source_authorization_raw=source_authorization_raw,expected_source_authorization_sha256=expected_source_authorization_sha256)
