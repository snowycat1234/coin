"""Guarded source/target-only CLI; no finance, provider iteration or process probe."""
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','POLARS_MAX_THREADS','VECLIB_MAXIMUM_THREADS'):os.environ[key]='1'
import argparse,json,resource,signal,time
from pathlib import Path

def main():
    parser=argparse.ArgumentParser()
    for name in ('source-root','output','source-go','source-go-sha'):parser.add_argument('--'+name,required=True)
    parser.add_argument('--cpu',type=int,required=True);args=parser.parse_args()
    if args.cpu not in os.sched_getaffinity(0):raise ValueError('ACTUALLY_ALLOWED_ASSIGNED_SOURCE_CPU_REQUIRED')
    os.sched_setaffinity(0,{args.cpu})
    resource.setrlimit(resource.RLIMIT_CPU,(300,300));resource.setrlimit(resource.RLIMIT_AS,(2000000000,2000000000))
    signal.signal(signal.SIGALRM,lambda *_:(_ for _ in ()).throw(TimeoutError('SOURCE_STAGE_WALL_CAP')));signal.alarm(900)
    import full_source as s
    import full_entry as e
    from source_projection import original_grid
    from source_guard import SourceOnlyGuard
    go=Path(args.source_go).read_bytes();s.require_source_stage_authority(go,args.source_go_sha)
    out=Path(args.output).absolute()
    if out.exists():raise ValueError('EXCLUSIVE_NEW_SOURCE_PREPARATION_REQUIRED')
    # Preload only original deterministic target functions before the financial
    # import guard. Vendor/account lazy imports remain blocked under the guard.
    g=original_grid();g.originals();g._h090()
    pins=json.loads((e.HERE/'DEPENDENCY_PINS.json').read_bytes());metadata=s.metadata_pins()
    reads=[s.ROOT/name for name in pins]+[s.ROOT/name for name in metadata['files']]
    reads += [p for p in e.HERE.iterdir() if p.is_file()]+[s.SOURCE_REVIEW_PATH,Path(args.source_go).absolute()]
    guard=SourceOnlyGuard(write_roots=(out,),read_paths=reads)
    began=time.monotonic();cpu=time.process_time()
    try:
        with guard:
            guard.checkpoint('ENTER_GUARDED_SOURCE_TARGET_STAGE')
            prep=e.prepare_source_only({2025:args.source_root},out,source_authorization_raw=go,expected_source_authorization_sha256=args.source_go_sha)
            guard.checkpoint('EXACT365_NINE_TARGETS_SAVED_NO_HISTORY')
            recorded=e.record_source_metadata_callbacks(out,go,args.source_go_sha)
            guard.checkpoint('NINE_EPHEMERAL_RECORDING_SCOPES_REVOKED')
            if s._ACTIVE_SOURCE:raise ValueError('SOURCE_SCOPES_NOT_REVOKED')
            with (out/'RECORDING_ONLY_METADATA_RECEIPT.json').open('x') as f:json.dump(recorded,f,indent=2);f.write('\n')
        elapsed=time.monotonic()-began
        total=sum(p.stat().st_size for p in out.rglob('*') if p.is_file())
        if elapsed>900 or time.process_time()-cpu>300 or total>268435456:raise ValueError('SOURCE_STAGE_RESOURCE_CAP')
        receipt=guard.receipt('PASS_GUARDED_SOURCE_TARGET_ONLY_NO_FINANCIAL_GO')
        receipt.update(source_scopes_revoked=not s._ACTIVE_SOURCE,recording_scopes_revoked=not e._METADATA_ACTIVE,
            elapsed_CPU_seconds=time.process_time()-cpu,elapsed_wall_seconds=elapsed,output_bytes_before_receipt=total,
            actual_CPU_affinity=sorted(os.sched_getaffinity(0)),all_TID_affinities=[sorted(os.sched_getaffinity(int(t))) for t in os.listdir('/proc/self/task')],
            limits=dict(CPU_seconds=300,wall_seconds=900,output_bytes=268435456),source_stage_GO_SHA256=args.source_go_sha)
        with (out/'OBSERVED_SOURCE_TARGET_GUARD_RECEIPT.json').open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
        print(json.dumps(dict(status=prep['status'],forbidden_attempts=receipt['forbidden_attempts'],source_scope_revoked=True,recording_scopes_revoked=True)))
    except BaseException as exc:
        if out.is_dir():
            with (out/'STOP_SOURCE_TARGET_PREPARATION.json').open('x') as f:json.dump(guard.receipt('STOP_SOURCE_TARGET_ONLY',str(exc)),f,indent=2);f.write('\n')
        raise
    finally:signal.alarm(0)

if __name__=='__main__':main()
