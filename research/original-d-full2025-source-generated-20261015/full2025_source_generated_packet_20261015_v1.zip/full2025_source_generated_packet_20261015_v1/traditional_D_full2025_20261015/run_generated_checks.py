"""Generated-only suite bootstrap with observed actual-source/legacy-GO denial."""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','POLARS_MAX_THREADS','VECLIB_MAXIMUM_THREADS'):os.environ[k]='1'
import builtins,io,json,sys,time,unittest,subprocess,socket
from contextlib import ExitStack
from pathlib import Path
from unittest.mock import patch
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
observed=dict(actual_source_body_read_attempts=0,old_private_GO_body_read_attempts=0,external_process_launch_attempts=0,network_attempts=0)
def check(file):
    if isinstance(file,int):return
    if not isinstance(file,(str,bytes,os.PathLike)):return
    p=Path(os.path.abspath(os.fsdecode(file)))
    if any(part in ('prepared_2025','qualified_source_only_pending_review') for part in p.parts) and p.suffix in ('.json','.npz','.zip'):
        observed['actual_source_body_read_attempts']+=1;raise AssertionError('ACTUAL2025_BODY_FORBIDDEN_IN_GENERATED_TESTS:'+str(p))
    if 'annual_go' in p.parts or p.name.startswith('ROOT_GO_APPROVED'):
        observed['old_private_GO_body_read_attempts']+=1;raise AssertionError('PRIVATE_OLD_GO_BODY_FORBIDDEN:'+str(p))
def wrap(original):
    def opened(file,mode='r',*a,**kw):
        if 'r' in mode or '+' in mode:check(file)
        return original(file,mode,*a,**kw)
    return opened
def os_open(path,flags,*a,**kw):
    if not flags&os.O_WRONLY:check(path)
    return original_os_open(path,flags,*a,**kw)
original_os_open=os.open
if __name__=='__main__':
    os.sched_setaffinity(0,{8});began=time.monotonic()
    with ExitStack() as stack:
        for obj,name,fn in ((builtins,'open',wrap(builtins.open)),(io,'open',wrap(io.open)),(os,'open',os_open)):
            stack.enter_context(patch.object(obj,name,fn))
        def denied(category,target):
            def fail(*a,**kw):
                observed[category]+=1;raise AssertionError('GENERATED_SUITE_EXTERNAL_ACTION_FORBIDDEN:'+target)
            return fail
        for obj,names,category in ((subprocess,('Popen','run','call','check_call','check_output'),'external_process_launch_attempts'),
                (os,('system','fork','forkpty','posix_spawn','posix_spawnp','execv','execve','execvp','execvpe'),'external_process_launch_attempts'),
                (socket.socket,('connect','connect_ex','sendto','send','sendall'),'network_attempts')):
            for name in names:
                if hasattr(obj,name):stack.enter_context(patch.object(obj,name,denied(category,name)))
        suite=unittest.defaultTestLoader.loadTestsFromNames(['test_full_gate','test_generated_d','test_generated_native40','test_generated_runner'])
        result=unittest.TextTestRunner(verbosity=2).run(suite)
    receipt=dict(schema='GENERATED_FULL2025_SOURCE_D_RUNNER_RECEIPT_V1',status='PASS' if result.wasSuccessful() and not any(observed.values()) else 'FAIL',
        tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),observed=observed,CPU_affinity=sorted(os.sched_getaffinity(0)),
        all_TID_affinities=[sorted(os.sched_getaffinity(int(t))) for t in os.listdir('/proc/self/task')],numerical_environment={k:os.environ[k] for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','POLARS_MAX_THREADS','VECLIB_MAXIMUM_THREADS')},elapsed_wall_seconds=time.monotonic()-began,
        actual_targets_generated=0,actual_financial_runs=0,financial_GO_written=0,publication_actions=0)
    (HERE/'GENERATED_TEST_RECEIPT.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
    raise SystemExit(0 if receipt['status']=='PASS' else 1)
