"""Pure mocked scheduler/resource/claims tests. No child process is launched."""
from copy import deepcopy
from pathlib import Path
from types import SimpleNamespace
import json,tempfile,unittest
from unittest.mock import patch
import run_full as r

class RunnerTests(unittest.TestCase):
    def test_limits_and_numerical_environment_match_frozen_contract(self):
        self.assertEqual(r.LIMITS,dict(maximum_live_workers=2,threads_per_worker=1,per_case_wall_seconds=600,
            per_case_CPU_seconds=600,per_case_RSS_stop_bytes=2000000000,per_case_AS_bytes=4000000000,
            per_case_output_bytes=250000000,aggregate_live_worker_RSS_stop_bytes=3500000000))
        self.assertTrue(all(r.environment()[key]=='1' for key in r.THREAD_ENV))

    def test_distinct_affinities_max_two_pressure_and_serial_fallback(self):
        host=dict(allowed_CPUs=[4,5],MemAvailable_bytes=6000000000,cgroup_observations={})
        self.assertEqual(r.choose_worker_count(2,[4,5],host),2)
        low=deepcopy(host);low['MemAvailable_bytes']=3000000000;self.assertEqual(r.choose_worker_count(2,[4,5],low),1)
        low['MemAvailable_bytes']=2000000000
        with self.assertRaises(RuntimeError):r.choose_worker_count(1,[4],low)
        for n,cpus in ((3,[4,5,6]),(2,[4,4]),(2,[4,6]),(True,[4]),(2,[True,5])):
            with self.assertRaises(ValueError):r.choose_worker_count(n,cpus,host)
        host['cgroup_observations']={'/sys/fs/cgroup/cpu.max':'100000 100000'}
        self.assertEqual(r.choose_worker_count(2,[4,5],host),1)

    def test_canonical_claims_permanent_across_outputs(self):
        with tempfile.TemporaryDirectory() as td:
            cell='2025_STATIC50_LOW_JAN1_DEC31_D'
            r.claim_launch(td,cell_id=cell,manifest_sha256=r.MANIFEST_SHA256,metadata={'case_output':'FIRST'})
            with self.assertRaisesRegex(RuntimeError,'PERMANENT_CANONICAL_CELL_CLAIM'):
                r.claim_launch(td,cell_id=cell,manifest_sha256=r.MANIFEST_SHA256,metadata={'case_output':'SECOND'})
            self.assertEqual(json.loads((Path(td)/r.MANIFEST_SHA256/(cell+'.json')).read_bytes())['case_output'],'FIRST')

    def test_global_nine_cell_controller_lease_rejects_overlap(self):
        with tempfile.TemporaryDirectory() as td:
            with r.controller_lease(td):
                with self.assertRaisesRegex(RuntimeError,'CONTROLLER_LEASE_HELD'):
                    with r.controller_lease(td):pass
            with r.controller_lease(td):pass

    def test_existing_output_and_unfinished_output_pause_no_spawn(self):
        with tempfile.TemporaryDirectory() as td,patch.object(r.subprocess,'Popen',side_effect=AssertionError('SPAWN_FORBIDDEN')),patch.object(r,'cpu_envelope',lambda *_: __import__('contextlib').nullcontext()):
            with self.assertRaisesRegex(ValueError,'RESUME_NOT_SUPPORTED'):r.controller(SimpleNamespace(output=td))
            (Path(td)/'FAKE').mkdir()
            with self.assertRaisesRegex(RuntimeError,'EXISTING_UNFINISHED'):
                r.run_pool([('FAKE',lambda *_:None)],td,requested_workers=1,cpus=[4],validator=lambda *_:None)

    def test_duplicate_jobs_and_low_memory_pause_before_spawn(self):
        with tempfile.TemporaryDirectory() as td,patch.object(r.subprocess,'Popen',side_effect=AssertionError('SPAWN_FORBIDDEN')),patch.object(r,'cpu_envelope',lambda *_: __import__('contextlib').nullcontext()):
            with self.assertRaisesRegex(ValueError,'UNIQUE'):
                r.run_pool([('FAKE',None),('FAKE',None)],td,requested_workers=1,cpus=[4],validator=None)
            with self.assertRaisesRegex(RuntimeError,'MEMORY'):
                r.run_pool([('FAKE',None)],td,requested_workers=1,cpus=[4],validator=None,
                    observation_callback=lambda:dict(allowed_CPUs=[4],MemAvailable_bytes=1,cgroup_observations={}))

    def test_immutable_atomic_publication_and_inode_accounting(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'FAKE.json';r.save(p,dict(generated_only=True))
            with self.assertRaises(FileExistsError):r.save(p,dict(replace=True))
            self.assertEqual(json.loads(p.read_bytes()),{'generated_only':True})
            self.assertEqual(list(Path(td).glob('.*.tmp')),[])


class RecordingOnlyTests(unittest.TestCase):
    def test_nine_fake_recording_scopes_revoked_and_cannot_admit_account(self):
        import full_entry as e
        import full_d as d
        scopes=[];prep=dict(cells={cell:dict(input_binding_SHA256='a'*64) for cell in e.tranche_cells()})
        def record(scope,metadata):
            scope.validate_current();scopes.append(scope)
            with self.assertRaises(ValueError):d.ExpansionAccount(historical_scope=scope)
            return metadata
        with self.assertRaisesRegex(ValueError,'VALIDATED_SOURCE_STAGE_SCOPE'):
            e._record_metadata_cells(prep,'b'*64,record,domain='ACTUAL_PREPARED_SOURCE_METADATA')
        result=e._record_metadata_cells(prep,'b'*64,record,domain='GENERATED_FAKE_METADATA')
        self.assertEqual(result['recording_scopes_created'],9);self.assertEqual(result['recording_scopes_revoked'],9)
        self.assertEqual(result['accounts_constructed'],0);self.assertFalse(e._METADATA_ACTIVE)
        for scope in scopes:
            with self.assertRaisesRegex(ValueError,'REVOKED'):scope.validate_current()

    def test_recording_scope_revoked_on_callback_exception(self):
        import full_entry as e
        held=[];prep=dict(cells={cell:dict(input_binding_SHA256='a'*64) for cell in e.tranche_cells()})
        def broken(scope,metadata):held.append(scope);raise RuntimeError('FAKE_CALLBACK_FAILURE')
        with self.assertRaisesRegex(RuntimeError,'FAKE_CALLBACK_FAILURE'):
            e._record_metadata_cells(prep,'b'*64,broken,domain='GENERATED_FAKE_METADATA')
        self.assertFalse(e._METADATA_ACTIVE)
        with self.assertRaisesRegex(ValueError,'REVOKED'):held[0].validate_current()

class ProviderBoundaryTests(unittest.TestCase):
    def test_unbound_empty_provider_cannot_iterate_or_accept_recording_scope(self):
        import full_source as s
        provider=s.CapturedMinuteProvider(2025,())
        with self.assertRaisesRegex(ValueError,'HISTORICAL_PROVIDER_REQUIRES_SEPARATE_ROOT_GO'):next(provider())
        with self.assertRaisesRegex(ValueError,'EXACT_FRESH_HISTORICAL_PROVIDER_ADMISSION'):provider._bind_historical_scope(object())

if __name__=='__main__':unittest.main()
