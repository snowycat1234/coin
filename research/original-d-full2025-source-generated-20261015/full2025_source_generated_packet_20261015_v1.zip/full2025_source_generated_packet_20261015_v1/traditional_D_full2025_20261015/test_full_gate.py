"""Generated-only full2025 projection, metadata and closed-admission tests.

The only saved source information read here is the scaffold's metadata pins.
Every price, NPZ, daily row and preparation body used by these tests is generated
in memory or a temporary directory. No canonical2025 market body is opened.
"""
from copy import deepcopy
from io import BytesIO
import builtins
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import types
import unittest
import zipfile
from unittest.mock import Mock, patch

import numpy as np

import full_source as s
import full_entry as e
import source_projection as p


def metadata():
    """Exact observed receipt metadata, with no source-body access."""
    return deepcopy(s.metadata_pins()['source_qualification'])


def npz_bytes(**arrays):
    out = BytesIO()
    np.savez_compressed(out, **arrays)
    return out.getvalue()


def json_bytes(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':')).encode()


def generated_daily():
    clocks = np.arange(s.START - 199*s.DAY, s.END, s.DAY, dtype=np.int64)
    base = np.arange(len(clocks), dtype=np.float64)
    close = np.column_stack([
        100 + j*30 + base*(.02 + j*.001) + np.sin(base/(11+j) + j)*.2
        for j in range(5)
    ]).astype(np.float64)
    warm = dict(close_available_us=clocks[:200].copy(), close=close[:200].copy())
    rows = [dict(symbol=symbol, close_us=int(at), close=float(close[i, j]))
            for i, at in enumerate(clocks) if s.START <= at < s.END
            for j, symbol in enumerate(s.S)]
    return warm, rows, clocks, close


def daily_projection(warm=None, rows=None):
    default_warm, default_rows, _, _ = generated_daily()
    warm = default_warm if warm is None else warm
    rows = default_rows if rows is None else rows
    return p.project_daily_grid(npz_bytes(**warm), json_bytes(rows))


def fake_preparation():
    return dict(cells={cell: dict(input_binding_SHA256='a'*64)
                       for cell in e.tranche_cells()})


def generated_month(count=4):
    arrays = {'times': np.arange(s.START, s.START+count*s.MINUTE, s.MINUTE, dtype=np.int64)}
    for j, symbol in enumerate(s.S):
        for field in ('open', 'close', 'quote_volume', 'mark'):
            arrays[symbol+'_'+field] = np.arange(count, dtype=np.float64)*.125 + 100+j
    arrays[s.S[0]+'_quote_volume'][0] = 0.
    return arrays


class MetadataAndAdmissionTests(unittest.TestCase):
    def test_observed_metadata_is_pure_and_mints_no_authority(self):
        m = metadata()
        q = s.SourceQualificationBinding.validate(m)
        self.assertIs(type(q), s.SourceQualificationBinding)
        self.assertEqual(q.qualification_SHA256, s.jsha(m))
        self.assertEqual(q.source_identity, s.jsha(m['canonical_source_files']))
        self.assertFalse(m['historical_execution_authorized'])
        self.assertFalse(m['financial_execution_authorized'])
        self.assertFalse(s._ACTIVE_SOURCE)
        with self.assertRaises(ValueError):
            s.require_source_stage_authority(None, None)

    def test_every_observed_metadata_field_is_required(self):
        m = metadata()
        for key in m:
            changed = deepcopy(m)
            del changed[key]
            with self.subTest(key=key), self.assertRaises(ValueError):
                s.SourceQualificationBinding.validate(changed)
        changed = deepcopy(m)
        changed['generated_fixture_is_authority'] = True
        with self.assertRaises(ValueError):
            s.SourceQualificationBinding.validate(changed)

    def test_bool_is_not_integer_metadata_or_calendar(self):
        for key in ('days', 'minutes_per_asset_per_family', 'raw_archive_selections', 'canonical_bytes'):
            changed = metadata()
            changed[key] = True
            with self.subTest(key=key), self.assertRaises(ValueError):
                s.SourceQualificationBinding.validate(changed)
        changed = metadata()
        changed['source_calendar_us'][0] = True
        with self.assertRaises(ValueError):
            s.SourceQualificationBinding.validate(changed)

    def test_metadata_source_files_and_false_authority_flags_are_exact(self):
        mutations = [
            ('source_calendar_us', [s.START, s.END+s.DAY]),
            ('symbols', list(reversed(s.S))),
            ('historical_execution_authorized', True),
            ('financial_execution_authorized', True),
            ('historical_arrival_certified', True),
            ('raw_rate_unit', 'CERTIFIED'),
            ('status', 'PASS_HISTORICAL_GO'),
        ]
        for key, value in mutations:
            changed = metadata()
            changed[key] = value
            with self.subTest(key=key), self.assertRaises(ValueError):
                s.SourceQualificationBinding.validate(changed)
        for key, value in (('SHA256', '0'*64), ('bytes', True), ('file', 'months/2026-01.npz')):
            changed = metadata()
            changed['canonical_source_files'][0][key] = value
            with self.subTest(file_field=key), self.assertRaises(ValueError):
                s.SourceQualificationBinding.validate(changed)

    def test_all_actual_source_boundaries_fail_before_body_or_callback(self):
        forbidden = Mock(side_effect=AssertionError('ACTUAL_BODY_OR_CALLBACK_FORBIDDEN'))
        with tempfile.TemporaryDirectory() as td:
            out = Path(td)/'out'
            actions = [
                lambda: s.project(s.SOURCE_ROOT),
                lambda: p.project(s.SOURCE_ROOT),
                lambda: p.capture(s.SOURCE_ROOT, source_authorization_raw=None,
                                  expected_source_authorization_sha256=None),
                lambda: p.base_projection(s.SOURCE_ROOT, source_authorization_raw=None,
                                          expected_source_authorization_sha256=None),
                lambda: p.load_prepared_projection(s.SOURCE_ROOT, {'SOURCE_PREP_GO.json': b'{}'}),
                lambda: s.admit_actual_source_stage(b'{}', b'{}', 'a'*64),
                lambda: e.prepare_source_only({2025: s.SOURCE_ROOT}, out),
                lambda: e.record_source_metadata_callbacks(td, b'{}', 'a'*64, callback=forbidden),
            ]
            # Code identity is ordinary code/manifest metadata. Replacing its
            # reads leaves the real authority validator and all body boundaries
            # in place, including a saved loader's self-hashed invalid GO.
            with patch.object(Path, 'read_bytes', forbidden), patch.object(np, 'load', forbidden), \
                    patch.object(s, 'exact', forbidden), \
                    patch.object(e, 'code_identity', return_value={'GENERATED': 'a'*64}):
                for action in actions:
                    with self.subTest(action=actions.index(action)), self.assertRaises(ValueError):
                        action()
            self.assertFalse(out.exists())
            forbidden.assert_not_called()
            # A generated empty preparation may be read; no source or financial
            # constructor is reached without separately supplied root authority.
            (Path(td)/'PREPARATION.json').write_bytes(b'{}')
            with patch.object(np, 'load', forbidden):
                with self.assertRaises(ValueError):
                    e.make_case({2025: s.SOURCE_ROOT}, td, b'{}', None,
                                cell_id=e.tranche_cells()[0], review_raw=b'{}',
                                expected_review_sha256=None, constructor_callback=forbidden)
            forbidden.assert_not_called()
            self.assertFalse(s._ACTIVE_SOURCE)

    def test_missing_external_roots_and_old_go_never_admit(self):
        raw = b'{"schema":"GENERATED_SELF_MINTED"}'
        with self.assertRaises(ValueError):
            s._external(raw, s.sha(raw), 'f'*64, 'EXTERNAL_ROOT_REQUIRED')
        with self.assertRaises(ValueError):
            e.validate_root_go(b'{}', raw, None, cell_id=e.tranche_cells()[0])
        with self.assertRaises(ValueError):
            e._validate_independent_review(b'{}', {}, raw, None, b'{}')
        template = e.invalid_go_template()
        self.assertFalse(template['historical_execution_authorized'])
        self.assertIsNone(template['preparation_SHA256'])
        with self.assertRaises(ValueError):
            e.validate_root_go(b'{}', json_bytes(template), s.sha(json_bytes(template)),
                               cell_id=e.tranche_cells()[0])

    def test_metadata_or_generated_objects_cannot_mint_source_scope(self):
        q = s.SourceQualificationBinding.validate(metadata())
        with self.assertRaises(ValueError):
            s.ActualSourceApplicationScope(q, 'a'*64, b'{}', object(), object())
        self.assertFalse(s._ACTIVE_SOURCE)
        with self.assertRaises(ValueError):
            s.QualityCell(symbol=s.S[0], price_text='100')
        self.assertEqual(s.ACTUAL27_OPEN_POINTS_US, ())

    def test_exact_nine_no_alias_calendar_and_unbound_targets(self):
        manifest = e.frozen_manifest()
        cells = e.tranche_cells()
        expected = tuple('2025_'+config+'_JAN1_DEC31_D' for config in s.CONFIGS)
        self.assertEqual(cells, expected)
        self.assertEqual(len(set(cells)), 9)
        self.assertEqual(manifest['alias_mapping'], {})
        self.assertEqual(manifest['unique_execution_jobs'], 9)
        self.assertEqual(manifest['calendar'], [1735689600000000, 1767225600000000])
        self.assertEqual((s.YEAR, s.DAYS, s.MINUTES), (2025, 365, 525600))
        self.assertEqual((s.END-s.START)//s.MINUTE, 525600)
        for cell_id in cells:
            cell = e.cell_descriptor(cell_id)
            self.assertEqual((cell['days'], cell['required_minutes'], cell['year']), (365, 525600, 2025))
            self.assertIsNone(cell['selected_target_raw_SHA256'])
        for bad in ('2022_STATIC50_LOW_JAN1_DEC31_D', '2025_STATIC50_LOW', '2025_H090_ALIAS_JAN1_DEC31_D', True):
            with self.subTest(cell=bad), self.assertRaises(ValueError):
                e.cell_descriptor(bad)
        for roots in ({2022: '/tmp/generated'}, {2025: '/tmp/generated', 2026: '/tmp/generated'}, {'2025': '/tmp/generated'}):
            with self.subTest(roots=roots), self.assertRaises(ValueError):
                e._source_roots(roots)

    def test_original_coldstart_funding_ownership_and_terminal_sixty(self):
        cold = e._coldstart_policy(2025)
        self.assertEqual(cold['initial_signal_us'], s.START)
        self.assertFalse(cold['available_prior_source_used'])
        self.assertEqual(cold['first_real_completed_quote_us'], s.START+s.MINUTE)
        self.assertEqual(cold['earliest_initial_increase_admission_us'], s.START+s.MINUTE+1)
        self.assertTrue(cold['all_funding_ownership_from_current_native_actual_quantity'])
        self.assertFalse(cold['old_Jan1_source_ownership_flag_used'])
        for year in (2022, 2024, 2026, True):
            with self.subTest(year=year), self.assertRaises(ValueError):
                e._coldstart_policy(year)
        policy = e._policy({'GENERATED': 'a'*64})
        self.assertEqual(policy['terminal_signal_us'], s.END-61*s.MINUTE)
        self.assertEqual(policy['terminal_eligible_open_range'], [s.END-60*s.MINUTE, s.END-s.MINUTE])
        self.assertFalse(policy['source_end_plus_one_witness_is_execution_authority'])
        self.assertTrue(policy['D_has_no_topup_or_internal_margin_transfer'])
        self.assertFalse(policy['annualization_allowed'])
        self.assertFalse(policy['wallet_compounding_allowed'])


class GeneratedMonthArrayTests(unittest.TestCase):
    def test_exact_genuine_numeric_arrays_preserve_bits_and_are_readonly(self):
        inputs = generated_month()
        arrays, quality = p.month_arrays(npz_bytes(**inputs), s.START, 4, ())
        self.assertEqual(quality, ())
        self.assertEqual(set(arrays), set(inputs))
        for name, array in arrays.items():
            self.assertEqual(array.tobytes(), inputs[name].tobytes())
            self.assertFalse(array.flags.writeable)
            with self.assertRaises(ValueError):
                array[0] = 1
            with self.assertRaises(ValueError):
                array.setflags(write=True)
        second = p.month_arrays(npz_bytes(**inputs), s.START, 4, ())[0]
        for name in inputs:
            self.assertEqual(second[name].tobytes(), inputs[name].tobytes())
        with self.assertRaises(TypeError):
            arrays['extra'] = np.ones(4)

    def test_exact_month_namespace_shapes_types_and_clocks(self):
        source = generated_month()
        bad = []
        extra = deepcopy(source); extra['available_us'] = source['times']+s.MINUTE; bad.append(extra)
        missing = deepcopy(source); del missing[s.S[0]+'_mark']; bad.append(missing)
        for name, value in (
            ('times', source['times'].astype(np.float64)),
            ('times', source['times']+1),
            (s.S[0]+'_close', source[s.S[0]+'_close'].astype(np.float32)),
            (s.S[0]+'_mark', source[s.S[0]+'_mark'][:-1]),
        ):
            item = deepcopy(source); item[name] = value; bad.append(item)
        for index, item in enumerate(bad):
            with self.subTest(case=index), self.assertRaises(ValueError):
                p.month_arrays(npz_bytes(**item), s.START, 4, ())
        raw = npz_bytes(**source)
        for start, count, quality in ((True, 4, ()), (s.START, True, ()),
                                      (s.START, 0, ()), (s.START, 4, (object(),))):
            with self.subTest(start=start, count=count), self.assertRaises(ValueError):
                p.month_arrays(raw, start, count, quality)

    def test_missing_imputed_or_nonfinite_prices_and_negative_volume_rejected(self):
        for field in ('open', 'close', 'mark'):
            for value in (0., -1., float('nan'), float('inf')):
                source = generated_month()
                source[s.S[0]+'_'+field][0] = value
                with self.subTest(field=field, value=value), self.assertRaises(ValueError):
                    p.month_arrays(npz_bytes(**source), s.START, 4, ())
        for value in (-1., float('nan'), float('inf')):
            source = generated_month(); source[s.S[0]+'_quote_volume'][0] = value
            with self.subTest(volume=value), self.assertRaises(ValueError):
                p.month_arrays(npz_bytes(**source), s.START, 4, ())

    def test_generated_capture_decodes_once_and_rejects_duplicate_members(self):
        raw = npz_bytes(**generated_month())
        first = p.month_arrays(raw, s.START, 4, ())[0]
        with patch.object(np, 'load', side_effect=AssertionError('REPEATED_ARRAY_DECODE_FORBIDDEN')):
            self.assertIs(p.month_arrays(raw, s.START, 4, ())[0], first)
        duplicate = BytesIO()
        with zipfile.ZipFile(BytesIO(raw)) as src, zipfile.ZipFile(duplicate, 'w') as dst:
            for item in src.infolist():
                dst.writestr(item.filename, src.read(item))
            import warnings
            with warnings.catch_warnings():
                warnings.simplefilter('ignore', UserWarning)
                dst.writestr('times.npy', src.read('times.npy'))
        with self.assertRaises(ValueError):
            p.month_arrays(duplicate.getvalue(), s.START, 4, ())


class GeneratedDailyProjectionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.warm, cls.rows, cls.clocks, cls.close = generated_daily()
        cls.projected = daily_projection(cls.warm, cls.rows)

    def test_exact_original_generated_target_and_covariance_bytes(self):
        if str(s.FROZEN) not in sys.path:
            sys.path.insert(0, str(s.FROZEN))
        import frozen_grid as original
        self.assertEqual(Path(original.__file__).resolve(), s.FROZEN/'frozen_grid.py')
        decisions = np.arange(s.START, s.END, s.DAY, dtype=np.int64)
        expected = original.build_target_grid(self.close, self.clocks, self.clocks.copy(), decisions)
        actual_d, actual_targets, actual_cov, actual_proofs, rows, daily, projection = self.projected
        self.assertEqual(actual_d.tobytes(), expected[0].tobytes())
        self.assertEqual(actual_cov.tobytes(), expected[2].tobytes())
        self.assertEqual(actual_proofs, expected[3])
        self.assertEqual(set(actual_targets), set(s.CONFIGS))
        for config in s.CONFIGS:
            self.assertEqual(actual_targets[config].tobytes(), expected[1][config].tobytes())
            self.assertEqual(actual_targets[config].shape, (365, 5))
            self.assertFalse(actual_targets[config].flags.writeable)
        self.assertEqual(actual_cov.shape, (365, 5, 5))
        self.assertFalse(actual_d.flags.writeable)
        self.assertFalse(actual_cov.flags.writeable)
        self.assertEqual(len(rows), 564*5)
        self.assertEqual(daily.height, 365*5)
        self.assertEqual(int(actual_d[0]), s.START)
        self.assertEqual(int(actual_d[-1]), s.END-s.DAY)
        self.assertTrue(all(proof['last_close_available_us'] == proof['decision_us'] for proof in actual_proofs))
        self.assertTrue(all(proof['oldest_close_available_us'] == proof['decision_us']-199*s.DAY for proof in actual_proofs))
        self.assertEqual(projection['selected_2026_daily_cube_rows'], 0)
        with self.assertRaises(TypeError):
            rows[0]['close'] = 1.

    def test_unordered_genuine_schema_rows_produce_identical_grid(self):
        reordered = self.rows[::2] + self.rows[1::2]
        other = daily_projection(self.warm, reordered)
        self.assertEqual(other[0].tobytes(), self.projected[0].tobytes())
        self.assertEqual(other[2].tobytes(), self.projected[2].tobytes())
        for config in s.CONFIGS:
            self.assertEqual(other[1][config].tobytes(), self.projected[1][config].tobytes())

    def test_last_permitted_close_never_changes_earlier_target_or_covariance(self):
        later = deepcopy(self.rows)
        for row in later:
            if row['close_us'] == s.END-s.DAY:
                row['close'] *= 1.2 + .1*s.S.index(row['symbol'])
        other = daily_projection(self.warm, later)
        self.assertEqual(other[2][:-1].tobytes(), self.projected[2][:-1].tobytes())
        self.assertEqual(other[3][:-1], self.projected[3][:-1])
        self.assertNotEqual(other[2][-1].tobytes(), self.projected[2][-1].tobytes())
        for config in s.CONFIGS:
            self.assertEqual(other[1][config][:-1].tobytes(), self.projected[1][config][:-1].tobytes())

    def test_warmup_exact_keys_shape_dtype_and_clock_support(self):
        changed = deepcopy(self.warm)
        bad = []
        extra = deepcopy(changed); extra['future_labels'] = np.ones(200); bad.append(extra)
        missing = deepcopy(changed); del missing['close_available_us']; bad.append(missing)
        for key, value in (
            ('close_available_us', changed['close_available_us'].astype(np.float64)),
            ('close', changed['close'].astype(np.float32)),
            ('close_available_us', changed['close_available_us'][:-1]),
            ('close', changed['close'][:-1]),
        ):
            item = deepcopy(changed); item[key] = value; bad.append(item)
        for at, value in ((0, s.START-198*s.DAY), (-1, s.START+s.DAY), (50, int(changed['close_available_us'][50])+s.MINUTE)):
            item = deepcopy(changed); item['close_available_us'][at] = value; bad.append(item)
        for index, item in enumerate(bad):
            with self.subTest(case=index), self.assertRaises(ValueError):
                daily_projection(item, self.rows)

    def test_warmup_and_daily_nonfinite_or_nonpositive_values_fail(self):
        for value in (0., -1., float('nan'), float('inf')):
            changed = deepcopy(self.warm); changed['close'][0, 0] = value
            with self.subTest(warm=value), self.assertRaises(ValueError):
                daily_projection(changed, self.rows)
            rows = deepcopy(self.rows); rows[-1]['close'] = value
            with self.subTest(daily=value), self.assertRaises(ValueError):
                daily_projection(self.warm, rows)

    def test_daily_exact_fields_unique_complete_corefive_and_integer_clocks(self):
        bad = [self.rows[:-1], self.rows + [deepcopy(self.rows[-1])]]
        for key, value in (
            ('close_us', True), ('close_us', s.START+s.MINUTE),
            ('symbol', 'BTC'), ('close', True), ('close', '100'),
            ('available_us', s.START),
        ):
            rows = deepcopy(self.rows); rows[0][key] = value; bad.append(rows)
        rows = deepcopy(self.rows); del rows[0]['close']; bad.append(rows)
        rows = deepcopy(self.rows); rows[0]['symbol'] = s.S[1]; bad.append(rows)
        for index, rows in enumerate(bad):
            with self.subTest(case=index), self.assertRaises(ValueError):
                daily_projection(self.warm, rows)
        with self.assertRaises(ValueError):
            daily_projection(self.warm, {'rows': self.rows})

    def test_2026_or_precalendar_daily_rows_are_rejected_even_if_unused(self):
        for at in (s.START-s.DAY, s.END, s.END+s.DAY):
            rows = deepcopy(self.rows)
            rows.append(dict(symbol=s.S[0], close_us=at, close=123.))
            with self.subTest(at=at), self.assertRaises(ValueError):
                daily_projection(self.warm, rows)
        rows = deepcopy(self.rows)
        rows[-1]['close_us'] = s.END
        with self.assertRaises(ValueError):
            daily_projection(self.warm, rows)

    def test_warmup_jan1_overlap_must_preserve_exact_float_bits(self):
        rows = deepcopy(self.rows)
        rows[0]['close'] = float(np.nextafter(rows[0]['close'], np.inf))
        with self.assertRaises(ValueError):
            daily_projection(self.warm, rows)

    def test_corrupt_containers_and_duplicate_json_keys_rejected(self):
        good_warm = npz_bytes(**self.warm)
        for raw in (b'', b'not an NPZ', good_warm[:-10]):
            with self.subTest(container=raw[:10]), self.assertRaises((ValueError, EOFError, OSError, zipfile.BadZipFile)):
                p.project_daily_grid(raw, json_bytes(self.rows))
        for raw in (b'', b'[] trailing', b'null', b'{"rows":[]}',
                    b'[{"symbol":"BTCUSDT","symbol":"DOGEUSDT","close_us":0,"close":1}]'):
            with self.subTest(json=raw[:40]), self.assertRaises(ValueError):
                p.project_daily_grid(good_warm, raw)


class GeneratedSavedProjectionTests(unittest.TestCase):
    def setUp(self):
        self.arrays = dict(
            decision_us=np.arange(s.START, s.END, s.DAY, dtype=np.int64),
            annual_covariance=np.repeat(np.eye(5, dtype=np.float64)[None, :, :], 365, axis=0),
        )
        self.arrays.update({config: np.full((365, 5), (i+1)*.001, dtype=np.float64)
                            for i, config in enumerate(s.CONFIGS)})
        self.base = dict(projection={'generated_only': True},
                         sidecar_raw=b'{"generated_only":true}\n',
                         source_identity='c'*64)
        self.artifacts = {
            'SOURCE_PREP_GO.json': b'{"generated_only":true}',
            'TARGETS.npz': npz_bytes(**self.arrays),
            'TARGET_PROOFS.json': b'[{"generated_only":true}]',
            'DAILY_SOURCE_PROJECTION.json': json_bytes(self.base['projection']),
            'MINUTE_MARK_PROVENANCE.json': self.base['sidecar_raw'],
        }

    def test_saved_targets_load_exact_bytes_without_source_decode_or_regeneration(self):
        original_load = np.load
        def generated_load(stream, *args, **kwargs):
            self.assertIsInstance(stream, BytesIO)
            self.assertEqual(stream.getvalue(), self.artifacts['TARGETS.npz'])
            return original_load(stream, *args, **kwargs)
        with patch.object(p, 'base_projection', return_value=self.base) as base, \
                patch.object(p, 'original_grid', side_effect=AssertionError('TARGET_REGENERATION_FORBIDDEN')) as grid, \
                patch.object(p, 'project_daily_grid', side_effect=AssertionError('SOURCE_REGENERATION_FORBIDDEN')) as project, \
                patch.object(np, 'load', side_effect=generated_load) as load, \
                patch.object(s, 'exact', side_effect=AssertionError('ACTUAL_SOURCE_BODY_FORBIDDEN')):
            result = p.load_prepared_projection(Path('/tmp/GENERATED_SOURCE'), self.artifacts)
        base.assert_called_once_with(Path('/tmp/GENERATED_SOURCE'),
            source_authorization_raw=self.artifacts['SOURCE_PREP_GO.json'],
            expected_source_authorization_sha256=s.sha(self.artifacts['SOURCE_PREP_GO.json']))
        grid.assert_not_called(); project.assert_not_called(); load.assert_called_once()
        self.assertEqual(result['decisions'].tobytes(), self.arrays['decision_us'].tobytes())
        self.assertEqual(result['covariance'].tobytes(), self.arrays['annual_covariance'].tobytes())
        self.assertEqual(result['proofs'], [{'generated_only': True}])
        self.assertFalse(result['decisions'].flags.writeable)
        self.assertFalse(result['covariance'].flags.writeable)
        for config in s.CONFIGS:
            self.assertEqual(result['targets'][config].tobytes(), self.arrays[config].tobytes())
            self.assertFalse(result['targets'][config].flags.writeable)

    def test_saved_targets_require_exact_nine_fields_shapes_dtypes_and_365_clocks(self):
        mutations = []
        missing = deepcopy(self.arrays); del missing[s.CONFIGS[0]]; mutations.append(missing)
        extra = deepcopy(self.arrays); extra['alias'] = extra[s.CONFIGS[0]]; mutations.append(extra)
        for name, value in (
            ('decision_us', self.arrays['decision_us'].astype(np.float64)),
            ('decision_us', self.arrays['decision_us']+s.DAY),
            ('decision_us', self.arrays['decision_us'][:-1]),
            ('annual_covariance', self.arrays['annual_covariance'].astype(np.float32)),
            ('annual_covariance', self.arrays['annual_covariance'][:, :4, :4]),
            (s.CONFIGS[0], np.zeros((364, 5), dtype=np.float64)),
            (s.CONFIGS[0], np.full((365, 5), np.nan, dtype=np.float64)),
            (s.CONFIGS[0], np.zeros((365, 5), dtype=np.float32)),
        ):
            arrays = deepcopy(self.arrays); arrays[name] = value; mutations.append(arrays)
        with patch.object(p, 'base_projection', return_value=self.base), \
                patch.object(p, 'original_grid', side_effect=AssertionError('TARGET_REGENERATION_FORBIDDEN')):
            for index, arrays in enumerate(mutations):
                artifacts = dict(self.artifacts, **{'TARGETS.npz': npz_bytes(**arrays)})
                with self.subTest(case=index), self.assertRaises(ValueError):
                    p.load_prepared_projection(Path('/tmp/GENERATED_SOURCE'), artifacts)

    def test_saved_source_proof_and_provenance_cannot_change(self):
        with patch.object(p, 'base_projection', return_value=self.base):
            for name, raw in (('DAILY_SOURCE_PROJECTION.json', b'{}'),
                              ('MINUTE_MARK_PROVENANCE.json', b'{}')):
                artifacts = dict(self.artifacts, **{name: raw})
                with self.subTest(artifact=name), self.assertRaises(ValueError):
                    p.load_prepared_projection(Path('/tmp/GENERATED_SOURCE'), artifacts)


class GeneratedSourceBoundaryTests(unittest.TestCase):
    def test_every_forbidden_category_is_observed_and_fatal(self):
        from source_guard import SourceOnlyGuard, SourceBoundaryViolation
        fixture = types.ModuleType('_full2025_generated_boundary_fixture')
        fixture.__source_guard_fixture__ = True
        def noop(*args, **kwargs):
            return None
        fixture.GeneratedAccount = type('GeneratedAccount', (), {'__init__': noop, 'update_marks': noop})
        fixture.GeneratedSimulator = type('GeneratedSimulator', (), {'__init__': noop})
        fixture.FreshHistoricalExecutionScope = type('FreshHistoricalExecutionScope', (), {'__init__': noop})
        fixture.GeneratedProvider = type('GeneratedProvider', (), {'__call__': noop})
        account = fixture.GeneratedAccount()
        provider = fixture.GeneratedProvider()
        sys.modules[fixture.__name__] = fixture
        try:
            with tempfile.TemporaryDirectory(dir=s.HERE, prefix='GENERATED_GUARD_') as td:
                directory = Path(td)
                output = directory/'output'; output.mkdir()
                unread = directory/'GENERATED_UNLISTED.txt'; unread.write_text('generated only')
                actions = {
                    'financial_constructors': lambda: fixture.GeneratedAccount(),
                    'financial_account_advance': lambda: account.update_marks(),
                    'native_simulator_construct_or_advance': lambda: fixture.GeneratedSimulator(),
                    'historical_scope_mints': lambda: fixture.FreshHistoricalExecutionScope(),
                    'actual_provider_calls': lambda: provider(),
                    'process_launches': lambda: subprocess.Popen(['GENERATED_NEVER_EXECUTED']),
                    'network_calls': lambda: socket.create_connection(('generated.invalid', 1)),
                    'canonical_financial_claims_or_leases': lambda: (output/'EXECUTION_CLAIMS'/'FAKE.json').write_text('{}'),
                    'financial_GO_writes': lambda: json.dumps({'schema': 'ROOT_GO_GENERATED', 'historical_execution_authorized': True}),
                    'financial_imports': lambda: builtins.__import__('full_d'),
                    'outside_source_writes': lambda: (directory/'outside.txt').write_text('generated'),
                    'nonallowlisted_file_reads': lambda: unread.read_text(),
                }
                self.assertEqual(set(actions), set(SourceOnlyGuard.CATEGORIES))
                for category, action in actions.items():
                    guard = SourceOnlyGuard(write_roots=(output,))
                    with self.subTest(category=category):
                        with self.assertRaisesRegex(SourceBoundaryViolation, 'FORBIDDEN_ATTEMPTS_FATAL_EVEN_IF_CAUGHT'):
                            with guard:
                                with self.assertRaisesRegex(SourceBoundaryViolation, 'SOURCE_ONLY_FORBIDDEN:'+category):
                                    action()
                                self.assertEqual(guard.attempts[category], 1)
                        self.assertFalse(guard.active)
                        self.assertEqual(guard.attempts[category], 1)
                        self.assertEqual(sum(guard.attempts.values()), 1)
                        self.assertEqual(guard.receipt('GENERATED_STOP')['forbidden_attempts'][category], 1)
                self.assertFalse((directory/'outside.txt').exists())
                self.assertFalse((output/'EXECUTION_CLAIMS').exists())
        finally:
            sys.modules.pop(fixture.__name__, None)

    def test_allowlisted_generated_read_and_source_output_have_zero_forbidden_attempts(self):
        from source_guard import SourceOnlyGuard, current_guard
        with tempfile.TemporaryDirectory(dir=s.HERE, prefix='GENERATED_GUARD_') as td:
            directory = Path(td)
            output = directory/'output'; output.mkdir()
            allowed = directory/'GENERATED_ALLOWED.txt'; allowed.write_text('generated only')
            guard = SourceOnlyGuard(write_roots=(output,), read_paths=(allowed,))
            with guard:
                self.assertIs(current_guard(), guard)
                self.assertEqual(allowed.read_text(), 'generated only')
                (output/'SOURCE_ONLY.json').write_text('{"generated_only":true}')
                guard.checkpoint('GENERATED_SOURCE_OUTPUT_ONLY')
            self.assertIsNone(current_guard())
            self.assertFalse(guard.active)
            self.assertFalse(any(guard.attempts.values()))
            receipt = guard.receipt('GENERATED_PASS')
            self.assertEqual(receipt['observed_workspace_read_paths'][str(allowed)], 1)
            self.assertEqual(len(receipt['checkpoints']), 1)
            self.assertEqual(json.loads((output/'SOURCE_ONLY.json').read_text()), {'generated_only': True})


class EphemeralRecordingAndProviderTests(unittest.TestCase):
    def test_nine_recording_scopes_are_metadata_only_and_revoked(self):
        scopes = []
        def record(*, scope, metadata):
            self.assertTrue(scope.validate_current())
            scopes.append(scope)
            self.assertTrue(metadata['recording_only'])
            for key in ('historical_execution_authorized', 'financial_constructor_authorized',
                        'provider_iteration_authorized', 'process_launch_authorized', 'claims_authorized'):
                self.assertFalse(metadata[key])
            provider = s.CapturedMinuteProvider(2025, ())
            with self.assertRaises(ValueError):
                provider._bind_historical_scope(scope)
            return metadata
        result = e._record_metadata_cells(fake_preparation(), 'b'*64, record, domain='GENERATED_FAKE_METADATA')
        self.assertEqual(result['recording_scopes_created'], 9)
        self.assertEqual(result['recording_scopes_revoked'], 9)
        for key in ('historical_scopes_created', 'accounts_constructed', 'accounts_advanced',
                    'provider_iterations', 'process_launches', 'canonical_financial_claims', 'financial_GO_written'):
            self.assertEqual(result[key], 0)
        self.assertEqual([r['cell_id'] for r in result['records']], list(e.tranche_cells()))
        self.assertFalse(e._METADATA_ACTIVE)
        for scope in scopes:
            with self.assertRaisesRegex(ValueError, 'REVOKED'):
                scope.validate_current()
            with self.assertRaisesRegex(ValueError, 'REVOKED'):
                _ = scope.metadata

    def test_recording_scope_revoked_on_callback_exception(self):
        held = []
        def broken(*, scope, metadata):
            held.append(scope)
            raise RuntimeError('GENERATED_CALLBACK_FAILURE')
        with self.assertRaisesRegex(RuntimeError, 'GENERATED_CALLBACK_FAILURE'):
            e._record_metadata_cells(fake_preparation(), 'b'*64, broken, domain='GENERATED_FAKE_METADATA')
        self.assertEqual(len(held), 1)
        self.assertFalse(e._METADATA_ACTIVE)
        with self.assertRaisesRegex(ValueError, 'REVOKED'):
            held[0].validate_current()

    def test_actual_recording_domain_requires_separate_source_scope_before_callback(self):
        callback = Mock(side_effect=AssertionError('UNAUTHORIZED_CALLBACK'))
        for domain, scope in (('ACTUAL_PREPARED_SOURCE_METADATA', None),
                              ('ACTUAL_PREPARED_SOURCE_METADATA', object()),
                              ('GENERATED_FAKE_METADATA', object()),
                              ('GENERATED_IS_ACTUAL', None)):
            with self.subTest(domain=domain), self.assertRaises(ValueError):
                e._record_metadata_cells(fake_preparation(), 'b'*64, callback,
                                         domain=domain, source_stage_scope=scope)
        callback.assert_not_called()
        self.assertFalse(e._METADATA_ACTIVE)

    def test_unbound_provider_refuses_iteration_before_array_decode(self):
        provider = s.CapturedMinuteProvider(2025, (('GENERATED.npz', s.START, 1, b'not source', 0, 1),))
        with patch.object(p, 'month_arrays', side_effect=AssertionError('UNBOUND_PROVIDER_DECODE_FORBIDDEN')) as decode:
            with self.assertRaisesRegex(ValueError, 'HISTORICAL_PROVIDER_REQUIRES_SEPARATE_ROOT_GO'):
                next(provider())
            decode.assert_not_called()
        with self.assertRaisesRegex(ValueError, 'EXACT_FRESH_HISTORICAL_PROVIDER_ADMISSION'):
            provider._bind_historical_scope(object())


if __name__ == '__main__':
    unittest.main()
