"""Read-only independent checks of exact SOURCE-only admitted saved artifacts.

Never imports the producer. Never reads opaque cache, raw wrappers/CSVs, original
warmup bodies, mixed archive members, targets, accounts, outcomes, or holdouts.
"""
import os
for _k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[_k] = '1'
import sys
sys.dont_write_bytecode = True
import argparse, ast, calendar, copy, datetime, hashlib, io, json, stat, time, unittest, zipfile
from pathlib import Path, PurePosixPath
import numpy as np

ROOT = Path(__file__).resolve().parent.parent
OUT = Path(__file__).resolve().parent
MODULE = ROOT/'full2025_selective_source_qualification_20261015_v2'
PLAN = ROOT/'full2025_selective_source_qualification_plan_20261015'
AUTH = '165270343bcc5c8ff8e54e9b6a0728e45e1a8643ae02bb7a59d6c03a446c7f44'
CODE = '52e60cc8fa748b333f56eee7f28bc466b6342a1ff222ecf91f7fbc6dfa51a25d'
PACKAGE = 'c80b01eba58053c8d8d484e544467cccbdd2140a43ecda5d30027abcc63b2c1f'
CODE_REVIEW = '7b028890541a3320651efaa3a53eeb7e97307207ddfdf2149bd9929fc478ad6f'
PLAN_SHA = '43d55792b548442a8e5d8fce56aade148c7f73ec668bf6400d9788df33b236c2'
PLAN_REVIEW = '993aead4dae9e9cbcc1346beba49d6346f38d5700c847bb80ad0070cb40d28b7'
TRANSPORT = 'ab527c785ed1292cd90d866ef8f13ed9d17f2b11a5a52c1992e41a4670f5fbe9'
CACHE = 'a68b86a3bdf542625c8356b928e23ffea15eee53e11cd18d930b577a96313a4b'
INDEX = '8a0235e428902f7a0ea4ec1893343abae6ccc23715080771796b54fb58f1f3c4'
SELECTOR = 'f47338cba170f4f98223a4df43fc01ae30988cedede64424b69fda17a57228d2'
COMPLETION = '29d905ad88ca64da222b291ca018d8d835fb60bd375d68950132bdb511febed3'
GUARD = 'b0d2feaa8ef4344729565aa1514fb722f9d1a394e0a8c56c7aff288a9b962c10'
QUALIFICATION = '286c10b27e88da6fabf61d1c93f1375693b807183c132238dbcbb8f76d327cbb'
START, END, DAY, MINUTE = 1735689600000000, 1767225600000000, 86400000000, 60000000
SYMBOLS = ['BTCUSDT','ETHUSDT','SOLUSDT','XRPUSDT','DOGEUSDT']
CATEGORIES = ['financial_constructors','financial_account_advance','native_simulator_construct_or_advance',
 'historical_scope_mints','actual_provider_calls','process_launches','network_calls',
 'canonical_financial_claims_or_leases','financial_GO_writes','financial_imports',
 'outside_source_writes','nonallowlisted_file_reads']

def require(ok, message):
    if not ok: raise ValueError(message)

def sha(raw): return hashlib.sha256(raw).hexdigest()

def parse(raw):
    def pairs(items):
        d = {}
        for k,v in items:
            require(k not in d, 'duplicate JSON key')
            d[k] = v
        return d
    return json.loads(raw, object_pairs_hook=pairs,
        parse_constant=lambda _: (_ for _ in ()).throw(ValueError('nonfinite JSON')))

def no_symlink(path):
    path = Path(os.path.abspath(path))
    require(not any(p.is_symlink() for p in [path,*path.parents]), 'symlink')
    return path

def relative(root, name):
    require(isinstance(name,str) and name and '\\' not in name and ':' not in name and '\0' not in name, 'unsafe name')
    require(not PurePosixPath(name).is_absolute() and all(p not in ('','.','..') for p in name.split('/')), 'unsafe path')
    return no_symlink(root/name)

def npz_arrays(raw, shapes, dtypes):
    """Inspect all exact permitted numeric headers before loading any arrays."""
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        infos = z.infolist()
        names = [i.filename for i in infos]
        require(len(names)==len(set(names)) and set(names)=={k+'.npy' for k in shapes}, 'NPZ member schema')
        for info in infos:
            require(info.orig_filename==info.filename and '/' not in info.filename and '\\' not in info.filename,
                    'NPZ unsafe name')
            require(not info.is_dir() and not info.flag_bits&1 and info.compress_type in (0,8), 'NPZ unsafe type')
            require(stat.S_IFMT(info.external_attr>>16) in (0,stat.S_IFREG), 'NPZ special member')
            require(0<info.file_size<67108864 and 0<=info.compress_size<67108864, 'NPZ size cap')
            key = info.filename[:-4]
            with z.open(info) as f:
                version = np.lib.format.read_magic(f)
                require(version in ((1,0),(2,0)), 'NPY version')
                reader = np.lib.format.read_array_header_1_0 if version==(1,0) else np.lib.format.read_array_header_2_0
                shape, fortran, dtype = reader(f, max_header_size=4096)
                require(shape==tuple(shapes[key]) and dtype==np.dtype(dtypes[key]) and not dtype.hasobject and not fortran,
                        'NPY shape dtype')
                require(f.tell()+int(np.prod(shape))*dtype.itemsize==info.file_size, 'NPY payload')
    with np.load(io.BytesIO(raw),allow_pickle=False) as z:
        arrays = {k:z[k] for k in shapes}
    require(all(np.isfinite(a).all() for a in arrays.values()), 'nonfinite array')
    return arrays

def month_grid(times, lo, count):
    require(times.dtype==np.dtype('int64') and np.array_equal(times,np.arange(lo,lo+count*MINUTE,MINUTE,dtype=np.int64)),
            'minute grid')
    require(lo>=START and lo+count*MINUTE<=END, 'calendar outside 2025')

def guard_checks(g):
    require(g['schema']=='OBSERVED_FULL2025_SOURCE_GUARD_V1' and
            g['status']=='PASS_OBSERVED_ZERO_FORBIDDEN_ATTEMPTS' and g['error'] is None, 'guard status')
    require(set(g['forbidden_attempts'])==set(CATEGORIES) and
            all(type(v) is int and v==0 for v in g['forbidden_attempts'].values()), 'guard nonzero counter')
    require(g['attempted_targets']==[] and g['guard_active'] is False and g['scope_revoked'] is True, 'guard revocation')
    require(g['financial_execution_authorized'] is False and g['historical_execution_authorized'] is False, 'guard finance authority')
    require(0<=g['elapsed_CPU_seconds']<=300 and 0<=g['elapsed_wall_seconds']<=900, 'guard resource duration')
    labels=[c['label'] for c in g['checkpoints']]
    expected=['ALL_217_OPAQUE_IDENTITIES_REHASHED','SELECTED_OUTER_METADATA_PASSED_NO_BODIES_YET'] + \
      ['EXACT_CANONICAL_MONTH_2025-%02d'%m for m in range(1,13)] + \
      ['ALL_SOURCE_QUALIFICATION_AND_PROOFS_PASSED','BEFORE_SCOPE_REVOCATION']
    require(labels==expected, 'whole-run checkpoints')
    require(all(c['attempts']==g['forbidden_attempts'] for c in g['checkpoints']), 'checkpoint counter')
    require(g['source_stage_authorization_SHA256']==AUTH and g['code_manifest_SHA256']==CODE and
            g['independent_code_review_SHA256']==CODE_REVIEW, 'guard exact pins')
    return g['source_observed_counters']

def windows_check(warm_t,warm_c,completed,proof):
    require(warm_t.shape==(200,) and warm_c.shape==(200,5) and (warm_c>0).all(), 'warmup schema/value')
    require(np.array_equal(warm_t,np.arange(START-199*DAY,START+DAY,DAY,dtype=np.int64)), 'warmup calendar')
    require(set(completed)==set(range(START+DAY,END+DAY,DAY)), '365 completed closes')
    t=np.concatenate([warm_t,np.arange(START+DAY,END+DAY,DAY,dtype=np.int64)])
    c=np.vstack([warm_c,np.array([completed[x] for x in range(START+DAY,END+DAY,DAY)],dtype=np.float64)])
    require(len(proof)==365,'365 windows')
    for n,p in enumerate(proof):
        decision=START+n*DAY
        expected=dict(decision_us=decision,rows=200,first_available_us=decision-199*DAY,last_available_us=decision,
            clocks_SHA256=sha(t[n:n+200].tobytes()),close_matrix_SHA256=sha(c[n:n+200].tobytes()),nonimputed_trade_closes=True)
        require(p==expected,'window parity/past bound')

class SavedReview:
    def __init__(self):
        self.reads={};self.checks=[];self.allowed=set();self.body_reads=0
    def allow(self,p):
        p=no_symlink(p);self.allowed.add(p);return p
    def read(self,p,pin=None):
        p=no_symlink(p);require(p in self.allowed,'nonallowlisted review read')
        fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW)
        with os.fdopen(fd,'rb') as f:
            before=os.fstat(f.fileno());require(stat.S_ISREG(before.st_mode),'nonregular')
            raw=f.read();after=os.fstat(f.fileno())
        stable=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
        require(stable(before)==stable(after) and len(raw)==before.st_size,'input changed during read')
        row=dict(bytes=len(raw),SHA256=sha(raw))
        if pin: require(row=={k:pin[k] for k in ('bytes','SHA256')},'exact file identity: '+p.name)
        name=str(p.relative_to(ROOT));prev=self.reads.get(name)
        require(prev is None or prev==row,'input changed between reads')
        self.reads[name]=row;return raw
    def json(self,p,pin=None): return parse(self.read(p,pin))
    def exact(self,p,s):
        raw=self.read(self.allow(p));require(sha(raw)==s,'external SHA pin: '+p.name);return parse(raw)
    def good(self,id,finding):self.checks.append(dict(id=id,status='PASS',finding=finding))
    def manifest(self,root,name,s):
        m=self.exact(root/name,s)
        for row in m['files']:self.read(self.allow(relative(root,row['file'])),row)
        return m
    def run(self):
        began=time.monotonic();cpu=time.process_time()
        require(os.sched_getaffinity(0)=={0},'review CPU0 affinity')
        code=self.manifest(MODULE,'CODE_MANIFEST.json',CODE)
        package=self.manifest(MODULE,'FROZEN_PACKAGE_MANIFEST.json',PACKAGE)
        plan=self.manifest(PLAN,'FROZEN_MANIFEST.json',PLAN_SHA)
        code_review=self.exact(ROOT/'full2025_selective_source_qualification_v2_independent_review_20261015/REVIEW.json',CODE_REVIEW)
        plan_review=self.exact(ROOT/'full2025_selective_source_qualification_plan_independent_review_20261015/REVIEW.json',PLAN_REVIEW)
        require(code_review['FAIL_count']==0 and code_review['actual_source_body_reads']==0 and
            plan_review['FAIL_count']==0 and plan_review['PASS_count']==124,'prior reviews')
        auth=self.exact(MODULE/'ROOT_SOURCE_AUTHORIZATION_APPROVED_20261015_1344.json',AUTH)
        require(auth['bindings']==dict(code_manifest_SHA256=CODE,independent_code_review_SHA256=CODE_REVIEW,
            frozen_plan_SHA256=PLAN_SHA,independent_plan_review_SHA256=PLAN_REVIEW,
            complete_transport_receipt_SHA256=TRANSPORT,opaque_cache_index_SHA256=CACHE,
            raw_selection_manifest_SHA256=SELECTOR,source_index_SHA256=INDEX),'authorization bindings')
        require(auth['schema']=='EXTERNAL_FULL2025_SOURCE_STAGE_AUTHORIZATION_V1' and
            auth['status']=='APPROVED_SOURCE_ONLY' and auth['root_source_qualification_authorized'] is True and
            auth['stage']=='SELECTIVE_FULL2025_SOURCE_QUALIFICATION_ONLY' and
            auth['action']=='QUALIFY_EXACT_FULL2025_SOURCE_ONLY' and auth['calendar_us']==[START,END] and
            auth['symbols']==SYMBOLS and auth['historical_execution_authorized'] is False and
            auth['financial_execution_authorized'] is False,'source-only authority')
        require(auth['limits']==dict(CPU_affinity=[8],CPU_seconds=300,wall_seconds=900,workers=1,
            additional_disk_bytes=268435456,new_network_requests=0),'authority limits')
        require(auth['priority_release']=='ROOT_RELEASED_CPU8_FOR_SOURCE_QUALIFICATION','priority release')
        require(auth['permitted_actions']==['REHASH_EXACT_217_OPAQUE_CACHE_IDENTITIES','REASSEMBLE_EXACT_PINNED_H1_AND_H2',
            'INSPECT_SELECTED_CENTRAL_DIRECTORIES','READ_EXACT_180_SOURCE_ARCHIVES_AND_120_CHECKSUMS',
            'READ_EXACT_QUALIFIED_2024_PAST_ONLY_CLOSE_WARMUP','WRITE_EXACT_15_CANONICAL_SOURCE_FILES',
            'WRITE_SOURCE_ONLY_365_WINDOW_ENDPOINT_UNIT_CLOCK_PROOFS'],'authority actions')
        self.good('AUTHORITY_CODE_PLAN_CLOSURE','Exact external authority, 8-code/16-package/20-plan members and both prior reviews independently hash checked.')
        prior_root=ROOT/'full2025_qualified_source_independent_review_20261015'
        prior=self.exact(prior_root/'REVIEW.json','57124711e7e8badd8fd59358e5fb5bbf01634303aae9234e90d8f95da36cb7ff')
        self.manifest(prior_root,'FROZEN_MANIFEST.json','c2c23612bcfe52e948079de443665f069a300d4bfcc82257f7fae8f829fc3b79')
        old_base=ROOT/'full2025_selective_source_qualification_20261015/source_runs/7b788d09bd45b8307bcef20d3dfd63e9239957179cc442c6a24720aa12ba19da'
        self.exact(old_base/'STOP_SOURCE_QUALIFICATION.json','42258a5a396c75348766629342bb95071e99e228bfe1860b2df264fda3906475')
        self.exact(old_base/'OBSERVED_SOURCE_GUARD_RECEIPT.json','a210d7108f1fafee7b97f56db732f2768b319e0b0380b8756e45709df6667d1a')
        require(prior['source_qualification_pass'] is False and prior['canonical_admission_exists'] is False,
                'preserved prior genuine failure')
        self.good('PRESERVED_V1_TERMINAL_FAILURE','Original v1 STOP/observed guard and independently frozen blocked-review package remain exact; no reinterpretation as an admitted source stage.')
        contract=self.json(PLAN/'EXACT_SELECTION_CONTRACT.json');checks=self.json(PLAN/'QUALIFICATION_CHECKS.json')
        cache_contract=self.json(PLAN/'CACHE_BINDING_SPEC.json')
        preserved=self.json(PLAN/'OBSERVED_METADATA_CODE_PINS.json')['observed_metadata_code_files']
        for row in preserved:self.read(self.allow(relative(ROOT,row['path'])),row)
        selector=self.exact(relative(ROOT,contract['source_selector_manifest']['path']),SELECTOR)
        transport=self.exact(ROOT/'full2025_bounded_source_transport_20261015/FINAL_OPAQUE_TRANSPORT_RECEIPT.json',TRANSPORT)
        cache=self.exact(ROOT/'full2025_bounded_source_transport_20261015/OPAQUE_CACHE_INDEX.json',CACHE)
        require(transport['opaque_cache_index_SHA256']==CACHE and len(cache['cache_objects'])==217,'transport closure')
        cache_map={r['cache_path']:r for r in cache['cache_objects']}
        require(len(cache_map)==217,'cache uniqueness')
        for row in cache_contract['objects']:
            actual=cache_map[row['cache_path']]
            require({k:actual[k] for k in ('bytes','SHA256','GitBlobSHA1')}==row['expected'] and
                actual['commit']==row['original_commit'] and actual['path']==row['original_path'],'cache metadata identity')
        self.good('TRANSPORT_SELECTOR_PRESERVATION','217 metadata lineage identities and 37 preserved metadata/code files verified; no opaque body rehash by reviewer.')
        base=MODULE/'source_runs'/AUTH;stage=base/'qualified_source_only_pending_review'
        require(not (base/'STOP_SOURCE_QUALIFICATION.json').exists() and not (base/'unadmitted').exists(),'STOP/unadmitted exists')
        completion=self.exact(base/'SOURCE_STAGE_COMPLETION.json',COMPLETION)
        require(completion==dict(status='SOURCE_ONLY_QUALIFIED_PENDING_INDEPENDENT_ACTUAL_REVIEW',
            source_stage_authorization_SHA256=AUTH,code_manifest_SHA256=CODE,output='qualified_source_only_pending_review',
            historical_execution_authorized=False,financial_execution_authorized=False),'completion scope')
        guard=self.exact(base/'OBSERVED_SOURCE_GUARD_RECEIPT.json',GUARD);counters=guard_checks(guard)
        allowed_stage_reads={MODULE/'ROOT_SOURCE_AUTHORIZATION_APPROVED_20261015_1344.json',MODULE/'CODE_MANIFEST.json',
            ROOT/'full2025_selective_source_qualification_v2_independent_review_20261015/REVIEW.json',
            ROOT/'full2025_bounded_source_transport_20261015/FINAL_OPAQUE_TRANSPORT_RECEIPT.json',
            ROOT/'full2025_bounded_source_transport_20261015/OPAQUE_CACHE_INDEX.json',PLAN/'FROZEN_MANIFEST.json',
            ROOT/'full2025_selective_source_qualification_plan_independent_review_20261015/REVIEW.json'}
        allowed_stage_reads.update(relative(MODULE,p['file']) for p in code['files'])
        allowed_stage_reads.update(relative(PLAN,p['file']) for p in plan['files'])
        allowed_stage_reads.update(relative(ROOT,p['path']) for p in preserved)
        allowed_stage_reads.update(relative(ROOT,p['cache_path']) for p in cache_contract['objects'])
        allowed_stage_reads.update(relative(ROOT,p['path']) for p in contract['january_reuse']['wrapper_pins'])
        allowed_stage_reads.add(relative(ROOT,contract['past_warmup']['file']))
        original_stage=base/'unadmitted'
        for name,count in guard['observed_workspace_read_paths'].items():
            p=Path(name)
            require(p.is_absolute() and type(count) is int and count>0 and
                (p in allowed_stage_reads or original_stage in p.parents), 'observed non-source input path')
        receipt=self.exact(stage/'SOURCE_QUALIFICATION_RECEIPT.json',QUALIFICATION)
        require(receipt['status']=='PASS_EXACT_SOURCE_ONLY_PENDING_INDEPENDENT_ACTUAL_SOURCE_REVIEW' and
            receipt['schema']=='FULL2025_SELECTIVE_SOURCE_QUALIFICATION_RECEIPT_V1' and
            receipt['source_stage_authorization_SHA256']==AUTH and receipt['source_observed_counters']==counters and
            receipt['financial_execution_authorized'] is False and receipt['historical_execution_authorized'] is False,'source receipt')
        require(receipt['original_normalizer_SHA256']=='ee394086066c96bc23e83b45bf0bc2777264ab4eb57128886394fee47fecd4ff' and
            receipt['role']=='ALREADY_SEEN_2025_DEVELOPMENT_EXACT_RAW_SOURCE' and
            receipt['original_index_PASS_labels_are_provenance_only'] is True and
            receipt['SEAM08']=='FUTURE_SEPARATE_2025_D_ADAPTER_TARGET_ADMISSION_REQUIRED','normalizer/provenance-only receipt')
        tree=ast.parse(self.read(ROOT/'native_2025_source_restore_20261015/metadata/original_normalize.py'))
        wanted={'PRICE_COLUMNS','FUND_COLUMNS','month_limits','numeric_csv','deduplicate','validate_price','validate_funding'}
        nodes=[];found=set()
        for node in tree.body:
            name=getattr(node,'name',None)
            if isinstance(node,ast.Assign) and len(node.targets)==1:name=getattr(node.targets[0],'id',None)
            if name in wanted:nodes.append(node);found.add(name)
        require(found==wanted,'exact original pure AST names')
        pure=ast.Module(body=[ast.ImportFrom(module='__future__',names=[ast.alias(name='annotations')],level=0),*nodes],type_ignores=[])
        require(sha((ast.unparse(pure)+'\n').encode())==receipt['pure_normalizer_AST_SHA256'],'original pure AST identity')
        expected_counts=dict(opaque_objects_rehashed=217,opaque_bytes_rehashed=156670939,selected_outer_bodies=120,
            selected_inner_bodies=180,selected_checksum_bodies=120,archive_reassemblies=61,canonical_files_written=15)
        require(all(counters[k]==v for k,v in expected_counts.items()) and
            0<counters['inner_decompressed_bytes']<=12079595520,'source observed counters')
        require(set(counters)==set(expected_counts)|{'inner_decompressed_bytes'},'source counter schema')
        self.good('OBSERVED_WHOLE_RUN_GUARD','12 observed forbidden categories zero at all 16 ordered checkpoints; source scope revoked, guard inactive; exact source counts and observed workspace read-path allowlist closure.')
        rehash=self.json(self.allow(stage/'OPAQUE_CACHE_REHASH_RECEIPT.json'))
        require(rehash['status']=='PASS_EXACT_217_OPAQUE_IDENTITIES' and len(rehash['objects'])==217,'rehash receipt')
        rehash_map={r['cache_path']:r for r in rehash['objects']};require(len(rehash_map)==217,'rehash duplicates')
        for row in cache_contract['objects']:
            require(rehash_map[row['cache_path']]==dict(cache_path=row['cache_path'],**row['expected']),'observed rehash metadata')
        raw=self.json(self.allow(stage/'RAW_SELECTED_SOURCE_RECEIPT.json'))
        require(raw['status']=='PASS_EXACT_SELECTED_SOURCE_ARCHIVES' and raw['whole_wrapper_testzip_used'] is False and
            raw['inner_metadata_previously_unknown'] is True and len(raw['raw_archives'])==180,'selected raw receipt')
        selections={s['selection_id']:s for s in contract['selectors']};prov={s['selection_id']:s for s in contract['provenance_supplement']}
        require(len(selections)==180 and len({r['selection_id'] for r in raw['raw_archives']})==180,'selector uniqueness')
        raw_inner_bytes=0
        for row in raw['raw_archives']:
            s=selections[row['selection_id']];p=prov[row['selection_id']];inner=row['inner_metadata']
            require(row['raw_bytes']==s['bytes'] and row['raw_SHA256']==s['SHA256'] and
                all(row[k]==s[k] for k in ('symbol','family','month')) and row['source_commit']==p['source_commit'] and
                row['inherited_commit_reason']==p['inherited_commit_reason'] and row['original_source_index_SHA256']==INDEX and
                row['selected_inner_CRC_checked_to_EOF'] is True,'raw selector/CRC binding')
            require(row['source_lineage']=={k:s[k] for k in ('transport','wrapper','wrapper_SHA256','member','raw_path','checksum_member') if k in s},'raw lineage')
            require(inner['member']==p['expected_inner_csv_basename'] and inner['regular'] is True and
                inner['encrypted'] is False and inner['compression'] in (0,8) and 0<inner['bytes']<=67108864 and
                0<=inner['compressed_bytes']<=67108864 and type(inner['CRC']) is int,'inner safe metadata')
            month=int(s['month'][-2:]);expected=s['expected_events'] if s['family']=='fundingRate' else calendar.monthrange(2025,month)[1]*1440
            require(row['rows']==expected,'selected rows');raw_inner_bytes+=inner['bytes']
        require(raw_inner_bytes==counters['inner_decompressed_bytes'],'aggregate inner bytes')
        expected_outer={}
        for s in selections.values():
            if s['transport']=='H2_RAW_PARTS':continue
            expected_outer.setdefault(s['member'],[]).append(s)
            if 'checksum_member' in s:expected_outer.setdefault(s['checksum_member'],[]).append(s)
        require(len(raw['wrapper_selected_body_reads'])==180,'120 raw outer plus 60 checksum reads')
        observed_outer={r['member']:r for r in raw['wrapper_selected_body_reads']}
        require(set(observed_outer)==set(expected_outer),'selected outer exact member closure')
        for name,row in observed_outer.items():
            require(row['selected_CRC_checked_to_EOF'] is True and row['regular'] is True and row['encrypted'] is False,'outer metadata')
            s=expected_outer[name][0]
            if name==s['member']:require(row['SHA256']==s['SHA256'] and row['bytes']==s['bytes'] and
                ('CRC' not in s or row['CRC']==s['CRC']),'outer raw exact SHA/CRC')
            else: require(0<row['bytes']<=4096,'checksum size')
        self.good('ACTUAL_SELECTED_SOURCE_RECEIPTS','Observed 217 rehash identities, 180 raw selector/rows/inner-CRC bindings, 120 checksums and selected-only outer closure validated as saved evidence.')
        require(receipt['canonical_source_files']==checks['canonical_expected_source_files'] and receipt['canonical_bytes']==46269167 and
            receipt['source_calendar_us']==[START,END] and receipt['symbols']==SYMBOLS and
            receipt['days']==365 and receipt['minutes_per_asset_per_family']==525600 and receipt['raw_archive_selections']==180 and
            receipt['original_source_index_SHA256']==INDEX and receipt['warmup_source_SHA256']==contract['past_warmup']['SHA256'], 'canonical receipt')
        prepared=stage/'prepared_2025';pins=checks['canonical_expected_source_files']
        require({str(p.relative_to(prepared)) for p in prepared.rglob('*') if p.is_file()}=={p['file'] for p in pins},'canonical file closure')
        require(len(pins)==15 and sum(p['bytes'] for p in pins)==46269167,'canonical count bytes')
        for pin in pins:self.read(self.allow(relative(prepared,pin['file'])),pin)
        self.good('EXACT_CANONICAL_IDENTITIES','Exactly 15 saved canonical files, 46,269,167 bytes, independently verified against original frozen SHA256 and sizes; original SOURCE_INDEX exact.')
        completed={};daily_expected={};last={};marks={s:[] for s in SYMBOLS};endpoints={}
        keys=checks['schema']['monthly_keys']
        for month in range(1,13):
            count=calendar.monthrange(2025,month)[1]*1440
            lo=int(datetime.datetime(2025,month,1,tzinfo=datetime.timezone.utc).timestamp())*1000000
            arrays=npz_arrays(self.read(prepared/('months/2025-%02d.npz'%month)),{k:(count,) for k in keys},
                {k:'int64' if k=='times' else 'float64' for k in keys});self.body_reads+=1
            month_grid(arrays['times'],lo,count)
            for s in SYMBOLS:
                for field in ('open','close','quote_volume','mark'):
                    a=arrays[s+'_'+field];require((a>=0).all() if field=='quote_volume' else (a>0).all(),'price/volume sign')
                for n in range(count//1440):
                    at=lo+n*DAY
                    close=float(arrays[s+'_close'][(n+1)*1440-1]);completed.setdefault(at+DAY,[None]*5)[SYMBOLS.index(s)]=close
                    if n:daily_expected[s,at]=float(arrays[s+'_close'][n*1440-1])
                    elif at>START:daily_expected[s,at]=last[s]
                last[s]=float(arrays[s+'_close'][-1]);marks[s].append(arrays[s+'_mark'])
                if month==12:endpoints[s]=(float(arrays[s+'_close'][-1]),float(arrays[s+'_mark'][-1]))
        warm=npz_arrays(self.read(self.allow(stage/'SOURCE_WARMUP_200_CLOSE_ONLY.npz')),
            {'close_available_us':(200,),'close':(200,5)},{'close_available_us':'int64','close':'float64'});self.body_reads+=1
        for i,s in enumerate(SYMBOLS):daily_expected[s,START]=float(warm['close'][-1,i])
        daily=self.json(prepared/'DAILY.json');events=self.json(prepared/'EVENTS.json');index=self.json(prepared/'SOURCE_INDEX.json')
        require(len(daily)==1825 and len({(r['symbol'],r['close_us']) for r in daily})==1825,'daily count/duplicate')
        for r in daily:
            require(set(r)=={'symbol','close_us','close'} and (r['symbol'],r['close_us']) in daily_expected and
                r['close']==daily_expected[r['symbol'],r['close_us']],'daily native minute parity')
        require(index['calendar']==[START,END] and index['symbol_order']==SYMBOLS,'index calendar')
        self.good('NUMERIC_SCHEMA_GRID_DAILY','12 exact NPZ numeric key/dtype/header/payload grids, positive finite prices/nonnegative volumes, 525600 minutes and 1825 daily prior-close values independently checked.')
        require(len(events)==5475 and events==sorted(events,key=lambda e:(e['event_us'],e['symbol'])),'funding count/order')
        caveats=self.json(self.allow(stage/'SOURCE_UNIT_CLOCK_CAVEATS.json'))
        require(caveats['raw_rate_unit']=='UNCONFIRMED' and caveats['historical_arrival_certified'] is False and
            caveats['raw_rate_conversion_performed'] is False and caveats['closure_clock_assumption_only'] is True and
            caveats['financial_charge_created'] is False and caveats['source_coverage_implies_ownership'] is False and
            caveats['initial_prior_mark']=='FLAT_UNOWNED_PRIORUNKNOWN_NO_FABRICATION','unit arrival caveats')
        require(receipt['raw_rate_unit']=='UNCONFIRMED' and receipt['historical_arrival_certified'] is False,'receipt caveats')
        funding_summaries=[]
        for s in SYMBOLS:
            rows=[e for e in events if e['symbol']==s];clocks=np.array([e['event_us'] for e in rows],dtype=np.int64)
            require(len(rows)==1095 and len(set(map(int,clocks)))==1095 and
                np.all(np.abs(clocks-np.arange(START,END,480*MINUTE,dtype=np.int64))<=1000000) and
                np.all(np.abs(np.diff(clocks)-480*MINUTE)<=1000000),'funding cadence')
            for e in rows:require(set(e)=={'symbol','event_us','raw_rate','reported_interval_hours'} and
                type(e['event_us']) is int and e['event_us']%1000==0 and START<=e['event_us']<END and e['reported_interval_hours']==8.0 and np.isfinite(e['raw_rate']),'funding schema/units')
            for m in range(1,13):
                lo=int(datetime.datetime(2025,m,1,tzinfo=datetime.timezone.utc).timestamp())*1000000
                hi=lo+calendar.monthrange(2025,m)[1]*DAY
                sel=next(x for x in selections.values() if x['symbol']==s and x['family']=='fundingRate' and x['month']=='2025-%02d'%m)
                require(sum(lo<=int(t)<hi for t in clocks)==sel['expected_events'],'funding monthly count')
            funding_summaries.append(dict(symbol=s,events=1095,min_event_us=int(clocks[0]),max_event_us=int(clocks[-1]),
                max_8h_cadence_jitter_us=int(np.max(np.abs(np.diff(clocks)-480*MINUTE))),raw_rate_unit='UNCONFIRMED',historical_arrival_certified=False))
        require(caveats['funding_by_symbol']==funding_summaries,'funding summary parity')
        marks={s:np.concatenate(chunks) for s,chunks in marks.items()}
        diagnostics=caveats['strict_past_mark_source_proofs'];require(len(diagnostics)==5475,'mark proof count')
        for e,p in zip(events,diagnostics):
            at=e['event_us'];n=(at-START-1)//MINUTE-1
            if n<0:expected=dict(symbol=e['symbol'],event_us=at,status='BOUNDARY_PRIOR_MARK_UNKNOWN',prior_mark_fabricated=False)
            else:
                available=START+(n+1)*MINUTE
                expected=dict(symbol=e['symbol'],event_us=at,status='SOURCE_STRICTLY_PAST_MARK_AVAILABLE',native_minute_open_us=available-MINUTE,
                    available_us=available,gap_us=at-available,raw_mark=float(marks[e['symbol']][n]),
                    source_arrival_assumption='CLOSURE_CLOCK_UNCERTIFIED',financial_charge_created=False)
                require(0<at-available<=MINUTE,'strict past mark clock')
            require(p==expected,'strict past mark parity')
        self.good('FUNDING_CLOCK_UNITS','5475 raw-rate events, 1095 per asset, exact monthly counts/8h cadence, all strictly-past mark diagnostics checked; units and arrival remain uncertified and no charge or ownership inferred.')
        window=self.json(self.allow(stage/'SOURCE_200_CLOSE_WINDOW_PROOF.json'))
        require(window['status']=='PASS_SOURCE_ONLY_365_PAST_200_CLOSE_WINDOWS' and window['symbols']==SYMBOLS and
            window['warmup_source_SHA256']==contract['past_warmup']['SHA256'] and window['targets_generated'] is False and
            window['historical_execution_authorized'] is False,'window receipt scope')
        windows_check(warm['close_available_us'],warm['close'],completed,window['windows'])
        self.good('PAST_WARMUP_365_WINDOWS','200-row close-only projection schema/support checked; all 365 structural window clocks and close-matrix hashes independently rebuilt from saved warmup and genuine monthly completed closes. No covariance/targets.')
        endpoint=self.json(self.allow(stage/'SOURCE_DEC31_ENDPOINT_WITNESS.json'))
        require(endpoint['status']=='PASS_GENUINE_DEC31_NATIVE_ENDPOINT' and endpoint['no_2026_daily_cube_row'] is True and
            endpoint['no_execution_authority'] is True and len(endpoint['endpoints'])==5,'endpoint receipt scope')
        for p,s in zip(endpoint['endpoints'],SYMBOLS):
            dec=next(p for p in pins if p['file']=='months/2025-12.npz')
            require(p==dict(symbol=s,native_minute_open_us=END-MINUTE,source_available_us=END,trade_close=endpoints[s][0],
                mark_close=endpoints[s][1],source_file='months/2025-12.npz',source_SHA256=dec['SHA256'],role='SOURCE_ENDPOINT_WITNESS_ONLY',
                feature_row_created=False),'Dec31 endpoint parity')
        require(not (stage/'NEW_2025_GAP_CLASSIFICATION.json').exists(),'new gap stops PASS')
        permitted_top={'H1_2025.zip','prepared_2025','SOURCE_WARMUP_200_CLOSE_ONLY.npz','OPAQUE_CACHE_REHASH_RECEIPT.json',
            'RAW_SELECTED_SOURCE_RECEIPT.json','SOURCE_200_CLOSE_WINDOW_PROOF.json','SOURCE_DEC31_ENDPOINT_WITNESS.json',
            'SOURCE_UNIT_CLOCK_CAVEATS.json','SOURCE_QUALIFICATION_RECEIPT.json'}
        require({p.name for p in stage.iterdir()}==permitted_top,'source-only top-level output closure')
        require(all(not p.is_symlink() for p in base.rglob('*')),'output symlink')
        disk=sum(p.stat().st_size for p in base.rglob('*') if p.is_file())
        require(disk<=268435456,'additional disk cap')
        self.good('ENDPOINT_GAP_OUTPUT_SCOPE','Five Dec31 last-minute witnesses independently match canonical arrays; no 2026 monthly/daily cube, new gap receipt, imputation output, financial output or alternate admission. Exact output closure and disk cap checked.')
        self.good('RESOURCE_LIMITS','Saved guarded CPU/wall durations and current output disk fit hard caps. CPU8/single-thread/2GB enforcement is configured in exact launcher; runtime telemetry unavailable, not independently observed throughout.')
        # Every byte read is checked again. No previously unseen file is opened here.
        snapshot=dict(self.reads)
        for name,pin in snapshot.items():self.read(ROOT/name,pin)
        self.good('READ_ONLY_STABILITY','All reviewed saved artifacts, preserved metadata/code, frozen plan/package and authority bytes remained exact before/after. Reviewer opened no opaque/raw/original warmup/holdout bodies.')
        return dict(schema='INDEPENDENT_ACTUAL_FULL2025_SOURCE_ONLY_REVIEW_V2',status='PASS_SOURCE_ONLY_NO_FINANCIAL_GO',
            UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),PASS_count=len(self.checks),FAIL_count=0,checks=self.checks,
            source_stage_authorization_SHA256=AUTH,code_manifest_SHA256=CODE,frozen_package_manifest_SHA256=PACKAGE,
            independent_code_review_SHA256=CODE_REVIEW,frozen_plan_SHA256=PLAN_SHA,independent_plan_review_SHA256=PLAN_REVIEW,
            complete_transport_receipt_SHA256=TRANSPORT,opaque_cache_index_SHA256=CACHE,raw_selection_manifest_SHA256=SELECTOR,
            source_stage_completion_SHA256=COMPLETION,source_observed_guard_SHA256=GUARD,source_qualification_receipt_SHA256=QUALIFICATION,
            source_index_SHA256=INDEX,source_observed_counters=counters,forbidden_attempts=guard['forbidden_attempts'],
            source_elapsed_CPU_seconds=guard['elapsed_CPU_seconds'],source_elapsed_wall_seconds=guard['elapsed_wall_seconds'],
            source_output_disk_bytes=disk,canonical_source_files=15,canonical_bytes=46269167,
            reviewer=dict(CPU_affinity=sorted(os.sched_getaffinity(0)),BLAS_threads=1,CPU_seconds=time.process_time()-cpu,
                wall_seconds=time.monotonic()-began,saved_NPZ_bodies_checked=self.body_reads,opaque_cache_body_reads=0,
                original_wrapper_or_raw_CSV_body_reads=0,original_2024_warmup_body_reads=0,holdout_body_reads=0,
                producer_modules_imported=0,normalizations_launched=0,targets_generated=0,accounts_constructed=0,
                provider_calls=0,financial_runs=0,source_scope_issued=False),
            inherited_proofs=[
              'Actual opaque SHA/Git body identities and selected raw/CSV checksum, CRC, source-schema and exact normalization values are inherited from exact reviewed producer code and observed receipts; reviewer did not independently reparse raw sources.',
              'Past-only original 2024 warmup container identity/support/projection values are inherited from exact producer receipt/code; reviewer checks saved 200-row projection and all window parity only.',
              'Genuineness of normalized final Dec31 values inherits selected raw qualification; independently compared final canonical minute and endpoint witness.',
              'No-write guard and exact preserved metadata/code hashes support original immutability. Opaque original cache/wrapper body preservation was not independently rehashed after the stage.',
              'CPU8/single worker/numerical thread/2GB AS limits are configured in exact launcher; whole-run telemetry unavailable. Receipt directly observes CPU/wall; review directly measures saved disk.'
            ],financial_execution_authorized=False,historical_execution_authorized=False,
            source_stage_authorization_granted_by_this_review=False,financial_GO_granted=False,
            development_data_role='ALREADY_SEEN_2025_DEVELOPMENT_EXACT_RAW_SOURCE_NO_PRISTINE_OOS_CLAIM',
            pending_gates=['Separate exact authority and reviewed adapter for any actual 2025 D entry/targets/account/provider or financial execution.'],
            inputs=[dict(file=k,**v) for k,v in sorted(self.reads.items())])

class SelfTests(unittest.TestCase):
    def raw(self,**arrays):
        f=io.BytesIO();np.savez_compressed(f,**arrays);return f.getvalue()
    def test_numeric_npz(self):
        a=npz_arrays(self.raw(t=np.arange(3,dtype=np.int64)),{'t':(3,)},{'t':'int64'});self.assertEqual(a['t'].tolist(),[0,1,2])
    def test_extra_member(self):
        with self.assertRaises(ValueError):npz_arrays(self.raw(t=np.arange(3),extra=np.arange(3)),{'t':(3,)},{'t':'int64'})
    def test_wrong_dtype(self):
        with self.assertRaises(ValueError):npz_arrays(self.raw(t=np.arange(3,dtype=np.float64)),{'t':(3,)},{'t':'int64'})
    def test_wrong_shape(self):
        with self.assertRaises(ValueError):npz_arrays(self.raw(t=np.arange(4)),{'t':(3,)},{'t':'int64'})
    def test_object_dtype(self):
        with self.assertRaises(ValueError):npz_arrays(self.raw(t=np.array(['x'],dtype=object)),{'t':(1,)},{'t':'object'})
    def test_nonfinite(self):
        with self.assertRaises(ValueError):npz_arrays(self.raw(t=np.array([np.nan])),{'t':(1,)},{'t':'float64'})
    def test_grid(self):month_grid(np.arange(START,START+3*MINUTE,MINUTE,dtype=np.int64),START,3)
    def test_grid_gap(self):
        with self.assertRaises(ValueError):month_grid(np.array([START,START+2*MINUTE]),START,2)
    def test_future_grid(self):
        with self.assertRaises(ValueError):month_grid(np.array([END],dtype=np.int64),END,1)
    def test_duplicate_json(self):
        with self.assertRaises(ValueError):parse(b'{"x":1,"x":2}')
    def test_nonfinite_json(self):
        with self.assertRaises(ValueError):parse(b'{"x":NaN}')
    def test_unsafe_paths(self):
        for s in ('../x','/x','x/../y','x\\y','x:y'):
            with self.assertRaises(ValueError):relative(ROOT,s)
    def test_windows(self):
        t=np.arange(START-199*DAY,START+DAY,DAY,dtype=np.int64);c=np.ones((200,5))
        completed={x:[1.]*5 for x in range(START+DAY,END+DAY,DAY)}
        proofs=[]
        for n in range(365):
            d=START+n*DAY;tt=np.arange(d-199*DAY,d+DAY,DAY,dtype=np.int64)
            proofs.append(dict(decision_us=d,rows=200,first_available_us=d-199*DAY,last_available_us=d,
                clocks_SHA256=sha(tt.tobytes()),close_matrix_SHA256=sha(c.tobytes()),nonimputed_trade_closes=True))
        windows_check(t,c,completed,proofs)
        altered=copy.deepcopy(proofs);altered[-1]['last_available_us']=END
        with self.assertRaises(ValueError):windows_check(t,c,completed,altered)
        altered=copy.deepcopy(proofs);altered[0]['close_matrix_SHA256']='0'*64
        with self.assertRaises(ValueError):windows_check(t,c,completed,altered)
    def test_guard_rejects_nonzero_or_active(self):
        g=dict(schema='OBSERVED_FULL2025_SOURCE_GUARD_V1',status='PASS_OBSERVED_ZERO_FORBIDDEN_ATTEMPTS',error=None,
            forbidden_attempts=dict.fromkeys(CATEGORIES,0),attempted_targets=[],guard_active=False,scope_revoked=True,
            historical_execution_authorized=False,financial_execution_authorized=False,elapsed_CPU_seconds=1,elapsed_wall_seconds=1,
            checkpoints=[],source_stage_authorization_SHA256=AUTH,code_manifest_SHA256=CODE,independent_code_review_SHA256=CODE_REVIEW)
        g['forbidden_attempts']['actual_provider_calls']=1
        with self.assertRaises(ValueError):guard_checks(g)
        g['forbidden_attempts']['actual_provider_calls']=0;g['guard_active']=True
        with self.assertRaises(ValueError):guard_checks(g)
    def clean_guard(self):
        counters=dict.fromkeys(CATEGORIES,0)
        labels=['ALL_217_OPAQUE_IDENTITIES_REHASHED','SELECTED_OUTER_METADATA_PASSED_NO_BODIES_YET']+\
            ['EXACT_CANONICAL_MONTH_2025-%02d'%m for m in range(1,13)]+\
            ['ALL_SOURCE_QUALIFICATION_AND_PROOFS_PASSED','BEFORE_SCOPE_REVOCATION']
        return dict(schema='OBSERVED_FULL2025_SOURCE_GUARD_V1',status='PASS_OBSERVED_ZERO_FORBIDDEN_ATTEMPTS',error=None,
            forbidden_attempts=counters,attempted_targets=[],guard_active=False,scope_revoked=True,
            historical_execution_authorized=False,financial_execution_authorized=False,elapsed_CPU_seconds=1,elapsed_wall_seconds=1,
            checkpoints=[dict(label=x,attempts=dict(counters)) for x in labels],source_stage_authorization_SHA256=AUTH,
            code_manifest_SHA256=CODE,independent_code_review_SHA256=CODE_REVIEW,source_observed_counters={})
    def test_clean_whole_run_guard(self):self.assertEqual(guard_checks(self.clean_guard()),{})
    def test_missing_final_checkpoint(self):
        g=self.clean_guard();g['checkpoints'].pop()
        with self.assertRaises(ValueError):guard_checks(g)
    def test_unrevoked_scope(self):
        g=self.clean_guard();g['scope_revoked']=False
        with self.assertRaises(ValueError):guard_checks(g)
    def test_resource_overrun(self):
        for field,limit in [('elapsed_CPU_seconds',300),('elapsed_wall_seconds',900)]:
            g=self.clean_guard();g[field]=limit+1
            with self.assertRaises(ValueError):guard_checks(g)
    def test_wrong_authority_pin(self):
        g=self.clean_guard();g['source_stage_authorization_SHA256']='0'*64
        with self.assertRaises(ValueError):guard_checks(g)

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--completed-authorization-sha');parser.add_argument('--self-test',action='store_true');args=parser.parse_args()
    if args.self_test:
        result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(SelfTests))
        raise SystemExit(0 if result.wasSuccessful() else 1)
    require(args.completed_authorization_sha==AUTH,'exact completed root handoff is required')
    review=SavedReview().run()
    path=OUT/'REVIEW.json'
    with path.open('x') as f:json.dump(review,f,sort_keys=True,indent=2,allow_nan=False);f.write('\n')
    print(json.dumps({k:review[k] for k in ('status','PASS_count','FAIL_count','canonical_bytes','source_output_disk_bytes')}))

if __name__=='__main__':main()
