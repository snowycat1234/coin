"""Finite-year source/target gates only: actual account constructor is blocked."""
import hashlib
import json
from pathlib import Path
import shutil
import tempfile
import unittest
from unittest.mock import patch
import numpy as np
import annual_entry_2023 as a

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent/'native_2023_source_restore_20261015'


def raw(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':')).encode()


def fixture_go(preparation, configs=None):
    # Generated GO-shaped metadata only; tests always block actual construction.
    p = json.loads(preparation)
    body = raw(dict(schema='ROOT_GO_FIXED_FINITE_FULL2023_GRID_V1',
        action='RUN_FRESH_APPROVED_2023_CANONICAL_JOBS_ONLY',
        preparation_SHA256=hashlib.sha256(preparation).hexdigest(),
        calendar=[a.START,a.END], cost='BASE27', resource_limits=p['resource_limits'],
        permitted_configs=configs or [g[0] for g in p['execution_groups']],
        locked_or_holdout_consumed=False, other_years_authorized=False))
    return body,hashlib.sha256(body).hexdigest()


class AnnualEntryTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory(prefix='annual_source_gate_')
        cls.prepared = Path(cls.temp.name)/'prepared'
        with patch.object(a.n,'_construct_case',side_effect=AssertionError('NO_ACCOUNT')):
            cls.prep = a.prepare_source_only(SOURCE,cls.prepared)
        cls.preparation = (cls.prepared/'PREPARATION.json').read_bytes()

    @classmethod
    def tearDownClass(cls):
        cls.temp.cleanup()

    def test_source_only_scope_and_core_unchanged(self):
        self.assertEqual(self.prep['accounts_created'],0)
        self.assertFalse(self.prep['annual_returns_computed'])
        self.assertEqual(self.prep['days'],365)
        self.assertEqual(self.prep['required_minutes'],525600)
        self.assertEqual(self.prep['code_identity'],a.code_identity())
        self.assertEqual(self.prep['riskmatched_excess_method'],'NOT_PREREGISTERED_NOT_CLAIMED')

    def test_all365_exact_target_source_comparisons_do_not_approximate(self):
        eq=json.loads((self.prepared/'EXACT_EXECUTION_EQUALITY.json').read_bytes())
        self.assertEqual(eq['requested_matrix_cells'],9)
        self.assertEqual(eq['unique_execution_jobs'],9)
        self.assertTrue(eq['no_cross_tier_reuse'])
        for pair in eq['STATIC50_H090_comparisons']:
            self.assertFalse(pair['entire_target_path_byte_exact'])
            self.assertGreater(pair['different_float64_cells'],0)
            self.assertLess(pair['maximum_absolute_target_difference'],2e-16)

    def test_exact_generated_equality_only_deduplicates_within_tier(self):
        d=np.arange(a.START,a.END,a.g.DAY,dtype=np.int64)
        targets={s+'_'+t:np.zeros((365,5)) for s,t in a.g.CONFIGS}
        eq=a.target_equality_receipt(d,targets,np.zeros((365,5,5)),source_identity='1'*64,code={})
        self.assertEqual(eq['unique_execution_jobs'],3)
        self.assertTrue(all(len(group)==3 for group in eq['execution_groups']))
        targets['H090_LOW'][0,0]=np.nextafter(0.,1.)
        changed=a.target_equality_receipt(d,targets,np.zeros((365,5,5)),source_identity='1'*64,code={})
        self.assertEqual(changed['unique_execution_jobs'],4)

    def test_partial_calendar_cannot_claim_whole_year_equality(self):
        d=np.arange(a.START,a.START+3*a.g.DAY,a.g.DAY,dtype=np.int64)
        targets={s+'_'+t:np.zeros((3,5)) for s,t in a.g.CONFIGS}
        with self.assertRaisesRegex(ValueError,'FULL365'):
            a.target_equality_receipt(d,targets,np.zeros((3,5,5)),source_identity='1'*64,code={})

    def test_unknown_hash_missing_or_string_go_is_rejected(self):
        go,digest=fixture_go(self.preparation)
        for body,sha in [(None,None),(go,'0'*64),(go.decode(),digest)]:
            with self.assertRaises(ValueError):
                a.validate_root_go(self.preparation,body,sha,config='STATIC50_LOW')

    def test_pilot_scope_cannot_run_unapproved_remaining_job(self):
        go,digest=fixture_go(self.preparation,['STATIC50_LOW'])
        a.validate_root_go(self.preparation,go,digest,config='STATIC50_LOW')
        with self.assertRaises(ValueError):
            a.validate_root_go(self.preparation,go,digest,config='STATIC50_MID')

    def test_extra_year_cost_resource_and_holdout_expansions_rejected(self):
        go,_=fixture_go(self.preparation);base=json.loads(go)
        for key,value in [('calendar',[a.START,a.END+a.g.DAY]),('cost','STRESS43'),
                ('locked_or_holdout_consumed',True),('other_years_authorized',True),
                ('permitted_configs',['LEVERAGE2_HIGH']),
                ('resource_limits',{**base['resource_limits'],'per_case_wall_seconds':601})]:
            body=raw({**base,key:value})
            with self.subTest(key=key),self.assertRaises(ValueError):
                a.validate_root_go(self.preparation,body,hashlib.sha256(body).hexdigest(),config='STATIC50_LOW')

    def blocked_window(self):
        go,digest=fixture_go(self.preparation,['STATIC50_LOW'])
        with patch.object(a.n,'_construct_case',side_effect=RuntimeError('NO_ANNUAL_ACCOUNT')) as constructor:
            with self.assertRaisesRegex(RuntimeError,'NO_ANNUAL_ACCOUNT'):
                a.make_annual_case(SOURCE,self.prepared,go,digest,config='STATIC50_LOW')
        self.assertEqual(constructor.call_count,1)
        return constructor.call_args

    def test_positive_gate_stops_before_account_and_all365_readiness(self):
        args=self.blocked_window()
        window,rows,d,targets=args.args
        self.assertEqual([window['start'],window['end']],[a.START,a.END])
        self.assertEqual(d.shape,(365,))
        self.assertEqual(targets.shape,(365,5))
        self.assertEqual(len(rows),2820)
        self.assertTrue(all(row['available_us']<=row['close_us'] for row in rows))
        self.assertEqual(len(window['daily']),1825)
        self.assertEqual(len(window['events']),5475)

    def test_all12_captured_months_decode_after_path_reads_are_blocked(self):
        window=self.blocked_window().args[0]
        with patch.object(Path,'read_bytes',side_effect=AssertionError('LATE_REOPEN')):
            sizes=[];first=None;last=None
            for block in window['minute_blocks']():
                sizes.append(len(block['times']))
                if first is None:first=int(block['times'][0])
                last=int(block['times'][-1])
                self.assertEqual(set(block['market']),set(a.g.SYMBOLS))
                self.assertTrue(all(v.dtype==np.dtype('float64') and np.isfinite(v).all()
                    for fields in block['market'].values() for v in fields.values()))
        self.assertEqual(sizes,[1440]*365)
        self.assertEqual((first,last),(a.START,a.END-a.n.MINUTE))

    def test_artifact_tamper_rejected_before_source_or_account(self):
        copied=Path(self.temp.name)/'tampered';shutil.copytree(self.prepared,copied)
        with (copied/'TARGETS.npz').open('ab') as out:out.write(b'GENERATED_TAMPER')
        go,digest=fixture_go(self.preparation)
        with patch.object(a,'_source',side_effect=AssertionError('NO_SOURCE')), \
                patch.object(a.n,'_construct_case',side_effect=AssertionError('NO_ACCOUNT')):
            with self.assertRaisesRegex(ValueError,'EXACT_SOURCE_HASH'):
                a.make_annual_case(SOURCE,copied,go,digest,config='STATIC50_LOW')


if __name__=='__main__':unittest.main(verbosity=2)
