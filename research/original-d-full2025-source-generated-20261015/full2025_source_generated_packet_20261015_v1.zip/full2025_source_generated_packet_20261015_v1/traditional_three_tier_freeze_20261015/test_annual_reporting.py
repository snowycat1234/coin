"""Generated reporting/controller tests; no actual-source account execution."""
import hashlib
import json
import unittest
import numpy as np
import annual_reporting as r
import annual_entry_2023 as a
import run_actual_2023 as driver


def fixture():
    names=['nav','free_cash','isolated_balance','gross_weight','close_us']+[
        s+'_signed_weight' for s in a.g.SYMBOLS]
    data=np.zeros((4320,len(names)));data[:,0]=10000;data[:,1]=9000;data[:,2]=1000
    data[:,4]=np.arange(a.START+a.n.MINUTE,a.START+4321*a.n.MINUTE,a.n.MINUTE)
    data[:,5]=.1;data[:,3]=.1
    decisions=np.arange(a.START,a.START+3*a.g.DAY,a.g.DAY,dtype=np.int64)
    covariance=np.tile(np.eye(5)[None,:,:],(3,1,1))
    targets=np.ones((3,5))*.05
    return data,names,decisions,covariance,targets


class AnnualReportTests(unittest.TestCase):
    def test_forecast_budget_breach_is_reported_without_scaling(self):
        data,names,d,c,t=fixture();before=data.copy()
        report=r.risk_diagnostics(data,names,d,c,t,'LOW',[])
        self.assertEqual(report['forecast_volatility_breach_minutes'],4320)
        self.assertAlmostEqual(report['forecast_annual_volatility_max'],.1)
        self.assertAlmostEqual(report['forecast_volatility_breach_max_absolute'],.05)
        self.assertEqual(report['realized_daily_simple_return_annual_volatility'],0)
        self.assertEqual(report['riskmatched_excess_method'],'NOT_PREREGISTERED_NOT_CLAIMED')
        self.assertTrue(np.array_equal(data,before))

    def test_low_high_same_inventory_has_different_budget_breach_count(self):
        data,names,d,c,t=fixture()
        report=r.risk_diagnostics(data,names,d,c,t,'HIGH',[])
        self.assertEqual(report['forecast_volatility_breach_minutes'],0)
        self.assertAlmostEqual(report['gross_exposure_mean'],.1)

    def test_latest_covariance_is_past_only_at_daily_boundary(self):
        data,names,d,c,t=fixture();c[1:]=0
        report=r.risk_diagnostics(data,names,d,c,t,'LOW',[])
        self.assertEqual(report['forecast_volatility_breach_minutes'],1440)

    def test_guard_reasons_are_candidate_counts_not_new_financial_decisions(self):
        data,names,d,c,t=fixture()
        receipts=[dict(fraction='.75',evaluations=[dict(allowed=False,reason='CAPITAL_MARGIN')])]
        report=r.risk_diagnostics(data,names,d,c,t,'LOW',receipts)
        self.assertEqual(report['guard_named_capital_rejection_reason_counts_not_exhaustive'],{'CAPITAL_MARGIN':1})
        self.assertEqual(report['guard_selection_counts'],{'.75':1})
        self.assertEqual(report['exact_capital_binding_count'],'NOT_IDENTIFIABLE_FROM_FROZEN_COMPACT_RECEIPTS')

    def test_nonfinite_missing_clock_or_negative_nav_report_fails(self):
        for column,value in [(0,-1),(1,np.nan),(4,0)]:
            data,names,d,c,t=fixture();data[1,column]=value
            with self.assertRaises(ValueError):r.risk_diagnostics(data,names,d,c,t,'LOW',[])

    def test_controller_go_requires_external_hash_serial_resources_and_report_pins(self):
        prep=dict(execution_groups=[['STATIC50_LOW']],resource_limits=driver.LIMITS)
        prepared=json.dumps(prep).encode()
        value=dict(schema='ROOT_GO_FIXED_FINITE_FULL2023_GRID_V1',
            action='RUN_FRESH_APPROVED_2023_CANONICAL_JOBS_ONLY',
            preparation_SHA256=hashlib.sha256(prepared).hexdigest(),calendar=[a.START,a.END],
            cost='BASE27',resource_limits=driver.LIMITS,permitted_configs=['STATIC50_LOW'],
            locked_or_holdout_consumed=False,other_years_authorized=False,
            controller_reporting_identity=driver.reporting_identity(),serial_execution=True)
        body=json.dumps(value).encode();digest=hashlib.sha256(body).hexdigest()
        driver.validate_controller_go(prepared,body,digest)
        for key,changed in [('serial_execution',False),('controller_reporting_identity',{}),
                ('permitted_configs',[]),('permitted_configs',None),('permitted_configs','STATIC50_LOW'),
                ('resource_limits',{**driver.LIMITS,'per_case_wall_seconds':601})]:
            other=json.dumps({**value,key:changed}).encode()
            with self.assertRaises(ValueError):
                driver.validate_controller_go(prepared,other,hashlib.sha256(other).hexdigest())


if __name__=='__main__':unittest.main(verbosity=2)
