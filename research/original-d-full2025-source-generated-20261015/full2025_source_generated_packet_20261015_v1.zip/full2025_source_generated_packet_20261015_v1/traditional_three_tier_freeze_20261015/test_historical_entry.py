"""Source/GO negative tests only; no actual account construction or advance."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import shutil
import tempfile
import unittest
from unittest.mock import patch

import historical_entry as h


PREPARED = Path(__file__).parent / 'actual_2023_smoke_preparation_attempt004'


def fixture_go(preparation_raw):
    prep = json.loads(preparation_raw)
    # This is generated test metadata, not an actual root authorization.
    value = dict(schema='ROOT_GO_2023_THREE_DAY_TRADITIONAL_GRID_V1',
        action='RUN_ONE_FRESH_THREE_DAY_CASE_PER_FIXED_CONFIG',
        preparation_SHA256=hashlib.sha256(preparation_raw).hexdigest(),
        calendar=[h.START, h.END], permitted_configs=prep['configs'],
        resource_limits=prep['resource_limits'], cost='BASE27',
        annual_execution_authorized=False, locked_or_holdout_consumed=False)
    raw = json.dumps(value, sort_keys=True).encode()
    return value, raw, hashlib.sha256(raw).hexdigest()


class HistoricalGateTests(unittest.TestCase):
    def setUp(self):
        self.raw = (PREPARED / 'PREPARATION.json').read_bytes()
        self.prep = json.loads(self.raw)

    def test_source_only_preparation_has_no_account_or_annual_authority(self):
        self.assertEqual(self.prep['accounts_created'], 0)
        self.assertEqual(self.prep['financial_years_run'], 0)
        self.assertFalse(self.prep['annual_execution_authorized'])
        self.assertEqual(self.prep['code_identity'], h.code_identity())
        self.assertEqual(self.prep['calendar'], [h.START, h.END])

    def test_metadata_scope_validation_only_does_not_create_account(self):
        _, raw, digest = fixture_go(self.raw)
        with patch('native_runtime._construct_case', side_effect=AssertionError('NO_ACCOUNT')):
            result = h.validate_root_go(self.raw, raw, digest, config='STATIC50_LOW')
        self.assertEqual(result['configs'], self.prep['configs'])

    def test_missing_wrong_or_nonbyte_go_is_rejected_first(self):
        for raw, digest in ((b'{}', '0'*64), (True, '0'*64), (None, None)):
            with self.assertRaises(ValueError):
                h.validate_root_go(self.raw, raw, digest, config='STATIC50_LOW')

    def test_changed_calendar_cost_budget_annual_or_holdout_is_rejected(self):
        original, _, _ = fixture_go(self.raw)
        changes = [dict(calendar=[h.START, h.YEAR_END]), dict(cost='FREE'),
            dict(annual_execution_authorized=True), dict(locked_or_holdout_consumed=True),
            dict(resource_limits={**original['resource_limits'], 'maximum_cases': 10})]
        for change in changes:
            value = {**original, **change}; raw = json.dumps(value).encode()
            with self.assertRaises(ValueError):
                h.validate_root_go(self.raw, raw, hashlib.sha256(raw).hexdigest(), config='STATIC50_LOW')

    def test_changed_preparation_bytes_reject_old_go(self):
        _, raw, digest = fixture_go(self.raw)
        changed = json.dumps({**self.prep, 'cost': 'FREE'}).encode()
        with self.assertRaises(ValueError):
            h.validate_root_go(changed, raw, digest, config='STATIC50_LOW')

    def test_unknown_or_extra_config_is_not_authorized(self):
        _, raw, digest = fixture_go(self.raw)
        for config in ('STATIC50_ULTRA', 'LEVERAGE2_HIGH', 'CASH_HIGH'):
            with self.assertRaises(ValueError):
                h.validate_root_go(self.raw, raw, digest, config=config)

    def test_target_tamper_caught_before_source_or_account_construction(self):
        _, go, digest = fixture_go(self.raw)
        with tempfile.TemporaryDirectory(prefix='three_tier_negative_') as directory:
            target = Path(directory)
            for name in ('PREPARATION.json', 'TARGETS.npz', 'TARGET_PROOFS.json'):
                shutil.copyfile(PREPARED / name, target / name)
            with (target / 'TARGETS.npz').open('ab') as output:
                output.write(b'GENERATED_TAMPER')
            with (patch('historical_entry.validate_source', side_effect=AssertionError('SOURCE_NOT_REACHED')),
                    patch('native_runtime._construct_case', side_effect=AssertionError('ACCOUNT_NOT_REACHED'))):
                with self.assertRaisesRegex(ValueError, 'EXACT_SOURCE_HASH'):
                    h.make_smoke_case('UNUSED', target, go, digest, config='STATIC50_LOW')


if __name__ == '__main__':
    unittest.main()
