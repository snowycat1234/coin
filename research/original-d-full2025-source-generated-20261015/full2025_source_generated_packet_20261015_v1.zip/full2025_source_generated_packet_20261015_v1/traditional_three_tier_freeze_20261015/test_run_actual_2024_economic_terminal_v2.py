"""Generated subprocess evidence only; no financial accounts or market replay."""
from copy import deepcopy
import json
from pathlib import Path
import subprocess,tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import annual_entry_2024 as a
import run_actual_2024_economic_terminal_v2 as d
import test_run_actual_2024 as oldtests


def raw(value):return json.dumps(value,sort_keys=True,separators=(',',':')).encode()
def fixture(configs=None):
 p,g,r,_=oldtests.fixture(configs);review=json.loads(r)
 review.update(controller_reporting_identity=d.reporting_identity(),economic_terminal_policy_version=d.TERMINAL_POLICY_VERSION)
 rr=raw(review);rs=d.sha(rr)
 g.update(controller_reporting_identity=d.reporting_identity(),independent_review_SHA256=rs,
  economic_terminal_policy_version=d.TERMINAL_POLICY_VERSION,allow_recognized_native_economic_terminal_to_advance_queue=True)
 return p,g,rr,rs


def terminal_values(p,g,config,halt):
 prep=json.loads(p);stop=a.START+60000001 if halt else None
 r=dict(schema='FINITE_FULL2024_CASE_RECEIPT_V1',config=config,
  status='NATIVE_ECONOMIC_HALT_UNPAID_PARTIAL' if halt else 'COMPLETED_NATIVE_PATH',
  account_stop_us=stop,paid_comparison_eligible=not halt,completed_minutes=1 if halt else 527040,
  required_minutes=527040,actual_complete_calendar_days=0 if halt else 366,calendar=[a.START,a.END],
  root_GO_SHA256=d.sha(raw(g)),preparation_SHA256=d.sha(p),code_identity=prep['code_identity'],
  source_identity=prep['source_identity'],source_quality_adapter=prep['artifacts']['CAUSAL_MARK_ADAPTER.json'],
  controller_reporting_identity=d.reporting_identity(),independent_review_SHA256=g['independent_review_SHA256'],
  source_review_receipt_SHA256=d.SOURCE_REVIEW_SHA256,original_interpolated_mark_execution_admitted=False,limits=d.LIMITS)
 result=dict(config=config,summary=dict(account_status='LIQUIDATION_REQUIRED_HALT' if halt else 'ACTIVE',clock_us=stop,
  halt_witness=dict(event_us=stop,symbol='BTCUSDT',isolated_equity='1',maintenance_margin='2',mark_price='100',quantity='.002',NAV='10000',unpaid_liability='0'),
  completed_minutes=r['completed_minutes'],required_minutes=527040,stop_us=stop,completion='NOT_EVALUABLE_ACCOUNT_HALT_NO_LIQUIDATION_SIMULATED' if halt else 'PAID_TERMINAL',
  positions={'BTCUSDT':dict(quantity='.002' if halt else '0',entry_price='100',isolated_balance='1' if halt else '0',opened_us=a.START)}),economics=dict(calendar=[a.START,a.END],
  liquidation_required_halt=halt,bankruptcy_halt=False,paid_flat=not halt,paid_net_return=None if halt else .01,
  full_calendar=not halt,actual_liquidation_fills=0,liquidation_fill_model='NOT_IMPLEMENTED_NATIVE_ACCOUNT_STOPS_WITH_WITNESS',
  residual_marked_notional='100' if halt else '0',unpaid_liability='0',marked_net_return=.01,
  all_observation_max_drawdown=.02,fees_USDT='1',execution_cost_USDT='2',funding_USDT='-3'))
 return r,result


def install_case(out,p,g,config,halt):
 out.mkdir();r,result=terminal_values(p,g,config,halt)
 d.save(out/'RESULT.json',result);d.save(out/'OBSERVED_RISK.json',{'observation_count':r['completed_minutes']});d.save(out/'CASE_RECEIPT.json',r)
 d.save(out/'ACCOUNT_FINANCIAL_AUDIT_SNAPSHOT.json',dict(status=result['summary']['account_status'],clock_us=result['summary']['clock_us'],halt_witness=result['summary']['halt_witness'],positions=result['summary']['positions']))
 if halt:d.save(out/'ECONOMIC_TERMINAL.json',d.economic_terminal_record(r,result))
 d.save(out/'TERMINAL_CHECKPOINT.json',dict(case_receipt_SHA256=d.sha((out/'CASE_RECEIPT.json').read_bytes()),
  account_financial_audit_SHA256=d.sha((out/'ACCOUNT_FINANCIAL_AUDIT_SNAPSHOT.json').read_bytes()),result_SHA256=d.sha((out/'RESULT.json').read_bytes()),observed_risk_SHA256=d.sha((out/'OBSERVED_RISK.json').read_bytes()),economic_terminal_SHA256=d.sha((out/'ECONOMIC_TERMINAL.json').read_bytes()) if halt else None,
  completed_minutes=r['completed_minutes'],paid_comparison_eligible=not halt,all_evidence_fsynced_before_checkpoint=True))
 return r,result


class EconomicTerminalControllerTests(unittest.TestCase):
 def test_exact_new_controller_root_and_review_binding_without_accounts(self):
  p,g,r,rs=fixture();b=raw(g)
  with patch.object(a.n,'_construct_case',side_effect=AssertionError('NO_ACCOUNT')):
   self.assertEqual(d.validate_controller_go(p,b,d.sha(b),r,rs)['economic_terminal_policy_version'],d.TERMINAL_POLICY_VERSION)
 def test_old_unqualified_or_disabled_policy_cannot_launch_v2(self):
  p,base,r,rs=fixture()
  for field,value in [('economic_terminal_policy_version','OLD'),('allow_recognized_native_economic_terminal_to_advance_queue',False),
   ('permitted_configs',[]),('permitted_configs',['STATIC50_LOW']*2),('source_review_receipt_SHA256','0'*64),('resource_limits',{})]:
   g={**base,field:value};b=raw(g)
   with self.subTest(field=field),self.assertRaises(ValueError):d.validate_controller_go(p,b,d.sha(b),r,rs)
 def test_recognized_native_halt_is_partial_no_annual_or_fictional_closure(self):
  p,g,_,_=fixture();r,result=terminal_values(p,g,'STATIC50_MID',True)
  t=d.economic_terminal_record(r,result)
  self.assertIsNone(t['annual_paid_net_return']);self.assertIsNone(t['annual_APR'])
  self.assertFalse(t['paid_comparison_eligible']);self.assertEqual(t['actual_liquidation_fills'],0)
  self.assertEqual(t['retained_positions'],result['summary']['positions'])
 def test_bankrupt_native_halt_is_also_explicit_economic_terminal(self):
  p,g,_,_=fixture();r,result=terminal_values(p,g,'STATIC50_MID',True)
  result['summary']['account_status']='BANKRUPT_HALT';result['summary']['halt_witness']['isolated_equity']='-1';result['economics'].update(bankruptcy_halt=True,liquidation_required_halt=False)
  self.assertEqual(d.economic_terminal_record(r,result)['account_status'],'BANKRUPT_HALT')
 def test_unknown_incomplete_halt_or_fabricated_liquidation_rejected(self):
  p,g,_,_=fixture();r,result=terminal_values(p,g,'STATIC50_MID',True)
  for owner,key,value in [('s','account_status','ACTIVE'),('e','liquidation_required_halt',False),
   ('e','bankruptcy_halt',True),('e','paid_net_return',.01),('e','actual_liquidation_fills',1),
   ('e','full_calendar',True),('e','unpaid_liability','NaN'),('e','residual_marked_notional',-1),
   ('r','completed_minutes',0),('r','account_stop_us',a.END+1)]:
   rr,zz=deepcopy(r),deepcopy(result);target=rr if owner=='r' else zz['summary' if owner=='s' else 'economics'];target[key]=value
   with self.subTest(key=key),self.assertRaises((ValueError,KeyError)):d.economic_terminal_record(rr,zz)
 def test_exact_checkpoint_and_result_hash_required_for_each_terminal_kind(self):
  p,g,_,_=fixture()
  for halt in (False,True):
   with tempfile.TemporaryDirectory() as temp:
    out=Path(temp)/'case';install_case(out,p,g,'STATIC50_MID',halt)
    self.assertEqual(d.validate_saved_terminal(out,g,p,expected_go_sha256=d.sha(raw(g)),config='STATIC50_MID'),
     'NATIVE_ECONOMIC_HALT_UNPAID_PARTIAL' if halt else 'PAID_FULL_YEAR')
    (out/'RESULT.json').write_text('{}')
    with self.assertRaises((ValueError,KeyError)):d.validate_saved_terminal(out,g,p,expected_go_sha256=d.sha(raw(g)),config='STATIC50_MID')
 def test_wrong_source_code_go_or_unpaid_false_status_rejects(self):
  p,g,_,_=fixture()
  for key,value in [('source_identity','BAD'),('code_identity',{}),('root_GO_SHA256','0'*64),('status','COMPLETED_NATIVE_PATH')]:
   with tempfile.TemporaryDirectory() as temp:
    out=Path(temp)/'case';r,_=install_case(out,p,g,'STATIC50_MID',True);r[key]=value
    (out/'CASE_RECEIPT.json').write_bytes(raw(r))
    cp=json.loads((out/'TERMINAL_CHECKPOINT.json').read_bytes());cp['case_receipt_SHA256']=d.sha(raw(r));(out/'TERMINAL_CHECKPOINT.json').write_bytes(raw(cp))
    with self.subTest(key=key),self.assertRaises(ValueError):d.validate_saved_terminal(out,g,p,expected_go_sha256=d.sha(raw(g)),config='STATIC50_MID')
 def mock_controller(self,*,first_halt=True,error=0,timeout=False):
  p,g,rv,rs=fixture(['STATIC50_LOW','STATIC50_HIGH']);b=raw(g);temp=tempfile.TemporaryDirectory();root=Path(temp.name)
  gp=root/'go.json';gp.write_bytes(b);rp=root/'review.json';rp.write_bytes(rv)
  args=SimpleNamespace(preparation=str(oldtests.PREP),go=str(gp),go_sha=d.sha(b),review=str(rp),review_sha=rs,source='NO_SOURCE_READ',output=str(root/'out'))
  calls=[]
  class Process:
   pid=7654321
   def wait(self,timeout=None):
    if timeout and timeout_mode:raise subprocess.TimeoutExpired('GENERATED',timeout)
    return error
   def kill(self):pass
  timeout_mode=timeout
  def popen(cmd,**kwargs):
   calls.append(cmd);out=Path(cmd[cmd.index('--case-output')+1]);config=cmd[cmd.index('--config')+1]
   install_case(out,p,g,config,first_halt and len(calls)==1)
   return Process()
  with patch.object(d.subprocess,'Popen',side_effect=popen),patch.object(a.n,'_construct_case',side_effect=AssertionError('NO_ACCOUNT')):
   if error or timeout:
    with self.assertRaises(RuntimeError):d.controller(args)
   else:d.controller(args)
  return temp,root,calls
 def test_known_economic_halt_then_distinct_paid_case_both_terminal(self):
  t,r,c=self.mock_controller()
  try:
   self.assertEqual(len(c),2)
   receipt=json.loads((r/'out/CONTROLLER_RECEIPT.json').read_bytes())
   self.assertEqual([v['terminal_classification'] for v in receipt['cases']],['NATIVE_ECONOMIC_HALT_UNPAID_PARTIAL','PAID_FULL_YEAR'])
  finally:t.cleanup()
 def test_nonzero_process_error_even_with_native_halt_files_stops_queue(self):
  t,r,c=self.mock_controller(error=1)
  try:self.assertEqual(len(c),1);self.assertTrue((r/'out/CONTROLLER_FAILURE.json').exists())
  finally:t.cleanup()
 def test_timeout_even_with_native_halt_files_stops_queue(self):
  t,r,c=self.mock_controller(timeout=True)
  try:self.assertEqual(len(c),1);self.assertTrue((r/'out/STATIC50_LOW_CONTROLLER_TIMEOUT.json').exists())
  finally:t.cleanup()
 def test_original_driver_remains_exact_reviewed_bytes(self):
  self.assertEqual(d.sha((d.HERE/'run_actual_2024.py').read_bytes()),'ba6e603b263760121709b78f20e03a2a471acbcc095eeae95cd8c2e016ff30b5')
 def test_old_mid_cannot_be_scheduled_twice_via_prior_references(self):
  p,g,_,_=fixture(['STATIC50_MID']);g['prior_economic_terminal_cases']=[dict(case_directory='DOES_NOT_EXIST')]
  with self.assertRaises((ValueError,FileNotFoundError)):d.prior_economic_terminals(g,p)
 def test_saved_original_mid_terminal_reference_is_verified_and_never_rerun(self):
  p,g,rv,_=fixture(['STATIC50_LOW','STATIC50_HIGH'])
  out=d.HERE/'actual_2024_pilot_attempt001/STATIC50_MID'
  savedreview=d.HERE.parent/'traditional_three_tier_independent_review_20261015/ANNUAL_2024_PILOT_FINAL_INDEPENDENT_REVIEW_RECEIPT.json'
  ref=dict(config='STATIC50_MID',case_directory=str(out),case_receipt_SHA256=d.sha((out/'CASE_RECEIPT.json').read_bytes()),
   result_SHA256=d.sha((out/'RESULT.json').read_bytes()),root_GO_SHA256=d.sha((out.parent/'ROOT_GO.json').read_bytes()),
   independent_saved_review_path=str(savedreview),independent_saved_review_SHA256=d.sha(savedreview.read_bytes()))
  g['prior_economic_terminal_cases']=[ref]
  completed=d.prior_economic_terminals(g,p)
  self.assertFalse(completed['STATIC50_MID']['financial_rerun_required'])
  self.assertFalse(completed['STATIC50_MID']['paid_comparison_eligible'])
  with self.assertRaisesRegex(ValueError,'BOUND_INDEPENDENT_SAVED_REVIEW'):
   b=raw(g);d.validate_controller_go(p,b,d.sha(b),rv,d.sha(rv))
  review=json.loads(rv);review['reviewed_prior_economic_terminal_cases']=[{k:ref[k] for k in
   ('config','case_receipt_SHA256','result_SHA256','root_GO_SHA256','independent_saved_review_SHA256')}]
  rr=raw(review);g['independent_review_SHA256']=d.sha(rr);b=raw(g)
  self.assertEqual(d.validate_controller_go(p,b,d.sha(b),rr,d.sha(rr))['prior_economic_terminal_cases'],[ref])
  for field in ('case_receipt_SHA256','result_SHA256','root_GO_SHA256','independent_saved_review_SHA256'):
   bad=deepcopy(g);bad['prior_economic_terminal_cases'][0][field]='0'*64
   with self.subTest(field=field),self.assertRaises(ValueError):d.prior_economic_terminals(bad,p)

if __name__=='__main__':unittest.main(verbosity=2)
