"""Generated-only quality seam regressions; no historical account is created."""
from copy import deepcopy
from decimal import Decimal as D
from types import MethodType
import unittest

import numpy as np
import frozen_grid as g
import native_runtime as n
import causal_mark_quality as q
from test_native_runtime import fixture, BASE, COST

SIDECAR = 'a' * 64


def generated_case(tier='MID', *, capacity=1e10):
    window, rows, decisions = fixture(1)
    window['end'] = window['start'] + 90 * n.MINUTE
    window['events'] = []
    for data in window['market'].values():
        for key in data:
            data[key] = data[key][:90].copy()
        data['quote_volume'][:] = capacity
    sim, guard = n.build_case(window, rows, decisions, np.full((1, 5), .03),
        tier_name=tier, generated_scope='GENERATED_FAKE_ORIGIN_ONLY')
    return sim, guard


def interval(sim, *, start=3, end=5):
    return q.StaleMarkInterval(sim.start + start*n.MINUTE, sim.start + end*n.MINUTE,
                              sim.start + (start-1)*n.MINUTE, tuple(g.SYMBOLS))


def install(sim, guard, intervals):
    return q.install_quality_guard(sim, guard, intervals, source_sidecar_sha256=SIDECAR)


def marks(sim, close):
    sim.account.update_marks(close, {s: dict(price=str(BASE[i]), close_us=close,
        available_us=close) for i, s in enumerate(g.SYMBOLS)})


def add_generated_increase_intents(sim, guard):
    """Fixture-only two additional known-source intents, with native orders.

    The same original signal remains bound; no retry extension or production
    scheduling behavior is added by the quality layer.
    """
    original = guard.original_attempt
    def attempt(_sim, open_us, row):
        if open_us in (sim.start+2*n.MINUTE, sim.start+3*n.MINUTE):
            target = {s:sim.account.positions[s].quantity for s in g.SYMBOLS}
            target['BTCUSDT'] += D('.001')
            guard.original_schedule(target, sim.start, 'DAILY_TARGET', ('BTCUSDT',))
        return original(open_us, row)
    guard.original_attempt = MethodType(attempt, sim)


class QualityValidationTests(unittest.TestCase):
    def test_immutable_intervals_and_explicit_identities(self):
        sim, guard = generated_case()
        gap = interval(sim)
        with self.assertRaises(Exception):
            gap.start_us = 0
        for bad in ([gap], (object(),)):
            with self.assertRaisesRegex(ValueError, 'IMMUTABLE'):
                install(sim, guard, bad)
        with self.assertRaisesRegex(ValueError, 'SHA256'):
            q.CausalMarkQualityGuard(guard, intervals=(gap,), source_sidecar_sha256='bad')
        a = q.CausalMarkQualityGuard(guard, intervals=(gap,), source_sidecar_sha256=SIDECAR)
        b = q.CausalMarkQualityGuard(guard, intervals=(gap,), source_sidecar_sha256=SIDECAR)
        self.assertEqual(a.policy_sha256, b.policy_sha256)
        self.assertFalse(a.identity['native_venue_or_current_mark_certified'])
        self.assertEqual(len(a.policy_sha256), 64)
        install(sim, guard, (gap,))
        self.assertNotIn('execute_fill', vars(sim.account))
        with self.assertRaisesRegex(ValueError, 'ALREADY'):
            guard.original_attempt.__self__.install()

    def test_no_mask_preblock_and_installed_recovery_not_prefetch(self):
        sim, guard = generated_case()
        quality = install(sim, guard, (interval(sim),))
        marks(sim, sim.start+2*n.MINUTE)
        self.assertIsNone(quality.quality_witness(sim.start+2*n.MINUTE+1))
        self.assertIsNotNone(quality.quality_witness(sim.start+3*n.MINUTE+1))
        # A decoder may already have read a later genuine row. The account has
        # not installed it, so crossing the interval end alone cannot release.
        self.assertIsNotNone(quality.quality_witness(sim.start+5*n.MINUTE+1))
        marks(sim, sim.start+4*n.MINUTE)
        self.assertIsNotNone(quality.quality_witness(sim.start+5*n.MINUTE+1))
        marks(sim, sim.start+5*n.MINUTE)
        self.assertIsNotNone(quality.quality_witness(sim.start+4*n.MINUTE+1))
        self.assertIsNone(quality.quality_witness(sim.start+5*n.MINUTE+1))

    def test_every_affected_symbol_must_install_genuine_recovery(self):
        sim, guard = generated_case()
        quality = install(sim, guard, (interval(sim),))
        marks(sim, sim.start+4*n.MINUTE)
        marks(sim, sim.start+5*n.MINUTE)
        sim.account.marks['DOGEUSDT'] = sim.account.marks['DOGEUSDT'][:-1]
        witness = quality.quality_witness(sim.start+5*n.MINUTE+1)
        self.assertIsNotNone(witness)
        self.assertEqual(witness['affected_intervals'][0]['installed_marks'][-1]
                         ['installed_close_us'], sim.start+4*n.MINUTE)


class GeneratedNativeQualityTests(unittest.TestCase):
    def test_zero_gap_exact_native_parity_all_nine(self):
        for strategy in g.STRATEGIES:
            for tier in g.TIERS:
                with self.subTest(strategy=strategy, tier=tier.name):
                    baseline, bguard = generated_case(tier.name)
                    candidate, cguard = generated_case(tier.name)
                    quality = install(candidate, cguard, ())
                    baseline.advance_day(); candidate.advance_day()
                    self.assertEqual(candidate.account.snapshot(), baseline.account.snapshot())
                    self.assertEqual(cguard.receipts, bguard.receipts)
                    self.assertEqual(candidate.rejections, baseline.rejections)
                    self.assertEqual(candidate.pending, baseline.pending)
                    np.testing.assert_array_equal(candidate.minute_chunks[0], baseline.minute_chunks[0])
                    self.assertFalse(quality.receipts)
                    self.assertIsNone(candidate.stop)
                    self.assertTrue(candidate.result()['summary']['terminal_cash_realized'])
                    self.assertGreater(candidate.account.fees, 0)

    def test_known_gap_preserves_native_attempts_and_resumes_on_genuine_close(self):
        sim, guard = generated_case()
        add_generated_increase_intents(sim, guard)
        quality = install(sim, guard, (interval(sim),))
        sim.advance_day()
        blocked = {r['event_us'] for r in quality.receipts}
        self.assertEqual(blocked, {sim.start+3*n.MINUTE+1, sim.start+4*n.MINUTE+1})
        actual = list(sim.account.trades)
        increases = [r for r in actual if r['leg'] == 'OPEN']
        self.assertTrue(increases)
        clocks = {r['event_us'] for r in increases}
        self.assertIn(sim.start+2*n.MINUTE+1, clocks)
        self.assertIn(sim.start+5*n.MINUTE+1, clocks)
        self.assertFalse(clocks & blocked)
        for r in quality.receipts:
            attempt = int(r['fill_id'].split(':')[-2])
            self.assertIn(attempt, (0, 1))
            self.assertEqual(r['signal_us'], sim.start)
        self.assertIsNone(sim.stop)
        self.assertEqual(sim.rows_written, 90)
        self.assertTrue(sim.result()['summary']['terminal_cash_realized'])
        self.assertGreater(sim.account.fees, 0)
        self.assertGreater(sim.account.execution_cost, 0)
        self.assertNotIn('execute_fill', vars(sim.account))

    def test_same_gap_policy_applies_to_all_nine_cells(self):
        reference = None
        for strategy in g.STRATEGIES:
            for tier in g.TIERS:
                with self.subTest(strategy=strategy, tier=tier.name):
                    sim, guard = generated_case(tier.name)
                    add_generated_increase_intents(sim, guard)
                    quality = install(sim, guard, (interval(sim),))
                    sim.advance_day()
                    blocked = [(r['symbol'], r['event_us']-sim.start,
                                r['fill_id'].split(':')[-2:]) for r in quality.receipts]
                    if reference is None:
                        reference = blocked
                    self.assertEqual(blocked, reference)
                    self.assertEqual(len(blocked), 2)
                    self.assertTrue(sim.result()['summary']['terminal_cash_realized'])

    def test_stale_rejections_do_not_extend_native_five_attempt_expiry(self):
        sim, guard = generated_case()
        add_generated_increase_intents(sim, guard)
        quality = install(sim, guard, (interval(sim, start=3, end=10),))
        sim.advance_day()
        self.assertEqual([r['event_us'] for r in quality.receipts],
                         [sim.start+i*n.MINUTE+1 for i in range(3, 8)])
        expired = [r for r in sim.rejections if r['reason']=='FIVE_ATTEMPTS_EXPIRED' and r['symbol']=='BTCUSDT']
        self.assertEqual(len(expired), 1)
        self.assertEqual(expired[0]['event_us'], sim.start+7*n.MINUTE+1)
        self.assertEqual(expired[0]['kind'], 'DAILY_TARGET')
        self.assertFalse(any(r['leg']=='OPEN' and r['event_us'] >= sim.start+3*n.MINUTE
                             for r in sim.account.trades))
        self.assertTrue(sim.result()['summary']['terminal_cash_realized'])

    def test_future_mark_endpoint_never_changes_prefix_or_quality(self):
        base, bguard = generated_case()
        changed, cguard = generated_case()
        add_generated_increase_intents(base, bguard)
        add_generated_increase_intents(changed, cguard)
        bq = install(base, bguard, (interval(base),))
        cq = install(changed, cguard, (interval(changed),))
        # Only future MARK/recovery close values change. Execution opens stay
        # byte-identical, including opens used for legitimate paid reductions.
        for i, s in enumerate(g.SYMBOLS):
            changed.window['market'][s]['mark'][4] = BASE[i] * 1.0001
            changed.window['market'][s]['mark'][5] = BASE[i] * .9999
        base.advance_day(); changed.advance_day()
        np.testing.assert_array_equal(base.minute_chunks[0][:4], changed.minute_chunks[0][:4])
        cutoff = base.start+5*n.MINUTE
        before = lambda sim: [r for r in sim.account.trades if r['event_us'] < cutoff]
        self.assertEqual(before(base), before(changed))
        self.assertEqual(bq.receipts, cq.receipts)
        self.assertEqual([r for r in bguard.receipts if 'event_us' in r and r['event_us'] < cutoff],
                         [r for r in cguard.receipts if 'event_us' in r and r['event_us'] < cutoff])


class InnerAttemptBoundaryTests(unittest.TestCase):
    def prepare(self, callback):
        sim, guard = generated_case()
        guard.original_attempt = MethodType(callback, sim)
        quality = install(sim, guard, (interval(sim),))
        marks(sim, sim.start+3*n.MINUTE)
        return sim, guard, quality

    def test_quality_reject_changes_no_pending_or_account(self):
        def callback(sim, open_us, row):
            before, pending = sim.account.preview_state_token(), deepcopy(sim.pending)
            receipt = sim.account.execute_fill('BTCUSDT','BUY','.001',open_us+1,sim.start,'new-risk',
                execution_mid_price='50000',quote_available_us=open_us,available_quantity='.001')
            self.assertEqual(receipt['reason'], q.REJECTION)
            self.assertEqual(sim.account.preview_state_token(), before)
            self.assertEqual(sim.pending, pending)
        sim, guard, quality = self.prepare(callback)
        order = {'order_id':'same-id','attempts':2,'signal_us':sim.start,
                 'kind':'DAILY_TARGET','target':D('.006')}
        sim.pending['BTCUSDT'] = order
        guard.attempt(sim.start+3*n.MINUTE, {})
        self.assertIs(sim.pending['BTCUSDT'], order)
        self.assertEqual(order['attempts'], 2)
        self.assertEqual(len(quality.receipts), 1)
        self.assertNotIn('execute_fill', vars(sim.account))

    def test_exception_restores_both_interceptor_layers(self):
        observed = []
        def callback(sim, open_us, row):
            observed.append(vars(sim.account)['execute_fill'])
            raise RuntimeError('generated inner failure')
        sim, guard, quality = self.prepare(callback)
        raw = sim.account.execute_fill
        with self.assertRaisesRegex(RuntimeError, 'generated inner failure'):
            guard.attempt(sim.start+3*n.MINUTE, {})
        self.assertNotIn('execute_fill', vars(sim.account))
        self.assertEqual(sim.account.execute_fill, raw)
        self.assertEqual(observed[0].__self__, sim.account)

    def test_paid_native_dust_reduction_and_cash_fees_unchanged(self):
        def callback(sim, open_us, row):
            return sim.account.execute_fill('BTCUSDT','SELL','.0005',open_us+1,sim.start,'paid-dust',
                execution_mid_price='50000',quote_available_us=open_us,available_quantity='.0005',reduce_only=True)
        sim, guard, quality = self.prepare(callback)
        # Explicit generated dust, intentionally below the unchanged BTC step.
        # The native account must apply its own lot behavior, not forgive it.
        account = sim.account
        account.positions['BTCUSDT'].quantity = D('.0005')
        account.positions['BTCUSDT'].entry_price = D('50000')
        account.positions['BTCUSDT'].isolated_balance = D('25')
        account.free_cash = D('9975')
        baseline = n.runtime()[4].fork_owned_account(account)
        kw = dict(execution_mid_price='50000',quote_available_us=sim.start+3*n.MINUTE,
                  available_quantity='.0005',reduce_only=True)
        expected = n.capital_guard_fill(baseline,'BTCUSDT','SELL','.0005',sim.start+3*n.MINUTE+1,
                                       sim.start,'paid-dust',**kw)
        receipt = guard.attempt(sim.start+3*n.MINUTE, {})
        self.assertEqual(receipt, expected)
        self.assertEqual(account.snapshot(), baseline.snapshot())
        self.assertEqual(account.positions['BTCUSDT'].quantity, D('.0005'))
        self.assertFalse(quality.receipts)
        # A real whole-lot paid reduction below the increase cash floor also
        # remains byte-for-byte native and actually charges the saved fees.
        account.positions['BTCUSDT'].quantity = D('.001')
        account.positions['BTCUSDT'].isolated_balance = D('50')
        account.free_cash = D('999')
        baseline = n.runtime()[4].fork_owned_account(account)
        def reduce(sim, open_us, row):
            return sim.account.execute_fill('BTCUSDT','SELL','.001',open_us+1,sim.start,'paid-reduce',
                execution_mid_price='50000',quote_available_us=open_us,available_quantity='.001',reduce_only=True)
        quality.original_attempt = MethodType(reduce, sim)
        expected = n.capital_guard_fill(baseline,'BTCUSDT','SELL','.001',sim.start+4*n.MINUTE+1,
            sim.start,'paid-reduce',execution_mid_price='50000',quote_available_us=sim.start+4*n.MINUTE,
            available_quantity='.001',reduce_only=True)
        receipt = guard.attempt(sim.start+4*n.MINUTE, {})
        self.assertEqual(receipt, expected)
        self.assertEqual(account.snapshot(), baseline.snapshot())
        self.assertEqual(account.positions['BTCUSDT'].quantity, 0)
        self.assertGreater(account.fees, 0)
        self.assertFalse(quality.receipts)

    def test_zero_executable_stale_request_keeps_native_receipt(self):
        def callback(sim, open_us, row):
            return sim.account.execute_fill('BTCUSDT','BUY','.0005',open_us+1,sim.start,'zero-lot',
                execution_mid_price='50000',quote_available_us=open_us,available_quantity='.0005')
        sim, guard, quality = self.prepare(callback)
        baseline = n.runtime()[4].fork_owned_account(sim.account)
        expected = n.capital_guard_fill(baseline,'BTCUSDT','BUY','.0005',sim.start+3*n.MINUTE+1,
            sim.start,'zero-lot',execution_mid_price='50000',quote_available_us=sim.start+3*n.MINUTE,
            available_quantity='.0005')
        self.assertEqual(guard.attempt(sim.start+3*n.MINUTE, {}), expected)
        self.assertEqual(sim.account.snapshot(), baseline.snapshot())
        self.assertFalse(quality.receipts)

    def test_nonactive_increase_delegates_outer_guard_unchanged(self):
        def callback(sim, open_us, row):
            return sim.account.execute_fill('BTCUSDT','BUY','.001',open_us+1,sim.start,'halt-increase',
                execution_mid_price='50000',quote_available_us=open_us,available_quantity='.001')
        sim, guard, quality = self.prepare(callback)
        baseline, bguard = generated_case()
        bguard.original_attempt = MethodType(callback, baseline)
        marks(baseline, baseline.start+3*n.MINUTE)
        baseline.account.status = sim.account.status = 'LIQUIDATION_REQUIRED_HALT'
        self.assertEqual(guard.attempt(sim.start+3*n.MINUTE, {}),
                         bguard.attempt(baseline.start+3*n.MINUTE, {}))
        self.assertEqual(sim.account.snapshot(), baseline.account.snapshot())
        self.assertFalse(quality.receipts)

    def test_known_fill_replay_and_conflict_precede_stale_guard(self):
        results = []
        args_holder = {}
        def callback(sim, open_us, row):
            args, kw = args_holder['request']
            before = sim.account.preview_state_token()
            results.append(sim.account.execute_fill(*args, **kw))
            self.assertEqual(sim.account.preview_state_token(), before)
            with self.assertRaisesRegex(ValueError, 'conflicting fill identity'):
                sim.account.execute_fill(*args, **{**kw,'available_quantity':'.002'})
        sim, guard, quality = self.prepare(callback)
        # Known request was valid before the missing interval. Native replay
        # must be allowed even though its event is earlier than current clock.
        a = n.make_owned_account('MID', COST)
        original = sim.start+n.MINUTE
        a.update_marks(original, {s:dict(price=str(BASE[i]),close_us=original,available_us=original)
            for i,s in enumerate(g.SYMBOLS)})
        args = ('BTCUSDT','BUY','.001',sim.start+2*n.MINUTE+1,sim.start,'known-before-gap')
        kw = dict(execution_mid_price='50000',quote_available_us=sim.start+2*n.MINUTE,
                  available_quantity='.001')
        expected = a.execute_fill(*args, **kw)
        sim.account = a
        marks(sim, sim.start+3*n.MINUTE)
        args_holder['request'] = (args, kw)
        guard.attempt(sim.start+3*n.MINUTE, {})
        self.assertEqual(results, [expected])
        self.assertFalse(quality.receipts)

    def test_real_generated_filled_inventory_stale_cache_paid_reduce_and_duplicate(self):
        known = {}
        def callback(sim, open_us, row):
            account = sim.account
            before = account.preview_state_token()
            blocked = account.execute_fill('BTCUSDT','BUY','.001',open_us+1,sim.start,'stale-new-risk',
                execution_mid_price='50001',quote_available_us=open_us,available_quantity='.001')
            self.assertEqual(blocked['reason'], q.REJECTION)
            self.assertEqual(account.preview_state_token(), before)
            self.assertEqual(account.execute_fill(*known['args'], **known['kw']), known['receipt'])
            self.assertEqual(account.preview_state_token(), before)
            with self.assertRaisesRegex(ValueError, 'conflicting fill identity'):
                account.execute_fill(*known['args'], **{**known['kw'],'available_quantity':'.003'})
            self.assertEqual(account.preview_state_token(), before)
            return account.execute_fill('BTCUSDT','SELL','.001',open_us+1,sim.start,'real-paid-reduce',
                execution_mid_price='50001',quote_available_us=open_us,available_quantity='.001',reduce_only=True)
        sim, guard = generated_case()
        account = sim.account
        marks(sim, sim.start+n.MINUTE)
        args = ('BTCUSDT','BUY','.002',sim.start+2*n.MINUTE+1,sim.start,'real-before-gap')
        kw = dict(execution_mid_price='50000',quote_available_us=sim.start+2*n.MINUTE,
                  available_quantity='.002')
        receipt = account.execute_fill(*args, **kw)
        self.assertEqual(receipt['status'], 'FILLED')
        self.assertEqual(account.positions['BTCUSDT'].quantity, D('.002'))
        self.assertGreater(account.fees, 0)
        known.update(args=args,kw=kw,receipt=receipt)
        marks(sim, sim.start+3*n.MINUTE)
        # The real native tape has cached a future genuine recovery row. The
        # account still holds the stale close, so even a post-boundary quality
        # query must remain blocked until account.update_marks installs it.
        cached = sim.tape.day(sim.start)
        self.assertEqual(len(cached), 90)
        self.assertGreater(cached[5][0], sim.start+3*n.MINUTE)
        guard.original_attempt = MethodType(callback, sim)
        quality = install(sim, guard, (interval(sim),))
        self.assertIsNotNone(quality.quality_witness(sim.start+5*n.MINUTE+1))
        baseline = n.runtime()[4].fork_owned_account(account)
        previous_fees, previous_cash = account.fees, account.free_cash
        expected = n.capital_guard_fill(baseline,'BTCUSDT','SELL','.001',sim.start+3*n.MINUTE+1,
            sim.start,'real-paid-reduce',execution_mid_price='50001',
            quote_available_us=sim.start+3*n.MINUTE,available_quantity='.001',reduce_only=True)
        row = {s:dict(open=str(BASE[i]),close=str(BASE[i]),mark=str(BASE[i]),quote_volume=1e10)
               for i,s in enumerate(g.SYMBOLS)}
        row['BTCUSDT']['open'] = '50001'
        sim.previous_quote = dict.fromkeys(g.SYMBOLS, 1e10)
        self.assertEqual(guard.attempt(sim.start+3*n.MINUTE, row), expected)
        self.assertEqual(account.snapshot(), baseline.snapshot())
        self.assertEqual(account.positions['BTCUSDT'].quantity, D('.001'))
        self.assertGreater(account.fees, previous_fees)
        self.assertNotEqual(account.free_cash, previous_cash)
        self.assertEqual(account.trades[-1]['decimal_strings']['execution_mid_price'], '50001')
        self.assertEqual(len(quality.receipts), 1)
        self.assertNotIn('stale-new-risk', account.fill_requests)
        self.assertNotIn('execute_fill', vars(account))

    def test_native_halt_remains_native_error(self):
        def callback(sim, open_us, row):
            return sim.account.execute_fill('BTCUSDT','SELL','.001',open_us+1,sim.start,'halt-reduce',
                execution_mid_price='50000',quote_available_us=open_us,available_quantity='.001',reduce_only=True)
        sim, guard, quality = self.prepare(callback)
        sim.account.status = 'LIQUIDATION_REQUIRED_HALT'
        with self.assertRaisesRegex(RuntimeError, 'LIQUIDATION_REQUIRED_HALT'):
            guard.attempt(sim.start+3*n.MINUTE, {})
        self.assertFalse(quality.receipts)
        self.assertNotIn('execute_fill', vars(sim.account))


if __name__ == '__main__':
    unittest.main()
