"""Year/controller/checkpoint tests: subprocess and actual accounts forbidden."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import numpy as np
import annual_entry_2024 as a
import annual_reporting as report
import run_actual_2024 as d

HERE=Path(__file__).resolve().parent
PREP=HERE/'annual_2024_source_preparation_attempt002'
SOURCE_REVIEW=HERE.parent/'traditional_three_tier_independent_review_20261015/SOURCE_2024_FINAL_INDEPENDENT_REVIEW_RECEIPT.json'


def raw(value):return json.dumps(value,sort_keys=True,separators=(',',':')).encode()
def fixture(configs=None):
    preparation=(PREP/'PREPARATION.json').read_bytes();prep=json.loads(preparation)
    review=json.loads(SOURCE_REVIEW.read_bytes())
    review.update(controller_reporting_identity=d.reporting_identity(),source_review_receipt_SHA256=d.SOURCE_REVIEW_SHA256,
        generated_fixture_only=True)
    reviewraw=raw(review);reviewsha=d.sha(reviewraw)
    go=dict(schema='ROOT_GO_FIXED_FINITE_FULL2024_GRID_V1',action='RUN_FRESH_APPROVED_2024_CANONICAL_JOBS_ONLY',
        preparation_SHA256=d.sha(preparation),calendar=[a.START,a.END],cost='BASE27',code_identity=prep['code_identity'],
        source_identity=prep['source_identity'],artifacts=prep['artifacts'],resource_limits=d.LIMITS,
        permitted_configs=configs or ['STATIC50_MID'],serial_execution=True,locked_or_holdout_consumed=False,
        other_years_authorized=False,original_interpolated_mark_execution_admitted=False,
        coldstart_policy=prep['coldstart_policy'],mark_feed_adapter_version=a.m.VERSION,
        mark_quality_guard_version=a.q.VERSION,independent_review_SHA256=reviewsha,
        source_review_receipt_SHA256=d.SOURCE_REVIEW_SHA256,
        controller_reporting_identity=d.reporting_identity())
    return preparation,go,reviewraw,reviewsha


class Driver2024Tests(unittest.TestCase):
    def test_attached_quality_is_checked_before_any_advance(self):
        class Guard:
            def attempt(self):pass
        class Quality:
            def attempt(self):pass
        p,_,_,_=fixture();prep=json.loads(p)
        sim=SimpleNamespace(meta={});guard=Guard();quality=Quality()
        quality._installed=True;quality.guard=guard;quality.sim=sim
        quality.source_sidecar_sha256=prep['artifacts']['CAUSAL_MARK_ADAPTER.json']['SHA256']
        quality.identity={'source_sidecar_sha256':quality.source_sidecar_sha256,'generated':True}
        quality.policy_sha256=d.sha(raw(quality.identity))
        sim.meta['mark_quality_policy_identity']=quality.policy_sha256
        sim.attempt=guard.attempt;guard.original_attempt=quality.attempt;guard.causal_mark_quality_guard=quality
        self.assertIs(d.validate_installed_quality(sim,guard,prep),quality)
        for owner,field,bad in [(quality,'_installed',False),(quality,'sim',None),
                (quality,'source_sidecar_sha256','0'*64),(guard,'original_attempt',guard.attempt),
                (sim,'attempt',quality.attempt),(quality,'policy_sha256','0'*64)]:
            old=getattr(owner,field);setattr(owner,field,bad)
            with self.subTest(field=field),self.assertRaises(ValueError):d.validate_installed_quality(sim,guard,prep)
            setattr(owner,field,old)

    def test_exact_year_source_and_runner_review_binding_without_accounts(self):
        p,g,r,rs=fixture();body=raw(g)
        with patch.object(a.n,'_construct_case',side_effect=AssertionError('NO_ACTUAL_ACCOUNT')):
            self.assertEqual(d.validate_controller_go(p,body,d.sha(body),r,rs)['calendar'],[a.START,a.END])

    def test_empty_duplicate_wrong_year_source_review_or_driver_pins_reject(self):
        p,base,r,rs=fixture()
        for field,value in [('permitted_configs',[]),('permitted_configs',['STATIC50_MID']*2),
                ('calendar',[1672531200000000,a.START]),('controller_reporting_identity',{}),
                ('source_identity','0'*64),('independent_review_SHA256','0'*64),
                ('source_review_receipt_SHA256','0'*64),
                ('original_interpolated_mark_execution_admitted',True),('serial_execution',False),
                ('resource_limits',{**d.LIMITS,'per_case_wall_seconds':601})]:
            g={**base,field:value};body=raw(g)
            with self.subTest(field=field),self.assertRaises(ValueError):
                d.validate_controller_go(p,body,d.sha(body),r,rs)

    def test_original_source_only_receipt_cannot_replace_reviewed_runner_wrapper(self):
        p,g,_,_=fixture();r=SOURCE_REVIEW.read_bytes();g['independent_review_SHA256']=d.sha(r);body=raw(g)
        with self.assertRaisesRegex(ValueError,'REVIEWED_CONTROLLER'):
            d.validate_controller_go(p,body,d.sha(body),r,d.sha(r))

    def test_checkpoint_atomic_exclusive_and_partial_never_overwritten(self):
        with tempfile.TemporaryDirectory() as temp:
            f=Path(temp)/'receipt.json';d.save(f,{'saved':True})
            self.assertTrue(json.loads(f.read_bytes())['saved'])
            self.assertFalse(f.with_name(f.name+'.partial').exists())
            with self.assertRaises(FileExistsError):d.save(f,{'saved':False})
            other=Path(temp)/'partial.json';other.with_name(other.name+'.partial').write_bytes(b'FAILED_PRESERVED')
            with self.assertRaises(FileExistsError):d.save(other,{})
            self.assertEqual(other.with_name(other.name+'.partial').read_bytes(),b'FAILED_PRESERVED')

    def test_batch_barriers_use_exact_three_tiers_and_do_not_claim_publication(self):
        self.assertEqual(d.completed_batches(['STATIC50_LOW','STATIC50_MID']),[])
        self.assertEqual(d.completed_batches(['STATIC50_LOW','STATIC50_MID','STATIC50_HIGH']),['STATIC50'])
        self.assertEqual(d.completed_batches(['STATIC50_LOW','H090_MID','VOL_MANAGED_HOLD_HIGH']),[])

    def run_mock_controller(self,configs,*,timeout=False,spawn_error=False):
        p,g,r,rs=fixture(configs);body=raw(g)
        temp=tempfile.TemporaryDirectory();root=Path(temp.name)
        go=root/'go.json';go.write_bytes(body);review=root/'review.json';review.write_bytes(r)
        args=SimpleNamespace(preparation=str(PREP),go=str(go),go_sha=d.sha(body),review=str(review),
            review_sha=rs,source='NEVER_READ_ACTUAL_SOURCE',output=str(root/'out'))
        calls=[]
        class Process:
            pid=987654
            def __init__(self,command):self.command=command;self.killed=False
            def wait(self,timeout=None):
                if timeout is not None and timeout_mode:raise subprocess.TimeoutExpired(self.command,timeout)
                return -9 if self.killed else 0
            def kill(self):self.killed=True
        timeout_mode=timeout
        def popen(command,**kwargs):
            calls.append((command,kwargs))
            if spawn_error:raise OSError('GENERATED_SPAWN_FAILURE')
            config=command[command.index('--config')+1];out=Path(command[command.index('--case-output')+1]);out.mkdir()
            receipt=dict(config=config,completed_minutes=527040,paid_comparison_eligible=True,root_GO_SHA256=args.go_sha)
            d.save(out/'CASE_RECEIPT.json',receipt)
            d.save(out/'TERMINAL_CHECKPOINT.json',dict(case_receipt_SHA256=d.sha((out/'CASE_RECEIPT.json').read_bytes()),
                completed_minutes=527040,all_evidence_fsynced_before_checkpoint=True))
            return Process(command)
        with patch.object(d.subprocess,'Popen',side_effect=popen), \
                patch.object(a.n,'_construct_case',side_effect=AssertionError('NO_ACTUAL_ACCOUNT')):
            if timeout or spawn_error:
                with self.assertRaises((RuntimeError,OSError)):d.controller(args)
            else:d.controller(args)
        return temp,root,args,calls

    def test_mocked_three_case_serial_controller_binds_review_and_emits_atomic_batch(self):
        temp,root,args,calls=self.run_mock_controller(['STATIC50_LOW','STATIC50_MID','STATIC50_HIGH'])
        try:
            self.assertEqual(len(calls),3)
            self.assertTrue(all('--review' in cmd and '--review-sha' in cmd and k['preexec_fn'] is d.limits for cmd,k in calls))
            batch=json.loads((root/'out/BATCH_COMPUTED_STATIC50.json').read_bytes())
            self.assertFalse(batch['publication_approved_by_this_checkpoint'])
            self.assertEqual(len(batch['cases']),3)
            self.assertFalse(list((root/'out').rglob('*.partial')))
        finally:temp.cleanup()

    def test_mocked600second_timeout_stops_before_second_job_without_retry(self):
        temp,root,args,calls=self.run_mock_controller(['STATIC50_LOW','STATIC50_MID'],timeout=True)
        try:
            self.assertEqual(len(calls),1)
            self.assertEqual(json.loads((root/'out/CONTROLLER_FAILURE.json').read_bytes())['status'],'STOPPED_NO_AUTOMATIC_RERUN')
        finally:temp.cleanup()

    def test_mocked_spawn_failure_is_preserved_without_second_job(self):
        temp,root,args,calls=self.run_mock_controller(['STATIC50_LOW','STATIC50_MID'],spawn_error=True)
        try:
            self.assertEqual(len(calls),1)
            self.assertEqual(json.loads((root/'out/CONTROLLER_FAILURE.json').read_bytes())['status'],'SPAWN_FAILED_NO_AUTOMATIC_RETRY')
        finally:temp.cleanup()

    def test_reporting366daily_calendar_uses_same365annualization_without_finance(self):
        names=['nav','free_cash','isolated_balance','gross_weight','close_us']+[s+'_signed_weight' for s in a.g.SYMBOLS]
        data=np.zeros((a.MINUTES,len(names)));data[:,0]=10000;data[:,1]=10000
        data[:,4]=np.arange(a.START+a.n.MINUTE,a.END+a.n.MINUTE,a.n.MINUTE)
        dtime=np.arange(a.START,a.END,a.g.DAY,dtype=np.int64)
        r=report.risk_diagnostics(data,names,dtime,np.zeros((366,5,5)),np.zeros((366,5)),'MID',[])
        self.assertEqual(r['complete_calendar_days'],366)
        self.assertEqual(r['observation_count'],527040)
        self.assertEqual(r['realized_daily_simple_return_annual_volatility'],0)


if __name__=='__main__':unittest.main(verbosity=2)
