"""Bounded serial controller for the approved Jan1-Jan4 nine-case smoke only."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import resource
import subprocess
import sys
import threading
import time
import traceback

HERE = Path(__file__).resolve().parent
PREPARATION_SHA = '380bf06f8ccb2c97cce2adfa62e67e1bc3854e6ec5e3bf39152db0a08de320bf'
ACTIVE = {'per_case_wall_seconds': 120, 'CPU_threads': 1, 'RSS_stop_bytes': 2_000_000_000,
          'AS_bytes': 4_000_000_000, 'output_bytes': 250_000_000, 'maximum_cases': 9}


def utc():
    return time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())


def save(path, value):
    path = Path(path)
    with path.open('x') as output:
        json.dump(value, output, indent=2, allow_nan=False); output.write('\n')


def own_bytes(path):
    return sum(p.stat().st_size for p in Path(path).rglob('*') if p.is_file())


def limits():
    resource.setrlimit(resource.RLIMIT_AS, (ACTIVE['AS_bytes'], ACTIVE['AS_bytes']))
    resource.setrlimit(resource.RLIMIT_CPU, (120, 120))
    resource.setrlimit(resource.RLIMIT_RSS, (ACTIVE['RSS_stop_bytes'], ACTIVE['RSS_stop_bytes']))
    if hasattr(os, 'sched_getaffinity'):
        os.sched_setaffinity(0, {min(os.sched_getaffinity(0))})


def case(args):
    import numpy as np
    import historical_entry as h
    import native_runtime as n
    out = Path(args.case_output)
    out.mkdir(exist_ok=False)
    started, began = utc(), time.monotonic()
    go = Path(args.go).read_bytes()
    if hashlib.sha256(go).hexdigest() != args.go_sha:
        raise ValueError('EXACT_CONTROLLER_GO_HASH_REQUIRED')
    if json.loads(go)['active_execution_limits'] != ACTIVE:
        raise ValueError('EXACT_ACTIVE_120_SECOND_BOUNDS_REQUIRED')
    stopped = threading.Event()
    def watch():
        while not stopped.wait(.05):
            rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024
            reason = ('RSS_LIMIT' if rss > ACTIVE['RSS_stop_bytes'] else
                      'WALL_LIMIT' if time.monotonic()-began > 120 else
                      'OUTPUT_LIMIT' if own_bytes(out) > ACTIVE['output_bytes'] else None)
            if reason:
                save(out/'RESOURCE_STOP.json', dict(status='STOPPED', reason=reason, UTC=utc(), RSS_bytes=rss))
                os._exit(137)
    threading.Thread(target=watch, daemon=True).start()
    try:
        sim, guard = h.make_smoke_case(args.source, args.preparation, go, args.go_sha, config=args.config)
        construction_seconds = time.monotonic()-began
        loop = time.monotonic()
        while sim.cursor < sim.end and sim.stop is None:
            sim.advance_day()
            print(json.dumps(dict(event='DAY_COMPLETE', config=args.config, UTC=utc(),
                completed_minutes=sim.rows_written, stop_us=sim.stop)), flush=True)
        loop_seconds = time.monotonic()-loop
        result = n.case_result(sim, guard)
        owned = n.runtime()[4]
        np.savez_compressed(out/'MINUTE.npz', values=result['minute'].to_numpy(),
            columns=np.asarray(result['minute'].columns))
        save(out/'ACCOUNT_FINANCIAL_AUDIT_SNAPSHOT.json', sim.account.snapshot())
        save(out/'GUARD_RECEIPTS.json', guard.receipts)
        save(out/'NATIVE_REJECTIONS.json', owned.export_tree(sim.rejections))
        save(out/'FUNDING_JOURNAL.json', owned.export_tree(sim.funding_journal))
        save(out/'RESULT.json', dict(config=args.config, summary=result['summary'],
            economics=result['economics'], common_execution_policy=result['common_execution_policy'],
            target_meta=result['target_meta']))
        receipt = dict(schema='ACTUAL_THREE_DAY_CASE_RECEIPT_V1', status='COMPLETED',
            config=args.config, start_UTC=started, end_UTC=utc(), PID=os.getpid(),
            construction_seconds=construction_seconds, native_loop_seconds=loop_seconds,
            total_wall_seconds=time.monotonic()-began,
            max_RSS_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,
            CPU_seconds=resource.getrusage(resource.RUSAGE_SELF).ru_utime+resource.getrusage(resource.RUSAGE_SELF).ru_stime,
            actual_limits=ACTIVE, observed_output_bytes=own_bytes(out),
            completed_minutes=sim.rows_written, required_minutes=4320,
            calendar=[h.START,h.END], account_stop_us=sim.stop,
            root_GO_SHA256=args.go_sha, preparation_SHA256=PREPARATION_SHA,
            current_code=h.code_identity(), annual_financial_runs=0, holdout_consumed=False,
            return_is_short_smoke_not_annual=True)
        save(out/'CASE_RECEIPT.json', receipt)
        print(json.dumps(dict(event='CASE_COMPLETE', config=args.config, UTC=utc(),
            wall_seconds=receipt['total_wall_seconds'], paid_flat=result['economics']['paid_flat'])), flush=True)
    except BaseException as error:
        if 'sim' in locals():
            try:
                save(out/'FAILED_ACCOUNT_FINANCIAL_AUDIT_SNAPSHOT.json', sim.account.snapshot())
                save(out/'FAILED_GUARD_RECEIPTS.json', guard.receipts)
                save(out/'FAILED_PROGRESS.json', dict(completed_minutes=sim.rows_written,
                    cursor_us=sim.cursor, stop_us=sim.stop, policy_restart_certified=False))
            except BaseException as audit_error:
                save(out/'FAILED_PARTIAL_AUDIT_UNAVAILABLE.json', dict(error=repr(audit_error)))
        save(out/'CASE_FAILURE.json', dict(status='FAILED_NO_AUTOMATIC_RETRY', UTC=utc(),
            config=args.config, error=repr(error), traceback=traceback.format_exc(),
            wall_seconds=time.monotonic()-began))
        raise
    finally:
        stopped.set()


def controller(args):
    out = Path(args.output)
    out.mkdir(exist_ok=False)
    prep_path = Path(args.preparation)/'PREPARATION.json'
    raw = prep_path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != PREPARATION_SHA:
        raise ValueError('EXACT_ROOT_APPROVED_PREPARATION003_REQUIRED')
    prep = json.loads(raw)
    go = dict(schema='ROOT_GO_2023_THREE_DAY_TRADITIONAL_GRID_V1',
        action='RUN_ONE_FRESH_THREE_DAY_CASE_PER_FIXED_CONFIG',
        preparation_SHA256=PREPARATION_SHA, calendar=prep['calendar'],
        permitted_configs=prep['configs'], resource_limits=prep['resource_limits'],
        active_execution_limits=ACTIVE,
        bounds_note='Preparation600s is a metadata upper bound; active controller is stricter120s per case.',
        cost='BASE27', annual_execution_authorized=False, locked_or_holdout_consumed=False,
        leverage=1, root_GO_recorded_UTC=utc(),
        controller_code_SHA256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    save(out/'ROOT_GO.json', go)
    go_sha = hashlib.sha256((out/'ROOT_GO.json').read_bytes()).hexdigest()
    started, start = utc(), time.monotonic()
    save(out/'CONTROLLER_START.json', dict(status='STARTED', UTC=started, PID=os.getpid(),
        root_GO_SHA256=go_sha, preparation_SHA256=PREPARATION_SHA, limits=ACTIVE,
        configuration_count=len(prep['configs'])))
    print(json.dumps(dict(event='CONTROLLER_STARTED',UTC=started,PID=os.getpid(),root_GO_SHA256=go_sha)), flush=True)
    statuses = []
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', OPENBLAS_NUM_THREADS='1',
               OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', NUMEXPR_NUM_THREADS='1')
    for config in prep['configs']:
        command = [sys.executable,str(Path(__file__).resolve()),'--case','--source',args.source,
            '--preparation',args.preparation,'--go',str((out/'ROOT_GO.json').resolve()),'--go-sha',go_sha,
            '--config',config,'--case-output',str((out/config).resolve())]
        with (out/(config+'.log')).open('w') as log:
            process = subprocess.Popen(command,cwd=HERE,env=env,stdout=log,stderr=subprocess.STDOUT,preexec_fn=limits)
            print(json.dumps(dict(event='ACTUAL_CASE_STARTED',UTC=utc(),config=config,PID=process.pid)),flush=True)
            try: code = process.wait(timeout=120)
            except subprocess.TimeoutExpired:
                process.kill(); process.wait(); code=124
                save(out/(config+'_CONTROLLER_TIMEOUT.json'),dict(status='STOPPED_120S_WALL',UTC=utc(),PID=process.pid))
        statuses.append(dict(config=config,PID=process.pid,exit_code=code))
        if code:
            save(out/'CONTROLLER_FAILURE.json',dict(status='STOPPED_NO_AUTOMATIC_RERUN',UTC=utc(),cases=statuses))
            raise RuntimeError('Case failed; preserved and stopped: '+config)
        print(json.dumps(dict(event='ACTUAL_CASE_TERMINAL',UTC=utc(),config=config,exit_code=code)),flush=True)
    save(out/'CONTROLLER_RECEIPT.json',dict(status='ALL_NINE_TERMINAL',start_UTC=started,end_UTC=utc(),
        PID=os.getpid(),wall_seconds=time.monotonic()-start,cases=statuses,root_GO_SHA256=go_sha,
        preparation_SHA256=PREPARATION_SHA,annual_runs=0,holdout_consumed=False,
        total_output_bytes=own_bytes(out)))
    print(json.dumps(dict(event='ALL_NINE_TERMINAL',UTC=utc(),seconds=time.monotonic()-start)),flush=True)


if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--case',action='store_true')
    parser.add_argument('--source',required=True)
    parser.add_argument('--preparation',required=True)
    parser.add_argument('--output')
    parser.add_argument('--go');parser.add_argument('--go-sha');parser.add_argument('--config');parser.add_argument('--case-output')
    args=parser.parse_args()
    case(args) if args.case else controller(args)
