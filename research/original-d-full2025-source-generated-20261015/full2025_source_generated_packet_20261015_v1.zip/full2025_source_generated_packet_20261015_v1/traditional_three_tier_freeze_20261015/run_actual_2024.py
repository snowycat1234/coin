"""New exact-GO-only bounded serial controller for finite seen2024 jobs.

Importing this module does not create an account. Root supplies the separately
authorized GO bytes/hash; this controller does not manufacture authorization.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import resource
import subprocess
import sys
import threading
import time
import traceback
from io import BytesIO

HERE=Path(__file__).resolve().parent
SOURCE_REVIEW_SHA256='493683d02e060a1e0015df0963e66effa11eddb95582b17cd43b9e7463b942bd'
LIMITS={'per_case_wall_seconds':600,'CPU_threads':1,'RSS_stop_bytes':2_000_000_000,
    'AS_bytes':4_000_000_000,'output_bytes':250_000_000,'maximum_cases':9}


def utc():return time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
def sha(raw):return hashlib.sha256(raw).hexdigest()
def write_bytes(path,body):
    """Atomic exclusive checkpoint: never replace old evidence or a partial."""
    path=Path(path);temporary=path.with_name(path.name+'.partial')
    if path.exists():raise FileExistsError(path)
    with temporary.open('xb') as out:
        out.write(body);out.flush();os.fsync(out.fileno())
    os.link(temporary,path)  # Atomic no-overwrite installation.
    temporary.unlink()
    directory=os.open(path.parent,os.O_RDONLY|os.O_DIRECTORY)
    try:os.fsync(directory)
    finally:os.close(directory)
def save(path,value):write_bytes(path,(json.dumps(value,indent=2,allow_nan=False)+'\n').encode())
def own_bytes(path):return sum(p.stat().st_size for p in Path(path).rglob('*') if p.is_file())
def reporting_identity():return {name:sha((HERE/name).read_bytes()) for name in ('run_actual_2024.py','annual_reporting.py')}


def validate_installed_quality(sim,guard,prep):
    """Fail closed before the first historical clock, not after the loop."""
    quality=getattr(guard,'causal_mark_quality_guard',None)
    if (quality is None or not quality._installed
            or quality.guard is not guard or quality.sim is not sim
            or getattr(guard.original_attempt,'__self__',None) is not quality
            or guard.original_attempt!=quality.attempt or sim.attempt!=guard.attempt
            or quality.source_sidecar_sha256!=prep['artifacts']['CAUSAL_MARK_ADAPTER.json']['SHA256']
            or quality.identity['source_sidecar_sha256']!=quality.source_sidecar_sha256
            or quality.policy_sha256!=sha(json.dumps(quality.identity,sort_keys=True,separators=(',',':')).encode())
            or sim.meta['mark_quality_policy_identity']!=quality.policy_sha256):
        raise ValueError('EXACT_INSTALLED_2024_CAUSAL_QUALITY_GUARD_REQUIRED_BEFORE_ADVANCE')
    return quality


def validate_controller_go(preparation,body,digest,review_raw,review_sha):
    import annual_entry_2024 as a
    if not isinstance(body,bytes) or sha(body)!=digest:raise ValueError('EXACT_EXTERNAL_CONTROLLER_ROOT_GO_REQUIRED')
    go=json.loads(body)
    if (go.get('resource_limits')!=LIMITS or go.get('controller_reporting_identity')!=reporting_identity()
            or go.get('serial_execution') is not True
            or not isinstance(go.get('permitted_configs'),list) or not go['permitted_configs']):
        raise ValueError('EXACT_SERIAL_CONTROLLER_AND_REPORTING_PIN_REQUIRED')
    for config in go['permitted_configs']:a.validate_root_go(preparation,body,digest,config=config)
    prep=json.loads(preparation)
    a._validate_independent_review(preparation,prep,review_raw,review_sha,body)
    if (json.loads(review_raw).get('controller_reporting_identity')!=reporting_identity()
            or json.loads(review_raw).get('source_review_receipt_SHA256')!=SOURCE_REVIEW_SHA256
            or go.get('source_review_receipt_SHA256')!=SOURCE_REVIEW_SHA256):
        raise ValueError('REVIEWED_CONTROLLER_AND_REPORTING_IDENTITY_REQUIRED')
    return go


def completed_batches(completed):
    """Computation barriers, never an independent-review/publication approval."""
    strategies=('STATIC50','H090','VOL_MANAGED_HOLD')
    return [strategy for strategy in strategies if
        {strategy+'_'+tier for tier in ('LOW','MID','HIGH')}<=set(completed)]


def prior_completed(go,preparation):
    """A GO-bound earlier pilot can satisfy a batch; never rerun that cell."""
    references=go.get('prior_completed_cases',[])
    if not isinstance(references,list):raise ValueError('BOUND_PRIOR_CASE_LIST_REQUIRED')
    completed={};prep=json.loads(preparation)
    representatives={group[0] for group in prep['execution_groups']}
    for ref in references:
        body=Path(ref['case_receipt_path']).read_bytes();receipt=json.loads(body)
        key=receipt['config']
        if (sha(body)!=ref['case_receipt_SHA256'] or key in completed
                or key not in representatives
                or key in go['permitted_configs'] or receipt['preparation_SHA256']!=sha(preparation)
                or receipt['calendar']!=[1704067200000000,1735689600000000]
                or receipt['schema']!='FINITE_FULL2024_CASE_RECEIPT_V1'
                or receipt['status']!='COMPLETED_NATIVE_PATH' or receipt['account_stop_us'] is not None
                or receipt['code_identity']!=prep['code_identity']
                or receipt['completed_minutes']!=527040 or not receipt['paid_comparison_eligible']
                or receipt['required_minutes']!=527040 or receipt['actual_complete_calendar_days']!=366
                or receipt['source_identity']!=prep['source_identity']
                or receipt['source_quality_adapter']!=prep['artifacts']['CAUSAL_MARK_ADAPTER.json']
                or receipt['controller_reporting_identity']!=reporting_identity()
                or receipt['independent_review_SHA256']!=go['independent_review_SHA256']
                or receipt['source_review_receipt_SHA256']!=SOURCE_REVIEW_SHA256
                or receipt['original_interpolated_mark_execution_admitted'] is not False
                or receipt['limits']!=LIMITS or receipt['root_GO_SHA256']!=ref['root_GO_SHA256']):
            raise ValueError('EXACT_DISJOINT_PAID_2024_PRIOR_CASE_REQUIRED')
        prior_path=Path(ref.get('root_GO_path',str(Path(ref['case_receipt_path']).parent.parent/'ROOT_GO.json')))
        prior_body=prior_path.read_bytes();prior_go=json.loads(prior_body)
        if (sha(prior_body)!=ref['root_GO_SHA256'] or key not in prior_go['permitted_configs']
                or prior_go['preparation_SHA256']!=sha(preparation)
                or prior_go['independent_review_SHA256']!=go['independent_review_SHA256']
                or prior_go.get('source_review_receipt_SHA256')!=SOURCE_REVIEW_SHA256
                or prior_go['controller_reporting_identity']!=reporting_identity()):
            raise ValueError('PRIOR_CASE_ORIGINAL_GO_SCOPE_NOT_BOUND')
        completed[key]=dict(case_receipt_path=ref['case_receipt_path'],case_receipt_SHA256=sha(body),
            review_status='PRIOR_ROOT_GO_BOUND_CASE_REQUIRES_SAVED_REVIEW_BEFORE_PUBLICATION')
    return completed


def limits():
    for which,value in ((resource.RLIMIT_AS,LIMITS['AS_bytes']),
            (resource.RLIMIT_CPU,600),(resource.RLIMIT_RSS,LIMITS['RSS_stop_bytes'])):
        resource.setrlimit(which,(value,value))
    if hasattr(os,'sched_getaffinity'):os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})


def case(args):
    limits()
    for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','POLARS_MAX_THREADS'):
        os.environ[key]='1'
    import numpy as np
    import annual_entry_2024 as a
    import native_runtime as n
    import annual_reporting as report
    preparation=(Path(args.preparation)/'PREPARATION.json').read_bytes()
    go=Path(args.go).read_bytes();review=Path(args.review).read_bytes();validate_controller_go(preparation,go,args.go_sha,review,args.review_sha)
    out=Path(args.case_output);out.mkdir(exist_ok=False)
    began=time.monotonic();started=utc();stopped=threading.Event()
    def watch():
        while not stopped.wait(.05):
            rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024
            reason=('RSS_LIMIT' if rss>LIMITS['RSS_stop_bytes'] else
                'WALL_LIMIT' if time.monotonic()-began>600 else
                'OUTPUT_LIMIT' if own_bytes(out)>LIMITS['output_bytes'] else None)
            if reason:
                save(out/'RESOURCE_STOP.json',dict(reason=reason,UTC=utc(),RSS_bytes=rss))
                os._exit(137)
    threading.Thread(target=watch,daemon=True).start()
    try:
        sim,guard=a.make_annual_case(args.source,args.preparation,go,args.go_sha,config=args.config,review_raw=review,expected_review_sha256=args.review_sha)
        prep=json.loads(preparation);quality=validate_installed_quality(sim,guard,prep)
        construction=time.monotonic()-began;loop=time.monotonic()
        while sim.cursor<sim.end and sim.stop is None:
            sim.advance_day()
            print(json.dumps(dict(event='DAY_COMPLETE',config=args.config,UTC=utc(),
                completed_minutes=sim.rows_written,stop_us=sim.stop)),flush=True)
        loop_seconds=time.monotonic()-loop;result=n.case_result(sim,guard);owned=n.runtime()[4]
        data=result['minute'].to_numpy();columns=result['minute'].columns
        target_rec=prep['artifacts']['TARGETS.npz']
        target_bytes=a.h._read_exact(Path(args.preparation)/'TARGETS.npz',
            target_rec['SHA256'],target_rec['bytes'])
        with np.load(BytesIO(target_bytes),allow_pickle=False) as z:
            risk=report.risk_diagnostics(data,columns,z['decision_us'],z['annual_covariance'],
                z[args.config],guard.tier_name,guard.receipts)
        np.savez_compressed(out/'MINUTE.npz',values=data,columns=np.asarray(columns))
        with (out/'MINUTE.npz').open('rb') as handle:os.fsync(handle.fileno())
        save(out/'ACCOUNT_FINANCIAL_AUDIT_SNAPSHOT.json',sim.account.snapshot())
        save(out/'GUARD_RECEIPTS.json',guard.receipts)
        save(out/'NATIVE_REJECTIONS.json',owned.export_tree(sim.rejections))
        save(out/'FUNDING_JOURNAL.json',owned.export_tree(sim.funding_journal))
        save(out/'OBSERVED_RISK.json',risk)
        save(out/'CAUSAL_MARK_QUALITY.json',dict(version=quality.identity['version'],
            policy_sha256=quality.policy_sha256,identity=quality.identity,
            source_adapter=prep['artifacts']['CAUSAL_MARK_ADAPTER.json'],
            estimated_source_mark_cells=10,original_interpolated_mark_execution_admitted=False,
            account_mark_clock_is_valuation_estimate_clock_not_new_genuine_observation=True,
            receipts=quality.receipts))
        save(out/'RESULT.json',dict(config=args.config,summary=result['summary'],economics=result['economics'],
            common_execution_policy=result['common_execution_policy'],target_meta=result['target_meta']))
        if reporting_identity()!=json.loads(go)['controller_reporting_identity']:
            raise ValueError('CONTROLLER_OR_REPORT_CODE_CHANGED_DURING_CASE')
        if own_bytes(out)>LIMITS['output_bytes']:raise RuntimeError('OUTPUT_LIMIT')
        receipt=dict(schema='FINITE_FULL2024_CASE_RECEIPT_V1',status='COMPLETED_NATIVE_PATH',
            config=args.config,start_UTC=started,end_UTC=utc(),PID=os.getpid(),
            construction_seconds=construction,native_loop_seconds=loop_seconds,
            total_wall_seconds=time.monotonic()-began,max_RSS_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,
            CPU_seconds=resource.getrusage(resource.RUSAGE_SELF).ru_utime+resource.getrusage(resource.RUSAGE_SELF).ru_stime,
            limits=LIMITS,observed_output_bytes=own_bytes(out),completed_minutes=sim.rows_written,
            required_minutes=a.MINUTES,calendar=[a.START,a.END],account_stop_us=sim.stop,
            paid_comparison_eligible=result['economics']['paid_flat'],root_GO_SHA256=args.go_sha,
            preparation_SHA256=sha(preparation),code_identity=a.code_identity(),
            controller_reporting_identity=reporting_identity(),holdout_consumed=False,other_years_run=0)
        receipt.update(independent_review_SHA256=args.review_sha,source_identity=prep['source_identity'],
            source_review_receipt_SHA256=SOURCE_REVIEW_SHA256,
            execution_label='NATIVE_ACCOUNT_OFFLINE_PROXY_WITH_COARSE_QUANTITY_SENSITIVITY',
            source_quality_adapter=prep['artifacts']['CAUSAL_MARK_ADAPTER.json'],
            stale_mark_block_count=len(quality.receipts),original_interpolated_mark_execution_admitted=False,
            actual_complete_calendar_days=risk['complete_calendar_days'])
        save(out/'CASE_RECEIPT.json',receipt)
        save(out/'TERMINAL_CHECKPOINT.json',dict(config=args.config,UTC=utc(),
            case_receipt_SHA256=sha((out/'CASE_RECEIPT.json').read_bytes()),
            paid_comparison_eligible=receipt['paid_comparison_eligible'],
            completed_minutes=sim.rows_written,all_evidence_fsynced_before_checkpoint=True))
        if own_bytes(out)>LIMITS['output_bytes']:raise RuntimeError('OUTPUT_LIMIT_AFTER_TERMINAL_CHECKPOINT')
        if not receipt['paid_comparison_eligible']:raise RuntimeError('INCOMPLETE_HALT_OR_RESIDUAL_NOT_ANNUAL_PAID_COMPARISON')
        print(json.dumps(dict(event='CASE_COMPLETE',config=args.config,UTC=utc(),wall_seconds=receipt['total_wall_seconds'])),flush=True)
    except BaseException as error:
        if 'sim' in locals():
            try:
                save(out/'FAILED_ACCOUNT_FINANCIAL_AUDIT_SNAPSHOT.json',sim.account.snapshot())
                save(out/'FAILED_GUARD_RECEIPTS.json',guard.receipts)
                save(out/'FAILED_PROGRESS.json',dict(completed_minutes=sim.rows_written,cursor_us=sim.cursor,
                    stop_us=sim.stop,policy_restart_certified=False))
            except BaseException as audit_error:
                save(out/'FAILED_PARTIAL_AUDIT_UNAVAILABLE.json',dict(error=repr(audit_error)))
        save(out/'CASE_FAILURE.json',dict(status='FAILED_NO_AUTOMATIC_RETRY',UTC=utc(),config=args.config,
            error=repr(error),traceback=traceback.format_exc(),wall_seconds=time.monotonic()-began))
        raise
    finally:stopped.set()


def controller(args):
    preparation=(Path(args.preparation)/'PREPARATION.json').read_bytes()
    body=Path(args.go).read_bytes();review=Path(args.review).read_bytes();go=validate_controller_go(preparation,body,args.go_sha,review,args.review_sha)
    completed=prior_completed(go,preparation);emitted=set(completed_batches(completed))
    out=Path(args.output);out.mkdir(exist_ok=False)
    write_bytes(out/'ROOT_GO.json',body)
    write_bytes(out/'INDEPENDENT_REVIEW.json',review)
    started=utc();begin=time.monotonic()
    save(out/'CONTROLLER_START.json',dict(UTC=started,PID=os.getpid(),status='STARTED',
        permitted_configs=go['permitted_configs'],root_GO_SHA256=args.go_sha,limits=LIMITS))
    print(json.dumps(dict(event='CONTROLLER_STARTED',UTC=started,PID=os.getpid(),root_GO_SHA256=args.go_sha)),flush=True)
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',
        MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',POLARS_MAX_THREADS='1')
    statuses=[]
    for config in go['permitted_configs']:
        command=[sys.executable,str(Path(__file__).resolve()),'--case','--source',args.source,
            '--preparation',str(Path(args.preparation).resolve()),'--go',str((out/'ROOT_GO.json').resolve()),'--go-sha',args.go_sha,
            '--review',str((out/'INDEPENDENT_REVIEW.json').resolve()),'--review-sha',args.review_sha,
            '--config',config,'--case-output',str((out/config).resolve())]
        command[command.index('--source')+1]=str(Path(args.source).resolve())
        with (out/(config+'.log')).open('x') as log:
            try:process=subprocess.Popen(command,cwd=HERE,env=env,stdout=log,stderr=subprocess.STDOUT,preexec_fn=limits)
            except BaseException as error:
                save(out/'CONTROLLER_FAILURE.json',dict(status='SPAWN_FAILED_NO_AUTOMATIC_RETRY',UTC=utc(),
                    config=config,error=repr(error),cases=statuses))
                raise
            print(json.dumps(dict(event='ACTUAL_ANNUAL_CASE_STARTED',UTC=utc(),config=config,PID=process.pid)),flush=True)
            try:code=process.wait(timeout=600)
            except subprocess.TimeoutExpired:
                process.kill();process.wait();code=124
                save(out/(config+'_CONTROLLER_TIMEOUT.json'),dict(UTC=utc(),status='STOPPED_600S_WALL'))
        statuses.append(dict(config=config,PID=process.pid,exit_code=code))
        if code:
            save(out/'CONTROLLER_FAILURE.json',dict(status='STOPPED_NO_AUTOMATIC_RERUN',UTC=utc(),cases=statuses))
            raise RuntimeError('Annual case failed, retained, no retry: '+config)
        receipt_path=out/config/'CASE_RECEIPT.json';receipt_body=receipt_path.read_bytes();receipt=json.loads(receipt_body)
        checkpoint=json.loads((out/config/'TERMINAL_CHECKPOINT.json').read_bytes())
        if (not receipt['paid_comparison_eligible'] or receipt['completed_minutes']!=527040
                or receipt['root_GO_SHA256']!=args.go_sha
                or checkpoint['case_receipt_SHA256']!=sha(receipt_body)
                or checkpoint['completed_minutes']!=527040 or not checkpoint['all_evidence_fsynced_before_checkpoint']):
            raise RuntimeError('CASE_TERMINAL_SCOPE_OR_PAID_STATUS_MISMATCH')
        completed[config]=dict(case_receipt_path=str(receipt_path.resolve()),case_receipt_SHA256=sha(receipt_body))
        save(out/('CASE_TERMINAL_'+config+'.json'),dict(UTC=utc(),config=config,**completed[config]))
        print(json.dumps(dict(event='CASE_TERMINAL',UTC=utc(),config=config,case_receipt_SHA256=sha(receipt_body))),flush=True)
        for strategy in completed_batches(completed):
            if strategy in emitted:continue
            emitted.add(strategy)
            evidence={key:value for key,value in completed.items() if key.startswith(strategy+'_')}
            save(out/('BATCH_COMPUTED_'+strategy+'.json'),dict(UTC=utc(),strategy=strategy,year=2024,
                cases=evidence,status='THREE_RISK_CELLS_COMPUTED_INDEPENDENT_SAVED_REVIEW_PENDING',
                publication_approved_by_this_checkpoint=False))
            print(json.dumps(dict(event='BATCH_COMPUTE_COMPLETE',UTC=utc(),strategy=strategy,year=2024,
                independent_review_required_before_publication=True)),flush=True)
    save(out/'CONTROLLER_RECEIPT.json',dict(status='ALL_APPROVED_CANONICAL_JOBS_TERMINAL',start_UTC=started,
        end_UTC=utc(),wall_seconds=time.monotonic()-begin,cases=statuses,root_GO_SHA256=args.go_sha,
        requested_matrix_cells=9,approved_job_count=len(statuses),holdout_consumed=False,other_years_run=0,
        total_output_bytes=own_bytes(out)))


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--case',action='store_true')
    for name in ('source','preparation','go','go-sha','review','review-sha'):parser.add_argument('--'+name,required=True)
    for name in ('output','config','case-output'):parser.add_argument('--'+name)
    args=parser.parse_args();case(args) if args.case else controller(args)
