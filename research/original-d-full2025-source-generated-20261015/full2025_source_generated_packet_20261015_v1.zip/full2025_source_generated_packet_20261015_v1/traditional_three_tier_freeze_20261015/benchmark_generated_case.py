"""One generated HIGH HOLD three-day native case, no historical outcomes."""
import hashlib
import json
from pathlib import Path
import resource
import time
from collections import Counter

import numpy as np
import frozen_grid as g
import native_runtime as n
from test_native_runtime import fixture, BASE
from test_frozen_grid import prices_fixture


def run():
    wall = time.monotonic(); cpu = time.process_time()
    window, rows, d = fixture(3)
    p, t, _ = prices_fixture(); p = p / 100 * BASE
    _, targets, _, _ = g.build_target_grid(p, t, t.copy(), d)
    construction = time.monotonic()
    sim, guard = n.build_case(window, rows, d, targets['VOL_MANAGED_HOLD_HIGH'],
        tier_name='HIGH', generated_scope='GENERATED_FAKE_ORIGIN_ONLY')
    before_loop = time.monotonic()
    while sim.cursor < sim.end and sim.stop is None:
        sim.advance_day()
    loop_seconds = time.monotonic() - before_loop
    result = n.case_result(sim, guard)
    total = time.monotonic() - wall
    fractions = Counter(r['fraction'] for r in guard.receipts if 'fraction' in r)
    return {
        'schema': 'GENERATED_THREE_DAY_SINGLE_NATIVE_CASE_BENCHMARK_V1',
        'fixture': 'DETERMINISTIC_GENERATED_HIGH_HOLD_NOT_MARKET_DATA',
        'days': 3, 'configuration': 'VOL_MANAGED_HOLD_HIGH', 'completed_minutes': sim.rows_written,
        'total_wall_seconds': total, 'source_target_seconds': construction-wall,
        'account_construction_seconds': before_loop-construction,
        'native_loop_seconds': loop_seconds, 'CPU_seconds': time.process_time()-cpu,
        'max_RSS_bytes': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,
        'linear_365_day_loop_projection_seconds': loop_seconds*365/3,
        'projection_is_execution_guarantee': False,
        'projection_limit': 'Three generated days do not establish annual event frequency or journal/output cost.',
        'paid_flat': result['economics']['paid_flat'], 'stop': sim.stop,
        'trade_legs': len(sim.account.trades), 'native_rejections': len(sim.rejections),
        'guard_receipt_count': len(guard.receipts), 'partial_selection_counts': dict(fractions),
        'maximum_corner_count': max((r.get('corners_checked', 0) for r in guard.receipts), default=0),
        'historical_data_read': False, 'financial_years_run': 0, 'holdout_outcomes_read': False,
        'new_fits': 0, 'leverage': 1,
        'code_SHA256': {name: hashlib.sha256((Path(__file__).parent/name).read_bytes()).hexdigest()
                        for name in ('frozen_grid.py', 'native_runtime.py', 'benchmark_generated_case.py')}}


if __name__ == '__main__':
    print(json.dumps(run(), indent=2, allow_nan=False))
