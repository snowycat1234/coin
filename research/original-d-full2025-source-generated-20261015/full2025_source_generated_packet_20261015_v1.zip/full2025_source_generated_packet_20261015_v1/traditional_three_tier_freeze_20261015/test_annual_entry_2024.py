"""Actual 2024 source/target-only and generated metadata tests; NO 2024 account."""
from copy import deepcopy
from io import BytesIO
import hashlib
import json
from pathlib import Path
import shutil
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import numpy as np
import annual_entry_2024 as a

HERE=Path(__file__).resolve().parent
SOURCE=HERE.parent/'native_2024_source_restore_20261015'


def raw(value):return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def digest(body):return hashlib.sha256(body).hexdigest()


def fixture_review(preparation):
    p=json.loads(preparation)
    body=raw(dict(schema='INDEPENDENT_FINITE2024_CAUSAL_ADAPTER_REVIEW_V1',
        status='PASS_SOURCE_ONLY_AND_GENERATED_GATES_NO_ACCOUNT_GO',preparation_SHA256=digest(preparation),
        code_identity=p['code_identity'],source_identity=p['source_identity'],artifacts=p['artifacts'],
        execution_identity=p['execution_identity'],mark_feed_adapter_version=a.m.VERSION,
        mark_quality_guard_version=a.q.VERSION,original_interpolated_mark_execution_admitted=False,
        actual_2024_accounts_constructed=0,actual_2024_financial_runs=0))
    return body,digest(body)


def fixture_go(preparation,configs=None,review_sha=None):
    p=json.loads(preparation)
    if review_sha is None:review_sha=fixture_review(preparation)[1]
    body=raw(dict(schema='ROOT_GO_FIXED_FINITE_FULL2024_GRID_V1',
        action='RUN_FRESH_APPROVED_2024_CANONICAL_JOBS_ONLY',preparation_SHA256=digest(preparation),
        calendar=[a.START,a.END],cost='BASE27',code_identity=p['code_identity'],
        source_identity=p['source_identity'],artifacts=p['artifacts'],resource_limits=p['resource_limits'],
        permitted_configs=configs or [group[0] for group in p['execution_groups']],
        locked_or_holdout_consumed=False,other_years_authorized=False,
        original_interpolated_mark_execution_admitted=False,coldstart_policy=p['coldstart_policy'],
        mark_feed_adapter_version=a.m.VERSION,mark_quality_guard_version=a.q.VERSION,
        independent_review_SHA256=review_sha))
    return body,digest(body)


class Annual2024SourceGateTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=tempfile.TemporaryDirectory(prefix='annual2024_source_gate_')
        cls.prepared=Path(cls.temp.name)/'prepared'
        # Absolute prohibition on actual constructor/runtime/results during prep.
        with patch.object(a.n,'_construct_case',side_effect=AssertionError('NO_2024_ACCOUNT')), \
                patch.object(a.n,'runtime',side_effect=AssertionError('NO_FINANCIAL_RUNTIME')):
            cls.prep=a.prepare_source_only(SOURCE,cls.prepared)
        cls.preparation=(cls.prepared/'PREPARATION.json').read_bytes()

    @classmethod
    def tearDownClass(cls):cls.temp.cleanup()

    def inputs(self):
        go,sha=fixture_go(self.preparation,['STATIC50_LOW'])
        with patch.object(a.n,'_construct_case',side_effect=AssertionError('NO_2024_ACCOUNT')):
            return a.validate_annual_inputs(SOURCE,self.prepared,go,sha,config='STATIC50_LOW')

    def test_scope_is_source_target_only_unchanged_v3_and_366_days(self):
        p=self.prep
        self.assertEqual((p['accounts_created'],p['annual_returns_computed']),(0,False))
        self.assertEqual((p['days'],p['required_minutes']),(366,527040))
        self.assertEqual(p['code_identity'],a.code_identity())
        self.assertEqual(p['execution_label'],'OFFLINE PROXY WITH COARSE QUANTITY SENSITIVITY')
        self.assertFalse(p['original_interpolated_mark_execution_admitted'])
        self.assertFalse(p['locked_or_holdout_consumed'])
        self.assertEqual(p['resource_limits'],a.RESOURCE_LIMITS)
        self.assertEqual(p['original200_quality']['exported_close_cells'],2830)
        self.assertEqual(p['original200_quality']['used_window_union_cells'],2825)

    def test_same_fresh_flat_unknown_prior_coldstart_even_prior_is_available(self):
        policy=self.prep['coldstart_policy']
        self.assertFalse(policy['available_prior_source_used'])
        self.assertEqual(policy['initial_signal_us'],a.START)
        self.assertEqual(policy['first_real_completed_quote_us'],a.START+a.n.MINUTE)
        self.assertEqual(policy['earliest_initial_increase_admission_us'],a.START+a.n.MINUTE+1)
        window=self.inputs()[1]
        self.assertNotIn('previous_quote',window)
        self.assertNotIn('initial_prior',window)

    def test_full366_exact_targets_do_not_approximate_or_claim_alpha(self):
        eq=json.loads((self.prepared/'EXACT_EXECUTION_EQUALITY.json').read_bytes())
        self.assertEqual(eq['unique_execution_jobs'],9)
        self.assertEqual(eq['requested_matrix_cells'],9)
        self.assertTrue(eq['no_cross_tier_reuse'])
        self.assertFalse(eq['independent_alpha_families_claimed'])
        for pair in eq['STATIC50_H090_comparisons']:
            self.assertFalse(pair['entire_target_path_byte_exact'])
            self.assertGreater(pair['different_float64_cells'],0)
            self.assertLess(pair['maximum_absolute_target_difference'],3e-16)

    def test_generated_exact_dedup_only_within_tier_and_one_bit_splits(self):
        d=np.arange(a.START,a.END,a.g.DAY,dtype=np.int64)
        targets={s+'_'+t:np.zeros((366,5)) for s,t in a.g.CONFIGS}
        eq=a.target_equality_receipt(d,targets,np.zeros((366,5,5)),source_identity='1'*64,code={})
        self.assertEqual(eq['unique_execution_jobs'],3)
        targets['H090_LOW'][0,0]=np.nextafter(0.,1.)
        changed=a.target_equality_receipt(d,targets,np.zeros((366,5,5)),source_identity='1'*64,code={})
        self.assertEqual(changed['unique_execution_jobs'],4)

    def test_target_dtype_coercion_cannot_authorize_byte_exact_reuse(self):
        d=np.arange(a.START,a.END,a.g.DAY,dtype=np.int64)
        targets={s+'_'+t:np.zeros((366,5),dtype=np.float64) for s,t in a.g.CONFIGS}
        targets['H090_LOW']=targets['H090_LOW'].astype(np.float32)
        with self.assertRaisesRegex(ValueError,'FLOAT64_TARGET'):
            a.target_equality_receipt(d,targets,np.zeros((366,5,5)),source_identity='1'*64,code={})

    def test_partial_calendar_cannot_claim_complete_year_equality(self):
        d=np.arange(a.START,a.START+3*a.g.DAY,a.g.DAY,dtype=np.int64)
        with self.assertRaisesRegex(ValueError,'FULL366'):
            a.target_equality_receipt(d,{s+'_'+t:np.zeros((3,5)) for s,t in a.g.CONFIGS},
                np.zeros((3,5,5)),source_identity='1'*64,code={})

    def test_source_positive_inputs_have_exact_clocks_records_and_rows(self):
        p,window,rows,d,w,captured=self.inputs()
        self.assertEqual((len(rows),len(d),w.shape,len(window['daily']),len(window['events'])),
            (2825,366,(366,5),1830,5490))
        self.assertEqual([window['start'],window['end']],[a.START,a.END])
        self.assertTrue(all(row['available_us']==row['close_us'] for row in rows))
        self.assertIn('INITIAL_PRIOR_SOURCE.json',captured)
        self.assertTrue(window['original_overlay_future_looking'])
        self.assertFalse(window['original_overlay_execution_admitted'])

    def test_all12_lazy_captured_months_decode_with_every_path_open_blocked(self):
        window=self.inputs()[1]
        with patch.object(Path,'read_bytes',side_effect=AssertionError('LATE_REOPEN')), \
                patch.object(Path,'open',side_effect=AssertionError('LATE_OPEN')):
            sizes=[];first=None;last=None;stale_values={}
            for block in window['minute_blocks']():
                stamps=block['times'];sizes.append(len(stamps))
                if first is None:first=int(stamps[0])
                last=int(stamps[-1])
                self.assertEqual(set(block['market']),set(a.g.SYMBOLS))
                for fields in block['market'].values():
                    self.assertEqual(set(fields),{'open','close','quote_volume','mark'})
                    self.assertTrue(all(v.dtype==np.dtype('float64') and np.isfinite(v).all() for v in fields.values()))
                for at in (a.m.LAST_GENUINE_OPEN,*a.m.MISSING_OPENS):
                    if int(stamps[0])<=at<=int(stamps[-1]):
                        i=int(np.searchsorted(stamps,at));stale_values[at]={s:float(block['market'][s]['mark'][i]) for s in a.g.SYMBOLS}
        self.assertEqual(sizes,[1440]*366)
        self.assertEqual((first,last),(a.START,a.END-a.n.MINUTE))
        self.assertEqual(stale_values[a.m.LAST_GENUINE_OPEN],stale_values[a.m.MISSING_OPENS[0]])
        self.assertEqual(stale_values[a.m.LAST_GENUINE_OPEN],stale_values[a.m.MISSING_OPENS[1]])

    def test_original_overlay_and_mask_are_pinned_and_qualified(self):
        p=self.prep['original200_quality']
        self.assertEqual(p['derived_mark_cells'],10)
        self.assertEqual(p['derived_mark_overlay_SHA256'],a.SOURCE_PINS['derived_mark/DERIVED_MARK_OHLC.csv'][1])
        rec=json.loads((self.prepared/'CAUSAL_MARK_ADAPTER.json').read_bytes())
        self.assertEqual(len(rec['sidecar']),10)
        self.assertEqual(rec['qualification']['increase_block_interval_us'],[1723456980000000,1723457100000000])
        self.assertTrue(all(r['stale'] and r['derived'] and r['source_missing'] and not r['is_actual_current_venue_mark'] for r in rec['sidecar']))
        self.assertEqual({r['last_genuine_source_available_us'] for r in rec['sidecar']},{1723456920000000})
        self.assertEqual({r['stale_age_us'] for r in rec['sidecar']},{60000000,120000000})

    def test_future_endpoint_and_original_interpolation_perturbations_do_not_change_carry(self):
        # Actual source bytes are never modified. Perturb only detached arrays.
        _,_,_,_,_,_,captured=a._source(SOURCE)
        arrays=a._month_arrays(captured['prepared_2024/months/2024-08.npz'],1722470400000000,44640)
        baseline,sidecar=a.m.project_month(arrays)
        perturbed={key:value.copy() for key,value in arrays.items()}
        k=int(np.searchsorted(arrays['times'],a.m.MISSING_OPENS[0]))
        end=int(np.searchsorted(arrays['times'],a.m.NEXT_GENUINE_OPEN))
        for s in a.g.SYMBOLS:
            perturbed[s+'_mark'][k:]=perturbed[s+'_mark'][k:]*10+123
            perturbed[s+'_open'][end:]=perturbed[s+'_open'][end:]*9
        changed,newsidecar=a.m.project_month(perturbed)
        self.assertEqual(sidecar,newsidecar)
        for s in a.g.SYMBOLS:
            self.assertEqual(baseline[s+'_mark'][:end].tobytes(),changed[s+'_mark'][:end].tobytes())
            self.assertEqual(arrays[s+'_close'].tobytes(),baseline[s+'_close'].tobytes())
        self.assertEqual((a.m.FIRST_MISSING_KNOWN,a.m.RESUME_AVAILABLE),(1723456980000000,1723457100000000))

    def test_generated_corrupted_200day_window_and_symbol_order_fail(self):
        _,_,t,p,_,_,captured=a._source(SOURCE)
        proof=json.loads(captured['SOURCE_200DAY_WINDOW_PROOF.json'])
        for mutate in (lambda x:x['windows'][0].update(last_available_us=a.START+1),
                       lambda x:x.update(symbols=list(reversed(a.g.SYMBOLS))),
                       lambda x:x['windows'][10].update(ordered_close_values_SHA256='0'*64)):
            bad=deepcopy(proof);mutate(bad)
            with self.assertRaises(ValueError):a._validate_warmup_proof(captured['SOURCE_WARMUP_CLOSE_ONLY.npz'],bad,
                self.prep['source_files']['prepared_2024/SOURCE_INDEX.json']['SHA256'])

    def test_go_missing_unknown_hash_or_nonbytes_fails(self):
        go,sha=fixture_go(self.preparation)
        for body,d in [(None,None),(go,'0'*64),(go.decode(),sha)]:
            with self.assertRaises(ValueError):a.validate_root_go(self.preparation,body,d,config='STATIC50_LOW')

    def test_pilot_subset_cannot_run_remaining_or_noncanonical_job(self):
        go,sha=fixture_go(self.preparation,['STATIC50_LOW'])
        a.validate_root_go(self.preparation,go,sha,config='STATIC50_LOW')
        with self.assertRaises(ValueError):a.validate_root_go(self.preparation,go,sha,config='STATIC50_MID')
        # Generated byte-exact groups: H090_LOW aliases STATIC50_LOW, so alias is not a canonical job.
        p=deepcopy(self.prep);p['execution_groups']=[['STATIC50_LOW','H090_LOW']]+p['execution_groups'][1:3]+p['execution_groups'][4:]
        prepraw=raw(p);go,sha=fixture_go(prepraw,['H090_LOW'])
        with self.assertRaises(ValueError):a.validate_root_go(prepraw,go,sha,config='H090_LOW')

    def test_other_year_resources_sources_cost_code_adapter_changes_fail(self):
        go,_=fixture_go(self.preparation);base=json.loads(go)
        changes=[('schema','ROOT_GO_FIXED_FINITE_FULL2023_GRID_V1'),('calendar',[a.START,a.END+a.g.DAY]),
            ('cost','STRESS43'),('other_years_authorized',True),('locked_or_holdout_consumed',True),
            ('original_interpolated_mark_execution_admitted',True),('source_identity','0'*64),
            ('code_identity',{}),('artifacts',{}),('mark_feed_adapter_version','ORIGINAL_INTERPOLATION'),
            ('mark_quality_guard_version','NONE'),('coldstart_policy',{'available_prior_source_used':True}),
            ('resource_limits',{**a.RESOURCE_LIMITS,'maximum_cases':10}),('permitted_configs',['STATIC50_LOW','STATIC50_LOW'])]
        for key,value in changes:
            body=raw({**base,key:value})
            with self.subTest(key=key),self.assertRaises(ValueError):a.validate_root_go(self.preparation,body,digest(body),config='STATIC50_LOW')

    def test_positive_constructor_boundary_returns_mock_and_installs_real_quality_guard(self):
        # Pure stand-ins only. No native account constructor is called.
        class FakeAccount:
            def execute_fill(self,*args,**kwargs):raise AssertionError('NO_FINANCIAL_FILL')
        class FakeSim:
            def __init__(self):self.account=FakeAccount();self.symbols=a.g.SYMBOLS;self.meta={}
            def inner_attempt(self,*args):raise AssertionError('NO_FINANCIAL_ATTEMPT')
        sim=FakeSim();guard=object.__new__(a.n.PartialTierGuard)
        guard.sim=sim;guard._installed=True;guard.original_attempt=sim.inner_attempt;sim.attempt=guard.attempt
        review,rs=fixture_review(self.preparation);go,sha=fixture_go(self.preparation,['STATIC50_LOW'],rs)
        with patch.object(a.n,'_construct_case',return_value=(sim,guard)) as construct, \
                patch.object(a.n,'runtime',side_effect=AssertionError('NO_FINANCIAL_RUNTIME')):
            result=a.make_annual_case(SOURCE,self.prepared,go,sha,config='STATIC50_LOW',
                review_raw=review,expected_review_sha256=rs)
        self.assertEqual(result,(sim,guard));self.assertEqual(construct.call_count,1)
        self.assertIsInstance(guard.original_attempt.__self__,a.q.CausalMarkQualityGuard)
        self.assertIs(guard.causal_mark_quality_guard,guard.original_attempt.__self__)
        self.assertNotIn('execute_fill',vars(sim.account))
        self.assertEqual(sim.meta['independent_review_SHA256'],rs)
        self.assertEqual(sim.meta['execution_label'],a.LABEL)
        self.assertFalse(sim.meta['initial_prior_source_used'])
        self.assertEqual(construct.call_args.args[3].shape,(366,5))

    def test_independent_review_is_required_before_source_or_account(self):
        go,sha=fixture_go(self.preparation)
        with patch.object(a,'_source',side_effect=AssertionError('NO_SOURCE')),patch.object(a.n,'_construct_case',side_effect=AssertionError('NO_ACCOUNT')):
            with self.assertRaisesRegex(ValueError,'REVIEW_HASH'):
                a.make_annual_case(SOURCE,self.prepared,go,sha,config='STATIC50_LOW')

    def test_review_hash_and_scope_changes_reject(self):
        review,rs=fixture_review(self.preparation);go,sha=fixture_go(self.preparation,review_sha=rs)
        a._validate_independent_review(self.preparation,self.prep,review,rs,go)
        for field,value in [('actual_2024_accounts_constructed',1),('original_interpolated_mark_execution_admitted',True),
                            ('source_identity','0'*64),('preparation_SHA256','0'*64),('mark_quality_guard_version','NONE')]:
            bad=raw({**json.loads(review),field:value});g,_=fixture_go(self.preparation,review_sha=digest(bad))
            with self.assertRaises(ValueError):a._validate_independent_review(self.preparation,self.prep,bad,digest(bad),g)
        with self.assertRaises(ValueError):a._validate_independent_review(self.preparation,self.prep,review,'0'*64,go)

    def test_preparation_artifact_tamper_fails_before_source_or_account(self):
        copied=Path(self.temp.name)/'tamper';shutil.copytree(self.prepared,copied)
        with (copied/'TARGETS.npz').open('ab') as out:out.write(b'GENERATED_TAMPER')
        go,sha=fixture_go(self.preparation)
        with patch.object(a,'_source',side_effect=AssertionError('NO_SOURCE')),patch.object(a.n,'_construct_case',side_effect=AssertionError('NO_ACCOUNT')):
            with self.assertRaisesRegex(ValueError,'EXACT_SOURCE_HASH'):
                a.validate_annual_inputs(SOURCE,copied,go,sha,config='STATIC50_LOW')

    def test_source_byte_tamper_fails_on_capture(self):
        original=Path.read_bytes
        def altered(path):
            body=original(path)
            return body+b'GENERATED_TAMPER' if path.name=='INITIAL_PRIOR_SOURCE.json' else body
        with patch.object(Path,'read_bytes',altered),self.assertRaisesRegex(ValueError,'EXACT_SOURCE_HASH'):
            a._source(SOURCE)

    def test_existing_output_directory_fails_without_rewrite(self):
        with self.assertRaisesRegex(ValueError,'EXCLUSIVE_NEW'):
            a.prepare_source_only(SOURCE,self.prepared)

    def test_general_historical_gate_stays_no_go(self):
        with self.assertRaises(RuntimeError):a.g.require_historical_execution()
        with self.assertRaises(ValueError):a.n.build_case({},[],[],[],tier_name='LOW')


if __name__=='__main__':unittest.main(verbosity=2)
