"""New exact-GO-only bounded serial controller for finite seen2023 jobs.

Importing this module does not create an account. Root supplies the separately
authorized GO bytes/hash; this controller does not manufacture authorization.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import resource
import subprocess
import sys
import threading
import time
import traceback
from io import BytesIO

HERE=Path(__file__).resolve().parent
LIMITS={'per_case_wall_seconds':600,'CPU_threads':1,'RSS_stop_bytes':2_000_000_000,
    'AS_bytes':4_000_000_000,'output_bytes':250_000_000,'maximum_cases':9}


def utc():return time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
def sha(raw):return hashlib.sha256(raw).hexdigest()
def save(path,value):
    with Path(path).open('x') as out:json.dump(value,out,indent=2,allow_nan=False);out.write('\n')
def own_bytes(path):return sum(p.stat().st_size for p in Path(path).rglob('*') if p.is_file())
def reporting_identity():return {name:sha((HERE/name).read_bytes()) for name in ('run_actual_2023.py','annual_reporting.py')}


def validate_controller_go(preparation,body,digest):
    import annual_entry_2023 as a
    if not isinstance(body,bytes) or sha(body)!=digest:raise ValueError('EXACT_EXTERNAL_CONTROLLER_ROOT_GO_REQUIRED')
    go=json.loads(body)
    if (go.get('resource_limits')!=LIMITS or go.get('controller_reporting_identity')!=reporting_identity()
            or go.get('serial_execution') is not True
            or not isinstance(go.get('permitted_configs'),list) or not go['permitted_configs']):
        raise ValueError('EXACT_SERIAL_CONTROLLER_AND_REPORTING_PIN_REQUIRED')
    for config in go['permitted_configs']:a.validate_root_go(preparation,body,digest,config=config)
    return go


def limits():
    for which,value in ((resource.RLIMIT_AS,LIMITS['AS_bytes']),
            (resource.RLIMIT_CPU,600),(resource.RLIMIT_RSS,LIMITS['RSS_stop_bytes'])):
        resource.setrlimit(which,(value,value))
    if hasattr(os,'sched_getaffinity'):os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})


def case(args):
    limits()
    for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','POLARS_MAX_THREADS'):
        os.environ[key]='1'
    import numpy as np
    import annual_entry_2023 as a
    import native_runtime as n
    import annual_reporting as report
    preparation=(Path(args.preparation)/'PREPARATION.json').read_bytes()
    go=Path(args.go).read_bytes();validate_controller_go(preparation,go,args.go_sha)
    out=Path(args.case_output);out.mkdir(exist_ok=False)
    began=time.monotonic();started=utc();stopped=threading.Event()
    def watch():
        while not stopped.wait(.05):
            rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024
            reason=('RSS_LIMIT' if rss>LIMITS['RSS_stop_bytes'] else
                'WALL_LIMIT' if time.monotonic()-began>600 else
                'OUTPUT_LIMIT' if own_bytes(out)>LIMITS['output_bytes'] else None)
            if reason:
                save(out/'RESOURCE_STOP.json',dict(reason=reason,UTC=utc(),RSS_bytes=rss))
                os._exit(137)
    threading.Thread(target=watch,daemon=True).start()
    try:
        sim,guard=a.make_annual_case(args.source,args.preparation,go,args.go_sha,config=args.config)
        construction=time.monotonic()-began;loop=time.monotonic()
        while sim.cursor<sim.end and sim.stop is None:
            sim.advance_day()
            print(json.dumps(dict(event='DAY_COMPLETE',config=args.config,UTC=utc(),
                completed_minutes=sim.rows_written,stop_us=sim.stop)),flush=True)
        loop_seconds=time.monotonic()-loop;result=n.case_result(sim,guard);owned=n.runtime()[4]
        data=result['minute'].to_numpy();columns=result['minute'].columns
        prep=json.loads(preparation);target_rec=prep['artifacts']['TARGETS.npz']
        target_bytes=a.h._read_exact(Path(args.preparation)/'TARGETS.npz',
            target_rec['SHA256'],target_rec['bytes'])
        with np.load(BytesIO(target_bytes),allow_pickle=False) as z:
            risk=report.risk_diagnostics(data,columns,z['decision_us'],z['annual_covariance'],
                z[args.config],guard.tier_name,guard.receipts)
        np.savez_compressed(out/'MINUTE.npz',values=data,columns=np.asarray(columns))
        save(out/'ACCOUNT_FINANCIAL_AUDIT_SNAPSHOT.json',sim.account.snapshot())
        save(out/'GUARD_RECEIPTS.json',guard.receipts)
        save(out/'NATIVE_REJECTIONS.json',owned.export_tree(sim.rejections))
        save(out/'FUNDING_JOURNAL.json',owned.export_tree(sim.funding_journal))
        save(out/'OBSERVED_RISK.json',risk)
        save(out/'RESULT.json',dict(config=args.config,summary=result['summary'],economics=result['economics'],
            common_execution_policy=result['common_execution_policy'],target_meta=result['target_meta']))
        receipt=dict(schema='FINITE_FULL2023_CASE_RECEIPT_V1',status='COMPLETED_NATIVE_PATH',
            config=args.config,start_UTC=started,end_UTC=utc(),PID=os.getpid(),
            construction_seconds=construction,native_loop_seconds=loop_seconds,
            total_wall_seconds=time.monotonic()-began,max_RSS_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,
            CPU_seconds=resource.getrusage(resource.RUSAGE_SELF).ru_utime+resource.getrusage(resource.RUSAGE_SELF).ru_stime,
            limits=LIMITS,observed_output_bytes=own_bytes(out),completed_minutes=sim.rows_written,
            required_minutes=525600,calendar=[a.START,a.END],account_stop_us=sim.stop,
            paid_comparison_eligible=result['economics']['paid_flat'],root_GO_SHA256=args.go_sha,
            preparation_SHA256=sha(preparation),code_identity=a.code_identity(),
            controller_reporting_identity=reporting_identity(),holdout_consumed=False,other_years_run=0)
        save(out/'CASE_RECEIPT.json',receipt)
        if not receipt['paid_comparison_eligible']:raise RuntimeError('INCOMPLETE_HALT_OR_RESIDUAL_NOT_ANNUAL_PAID_COMPARISON')
        print(json.dumps(dict(event='CASE_COMPLETE',config=args.config,UTC=utc(),wall_seconds=receipt['total_wall_seconds'])),flush=True)
    except BaseException as error:
        if 'sim' in locals():
            try:
                save(out/'FAILED_ACCOUNT_FINANCIAL_AUDIT_SNAPSHOT.json',sim.account.snapshot())
                save(out/'FAILED_GUARD_RECEIPTS.json',guard.receipts)
                save(out/'FAILED_PROGRESS.json',dict(completed_minutes=sim.rows_written,cursor_us=sim.cursor,
                    stop_us=sim.stop,policy_restart_certified=False))
            except BaseException as audit_error:
                save(out/'FAILED_PARTIAL_AUDIT_UNAVAILABLE.json',dict(error=repr(audit_error)))
        save(out/'CASE_FAILURE.json',dict(status='FAILED_NO_AUTOMATIC_RETRY',UTC=utc(),config=args.config,
            error=repr(error),traceback=traceback.format_exc(),wall_seconds=time.monotonic()-began))
        raise
    finally:stopped.set()


def controller(args):
    preparation=(Path(args.preparation)/'PREPARATION.json').read_bytes()
    body=Path(args.go).read_bytes();go=validate_controller_go(preparation,body,args.go_sha)
    out=Path(args.output);out.mkdir(exist_ok=False)
    (out/'ROOT_GO.json').write_bytes(body)
    started=utc();begin=time.monotonic()
    save(out/'CONTROLLER_START.json',dict(UTC=started,PID=os.getpid(),status='STARTED',
        permitted_configs=go['permitted_configs'],root_GO_SHA256=args.go_sha,limits=LIMITS))
    print(json.dumps(dict(event='CONTROLLER_STARTED',UTC=started,PID=os.getpid(),root_GO_SHA256=args.go_sha)),flush=True)
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',
        MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',POLARS_MAX_THREADS='1')
    statuses=[]
    for config in go['permitted_configs']:
        command=[sys.executable,str(Path(__file__).resolve()),'--case','--source',args.source,
            '--preparation',str(Path(args.preparation).resolve()),'--go',str((out/'ROOT_GO.json').resolve()),'--go-sha',args.go_sha,
            '--config',config,'--case-output',str((out/config).resolve())]
        command[command.index('--source')+1]=str(Path(args.source).resolve())
        with (out/(config+'.log')).open('x') as log:
            process=subprocess.Popen(command,cwd=HERE,env=env,stdout=log,stderr=subprocess.STDOUT,preexec_fn=limits)
            print(json.dumps(dict(event='ACTUAL_ANNUAL_CASE_STARTED',UTC=utc(),config=config,PID=process.pid)),flush=True)
            try:code=process.wait(timeout=600)
            except subprocess.TimeoutExpired:
                process.kill();process.wait();code=124
                save(out/(config+'_CONTROLLER_TIMEOUT.json'),dict(UTC=utc(),status='STOPPED_600S_WALL'))
        statuses.append(dict(config=config,PID=process.pid,exit_code=code))
        if code:
            save(out/'CONTROLLER_FAILURE.json',dict(status='STOPPED_NO_AUTOMATIC_RERUN',UTC=utc(),cases=statuses))
            raise RuntimeError('Annual case failed, retained, no retry: '+config)
    save(out/'CONTROLLER_RECEIPT.json',dict(status='ALL_APPROVED_CANONICAL_JOBS_TERMINAL',start_UTC=started,
        end_UTC=utc(),wall_seconds=time.monotonic()-begin,cases=statuses,root_GO_SHA256=args.go_sha,
        requested_matrix_cells=9,approved_job_count=len(statuses),holdout_consumed=False,other_years_run=0,
        total_output_bytes=own_bytes(out)))


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--case',action='store_true')
    for name in ('source','preparation','go','go-sha'):parser.add_argument('--'+name,required=True)
    for name in ('output','config','case-output'):parser.add_argument('--'+name)
    args=parser.parse_args();case(args) if args.case else controller(args)
