"""Independent data-free guard, bindings, strict D and resource contract tests."""
import os
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','POLARS_MAX_THREADS','VECLIB_MAXIMUM_THREADS'):os.environ[k]='1'
os.sched_setaffinity(0,{3})
import independent_io_guard as io_guard
import ast,builtins,json,resource,socket,subprocess,sys,tempfile,time,types,unittest
from copy import deepcopy
from hashlib import sha256
from pathlib import Path
from types import MappingProxyType,SimpleNamespace
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1];HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'traditional_D_full2025_20261015'))
import numpy as np
import polars as pl
import full_source as s
import full_entry as e
import source_projection as p
import source_guard as g
import run_full as r
import full_d as d
from test_native_runtime import fixture

GUARD_EVIDENCE=[]
def fake_binding_inputs():
    cell=dict(e.cell_descriptor(e.tranche_cells()[0]));dec=p.frozen_array(np.arange(s.START,s.END,s.DAY,dtype=np.int64))
    target=p.frozen_array(np.full((365,5),.01));cov=p.frozen_array(np.repeat(np.eye(5)[None,:,:],365,axis=0))
    cell['selected_target_raw_SHA256']=s.sha(target.tobytes())
    rows=(MappingProxyType(dict(symbol='GENERATED_FAKE',close_us=1,available_us=1,close=1.)),)
    window=MappingProxyType(dict(start=s.START,end=s.END,symbols=s.S,daily=pl.DataFrame([dict(fake=1)]),events=(),
        minute_blocks=s.CapturedMinuteProvider(2025,()),derived_mark_cells=0,original_missing_mark_open_ms=(),
        original_overlay_future_looking=False,original_overlay_execution_admitted=False,causal_mark_adapter=s.immutable(dict(cells=[],fixture='GENERATED_FAKE_ONLY'))))
    return cell,window,rows,dec,target,cov

class Boundaries(unittest.TestCase):
    def test_cold_code_identity_opens_no_legacy_authority_or_source_bodies(self):
        identity=e.code_identity();self.assertGreater(len(identity),50)
        for name,value in e.preserved_evidence_identity().items():
            self.assertIn('evidence_only',name);s.digest(value)
        self.assertFalse(e._policy(identity)['old_GO_private_runtime_bodies_required'])
        self.assertFalse(e._policy(identity)['old_GO_is_new_authority'])
        self.assertFalse(any(Path(name).suffix.lower() in ('.npz','.zip') or ('GO' in Path(name).name.upper() and Path(name).suffix=='.json') for name in identity))
        pins=json.loads((e.HERE/'DEPENDENCY_PINS.json').read_bytes())
        self.assertFalse(any(('GO' in Path(name).name.upper() and Path(name).suffix=='.json') for name in pins))
        self.assertFalse(io_guard.DENIED)

    def test_exact_input_references_mutability_finiteness_calendar_and_hash_swaps(self):
        c,w,rows,dec,target,cov=fake_binding_inputs();base=e._input_binding(c,w,rows,dec,target,cov)
        for args in ((dict(w),rows,dec,target,cov),(w,tuple(dict(x) for x in rows),dec,target,cov),(w,rows,dec.copy(),target,cov),(w,rows,dec,target.copy(),cov),(w,rows,dec,target,cov.copy())):
            with self.assertRaises(ValueError):e._input_binding(c,*args)
        for value in (np.nan,np.inf):
            bad=np.array(cov);bad[0,0,0]=value;bad=p.frozen_array(bad)
            with self.assertRaises(ValueError):e._input_binding(c,w,rows,dec,target,bad)
        swapped=np.array(target);swapped[0,0]+=.001
        with self.assertRaises(ValueError):e._input_binding(c,w,rows,dec,p.frozen_array(swapped),cov)
        for changes in ({'start':s.START+s.MINUTE},{'symbols':tuple(reversed(s.S))},{'minute_blocks':s.CapturedMinuteProvider(2024,())}):
            bad=MappingProxyType(dict(w,**changes))
            with self.assertRaises(ValueError):e._input_binding(c,bad,rows,dec,target,cov)
        for changes in ({'events':(MappingProxyType(dict(generated_funding='SWAPPED')),)} ,{'causal_mark_adapter':s.immutable(dict(cells=[],fixture='SWAPPED'))}):
            self.assertNotEqual(s.jsha(base),s.jsha(e._input_binding(c,MappingProxyType(dict(w,**changes)),rows,dec,target,cov)))

    def test_all_twelve_source_guard_categories_fatal_and_restored(self):
        module=types.ModuleType('_independent_obvious_generated_boundary');module.__source_guard_fixture__=True
        noop=lambda *args,**kwargs:None
        module.GeneratedAccount=type('GeneratedAccount',(),{'__init__':noop,'update_marks':noop})
        module.GeneratedSimulator=type('GeneratedSimulator',(),{'__init__':noop})
        module.FreshHistoricalExecutionScope=type('FreshHistoricalExecutionScope',(),{'__init__':noop})
        module.GeneratedProvider=type('GeneratedProvider',(),{'__call__':noop})
        account=module.GeneratedAccount();provider=module.GeneratedProvider();sys.modules[module.__name__]=module
        try:
            with tempfile.TemporaryDirectory(prefix='GENERATED_INDEPENDENT_',dir=HERE) as td:
                root=Path(td);out=root/'output';out.mkdir();unlisted=root/'unlisted.txt';unlisted.write_text('OBVIOUS_FAKE_ONLY')
                actions=dict(financial_constructors=lambda:module.GeneratedAccount(),financial_account_advance=lambda:account.update_marks(),
                    native_simulator_construct_or_advance=lambda:module.GeneratedSimulator(),historical_scope_mints=lambda:module.FreshHistoricalExecutionScope(),
                    actual_provider_calls=lambda:provider(),process_launches=lambda:subprocess.Popen(['NEVER_EXECUTED_GENERATED']),
                    network_calls=lambda:socket.create_connection(('NEVER.invalid',1)),
                    canonical_financial_claims_or_leases=lambda:(out/'EXECUTION_CLAIMS').mkdir(),
                    financial_GO_writes=lambda:json.dumps(dict(schema='ROOT_GO_GENERATED',historical_execution_authorized=True)),
                    financial_imports=lambda:builtins.__import__('full_d'),outside_source_writes=lambda:(root/'outside.txt').write_text('NEVER'),
                    nonallowlisted_file_reads=lambda:unlisted.read_text())
                self.assertEqual(set(actions),set(g.SourceOnlyGuard.CATEGORIES))
                for category,action in actions.items():
                    guard=g.SourceOnlyGuard(write_roots=(out,))
                    with self.subTest(category=category),self.assertRaisesRegex(g.SourceBoundaryViolation,'FATAL_EVEN_IF_CAUGHT'):
                        with guard:
                            with self.assertRaisesRegex(g.SourceBoundaryViolation,'SOURCE_ONLY_FORBIDDEN:'+category):action()
                            self.assertEqual(guard.attempts[category],1)
                    self.assertEqual(sum(guard.attempts.values()),1);self.assertFalse(guard.active);self.assertIsNone(g.current_guard())
                    GUARD_EVIDENCE.append(guard.receipt('EXPECTED_GENERATED_NEGATIVE'))
                self.assertFalse((root/'outside.txt').exists());self.assertFalse((out/'EXECUTION_CLAIMS').exists())
        finally:sys.modules.pop(module.__name__,None)

    def test_safe_nine_fake_recording_callbacks_observed_zero_and_revoked(self):
        prep=dict(cells={cell:dict(input_binding_SHA256='a'*64) for cell in e.tranche_cells()});held=[]
        paths=[e.HERE/'FROZEN_NINE_CELL_MANIFEST.json',HERE/'review_generated_boundaries.py']
        guard=g.SourceOnlyGuard(read_paths=paths)
        def callback(scope,metadata):scope.validate_current();held.append(scope);return metadata
        with guard:
            record=e._record_metadata_cells(prep,'b'*64,callback,domain='GENERATED_FAKE_METADATA')
            guard.checkpoint('NINE_FAKE_SCOPES_REVOKED')
        self.assertEqual(record['recording_scopes_created'],9);self.assertEqual(record['recording_scopes_revoked'],9)
        self.assertFalse(e._METADATA_ACTIVE);self.assertFalse(s._ACTIVE_SOURCE);self.assertFalse(any(guard.attempts.values()))
        for scope in held:
            with self.assertRaises(ValueError):scope.validate_current()
        GUARD_EVIDENCE.append(guard.receipt('PASS_ZERO_FORBIDDEN_GENERATED_METADATA_ONLY'))

    def test_resource_lease_claim_scheduler_reporting_inherited_AST_exact(self):
        old=ast.parse((ROOT/'traditional_D_full2022_20261015_v2/run_full.py').read_text());new=ast.parse((e.HERE/'run_full.py').read_text())
        class Year(ast.NodeTransformer):
            def visit_Constant(self,node):
                if isinstance(node.value,str):node.value=node.value.replace('2022','2025')
                return node
        names=('apply_limits','process_observation','host_observation','choose_worker_count','confine_existing_threads','cpu_envelope','run_pool','_run_pool','claim_launch','controller_lease','validate_worker_claim','held_risk_report','validate_saved_risk_report')
        for name in names:
            before=next(x for x in old.body if isinstance(x,ast.FunctionDef) and x.name==name);after=next(x for x in new.body if isinstance(x,ast.FunctionDef) and x.name==name)
            with self.subTest(function=name):self.assertEqual(ast.dump(Year().visit(before)),ast.dump(after))
        self.assertEqual(r.LIMITS,dict(maximum_live_workers=2,threads_per_worker=1,per_case_wall_seconds=600,per_case_CPU_seconds=600,
            per_case_RSS_stop_bytes=2000000000,per_case_AS_bytes=4000000000,per_case_output_bytes=250000000,aggregate_live_worker_RSS_stop_bytes=3500000000))
        host=dict(allowed_CPUs=[4,5],MemAvailable_bytes=6000000000,cgroup_observations={})
        self.assertEqual(r.choose_worker_count(2,[4,5],host),2);host['MemAvailable_bytes']=3000000000;self.assertEqual(r.choose_worker_count(2,[4,5],host),1)
        host['MemAvailable_bytes']=1
        with self.assertRaises(RuntimeError):r.choose_worker_count(1,[4],host)
        for n,cpus in ((3,[3,4,5]),(2,[4,4]),(True,[4]),(2,[True,5])):
            with self.assertRaises(ValueError):r.choose_worker_count(n,cpus,host)

    def test_defining_D_resealed_zero_ids_strict_bools_actions_and_policy(self):
        window,rows,decisions=fixture(1);sim,guard=d.construct_case(window,rows,decisions,np.full((1,5),.03),generated_scope=d.GENERATED)
        while sim.cursor<sim.end and sim.stop is None:sim.advance_day()
        audit=d.V2.OWNED.export_tree(sim.account.snapshot());result=d.case_result(sim,guard)
        self.assertTrue(r.validate_defining_D(audit,result))
        mutations=[lambda a,z:a.__setitem__('transfer_journal',[{}]),lambda a,z:a.__setitem__('transfer_ids',{'FORGED':{}}),
            lambda a,z:a['contract'].__setitem__('topup_enabled',0),lambda a,z:a['contract'].__setitem__('topup_enabled',True),
            lambda a,z:a['contract'].__setitem__('policy_enabled',1),lambda a,z:a['contract'].__setitem__('policy_variant','TOPUP_THEN_CONTINUE'),
            lambda a,z:z['common_execution_policy'].__setitem__('automatic_topup',0),lambda a,z:z['common_execution_policy'].__setitem__('version','OTHER'),
            lambda a,z:a.__setitem__('monitor_journal',[dict(actions=[dict(transferred='1',reason='GUARD50_PAID_EXIT_NO_TOPUP',full_actual_position_exit_required=True)])]),
            lambda a,z:a.__setitem__('monitor_journal',[dict(actions=[dict(transferred='0',reason='GUARD50_PAID_EXIT_NO_TOPUP',full_actual_position_exit_required=1)])])]
        for index,mutate in enumerate(mutations):
            a,z=deepcopy(audit),deepcopy(result);mutate(a,z)
            with self.subTest(case=index),self.assertRaises(ValueError):r.validate_defining_D(a,z)

    def test_all_tier_fake_held_exposure_and_forecast_overshoot_nonvacuous(self):
        columns=['close_us','nav','free_cash','isolated_balance','gross_weight']+[symbol+'_signed_weight' for symbol in s.S]
        weights=np.array([[.01,0,0,0,0],[.06,-.02,0,0,0],[.11,.03,0,0,0],[-.16,.04,0,0,0],[.3,-.1,.02,0,0],[-.4,.2,0,-.03,.01]])
        values=np.column_stack((np.arange(1,7)*s.MINUTE,np.arange(10000,10006),np.full(6,900.),np.full(6,8600.),np.abs(weights).sum(axis=1),weights))
        decisions=np.array([0],dtype=np.int64);cov=np.array([np.eye(5)]);targets=np.full((1,5),.2)
        forecast=np.sqrt((weights**2).sum(axis=1));counts=[]
        import annual_reporting
        for tier in ('LOW','MID','HIGH'):
            report=r.held_risk_report(values,columns,decisions,cov,targets,tier,[dict(allowed=False,reason='CASH_LIMIT',fraction='.5')])
            budget=annual_reporting.g.tier_named(tier).annual_vol_target
            count=int(np.sum(forecast-budget>annual_reporting.BREACH_NUMERICAL_TOLERANCE));counts.append(count)
            self.assertEqual(report['forecast_volatility_breach_minutes'],count)
            self.assertEqual(report['forecast_annual_volatility_max'],float(forecast.max()))
            self.assertEqual(report['actual_signed_weight_min_by_symbol']['BTCUSDT'],-.4)
            self.assertEqual(report['actual_absolute_weight_max_by_symbol']['ETHUSDT'],.2)
            self.assertEqual(report['minutes_observed_free_cash_below1000'],6)
            self.assertEqual(report['minutes_observed_margin_above8500'],6)
            self.assertTrue(report['nominal_tier_equality_is_not_exact_realized_risk_matching'])
        self.assertEqual(counts,[5,4,3])

if __name__=='__main__':
    began=time.monotonic();result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Boundaries))
    record=dict(schema='INDEPENDENT_FULL2025_GENERATED_BOUNDARY_REVIEW_V1',status='PASS_GENERATED_ONLY' if result.wasSuccessful() else 'FAIL',tests_run=result.testsRun,
        failures=len(result.failures),errors=len(result.errors),guard_observations=GUARD_EVIDENCE,
        code_files={name:sha256((e.HERE/name).read_bytes()).hexdigest() for name in ('full_source.py','full_entry.py','full_d.py','source_projection.py','source_guard.py','run_full.py','prepare_source.py')},
        audited_workspace_read_paths=sorted(set(io_guard.READS)),forbidden_read_or_process_attempts=io_guard.DENIED,
        actual_source_body_reads=0,actual_targets_generated=0,actual_source_scopes=0,historical_scopes=0,actual_accounts=0,actual_provider_iterations=0,process_launches=0,financial_claims=0,financial_GO_writes=0,
        CPU_affinity=sorted(os.sched_getaffinity(0)),task_affinities={x.name:sorted(os.sched_getaffinity(int(x.name))) for x in Path('/proc/self/task').iterdir()},wall_seconds=time.monotonic()-began,
        max_RSS_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,script_SHA256=sha256(Path(__file__).read_bytes()).hexdigest())
    with (HERE/os.environ.get('REVIEW_RECEIPT','GENERATED_BOUNDARIES_CHECKPOINT001.json')).open('x') as stream:json.dump(record,stream,indent=2,sort_keys=True);stream.write('\n')
    raise SystemExit(not result.wasSuccessful())
