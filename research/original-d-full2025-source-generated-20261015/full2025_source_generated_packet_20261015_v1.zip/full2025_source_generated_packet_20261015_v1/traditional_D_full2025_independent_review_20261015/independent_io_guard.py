"""Audit evidence for a strictly generated/static independent review process."""
import os,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
READS=[];DENIED=[]
def audit(event,args):
    if event in ('subprocess.Popen','os.system','os.fork','os.posix_spawn','socket.connect','socket.getaddrinfo'):
        DENIED.append(dict(event=event));raise AssertionError('GENERATED_REVIEW_PROCESS_NETWORK_FORBIDDEN')
    if event!='open' or not isinstance(args[0],(str,bytes,os.PathLike)):return
    path=Path(os.fsdecode(args[0]));mode=args[1]
    writing=isinstance(mode,str) and any(x in mode for x in 'wax+')
    text=str(path);name=path.name.upper()
    obvious_fake=any(x in text for x in ('/tmp/generated_risk_review_','/tmp/obvious_fake_','/tmp/GENERATED_'))
    if writing:return
    banned=(path.suffix.lower() in ('.npz','.zip') and not obvious_fake
        or (path.suffix.lower()=='.json' and ('GO' in name or name=='ADMISSION_REVIEW.JSON') and not obvious_fake)
        or '/qualified_source_only_pending_review/' in text
        or '/native_2024_source_restore_20261015/' in text)
    if banned:
        DENIED.append(dict(event=event,path=text));raise AssertionError('ACTUAL_SOURCE_OR_LEGACY_AUTHORITY_BODY_FORBIDDEN:'+text)
    if path.is_absolute() and path.is_relative_to(ROOT):READS.append(str(path.relative_to(ROOT)))
sys.addaudithook(audit)
