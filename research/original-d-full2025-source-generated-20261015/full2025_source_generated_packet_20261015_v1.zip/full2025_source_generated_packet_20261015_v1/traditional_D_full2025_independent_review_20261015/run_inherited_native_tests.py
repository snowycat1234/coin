"""Source-free reuse of exact frozen D and native40 generated tests."""
import os
for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','POLARS_MAX_THREADS','VECLIB_MAXIMUM_THREADS'):
    os.environ[key]='1'
os.sched_setaffinity(0,{3})
import json,resource,sys,time,unittest
from pathlib import Path
from hashlib import sha256
ROOT=Path(__file__).resolve().parents[1];HERE=Path(__file__).resolve().parent
READS=[];DENIED=[]
def audit(event,args):
    if event in ('subprocess.Popen','os.system','os.fork','os.posix_spawn','socket.connect','socket.getaddrinfo'):
        DENIED.append({'event':event});raise AssertionError('GENERATED_REVIEW_PROCESS_NETWORK_FORBIDDEN')
    if event!='open' or not isinstance(args[0],(str,bytes,os.PathLike)):return
    path=Path(os.fsdecode(args[0]));mode=args[1]
    if isinstance(mode,str) and any(x in mode for x in 'wax+'):return
    if path.suffix.lower() in ('.npz','.zip') or (path.suffix.lower()=='.json' and ('GO' in path.name.upper() or path.name.upper()=='ADMISSION_REVIEW.JSON')):
        DENIED.append({'event':event,'path':str(path)});raise AssertionError('ACTUAL_DATA_OR_LEGACY_AUTHORITY_BODY_FORBIDDEN:'+str(path))
    if path.is_relative_to(ROOT):READS.append(str(path.relative_to(ROOT)))
sys.addaudithook(audit)
for name in ('traditional_three_tier_freeze_20261015','bounded_native_continuation_guard50_exit_20261015','bounded_native_continuation_guard50_exit_expansion_20261015'):
    sys.path.insert(0,str(ROOT/name))
import test_guard50_exit
import test_saved_native_reconciliation
began=time.monotonic()
suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromModule(m) for m in (test_guard50_exit,test_saved_native_reconciliation))
result=unittest.TextTestRunner(verbosity=2).run(suite)
files=[ROOT/'bounded_native_continuation_guard50_exit_20261015/test_guard50_exit.py',ROOT/'bounded_native_continuation_guard50_exit_expansion_20261015/test_saved_native_reconciliation.py']
record=dict(schema='INDEPENDENT_FROZEN_D_NATIVE_GENERATED_REUSE_V1',status='PASS_GENERATED_ONLY' if result.wasSuccessful() and not DENIED else 'FAIL',
    tests_run=result.testsRun,failures=len(result.failures),errors=len(result.errors),
    inherited_tests={str(p.relative_to(ROOT)):dict(SHA256=sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size) for p in files},
    observed_workspace_read_paths=sorted(set(READS)),forbidden_read_or_process_attempts=DENIED,
    fixture_scope='GENERATED_FAKE_ORIGIN_ONLY',actual_source_body_reads=0,historical_scopes_minted=0,actual_accounts_constructed=0,
    actual_provider_iterations=0,process_launches=0,financial_GO_writes=0,publication_actions=0,
    CPU_affinity=sorted(os.sched_getaffinity(0)),all_task_affinities={p.name:sorted(os.sched_getaffinity(int(p.name))) for p in Path('/proc/self/task').iterdir()},
    numerical_thread_environment={key:os.environ[key] for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','POLARS_MAX_THREADS','VECLIB_MAXIMUM_THREADS')},
    wall_seconds=time.monotonic()-began,max_RSS_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,
    script_SHA256=sha256(Path(__file__).read_bytes()).hexdigest())
with (HERE/os.environ.get('REVIEW_RECEIPT','INHERITED_NATIVE_TEST_RECEIPT.json')).open('x') as stream:json.dump(record,stream,indent=2,sort_keys=True);stream.write('\n')
raise SystemExit(not result.wasSuccessful() or bool(DENIED))
