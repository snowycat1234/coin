"""Honest generated paid, conditional, native debt HALT and ACTIVE-partial taxonomy."""
import os
for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','POLARS_MAX_THREADS','VECLIB_MAXIMUM_THREADS'):os.environ[key]='1'
os.sched_setaffinity(0,{3})
import independent_io_guard as io_guard
import json,sys,time,unittest
from copy import deepcopy
from hashlib import sha256
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'traditional_D_full2025_20261015'))
import numpy as np
import full_d as d
import run_full as r
from test_native_runtime import fixture
from saved_native_reconciliation import reconcile_saved_native
EVIDENCE=[]
def run(kind):
    w,rows,decisions=fixture(1)
    if kind=='CONDITIONAL':w['market']['BTCUSDT']['mark'][10:]=100000.
    if kind=='DEBT_HALT':
        for event in w['events']:event['raw_rate']=-1000.
    targets=np.full((1,5),-.03 if kind in ('CONDITIONAL','DEBT_HALT') else .03)
    sim,guard=d.construct_case(w,rows,decisions,targets,generated_scope=d.GENERATED)
    while sim.cursor<sim.end and sim.stop is None:sim.advance_day()
    audit=d.V2.OWNED.export_tree(sim.account.snapshot());result=d.case_result(sim,guard)
    export=d.V2.OWNED.export_tree(dict(result,minute=None,targets=result['targets'].to_dicts()))
    export.pop('minute')
    proof=reconcile_saved_native(audit,export,expected_continuation_version=d.VERSION)
    assert proof['passed'] and not proof['tolerance_or_epsilon_used']
    return sim,audit,result

class Taxonomy(unittest.TestCase):
    def test_actual_paid_market_flat_generated_calendar(self):
        sim,audit,result=run('PAID')
        status=r.classify_terminal(audit,result,calendar=[sim.start,sim.end],completed_minutes=sim.rows_written,stop_us=sim.stop)
        self.assertEqual(status,'FULL_CALENDAR_ACTUAL_PAID_MARKET_FLAT');self.assertTrue(result['economics']['paid_flat'])
        self.assertTrue(audit['trades']);self.assertFalse(audit['settlement_journal'])
        EVIDENCE.append(dict(case='GENERATED_PAID',status=status,paid_trade_rows=len(audit['trades'])))

    def test_conditional_forfeiture_full_calendar_never_paid_flat(self):
        sim,audit,result=run('CONDITIONAL')
        self.assertTrue(audit['settlement_journal']);self.assertIsNone(sim.stop)
        status=r.classify_terminal(audit,result,calendar=[sim.start,sim.end],completed_minutes=sim.rows_written,stop_us=sim.stop)
        self.assertEqual(status,'FULL_CALENDAR_CONDITIONAL_SETTLED_FLAT')
        self.assertFalse(result['economics']['paid_flat']);self.assertIsNone(result['economics']['paid_net_return'])
        self.assertIsNotNone(result['economics']['conditional_model_net_return'])
        for field in ('paid_flat','actual_paid_market_flat'):
            bad=deepcopy(result);bad['economics'][field]=True
            with self.assertRaises(ValueError):r.classify_terminal(audit,bad,calendar=[sim.start,sim.end],completed_minutes=sim.rows_written,stop_us=sim.stop)
        EVIDENCE.append(dict(case='GENERATED_CONDITIONAL',status=status,settlement_rows=len(audit['settlement_journal'])))

    def test_honest_native_debt_halt_is_partial_and_not_paid_or_conditional(self):
        sim,audit,result=run('DEBT_HALT')
        self.assertEqual(audit['status'],'BANKRUPT_HALT');self.assertGreater(float(audit['unpaid_liability']),0);self.assertIsNotNone(sim.stop)
        status=r.classify_terminal(audit,result,calendar=[sim.start,sim.end],completed_minutes=sim.rows_written,stop_us=sim.stop)
        self.assertEqual(status,'NATIVE_HALT_PARTIAL_CALENDAR')
        self.assertIsNone(result['economics']['paid_net_return']);self.assertIsNone(result['economics']['conditional_model_net_return'])
        EVIDENCE.append(dict(case='GENERATED_REAL_NATIVE_DEBT',status=status,completed_minutes=sim.rows_written,unpaid_liability=audit['unpaid_liability']))

    def test_active_partial_and_fabricated_positive_cash_bankruptcy_fail_closed(self):
        sim,audit,result=run('PAID');partial=deepcopy(result)
        partial['summary'].update(completed_minutes=1439,stop_us=None)
        partial['economics'].update(full_calendar=False,paid_flat=False,actual_paid_market_flat=False,conditional_settled_flat=False,
            comparable_full_calendar_return=None,paid_net_return=None,conditional_model_net_return=None)
        with self.assertRaisesRegex(ValueError,'INCOMPLETE_EXECUTION_IS_NOT_ECONOMIC_HALT'):
            r.classify_terminal(audit,partial,calendar=[sim.start,sim.end],completed_minutes=1439,stop_us=None)
        fake=deepcopy(audit);fake.update(status='BANKRUPT_HALT',clock_us=sim.end,halt_witness=dict(event_us=sim.end,
            decimal_strings=dict(NAV=result['summary']['decimal_strings']['NAV'],unpaid_liability='0')))
        partial['summary']['stop_us']=sim.end
        with self.assertRaisesRegex(ValueError,'EXACT_NATIVE_GLOBAL_BANKRUPTCY_PREDICATE'):
            r.classify_terminal(fake,partial,calendar=[sim.start,sim.end],completed_minutes=1439,stop_us=sim.end)

if __name__=='__main__':
    began=time.monotonic();result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Taxonomy))
    record=dict(schema='INDEPENDENT_FULL2025_GENERATED_TERMINAL_TAXONOMY_V1',status='PASS_GENERATED_ONLY' if result.wasSuccessful() else 'FAIL',
        tests_run=result.testsRun,failures=len(result.failures),errors=len(result.errors),evidence=EVIDENCE,code_files={name:sha256((d.HERE/name).read_bytes()).hexdigest() for name in ('full_d.py','run_full.py')},
        actual_source_body_reads=0,actual_accounts_constructed=0,actual_provider_iterations=0,historical_scopes=0,financial_GO_written=0,
        audited_workspace_read_paths=sorted(set(io_guard.READS)),forbidden_read_or_process_attempts=io_guard.DENIED,CPU_affinity=sorted(os.sched_getaffinity(0)),wall_seconds=time.monotonic()-began,
        script_SHA256=sha256(Path(__file__).read_bytes()).hexdigest())
    with (HERE/'GENERATED_TERMINAL_TAXONOMY.json').open('x') as stream:json.dump(record,stream,indent=2,sort_keys=True);stream.write('\n')
    raise SystemExit(not result.wasSuccessful())
