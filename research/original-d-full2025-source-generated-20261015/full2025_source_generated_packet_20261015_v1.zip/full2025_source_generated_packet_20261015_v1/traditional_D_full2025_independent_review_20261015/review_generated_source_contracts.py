"""Independent generated-only exact source/target and closed admission review."""
import os
for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','POLARS_MAX_THREADS','VECLIB_MAXIMUM_THREADS'):os.environ[key]='1'
os.sched_setaffinity(0,{3})
import independent_io_guard as io_guard
import ast,json,resource,sys,tempfile,time,unittest,zipfile
from copy import deepcopy
from dataclasses import replace
from hashlib import sha256
from io import BytesIO
from pathlib import Path
from types import MappingProxyType
from unittest.mock import Mock,patch
ROOT=Path(__file__).resolve().parents[1];HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'traditional_D_full2025_20261015'))
import numpy as np
import polars as pl
import full_source as s
import full_entry as e
import source_projection as p

def npz(**arrays):
    out=BytesIO();np.savez_compressed(out,**arrays);return out.getvalue()
def fake_daily():
    clocks=np.arange(s.START-199*s.DAY,s.END,s.DAY,dtype=np.int64)
    index=np.arange(len(clocks),dtype=np.float64)
    close=np.column_stack([(j+1)*100*(1+.0004*index+.003*np.sin(index/(7+j))) for j in range(5)])
    warm=npz(close_available_us=clocks[:200],close=close[:200])
    rows=[dict(symbol=symbol,close_us=int(at),close=float(close[i,j])) for i,at in enumerate(clocks) if at>=s.START for j,symbol in enumerate(s.S)]
    return warm,s.canonical(rows),clocks,close,rows
def fake_month(count=7):
    start=978307200000000
    a=dict(times=start+np.arange(count,dtype=np.int64)*s.MINUTE)
    for symbol in s.S:
        for name in ('open','close','mark','quote_volume'):a[symbol+'_'+name]=np.full(count,1.25,dtype=np.float64)
    return start,a

class SourceContracts(unittest.TestCase):
    def test_final_audit_metadata_and_exact_qualification_type_closure(self):
        self.assertEqual(s.SOURCE_INDEPENDENT_REVIEW_SHA256,'ed38099a903e003db750015f38cd92db0fccd2d090d96ca910f06144f90f8ee1')
        raw=(ROOT/'full2025_qualified_source_v2_independent_review_20261015/REVIEW.json').read_bytes()
        self.assertEqual(sha256(raw).hexdigest(),s.SOURCE_INDEPENDENT_REVIEW_SHA256)
        review=json.loads(raw);self.assertEqual(review['status'],'PASS_SOURCE_ONLY_NO_FINANCIAL_GO')
        self.assertEqual((review['PASS_count'],review['FAIL_count']),(12,0))
        m=deepcopy(s.metadata_pins()['source_qualification']);q=s.SourceQualificationBinding.validate(m)
        self.assertEqual(q.source_identity,s.jsha(m['canonical_source_files']))
        self.assertFalse(s._ACTIVE_SOURCE)
        for key in m:
            bad=deepcopy(m);del bad[key]
            with self.subTest(missing=key),self.assertRaises(ValueError):s.SourceQualificationBinding.validate(bad)
        for key,val in m.items():
            if type(val) not in (int,bool):continue
            bad=deepcopy(m);bad[key]=bool(val) if type(val) is int else int(val)
            with self.subTest(type_changed=key),self.assertRaises(ValueError):s.SourceQualificationBinding.validate(bad)
        bad=deepcopy(m);bad['canonical_source_files'][0]['bytes']=True
        with self.assertRaises(ValueError):s.SourceQualificationBinding.validate(bad)

    def test_import_and_unauthorized_actual_paths_cannot_open_or_callback(self):
        forbidden=Mock(side_effect=AssertionError('NO_ACTUAL_BODY_CALLBACK_OR_SCOPE'))
        with patch.object(s,'exact',forbidden),patch.object(np,'load',forbidden):
            for action in (lambda:s.project('/NONEXISTENT_GENERATED'),lambda:p.project('/NONEXISTENT_GENERATED'),
                lambda:p.capture('/NONEXISTENT_GENERATED',source_authorization_raw=None,expected_source_authorization_sha256=None),
                lambda:s.admit_actual_source_stage(b'{}',b'{}',None),
                lambda:e.prepare_source_only({2025:'/NONEXISTENT_GENERATED'},'/tmp/UNAUTHORIZED_NEVER_CREATED'),
                lambda:e.record_source_metadata_callbacks('/NONEXISTENT_GENERATED',b'{}',None,callback=forbidden)):
                with self.assertRaises(ValueError):action()
            forbidden.assert_not_called()
        self.assertFalse(s._ACTIVE_SOURCE)
        for forged in (None,object(),'GENERATED_FAKE_ORIGIN_ONLY',True):
            provider=s.CapturedMinuteProvider(2025,())
            with self.assertRaises(ValueError):provider._bind_historical_scope(forged)
            with patch.object(p,'month_arrays',forbidden):
                with self.assertRaisesRegex(ValueError,'SEPARATE_ROOT_GO'):next(provider())

    def test_nine_exact_cells_policy_source_and_fresh_wallet_boundaries(self):
        m=e.frozen_manifest();self.assertEqual(m['years'],[2025]);self.assertEqual(m['alias_mapping'],{})
        self.assertEqual(len(m['cells']),9);self.assertEqual(m['unique_execution_jobs'],9)
        expected=['2025_'+c+'_JAN1_DEC31_D' for c in s.CONFIGS]
        self.assertEqual(list(e.tranche_cells()),expected)
        for c in m['cells']:
            self.assertEqual(c['calendar'],[s.START,s.END]);self.assertEqual(c['required_minutes'],525600)
            self.assertEqual(c['cost'],'BASE27');self.assertEqual(c['days'],365)
        policy=e._policy({'OBVIOUS_GENERATED_METADATA':'1'*64})
        for key in ('all_years_seen_development','fresh_genesis_only','D_has_no_topup_or_internal_margin_transfer','native40_chronological_reconstruction_authoritative','raw100_delta_residual_preserved'):
            self.assertIs(policy[key],True)
        self.assertEqual(policy['initial_shared_wallet_USDT'],'10000')
        self.assertEqual(policy['terminal_signal_us'],s.END-61*s.MINUTE)
        self.assertEqual(policy['coldstart']['earliest_initial_increase_admission_us'],s.START+s.MINUTE+1)
        self.assertFalse(policy['publication_authorized']);self.assertFalse(policy['locked_or_holdout_consumed'])

    def test_fake_month_namespace_clocks_finite_quality_and_cache_immutability(self):
        start,a=fake_month();raw=npz(**a);out,missing=p.month_arrays(raw,start,7,())
        self.assertEqual(missing,());self.assertIsInstance(out,MappingProxyType)
        self.assertEqual(out['BTCUSDT_close'].tobytes(),a['BTCUSDT_close'].tobytes())
        for value in out.values():
            self.assertFalse(value.flags.writeable)
            with self.assertRaises(ValueError):value.setflags(write=True)
        self.assertIs(p.month_arrays(raw,start,7,())[0],out)
        for key,value in (('times',a['times'].astype(float)),('times',a['times']+1),('BTCUSDT_open',np.zeros(7)),('BTCUSDT_mark',np.full(7,np.nan)),('BTCUSDT_quote_volume',np.full(7,-1.))):
            changed=dict(a);changed[key]=value
            with self.subTest(field=key),self.assertRaises(ValueError):p.month_arrays(npz(**changed),start,7,())
        changed=dict(a);changed['available_us']=a['times']+s.MINUTE
        with self.assertRaises(ValueError):p.month_arrays(npz(**changed),start,7,())
        with self.assertRaises(ValueError):p.month_arrays(raw,start,7,(object(),))

    def test_fake_numeric_headers_fail_before_numpy_allocation(self):
        def archive(shape=(1,),descr='<f8',fortran=False,payload=b'\0'*8):
            stream=BytesIO();np.lib.format.write_array_header_1_0(stream,dict(descr=descr,fortran_order=fortran,shape=shape));stream.write(payload)
            out=BytesIO()
            with zipfile.ZipFile(out,'w') as z:z.writestr('x.npy',stream.getvalue())
            return out.getvalue()
        self.assertEqual(p.numeric_archive(archive(),{'x':(1,)},{'x':'float64'})['x'].tobytes(),b'\0'*8)
        for raw in (archive(shape=(2**40,)),archive(descr='|O'),archive(fortran=True),archive(payload=b''),archive(descr='<f4')):
            with patch.object(np,'load',side_effect=AssertionError('ALLOCATION_FORBIDDEN')) as load:
                with self.assertRaises(ValueError):p.numeric_archive(raw,{'x':(1,)},{'x':'float64'})
                load.assert_not_called()

    def test_fake_full_daily_projection_matches_original_all_nine_exactly(self):
        warm,daily,clocks,close,rows=fake_daily()
        d,targets,covariance,proofs,source_rows,frame,projection=p.project_daily_grid(warm,daily)
        expected=p.original_grid().build_target_grid(close,clocks,clocks.copy(),np.arange(s.START,s.END,s.DAY,dtype=np.int64))
        self.assertEqual(d.tobytes(),expected[0].tobytes());self.assertEqual(covariance.tobytes(),expected[2].tobytes())
        self.assertEqual(proofs,expected[3]);self.assertEqual(len(source_rows),2820);self.assertEqual(frame.height,1825)
        for config in s.CONFIGS:self.assertEqual(targets[config].tobytes(),expected[1][config].tobytes())
        self.assertTrue(any(np.any(np.abs(v)>0) for v in targets.values()))
        self.assertEqual(projection['selected_2026_daily_cube_rows'],0)
        for a in (d,covariance,*targets.values()):
            self.assertFalse(a.flags.writeable)
            with self.assertRaises(ValueError):a.setflags(write=True)

    def test_future_daily_perturbation_preserves_every_prior_target_and_covariance(self):
        warm,daily,clocks,close,rows=fake_daily();base=p.project_daily_grid(warm,daily)
        changed=deepcopy(rows)
        for row in changed:
            if row['close_us']==s.END-s.DAY:row['close']*=10
        altered=p.project_daily_grid(warm,s.canonical(changed))
        for config in s.CONFIGS:self.assertEqual(base[1][config][:-1].tobytes(),altered[1][config][:-1].tobytes())
        self.assertEqual(base[2][:-1].tobytes(),altered[2][:-1].tobytes())
        for change in (lambda x:x.append(dict(x[-1],close_us=s.END)),lambda x:x.__setitem__(0,dict(x[0],close=True)),lambda x:x.pop(),lambda x:x.append(x[0])):
            bad=deepcopy(rows);change(bad)
            with self.assertRaises(ValueError):p.project_daily_grid(warm,s.canonical(bad))

    def test_generated_recording_scopes_revoked_per_callback_and_on_failure(self):
        prep=dict(cells={cell:dict(input_binding_SHA256='a'*64) for cell in e.tranche_cells()});held=[]
        def callback(scope,metadata):
            scope.validate_current();held.append(scope)
            for old in held[:-1]:
                with self.assertRaisesRegex(ValueError,'REVOKED'):old.validate_current()
            self.assertIs(metadata['historical_execution_authorized'],False)
            with self.assertRaises(ValueError):s.CapturedMinuteProvider(2025,())._bind_historical_scope(scope)
            return metadata
        with self.assertRaises(ValueError):e._record_metadata_cells(prep,'b'*64,callback,domain='ACTUAL_PREPARED_SOURCE_METADATA')
        record=e._record_metadata_cells(prep,'b'*64,callback,domain='GENERATED_FAKE_METADATA')
        self.assertEqual(record['recording_scopes_created'],9);self.assertEqual(record['recording_scopes_revoked'],9)
        self.assertFalse(e._METADATA_ACTIVE)
        for scope in held:
            with self.assertRaisesRegex(ValueError,'REVOKED'):scope.validate_current()
        def failure(scope,metadata):held.append(scope);raise RuntimeError('OBVIOUS_FAKE_CALLBACK_FAILURE')
        with self.assertRaisesRegex(RuntimeError,'OBVIOUS_FAKE_CALLBACK_FAILURE'):e._record_metadata_cells(prep,'b'*64,failure,domain='GENERATED_FAKE_METADATA')
        self.assertFalse(e._METADATA_ACTIVE)
        with self.assertRaisesRegex(ValueError,'REVOKED'):held[-1].validate_current()

    def test_no_actual_source_or_legacy_authority_read(self):self.assertFalse(io_guard.DENIED)

if __name__=='__main__':
    began=time.monotonic();result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(SourceContracts))
    record=dict(schema='INDEPENDENT_FULL2025_SOURCE_GENERATED_CONTRACTS_V1',status='PASS_GENERATED_ONLY' if result.wasSuccessful() else 'FAIL',
        tests_run=result.testsRun,failures=len(result.failures),errors=len(result.errors),
        code_files={name:sha256((s.HERE/name).read_bytes()).hexdigest() for name in ('full_source.py','full_entry.py','source_projection.py','FROZEN_NINE_CELL_MANIFEST.json','OBSERVED_SOURCE_METADATA_PINS.json')},
        source_actual_review_SHA256=s.SOURCE_INDEPENDENT_REVIEW_SHA256,audited_workspace_read_paths=sorted(set(io_guard.READS)),forbidden_read_or_process_attempts=io_guard.DENIED,
        actual_source_body_reads=0,actual_targets_generated=0,actual_source_scopes=0,historical_scopes=0,actual_accounts=0,actual_provider_iterations=0,process_launches=0,financial_claims=0,financial_GO_writes=0,
        CPU_affinity=sorted(os.sched_getaffinity(0)),task_affinities={x.name:sorted(os.sched_getaffinity(int(x.name))) for x in Path('/proc/self/task').iterdir()},wall_seconds=time.monotonic()-began,
        max_RSS_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,script_SHA256=sha256(Path(__file__).read_bytes()).hexdigest())
    output=os.environ.get('REVIEW_RECEIPT','GENERATED_SOURCE_CONTRACTS_CHECKPOINT001.json')
    with (HERE/output).open('x') as stream:json.dump(record,stream,indent=2,sort_keys=True);stream.write('\n')
    raise SystemExit(not result.wasSuccessful())
