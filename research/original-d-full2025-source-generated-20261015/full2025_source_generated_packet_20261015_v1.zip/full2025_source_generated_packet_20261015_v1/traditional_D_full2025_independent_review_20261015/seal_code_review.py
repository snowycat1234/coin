"""Seal exact already-reviewed static/generated evidence; no source stage."""
import os
for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','POLARS_MAX_THREADS','VECLIB_MAXIMUM_THREADS'):os.environ[key]='1'
os.sched_setaffinity(0,{3})
import json,sys
from datetime import datetime,timezone
from hashlib import sha256
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];HERE=Path(__file__).resolve().parent;EXEC=ROOT/'traditional_D_full2025_20261015'
READS=[]
def pin(path):
    path=Path(path)
    if not path.is_file() or path.is_symlink():raise ValueError('ORDINARY_STATIC_REVIEW_FILE_REQUIRED')
    if path.suffix.lower() in ('.npz','.zip'):raise ValueError('NO_MARKET_OR_ARCHIVE_BODY_IN_CODE_REVIEW_SEAL')
    if ('GO' in path.name.upper() or 'AUTHORIZATION' in path.name.upper()) and path.suffix=='.json' and path.name not in ('ROOT_GO_TEMPLATE_INVALID.json','SOURCE_PREP_AUTHORIZATION_TEMPLATE_INVALID.json'):
        raise ValueError('NO_PRIVATE_AUTHORITY_BODY_IN_CODE_REVIEW_SEAL')
    raw=path.read_bytes();READS.append(str(path.relative_to(ROOT)))
    return dict(SHA256=sha256(raw).hexdigest(),bytes=len(raw))
def read(path):pin(path);return json.loads(Path(path).read_bytes())
def exact(path,expected):
    got=pin(path)
    if got['SHA256']!=expected:raise ValueError('EXTERNALLY_EXPECTED_REVIEW_PIN_CHANGED:'+str(path))
    return got

expected_code='21438063dd7fb390427dc5d6cb49f128cc365ba2837fbfd85afe1871064ce6ed'
expected_package='69140c7ceebc20ab60a811f7090073e7cbf37b8fbb28bcc26d6ea63595a495a9'
expected_delivery='e694248085094a7b258036129c7c521ae3999eadabfa1d2991d2ba1a3f15f89e'
for name,digest in (('CODE_MANIFEST.json',expected_code),('FROZEN_PACKAGE_MANIFEST.json',expected_package),('DELIVERABLE_PINS.json',expected_delivery)):exact(EXEC/name,digest)
delivery=read(EXEC/'DELIVERABLE_PINS.json')
for name,value in delivery['files'].items():assert pin(EXEC/name)==value,name
package=read(EXEC/'FROZEN_PACKAGE_MANIFEST.json')
for row in package['files']:assert pin(EXEC/row['file'])==dict(SHA256=row['SHA256'],bytes=row['bytes']),row['file']
sys.path.insert(0,str(EXEC));import full_entry as e
identity=e.code_identity();assert identity==read(EXEC/'CODE_MANIFEST.json')['code_identity']
for name,digest in identity.items():assert pin(ROOT/name)['SHA256']==digest,name

final_names=('INHERITED_NATIVE_FINAL','GENERATED_SOURCE_CONTRACTS_FINAL','GENERATED_CORE_REVIEW_FINAL','GENERATED_BOUNDARIES_FINAL')
reports={name:read(HERE/(name+'.json')) for name in final_names}
for name,r in reports.items():
    assert r['status']=='PASS_GENERATED_ONLY' and r['failures']==0 and r['errors']==0
    assert r['CPU_affinity']==[3]
    assert not r.get('forbidden_read_or_process_attempts')
    for tasks in (r.get('task_affinities',{}),r.get('all_task_affinities',{}),r.get('observed_task_affinities',{})):
        assert all(value==[3] for value in tasks.values())
    for code,digest in r.get('code_files',{}).items():assert pin(EXEC/code)['SHA256']==digest,(name,code)
assert sum(r['tests_run'] for r in reports.values())==45
source=read(ROOT/'full2025_qualified_source_v2_independent_review_20261015/REVIEW.json')
assert pin(ROOT/'full2025_qualified_source_v2_independent_review_20261015/REVIEW.json')['SHA256']=='ed38099a903e003db750015f38cd92db0fccd2d090d96ca910f06144f90f8ee1'
assert source['status']=='PASS_SOURCE_ONLY_NO_FINANCIAL_GO' and source['PASS_count']==12 and source['FAIL_count']==0
author=read(EXEC/'GENERATED_TEST_RECEIPT.json');assert author['status']=='PASS' and author['tests']==58 and not any(author['observed'].values())
assert all(a==[8] for a in author['all_TID_affinities'])

profile_path=EXEC/'generated_synthetic_probe_attempt001/GENERATED_POOL_PROFILE.json';profile=read(profile_path)
assert profile['generated_only'] and not profile['annual_resource_envelope_certified'] and profile['limits']==e.RESOURCE_LIMITS
assert profile['runner_SHA256']==identity[EXEC.name+'/run_full.py'] and profile['profile_SHA256']==identity[EXEC.name+'/profile_synthetic.py']
assert {r['CPU'] for r in profile['cases']}=={4,5} and len(profile['cases'])==2
overlap=sum(len(r['workers'])==2 for r in profile['observations']);assert overlap>0
for observation in profile['observations']:
    assert observation['aggregate_live_RSS_bytes']<=3500000000
    for worker in observation['workers']:
        assert worker['CPU_affinity'] in ([4],[5])
        assert all(task['CPU_affinity']==worker['CPU_affinity'] for task in worker['tasks'])
import full_d as d
sys.path.insert(0,str(ROOT/'bounded_native_continuation_guard50_exit_expansion_20261015'))
from saved_native_reconciliation import reconcile_saved_native
probe=[]
for row in profile['cases']:
    directory=profile_path.parent/row['cell_id'];assert pin(directory/'TERMINAL_CHECKPOINT.json')['SHA256']==row['checkpoint_SHA256']
    checkpoint=read(directory/'TERMINAL_CHECKPOINT.json')
    for name,digest in checkpoint['files'].items():assert pin(directory/name)['SHA256']==digest
    receipt=read(directory/'CASE_RECEIPT.json');audit=read(directory/'GENERATED_AUDIT.json');result=read(directory/'GENERATED_RESULT.json')
    proof=reconcile_saved_native(audit,result,expected_continuation_version=d.VERSION);assert proof==read(directory/'GENERATED_PROOF.json')
    assert proof['passed'] and not proof['tolerance_or_epsilon_used']
    assert receipt['generated_only'] and receipt['generated_minutes']==4320 and receipt['synthetic_calendar'][0]==205*86400000000
    assert receipt['actual_affinity']==[row['CPU']] and all(a==[row['CPU']] for a in receipt['all_TID_affinities'])
    assert all(value=='1' for value in receipt['thread_environment'].values()) and receipt['lease_FD_inherited']
    assert len(audit['trades'])>0 and audit['transfer_journal']==[] and audit['transfer_ids']=={}
    probe.append(dict(cell=row['cell_id'],CPU=row['CPU'],generated_minutes=receipt['generated_minutes'],paid_trade_rows=len(audit['trades']),native40_exact=True))

record=dict(schema='INDEPENDENT_ORIGINAL_D_FULL2025_SOURCE_GENERATED_CODE_REVIEW_V1',status='PASS_STATIC_AND_GENERATED_ONLY_NO_ACTUAL_STAGE_OR_FINANCIAL_GO',
    UTC=datetime.now(timezone.utc).isoformat(),reviewed_directory=EXEC.name,code_manifest=pin(EXEC/'CODE_MANIFEST.json'),package_manifest=pin(EXEC/'FROZEN_PACKAGE_MANIFEST.json'),deliverable_pins=pin(EXEC/'DELIVERABLE_PINS.json'),
    code_identity=identity,code_identity_SHA256=e._json_sha(identity),manifest_SHA256=e.MANIFEST_SHA256,
    source_audit=dict(path='full2025_qualified_source_v2_independent_review_20261015/REVIEW.json',SHA256=e.s.SOURCE_INDEPENDENT_REVIEW_SHA256,status=source['status'],canonical_files=15,canonical_bytes=46269167,actual_revalidation_repeated_by_this_review=False),
    independent_tests=dict(inherited_frozen_D_native40=20,source_schema_immutable_causality=9,new_all_tier_native_equivalence=9,boundary_strict_D_resource_and_reporting=7,total=45),
    author_generated_tests=dict(tests=58,observed_actual_body_or_legacy_GO_or_process_or_network_attempts=author['observed'],receipt=pin(EXEC/'GENERATED_TEST_RECEIPT.json')),
    independent_fixed_findings=['Reversible owning-array readonly flags replaced by genuinely immutable bytes-backed month/daily/decision/target/covariance arrays.','Finite covariance now required by the entry input-binding seam.','Saved defining-D validation now enforces strict policy/topup booleans, empty transfer journal/IDs and exact zero-transfer full-position paid-exit actions.','Unused2022 gap adapter overrides removed; genuine2025 uses exact frozen D quality/mark behavior.'],
    verified_contracts=[
      'Exactly STATIC50/H090/VOL_MANAGED_HOLD x LOW/MID/HIGH; nine predeclared Jan1-Dec31 full2025 DEV cells, no aliases or performance selection, fresh10000 wallets, BASE27/coarse profile, native cash1000/isolated8500 and fixed Guard50 paid exits.',
      'Canonical2025 NPZ/JSON captured once per process directly; exact saved warmup200 closes and Dec31 witness; no raw ZIP normalization or per-case target regeneration; immutable captured bytes and numeric arrays.',
      'Current target grid matches exact frozen original functions byte-for-byte on fake full-calendar inputs; future perturbation leaves earlier targets/covariance unchanged; no2026 daily feature rows, holdouts, labels or model fitting.',
      'Exact source/target/covariance/calendar/funding/quality/code/manifest/review/GO commitments and entry-owned input references; external expected authority hashes, no generated flag accepted as actual admission.',
      'Complete all-tier fake native financial states, ledgers, no-op commitments and minute bytes equal old original-D transport; nonzero paid opens, funding, reductions and D warnings; all32 charged common-wallet corners and detached callback/fullstate isolation.',
      'Authoritative pure chronological native40 reconciliation and distinct raw100 stored-delta residuals; actual cash/debt/margin corruption negatives and strict paidflat/conditional/HALT/incomplete taxonomy.',
      'Twelve dynamic source-guard categories independently deny before action and caught attempts are fatal; generated nine metadata scopes are revoked individually/on exceptions with observed zero forbidden calls; actual positive scopes remain unrun.',
      'Finite driver scheduler/claim/lease/resource/reporting functions AST-equal to inherited reviewed2022 implementation modulo2025 provenance strings; max2 distinct CPUs, numerics1,600s CPU/wall,2GB RSS/4GB AS/250MB outputs and3.5GB aggregate; no automatic retries or resume.',
      'Old source/2023/2024 GO hashes are evidence only; current code-identity walk succeeds with legacy private authority and actual source bodies denied. Fresh2025 source/financial GO must bind current source audit, code, preparation and targets directly.'
    ],
    generated_two_worker_saved_evidence=dict(profile=pin(profile_path),independently_reconciled_cases=probe,overlap_observations=overlap,peak_observed_aggregate_RSS_bytes=max(r['aggregate_live_RSS_bytes'] for r in profile['observations']),all_observed_helper_affinities_single_worker_CPU=True,temporary_global_lease_FD_inherited=True,annual_resource_envelope_certified=False,host_quota_guaranteed=False),
    required_source_stage=dict(eligible_for_root_consideration=True,launcher='traditional_D_full2025_20261015/prepare_source.py',external_new_root_authority_required=True,code_manifest_SHA256=expected_code,exact_source_audit_SHA256=e.s.SOURCE_INDEPENDENT_REVIEW_SHA256,allowed='Canonical capture, deterministic365 decisions/nine targets/covariance/source proofs and nine ephemeral recording-only metadata callbacks.',required_observed_zero_categories=list(read(HERE/'GENERATED_BOUNDARIES_FINAL.json')['guard_observations'][-1]['forbidden_attempts']),all_source_and_recording_scopes_must_be_revoked=True),
    no_actual_activity_by_this_reviewer=dict(canonical_source_body_opens=0,raw_archive_or_mixed_body_reads=0,actual_source_target_or_covariance_generation=0,actual_source_scopes=0,actual_positive_recording_scopes=0,historical_scopes=0,actual_accounts_constructed=0,actual_accounts_advanced=0,actual_provider_iterations=0,actual_process_launches=0,canonical_financial_claims_or_leases=0,financial_GO_writes=0,financial_runs=0,network_calls=0,holdout_reads=0,publication_actions=0),
    actual_source_target_equivalence_passed=False,source_stage_authorization_granted=False,financial_GO_eligible=False,historical_execution_authorized=False,financial_execution_authorized=False,publication_authorized=False,
    remaining=['Fresh exact root source-stage authority and guarded actual canonical source/target preparation.','Independent actual saved source/targets/covariance/365calendar/endpoint/funding binding review plus observed guard and nine revoked metadata scopes.','Separate admission-compatible financial review and fresh external root financial GO before any actual historical scope/account/provider/process/claim.'],
    evidence={name:pin(HERE/(name+'.json')) for name in final_names},review_script_pins={path.name:pin(path) for path in HERE.glob('*.py')},static_seal_read_paths=sorted(set(READS)),CPU_affinity=[3])
for name,digest in (('CODE_MANIFEST.json',expected_code),('FROZEN_PACKAGE_MANIFEST.json',expected_package),('DELIVERABLE_PINS.json',expected_delivery)):exact(EXEC/name,digest)
out=HERE/'CODE_GENERATED_REVIEW_RECEIPT.json'
with out.open('x') as stream:json.dump(record,stream,indent=2,sort_keys=True);stream.write('\n')
print(json.dumps(dict(status=record['status'],receipt=str(out.relative_to(ROOT)),pin=pin(out),independent_tests=45),sort_keys=True))
