# Independent full-2025 selective source-plan review

Result: PASS for the frozen metadata/code-only plan. 124 of 124 independent checks pass. Four existing source guards and eighteen synthetic fixtures independently pass on CPU1 with one BLAS thread. This review grants no authorization and does not make the draft adapter execution-ready.

Reviewed plan manifest SHA256: 43d55792b548442a8e5d8fce56aade148c7f73ec668bf6400d9788df33b236c2. All twenty frozen file identities were checked. The unchanged upstream manifest SHA256 is 4b165a00b1506e3173f23ffc80d23c4fd6fb5e707c03a99a6187254aa466ad29, and the canonical source-index SHA256 is 8a0235e428902f7a0ea4ec1893343abae6ccc23715080771796b54fb58f1f3c4.

## Findings

- All 180 selectors equal the previously frozen selector objects, including raw byte/hash, field/schema and calendar declarations. The exact CORE5 × twelve-month × three-family inventory and the 120 price-checksum scope are preserved.
- The complete expected 217-object cache map equals the original five reused objects plus the 212 separately authorized transport objects, with their exact paths, immutable lineage and byte/SHA256/Git-blob identities. It is expected metadata, not transport-completion evidence.
- Ten January selectors lack inline commits. The packet discloses inherited H1-index and exact tail-wrapper/member lineage without modifying the original selectors. That inheritance is not newly verified direct tail-source provenance.
- Inner CSV CRCs and uncompressed sizes are not predeclared. The plan requires later authorized central-directory inspection, exact selected-name/type/encryption/compression/size predicates before body access, and selected-only EOF/CRC checks. Whole-wrapper testzip and excluded-member CRC body reads remain prohibited.
- Reusing the existing normalizer, reader and pure AST transforms is appropriate. The required receipt/cache, ZIP-safety, schema, warmup, endpoint, immutable-reader and caveat seams remain explicitly unimplemented and require a separate exact-code review. The fixtures do not certify those future seams.
- The qualified warmup is a past-only, close-only artifact ending at 2025-01-01. The 200-close Jan1 projection, 365 rolling decision-window proofs, genuine minute-derived 2025 boundaries and separate Dec31 terminal witness are correctly distinguished. Canonical DAILY stays unchanged; no 2026 daily-cube row is needed or permitted.
- Any newly found 2025 gap stops qualification and gets a new exact-cell/provenance classification. The 2022 exact27 approval, overlay and imputation treatment do not carry over.
- Original-D nine-configuration discussion is structural feasibility only. Numerical readiness, actual targets, accounts, provider iteration, financial runs and GO remain unapproved and unestablished. Funding source-event coverage is separate from owned charges; funding units, historical arrival and venue filters remain uncertified. 2025 stays already-seen development evidence.
- Resource bounds are explicit and arithmetic-consistent: one worker, CPU8 proposed only after release of the existing priority, 300 CPU seconds, 900 wall seconds, 2,000,000,000-byte address space, 64 MiB per selected CSV, bounded aggregate decompression, and a 256 MiB output hard cap. Runtime is honestly unmeasured; exhaustion stops without automatic extension.

## Conditions before source application

1. Complete the sibling opaque transport with the exact pinned 217-object binding and no unresolved STOP.
2. Implement only the required small source-only adapter/reader seams and independently review their exact code and data-free safety tests.
3. Obtain separate root authorization naming the frozen plan, independent review, new code, complete transport receipt and exact source pins. It must explicitly cover reassembly, necessary central-directory inspection, selected ZIP/checksum bodies, past-only warmup and source-only outputs.
4. Establish fresh actual raw/normalized hash, schema, grid, selected CRC, 365-window and Dec31 endpoint qualification before any later admission. Target/account/provider/financial work needs its own authority.

## Review execution and limitations

The review read only named metadata, code, Markdown and test logs. It performed zero historical source or opaque transport body reads, historical ZIP central-directory reads, archive reassemblies, historical member decompressions, normalizations, network requests, target generation, provider iterations, account constructions, financial runs or claims. Historical source completeness is not certified.

The initial review run used an incorrect reviewer-side key name for the five old cache objects' immutable lineage, causing one comparison to fail. Correcting the reviewer to use the upstream immutable_commit/immutable_path fields produced 124/124 PASS; the plan was unchanged. The original attempt is retained transparently.

REVIEW.json is the detailed receipt. REVIEW_READ_ALLOWLIST.json records observed metadata/code identities. The two independent test logs and review_metadata_only.py provide reproducible evidence within this restricted scope.
