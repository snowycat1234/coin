"""Bounded offline cold checks on exact archived tests and fake fixtures only.
No original tests, source code or pinned evidence are rewritten. Explicit skips
cover omitted private metadata or fixed CPU4 tests incompatible with CPU2.
Run each suite in its own fresh process to avoid module-name collisions.
"""
import os
THREADS=('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','POLARS_MAX_THREADS','VECLIB_MAXIMUM_THREADS')
for key in THREADS:os.environ[key]='1'
os.environ['PYTHONDONTWRITEBYTECODE']='1'
import argparse,json,sys,time,resource,unittest,runpy
from pathlib import Path
from hashlib import sha256
from unittest.mock import patch
sys.dont_write_bytecode=True
p=argparse.ArgumentParser();p.add_argument('--cpu',type=int,required=True);p.add_argument('--suite',choices=('qualifier','full'),required=True);p.add_argument('--output',required=True);args=p.parse_args()
ROOT=Path(__file__).resolve().parent
assert args.cpu in os.sched_getaffinity(0),'ASSIGNED_CPU_UNAVAILABLE'
os.sched_setaffinity(0,{args.cpu})
started=time.monotonic();cpu_start=time.process_time()
# Integrity hashing of approved actual numeric bytes is the only permitted body
# access. Their JSON/NPZ content is never parsed or scientifically decoded here.
mapping=json.loads((ROOT/'ORIGINAL_COPY_MAPPING.json').read_bytes())['files']
initial={r['packet_path']:{'SHA256':r['SHA256'],'bytes':r['bytes']} for r in mapping}
for name,pin in initial.items():
 f=ROOT/name;raw=f.read_bytes()
 assert not f.is_symlink() and len(raw)==pin['bytes'] and sha256(raw).hexdigest()==pin['SHA256'],name
small=set(json.loads((ROOT/'BUILD_COPY_RECEIPT.json').read_bytes())['small_numeric_bodies_copied'])
observed=dict(actual_source_or_cache_body_read_attempts=0,old_valid_GO_body_read_attempts=0,external_process_launch_attempts=0,network_attempts=0,original_workspace_fallback_read_attempts=0)
blocked=[]
def audit(event,values):
 if event in ('subprocess.Popen','os.system','os.fork','os.forkpty','os.posix_spawn','os.exec'):
  observed['external_process_launch_attempts']+=1;blocked.append(event);raise AssertionError('COLD_EXTERNAL_PROCESS_FORBIDDEN')
 if event.startswith('socket.') and event not in ('socket.__new__',):
  observed['network_attempts']+=1;blocked.append(event);raise AssertionError('COLD_NETWORK_FORBIDDEN')
 if event!='open' or not values or not isinstance(values[0],(str,bytes,os.PathLike)):return
 path=Path(os.fsdecode(values[0])).absolute()
 mode=values[1] if len(values)>1 else 'r'
 writing=isinstance(mode,str) and any(x in mode for x in 'wax+')
 if writing:return
 try:rel=path.relative_to(ROOT).as_posix()
 except ValueError:
  # The installed interpreter and site packages are permitted; project source
  # outside this cold packet is never a fallback dependency.
  private_root=Path('/'+'workspace')
  if path.is_relative_to(private_root) and '/.venv/' not in str(path):
   observed['original_workspace_fallback_read_attempts']+=1;blocked.append('PROJECT_SOURCE_OUTSIDE_PACKET');raise AssertionError('ORIGINAL_WORKSPACE_FALLBACK_FORBIDDEN')
  return
 upper=path.name.upper()
 valid_go=('ROOT_SOURCE_STAGE_GO_APPROVED' in upper or 'ROOT_SOURCE_AUTHORIZATION_APPROVED' in upper or upper=='SOURCE_PREP_GO.JSON')
 obvious_fake=any(t in rel for t in ('GENERATED','obvious_fake','generated','FAKE'))
 if valid_go and not obvious_fake:
  observed['old_valid_GO_body_read_attempts']+=1;blocked.append('VALID_GO');raise AssertionError('ACTUAL_VALID_GO_FORBIDDEN')
 source_body=(rel in small or '/source_runs/' in rel or '/prepared_2025/months/' in rel or '/opaque_cache/' in rel)
 if source_body and not obvious_fake:
  observed['actual_source_or_cache_body_read_attempts']+=1;blocked.append('ACTUAL_SOURCE_OR_CACHE');raise AssertionError('ACTUAL_SOURCE_OR_CACHE_BODY_FORBIDDEN')
sys.addaudithook(audit)
suite=unittest.TestSuite();groups=[];remaps=[];exclusions={}
def add(loaded,group):
 groups.append(dict(group=group,declared_tests=loaded.countTestCases()))
 def walk(tests):
  for test in tests:
   if isinstance(test,unittest.TestSuite):walk(test);continue
   reason=exclusions.get(test._testMethodName)
   if reason:
    def skip(self,reason=reason):self.skipTest(reason)
    setattr(test,test._testMethodName,skip.__get__(test,type(test)))
   suite.addTest(test)
 walk(loaded)
if args.suite=='qualifier':
 for folder in ('full2025_selective_source_qualification_20261015_v2','full2025_selective_source_qualification_v2_independent_review_20261015'):sys.path.insert(0,str(ROOT/folder))
 exclusions.update({n:'Exact load_plan requires deliberately omitted private-prefix metadata/log bodies. Archived original test and hash-only evidence preserved; no sanitized replacement satisfies its frozen hash.' for n in ('test_actual_frozen_metadata_only_closure','test_exact_frozen_plan_load_is_metadata_only','test_generated_funding_units_and_calendar_unchanged','test_injected_generated_partial_failure_never_admits_batch')})
 for name in ('test_generated_seams','test_independent_generated'):add(unittest.defaultTestLoader.loadTestsFromName(name),name)
else:
 for folder in ('traditional_D_full2025_20261015','traditional_three_tier_freeze_20261015','bounded_native_continuation_guard50_exit_expansion_20261015','traditional_D_full2025_independent_review_20261015','bounded_native_continuation_guard50_exit_20261015'):sys.path.insert(0,str(ROOT/folder))
 exclusions.update({n:'Exact archived mocked runner test hardcodes CPU4 while this cold wrapper is confined to assigned CPU2. No two-worker or resource-probe rerun and no rewrite of the original test.' for n in ('test_existing_output_and_unfinished_output_pause_no_spawn','test_duplicate_jobs_and_low_memory_pause_before_spawn')})
 for name in ('test_full_gate','test_generated_d','test_generated_native40','test_generated_runner'):add(unittest.defaultTestLoader.loadTestsFromName(name),name)
 original=os.sched_setaffinity
 def remap(pid,mask):
  assert pid==0 and set(mask)=={3},'UNEXPECTED_ARCHIVED_AFFINITY_REQUEST'
  remaps.append(dict(original_CPU=3,assigned_CPU=args.cpu,scope='ARCHIVED_REVIEW_MODULE_LOAD_ONLY'));return original(pid,{args.cpu})
 for name in ('test_guard50_exit','test_saved_native_reconciliation'):add(unittest.defaultTestLoader.loadTestsFromName(name),'inherited_'+name)
 for filename,cls in (('review_generated_core.py','GeneratedReview'),('review_generated_boundaries.py','Boundaries'),('review_generated_source_contracts.py','SourceContracts'),('review_generated_terminal_taxonomy.py','Taxonomy')):
  with patch.object(os,'sched_setaffinity',remap):mod=runpy.run_path(str(ROOT/'traditional_D_full2025_independent_review_20261015'/filename),run_name='portable_'+filename[:-3])
  add(unittest.defaultTestLoader.loadTestsFromTestCase(mod[cls]),filename)
class IntegrityTests(unittest.TestCase):
 def test_exact_copied_code_and_evidence_have_not_changed(self):
  # Avoid opening approved actual numeric bodies after the audit was installed.
  for name,pin in initial.items():
   if name in small or '/source_runs/' in name or name.startswith('native_2024_source_restore_20261015/'):continue
   raw=(ROOT/name).read_bytes();self.assertEqual(dict(SHA256=sha256(raw).hexdigest(),bytes=len(raw)),pin,name)
 def test_no_actual_monthly_raw_authority_or_claim_bodies(self):
  for f in ROOT.rglob('*'):
   if not f.is_file():continue
   n=f.relative_to(ROOT).as_posix();self.assertFalse('/prepared_2025/months/' in n)
   self.assertNotIn('ROOT_SOURCE_STAGE_GO_APPROVED',f.name)
   self.assertNotIn('ROOT_SOURCE_AUTHORIZATION_APPROVED',f.name)
   self.assertNotEqual(f.name,'SOURCE_PREP_GO.json')
   self.assertNotIn('EXECUTION_CLAIMS',f.parts)
 def test_dynamic_forbidden_actual_action_counters_remain_zero(self):self.assertFalse(any(observed.values()))
add(unittest.defaultTestLoader.loadTestsFromTestCase(IntegrityTests),'packet_integrity_and_absence')
result=unittest.TextTestRunner(verbosity=2).run(suite)
# Test sources can create temporary fake scopes/accounts, lease files and fake
# projections, but can never read or admit the actual source bodies above.
changed=[]
for name,pin in initial.items():
 if name.endswith('.py') and sha256((ROOT/name).read_bytes()).hexdigest()!=pin['SHA256']:changed.append(name)
foreign=[]
for name,mod in tuple(sys.modules.items()):
 fn=getattr(mod,'__file__',None)
 if fn and Path(fn).absolute().is_relative_to(Path('/'+'workspace')) and '/.venv/' not in str(fn) and not Path(fn).absolute().is_relative_to(ROOT):foreign.append(name)
report=dict(schema='PUBLIC_FULL2025_COLD_FAKE_ONLY_RECEIPT_V1',suite=args.suite,status='PASS_EXACT_FAKE_SUBSET_WITH_EXPLICIT_SKIPS' if result.wasSuccessful() and not any(observed.values()) and not changed and not foreign else 'FAIL',
 tests_run=result.testsRun,tests_passed=result.testsRun-len(result.skipped)-len({getattr(t,'test_case',t).id() for t,_ in result.failures})-len({getattr(t,'test_case',t).id() for t,_ in result.errors}),failures=len(result.failures),errors=len(result.errors),skipped=[dict(test=str(t),reason=reason) for t,reason in result.skipped],declared_groups=groups,
 observed=observed,blocked_attempts=blocked,exact_copied_Python_files_changed=changed,foreign_project_modules=foreign,independent_io_guard_denials=getattr(sys.modules.get('independent_io_guard'),'DENIED',[]),archived_load_time_CPU_remaps=remaps,explicit_wrapper_exclusions=exclusions,
 approved_actual_numeric_bytes_integrity_hashed_only=True,approved_actual_numeric_bytes_decoded=False,actual_source_normalization=0,actual_targets_or_covariance_generated=0,actual_source_scopes=0,actual_historical_scopes=0,actual_provider_iterations=0,actual_accounts_constructed=0,actual_financial_runs=0,actual_canonical_claims=0,actual_GO_issued=0,two_worker_probe_rerun=False,publication_actions=0,
 fake_fixture_accounts_providers_targets_and_temporary_claim_tests=True,original_archived_code_and_tests_rewritten=False,
 CPU_affinity=sorted(os.sched_getaffinity(0)),all_TID_affinities={p.name:sorted(os.sched_getaffinity(int(p.name))) for p in Path('/proc/self/task').iterdir()},thread_environment={k:os.environ[k] for k in THREADS},wall_seconds=time.monotonic()-started,CPU_seconds=time.process_time()-cpu_start,max_RSS_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,Python=sys.version.split()[0],script_SHA256=sha256(Path(__file__).read_bytes()).hexdigest())
for name in ('numpy','polars','pandas'):
 mod=sys.modules.get(name)
 if mod is not None:report[name+'_version']=mod.__version__
with Path(args.output).open('x') as f:json.dump(report,f,sort_keys=True,indent=2);f.write('\n')
print(json.dumps({k:report[k] for k in ('suite','status','tests_run','tests_passed','failures','errors','wall_seconds','max_RSS_bytes')}))
raise SystemExit(0 if report['status'].startswith('PASS') else 1)
