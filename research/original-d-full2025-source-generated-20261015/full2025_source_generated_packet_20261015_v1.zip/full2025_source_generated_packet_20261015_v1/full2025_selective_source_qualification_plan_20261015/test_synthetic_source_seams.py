"""Data-free fixtures exercising existing pure normalizer and exact read guard.

Reads Python code and selector metadata only. It never imports the executable
2025 adapter, invokes a historical reader, or opens any historical ZIP/NPZ/CSV.
"""
from pathlib import Path
import ast
import hashlib
import io
import json
import unittest
import zipfile

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
NATIVE = ROOT / 'native_2025_source_restore_20261015'
NAMES = {'PRICE_COLUMNS', 'FUND_COLUMNS', 'month_limits', 'numeric_csv',
         'deduplicate', 'validate_price', 'validate_funding'}


def pure_functions():
    tree = ast.parse((NATIVE / 'metadata/original_normalize.py').read_text())
    nodes = []
    for node in tree.body:
        name = getattr(node, 'name', None)
        if isinstance(node, ast.Assign) and len(node.targets) == 1:
            name = getattr(node.targets[0], 'id', None)
        if name in NAMES:
            nodes.append(node)
    module = ast.Module(body=[ast.ImportFrom(module='__future__',
        names=[ast.alias(name='annotations')], level=0), *nodes], type_ignores=[])
    namespace = dict(np=np, pd=pd, Path=Path, zipfile=zipfile)
    exec(compile(ast.fix_missing_locations(module), 'PURE_PINNED_SYNTHETIC_ONLY', 'exec'), namespace)
    return namespace


def synthetic_zip(text):
    body = io.BytesIO()
    with zipfile.ZipFile(body, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('SYNTHETIC-1m-2025-01.csv', text)
    body.seek(0)
    body.name = 'SYNTHETIC-1m-2025-01.zip'
    return body


class SourceSeamTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.n = pure_functions()
        cls.lo, cls.hi = cls.n['month_limits'](2025, 1)

    def price(self, rows=2):
        return pd.DataFrame([[self.lo + 60000*i, 10., 12., 9., 11., 20.,
            self.lo + 60000*i + 59999, 200., 3., 10., 100., 0.] for i in range(rows)],
            columns=self.n['PRICE_COLUMNS'])

    def test_good_price_and_original_millisecond_clock(self):
        p, duplicates = self.n['validate_price'](self.price(), 'klines', self.lo, self.hi)
        self.assertEqual(duplicates, 0)
        self.assertEqual(p.timestamp_ms.dtype, np.dtype('int64'))
        self.assertEqual(int((p.timestamp_ms.iloc[0] + 60000)*1000), self.lo*1000 + 60000000)

    def test_no_automatic_microsecond_conversion(self):
        p = self.price(); p['timestamp_ms'] *= 1000
        with self.assertRaisesRegex(ValueError, 'MILLISECONDS'):
            self.n['validate_price'](p, 'klines', self.lo, self.hi)

    def test_bad_inclusive_close_rejected(self):
        p = self.price(); p.loc[0, 'close_time_ms'] += 1
        with self.assertRaisesRegex(ValueError, '59,999'):
            self.n['validate_price'](p, 'klines', self.lo, self.hi)

    def test_conflicting_duplicate_rejected(self):
        p = self.price(); q = p.iloc[[0]].copy(); q['close'] = 10.5
        with self.assertRaisesRegex(ValueError, 'Conflicting'):
            self.n['validate_price'](pd.concat([p, q]), 'klines', self.lo, self.hi)

    def test_identical_duplicate_count_requires_existing_adapter_zero_gate(self):
        p = self.price(); _, dups = self.n['validate_price'](pd.concat([p, p.iloc[[0]]]), 'klines', self.lo, self.hi)
        self.assertEqual(dups, 1)
        adapter = (NATIVE / 'normalize_source_only.py').read_text()
        self.assertIn('assert dups==0', adapter)

    def test_grid_coverage_requires_existing_adapter_array_equality(self):
        p, _ = self.n['validate_price'](self.price(1), 'klines', self.lo, self.hi)
        with self.assertRaises(AssertionError):
            np.testing.assert_array_equal(p.timestamp_ms.to_numpy()*1000,
                np.arange(self.lo*1000, self.hi*1000, 60000000, dtype=np.int64))
        self.assertIn('np.testing.assert_array_equal(f.timestamp_ms.to_numpy()*1000,times)',
            (NATIVE / 'normalize_source_only.py').read_text())

    def test_negative_trade_volume_rejected(self):
        p = self.price(); p.loc[0, 'quote_volume'] = -1
        with self.assertRaisesRegex(ValueError, 'volume/count'):
            self.n['validate_price'](p, 'klines', self.lo, self.hi)

    def test_nonintegral_trade_count_rejected(self):
        p = self.price(); p.loc[0, 'trades'] = 1.5
        with self.assertRaisesRegex(ValueError, 'volume/count'):
            self.n['validate_price'](p, 'klines', self.lo, self.hi)

    def test_bad_ohlc_rejected(self):
        p = self.price(); p.loc[0, 'high'] = 8
        with self.assertRaisesRegex(ValueError, 'OHLC'):
            self.n['validate_price'](p, 'klines', self.lo, self.hi)

    def test_nonpositive_mark_rejected(self):
        p = self.price(); p.loc[0, 'close'] = 0
        with self.assertRaisesRegex(ValueError, 'Nonpositive'):
            self.n['validate_price'](p, 'markPriceKlines', self.lo, self.hi)

    def test_csv_nonfinite_rejected(self):
        with self.assertRaisesRegex(ValueError, 'nonfinite|invalid data row'):
            self.n['numeric_csv'](synthetic_zip('1,2,3,1,2,1,60000,1,1,1,1,NaN\n'))

    def test_csv_unsupported_header_rejected(self):
        with self.assertRaisesRegex(ValueError, 'unsupported/reordered'):
            self.n['numeric_csv'](synthetic_zip('open_time,close,high,low,open,volume,close_time,quote_volume,count,taker_buy_volume,taker_buy_quote_volume,ignore\n1,2,3,1,2,1,60000,1,1,1,1,0\n'))

    def test_funding_raw_jitter_and_rates_preserved(self):
        p = pd.DataFrame([[self.lo+123, 8., .0001]], columns=self.n['FUND_COLUMNS'])
        out, dups = self.n['validate_funding'](p, self.lo, self.hi)
        self.assertEqual(int(out.calc_time_ms.iloc[0]), self.lo+123)
        self.assertEqual(float(out.last_funding_rate.iloc[0]), .0001)
        self.assertEqual(dups, 0)

    def test_funding_unsupported_interval_rejected(self):
        for interval in (0, -1, 25):
            p = pd.DataFrame([[self.lo, interval, .001]], columns=self.n['FUND_COLUMNS'])
            with self.assertRaisesRegex(ValueError, 'interval'):
                self.n['validate_funding'](p, self.lo, self.hi)

    def test_funding_out_of_month_rejected(self):
        p = pd.DataFrame([[self.hi, 8, .001]], columns=self.n['FUND_COLUMNS'])
        with self.assertRaisesRegex(ValueError, 'stated month'):
            self.n['validate_funding'](p, self.lo, self.hi)

    def test_guard_refuses_excluded_body_before_backend_read(self):
        tree = ast.parse((NATIVE/'normalize_source_only.py').read_text())
        function = next(x for x in tree.body if isinstance(x, ast.FunctionDef) and x.name == 'guarded_read')
        calls=[]
        class Fake:
            def read(self, name): calls.append(name); return b'synthetic'
        namespace=dict(wrapper_allowed={'w':{'raw/allowed.zip'}}, wrappers={'w':Fake()},
            body_reads=[], digest=lambda b:hashlib.sha256(b).hexdigest())
        exec(compile(ast.fix_missing_locations(ast.Module(body=[function], type_ignores=[])), 'GUARD_FIXTURE_ONLY', 'exec'), namespace)
        for name in ('Y2025.npz', 'Y2025_RISK.json', 'features2025/FEATURES.npz',
                     'models/model.pkl', 'holdout/2026-03.npz', '../raw/allowed.zip'):
            with self.assertRaisesRegex(ValueError, 'EXCLUDED_MEMBER_BODY_REQUEST'):
                namespace['guarded_read']('w', name)
        self.assertEqual(calls, [])
        self.assertEqual(namespace['guarded_read']('w', 'raw/allowed.zip'), b'synthetic')
        self.assertEqual(calls, ['raw/allowed.zip'])

    def test_selector_calendar_combinations_exact(self):
        data=json.loads((ROOT/'full2025_remaining_source_plan_20261015/SOURCE_SELECTION_ALLOWLIST.json').read_text())
        selectors=data['selectors']
        self.assertEqual(len(selectors), 180)
        self.assertEqual(len({(s['symbol'],s['family'],s['month']) for s in selectors}), 180)
        self.assertTrue(all(s['calendar_year_us']==[1735689600000000,1767225600000000] for s in selectors))
        self.assertTrue(all(s['month'].startswith('2025-') for s in selectors))

    def test_dec31_endpoint_and_warmup_clocks_need_no_2026_cube(self):
        day=86400000000; start=1735689600000000; end=1767225600000000
        warm=np.arange(start-199*day,start+day,day,dtype=np.int64)
        self.assertEqual(len(warm),200);self.assertTrue((warm<=start).all())
        minute_opens=np.arange(end-day,end,60000000,dtype=np.int64)
        self.assertEqual(len(minute_opens),1440)
        self.assertEqual(int(minute_opens[-1]+60000000),end)
        self.assertEqual(int(minute_opens[-1]),end-60000000)
        self.assertTrue((minute_opens<end).all())


if __name__ == '__main__':
    unittest.main(verbosity=2)
