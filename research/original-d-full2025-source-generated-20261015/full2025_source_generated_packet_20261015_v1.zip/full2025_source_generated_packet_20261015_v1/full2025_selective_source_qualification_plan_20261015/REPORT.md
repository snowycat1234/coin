# Full-2025 selective source-qualification plan

Status: PLAN ONLY, UNAPPROVED. No reassembly, historical ZIP central-directory inspection, source-member access, historical decompression, normalization, targets, accounts, provider iteration, financial processes or financial GO occurred. This is a metadata/code plan for a later separately authorized source-only stage. 2025 is already SEENDEV, not untouched OOS.

## Result

The pinned original index and exact selector inventory describe enough source coverage to attempt full January 1–December 31, 2025 qualification. The existing 2025 source-only normalizer and reader are the reuse path. They are draft adapters, not currently admitted full-year execution tools. Eight small seams are explicitly recorded; no replacement normalization or financial framework is proposed.

The exact calendar is [1735689600000000, 1767225600000000) microseconds UTC. It has 365 daily decisions, 525,600 minute opens per asset, five ordered assets, two price domains, and 5,256,000 trade-plus-mark asset-minute rows. The expected raw funding union is 5,475 events, 1,095 per asset. All of these remain source expectations pending actual local qualification.

## Frozen upstream authority and separate transport

- Original source-index SHA256: 8a0235e428902f7a0ea4ec1893343abae6ccc23715080771796b54fb58f1f3c4
- Reviewed remaining-transport plan manifest SHA256: 4b165a00b1506e3173f23ffc80d23c4fd6fb5e707c03a99a6187254aa466ad29
- Independent metadata review SHA256: 08be23d2150a73560f11915deddea0a79f552d6f28170e0e64400c3183a94c78, 43/43 PASS
- Original selector manifest SHA256: f47338cba170f4f98223a4df43fc01ae30988cedede64424b69fda17a57228d2

The sibling transport has a separate opaque-only authorization for 212 new objects and 114,727,899 bytes. Five existing H1 cache parts contribute 41,943,040 bytes. This packet maps the exact 217 expected opaque objects, 156,670,939 bytes total, to their old/new cache locations. It does not attest that the new batch has finished, read its bodies, duplicate downloads, or revise old denial receipts. A new complete transport receipt and independent byte/Git identities must be bound before the source stage begins. The old draft's single-cache paths and old DOWNLOAD_RECEIPT success gate cannot simply be relabeled.

Reassembly, central-directory inspection and selected-body extraction each require explicit coverage in the separate source-stage authorization. Opaque transport approval gives none of them permission.

## Exact selective scope

EXACT_SELECTION_CONTRACT.json preserves every original selector unchanged and adds only explicit provenance/guard requirements.

- SOURCE000–SOURCE009: ten January trade/mark archives, 14,037,027 bytes, reused within three already qualified 2024 tail wrappers. Only their exact raw ZIP and checksum member names may be opened. No wrapper is downloaded again.
- SOURCE010–SOURCE059: fifty February–June trade/mark archives, 67,142,861 bytes, within the exact H1 mixed wrapper.
- SOURCE060–SOURCE119: sixty July–December trade/mark archives, 82,770,519 bytes, reassembled from their exact indexed parts.
- SOURCE120–SOURCE179: sixty CORE5 funding archives, 54,839 bytes, within the pinned primitives wrapper.
- Exactly 120 price checksums accompany the 120 price archives. Funding identities come from the pinned primitives manifest; no nonexistent official funding-checksum evidence is invented.

All 180 selectors have raw SHA256/bytes, declared CSV columns, selected fields, month and year predicates. Ten reused January selectors do not contain an inline source_commit. Their exact wrapper SHA/member plus the pinned original index's H1_commit establish inherited lineage; the supplement records commit d69e9ac94478c5be54cb46c622afec7aaf3c61f7 without mutating the original selectors.

Inner CSV uncompressed sizes and CRCs are not predeclared in the currently available metadata. Expected inner basenames are derived exactly from symbol/family/month. Later authorized central-directory inspection must establish the size/CRC/type/encryption/compression metadata, enforce caps and exact names before opening that selected CSV body. The tests here do not implement or certify those new checks.

H1, primitives and tail wrappers may contain excluded material. No whole wrapper is called holdout-free. No wrapper-wide testzip is permitted. Central-directory inspection authorizes no body. The selected outer raw ZIP and checksum are verified to EOF; their CRC/hash/size/checksum pass before inner inspection. The one selected inner regular CSV must have its exact basename, a safe nontraversal name, supported compression and no encryption or symlink before opening. Its selected CRC is checked by reading only that member to EOF. No excluded member CRC may be obtained by reading its body.

All labels, outcomes, targets, risk outputs, model/checkpoint files, account results, shared later-year cubes, every 2026 daily-cube row, March–August 2026 holdout bodies and other nonallowlisted bodies remain excluded. No glob/fallback discovery or decompression-then-slice workaround is allowed.

## Past-only warmup and the real December 31 endpoint

The chosen warmup is the already qualified, close-only 2024 source artifact SOURCE_WARMUP_CLOSE_ONLY.npz, expected 16,557 bytes and SHA256 84c0fbcc41f068f7b3066c942efa219625adcd58b7b45d2b7e2e395b8cd7d777. Existing qualification metadata declares 566 source-close rows ending at 2025-01-01. It contains no 2026 support. Only the exact close_available_us.npy and close.npy members may be opened after the qualified past-only container identity/support/schema gate.

Project exactly the 200 vectors available from 2024-06-16 00:00 through 2025-01-01 00:00 UTC, inclusive. These are actual completed trade closes, beginning with the completed June 15 day. The underlying source is past-only; earlier rows in that pure source artifact are not exposed to the consumer. A shared cube or a container with unknown/later-year support is rejected before any array body opens. Do not load an entire shared compressed array and then discard its 2026 rows.

The ten derived 2024 mark cells remain flagged and never become trade-close warmup features. The prior trade close at the 2025 boundary is genuine. The prior mark stays FLAT_UNOWNED_PRIORUNKNOWN_NO_FABRICATION. Optional cross-checking of the exact 2024-12 normalized source is separately enumerated and must be explicitly included if used; only its time and trade-close array members are relevant.

For each 2025 decision d, a new proof must bind exactly 200 actual closes at d−199 days through d, with completed availability no later than d, correct CORE5 order and no imputation. New 2025 closes come directly from the preceding genuine 23:59 trade minute. Thirty simple daily returns use the final 31 closes, ddof 1 and annualization 365.

The original canonical DAILY.json ends at 2025-12-31 00:00, representing the prior completed day. It must remain byte-identical. The real final daily bar is completed from the 2025-12-31 23:59 source minute: open_us=1767225540000000, inclusive exchange close_ms=1767225599999, completed/available_us=1767225600000000. A separate source-only endpoint sidecar records this native-minute witness for each asset. It is not a selected 2026 daily-cube row, a decision-time feature, an end-plus-one execution permission or a financial result.

## Reuse coverage and missing seams

The original pure normalizer SHA256 is ee394086066c96bc23e83b45bf0bc2777264ab4eb57128886394fee47fecd4ff. Reuse only its existing seven selected AST functions/constants. Never execute the original module import graph or consumer/target paths.

Existing coverage includes recognized 12-/3-column parsing, nonfinite rejection, millisecond/month/close-time validation, OHLC and trade-volume/count checks, conflicting duplicate rejection, the adapter's zero-identical-duplicates assertion, exact monthly minute-array equality, exact raw hash/size/checksum checks, original 12 monthly NPZ plus DAILY/EVENTS identities, and an explicit source-only reader. The raw funding numeric values and clocks are preserved.

Missing, unimplemented seams are:

1. New complete transport receipt and exact old/new cache resolver, preserving old denials.
2. Selected ZIP metadata safety and decompression caps before body access, including exact inner basenames.
3. Explicit output key/dtype/shape/full-year coverage receipts and funding per-month/per-asset cadence checks.
4. Fresh 365-window 200-close proof over the already qualified past-only warmup and genuine 2025 closes.
5. A genuine December 31 final-native-bar source endpoint sidecar; canonical DAILY remains unchanged.
6. Ordinary-path and immutable verified-byte reader hardening. No provider iteration in this stage.
7. Explicit funding-unit, arrival and initial-mark caveats, plus source-only strictly-past mark-alignment diagnostics.
8. Any future 2025 original-D admission seam. Current expansion historical entry is year-restricted; it cannot authorize 2025. This packet only records that future need.

No existing production adapter or financial code was edited. No source seam is claimed to have been implemented or execution-certified by the added fixtures.

## Qualification and fail-closed gaps

A later source stage must require the exact original 15 source-only files, totaling 46,269,167 bytes: twelve monthly NPZs, DAILY.json, EVENTS.json and unchanged SOURCE_INDEX.json. Old Y2025.npz and Y2025_RISK.json references remain provenance text only; those bodies are excluded.

Require all 120 exact price grids, raw archives and official price checksums, selected-only outer/inner CRCs, recognized schema, exact timestamps and counts, positive finite OHLC, valid envelopes, valid nonnegative trade volumes and integral trade counts. Require zero duplicate timestamps and zero derived 2025 marks. No automatic timestamp-unit conversion or quote imputation is allowed.

Require the exact 60 funding archive identities, original finite rates, original millisecond jitter, positive reported intervals no greater than 24 hours, exact expected per-month counts, 1,095 events per asset and 5,475 total. Canonical source hashes enforce the original event union. Explicit continuity diagnostics should check the original approximately-eight-hour cadence with up to 1,000,000us jitter tolerance. Any unsupported deviation stops; it is never silently rescaled or recast.

If any previously unrecorded 2025 gap appears, stop the entire qualification stage and classify the exact missing asset/field/minute cells, streams, runs and original source provenance. Preserve original bytes and report the checksum/CRC/grid evidence. The 2022 exact27 allowlist and its approval are 2022-specific. Do not import that allowlist, apply its overlay, automatically interpolate, select a replacement source, or invent a new unknown-mark policy. Any recovery or quality proposal must name the exact 2025 cells and receive separate review and authorization.

## Original-D nine-target structural feasibility

The fixed configurations are STATIC50, H090 and VOL_MANAGED_HOLD, each crossed with LOW, MID and HIGH. Expected eventual target shapes are 365×5 per configuration. Metadata support is potentially sufficient for all 365 calendar decisions, but actual source qualification, complete eligibility, finite/nondegenerate covariances and numerical target reproduction remain unproven. No target values, target files, covariance outputs, accounts or economic results were generated here.

Preserve canonical STATIC50, one-time H090 construction, equal-CORE5 HOLD, 200-close readiness, 30-return covariance, fixed .30 asset cap, and LOW/MID/HIGH gross .30/.60/.90 and annual-volatility .05/.10/.15 limits. Nominal tier equality is not exact realized-risk matching. No per-year winner selection, threshold tuning, forecast monitor or rejected-policy reuse is introduced.

Frozen original D stays GUARD50_EXIT_ONLY, rule SHA256 5fb0b20494269da55ea705c9f3f8aaa7270d132eb3d566eb81a29cb0466b1fc8. Known-fresh isolated equity at or below half the isolated balance calls for a native paid full actual-position exit, with no topup or internal transfer. Unknown/stale mark quality does not itself create a new D warning exit. Native risk and the whole same-clock funding batch precede the D warning. Ordinary exits and legitimate pending exits remain preserved.

Any later wallet is fresh 10,000 USDT, 1× isolated, 1,000 USDT free-cash increase floor and 8,500 USDT isolated-margin ceiling. BASE27 remains 5.5bp taker fee plus 4bp half-spread and 4bp slippage per side. The fixed coarse quantity steps remain BTC .001, ETH .01, SOL 1, XRP 100 and DOGE 1000, with 10 USDT minimum notional and the unchanged closing exemption. This is a coarse research profile, not a certified historical/current venue filter table. Flat maintenance margin .005 is a frozen proxy, not a certified venue maintenance schedule.

Raw funding unit stays UNCONFIRMED. Any later RAW_AS_FRACTION_CONDITIONAL_UNCERTIFIED economic convention requires its own admitted scope. Source-event coverage is distinct from owned funding charges: ownership depends solely on current native actual quantities after paid fills. Closure clocks are research availability assumptions; historical publication/arrival, funding units and native venue execution remain uncertified. A source-identity PASS does not remove these caveats.

Preserve original signal latency, fresh-flat unknown-prior first-quote handling, charged pending previews, capacity-limited paid terminal60 fills, native chronology and Decimal reconciliation. The terminal signal is END−61 minutes and paid eligible opens are END−60 through END−1 minute. No free flatten, no conditional-forfeiture-as-paid-flat claim, no erased raw delta residual and no prior GO reuse are permitted.

## Byte, disk and runtime bounds

This plan adds zero network bytes. Future selected raw ZIP bodies total exactly 164,005,246 bytes, including the reused January members. Exact expected canonical normalized source bytes are 46,269,167.

Conservative additional persistent disk, retaining every H2 reassembly, is 72,342,553 bytes H1 + 82,770,519 bytes H2 + 46,269,167 bytes normalized = 201,382,239 bytes. An 8 MiB auxiliary/receipt cap and 1 MiB unique-partial cap give a conservative reservation of 210,819,423 bytes, within a proposed 256 MiB output hard cap. Existing opaque caches and January wrappers remain untouched. One-H2-at-a-time in-memory processing can avoid the 82,770,519-byte persistent H2 duplicate; H1 plus normalized base then equals 118,611,720 bytes. The largest selected raw archive is 2,017,496 bytes. Raw CSVs are not retained on disk.

Proposed single-worker limits preserve the existing 2,000,000,000-byte address-space and 300 CPU-second caps, with 900-second wall stop, CPU8 affinity and one BLAS thread. Per selected inner CSV decompression is capped at 64 MiB before body access; checksum bodies at 4 KiB. Aggregate decompression has a conservative hard bound of 180×64 MiB, not a prediction of actual CSV size. Only one selected CSV may be open at once. Exact output/checksum/CRC failures or budget exhaustion stop without automatic extension/retry.

No actual-source runtime was measured. Conditional 1/2/4 seconds per archive gives 180/360/720 seconds before hashing/reassembly/compression overhead; this is an uncalibrated estimate, not an ETA or completion promise. Any budget change needs renewed authorization. The 2022 priority remains with the parent; no high-CPU overlap is proposed.

## Tests and next authorization

Four existing guard tests pass. Eighteen added tests use in-memory fake ZIP/CSV fixtures and AST-extracted original transforms, exact selector metadata and synthetic clocks. They verify existing behavior and expose where additional gates are required. They do not open a historical ZIP/NPZ/CSV, invoke the executable adapter, implement new ZIP guards, establish actual 2025 source qualification or certify execution. One initial fixture asserted a narrower error-message category than pandas produced for literal NaN; the source correctly rejected it. The expectation was fixed, production code stayed unchanged and the first log is retained.

The next step is independent review of this frozen plan, followed by the small source-only adapter seams and their own independent review. After complete opaque transport and release of 2022 priority, separate external root authorization must bind the exact new code, review, transport-completion receipt, this plan and its 180-member selector. It must explicitly cover reassembly, necessary central-directory inspection, exact selected archive/checksum bodies, past-only warmup and canonical source/proof outputs, with the resource caps above.

That stage still authorizes zero targets, provider iterations, accounts, financial launches, canonical claims, uploads, publication or historical GO. NEXT_STAGE_AUTHORIZATION_REQUIREMENTS.json is deliberately unapproved requirements text, not an executable historical authorization.
