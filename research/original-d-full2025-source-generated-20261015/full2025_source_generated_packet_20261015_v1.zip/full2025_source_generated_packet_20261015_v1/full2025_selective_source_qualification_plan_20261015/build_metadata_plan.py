"""Freeze metadata/code-only qualification plan. Never open source-body files."""
from pathlib import Path
import collections
import datetime as dt
import hashlib
import json
import os

ROOT=Path(__file__).resolve().parent.parent
OUT=Path(__file__).resolve().parent
SOURCE=ROOT/'native_2025_source_restore_20261015'
P=ROOT/'full2025_remaining_source_plan_20261015'
STATUS='PLAN_ONLY_UNAPPROVED_NO_SOURCE_BODY_ACCESS'
S=['BTCUSDT','ETHUSDT','SOLUSDT','XRPUSDT','DOGEUSDT']
START=1735689600000000;END=1767225600000000;DAY=86400000000;MINUTE=60000000

def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):
    p=Path(p)
    if p.suffix not in ('.json','.py','.md','.log'):
        raise ValueError('METADATA_CODE_ONLY_READ_REQUIRED')
    return p.read_bytes()
def load(p):return json.loads(read(p))
def pin(p):
    p=Path(p);b=read(p)
    return dict(path=str(p.relative_to(ROOT)),bytes=len(b),SHA256=sha(b))
def save(name,x):
    (OUT/name).write_text(json.dumps(x,sort_keys=True,indent=2,allow_nan=False)+'\n')

manifest=pin(P/'FROZEN_MANIFEST.json')
assert manifest['SHA256']=='4b165a00b1506e3173f23ffc80d23c4fd6fb5e707c03a99a6187254aa466ad29'
reviewpath=ROOT/'full2025_remaining_source_plan_independent_review_20261015/REVIEW.json'
assert pin(reviewpath)['SHA256']=='08be23d2150a73560f11915deddea0a79f552d6f28170e0e64400c3183a94c78'
review=load(reviewpath);assert review['PASS_count']==43 and review['FAIL_count']==0
for r in load(P/'FROZEN_MANIFEST.json')['files']:
    actual=pin(P/r['file']);assert actual['bytes']==r['bytes'] and actual['SHA256']==r['SHA256']
idx=load(SOURCE/'metadata/SOURCE_INDEX.json')
assert pin(SOURCE/'metadata/SOURCE_INDEX.json')['SHA256']=='8a0235e428902f7a0ea4ec1893343abae6ccc23715080771796b54fb58f1f3c4'
sel=load(P/'SOURCE_SELECTION_ALLOWLIST.json');sels=sel['selectors']
assert len(sels)==180 and len({x['selection_id'] for x in sels})==180
assert len({(x['symbol'],x['family'],x['month']) for x in sels})==180
assert all(x['calendar_year_us']==[START,END] and x['month'].startswith('2025-') for x in sels)
phase=load(P/'PHASE_PLAN.json')
requests=load(P/'REMAINING_REQUEST_ALLOWLIST.json')
reuse=load(P/'REUSED_CACHE_PIN_MANIFEST.json')
ix24=load(ROOT/'native_2024_source_restore_20261015/metadata/SOURCE_INDEX.json')
rec24=load(ROOT/'native_2024_source_restore_20261015/VERIFIED_SOURCE_RECEIPT.json')
warmproof=load(ROOT/'native_2024_source_restore_20261015/SOURCE_200DAY_WINDOW_PROOF.json')
assert warmproof['source_close_clock_end_us']==START and warmproof['source_clocks']==566
assert rec24['status']=='PASS_EXACT_2024_SOURCE_BYTES_AND_ACTUAL_CLOSE_WINDOWS'
assert rec24['warmup']['SHA256']=='84c0fbcc41f068f7b3066c942efa219625adcd58b7b45d2b7e2e395b8cd7d777'

# Source bodies named below are expected identities from qualified metadata;
# they are NOT read, hashed, decompressed, or requalified by this builder.
sourceonly_expected=[dict(file='months/'+m['month']+'.npz',bytes=m['source_NPZ_bytes'],SHA256=m['source_NPZ_SHA256']) for m in idx['months']]
sourceonly_expected += [dict(file=n,**idx['files'][n]) for n in ('DAILY.json','EVENTS.json')]
sourceonly_expected += [dict(file='SOURCE_INDEX.json',bytes=83031,SHA256=pin(SOURCE/'metadata/SOURCE_INDEX.json')['SHA256'])]
assert sum(r['bytes'] for r in sourceonly_expected)==46269167
cache=[]
for r in reuse['H1_reused_parts']:
    cache.append(dict(provenance='REUSED_OPAQUE_H1_CACHE_NO_NEW_BODY_CHECK_IN_THIS_PLAN',
        cache_path=r['cache_path'],expected={k:r[k] for k in ('bytes','SHA256','GitBlobSHA1')},
        original_commit=r['immutable_commit'],original_path=r['immutable_path']))
for r in requests['objects']:
    cache.append(dict(provenance='NEW_OPAQUE_TRANSPORT_EXPECTED_ONLY_NOT_COMPLETION_EVIDENCE',
        request_id=r['request_id'],cache_path='full2025_bounded_source_transport_20261015/'+r['destination_cache_relative'],
        expected={k:r[k] for k in ('bytes','SHA256','GitBlobSHA1')},original_commit=r['commit'],original_path=r['path']))
assert all(r['original_commit'] and r['original_path'] for r in cache)
assert len(cache)==217 and sum(r['expected']['bytes'] for r in cache)==156670939
assert len({r['cache_path'] for r in cache})==217
save('CACHE_BINDING_SPEC.json',dict(status=STATUS,scope='Expected immutable 217-object map only; actual opaque object verification deferred to separately authorized source stage.',
    objects=cache,expected_objects=217,expected_bytes=156670939,old_download_denial_receipt_must_remain_unchanged=True,
    use_new_atomic_complete_transport_receipt=True,body_reads_during_plan=0))

jan=[x for x in sels if x['transport']=='REUSE_LOCAL_TAIL_WRAPPER']
assert len(jan)==10 and sum(x['bytes'] for x in jan)==14037027
warmup=dict(status='EXPECTED_FROM_QUALIFIED_2024_METADATA_NOT_LOADED_NOW',
    file='native_2024_source_restore_20261015/SOURCE_WARMUP_CLOSE_ONLY.npz',
    bytes=rec24['warmup']['bytes'],SHA256=rec24['warmup']['SHA256'],
    exact_archive_members=['close_available_us.npy','close.npy'],exact_array_keys=['close_available_us','close'],
    container_expected_rows=566,container_source_available_us_bounds=[warmproof['source_close_clock_start_us'],START],
    forbidden_future_or_holdout_rows_in_container=0,
    predicate_before_body_access='Before opening any .npy body: verify qualified 2024 metadata and closed container identity, exact two-member numeric-only archive schema, entire declared clock support ending at 2025-01-01. A shared cube or any container with later/unknown-year support is rejected before decompression. This file is a past-only source-close artifact; it contains no 2026 data.',
    row_projection=dict(close_available_us_min_inclusive=START-199*DAY,close_available_us_max_inclusive=START,
        UTC_bounds=['2024-06-16T00:00:00Z','2025-01-01T00:00:00Z'],expected_rows=200,expected_shape=[200,5],
        daily_clock_step_us=DAY,close_dtype='float64',clock_dtype='int64',symbol_order=S,
        quality='actual completed nonimputed trade closes only; exclude all mark fields'),
    earliest_underlying_completed_day_open_UTC='2024-06-15T00:00:00Z',
    no_shared_daily_cube=True,no_2026_daily_cube_row=True,
    refresh_proof_required='Fresh source-only per-window 200-close proof for all 365 2025 decision clocks. Retain original qualified 2024 artifact unchanged; emit exact 200-row projection only in a new source-only output.',
    terminal_prior_trade_close='Use the last qualified warmup close at START, cross-check hash-pinned 2024-12 source close fields if needed; never infer a new prior mark.',
    optional_terminal_2024_source=dict(file='native_2024_source_restore_20261015/prepared_2024/months/2024-12.npz',
        **{k:v for k,v in next(x for x in rec24['exact_normalized_files'] if x['file']=='months/2024-12.npz').items() if k!='file'},
        exact_array_members=['times.npy']+[s+'_close.npy' for s in S],
        calendar_us=[1733011200000000,START],projection='Only actual final close per asset; full archive hash may be verified opaquely but no other array member is opened.',
        read_required=False),
    existing_2024_derived_mark_cells=10,derived_mark_features_used=0)
selection=dict(status=STATUS,source_index_SHA256=sel['source_index_SHA256'],
    source_selector_manifest=pin(P/'SOURCE_SELECTION_ALLOWLIST.json'),selectors=sels,
    groups=sel['groups'],raw_archive_count=180,price_checksum_count=120,
    exact_raw_archive_bytes=sum(x['bytes'] for x in sels),price_archive_bytes=163950407,funding_archive_bytes=54839,
    january_reuse=dict(selectors=[x['selection_id'] for x in jan],archives=10,raw_bytes=14037027,
        wrapper_pins=[dict(path=path,SHA256=next(x['wrapper_SHA256'] for x in jan if x['wrapper']==path)) for path in dict.fromkeys(x['wrapper'] for x in jan)],
        repeat_downloads=0,no_whole_wrapper_duplicate=True),past_warmup=warmup,
    body_access_order=['Separate stage authorization and independent plan/code review first',
        'Verify new complete transport receipt and all 217 opaque byte/Git identities using exact path map',
        'Authorize and perform exact H1/H2 reassembly; verify aggregate bytes/SHA before ZIP access',
        'Authorize central-directory inspection only; match exact selected identities and safe metadata before any body read',
        'Read only allowlisted raw archive/checksum bodies; selected outer CRC is checked by reading each selected member to EOF',
        'Verify raw archive size/SHA256 and official checksum before inspecting its one inner member',
        'Validate inner exact basename, regular-file type, nonencrypted, nontraversal and byte caps before opening its body',
        'Read only that selected CSV to EOF, check selected-inner CRC and original schema/field/calendar/grid constraints',
        'Normalize using unchanged pure AST functions and require original source-only hashes',
        'Use already-qualified past-only 2024 close artifact plus newly qualified 2025 minute-derived closes for warmup/endpoint evidence'],
    inner_basename=dict(klines='{symbol}-1m-{YYYY-MM}.csv',markPriceKlines='{symbol}-1m-{YYYY-MM}.csv',fundingRate='{symbol}-fundingRate-{YYYY-MM}.csv'),
    fail_closed_rules=['Exact names only: no glob, prefix, substring, basename fallback or automatic discovery; duplicate names are fatal',
        'Reject selected absolute/drive-qualified/traversal/NUL/backslash aliases, symlinks, directories, encryption and unknown compression before selected-body open',
        'Never call testzip over mixed wrappers; do not open or compute CRC by reading any excluded member',
        'Opaque wrapper hashing is not permission to inspect bodies; central-directory permission is not body permission',
        'All archive/member metadata must pass size and expansion limits before decompression; no extraction to arbitrary member paths',
        'Unknown or shared later-year cube namespace fails before any array body load; no decompression-then-slice workaround',
        'No imputation, no fabricated quotes/marks, no timestamp unit guessing, no outcome-derived normalization fixes',
        'Any mismatch stops the whole source stage; no automatic retries, alternative source or changed original hashes'],
    excluded_bodies=['Y2025.npz','Y2025_RISK.json','features2025/FEATURES.npz','features2025/EXPERTS.npz',
        'all targets, labels, outcomes, accounts, models and checkpoints','all nonallowlisted mixed-wrapper members',
        'all shared later-year daily cubes and any 2026 daily-cube row','2026 March-August and every other unapproved future/holdout body'])
selection['gap_policy']='Any newly discovered 2025 gap stops qualification. Classify exact missing cells, symbols, families, minute clocks, streams and original source provenance. No 2022 exact27 allowlist, overlay, interpolation or repair permission is inherited. Any genuine source recovery or new quality policy requires a separately reviewed exact proposal and explicit authorization.'
selection['provenance_supplement']=[dict(selection_id=x['selection_id'],
    source_commit=x.get('source_commit',idx['H1_commit']),
    inherited_commit_reason='Canonical H1 source-index lineage plus exact qualified tail-wrapper SHA/member' if 'source_commit' not in x else 'Declared inline in original selector',
    expected_inner_csv_basename=x['symbol']+('-fundingRate-' if x['family']=='fundingRate' else '-1m-')+x['month']+'.csv',
    inner_uncompressed_bytes_and_CRC='Not available in current metadata; inspect only after separate central-directory authorization, enforce cap before body access, and check selected member to EOF') for x in sels]
save('EXACT_SELECTION_CONTRACT.json',selection)

save('NEW_2025_GAP_STOP_POLICY.json',dict(status=STATUS,existing_expected_missing_trade_cells=0,existing_expected_missing_mark_cells=0,
    discovery_action='Stop the entire source qualification stage. Do not normalize or mark a partial year PASS.',
    classification_receipt_required_fields=['selection_id','symbol','family','month','original archive SHA256 and bytes',
        'source commit/path or exact wrapper/member lineage','exact missing expected minute-open clocks',
        'affected trade or mark fields and asset-minute cell count','contiguous missing runs and affected stream count',
        'expected versus observed row count and exact grid difference','duplicate/conflicting rows classified separately',
        'last genuine prior observation and first genuine next observation if already allowed in the same source stream',
        'selected checksum/CRC status and source provenance','stage halted before target, account or provider use'],
    allowed_now='Plan the receipt schema only; no source bodies or gap values inspected.',
    allowed_future_on_discovery='Write diagnostic metadata derived solely from already authorized source reads, preserve original bytes and stop for root review.',
    no_2022_exact27_allowlist_or_overlay_import=True,no_automatic_imputation=True,no_automatic_new_gap_policy=True,
    no_new_download_or_alternate_source_without_authorization=True,
    follow_on='A genuine source-recovery proposal or a declared unknown-mark quality treatment must name exact 2025 cells/provenance and obtain new independent review and root authorization. The existing 2022 exact27 approval applies only to its 2022 scope.'))

save('SELECTOR_SCHEMA_PROVENANCE_AUDIT.json',dict(status='METADATA_AUDIT_PASS_WITH_DECLARED_FUTURE_INSPECTION_LIMITS',
    selectors=180,selectors_with_declared_validate_columns=180,selectors_with_declared_selected_fields=180,
    selectors_with_declared_calendar_year_and_month=180,selectors_with_raw_SHA256_and_bytes=180,
    selectors_with_inline_source_commit=170,january_selectors_with_inherited_source_commit=10,
    inherited_commit=idx['H1_commit'],inherited_lineage='Exact source index H1_commit plus selected qualified 2024 tail-wrapper SHA/member. Supplement records inherited provenance without mutating the original selector manifest.',
    selectors_with_predeclared_inner_uncompressed_bytes=0,selectors_with_predeclared_inner_CRC=0,
    explanation='All 180 selectors declare CSV column schema and field/time predicates. Ten January reuse selectors lack an inline source_commit but have exact wrapper/member lineage. Inner CSV CRC/uncompressed metadata are unavailable without later authorized central-directory inspection. This plan derives exact expected CSV basenames and requires metadata checks before the selected body opens. Funding archive provenance is the pinned primitives manifest; no official funding checksum body is invented.',
    future_inspection_is_authorized=False,actual_body_qualification=False))

seams=[
 dict(id='SEAM01_TRANSPORT_BINDING',existing='Hardcoded old DOWNLOAD_RECEIPT requires PASS_ALL_PART_IDENTITIES and old single-cache paths.',
      missing='Transport now spans five old cached parts plus 212 new cache objects. Preserve denial receipts, bind new immutable complete-transport receipt and exact217 map before any body read.',scope='small read-only cache resolver + receipt gate'),
 dict(id='SEAM02_SELECTED_ZIP_METADATA',existing='Exact wrapper member-name guard and duplicate wrapper names; one inner member count; selected read implicitly CRC-checks to EOF.',
      missing='No explicit selected type/encryption/traversal/inner basename/compression or decompression bound gate. Add metadata predicates before opening selected bodies and exact inner one-CSV validation.',scope='strengthen existing guarded_read/raw/numeric_csv seam; do not replace pure normalizer'),
 dict(id='SEAM03_SOURCE_OUTPUT_SCHEMA',existing='Original12 monthly NPZ, DAILY and EVENTS bytes/SHA, calendar/time arrays, dups==0, 5475 total funding events.',
      missing='Add exact array-key/dtype/shape and full-year aggregate/source-provenance checks, per-symbol funding1095 and per-month expected counts/8h jitter continuity; do not silently reinterpret units.',scope='source-only verification receipts; canonical normalization outputs unchanged'),
 dict(id='SEAM04_PAST_WARMUP',existing='Actual2024 terminal close loaded from2024-12 NPZ; no consumer cube import.',
      missing='Bind qualified past-only close artifact, project exact200 closes for Jan1, and prove365 rolling windows with correct clocks/symbol order and nonimputed trade-close provenance.',scope='reuse qualified2024 artifact and minute-derived2025 closes; no new framework'),
 dict(id='SEAM05_DEC31_ENDPOINT',existing='Monthly2025-12 NPZ contains genuine final minute, but DAILY stops at Dec31 00:00 and reader exposes only that DAILY list.',
      missing='Retain canonical DAILY bytes unchanged. Derive separate source endpoint witness from2025-12 final native minute open END-MINUTE, available END, per asset. It is an endpoint witness, not a2026 feature row or an execution permit.',scope='small source-only endpoint sidecar and reader metadata seam'),
 dict(id='SEAM06_IMMUTABLE_READER',existing='Exact2025 index/monthly/DAILY/EVENTS hashes and explicit DAILY/EVENTS names; minute_blocks generator reads onlysource arrays.',
      missing='Reject symlinked paths and undeclared schemas; capture verified immutable bytes or recheck exact bytes immediately before every load, and keep consumer/provider iteration behind separate later admission.',scope='harden existing source_window_interface; no runtime account imports'),
 dict(id='SEAM07_SOURCE_UNIT_CLOCK_CAVEATS',existing='Raw funding rates/timestamps/intervals preserved; initial mark boundary remains unknown; no rate conversion in adapter.',
      missing='Emit explicit UNCONFIRMED unit and historical arrival uncertified flags, strict-past mark alignment source-availability proof, boundary unknown flags. A raw-fraction financial interpretation stays conditional and outside source stage.',scope='source-only receipt, no funding economics'),
 dict(id='SEAM08_2025_D_ENTRY_FUTURE_ONLY',existing='Frozen originalD/grid math exists, but existing expansion historical admission accepts2023/2024 only.',
      missing='No actual2025 D entry, generated process fit, source-target equivalence, or independent admission exists. Do not relabel an old year/GO or reuse forecast/rejected policies. A later separate request must authorize any target/adapter work.',scope='feasibility finding only; no implementation or execution in this plan')]
save('ADAPTER_COVERAGE_AND_MISSING_SEAMS.json',dict(status=STATUS,reuse='Existing normalize_source_only.py, source_window_interface.py, test_source_guard.py and pure AST transforms',
    original_pure_normalizer_SHA256='ee394086066c96bc23e83b45bf0bc2777264ab4eb57128886394fee47fecd4ff',
    existing_adapter_test_status='Four existing guards re-run PASS; eighteen new data-free seam fixtures PASS. No actual source bodies were read or normalized.',
    new_frameworks=0,actual_adapter_edits=0,seams=seams))

configs=[s+'_'+t for s in ('STATIC50','H090','VOL_MANAGED_HOLD') for t in ('LOW','MID','HIGH')]
feasibility=dict(status='METADATA_POTENTIALLY_SUPPORTABLE_NOT_ACTUAL_SOURCE_OR_TARGET_QUALIFICATION',
    evidence_role='2025 already SEENDEV, not pristine OOS',calendar_us=[START,END],UTC=['2025-01-01T00:00:00Z','2026-01-01T00:00:00Z exclusive'],
    days=365,decision_us_contract=dict(first=START,last=END-DAY,step=DAY,count=365),
    minute_open_us_contract=dict(first=START,last=END-MINUTE,step=MINUTE,count_per_asset=525600,assets=5,
        rows_per_price_family=2628000,price_families=2,total_trade_and_mark_rows=5256000),
    configurations=configs,targets_generated=0,accounts_constructed=0,financial_runs=0,provider_iteration=0,
    per_config=[dict(config=c,expected_decisions=365,expected_target_shape=[365,5],status='SOURCE_AND_NUMERIC_READINESS_UNPROVEN; no target values generated') for c in configs],
    warmup=warmup,
    rolling_200_close_rule='For every decision d use exactly 200 actual completed trade-close vectors at d-199DAY through d inclusive; latest close availability <=d. 31 closes supply 30 simple returns, ddof 1 annualization 365. At Jan1 all 200 are available in past-only 2024 qualified artifact. Subsequent closes come from exact 2025 prior-minute trade closes.',
    endpoint=dict(open_us=END-MINUTE,exchange_inclusive_close_ms=END//1000-1,completed_available_us=END,
        source_month='2025-12',source_file_SHA256=idx['months'][-1]['source_NPZ_SHA256'],
        expected_complete_daily_bars=365,last_daily_bar_open_us=END-DAY,last_daily_bar_close_us=END,
        origin='GENUINE_2025_DEC31_2359_NATIVE_MINUTE_FOR_ALL_CORE5',selected_2026_daily_cube_rows=0,
        end_plus_one_witness_is_execution_authority=False,
        canonical_DAILY_file_unchanged=True,new_source_only_endpoint_sidecar_required=True),
    unproven=['Full raw local source identities/schema/grids/checksums/selected CRCs','Original12 monthly and DAILY/EVENTS normalized bytes',
        'Fresh365 per-window200-close proofs and genuineDec31 source endpoint','Finite nondegenerate covariance and canonical original fullfive eligibility at every decision',
        'Any numerical9-target reproduction/equivalence; actual target bytes','New independently reviewed2025 adapter and generated/native process resource fit','Separate source-stage and any later financial authority'],
    no_admission_from_prior_PASS_labels=True,no_old_GO_reuse=True,no_financial_feasibility_claim=True)
save('JAN_DEC_ORIGINAL_D_NINE_FEASIBILITY.json',feasibility)

preserve=dict(status='PRESERVE_FROZEN_RULES_NO_FINANCIAL_ACTION',
    original_D=dict(policy_variant='GUARD50_EXIT_ONLY',rule_SHA256='5fb0b20494269da55ea705c9f3f8aaa7270d132eb3d566eb81a29cb0466b1fc8',
        warning='Known fresh isolated equity <= one half isolated balance triggers native paid full actual-position exit; no topup or internal margin transfers.',
        unknown_or_stale_mark_itself_creates_new_warning_exit=False,ordinary_native_exits_and_existing_pending_exits_preserved=True,
        native_risk_and_all_sameclock_funding_precede_D_warning=True,forecast_monitor_used=False,rejected_policy_reuse=False),
    strategies=dict(STATIC50='Canonical later risk-retargeted STATIC50; older no-reexpansion mixture remains separate',
        H090='Once1.5*canonical STATIC50 then original clip,gross-shrink,vol-shrink order',
        VOL_MANAGED_HOLD='Original constant long equalCORE5 .6/5 followed by signed past30 covariance downscale; no inverse-vol substitution'),
    tiers=[dict(name=n,gross_cap=g,annual_volatility_budget=v) for n,g,v in [('LOW',.3,.05),('MID',.6,.10),('HIGH',.9,.15)]],
    risk=dict(asset_absolute_cap=.30,completed_closes=200,covariance_returns=30,covariance_ddof=1,annualization_days=365,
        actual_charged_position_risk_guard_unchanged=True,nominal_tier_equality_is_exact_realized_risk_matching=False),
    wallet=dict(initial_USDT='10000',leverage=1,margin='ISOLATED',free_cash_increase_floor_USDT='1000',isolated_margin_ceiling_USDT='8500',
        automatic_topup=False,internal_transfers=False,fresh_genesis_required=True,no_halted_snapshot_resume=True),
    costs=dict(primary='BASE27',taker_fee_fraction='0.00055',taker_fee_bps_per_side='5.5',half_spread_bps_per_side='4',slippage_bps_per_side='4',nominal_roundtrip_bps='27',
        STRESS43_is_separate_unapproved_sensitivity=True,no_financial_cost_changes=True),
    coarse_profile=dict(SHA256='94b2238b25ed345a24a1fa148c6f35523b8efe9bf47496958028844432cb8ebf',
        quantity_steps=dict(BTCUSDT='.001',ETHUSDT='.01',SOLUSDT='1',XRPUSDT='100',DOGEUSDT='1000'),min_notional_USDT='10',
        closing_min_notional_exempt=True,historical_or_current_exchange_filters_certified=False,
        role='Fixed coarse research sensitivity; not historical/native instrument filter table'),
    maintenance=dict(rate_fraction='0.005',role='Frozen flat maintenance-rate proxy; no historical exchange risk tier or maintenance schedule certification'),
    funding=dict(source_rate_unit='UNCONFIRMED',raw_rates_unchanged=True,reported_interval_unchanged=True,
        fractional_economic_model='RAW_AS_FRACTION_CONDITIONAL_UNCERTIFIED',rate_conversion_in_source_stage=False,
        source_coverage_implies_ownership=False,ownership='Any later funding exposure determined solely by current native actual position after paid fills'),
    clock=dict(minute_available_us='(open_ms+60000)*1000',daily_close_available='FollowingUTCmidnight',funding_raw_millisecond_jitter_preserved=True,
        prior_mark='FLAT_UNOWNED_PRIORUNKNOWN_NO_FABRICATION',funding_mark='Latest strictly-past completed minute, gap>0 and<=60000000us; boundary unknown remains unknown',
        historical_publication_arrival_certified=False,availability_role='Closure-clock research assumption; historical publication delay not certified',
        original_daily_signal_latency_preserved=True,coldstart='Fresh flat; no prior minute quote fabricated; first actual completed minute quote at START+MINUTE and initial increase no earlier than START+MINUTE+1us'),
    terminal=dict(signal_us=END-61*MINUTE,eligible_open_range=[END-60*MINUTE,END-MINUTE],paid_capacity_limited_fills_only=True,no_free_flatten=True,
        conditional_forfeiture_is_paid_market_flat=False,native_chronological_Decimal_reconstruction_unchanged=True,raw_delta_residual_not_erased=True),
    certification=dict(native_venue=False,historical_filters=False,historical_arrival=False,funding_units=False,new_alpha=False,untouched_OOS=False))
save('PRESERVED_RULES_AND_ASSUMPTIONS.json',preserve)

h1bytes=phase['recomputed_inventory']['complete_H1_expected_bytes'];h2bytes=82770519;normbytes=46269167
auxcap=8*1048576;partialcap=1048576;maxraw=max(x['bytes'] for x in sels)
# Conservative all-H2-retained scenario. Existing cache and existing wrappers
# are excluded from additional disk, never duplicated by a fresh download.
base=h1bytes+h2bytes+normbytes
resources=dict(status='BOUNDED_PLANNING_ESTIMATE_UNMEASURED_ON_ACTUAL2025_SOURCE',new_network_requests=0,new_network_payload_bytes=0,
    opaque_transport_reference=dict(new_approved_objects=212,new_approved_bytes=114727899,reused_objects=5,reused_bytes=41943040,total_opaque_bytes=156670939,task='Separate sibling transport; no duplicate download'),
    source_archive_inventory=dict(price_ZIPs=120,price_ZIP_bytes=163950407,funding_ZIPs=60,funding_ZIP_bytes=54839,selected_raw_ZIP_bytes=164005246,january_reused_raw_bytes=14037027),
    additional_disk_bytes=dict(H1_reassembly=72342553,H2_reassembly_all_retained=82770519,canonical_normalized_source=46269167,
        exact_base_all_reassemblies_plus_normalized=base,auxiliary_sidecar_and_receipt_cap=auxcap,unique_partial_cap=partialcap,
        total_conservative_output_reservation=base+auxcap+partialcap,requested_output_hard_cap=256*1048576,
        streaming_H2_one_archive_in_memory_base=h1bytes+normbytes,
        largest_selected_raw_archive_scratch=maxraw,warmup_projection_float_payload=200*5*8),
    disk_policy='Require256MiB free reservation plus existing cache untouched; conservative exact base201382239B and proposed auxiliary/partial caps give210819423B. Keep any large raw CSV temporary in bounded memory; do not duplicate raw archives extracted from wrappers on disk. Reassembly-all retention is optional; one-H2-at-a-time avoids82770519B persistent duplicate.',
    compute_limits_proposed=dict(workers=1,CPU_affinity=[8],BLAS_threads=1,CPU_seconds=300,wall_seconds=900,AS_bytes=2000000000,
        selected_inner_max_uncompressed_bytes=64*1048576,selected_checksum_max_bytes=4096,archive_count=180,
        decompression_max_selected_inner_aggregate_bytes=180*64*1048576,selected_CSVs_simultaneously_open=1,
        metadata_receipt_max_bytes=auxcap),
    runtime_estimate='No actual2025 source processing benchmark exists. Conditional1/2/4seconds per selected archive gives180/360/720seconds plus reassembly/hash/compression overhead;900second wall and existing300CPU-second limits are hard stops, not a completion promise. Stop and request revised authorization if budget exceeded; no automatic extension or retry.',
    preparation_test_resources=dict(CPU_affinity=[8],BLAS_threads=1,existing_guard_tests=4,new_synthetic_seam_tests=18,actual_body_reads=0,actual_financial_imports=0),
    spending='No paid service or spend authorized; no external service used by plan.')
assert base==201382239 and base+auxcap+partialcap==210819423
save('BYTE_DISK_RUNTIME_BOUNDS.json',resources)

checks=dict(status=STATUS,canonical_expected_source_files=sourceonly_expected,
    schema=dict(monthly_keys=['times']+[s+'_'+f for s in S for f in ('open','close','quote_volume','mark')],
        times_dtype='int64',prices_dtype='float64',times='Exact month-open grid; no gaps/duplicates; concatenated525600 per asset',
        daily_columns=['symbol','close_us','close'],daily_records=1825,events_columns=['symbol','event_us','raw_rate','reported_interval_hours'],events=5475,
        source_only_files=15,excluded_old_index_outputs_not_restored=['Y2025.npz','Y2025_RISK.json']),
    price_checks=['Exact 180 raw archive SHA/size, exact 120 official price checksum bindings, selected outer and inner CRCs',
        'USD-M integral epoch milliseconds, exact month and open-minute grid; close_time=open+59999',
        'Full 12-column recognized schema; finite values; positive trade/mark OHLC; valid OHLC envelope',
        'Trade volume/quote/taker volume nonnegative; trades integral; zero identical and conflicting duplicate timestamps',
        'Exact 120 price grids, each monthly count and 525600 yearly minutes per asset per family; zero derived 2025 marks'],
    funding_checks=['Three exact source columns, finite raw rates, integral original millisecond clock in exact month, positive interval <=24',
        'Zero duplicate/conflicting timestamp per asset; exact monthly expected count from 180-selector manifest; 1095 per asset; 5475 total',
        'Original cadence near 8 hours with <=1000000us jitter tolerance and reported interval 8 expected; preserve original timestamps',
        'No rescaling, rounding or implicit percent/fraction conversion; unit UNCONFIRMED retained',
        'Source-only strictly-past mark alignment diagnostic; no financial charge and no fabricated first mark'],
    qualification_outputs_required=['Atomic original transport completion binding, selected raw archive/member CRC/schema/grid receipt',
        'All 15 canonical source-only file identities; original index bytes unchanged as provenance only',
        'New source-only 2025 200-close window proof for 365 decision clocks and exact warmup projection',
        'Genuine Dec31 native-minute endpoint witness, zero 2026 cube rows',
        'New source-only qualification receipt with all assumptions/zero excluded reads; independent actual source review'],
    classification='Original index PASS labels are provenance only; require fresh local body qualification after separate authorization. Units/arrival remain uncertified even if exact bytes pass.')
save('QUALIFICATION_CHECKS.json',checks)

requirements=dict(status='UNAPPROVED_REQUIREMENTS_ONLY_NOT_VALID_GO',approval_granted=False,
    stage='SELECTIVE_FULL2025_SOURCE_QUALIFICATION_ONLY',
    prerequisites=['Complete bounded opaque sibling transport with exact 212 new and 5 reused identities, no STOP/outstanding failure',
        'Root release of 2022 priority and explicit CPU8 allocation','Independent review of this frozen plan and minimal source-selector/reader seam code',
        'Separate external root authorization that names exact frozen plan, exact review, exact new adapter code, complete transport receipt and all source pins'],
    future_authorization_must_explicitly_cover=['Read exact 217 opaque objects using CACHE_BINDING_SPEC, rehash opaque bytes only',
        'Reassemble exact H1 wrapper and 60 exact H2 raw archives within disk cap','Inspect only necessary central-directory metadata before selected extraction',
        'Read/decompress exact 180 source ZIPs and 120 price checksum bodies under predicate-before-body contract',
        'Read only qualified past 2024 close artifact, its exact two arrays and 200-row projection; optional 2024 terminal-close source only if explicitly named',
        'Apply unchanged pure normalizer, write source-only canonical 12 months/DAILY/EVENTS/index and new source-only proof/endpoint receipts',
        'Perform fresh source-only schema/hash/grid/funding-unit/arrival caveat qualification and 365-window structural feasibility checks'],
    exact_scope=dict(year=2025,calendar_us=[START,END],symbols=S,source_index_SHA256=sel['source_index_SHA256'],
        raw_selection_manifest_SHA256=pin(P/'SOURCE_SELECTION_ALLOWLIST.json')['SHA256'],max_source_archive_selections=180,max_price_checksums=120,
        targets_generated=0,provider_iteration=0,accounts_constructed=0,financial_runs=0,claims_created=0,process_financial_launches=0,
        historical_GO=False,new_network_requests=0,holdout_or_nonallowlisted_reads=0,publication_actions=0),
    prohibited=['No historical target generation or covariance/strategy target build','No account, provider iteration, financial run or canonical claim',
        'No new financial GO or financial entry constructor','No source/outcome uploads, publication or forecast-monitor/rejected-policy reuse',
        'No whole mixed-wrapper testzip, nonallowlisted CRC body reads, shared later-year cube or 2026 holdout reads'],
    note='This JSON deliberately contains no approved review, no external authorization digest and no executable historical action. Transport approval does not satisfy this stage.')
save('NEXT_STAGE_AUTHORIZATION_REQUIREMENTS.json',requirements)

# Only code/metadata is pinned here. Future body pins are declarations above.
pinpaths=[P/n for n in ['FROZEN_MANIFEST.json','PHASE_PLAN.json','REMAINING_REQUEST_ALLOWLIST.json','REUSED_CACHE_PIN_MANIFEST.json','SOURCE_SELECTION_ALLOWLIST.json','SOURCE_EXPECTATION_CHECKS.json']]
pinpaths += [reviewpath]
pinpaths += [SOURCE/n for n in ['normalize_source_only.py','source_window_interface.py','test_source_guard.py','SOURCE_ONLY_ADAPTER_RECEIPT.json','DOWNLOAD_RECEIPT.json','BLOCKED_RECOVERY_RECEIPT.json']]
pinpaths += [SOURCE/'metadata'/n for n in ['SOURCE_INDEX.json','SOURCE_MEMBER_ALLOWLIST.json','TRANSFER_PLAN.json','original_normalize.py','H1_INDEX.json','H2_INDEX.json','FUNDING_MANIFEST.json']]
pinpaths += [ROOT/'native_2024_source_restore_20261015'/n for n in ['metadata/SOURCE_INDEX.json','VERIFIED_SOURCE_RECEIPT.json','SOURCE_200DAY_WINDOW_PROOF.json']]
pinpaths += [ROOT/'traditional_three_tier_freeze_20261015'/n for n in ['frozen_grid.py','native_runtime.py','FROZEN_SPEC.json','SOURCE_PROVENANCE.json','NATIVE_SOURCE_PROVENANCE.json','sources/QUANTITY_PROFILE.json','sources/vendor_quant/perpetual_account.py']]
pinpaths += [ROOT/'bounded_native_continuation_guard50_exit_20261015'/n for n in ['guard50_exit.py','guard50_exit_entry.py','run_guard50_exit.py']]
pinpaths += [ROOT/'bounded_native_continuation_guard50_exit_expansion_20261015'/n for n in ['expansion.py','expansion_entry.py']]
pinpaths += [ROOT/'full2025_bounded_source_transport_20261015'/n for n in ['PREFLIGHT.json','FROZEN_REQUEST_MANIFEST.json']]
observed=[pin(p) for p in pinpaths]
save('OBSERVED_METADATA_CODE_PINS.json',dict(status=STATUS,observed_metadata_code_files=observed,
    source_payload_bodies_hashed_here=0,opaque_transport_bodies_hashed_here=0,expected_body_pins_are_not_observed_body_verification=True))
save('PREPARATION_RECEIPT.json',dict(status='PASS_METADATA_CODE_PLAN_AND22_SYNTHETIC_TESTS_ONLY',UTC=dt.datetime.now(dt.UTC).isoformat(),
    original_frozen_plan_SHA256=manifest['SHA256'],source_index_SHA256=sel['source_index_SHA256'],observed_metadata_code_files=len(observed),
    exact_selection_ids=180,price_checksums=120,cache_object_map=217,old_receipts_or_original_code_modified=0,
    existing_test_count=4,synthetic_test_count=18,synthetic_tests_status='PASS',
    first_synthetic_attempt='One assertion expected a nonfinite message; pandas instead correctly rejected literal NaN at numeric conversion. Fixture expectation broadened to both valid reject paths; production code unchanged. Original failed log preserved.',
    actual_source_body_reads=0,opaque_transport_body_reads=0,archive_reassemblies=0,historical_archive_central_directory_reads=0,
    historical_decompressions=0,historical_normalizations=0,network_requests=0,targets_generated=0,provider_iteration=0,
    accounts_constructed=0,financial_runs=0,claims_created=0,publication_actions=0,approval_granted=False,
    code_only_test_CPU_affinity=[8],qualifying_actual_source_bodies=False,
    minimum_next_step='Review this exact plan and minimal adapter-seam proposal; await complete opaque transport; then request separate source-only stage authorization.'))
for row in observed:assert pin(ROOT/row['path'])==row
print(json.dumps(dict(status=STATUS,selection_ids=180,cache_objects=217,observed_metadata_code_files=len(observed),source_body_reads=0,normalized_expected_bytes=46269167,conservative_additional_disk_cap=210819423),indent=2))
