"""Metadata/code-only internal consistency checks. No historical body access."""
from pathlib import Path
import ast
import hashlib
import json

P=Path(__file__).resolve().parent
ROOT=P.parent
checks=[]
def load(n):return json.loads((P/n).read_text())
def test(name,condition):
    if not condition:raise AssertionError(name)
    checks.append(dict(check=name,status='PASS'))

sel=load('EXACT_SELECTION_CONTRACT.json')
old=json.loads((ROOT/'full2025_remaining_source_plan_20261015/SOURCE_SELECTION_ALLOWLIST.json').read_text())
test('exact180_original_selectors_unchanged',sel['selectors']==old['selectors'] and len(sel['selectors'])==180)
test('exact_source_index_pin',sel['source_index_SHA256']=='8a0235e428902f7a0ea4ec1893343abae6ccc23715080771796b54fb58f1f3c4')
test('raw_bytes',sum(x['bytes'] for x in sel['selectors'])==164005246)
test('funding_expected_events',sum(x.get('expected_events',0) for x in sel['selectors'])==5475)
test('january_reuse',sel['january_reuse']['archives']==10 and sel['january_reuse']['raw_bytes']==14037027 and sel['january_reuse']['repeat_downloads']==0)
cache=load('CACHE_BINDING_SPEC.json')
test('exact217_cache_map',len(cache['objects'])==217 and len({x['cache_path'] for x in cache['objects']})==217 and sum(x['expected']['bytes'] for x in cache['objects'])==156670939)
test('cache_lineage_declared',all(x['original_commit'] and x['original_path'] for x in cache['objects']))
warm=sel['past_warmup'];proj=warm['row_projection']
test('warmup_past_only_before_body_gate',warm['container_source_available_us_bounds'][1]==1735689600000000 and warm['forbidden_future_or_holdout_rows_in_container']==0 and 'Before opening' in warm['predicate_before_body_access'])
test('warmup_exact200',proj['expected_rows']==200 and proj['close_available_us_max_inclusive']-proj['close_available_us_min_inclusive']==199*86400000000)
f=load('JAN_DEC_ORIGINAL_D_NINE_FEASIBILITY.json')
test('strict2025_calendar',f['calendar_us']==[1735689600000000,1767225600000000] and f['days']==365)
test('exactnine_configs',len(f['configurations'])==9 and len(set(f['configurations']))==9)
test('five_asset_minute_grid',f['minute_open_us_contract']['count_per_asset']==525600 and f['minute_open_us_contract']['total_trade_and_mark_rows']==5256000)
e=f['endpoint'];test('genuineDec31_endpoint_without2026cube',e['open_us']==1767225540000000 and e['completed_available_us']==1767225600000000 and e['selected_2026_daily_cube_rows']==0 and not e['end_plus_one_witness_is_execution_authority'])
q=load('QUALIFICATION_CHECKS.json');test('canonical15_source_only_expectedbytes',len(q['canonical_expected_source_files'])==15 and sum(x['bytes'] for x in q['canonical_expected_source_files'])==46269167)
gap=load('NEW_2025_GAP_STOP_POLICY.json')
test('new2025gap_stop_no2022inheritance',gap['no_2022_exact27_allowlist_or_overlay_import'] and gap['no_automatic_imputation'] and gap['no_automatic_new_gap_policy'])
a=load('SELECTOR_SCHEMA_PROVENANCE_AUDIT.json')
test('allselectors_schema_provenance_limits_declared',a['selectors_with_declared_validate_columns']==180 and a['january_selectors_with_inherited_source_commit']==10 and a['selectors_with_predeclared_inner_CRC']==0 and not a['future_inspection_is_authorized'])
r=load('PRESERVED_RULES_AND_ASSUMPTIONS.json')
test('originalD_frozen_no_monitor_reuse',r['original_D']['rule_SHA256']=='5fb0b20494269da55ea705c9f3f8aaa7270d132eb3d566eb81a29cb0466b1fc8' and not r['original_D']['forecast_monitor_used'] and not r['original_D']['rejected_policy_reuse'])
test('funding_units_coverage_ownership_separate',r['funding']['source_rate_unit']=='UNCONFIRMED' and not r['funding']['source_coverage_implies_ownership'] and not r['clock']['historical_publication_arrival_certified'])
b=load('BYTE_DISK_RUNTIME_BOUNDS.json')['additional_disk_bytes']
test('exact_conservative_disk_bound',b['exact_base_all_reassemblies_plus_normalized']==201382239 and b['total_conservative_output_reservation']==210819423 and b['requested_output_hard_cap']==268435456)
nextstage=load('NEXT_STAGE_AUTHORIZATION_REQUIREMENTS.json')
test('no_stage_or_financial_authority',not nextstage['approval_granted'] and not nextstage['exact_scope']['historical_GO'] and nextstage['exact_scope']['targets_generated']==0 and nextstage['exact_scope']['accounts_constructed']==0)
obs=load('OBSERVED_METADATA_CODE_PINS.json')
for row in obs['observed_metadata_code_files']:
    p=ROOT/row['path'];raw=p.read_bytes()
    test('observed_metadata_code_pin:'+row['path'],len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['SHA256'])
for p in P.glob('*.py'):
    ast.parse(p.read_text());test('syntax:'+p.name,True)
for name,count in [('EXISTING_GUARD_TESTS.log',4),('SYNTHETIC_SOURCE_TESTS.log',18)]:
    log=(P/name).read_text();test('synthetic_log:'+name,'Ran '+str(count)+' tests' in log and '\nOK\n' in log and 'FAILED' not in log)
receipt=dict(status='PASS_METADATA_CODE_CONSISTENCY_ONLY',checks=checks,PASS_count=len(checks),FAIL_count=0,
    source_body_reads=0,opaque_transport_body_reads=0,historical_archive_inspections=0,historical_decompressions=0,
    original_adapter_edits=0,new_seam_implementation_certified=False,actual_source_qualification=False,approval_granted=False)
(P/'METADATA_CONSISTENCY_REVIEW.json').write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k!='checks'},indent=2))
