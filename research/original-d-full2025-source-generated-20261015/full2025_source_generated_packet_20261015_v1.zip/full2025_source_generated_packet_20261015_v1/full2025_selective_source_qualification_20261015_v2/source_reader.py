"""Immutable source-array schema reader. Deliberately exposes no provider iterator."""
import io
import json
from pathlib import Path
import zipfile
import numpy as np

from contracts import (START, END, DAY, MINUTE, SYMBOLS, INDEX_SHA, INNER_CAP,
    require, read_exact, relative_path, digest, json_object, require_actual_scope,
    require_frozen_contract, exact_month_predicate)
from selection import safe_zip_info


def numeric_npz_bytes(raw, expected_keys, *, shapes, dtypes):
    """No array body opened until the entire exact numeric member schema passes."""
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        infos = archive.infolist()
        names = [i.filename for i in infos]
        require(len(names) == len(set(names)) and set(names) == {k + '.npy' for k in expected_keys},
                'UNDECLARED_ARRAY_ARCHIVE_SCHEMA')
        for info in infos:
            safe_zip_info(info, expected_name=info.filename, cap=INNER_CAP)
        # Numeric .npy headers must fit the declared shape before any allocation.
        # Only exact permitted array members are opened, never an unknown member.
        for info in infos:
            key = info.filename[:-4]
            with archive.open(info, 'r') as stream:
                version = np.lib.format.read_magic(stream)
                require(version in ((1, 0), (2, 0)), 'UNSUPPORTED_NUMPY_ARRAY_VERSION')
                reader = np.lib.format.read_array_header_1_0 if version == (1, 0) else np.lib.format.read_array_header_2_0
                shape, fortran, dtype = reader(stream, max_header_size=4096)
                require(shape == tuple(shapes[key]) and dtype == np.dtype(dtypes[key]) and not dtype.hasobject and not fortran,
                        'ARRAY_HEADER_DTYPE_OR_SHAPE:' + key)
                payload = int(np.prod(shape, dtype=np.int64))*dtype.itemsize
                require(stream.tell()+payload == info.file_size and info.file_size <= INNER_CAP,
                        'ARRAY_DECLARED_PAYLOAD_SIZE:' + key)
    # Load exclusively from the immutable verified byte capture, never the path again.
    with np.load(io.BytesIO(raw), allow_pickle=False) as archive:
        require(set(archive.files) == set(expected_keys), 'UNDECLARED_ARRAY_KEYS')
        arrays = {}
        for key in expected_keys:
            array = archive[key]
            require(array.dtype == np.dtype(dtypes[key]) and array.shape == tuple(shapes[key]),
                    'ARRAY_DTYPE_OR_SHAPE:' + key)
            require(np.isfinite(array).all(), 'NONFINITE_SOURCE_ARRAY:' + key)
            array.flags.writeable = False
            arrays[key] = array
    return arrays


def monthly_arrays(path, pin, expected_keys, *, month_lo, minutes, scope):
    require_actual_scope(scope)
    stamp = Path(path).stem
    exact_month_predicate(stamp, month_lo, minutes)
    require(Path(path) == scope.output/'prepared_2025/months'/(stamp+'.npz'), 'EXACT_MONTH_SOURCE_PATH')
    checks = __import__('contracts').frozen_metadata('QUALIFICATION_CHECKS.json')
    require(pin == next((p for p in checks['canonical_expected_source_files'] if p['file'] == 'months/'+stamp+'.npz'), None) and
            expected_keys == checks['schema']['monthly_keys'], 'EXACT_MONTH_SOURCE_PIN_AND_FIELDS')
    raw = read_exact(path, pin['bytes'], pin['SHA256'])
    arrays = numeric_npz_bytes(raw, expected_keys,
        shapes={k: (minutes,) for k in expected_keys},
        dtypes={k: 'int64' if k == 'times' else 'float64' for k in expected_keys})
    require(np.array_equal(arrays['times'], np.arange(month_lo, month_lo + minutes*MINUTE, MINUTE, dtype=np.int64)),
            'MONTHLY_EXACT_GRID')
    for key, array in arrays.items():
        if key != 'times':
            require((array >= 0).all() if key.endswith('_quote_volume') else (array > 0).all(),
                    'INVALID_SOURCE_PRICE_OR_VOLUME:' + key)
    return arrays


def warmup_projection(raw, contract):
    """The exact past-only container has no future row, mark, model, or label."""
    require(len(raw) == contract['bytes'] and digest(raw) == contract['SHA256'], 'PAST_ONLY_WARMUP_IDENTITY')
    require(contract['exact_array_keys'] == ['close_available_us', 'close'] and
            contract['container_source_available_us_bounds'] == [1686873600000000, START] and
            contract['forbidden_future_or_holdout_rows_in_container'] == 0, 'PAST_ONLY_CONTAINER_DECLARATION')
    arrays = numeric_npz_bytes(raw, ['close_available_us', 'close'],
        shapes={'close_available_us': (566,), 'close': (566, 5)},
        dtypes={'close_available_us': 'int64', 'close': 'float64'})
    clocks, closes = arrays['close_available_us'], arrays['close']
    require(np.array_equal(clocks, np.arange(1686873600000000, START + DAY, DAY, dtype=np.int64)),
            'PAST_ONLY_WARMUP_CLOCK_SUPPORT')
    require((closes > 0).all(), 'INVALID_PAST_TRADE_CLOSE')
    p = contract['row_projection']
    require(p['expected_rows'] == 200 and p['expected_shape'] == [200, 5] and
            tuple(p['symbol_order']) == SYMBOLS and p['close_available_us_max_inclusive'] == START,
            'EXACT_200_CLOSE_PROJECTION_DECLARATION')
    choose = (clocks >= START - 199*DAY) & (clocks <= START)
    selected_clocks, selected_closes = clocks[choose].copy(), closes[choose].copy()
    require(selected_clocks.shape == (200,) and selected_closes.shape == (200, 5), 'EXACT_200_PAST_ROWS')
    return selected_clocks, selected_closes


def window_proof(warm_clocks, warm_close, completed_closes):
    """365 structural past-close windows; no covariance, targets, or D entry."""
    require(warm_clocks.dtype == np.dtype('int64') and warm_close.dtype == np.dtype('float64') and
        warm_clocks.shape == (200,) and warm_close.shape == (200, 5), 'WARMUP_WINDOW_SCHEMA')
    require(np.array_equal(warm_clocks, np.arange(START-199*DAY, START+DAY, DAY, dtype=np.int64)), 'WARMUP_WINDOW_CLOCK')
    expected = np.arange(START+DAY, END+DAY, DAY, dtype=np.int64)
    require(set(completed_closes) == set(map(int, expected)), 'EXACT_365_NATIVE_COMPLETED_CLOSES')
    clocks = np.concatenate((warm_clocks, expected))
    closes = np.vstack((warm_close, np.array([completed_closes[int(t)] for t in expected], dtype=np.float64)))
    require(closes.shape == (565, 5) and np.isfinite(closes).all() and (closes > 0).all(), 'WINDOW_CLOSE_VALUES')
    proofs = []
    for decision in range(START, END, DAY):
        last = int(np.searchsorted(clocks, decision, side='right'))
        selected_t, selected_c = clocks[last-200:last], closes[last-200:last]
        require(selected_t.shape == (200,) and selected_c.shape == (200, 5) and
                selected_t[-1] == decision and np.all(np.diff(selected_t) == DAY) and
                np.all(selected_t <= decision), 'EXACT_PAST_200_WINDOW_FAILED')
        proofs.append(dict(decision_us=decision, rows=200, first_available_us=int(selected_t[0]),
            last_available_us=int(selected_t[-1]), close_matrix_SHA256=digest(selected_c.tobytes()),
            clocks_SHA256=digest(selected_t.tobytes()), nonimputed_trade_closes=True))
    require(len(proofs) == 365, 'EXACT_365_WINDOWS_REQUIRED')
    return proofs


class ImmutableSourceReader:
    """Internal qualification reader; downstream iteration is separately gated."""
    def __init__(self, scope, source_root, checks):
        require_actual_scope(scope)
        require_frozen_contract(checks, 'QUALIFICATION_CHECKS.json')
        require(Path(source_root) == scope.output / 'prepared_2025', 'EXACT_SOURCE_STAGING_ROOT')
        self.scope, self.root, self.checks = scope, Path(source_root), checks
        self._checks_sha = digest(json.dumps(checks, sort_keys=True).encode())
        self._pins = {p['file']: dict(p) for p in checks['canonical_expected_source_files']}
        self.index = json_object(read_exact(self.root/'SOURCE_INDEX.json', 83031, INDEX_SHA))
        require(self.index['calendar'] == [START, END] and tuple(self.index['symbol_order']) == SYMBOLS,
                'EXACT_SOURCE_TIME_AND_SYMBOLS')
    def month(self, stamp, month_lo, minutes):
        require_actual_scope(self.scope)
        require_frozen_contract(self.checks, 'QUALIFICATION_CHECKS.json')
        require(digest(json.dumps(self.checks, sort_keys=True).encode()) == self._checks_sha,
                'SOURCE_READER_CONTRACT_MUTATED')
        require(self._pins == {p['file']: p for p in self.checks['canonical_expected_source_files']},
                'SOURCE_READER_PINS_MUTATED')
        exact_month_predicate(stamp, month_lo, minutes)
        name = 'months/' + stamp + '.npz'
        require(name in self._pins and stamp.startswith('2025-'), 'UNDECLARED_SOURCE_MONTH')
        return monthly_arrays(relative_path(self.root, name), self._pins[name],
            self.checks['schema']['monthly_keys'], month_lo=month_lo, minutes=minutes, scope=self.scope)
    def minute_blocks(self, *args, **kwargs):
        self.scope.guard.deny('actual_provider_calls', 'ImmutableSourceReader.minute_blocks')
    def historical_scope(self, *args, **kwargs):
        self.scope.guard.deny('historical_scope_mints', 'ImmutableSourceReader.historical_scope')
