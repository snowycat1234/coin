"""Exact selected-archive adapter; no extraction, discovery, or whole-ZIP CRC scan."""
from pathlib import Path, PurePosixPath
from copy import deepcopy
import hashlib
import io
import json
import os
import stat
import zipfile

from contracts import (ROOT, NATIVE, PLAN, INNER_CAP, META_CAP, MINUTE, START, END,
    QualificationStop, require, digest, read_exact, relative_path, opaque_identity,
    json_object, no_symlink, require_actual_scope, require_frozen_contract)


def safe_zip_info(info, *, expected_name, cap, expected_size=None, expected_crc=None):
    """Central-directory predicates run before opening this selected body."""
    name = info.filename
    require(type(name) is str and name == expected_name and info.orig_filename == name, 'EXACT_ZIP_MEMBER_REQUIRED')
    require(name and '\\' not in name and '\0' not in name and ':' not in name,
            'UNSAFE_ZIP_MEMBER_NAME')
    p = PurePosixPath(name)
    require(not p.is_absolute() and all(x not in ('', '.', '..') for x in name.split('/')),
            'UNSAFE_ZIP_MEMBER_PATH')
    mode = info.external_attr >> 16
    require(stat.S_IFMT(mode) in (0, stat.S_IFREG) and not info.is_dir() and not (info.external_attr & 0x10), 'REGULAR_ZIP_MEMBER_REQUIRED')
    require(not (info.flag_bits & 1), 'ENCRYPTED_ZIP_MEMBER_FORBIDDEN')
    require(info.compress_type in (zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED), 'UNSUPPORTED_COMPRESSION')
    require(0 < info.file_size <= cap and 0 <= info.compress_size <= cap, 'ZIP_DECOMPRESSION_CAP')
    if expected_size is not None:
        require(info.file_size == expected_size, 'SELECTED_ZIP_SIZE_MISMATCH')
    if expected_crc is not None:
        require(info.CRC == expected_crc, 'SELECTED_ZIP_CRC_METADATA_MISMATCH')
    return dict(member=name, bytes=info.file_size, compressed_bytes=info.compress_size,
                CRC=info.CRC, compression=info.compress_type, regular=True, encrypted=False)


def exact_zip_metadata(archive, required):
    infos = archive.infolist()
    names = [info.filename for info in infos]
    require(len(names) == len(set(names)), 'DUPLICATE_ZIP_MEMBER_NAMES')
    require(set(required).issubset(names), 'MISSING_EXACT_SELECTED_MEMBER')
    return {name: archive.getinfo(name) for name in required}


def inner_metadata(raw, selector, expected_basename):
    require(len(raw) == selector['bytes'] and digest(raw) == selector['SHA256'], 'RAW_ARCHIVE_IDENTITY_MISMATCH')
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        require(len(archive.infolist()) == 1, 'EXACT_SINGLE_INNER_CSV_REQUIRED')
        return safe_zip_info(archive.infolist()[0], expected_name=expected_basename, cap=INNER_CAP)


def selected_read(archive, allow, name, *, cap, size=None, crc=None, observed=None):
    """Pure seam usable with in-memory generated ZIPs; checks before backend read."""
    require(name in allow, 'EXCLUDED_MEMBER_BODY_REQUEST:' + name)
    infos = exact_zip_metadata(archive, allow)
    metadata = safe_zip_info(infos[name], expected_name=name, cap=cap,
                             expected_size=size, expected_crc=crc)
    with archive.open(infos[name], 'r') as stream:
        body = stream.read(cap + 1)
    require(len(body) == metadata['bytes'] and len(body) <= cap, 'SELECTED_MEMBER_SIZE_MISMATCH')
    # ZipExtFile validates this selected member's CRC at EOF. No other body is read.
    if observed is not None:
        observed.append(dict(**metadata, SHA256=digest(body), selected_CRC_checked_to_EOF=True))
    return body


H1_ORIGINAL_COMMIT = 'd69e9ac94478c5be54cb46c622afec7aaf3c61f7'
H1_ORIGINAL_DIRECTORY = 'research_artifacts/frozen_e5_2025h1_20261008/'
H1_INDEX_SHA = 'cfe6dac4f351d43237c61053ec0103069934c863317a1b5708e5e05af5915611'


def exact_h1_cache_routes(cache_contract, h1_index):
    """Metadata-only exact join; no directory search or alternate-path fallback."""
    parts = h1_index['parts']
    expected_names = {'coin_frozen_e5_2025h1_increment_20261008.zip.bytepart' + f'{i:03d}' for i in range(9)}
    require(len(parts) == 9 and {p['file_name'] for p in parts} == expected_names,
            'EXACT_NINE_H1_INDEX_PARTS_REQUIRED')
    routes = {}
    for part in parts:
        filename = part['file_name']
        original_path = H1_ORIGINAL_DIRECTORY + filename
        matches = [row for row in cache_contract['objects']
                   if row['original_path'] == original_path and row['original_commit'] == H1_ORIGINAL_COMMIT]
        require(len(matches) == 1, 'EXACT_UNIQUE_H1_ORIGINAL_CACHE_MAPPING_REQUIRED:' + filename)
        row = matches[0]
        expected = dict(bytes=part['bytes'], SHA256=part['sha256'], GitBlobSHA1=part['git_blob_sha1'])
        require(row['expected'] == expected, 'H1_ORIGINAL_CACHE_IDENTITY_CONFLICT:' + filename)
        relative_path(ROOT, row['cache_path'])
        routes[filename] = row['cache_path']
    require(len(set(routes.values())) == 9, 'EXACT_UNIQUE_H1_CACHE_PATHS_REQUIRED')
    return routes


def pinned_h1_index():
    return json_object(read_exact(NATIVE/'metadata/H1_INDEX.json', 3939, H1_INDEX_SHA))


class ExactCache:
    def __init__(self, scope, cache_contract, transport_receipt, cache_index):
        require_actual_scope(scope)
        require_frozen_contract(cache_contract, 'CACHE_BINDING_SPEC.json')
        self.scope = scope
        self._contract = deepcopy(cache_contract)
        self._contract_sha = digest(json.dumps(self._contract, sort_keys=True).encode())
        require(len(self._contract['objects']) == 217, 'EXACT_217_CACHE_REQUIRED')
        self._objects = {item['cache_path']: deepcopy(item) for item in self._contract['objects']}
        require(len(self._objects) == 217, 'DUPLICATE_CACHE_PATHS')
        require(transport_receipt['schema'] == 'FULL2025_BOUNDED_OPAQUE_SOURCE_TRANSPORT_RECEIPT_V1' and
            transport_receipt['status'] == 'PASS_OPAQUE_TRANSPORT_ONLY_EXTRACTION_AND_SOURCE_QUALIFICATION_PENDING',
            'COMPLETE_EXACT_TRANSPORT_RECEIPT_REQUIRED')
        for key, value in dict(all_exact_opaque_objects=217, all_exact_opaque_bytes=156670939,
            new_exact_objects=212, new_exact_bytes=114727899, reused_exact_objects=5,
            reused_exact_bytes=41943040, origin_200_responses=212, failed_objects=0,
            retries=0, redirects=0, alternate_routes=0).items():
            require(type(transport_receipt.get(key)) is int and transport_receipt[key] == value,
                    'TRANSPORT_COMPLETION_FIELD:' + key)
        require(transport_receipt['frozen_request_manifest_SHA256'] ==
            '67a6ce9f91acfc37fc4abedd17f2be9c8b0543b03a64336de1ba87c76337a110', 'TRANSPORT_MANIFEST_BINDING')
        require(not (ROOT / 'full2025_bounded_source_transport_20261015/STOP.json').exists(), 'TRANSPORT_STOP_EXISTS')
        require(cache_index['schema'] == 'FULL2025_OPAQUE_SOURCE_CACHE_INDEX_V1', 'EXACT_CACHE_INDEX_SCHEMA')
        rows = cache_index['cache_objects']
        require(len(rows) == 217 and len({row['cache_path'] for row in rows}) == 217, 'CACHE_INDEX_CARDINALITY')
        for row in rows:
            require(row['cache_path'] in self._objects, 'UNDECLARED_CACHE_OBJECT')
            item = self._objects[row['cache_path']]
            require({k: row[k] for k in ('bytes', 'SHA256', 'GitBlobSHA1')} == item['expected'] and
                    row['commit'] == item['original_commit'] and row['path'] == item['original_path'],
                    'CACHE_INDEX_LINEAGE_MISMATCH')
        self._h1_routes = exact_h1_cache_routes(self._contract, pinned_h1_index())
        self.rehash = []
        for path, item in self._objects.items():
            scope.check()
            observed = opaque_identity(relative_path(ROOT, path), item['expected'])
            self.rehash.append(dict(cache_path=path, **observed))
            scope.observed['opaque_objects_rehashed'] += 1
            scope.observed['opaque_bytes_rehashed'] += observed['bytes']
        require(scope.observed['opaque_objects_rehashed'] == 217 and
                scope.observed['opaque_bytes_rehashed'] == 156670939, 'ALL_OPAQUE_REHASH_REQUIRED')
        scope.guard.checkpoint('ALL_217_OPAQUE_IDENTITIES_REHASHED')
    def _check(self):
        require_actual_scope(self.scope)
        require_frozen_contract(self._contract, 'CACHE_BINDING_SPEC.json')
        require(digest(json.dumps(self._contract, sort_keys=True).encode()) == self._contract_sha,
                'CACHE_CONTRACT_MUTATED')
        require(self._objects == {item['cache_path']: item for item in self._contract['objects']},
                'CACHE_RESOLVER_MUTATED')
        require(self._h1_routes == exact_h1_cache_routes(self._contract, pinned_h1_index()),
                'H1_ORIGINAL_CACHE_MAPPING_MUTATED')
    def bytes(self, exact_path):
        self._check()
        require(exact_path in self._objects, 'NONALLOWLISTED_CACHE_PATH')
        item = self._objects[exact_path]
        # Capture the exact immutable bytes consumed; later path swaps cannot alter them.
        raw = read_exact(relative_path(ROOT, exact_path), item['expected']['bytes'], item['expected']['SHA256'])
        git = hashlib.sha1(('blob ' + str(len(raw)) + '\0').encode() + raw).hexdigest()
        require(git == item['expected']['GitBlobSHA1'], 'CACHE_GIT_IDENTITY_CHANGED')
        return raw
    def h1_part(self, filename):
        self._check()
        require(type(filename) is str and filename in self._h1_routes,
                'EXACT_ALLOWLISTED_H1_INDEX_FILENAME_REQUIRED')
        return self.bytes(self._h1_routes[filename])
    def h2_part(self, filename):
        return self.bytes('full2025_bounded_source_transport_20261015/transport/H2/' + filename)


class SelectedSources:
    def __init__(self, scope, contract, cache):
        require_actual_scope(scope)
        require_frozen_contract(contract, 'EXACT_SELECTION_CONTRACT.json')
        require(type(cache) is ExactCache and cache.scope is scope, 'EXACT_ISSUED_CACHE_REQUIRED')
        self.scope, self.cache = scope, cache
        self._contract = deepcopy(contract)
        self._sha = digest(json.dumps(self._contract, sort_keys=True).encode())
        self._selectors = {s['selection_id']: deepcopy(s) for s in contract['selectors']}
        self._provenance = {s['selection_id']: deepcopy(s) for s in contract['provenance_supplement']}
        self._wrappers, self._allowed, self._used = {}, {}, set()
        self._wrapper_snapshots = {}
        self.reads, self.raw_proofs = [], []
        # Reassemble exactly one pinned H1 wrapper under unadmitted source staging.
        from contracts import json_object
        h1 = json_object(read_exact(NATIVE/'metadata/H1_INDEX.json', 3939,
            'cfe6dac4f351d43237c61053ec0103069934c863317a1b5708e5e05af5915611'))
        h1path = scope.output / 'H1_2025.zip'
        with h1path.open('xb') as stream:
            for part in h1['parts']:
                raw = cache.h1_part(part['file_name'])
                require(len(raw) == part['bytes'] and digest(raw) == part['sha256'], 'H1_PART_IDENTITY')
                stream.write(raw)
                scope.check()
        require(h1path.stat().st_size == h1['original_bytes'], 'H1_AGGREGATE_SIZE')
        from contracts import open_regular
        scope.observed['archive_reassemblies'] += 1
        self.h1path = h1path
        self.fund_raw = cache.bytes('full2025_bounded_source_transport_20261015/transport/PRIMITIVES.zip')
        for selector in self._selectors.values():
            if 'member' not in selector:
                continue
            key = self._wrapper_key(selector)
            self._allowed.setdefault(key, set()).add(selector['member'])
            if 'checksum_member' in selector:
                self._allowed[key].add(selector['checksum_member'])
        wrapper_sha = {'H1': h1['original_sha256']}
        wrapper_sha.update({pin['path']: pin['SHA256'] for pin in contract['january_reuse']['wrapper_pins']})
        for key, names in self._allowed.items():
            if key == 'H1':
                source = open_regular(h1path)
            elif key == 'FUNDING':
                source = io.BytesIO(self.fund_raw)
            else:
                source = open_regular(relative_path(ROOT, key))
            if key != 'FUNDING':
                before = os.fstat(source.fileno())
                sha = hashlib.sha256()
                for block in iter(lambda: source.read(1024*1024), b''):
                    sha.update(block)
                after = os.fstat(source.fileno())
                snapshot = lambda st: (st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns, st.st_ctime_ns)
                require(snapshot(before) == snapshot(after) and sha.hexdigest() == wrapper_sha[key],
                        'EXACT_SAME_HANDLE_WRAPPER_IDENTITY')
                self._wrapper_snapshots[key] = snapshot(after)
                source.seek(0)
            archive = zipfile.ZipFile(source)
            try:
                infos = exact_zip_metadata(archive, names)
                for name, info in infos.items():
                    # All declared selected metadata is checked before any selected body.
                    selectors = [s for s in self._selectors.values() if self._wrapper_key(s) == key and s.get('member') == name]
                    if selectors:
                        sel = selectors[0]
                        safe_zip_info(info, expected_name=name, cap=INNER_CAP, expected_size=sel['bytes'], expected_crc=sel.get('CRC'))
                    else:
                        safe_zip_info(info, expected_name=name, cap=4096)
            except BaseException:
                archive.close(); source.close(); raise
            self._wrappers[key] = archive, source
        scope.guard.checkpoint('SELECTED_OUTER_METADATA_PASSED_NO_BODIES_YET')
    def _wrapper_key(self, selector):
        transport = selector['transport']
        if transport == 'H1_WRAPPER': return 'H1'
        if transport == 'FUNDING_PRIMITIVES': return 'FUNDING'
        if transport == 'REUSE_LOCAL_TAIL_WRAPPER': return selector['wrapper']
        return None
    def _check(self):
        require_actual_scope(self.scope)
        require_frozen_contract(self._contract, 'EXACT_SELECTION_CONTRACT.json')
        require(digest(json.dumps(self._contract, sort_keys=True).encode()) == self._sha,
                'SELECTOR_CONTRACT_MUTATED')
        require(self._selectors == {s['selection_id']: s for s in self._contract['selectors']} and
                self._provenance == {s['selection_id']: s for s in self._contract['provenance_supplement']},
                'SELECTOR_AUTHORITY_MUTATED')
        expected = {}
        for selector in self._selectors.values():
            if 'member' in selector:
                key = self._wrapper_key(selector)
                expected.setdefault(key, set()).add(selector['member'])
                if 'checksum_member' in selector: expected[key].add(selector['checksum_member'])
        require(self._allowed == expected, 'WRAPPER_MEMBER_ALLOWLIST_MUTATED')
        for key, snapshot in self._wrapper_snapshots.items():
            source = self._wrappers[key][1]
            stat_now = os.fstat(source.fileno())
            path = self.h1path if key == 'H1' else relative_path(ROOT, key)
            path_now = os.stat(no_symlink(path), follow_symlinks=False)
            observed = lambda st: (st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns, st.st_ctime_ns)
            require(observed(stat_now) == snapshot and observed(path_now) == snapshot,
                    'VERIFIED_WRAPPER_CHANGED_AFTER_HASH')
    def raw(self, selection_id):
        self._check()
        require(selection_id in self._selectors and selection_id not in self._used, 'EXACT_UNUSED_SELECTION_REQUIRED')
        selector = self._selectors[selection_id]
        if selector['transport'] == 'H2_RAW_PARTS':
            reassembly = selector['reassembly']
            raw = b''.join(self.cache.h2_part(p['file']) for p in reassembly['parts'])
            checksum = self.cache.h2_part(reassembly['checksum_file'])
            require(digest(checksum) == reassembly['checksum_SHA256'], 'H2_CHECKSUM_IDENTITY')
            self.scope.observed['archive_reassemblies'] += 1
            self.scope.observed['selected_checksum_bodies'] += 1
        else:
            key = self._wrapper_key(selector)
            archive = self._wrappers[key][0]
            raw = selected_read(archive, self._allowed[key], selector['member'], cap=INNER_CAP,
                size=selector['bytes'], crc=selector.get('CRC'), observed=self.reads)
            self.scope.observed['selected_outer_bodies'] += 1
            checksum = None
            if 'checksum_member' in selector:
                checksum = selected_read(archive, self._allowed[key], selector['checksum_member'],
                    cap=4096, observed=self.reads)
                self.scope.observed['selected_checksum_bodies'] += 1
        require(len(raw) == selector['bytes'] and digest(raw) == selector['SHA256'], 'SELECTED_RAW_SHA_SIZE')
        if checksum is not None:
            fields = checksum.decode('ascii').split()
            expected = (selector['symbol'] + '-1m-' + selector['month'] + '.zip')
            require(len(fields) == 2 and fields[0] == selector['SHA256'] and fields[1].lstrip('*') == expected,
                    'OFFICIAL_CHECKSUM_BINDING')
        self._check()
        inner = inner_metadata(raw, selector, self._provenance[selection_id]['expected_inner_csv_basename'])
        self.scope.observed['inner_decompressed_bytes'] += inner['bytes']
        require(self.scope.observed['inner_decompressed_bytes'] <= 12079595520, 'AGGREGATE_DECOMPRESSION_CAP')
        self._used.add(selection_id)
        buffer = io.BytesIO(raw)
        buffer.name = selector.get('raw_path', selector.get('member', 'source.zip'))
        proof = dict(selection_id=selection_id, symbol=selector['symbol'], family=selector['family'],
            month=selector['month'], raw_bytes=len(raw), raw_SHA256=digest(raw), inner_metadata=inner,
            source_commit=self._provenance[selection_id]['source_commit'],
            inherited_commit_reason=self._provenance[selection_id]['inherited_commit_reason'],
            source_lineage={k:selector[k] for k in ('transport','wrapper','wrapper_SHA256','member','raw_path','checksum_member') if k in selector},
            original_source_index_SHA256=self._contract['source_index_SHA256'],
            inner_size_and_CRC_status='OBSERVED_ONLY_AFTER_AUTHORIZED_SELECTED_CENTRAL_DIRECTORY')
        return buffer, proof
    def consumed(self, proof, rows):
        # Called only after unchanged numeric_csv returns; selected-inner EOF/CRC passed.
        self.scope.observed['selected_inner_bodies'] += 1
        self.raw_proofs.append(dict(**proof, rows=rows, selected_inner_CRC_checked_to_EOF=True))
    def close(self):
        for archive, source in self._wrappers.values():
            archive.close(); source.close()
