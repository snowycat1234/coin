"""Source-only adaptation of frozen normalization. No financial import graph."""
import json
from pathlib import Path
import time
import numpy as np

from contracts import (ROOT, NATIVE, START, END, DAY, MINUTE, SYMBOLS, INDEX_SHA,
    NORMALIZER_SHA, require, digest, read_exact, save_new, pure_normalizer,
    require_actual_scope, require_frozen_contract)
from selection import ExactCache, SelectedSources
from source_reader import monthly_arrays, warmup_projection, window_proof, ImmutableSourceReader


class SourceGapStop(ValueError):
    def __init__(self, classification):
        self.classification = classification
        super().__init__('NEW_2025_SOURCE_GAP_FAIL_CLOSED:' + classification['classification'])


def gap_classification(frame, expected, selector, proof=None, *, classification='MINUTE_GRID_DIFFERENCE', detail=None):
    observed = frame.timestamp_ms.to_numpy(dtype=np.int64)*1000
    unique = np.unique(observed)
    missing, extra = np.setdiff1d(expected, unique), np.setdiff1d(unique, expected)
    fields = ['open', 'close', 'quote_volume'] if selector['family'] == 'klines' else ['close']
    runs = []
    if len(missing):
        groups = np.split(missing, np.where(np.diff(missing) != MINUTE)[0]+1)
        ordered = frame.sort_values('timestamp_ms').drop_duplicates('timestamp_ms')
        clocks = ordered.timestamp_ms.to_numpy(dtype=np.int64)*1000
        for group in groups:
            prior = int(np.searchsorted(clocks, group[0], side='left'))-1
            following = int(np.searchsorted(clocks, group[-1], side='right'))
            def observation(index):
                if index < 0 or index >= len(clocks): return None
                row = ordered.iloc[index]
                return dict(minute_open_us=int(clocks[index]), values={f:float(row[f]) for f in fields})
            runs.append(dict(first_missing_open_us=int(group[0]), last_missing_open_us=int(group[-1]),
                missing_minutes=len(group), last_genuine_prior_observation=observation(prior),
                first_genuine_next_observation=observation(following)))
    duplicate_mask = frame.duplicated('timestamp_ms', keep=False)
    duplicated = frame[duplicate_mask]
    identical_removed = len(frame)-len(frame.drop_duplicates())
    conflicting = frame.drop_duplicates().duplicated('timestamp_ms', keep=False)
    lineage = {k:selector[k] for k in ('source_commit','raw_path','wrapper','wrapper_SHA256','member','checksum_member','transport') if k in selector}
    return dict(status='NEW_2025_SOURCE_GAP_FAIL_CLOSED', classification=classification, detail=detail,
        selection_id=selector['selection_id'], symbol=selector['symbol'], family=selector['family'], month=selector['month'],
        original_archive_SHA256=selector['SHA256'], original_archive_bytes=selector.get('bytes'), source_lineage=lineage,
        source_commit=(proof or {}).get('source_commit',selector.get('source_commit')),
        exact_missing_expected_minute_open_us=missing.tolist(), exact_extra_minute_open_us=extra.tolist(),
        affected_fields=fields, affected_asset_minute_cells=len(missing), affected_field_cells=len(missing)*len(fields),
        contiguous_missing_runs=runs, affected_stream_count=int(bool(len(missing) or len(extra) or len(duplicated))),
        expected_rows=len(expected), observed_rows=len(frame), unique_observed_rows=len(unique),
        identical_duplicate_rows=identical_removed, conflicting_duplicate_rows=int(conflicting.sum()),
        duplicate_timestamp_us=sorted(set(map(int,duplicated.timestamp_ms.to_numpy(dtype=np.int64)*1000))),
        selected_checksum_status='PASS_EXACT_OFFICIAL_CHECKSUM' if selector['family'] != 'fundingRate' and proof is not None else 'NOT_REACHED',
        selected_outer_CRC_status=('NOT_APPLICABLE_RAW_PART_REASSEMBLY' if selector.get('transport') == 'H2_RAW_PARTS'
                                   else 'PASS_SELECTED_EOF' if proof is not None else 'NOT_REACHED'),
        selected_inner_CRC_status='PASS_SELECTED_EOF' if proof is not None else 'NOT_REACHED',
        original_bytes_preserved=True, stage_halted_before_target_account_provider_use=True,
        imputation_or_2022_policy_reuse=False, new_download_or_retry_authorized=False)


def exact_price_grid(frame, expected, *, selector, proof=None):
    observed = frame.timestamp_ms.to_numpy()*1000
    if not np.array_equal(observed, expected):
        raise SourceGapStop(gap_classification(frame, expected, selector, proof))


def funding_check(events, selectors):
    require(len(events) == 5475, 'EXACT_5475_FUNDING_EVENTS')
    summary = []
    for symbol in SYMBOLS:
        rows = [e for e in events if e['symbol'] == symbol]
        clocks = np.array([e['event_us'] for e in rows], dtype=np.int64)
        require(len(rows) == 1095 and len(set(map(int, clocks))) == 1095, 'EXACT_1095_FUNDING_PER_SYMBOL')
        require(np.all(np.abs(np.diff(clocks) - 8*60*MINUTE) <= 1000000), 'FUNDING_8H_CONTINUITY_OR_GAP')
        nominal = np.arange(START, END, 8*60*MINUTE, dtype=np.int64)
        require(np.all(np.abs(clocks - nominal) <= 1000000), 'FUNDING_CALENDAR_COVERAGE_OR_JITTER')
        require(all(e['reported_interval_hours'] == 8.0 for e in rows), 'FUNDING_REPORTED_INTERVAL_UNEXPECTED')
        for selector in selectors:
            if selector['family'] == 'fundingRate' and selector['symbol'] == symbol:
                year, month = map(int, selector['month'].split('-'))
                import pandas as pd
                lo = int(pd.Timestamp(year=year, month=month, day=1, tz='UTC').value // 1000)
                hi = int((pd.Timestamp(year=year, month=month, day=1, tz='UTC') + pd.offsets.MonthBegin(1)).value // 1000)
                require(sum(lo <= int(t) < hi for t in clocks) == selector['expected_events'], 'FUNDING_EXACT_MONTHLY_COUNT')
        summary.append(dict(symbol=symbol, events=len(rows), min_event_us=int(clocks[0]),
            max_event_us=int(clocks[-1]), max_8h_cadence_jitter_us=int(np.max(np.abs(np.diff(clocks)-8*60*MINUTE))),
            raw_rate_unit='UNCONFIRMED', historical_arrival_certified=False))
    return summary


def strict_past_mark_proof(events, marks):
    proof = []
    for event in events:
        at = event['event_us']
        completed_index = (at - START - 1) // MINUTE - 1
        if completed_index < 0:
            proof.append(dict(symbol=event['symbol'], event_us=at, status='BOUNDARY_PRIOR_MARK_UNKNOWN',
                              prior_mark_fabricated=False))
            continue
        available = START + (completed_index + 1)*MINUTE
        require(0 <= completed_index < 525600 and 0 < at-available <= MINUTE, 'STRICT_PAST_MARK_CLOCK')
        value = float(marks[event['symbol']][completed_index])
        require(np.isfinite(value) and value > 0, 'STRICT_PAST_NATIVE_MARK_VALUE')
        proof.append(dict(symbol=event['symbol'], event_us=at, status='SOURCE_STRICTLY_PAST_MARK_AVAILABLE',
            native_minute_open_us=available-MINUTE, available_us=available,
            gap_us=at-available, raw_mark=value, source_arrival_assumption='CLOSURE_CLOCK_UNCERTIFIED',
            financial_charge_created=False))
    return proof


def run_source_qualification(scope, contract, checks, cache_contract, transport_receipt, cache_index):
    """The launcher owns guard, limits, external authority, final rename, and STOP."""
    require_actual_scope(scope)
    require_frozen_contract(contract, 'EXACT_SELECTION_CONTRACT.json')
    require_frozen_contract(checks, 'QUALIFICATION_CHECKS.json')
    require_frozen_contract(cache_contract, 'CACHE_BINDING_SPEC.json')
    ns, pure_sha = pure_normalizer()
    cache = ExactCache(scope, cache_contract, transport_receipt, cache_index)
    save_new(scope.output/'OPAQUE_CACHE_REHASH_RECEIPT.json', dict(status='PASS_EXACT_217_OPAQUE_IDENTITIES', objects=cache.rehash))
    warm_contract = contract['past_warmup']
    # Opaque identity/schema is past-only before either array body is loaded.
    warm_raw = read_exact(ROOT/warm_contract['file'], warm_contract['bytes'], warm_contract['SHA256'])
    warm_clocks, warm_close = warmup_projection(warm_raw, warm_contract)
    out = scope.output/'prepared_2025'
    out.mkdir(); (out/'months').mkdir()
    np.savez_compressed(scope.output/'SOURCE_WARMUP_200_CLOSE_ONLY.npz',
                        close_available_us=warm_clocks, close=warm_close)
    index_raw = read_exact(NATIVE/'metadata/SOURCE_INDEX.json', 83031, INDEX_SHA)
    index = json.loads(index_raw)
    initial = {symbol: float(warm_close[-1, i]) for i, symbol in enumerate(SYMBOLS)}
    prior, daily, completed_closes, endpoints = {}, [], {}, []
    mark_chunks = {symbol: [] for symbol in SYMBOLS}
    selectors = {(s['month'], s['symbol'], s['family']): s for s in contract['selectors']}
    pins = {p['file']: p for p in checks['canonical_expected_source_files']}
    selected = SelectedSources(scope, contract, cache)
    try:
        for month in range(1, 13):
            scope.check()
            stamp = f'2025-{month:02d}'
            lo, hi = ns['month_limits'](2025, month)
            times = np.arange(lo*1000, hi*1000, MINUTE, dtype=np.int64)
            arrays = dict(times=times)
            for symbol in SYMBOLS:
                for family in ('klines', 'markPriceKlines'):
                    selector = selectors[stamp, symbol, family]
                    raw, proof = selected.raw(selector['selection_id'])
                    raw_frame = ns['numeric_csv'](raw)
                    try:
                        frame, duplicates = ns['validate_price'](raw_frame.copy(), family, lo, hi)
                    except ValueError as exc:
                        classification = gap_classification(raw_frame, times, selector, proof,
                            classification='DUPLICATE_OR_PRICE_VALIDATION_REJECTION', detail=str(exc))
                        save_new(scope.output/'NEW_2025_GAP_CLASSIFICATION.json', classification)
                        raise SourceGapStop(classification) from exc
                    if duplicates != 0:
                        classification = gap_classification(raw_frame, times, selector, proof,
                            classification='IDENTICAL_DUPLICATE_ROWS_FORBIDDEN')
                        save_new(scope.output/'NEW_2025_GAP_CLASSIFICATION.json', classification)
                        raise SourceGapStop(classification)
                    try:
                        exact_price_grid(frame, times, selector=selector, proof=proof)
                    except SourceGapStop as exc:
                        save_new(scope.output/'NEW_2025_GAP_CLASSIFICATION.json', exc.classification)
                        raise
                    selected.consumed(proof, len(frame))
                    if family == 'klines':
                        for field in ('open', 'close', 'quote_volume'):
                            arrays[symbol+'_'+field] = frame[field].to_numpy()
                        for day, at in enumerate(range(lo*1000, hi*1000, DAY)):
                            actual = initial[symbol] if at == START else prior[symbol] if day == 0 else float(frame.close.iloc[day*1440-1])
                            daily.append(dict(symbol=symbol, close_us=at, close=actual))
                            completed_closes.setdefault(at+DAY, [None]*5)[SYMBOLS.index(symbol)] = float(frame.close.iloc[(day+1)*1440-1])
                        prior[symbol] = float(frame.close.iloc[-1])
                    else:
                        arrays[symbol+'_mark'] = frame.close.to_numpy()
                        mark_chunks[symbol].append(frame.close.to_numpy().copy())
            name = 'months/' + stamp + '.npz'
            np.savez_compressed(out/name, **arrays)
            # Exact original canonical bytes, dtype, keys, shape, and month grid.
            verified = monthly_arrays(out/name, pins[name], checks['schema']['monthly_keys'],
                                      month_lo=lo*1000, minutes=len(times), scope=scope)
            scope.observed['canonical_files_written'] += 1
            if month == 12:
                require(int(verified['times'][-1]) == END-MINUTE, 'GENUINE_DEC31_LAST_MINUTE')
                for symbol in SYMBOLS:
                    endpoints.append(dict(symbol=symbol, native_minute_open_us=END-MINUTE,
                        source_available_us=END, trade_close=float(verified[symbol+'_close'][-1]),
                        mark_close=float(verified[symbol+'_mark'][-1]),
                        source_file=name, source_SHA256=pins[name]['SHA256'],
                        role='SOURCE_ENDPOINT_WITNESS_ONLY', feature_row_created=False))
            del frame, arrays, verified
            scope.guard.checkpoint('EXACT_CANONICAL_MONTH_' + stamp)
            print(json.dumps(dict(source_month=stamp, status='EXACT_ORIGINAL_SOURCE_MONTH_PASS')), flush=True)
        events = []
        for symbol in SYMBOLS:
            for month in range(1, 13):
                scope.check()
                stamp = f'2025-{month:02d}'
                selector = selectors[stamp, symbol, 'fundingRate']
                lo, hi = ns['month_limits'](2025, month)
                raw, proof = selected.raw(selector['selection_id'])
                frame, duplicates = ns['validate_funding'](ns['numeric_csv'](raw, funding=True), lo, hi)
                require(duplicates == 0 and len(frame) == selector['expected_events'], 'EXACT_FUNDING_COUNT_AND_ZERO_DUPLICATES')
                for row in frame.itertuples(index=False):
                    events.append(dict(symbol=symbol, event_us=int(row.calc_time_ms)*1000,
                        raw_rate=float(row.last_funding_rate), reported_interval_hours=float(row.funding_interval_hours)))
                selected.consumed(proof, len(frame))
        events.sort(key=lambda e: (e['event_us'], e['symbol']))
        funding_summary = funding_check(events, contract['selectors'])
        require(len(daily) == 1825 and all(set(row) == {'symbol','close_us','close'} for row in daily), 'DAILY_EXACT_SCHEMA')
        for row in daily:
            require(START <= row['close_us'] < END and np.isfinite(row['close']) and row['close'] > 0,
                    'DAILY_SOURCE_TIME_VALUE')
            if row['close_us'] != START:
                require(row['close'] == completed_closes[row['close_us']][SYMBOLS.index(row['symbol'])],
                        'DAILY_NATIVE_MINUTE_PARITY')
        for row in events:
            require(set(row) == {'symbol','event_us','raw_rate','reported_interval_hours'} and START <= row['event_us'] < END,
                    'EVENT_EXACT_SCHEMA_TIME')
        save_new(out/'DAILY.json', daily); save_new(out/'EVENTS.json', events)
        with (out/'SOURCE_INDEX.json').open('xb') as stream: stream.write(index_raw)
        scope.observed['canonical_files_written'] += 3
        canonical = []
        for pin in checks['canonical_expected_source_files']:
            read_exact(out/pin['file'], pin['bytes'], pin['SHA256'])
            canonical.append(dict(pin))
        require(len(canonical) == 15 and sum(p['bytes'] for p in canonical) == 46269167,
                'EXACT_15_CANONICAL_SOURCE_FILES_46269167_BYTES')
        reader = ImmutableSourceReader(scope, out, checks)
        # Qualified immutable reader has no financial/provider admission.
        reader.month('2025-12', int(ns['month_limits'](2025,12)[0])*1000, 44640)
        windows = window_proof(warm_clocks, warm_close, completed_closes)
        marks = {symbol: np.concatenate(chunks) for symbol, chunks in mark_chunks.items()}
        require(all(value.shape == (525600,) for value in marks.values()), 'FULL_525600_CORE5_MARK_GRID')
        mark_proofs = strict_past_mark_proof(events, marks)
        require(len(selected.raw_proofs) == 180 and len(selected._used) == 180 and
            scope.observed['selected_inner_bodies'] == 180 and scope.observed['selected_checksum_bodies'] == 120,
            'EXACT_180_SELECTED_ARCHIVES_AND_120_CHECKSUMS')
        save_new(scope.output/'RAW_SELECTED_SOURCE_RECEIPT.json', dict(status='PASS_EXACT_SELECTED_SOURCE_ARCHIVES',
            raw_archives=selected.raw_proofs, wrapper_selected_body_reads=selected.reads,
            inner_metadata_previously_unknown=True, whole_wrapper_testzip_used=False))
        save_new(scope.output/'SOURCE_200_CLOSE_WINDOW_PROOF.json', dict(status='PASS_SOURCE_ONLY_365_PAST_200_CLOSE_WINDOWS',
            symbols=list(SYMBOLS), warmup_source_SHA256=warm_contract['SHA256'], windows=windows,
            targets_generated=False, historical_execution_authorized=False))
        save_new(scope.output/'SOURCE_DEC31_ENDPOINT_WITNESS.json', dict(status='PASS_GENUINE_DEC31_NATIVE_ENDPOINT',
            endpoints=endpoints, no_2026_daily_cube_row=True, no_execution_authority=True))
        save_new(scope.output/'SOURCE_UNIT_CLOCK_CAVEATS.json', dict(status='SOURCE_ONLY_UNITS_AND_ARRIVAL_UNCERTIFIED',
            raw_rate_unit='UNCONFIRMED', raw_rate_conversion_performed=False,
            historical_arrival_certified=False, closure_clock_assumption_only=True,
            initial_prior_mark='FLAT_UNOWNED_PRIORUNKNOWN_NO_FABRICATION',
            funding_by_symbol=funding_summary, strict_past_mark_source_proofs=mark_proofs,
            source_coverage_implies_ownership=False, financial_charge_created=False))
        receipt = dict(schema='FULL2025_SELECTIVE_SOURCE_QUALIFICATION_RECEIPT_V1',
            status='PASS_EXACT_SOURCE_ONLY_PENDING_INDEPENDENT_ACTUAL_SOURCE_REVIEW',
            source_stage_authorization_SHA256=scope.authorization_sha, canonical_source_files=canonical,
            canonical_bytes=46269167, source_calendar_us=[START,END], symbols=list(SYMBOLS),
            minutes_per_asset_per_family=525600, days=365, raw_archive_selections=180,
            original_source_index_SHA256=INDEX_SHA, original_normalizer_SHA256=NORMALIZER_SHA,
            pure_normalizer_AST_SHA256=pure_sha, warmup_source_SHA256=warm_contract['SHA256'],
            raw_rate_unit='UNCONFIRMED', historical_arrival_certified=False,
            role='ALREADY_SEEN_2025_DEVELOPMENT_EXACT_RAW_SOURCE',
            original_index_PASS_labels_are_provenance_only=True,
            SEAM08='FUTURE_SEPARATE_2025_D_ADAPTER_TARGET_ADMISSION_REQUIRED',
            historical_execution_authorized=False, financial_execution_authorized=False,
            source_observed_counters=dict(scope.observed))
        save_new(scope.output/'SOURCE_QUALIFICATION_RECEIPT.json', receipt)
        scope.check()
        scope.guard.checkpoint('ALL_SOURCE_QUALIFICATION_AND_PROOFS_PASSED')
        return receipt
    finally:
        selected.close()
