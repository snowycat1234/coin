"""Externally pinned source-only launch gate. Ships no valid source authorization.

All executable/source authority arrives via explicit independent invocation SHA
pins. A candidate/template stored with this code cannot authorize actual reads.
"""
import os
for _key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS',
             'NUMEXPR_NUM_THREADS', 'POLARS_MAX_THREADS', 'VECLIB_MAXIMUM_THREADS'):
    os.environ[_key] = '1'
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
import sys
sys.dont_write_bytecode = True
import argparse
import json
from pathlib import Path
import resource
import signal
import shutil
import time

if (Path(__file__).resolve().parent/'__pycache__').exists():
    raise RuntimeError('UNPINNED_LOCAL_BYTECODE_CACHE_FORBIDDEN')

from contracts import (HERE, ROOT, PLAN, PLAN_SHA, PLAN_REVIEW_SHA, INDEX_SHA, STAGE,
    SCHEMA, ACTION, START, END, SYMBOLS, CPU_CAP, WALL_CAP, DISK_CAP, StageScope,
    _ISSUER_TOKEN, _register_reviewed_launch, require, read_exact, digest, json_object, load_plan, save_new,
    no_symlink, relative_path)
from source_guard import SourceOnlyGuard
# Source transforms load only after thread environment configuration above.
from qualify import run_source_qualification

TRANSPORT = ROOT/'full2025_bounded_source_transport_20261015'
TRANSPORT_SHA = 'ab527c785ed1292cd90d866ef8f13ed9d17f2b11a5a52c1992e41a4670f5fbe9'
CACHE_INDEX_SHA = 'a68b86a3bdf542625c8356b928e23ffea15eee53e11cd18d930b577a96313a4b'
CODE_FILES = ('contracts.py', 'source_guard.py', 'selection.py', 'source_reader.py',
              'qualify.py', 'launch_source.py', 'test_generated_seams.py', 'run_generated_checks.py')


def pinned_input(path, sha, closure):
    require(type(sha) is str and len(sha) == 64 and all(c in '0123456789abcdef' for c in sha), 'EXTERNAL_SHA256_PIN_REQUIRED')
    path = no_symlink(path)
    size = path.stat().st_size
    require(0 < size <= 8388608, 'EXTERNAL_METADATA_SIZE_CAP')
    raw = read_exact(path, size, sha)
    closure.append((path, size, sha))
    return json_object(raw)


def verify_code_manifest(manifest, closure):
    require(manifest['schema'] == 'FULL2025_SOURCE_QUALIFIER_CODE_MANIFEST_V1', 'EXACT_CODE_MANIFEST_SCHEMA')
    rows = manifest['files']
    require({row['file'] for row in rows} == set(CODE_FILES) and len(rows) == len(CODE_FILES), 'EXACT_CODE_FILE_CLOSURE')
    for row in rows:
        path = relative_path(HERE, row['file'])
        read_exact(path, row['bytes'], row['SHA256'])
        closure.append((path, row['bytes'], row['SHA256']))
    require(manifest['frozen_plan_SHA256'] == PLAN_SHA and manifest['source_index_SHA256'] == INDEX_SHA,
            'CODE_SOURCE_PLAN_BINDING')


def validate_authorization(auth, *, code_sha, review_sha, transport_sha, cache_sha):
    require(auth.get('schema') == SCHEMA and auth.get('action') == ACTION and
        auth.get('stage') == STAGE and auth.get('status') == 'APPROVED_SOURCE_ONLY' and
        auth.get('root_source_qualification_authorized') is True, 'EXTERNAL_ROOT_SOURCE_ONLY_AUTHORIZATION_REQUIRED')
    require(auth.get('historical_execution_authorized') is False and auth.get('financial_execution_authorized') is False,
            'SOURCE_AUTHORIZATION_CANNOT_GRANT_FINANCIAL_OR_HISTORY_AUTHORITY')
    expected = dict(frozen_plan_SHA256=PLAN_SHA, independent_plan_review_SHA256=PLAN_REVIEW_SHA,
        code_manifest_SHA256=code_sha, independent_code_review_SHA256=review_sha,
        complete_transport_receipt_SHA256=transport_sha, opaque_cache_index_SHA256=cache_sha,
        source_index_SHA256=INDEX_SHA, raw_selection_manifest_SHA256='f47338cba170f4f98223a4df43fc01ae30988cedede64424b69fda17a57228d2')
    require(auth.get('bindings') == expected, 'EXACT_EXTERNAL_AUTHORITY_BINDINGS_REQUIRED')
    require(auth.get('calendar_us') == [START, END] and auth.get('symbols') == list(SYMBOLS), 'EXACT_SOURCE_SCOPE_REQUIRED')
    require(auth.get('limits') == dict(CPU_seconds=300, wall_seconds=900, additional_disk_bytes=268435456,
        CPU_affinity=[8], workers=1, new_network_requests=0), 'EXACT_SOURCE_BUDGET_REQUIRED')
    require(auth.get('permitted_actions') == [
        'REHASH_EXACT_217_OPAQUE_CACHE_IDENTITIES', 'REASSEMBLE_EXACT_PINNED_H1_AND_H2',
        'INSPECT_SELECTED_CENTRAL_DIRECTORIES', 'READ_EXACT_180_SOURCE_ARCHIVES_AND_120_CHECKSUMS',
        'READ_EXACT_QUALIFIED_2024_PAST_ONLY_CLOSE_WARMUP', 'WRITE_EXACT_15_CANONICAL_SOURCE_FILES',
        'WRITE_SOURCE_ONLY_365_WINDOW_ENDPOINT_UNIT_CLOCK_PROOFS'], 'EXACT_SOURCE_ACTION_ALLOWLIST')
    require(auth.get('priority_release') == 'ROOT_RELEASED_CPU8_FOR_SOURCE_QUALIFICATION', 'ROOT_PRIORITY_RELEASE_REQUIRED')


def launch(*, authorization_path, authorization_sha, code_manifest_path, code_manifest_sha,
           code_review_path, code_review_sha):
    """Never accepts a generated-origin bypass or caller-selected actual source root."""
    closure = []
    auth = pinned_input(authorization_path, authorization_sha, closure)
    manifest = pinned_input(code_manifest_path, code_manifest_sha, closure)
    verify_code_manifest(manifest, closure)
    review = pinned_input(code_review_path, code_review_sha, closure)
    require(str(review.get('status', '')).startswith('PASS') and review.get('code_manifest_SHA256') == code_manifest_sha and
        review.get('actual_source_body_reads') == 0 and review.get('FAIL_count') == 0,
        'EXACT_INDEPENDENT_CODE_PASS_REQUIRED')
    receipt_path, cache_path = TRANSPORT/'FINAL_OPAQUE_TRANSPORT_RECEIPT.json', TRANSPORT/'OPAQUE_CACHE_INDEX.json'
    transport = pinned_input(receipt_path, TRANSPORT_SHA, closure)
    cache_index = pinned_input(cache_path, CACHE_INDEX_SHA, closure)
    require(transport['opaque_cache_index_SHA256'] == CACHE_INDEX_SHA, 'TRANSPORT_CACHE_INDEX_BINDING')
    pinned_input(PLAN/'FROZEN_MANIFEST.json', PLAN_SHA, closure)
    plan_review_path = ROOT/'full2025_selective_source_qualification_plan_independent_review_20261015/REVIEW.json'
    plan_review = pinned_input(plan_review_path, PLAN_REVIEW_SHA, closure)
    require(plan_review['PASS_count'] == 124 and plan_review['FAIL_count'] == 0, 'EXACT_PLAN_REVIEW_PASS_REQUIRED')
    validate_authorization(auth, code_sha=code_manifest_sha, review_sha=code_review_sha,
                           transport_sha=TRANSPORT_SHA, cache_sha=CACHE_INDEX_SHA)
    # Metadata/code only up to here; no actual cache/archive/CSV/NPZ was opened.
    require(8 in os.sched_getaffinity(0), 'CPU8_NOT_AVAILABLE')
    os.sched_setaffinity(0, {8})
    require(shutil.disk_usage(HERE).free >= DISK_CAP, '256MIB_ADDITIONAL_DISK_RESERVATION_REQUIRED')
    base = HERE/'source_runs'/authorization_sha
    require(not base.exists(), 'NO_RETRY_OR_OVERWRITE_AUTHORIZED')
    no_symlink(base)
    base.mkdir(parents=True)
    stage = base/'unadmitted'
    stage.mkdir()
    # Closed actual filesystem read set; ZIP members have their own exact gate.
    # These paths are metadata or explicitly authorized opaque/source containers.
    contract, checks, cache_contract, contents = load_plan()
    read_paths = {Path(path) for path, _, _ in closure}
    read_paths.add(PLAN/'FROZEN_MANIFEST.json')
    frozen_manifest = json_object(read_exact(PLAN/'FROZEN_MANIFEST.json',4016,PLAN_SHA))
    read_paths.update(relative_path(PLAN,row['file']) for row in frozen_manifest['files'])
    read_paths.update(relative_path(ROOT,row['path']) for row in contents['OBSERVED_METADATA_CODE_PINS.json']['observed_metadata_code_files'])
    read_paths.update(relative_path(ROOT,row['cache_path']) for row in cache_contract['objects'])
    read_paths.update(relative_path(ROOT,row['path']) for row in contract['january_reuse']['wrapper_pins'])
    read_paths.add(relative_path(ROOT,contract['past_warmup']['file']))
    guard = SourceOnlyGuard(write_roots=(base,), read_paths=read_paths)
    error, result, scope = None, None, None
    began, cpu_began = time.monotonic(), time.process_time()
    # Process limits cannot be silently extended by this launcher.
    old_as = resource.getrlimit(resource.RLIMIT_AS)
    as_cap = min(2000000000, old_as[0]) if old_as[0] != resource.RLIM_INFINITY else 2000000000
    resource.setrlimit(resource.RLIMIT_AS, (as_cap, old_as[1]))
    used_cpu = int(time.process_time()) + 1
    old_cpu = resource.getrlimit(resource.RLIMIT_CPU)
    cpu_limit = used_cpu + CPU_CAP
    if old_cpu[0] != resource.RLIM_INFINITY: cpu_limit = min(cpu_limit, old_cpu[0])
    resource.setrlimit(resource.RLIMIT_CPU, (cpu_limit, old_cpu[1]))
    def wall_timeout(signum, frame):
        raise TimeoutError('SOURCE_900_SECOND_WALL_BUDGET_EXCEEDED')
    previous_alarm = signal.signal(signal.SIGALRM, wall_timeout)
    def cpu_timeout(signum, frame):
        raise TimeoutError('SOURCE_300_SECOND_CPU_BUDGET_EXCEEDED')
    previous_cpu_signal = signal.signal(signal.SIGXCPU, cpu_timeout)
    signal.setitimer(signal.ITIMER_REAL, WALL_CAP)
    try:
        with guard:
            contract, checks, cache_contract, contents = load_plan()
            _register_reviewed_launch(authorization_sha, stage, guard, closure)
            scope = StageScope(_ISSUER_TOKEN, authorization_sha, stage, guard, closure)
            result = run_source_qualification(scope, contract, checks, cache_contract, transport, cache_index)
            scope.check()
            guard.checkpoint('BEFORE_SCOPE_REVOCATION')
            scope.close()
    except BaseException as exc:
        error = repr(exc)
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        signal.signal(signal.SIGALRM, previous_alarm)
        signal.signal(signal.SIGXCPU, previous_cpu_signal)
        if scope is not None: scope.close()
    observed = guard.receipt('PASS_OBSERVED_ZERO_FORBIDDEN_ATTEMPTS' if error is None else 'SOURCE_STAGE_STOPPED', error)
    observed.update(source_stage_authorization_SHA256=authorization_sha,
                    code_manifest_SHA256=code_manifest_sha, independent_code_review_SHA256=code_review_sha,
                    elapsed_wall_seconds=time.monotonic()-began, elapsed_CPU_seconds=time.process_time()-cpu_began,
                    source_observed_counters=dict(scope.observed) if scope is not None else {},
                    scope_revoked=scope is None or not scope.active)
    save_new(base/'OBSERVED_SOURCE_GUARD_RECEIPT.json', observed)
    if error is not None:
        save_new(base/'STOP_SOURCE_QUALIFICATION.json', dict(status='FAIL_CLOSED_NO_CANONICAL_ADMISSION', error=error,
            source_stage_authorization_SHA256=authorization_sha, no_automatic_retry=True,
            historical_execution_authorized=False, financial_execution_authorized=False))
        raise RuntimeError(error)
    # All outputs remain source-only. Independent actual review is still pending.
    require(not guard.active and not any(guard.attempts.values()), 'ZERO_OBSERVED_GUARD_ATTEMPTS_REQUIRED')
    stage.rename(base/'qualified_source_only_pending_review')
    save_new(base/'SOURCE_STAGE_COMPLETION.json', dict(status='SOURCE_ONLY_QUALIFIED_PENDING_INDEPENDENT_ACTUAL_REVIEW',
        source_stage_authorization_SHA256=authorization_sha, code_manifest_SHA256=code_manifest_sha,
        output='qualified_source_only_pending_review', historical_execution_authorized=False,
        financial_execution_authorized=False))
    return result, observed


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    for name in ('authorization', 'authorization-sha', 'code-manifest', 'code-manifest-sha', 'code-review', 'code-review-sha'):
        parser.add_argument('--' + name, required=True)
    args = parser.parse_args()
    launch(authorization_path=args.authorization, authorization_sha=args.authorization_sha,
        code_manifest_path=args.code_manifest, code_manifest_sha=args.code_manifest_sha,
        code_review_path=args.code_review, code_review_sha=args.code_review_sha)
