"""Pinned metadata contracts and non-following, identity-checked source I/O.

Importing this module performs no I/O. Historical bodies are reachable only via
an activated source-stage scope issued by the externally pinned launcher.
"""
from pathlib import Path, PurePosixPath
import ast
import calendar
import datetime
import hashlib
import io
import json
import os
import stat
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
PLAN = ROOT / 'full2025_selective_source_qualification_plan_20261015'
NATIVE = ROOT / 'native_2025_source_restore_20261015'
PLAN_SHA = '43d55792b548442a8e5d8fce56aade148c7f73ec668bf6400d9788df33b236c2'
PLAN_REVIEW_SHA = '993aead4dae9e9cbcc1346beba49d6346f38d5700c847bb80ad0070cb40d28b7'
INDEX_SHA = '8a0235e428902f7a0ea4ec1893343abae6ccc23715080771796b54fb58f1f3c4'
NORMALIZER_SHA = 'ee394086066c96bc23e83b45bf0bc2777264ab4eb57128886394fee47fecd4ff'
START, END, DAY, MINUTE = 1735689600000000, 1767225600000000, 86400000000, 60000000
SYMBOLS = ('BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'XRPUSDT', 'DOGEUSDT')
STAGE = 'SELECTIVE_FULL2025_SOURCE_QUALIFICATION_ONLY'
ACTION = 'QUALIFY_EXACT_FULL2025_SOURCE_ONLY'
SCHEMA = 'EXTERNAL_FULL2025_SOURCE_STAGE_AUTHORIZATION_V1'
DISK_CAP, CPU_CAP, WALL_CAP = 268435456, 300, 900
INNER_CAP, META_CAP = 67108864, 8388608
FIELDS = {
 'klines': ['timestamp_ms', 'open', 'close', 'quote_volume', 'close_time_ms'],
 'markPriceKlines': ['timestamp_ms', 'close', 'close_time_ms'],
 'fundingRate': ['calc_time_ms', 'funding_interval_hours', 'last_funding_rate'],
}
PRICE_COLUMNS = ['timestamp_ms', 'open', 'high', 'low', 'close', 'volume', 'close_time_ms',
 'quote_volume', 'trades', 'taker_buy_volume', 'taker_buy_quote_volume', 'ignore']
FUND_COLUMNS = ['calc_time_ms', 'funding_interval_hours', 'last_funding_rate']

class QualificationStop(ValueError):
    """A mismatch is terminal; recovery requires a new exact reviewed proposal."""


def require(condition, message):
    if not condition:
        raise QualificationStop(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def no_symlink(path):
    path = Path(os.path.abspath(path))
    for part in [path, *path.parents]:
        require(not part.is_symlink(), 'SYMLINK_PATH_FORBIDDEN:' + str(part))
    return path


def open_regular(path):
    path = no_symlink(path)
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        require(stat.S_ISREG(os.fstat(fd).st_mode), 'REGULAR_FILE_REQUIRED')
        return os.fdopen(fd, 'rb')
    except BaseException:
        os.close(fd)
        raise


def read_exact(path, size, sha):
    with open_regular(path) as stream:
        require(os.fstat(stream.fileno()).st_size == size, 'FILE_SIZE_MISMATCH:' + str(path))
        data = stream.read(size + 1)
    require(len(data) == size and digest(data) == sha, 'FILE_IDENTITY_MISMATCH:' + str(path))
    return data


def opaque_identity(path, expected):
    """Streaming SHA/Git blob verification, no archive inspection or parsing."""
    with open_regular(path) as stream:
        size = os.fstat(stream.fileno()).st_size
        require(size == expected['bytes'], 'OPAQUE_SIZE_MISMATCH:' + str(path))
        sha = hashlib.sha256()
        git = hashlib.sha1(('blob ' + str(size) + '\0').encode())
        count = 0
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            count += len(block)
            sha.update(block)
            git.update(block)
    observed = dict(bytes=count, SHA256=sha.hexdigest(), GitBlobSHA1=git.hexdigest())
    require(observed == expected, 'OPAQUE_IDENTITY_MISMATCH:' + str(path))
    return observed


def relative_path(root, name):
    require(type(name) is str and name and '\\' not in name and '\0' not in name,
            'EXACT_RELATIVE_PATH_REQUIRED')
    p = PurePosixPath(name)
    require(not p.is_absolute() and ':' not in name and all(x not in ('', '.', '..') for x in name.split('/')),
            'UNSAFE_RELATIVE_PATH:' + name)
    return no_symlink(Path(root) / name)


def json_object(raw):
    def pairs(items):
        obj = {}
        for key, value in items:
            require(key not in obj, 'DUPLICATE_JSON_KEY:' + key)
            obj[key] = value
        return obj
    value = json.loads(raw, object_pairs_hook=pairs,
                       parse_constant=lambda _: (_ for _ in ()).throw(QualificationStop('NONFINITE_JSON')))
    return value


def save_new(path, value):
    path = no_symlink(path)
    data = (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()
    if len(data) > META_CAP:
        # Preserve exact canonical pretty bytes whenever they fit. A diagnostic
        # may use compact formatting, with all values retained and the same cap.
        data = (json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False) + '\n').encode()
    require(len(data) <= META_CAP, 'METADATA_OUTPUT_SIZE_CAP')
    with path.open('xb') as stream:
        stream.write(data)
    return dict(file=str(path), bytes=len(data), SHA256=digest(data))


def load_plan():
    manifest_raw = read_exact(PLAN / 'FROZEN_MANIFEST.json', 4016, PLAN_SHA)
    manifest = json_object(manifest_raw)
    contents = {}
    for item in manifest['files']:
        raw = read_exact(relative_path(PLAN, item['file']), item['bytes'], item['SHA256'])
        contents[item['file']] = json_object(raw) if item['file'].endswith('.json') else raw
    # Preserve old adapter, denial receipts, and source/code provenance exactly.
    for item in contents['OBSERVED_METADATA_CODE_PINS.json']['observed_metadata_code_files']:
        read_exact(relative_path(ROOT, item['path']), item['bytes'], item['SHA256'])
    contract = contents['EXACT_SELECTION_CONTRACT.json']
    checks = contents['QUALIFICATION_CHECKS.json']
    cache = contents['CACHE_BINDING_SPEC.json']
    require(len(contract['selectors']) == 180 and cache['expected_objects'] == 217,
            'EXACT_180_217_CONTRACT_REQUIRED')
    require(checks['schema']['monthly_keys'] == ['times'] +
            [s + '_' + f for s in SYMBOLS for f in ('open', 'close', 'quote_volume', 'mark')],
            'EXACT_ARRAY_SCHEMA_REQUIRED')
    for selector in contract['selectors']:
        require(selector['selected_fields'] == FIELDS[selector['family']], 'FIELD_SCOPE_MISMATCH')
        require(selector['validate_columns'] == (FUND_COLUMNS if selector['family'] == 'fundingRate' else PRICE_COLUMNS),
                'VALIDATION_FIELD_SCOPE_MISMATCH')
        require(selector['calendar_year_us'] == [START, END] and selector['month'].startswith('2025-'),
                'TIME_SCOPE_MISMATCH')
    return contract, checks, cache, contents


def pure_normalizer():
    """Reuse exact frozen numeric transform AST; never import its runtime module."""
    import numpy as np
    import pandas as pd
    import zipfile
    path = NATIVE / 'metadata/original_normalize.py'
    raw = read_exact(path, 20360, NORMALIZER_SHA)
    wanted = {'PRICE_COLUMNS', 'FUND_COLUMNS', 'month_limits', 'numeric_csv',
              'deduplicate', 'validate_price', 'validate_funding'}
    nodes, found = [], set()
    for node in ast.parse(raw).body:
        name = getattr(node, 'name', None)
        if isinstance(node, ast.Assign) and len(node.targets) == 1:
            name = getattr(node.targets[0], 'id', None)
        if name in wanted:
            nodes.append(node)
            found.add(name)
    require(found == wanted, 'EXACT_PURE_AST_REQUIRED')
    mod = ast.Module(body=[ast.ImportFrom(module='__future__', names=[ast.alias(name='annotations')], level=0), *nodes], type_ignores=[])
    namespace = dict(np=np, pd=pd, Path=Path, zipfile=zipfile)
    exec(compile(ast.fix_missing_locations(mod), 'PINNED_SOURCE_ONLY_PURE_AST', 'exec'), namespace)
    return namespace, digest((ast.unparse(mod) + '\n').encode())


def frozen_metadata(name):
    manifest = json_object(read_exact(PLAN/'FROZEN_MANIFEST.json', 4016, PLAN_SHA))
    rows = [row for row in manifest['files'] if row['file'] == name]
    require(len(rows) == 1, 'EXACT_FROZEN_METADATA_NAME')
    row = rows[0]
    return json_object(read_exact(relative_path(PLAN, name), row['bytes'], row['SHA256']))


def require_frozen_contract(value, name):
    require(value == frozen_metadata(name), 'ACTUAL_FROZEN_CONTRACT_REQUIRED:' + name)


def exact_month_predicate(stamp, lo, minutes):
    require(type(stamp) is str and len(stamp) == 7 and stamp[:5] == '2025-' and
            stamp[5:].isdigit() and 1 <= int(stamp[5:]) <= 12, 'EXACT_2025_MONTH_PREDICATE')
    month = int(stamp[5:])
    expected_lo = int(datetime.datetime(2025, month, 1, tzinfo=datetime.timezone.utc).timestamp())*1000000
    require(type(lo) is int and type(minutes) is int and lo == expected_lo and
            minutes == calendar.monthrange(2025, month)[1]*1440, 'EXACT_MONTH_CLOCK_PREDICATE_BEFORE_BODY')


def require_actual_scope(scope):
    require(type(scope) is StageScope, 'EXACT_LAUNCHER_ISSUED_STAGE_SCOPE_REQUIRED')
    StageScope.check(scope)
    return scope


_ISSUER_TOKEN = object()
_ACTIVE_SCOPES = {}
_PENDING_ISSUANCE = {}


def _register_reviewed_launch(authorization_sha, output, guard, closure):
    """One-shot registration called only after the launcher's complete gate."""
    require(guard.active and len(closure) >= 1, 'COMPLETE_EXTERNAL_SCOPE_CLOSURE_REQUIRED')
    rows = tuple(closure)
    expected = {path.name: sha for path, size, sha in rows}
    require(expected.get('FINAL_OPAQUE_TRANSPORT_RECEIPT.json') ==
            'ab527c785ed1292cd90d866ef8f13ed9d17f2b11a5a52c1992e41a4670f5fbe9' and
            expected.get('OPAQUE_CACHE_INDEX.json') ==
            'a68b86a3bdf542625c8356b928e23ffea15eee53e11cd18d930b577a96313a4b',
            'EXACT_TRANSPORT_SCOPE_CLOSURE_REQUIRED')
    objects = [(path, sha, json_object(read_exact(path,size,sha))) for path,size,sha in rows
               if path.suffix == '.json']
    authorizations = [(path,sha,obj) for path,sha,obj in objects if obj.get('schema') == SCHEMA]
    require(len(authorizations) == 1 and authorizations[0][1] == authorization_sha,
            'EXACT_EXTERNAL_AUTHORIZATION_IN_SCOPE_CLOSURE_REQUIRED')
    auth = authorizations[0][2]
    require(auth.get('status') == 'APPROVED_SOURCE_ONLY' and auth.get('action') == ACTION and
            auth.get('root_source_qualification_authorized') is True and
            auth.get('historical_execution_authorized') is False and auth.get('financial_execution_authorized') is False,
            'APPROVED_SOURCE_ONLY_SCOPE_CLOSURE_REQUIRED')
    bindings = auth['bindings']
    manifests = [obj for _,sha,obj in objects if sha == bindings['code_manifest_SHA256'] and
                 obj.get('schema') == 'FULL2025_SOURCE_QUALIFIER_CODE_MANIFEST_V1']
    require(len(manifests) == 1 and len(rows) == len(manifests[0]['files'])+7 and
            len({path for path,_,_ in rows}) == len(rows) and
            any(path == PLAN/'FROZEN_MANIFEST.json' and sha == PLAN_SHA for path,_,sha in rows),
            'EXACT_METADATA_AND_CODE_CLOSURE_MEMBERSHIP_REQUIRED')
    require(any(sha == bindings['code_manifest_SHA256'] and obj.get('schema') == 'FULL2025_SOURCE_QUALIFIER_CODE_MANIFEST_V1' for _,sha,obj in objects) and
            any(sha == bindings['independent_code_review_SHA256'] and str(obj.get('status','')).startswith('PASS') and
                obj.get('code_manifest_SHA256') == bindings['code_manifest_SHA256'] and obj.get('FAIL_count') == 0 for _,sha,obj in objects) and
            any(sha == PLAN_REVIEW_SHA and obj.get('PASS_count') == 124 and obj.get('FAIL_count') == 0 for _,sha,obj in objects),
            'INDEPENDENT_REVIEW_SCOPE_CLOSURE_REQUIRED')
    require(id(guard) not in _PENDING_ISSUANCE, 'SCOPE_ISSUANCE_ALREADY_PENDING')
    _PENDING_ISSUANCE[id(guard)] = (authorization_sha, no_symlink(output), guard, rows)



class StageScope:
    """Only the launch gate instantiates an active scope; no history/provider API."""
    def __init__(self, token, authorization_sha, output, guard, closure):
        from source_guard import SourceOnlyGuard
        require(token is _ISSUER_TOKEN and type(guard) is SourceOnlyGuard and guard.active and len(authorization_sha) == 64,
                'LAUNCHER_ISSUED_EXACT_SOURCE_SCOPE_REQUIRED')
        request = (authorization_sha, no_symlink(output), guard, tuple(closure))
        require(_PENDING_ISSUANCE.pop(id(guard), None) == request, 'ONE_SHOT_REVIEWED_LAUNCH_ISSUANCE_REQUIRED')
        require(Path(output) == HERE/'source_runs'/authorization_sha/'unadmitted', 'EXACT_AUTHORIZATION_OUTPUT_ROOT')
        self.authorization_sha, self.output, self.guard = authorization_sha, no_symlink(output), guard
        self._closure = tuple(closure)
        self._identity = (authorization_sha, self.output, guard, self._closure)
        _ACTIVE_SCOPES[id(self)] = (self, self._identity)
        self.active = True
        self.started_wall, self.started_cpu = time.monotonic(), time.process_time()
        self.observed = dict(opaque_objects_rehashed=0, opaque_bytes_rehashed=0,
                             selected_outer_bodies=0, selected_inner_bodies=0,
                             selected_checksum_bodies=0, inner_decompressed_bytes=0,
                             archive_reassemblies=0, canonical_files_written=0)
    def check(self):
        require(self.active and self.guard.active and _ACTIVE_SCOPES.get(id(self)) == (self, self._identity),
                'REVOKED_OR_UNGUARDED_SOURCE_SCOPE')
        require((self.authorization_sha, self.output, self.guard, self._closure) == self._identity,
                'SOURCE_SCOPE_IDENTITY_MUTATED')
        require(no_symlink(self.output) == HERE/'source_runs'/self.authorization_sha/'unadmitted',
                'SOURCE_SCOPE_ROOT_MUTATED')
        for path, size, sha in self._closure:
            read_exact(path, size, sha)
        require(time.monotonic() - self.started_wall <= WALL_CAP, 'SOURCE_WALL_BUDGET_EXCEEDED')
        require(time.process_time() - self.started_cpu <= CPU_CAP, 'SOURCE_CPU_BUDGET_EXCEEDED')
        if self.output.exists():
            size = sum(p.stat().st_size for p in self.output.rglob('*') if p.is_file())
            require(size <= DISK_CAP, 'SOURCE_ADDITIONAL_DISK_BUDGET_EXCEEDED')
        self.guard.checkpoint('SOURCE_SCOPE_CHECK')
    def close(self):
        self.active = False
        _ACTIVE_SCOPES.pop(id(self), None)
    def historical_scope(self, *args, **kwargs):
        self.guard.deny('historical_scope_mints', 'StageScope.historical_scope')
