"""CPU8 generated-only test runner with an observed historical-open prohibition."""
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[key]='1'
os.environ['PYTHONDONTWRITEBYTECODE']='1'
import sys
sys.dont_write_bytecode=True
import json
from pathlib import Path
import time
import unittest

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
metadata=json.loads((ROOT/'full2025_selective_source_qualification_plan_20261015/CACHE_BINDING_SPEC.json').read_text())
selection=json.loads((ROOT/'full2025_selective_source_qualification_plan_20261015/EXACT_SELECTION_CONTRACT.json').read_text())
protected={str(ROOT/row['cache_path']) for row in metadata['objects']}
protected.update(str(ROOT/row['path']) for row in selection['january_reuse']['wrapper_pins'])
protected.add(str(ROOT/selection['past_warmup']['file']))
actual_attempts=[]
workspace_reads={}
def audit(event,args):
    if event!='open' or not args or not isinstance(args[0],(str,bytes,os.PathLike)): return
    path=str(Path(os.path.abspath(os.fsdecode(args[0]))))
    if path in protected or (str(ROOT)+'/' in path and any(part in path for part in ('/prepared_2025/','/prepared_2024/','/source_runs/'))):
        actual_attempts.append(path)
        raise RuntimeError('GENERATED_TEST_ACTUAL_SOURCE_BODY_OPEN_FORBIDDEN:'+path)
    if path.startswith(str(ROOT)+'/'):workspace_reads[path]=workspace_reads.get(path,0)+1
sys.addaudithook(audit)
os.sched_setaffinity(0,{8})
start=time.monotonic()
suite=unittest.defaultTestLoader.loadTestsFromName('test_generated_seams')
result=unittest.TextTestRunner(verbosity=2).run(suite)
receipt=dict(schema='OBSERVED_GENERATED_ONLY_SOURCE_SEAM_TESTS_V1',
    status='PASS_GENERATED_ONLY' if result.wasSuccessful() and not actual_attempts else 'FAIL_GENERATED_ONLY',
    tests_run=result.testsRun,failures=len(result.failures),errors=len(result.errors),
    observed_actual_source_open_attempts=actual_attempts,observed_actual_source_body_reads=len(actual_attempts),
    observed_workspace_metadata_code_open_counts=workspace_reads,CPU_affinity=sorted(os.sched_getaffinity(0)),
    wall_seconds=time.monotonic()-start)
with (HERE/'GENERATED_TEST_RECEIPT.json').open('x') as stream:
    json.dump(receipt,stream,sort_keys=True,indent=2);stream.write('\n')
sys.exit(0 if receipt['status']=='PASS_GENERATED_ONLY' else 1)
