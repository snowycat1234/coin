# Full-2025 selective source qualification

This new sibling implements the eight frozen seams without changing the original adapter, reader, tests, receipts, transport objects, financial framework, or backtester. It is source-only code. The original pure numeric normalizer is loaded from its exact pinned AST; its executable restoration module is never imported.

## Current checkpoint

Implementation and generated tests only. No actual 2025 opaque object, wrapper directory, selected member, CSV, canonical NPZ, or 2024 warmup body has been opened by this implementation work. The separate transport receipt certifies opaque transport only. Source completeness and actual qualification remain unestablished until the exact launcher is separately authorized and passes, followed by independent actual-source review.

The supplied authorization template is deliberately INVALID. The candidate metadata is not a GO. The root must provide a new approved source-only authorization and its independent SHA256, naming this exact code manifest, fresh independent code review, frozen plan/review, final transport/cache receipts, source index, resource limits, and source-only actions. No historical or financial permission is conferred.

## New seams

1. `ExactCache` binds the final transport receipt/cache index and frozen217 map, rehashes all217 byte/SHA256/Git identities, and rechecks captured part bytes immediately before use. It never downloads.
2. `SelectedSources` reassembles the exact H1 wrapper and exact H2 archives in memory. Same-handle wrapper hashing, selected metadata predicates, safe exact inner names, caps, official price checksums and selected CRC-to-EOF precede numeric import. No extraction or mixed-wrapper `testzip` is used.
3. `source_reader` checks exact numeric NPZ keys, headers, dtypes, shapes, payload sizes, month clocks and immutable byte captures. Qualification requires all15 canonical files/46,269,167B,525,600 minutes per asset/family, exact funding counts, cadence and unconverted raw rates.
4. The already-qualified past-only2024 two-array warmup is captured once, projected to200 actual trade closes, and combined with2025 minute-derived trade closes for365 structural past-close windows.
5. A separate Dec31 witness uses the final actual2025 minute at END-MINUTE, available END. Canonical DAILY bytes stay unchanged. No2026 daily cube or feature row is read or created.
6. The qualification reader accepts only the launcher-issued scope and fixed staging root; it provides no provider iteration or history scope. Paths reject symlinks and file changes.
7. Source-only receipts retain funding unit UNCONFIRMED, historical arrival uncertified, closure-clock assumptions, strictly-past mark diagnostics and unknown first mark boundaries. They make no economic ownership/charge claim.
8. Any2025D target/entry/admission work remains future-only and separately authorized. There is no2025 account, genesis, target generation, covariance, provider loop, historical scope, financial claim, lease, or financial GO.

## Whole-run boundary and failure behavior

A dynamic guard surrounds actual qualification, including pure-transform loading, rehashing, selected source processing, canonical writing and proof emission. It observes and denies financial constructors/advance, simulator use, provider calls, historical scopes, external processes, network, claims/leases, financial authority writes, outside-source writes and nonallowlisted workspace reads. Caught violations are still fatal. Observed counters and paths are saved on success or failure.

All source artifacts are written under an authorization-derived unadmitted directory. A mismatch, duplicate, new gap, checksum/schema change, budget exhaustion or forbidden call stops the batch. Failed output is never renamed to qualified output. A source-derived gap receipt includes original lineage, exact missing clocks, affected fields/cells, runs, same-stream neighbors and duplicate/checksum/CRC status. No2022 gap policy, repair, interpolation, alternate source, retry or limit extension is inherited.

The source stage is bounded to CPU8, one worker/BLAS thread,300 CPU seconds,900 wall seconds,2GB address space,256MiB additional disk and no network requests. A source-only PASS still awaits independent actual-source review and confers no financial authority.

## Reuse/performance contract

Each of180 raw archives is parsed exactly once during qualification to produce the canonical immutable source artifacts. The past warmup file is read once. A later separately reviewed entry must consume those canonical hash-bound NPZ/JSON files and saved past-close projection directly, without repeating raw ZIP parsing per cell or provider callback. This checkpoint does not implement that later financial entry.

## Tests

Run the generated-only runner on CPU8:

`PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 taskset -c 8 python full2025_selective_source_qualification_20261015_v2/run_generated_checks.py`

The runner's receipt is exclusive-create. Preserve an existing receipt before another run. Its audit hook prohibits actual source/cache opens. The tests exercise exact authority, fake scope rejection, frozen contract changes, cache/Git identity changes, symlinks/path aliases, exact members and CRCs, field/year/clock predicates before reads, array schema/header gates, immutable captures, warmup/windows/endpoint clocks, gap classification and observed dynamic blockers. Generated test authority is an in-memory parsing fixture and cannot issue a source scope.

## Future launcher

`python full2025_selective_source_qualification_20261015_v2/launch_source.py --authorization EXTERNAL_APPROVED_SOURCE_AUTHORIZATION.json --authorization-sha EXTERNAL_SHA256 --code-manifest full2025_selective_source_qualification_20261015_v2/CODE_MANIFEST.json --code-manifest-sha EXTERNAL_CODE_MANIFEST_SHA256 --code-review INDEPENDENT_REVIEW.json --code-review-sha EXTERNAL_REVIEW_SHA256`

The launcher has no generated-origin switch, source-root override, retry, overwrite, financial mode or authority-minting command. It rejects the included INVALID template.

## Narrow v2 cache-location correction

The root-owned v1 source attempt7b788d09 stopped fail-closed at part004 because its filename-prefix heuristic requested an undeclared native-cache path. The frozen217-object contract instead declares the recovered part004 under source_network_readonly_diagnosis_20261015/part004_original_route_probe/. No v1 code, package, review, transport object or failed attempt is changed.

The only executable change in v2 is the H1 resolver seam. A metadata-only exact join requires the full original repository path and pinned commit to match exactly one frozen217row, with identical bytes/SHA256/GitBlobSHA1 to the pinned H1 index part. Allnine cache routes are derived and checked before use. Missing, duplicate, conflicting, mutated, aliased or nonallowlisted requests fail closed; no search, fallback, new read root, alternate download, broader authority or source predicate is added.

The three added generated tests cover the real metadata map with actual body opens prohibited, exact recoveredpart004 routing, full identity conflicts, missing/duplicate mappings, aliases and the old undeclaredpart004path. No actual source body was opened for v2 implementation/tests. A fresh independent v2 code review and new externally pinned root source authorization are required before any actual rerun.
