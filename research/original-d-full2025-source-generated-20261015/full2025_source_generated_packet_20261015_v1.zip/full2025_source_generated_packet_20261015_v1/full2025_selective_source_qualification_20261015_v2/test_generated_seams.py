"""Generated-only adversarial tests. No actual cache or historical member opens."""
import builtins
from contextlib import contextmanager
from copy import deepcopy
import hashlib
import io
import json
import os
from pathlib import Path
import socket
import stat
import subprocess
import sys
import tempfile
import types
import unittest
import zipfile
from unittest.mock import patch
import numpy as np

from contracts import (HERE, ROOT, START, END, DAY, MINUTE, SYMBOLS, INDEX_SHA, PLAN_SHA,
    PLAN_REVIEW_SHA, SCHEMA, ACTION, STAGE, StageScope, QualificationStop, require,
    digest, read_exact, opaque_identity, relative_path, load_plan, pure_normalizer)
from source_guard import SourceOnlyGuard, SourceBoundaryViolation
from selection import safe_zip_info, selected_read, inner_metadata, ExactCache, SelectedSources, exact_h1_cache_routes, pinned_h1_index
from source_reader import numeric_npz_bytes, window_proof, warmup_projection, monthly_arrays
from qualify import strict_past_mark_proof, exact_price_grid, funding_check, gap_classification
from launch_source import validate_authorization, launch, TRANSPORT_SHA, CACHE_INDEX_SHA


def generated_zip(items, *, compression=zipfile.ZIP_DEFLATED):
    output = io.BytesIO()
    with zipfile.ZipFile(output, 'w', compression) as archive:
        for name, body in items:
            archive.writestr(name, body)
    return output.getvalue()


def generated_npz(**arrays):
    output = io.BytesIO()
    np.savez_compressed(output, **arrays)
    return output.getvalue()


def generated_authority():
    return dict(schema=SCHEMA, action=ACTION, stage=STAGE, status='APPROVED_SOURCE_ONLY',
        root_source_qualification_authorized=True, historical_execution_authorized=False,
        financial_execution_authorized=False,
        bindings=dict(frozen_plan_SHA256=PLAN_SHA, independent_plan_review_SHA256=PLAN_REVIEW_SHA,
            code_manifest_SHA256='a'*64, independent_code_review_SHA256='b'*64,
            complete_transport_receipt_SHA256=TRANSPORT_SHA, opaque_cache_index_SHA256=CACHE_INDEX_SHA,
            source_index_SHA256=INDEX_SHA, raw_selection_manifest_SHA256='f47338cba170f4f98223a4df43fc01ae30988cedede64424b69fda17a57228d2'),
        calendar_us=[START, END], symbols=list(SYMBOLS),
        limits=dict(CPU_seconds=300, wall_seconds=900, additional_disk_bytes=268435456,
                    CPU_affinity=[8], workers=1, new_network_requests=0),
        permitted_actions=['REHASH_EXACT_217_OPAQUE_CACHE_IDENTITIES', 'REASSEMBLE_EXACT_PINNED_H1_AND_H2',
            'INSPECT_SELECTED_CENTRAL_DIRECTORIES', 'READ_EXACT_180_SOURCE_ARCHIVES_AND_120_CHECKSUMS',
            'READ_EXACT_QUALIFIED_2024_PAST_ONLY_CLOSE_WARMUP', 'WRITE_EXACT_15_CANONICAL_SOURCE_FILES',
            'WRITE_SOURCE_ONLY_365_WINDOW_ENDPOINT_UNIT_CLOCK_PROOFS'],
        priority_release='ROOT_RELEASED_CPU8_FOR_SOURCE_QUALIFICATION')


def check_authority(auth):
    validate_authorization(auth, code_sha='a'*64, review_sha='b'*64,
                           transport_sha=TRANSPORT_SHA, cache_sha=CACHE_INDEX_SHA)


class MetadataAndAuthority(unittest.TestCase):
    def test_actual_frozen_metadata_only_closure(self):
        c, k, b, m = load_plan()
        self.assertEqual(len(c['selectors']), 180)
        self.assertEqual(len(b['objects']), 217)
        self.assertEqual(sum(p['bytes'] for p in k['canonical_expected_source_files']), 46269167)
    def test_valid_generated_authority_parses_without_scope_or_reads(self):
        check_authority(generated_authority())
    def test_invalid_template_fails_before_scope(self):
        auth = generated_authority(); auth['action'] = 'INVALID_TEMPLATE_NOT_ROOT_AUTHORIZATION'
        with self.assertRaisesRegex(QualificationStop, 'EXTERNAL_ROOT'): check_authority(auth)
    def test_every_authority_pin_is_exact(self):
        for key in generated_authority()['bindings']:
            auth = generated_authority(); auth['bindings'][key] = '0'*64
            with self.subTest(key=key), self.assertRaises(QualificationStop): check_authority(auth)
    def test_finance_or_historical_authority_rejected(self):
        for field in ('historical_execution_authorized', 'financial_execution_authorized'):
            auth = generated_authority(); auth[field] = True
            with self.subTest(field=field), self.assertRaises(QualificationStop): check_authority(auth)
    def test_year_fields_symbols_budgets_and_action_expansion_rejected(self):
        mutations = [('calendar_us', [START, END+DAY]), ('symbols', list(reversed(SYMBOLS))),
            ('limits', dict(generated_authority()['limits'], CPU_seconds=301)),
            ('permitted_actions', generated_authority()['permitted_actions']+['READ_TARGETS']),
            ('priority_release', 'UNRELEASED')]
        for key, value in mutations:
            auth = generated_authority(); auth[key] = value
            with self.subTest(key=key), self.assertRaises(QualificationStop): check_authority(auth)
    def test_public_scope_cannot_accept_generated_or_fake_guard(self):
        fake = types.SimpleNamespace(active=True)
        with self.assertRaisesRegex(QualificationStop, 'LAUNCHER_ISSUED'):
            StageScope(object(), 'a'*64, Path('/tmp/generated'), fake, ())
    def test_private_token_alone_cannot_mint_actual_source_scope(self):
        import contracts
        with tempfile.TemporaryDirectory() as folder:
            guard=SourceOnlyGuard((Path(folder),))
            with guard:
                with self.assertRaisesRegex(QualificationStop,'ONE_SHOT'):
                    StageScope(contracts._ISSUER_TOKEN,'a'*64,HERE/'source_runs'/('a'*64)/'unadmitted',guard,())
                with self.assertRaisesRegex(QualificationStop,'COMPLETE_EXTERNAL_SCOPE_CLOSURE'):
                    contracts._register_reviewed_launch('a'*64,HERE/'source_runs'/('a'*64)/'unadmitted',guard,())
    def test_launcher_invalid_auth_never_reaches_cache_or_source(self):
        with tempfile.TemporaryDirectory() as folder:
            auth = Path(folder)/'INVALID.json'; auth.write_text('{}')
            # Missing metadata is reached before any historical scope or cache.
            with patch('launch_source.run_source_qualification') as run:
                with self.assertRaises(Exception):
                    launch(authorization_path=auth, authorization_sha=digest(b'{}'),
                        code_manifest_path=Path(folder)/'MISSING', code_manifest_sha='a'*64,
                        code_review_path=Path(folder)/'MISSING2', code_review_sha='b'*64)
                run.assert_not_called()

    def test_all_actual_entry_points_reject_duck_scope_before_reads(self):
        from qualify import run_source_qualification
        from source_reader import ImmutableSourceReader, monthly_arrays
        fake = types.SimpleNamespace(check=lambda:None, output=Path('/tmp/generated'), guard=types.SimpleNamespace(active=True))
        callbacks = [lambda:ExactCache(fake, {}, {}, {}), lambda:SelectedSources(fake, {}, object()),
            lambda:ImmutableSourceReader(fake, Path('/tmp/generated'), {}),
            lambda:run_source_qualification(fake, {}, {}, {}, {}, {}),
            lambda:monthly_arrays(Path('/tmp/generated'), {}, [], month_lo=START, minutes=1, scope=fake)]
        with patch('selection.opaque_identity') as opaque, patch('source_reader.read_exact') as reader:
            for callback in callbacks:
                with self.assertRaisesRegex(QualificationStop, 'EXACT_LAUNCHER_ISSUED'): callback()
            opaque.assert_not_called(); reader.assert_not_called()
    def test_changed_frozen_contract_rejected_before_any_opaque_read(self):
        from contracts import frozen_metadata
        for filename, constructor in [('CACHE_BINDING_SPEC.json',lambda value:ExactCache(object(),value,{},{})),
            ('EXACT_SELECTION_CONTRACT.json',lambda value:SelectedSources(object(),value,object()))]:
            value=deepcopy(frozen_metadata(filename))
            value['status']='MUTATED_BEFORE_CONSTRUCTION'
            with patch('selection.require_actual_scope'), patch('selection.opaque_identity') as opaque:
                with self.assertRaisesRegex(QualificationStop,'ACTUAL_FROZEN_CONTRACT'): constructor(value)
                opaque.assert_not_called()
    def test_month_clock_and_fields_rejected_before_file_read(self):
        from contracts import frozen_metadata
        from source_reader import monthly_arrays
        checks=frozen_metadata('QUALIFICATION_CHECKS.json');pin=checks['canonical_expected_source_files'][0]
        fake=types.SimpleNamespace(output=Path('/tmp/generated'))
        path=fake.output/'prepared_2025/months/2025-01.npz'
        cases=[dict(month_lo=START+MINUTE,minutes=44640),dict(month_lo=START,minutes=44639)]
        with patch('source_reader.require_actual_scope'),patch('source_reader.read_exact') as read:
            for kw in cases:
                with self.assertRaisesRegex(QualificationStop,'CLOCK_PREDICATE'): monthly_arrays(path,pin,checks['schema']['monthly_keys'],scope=fake,**kw)
            with self.assertRaisesRegex(QualificationStop,'PIN_AND_FIELDS'):
                monthly_arrays(path,pin,checks['schema']['monthly_keys']+['targets'],scope=fake,month_lo=START,minutes=44640)
            read.assert_not_called()


class FilesAndCache(unittest.TestCase):
    def test_exact_generated_file_then_tamper(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder)/'generated'; path.write_bytes(b'original')
            self.assertEqual(read_exact(path, 8, digest(b'original')), b'original')
            path.write_bytes(b'changed!')
            with self.assertRaisesRegex(QualificationStop, 'IDENTITY'): read_exact(path, 8, digest(b'original'))
    def test_generated_git_blob_identity_and_mismatch(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder)/'generated'; raw=b'generated'; path.write_bytes(raw)
            pin=dict(bytes=len(raw), SHA256=digest(raw), GitBlobSHA1=hashlib.sha1(b'blob 9\0'+raw).hexdigest())
            self.assertEqual(opaque_identity(path, pin), pin)
            pin['GitBlobSHA1']='0'*40
            with self.assertRaisesRegex(QualificationStop, 'OPAQUE_IDENTITY'): opaque_identity(path,pin)
    def test_symlink_file_and_parent_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder); (root/'real').mkdir(); (root/'real/file').write_bytes(b'x')
            (root/'link').symlink_to(root/'real', target_is_directory=True)
            for p in (root/'link/file',):
                with self.assertRaisesRegex(QualificationStop, 'SYMLINK'): read_exact(p,1,digest(b'x'))
    def test_path_aliases_rejected(self):
        for name in ('../x','/x','a/../x','a//x','a/./x','C:/x','a\\x','a\0x'):
            with self.subTest(name=name), self.assertRaises(QualificationStop): relative_path('/tmp',name)
    def test_immutable_npz_capture_survives_path_change(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'g.npz'; raw=generated_npz(times=np.array([1],dtype=np.int64)); path.write_bytes(raw)
            captured=read_exact(path,len(raw),digest(raw)); path.write_bytes(b'changed')
            arrays=numeric_npz_bytes(captured,['times'],shapes={'times':(1,)},dtypes={'times':'int64'})
            self.assertEqual(int(arrays['times'][0]),1)
            self.assertFalse(arrays['times'].flags.writeable)
            with self.assertRaises(QualificationStop): read_exact(path,len(raw),digest(raw))

    def test_save_new_under_cap_preserves_canonical_pretty_bytes(self):
        from contracts import save_new
        with tempfile.TemporaryDirectory() as folder:
            value=dict(z=[1,2,3],a='canonical');path=Path(folder)/'pretty.json'
            expected=(json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
            save_new(path,value)
            self.assertEqual(path.read_bytes(),expected)
    def test_save_new_compact_fallback_retains_every_field(self):
        import contracts
        value=dict(rows=[dict(index=i,value='generated') for i in range(20)],complete=True)
        compact=(json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()
        pretty=(json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
        self.assertGreater(len(pretty),len(compact))
        with tempfile.TemporaryDirectory() as folder,patch.object(contracts,'META_CAP',len(compact)):
            path=Path(folder)/'compact.json';contracts.save_new(path,value)
            self.assertEqual(path.read_bytes(),compact);self.assertEqual(json.loads(path.read_bytes()),value)
    def test_save_new_compact_over_cap_fails_before_write(self):
        import contracts
        value=dict(payload='generated'*20)
        compact=(json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()
        with tempfile.TemporaryDirectory() as folder,patch.object(contracts,'META_CAP',len(compact)-1):
            path=Path(folder)/'never-written.json'
            with self.assertRaisesRegex(QualificationStop,'OUTPUT_SIZE_CAP'): contracts.save_new(path,value)
            self.assertFalse(path.exists())

    def test_H1_exact_routes_include_the_recovered_part004_location(self):
        from contracts import frozen_metadata
        contract=frozen_metadata('CACHE_BINDING_SPEC.json');index=pinned_h1_index()
        routes=exact_h1_cache_routes(contract,index)
        self.assertEqual(len(routes),9)
        recovered='source_network_readonly_diagnosis_20261015/part004_original_route_probe/coin_frozen_e5_2025h1_increment_20261008.zip.bytepart004'
        self.assertEqual(routes['coin_frozen_e5_2025h1_increment_20261008.zip.bytepart004'],recovered)
        exact_paths={row['cache_path'] for row in contract['objects']}
        self.assertTrue(set(routes.values()).issubset(exact_paths))
        calls=[];cache=ExactCache.__new__(ExactCache);cache._h1_routes=routes;cache._check=lambda:None
        cache.bytes=lambda path:calls.append(path) or b'GENERATED_NO_SOURCE_BYTES'
        for part in index['parts']:
            self.assertEqual(cache.h1_part(part['file_name']),b'GENERATED_NO_SOURCE_BYTES')
        self.assertEqual(calls,[routes[part['file_name']] for part in index['parts']])
    def test_H1_missing_duplicate_commit_and_identity_conflicts_fail_closed(self):
        from contracts import frozen_metadata
        original=frozen_metadata('CACHE_BINDING_SPEC.json');index=pinned_h1_index()
        name='coin_frozen_e5_2025h1_increment_20261008.zip.bytepart004'
        row=next(row for row in original['objects'] if row['original_path']=='research_artifacts/frozen_e5_2025h1_20261008/'+name)
        mutations=[]
        missing=deepcopy(original);missing['objects'].remove(row);mutations.append(missing)
        duplicate=deepcopy(original);duplicate['objects'].append(deepcopy(row));mutations.append(duplicate)
        for field in ('original_commit','SHA256','GitBlobSHA1','bytes'):
            value=deepcopy(original);target=next(r for r in value['objects'] if r['cache_path']==row['cache_path'])
            if field=='original_commit':target[field]='0'*40
            elif field=='bytes':target['expected'][field]+=1
            else:target['expected'][field]='0'*(64 if field=='SHA256' else 40)
            mutations.append(value)
        for changed in mutations:
            with self.assertRaises(QualificationStop):exact_h1_cache_routes(changed,index)
    def test_H1_aliases_invalid_paths_and_old_wrong_part004_path_never_read(self):
        from contracts import frozen_metadata
        contract=frozen_metadata('CACHE_BINDING_SPEC.json');routes=exact_h1_cache_routes(contract,pinned_h1_index())
        cache=ExactCache.__new__(ExactCache);cache._h1_routes=routes;cache._check=lambda:None
        calls=[];cache.bytes=lambda path:calls.append(path)
        valid='coin_frozen_e5_2025h1_increment_20261008.zip.bytepart004'
        for name in ('../'+valid,'/tmp/'+valid,valid+'.extra','a/'+valid,valid.replace('004','009'),valid+'\\bad'):
            with self.assertRaisesRegex(QualificationStop,'EXACT_ALLOWLISTED_H1'):cache.h1_part(name)
        self.assertEqual(calls,[])
        cache._objects={row['cache_path']:row for row in contract['objects']}
        wrong='native_2025_source_restore_20261015/transport/H1/'+valid
        with patch('selection.read_exact') as read:
            with self.assertRaisesRegex(QualificationStop,'NONALLOWLISTED_CACHE_PATH'):ExactCache.bytes(cache,wrong)
            read.assert_not_called()


class ZipPredicates(unittest.TestCase):
    def test_exact_selected_body_only_and_nonallowlisted_never_opened(self):
        raw=generated_zip([('raw/source.zip',b'generated'),('models/model.pkl',b'NEVER')])
        with zipfile.ZipFile(io.BytesIO(raw)) as archive:
            calls=[]; original=archive.open
            def observed(name,*args,**kwargs): calls.append(getattr(name,'filename',name)); return original(name,*args,**kwargs)
            with patch.object(archive,'open',observed):
                for name in ('models/model.pkl','Y2025.npz','raw/source.zip/../bad','holdout/2026-03.npz'):
                    with self.assertRaisesRegex(QualificationStop,'EXCLUDED_MEMBER'): selected_read(archive,{'raw/source.zip'},name,cap=64)
                self.assertEqual(selected_read(archive,{'raw/source.zip'},'raw/source.zip',cap=64,size=9),b'generated')
            self.assertEqual(calls,['raw/source.zip'])
    def test_duplicate_outer_names_fail_before_body(self):
        import warnings
        with warnings.catch_warnings():
            warnings.simplefilter('ignore'); raw=generated_zip([('x',b'a'),('x',b'b')])
        with zipfile.ZipFile(io.BytesIO(raw)) as archive, patch.object(archive,'open') as body:
            with self.assertRaisesRegex(QualificationStop,'DUPLICATE'): selected_read(archive,{'x'},'x',cap=64)
            body.assert_not_called()
    def test_selected_metadata_rejects_all_unsafe_types_before_open(self):
        for kind in ('traversal','absolute','drive','backslash','symlink','directory','encryption','compression','large'):
            name={'traversal':'../x','absolute':'/x','drive':'C:/x','backslash':'a\\x'}.get(kind,'x')
            info=zipfile.ZipInfo(name);info.file_size=8;info.compress_size=8
            if kind=='symlink': info.external_attr=(stat.S_IFLNK|0o777)<<16
            if kind=='directory': info.external_attr=(stat.S_IFDIR|0o755)<<16
            if kind=='encryption': info.flag_bits|=1
            if kind=='compression': info.compress_type=zipfile.ZIP_BZIP2
            if kind=='large': info.file_size=65
            with self.subTest(kind=kind), self.assertRaises(QualificationStop): safe_zip_info(info,expected_name=name,cap=64)
    def test_selected_size_crc_and_exact_name_mutation_rejected(self):
        info=zipfile.ZipInfo('x');info.file_size=8;info.compress_size=8;info.CRC=42
        for kwargs in (dict(expected_name='y',cap=64),dict(expected_name='x',cap=64,expected_size=9),dict(expected_name='x',cap=64,expected_crc=43)):
            with self.assertRaises(QualificationStop): safe_zip_info(info,**kwargs)
    def test_inner_exact_basename_and_one_member(self):
        raw=generated_zip([('BTCUSDT-1m-2025-01.csv',b'generated')]);s=dict(bytes=len(raw),SHA256=digest(raw))
        self.assertEqual(inner_metadata(raw,s,'BTCUSDT-1m-2025-01.csv')['bytes'],9)
        with self.assertRaises(QualificationStop): inner_metadata(raw,s,'BTCUSDT-1m-2026-01.csv')
        more=generated_zip([('a.csv',b'a'),('label.npy',b'bad')]);s=dict(bytes=len(more),SHA256=digest(more))
        with self.assertRaisesRegex(QualificationStop,'SINGLE'): inner_metadata(more,s,'a.csv')
    def test_raw_hash_mutation_rejected_before_zip(self):
        with patch('selection.zipfile.ZipFile') as archive:
            with self.assertRaisesRegex(QualificationStop,'IDENTITY'): inner_metadata(b'fake',dict(bytes=4,SHA256='0'*64),'x.csv')
            archive.assert_not_called()
    def test_npz_undeclared_field_before_array_body(self):
        raw=generated_npz(times=np.array([START]),targets=np.array([1.]))
        with patch('source_reader.np.load') as load:
            with self.assertRaisesRegex(QualificationStop,'SCHEMA'): numeric_npz_bytes(raw,['times'],shapes={'times':(1,)},dtypes={'times':'int64'})
            load.assert_not_called()
    def test_npz_dtype_shape_and_object_rejected(self):
        for raw in (generated_npz(x=np.array([1],dtype=np.int32)),generated_npz(x=np.array([1,2],dtype=np.int64)),generated_npz(x=np.array([object()],dtype=object))):
            with self.assertRaises((QualificationStop,ValueError)): numeric_npz_bytes(raw,['x'],shapes={'x':(1,)},dtypes={'x':'int64'})


class SourceClockAndGrid(unittest.TestCase):
    def test_exact_365_windows_and_no_future_use(self):
        t=np.arange(START-199*DAY,START+DAY,DAY,dtype=np.int64);c=np.ones((200,5),dtype=np.float64)
        future={at:[2.]*5 for at in range(START+DAY,END+DAY,DAY)}
        p=window_proof(t,c,future)
        self.assertEqual(len(p),365);self.assertEqual(p[0]['last_available_us'],START)
        self.assertEqual(p[-1]['last_available_us'],END-DAY)
    def test_warmup_clock_and_missing_close_fail_closed(self):
        t=np.arange(START-199*DAY,START+DAY,DAY,dtype=np.int64);c=np.ones((200,5),dtype=np.float64)
        future={at:[2.]*5 for at in range(START+DAY,END+DAY,DAY)}
        changed=t.copy();changed[-1]+=MINUTE
        with self.assertRaises(QualificationStop): window_proof(changed,c,future)
        del future[START+DAY]
        with self.assertRaises(QualificationStop): window_proof(t,c,future)
    def test_genuine_lastbar_endpoint_needs_no_next_year_row(self):
        t=np.arange(END-DAY,END,MINUTE,dtype=np.int64)
        self.assertEqual(len(t),1440);self.assertEqual(int(t[-1]),END-MINUTE);self.assertEqual(int(t[-1])+MINUTE,END)
    def test_strict_past_mark_boundary_and_jitter(self):
        events=[dict(symbol=SYMBOLS[0],event_us=t) for t in (START,START+1000,START+8*60*MINUTE,START+8*60*MINUTE+1000)]
        p=strict_past_mark_proof(events,{SYMBOLS[0]:np.ones(525600)})
        self.assertTrue(all(r['status']=='BOUNDARY_PRIOR_MARK_UNKNOWN' for r in p[:2]))
        self.assertEqual(p[2]['gap_us'],MINUTE);self.assertEqual(p[3]['gap_us'],1000)
        self.assertTrue(all(r['available_us']<r['event_us'] for r in p[2:]))
    def test_pure_price_clock_field_and_grid_guards(self):
        import pandas as pd
        n,_=pure_normalizer();lo,hi=n['month_limits'](2025,1)
        frame=pd.DataFrame([[lo,10.,12.,9.,11.,20.,lo+59999,200.,3.,10.,100.,0.]],columns=n['PRICE_COLUMNS'])
        valid,dups=n['validate_price'](frame.copy(),'klines',lo,hi)
        exact_price_grid(valid,np.array([lo*1000]),selector=dict(selection_id='G',symbol='BTC',family='klines',month='2025-01',SHA256='0'*64))
        with self.assertRaisesRegex(ValueError,'GAP_FAIL_CLOSED'):
            exact_price_grid(valid,np.array([lo*1000,lo*1000+MINUTE]),selector=dict(selection_id='G',symbol='BTC',family='klines',month='2025-01',SHA256='0'*64))
        frame.timestamp_ms*=1000
        with self.assertRaisesRegex(ValueError,'MILLISECONDS'): n['validate_price'](frame,'klines',lo,hi)

    def test_gap_classification_has_lineage_cells_runs_neighbors_and_crc(self):
        import pandas as pd
        frame=pd.DataFrame(dict(timestamp_ms=[START//1000,(START+2*MINUTE)//1000],open=[1.,2.],close=[1.,2.],quote_volume=[3.,4.]))
        selector=dict(selection_id='GENERATED',symbol=SYMBOLS[0],family='klines',month='2025-01',bytes=9,SHA256='0'*64,
                      transport='H1_WRAPPER',source_commit='0'*40,wrapper='g',member='g.zip')
        proof=dict(source_commit='0'*40)
        c=gap_classification(frame,np.array([START,START+MINUTE,START+2*MINUTE]),selector,proof)
        self.assertEqual(c['exact_missing_expected_minute_open_us'],[START+MINUTE])
        self.assertEqual(c['affected_asset_minute_cells'],1);self.assertEqual(c['affected_field_cells'],3)
        self.assertEqual(c['contiguous_missing_runs'][0]['last_genuine_prior_observation']['minute_open_us'],START)
        self.assertEqual(c['contiguous_missing_runs'][0]['first_genuine_next_observation']['minute_open_us'],START+2*MINUTE)
        self.assertTrue(c['stage_halted_before_target_account_provider_use'])

    def test_H2_gap_diagnostic_has_no_false_outer_CRC_claim(self):
        import pandas as pd
        frame=pd.DataFrame(dict(timestamp_ms=[START//1000],open=[1.],close=[1.],quote_volume=[3.]))
        selector=dict(selection_id='GENERATED_H2',symbol=SYMBOLS[0],family='klines',month='2025-07',bytes=9,
            SHA256='0'*64,transport='H2_RAW_PARTS',source_commit='0'*40,raw_path='raw/generated.zip')
        c=gap_classification(frame,np.array([START,START+MINUTE]),selector,dict(source_commit='0'*40))
        self.assertEqual(c['selected_outer_CRC_status'],'NOT_APPLICABLE_RAW_PART_REASSEMBLY')
        self.assertEqual(c['selected_inner_CRC_status'],'PASS_SELECTED_EOF')


class GuardBoundaries(unittest.TestCase):
    def assert_blocked(self, callback, category):
        with tempfile.TemporaryDirectory() as folder:
            guard=SourceOnlyGuard((Path(folder),))
            with self.assertRaises(SourceBoundaryViolation):
                with guard:
                    try: callback(Path(folder))
                    except SourceBoundaryViolation: pass
                    guard.checkpoint('MUST_FAIL_EVEN_IF_CAUGHT')
            self.assertGreater(guard.attempts[category],0)
            self.assertFalse(guard.active)
    def test_process_subprocess_os_and_multiprocessing(self):
        import multiprocessing.process
        for callback in (lambda p:subprocess.run(['false']),lambda p:os.system('false'),
                         lambda p:multiprocessing.process.BaseProcess().start()):
            self.assert_blocked(callback,'process_launches')
    def test_network_socket_and_http(self):
        import urllib.request
        for callback in (lambda p:socket.create_connection(('example.com',80)),lambda p:urllib.request.urlopen('https://example.com')):
            self.assert_blocked(callback,'network_calls')
    def test_financial_import_blocks_before_import(self):
        self.assert_blocked(lambda p:__import__('traditional_D_full2022_20261015_v2.full_entry'),'financial_imports')
    def test_financial_GO_filename_and_content(self):
        for callback in (lambda p:(p/'FINANCIAL_GO.json').write_text('{}'),
            lambda p:(p/'arbitrary.json').write_text('{"schema":"FINANCIAL_GO_V1","action":"RUN_ACTUAL","historical_execution_authorized":true}')):
            self.assert_blocked(callback,'financial_GO_writes')
    def test_GO_schema_without_action_still_denied(self):
        for schema in ('ROOT_GO','EXECUTABLE_FINANCIAL_GO'):
            self.assert_blocked(lambda p,schema=schema:(p/'innocuous.json').write_text(json.dumps({'schema':schema})), 'financial_GO_writes')
    def test_raw_descriptor_and_nonallowlisted_workspace_reads_denied(self):
        self.assert_blocked(lambda p:os.open(p/'raw',os.O_CREAT|os.O_WRONLY), 'outside_source_writes')
        self.assert_blocked(lambda p:(ROOT/'NONALLOWLISTED_NO_ACTUAL_BODY_FIXTURE').read_bytes(), 'nonallowlisted_file_reads')
    def test_buffered_raw_financial_json_and_os_write_denied(self):
        def buffer_write(p):
            with (p/'harmless.json').open('w') as stream:
                stream.buffer.write(b'{"schema":"EXECUTABLE_FINANCIAL_GO"}')
        self.assert_blocked(buffer_write,'financial_GO_writes')
        self.assert_blocked(lambda p:os.write(1,b'generated'), 'outside_source_writes')
    def test_claim_and_lease_writes(self):
        self.assert_blocked(lambda p:(p/'EXECUTION_CLAIMS').mkdir(),'canonical_financial_claims_or_leases')
        import fcntl
        self.assert_blocked(lambda p:fcntl.flock(0,fcntl.LOCK_EX),'canonical_financial_claims_or_leases')
    def test_source_artifacts_and_invalid_template_permitted(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);g=SourceOnlyGuard((root,))
            with g:
                (root/'SOURCE_ONLY.json').write_text(json.dumps(dict(status='SOURCE_ONLY',historical_execution_authorized=False)))
                (root/'INVALID_TEMPLATE.json').write_text(json.dumps(dict(schema='FINANCIAL_GO_V1',action='INVALID_TEMPLATE_NOT_ROOT_AUTHORIZATION',status='INVALID_TEMPLATE',historical_execution_authorized=False)))
                g.checkpoint('SOURCE_ONLY_ALLOWED')
            self.assertFalse(any(g.attempts.values()));self.assertTrue(g.installed)
    def test_generated_numpy_and_pure_transform_under_whole_guard(self):
        from contracts import NATIVE, save_new
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);source_code=NATIVE/'metadata/original_normalize.py'
            g=SourceOnlyGuard((root,),read_paths=(source_code,))
            with g:
                ns,ast_sha=pure_normalizer()
                np.savez_compressed(root/'generated.npz',times=np.array([START],dtype=np.int64),x=np.array([1.]))
                raw=(root/'generated.npz').read_bytes()
                arrays=numeric_npz_bytes(raw,['times','x'],shapes={'times':(1,),'x':(1,)},dtypes={'times':'int64','x':'float64'})
                save_new(root/'SOURCE_RECEIPT.json',dict(status='GENERATED_SOURCE_ONLY',array_keys=list(arrays),pure_AST_SHA256=ast_sha,historical_execution_authorized=False))
                g.checkpoint('COMPLETE_GENERATED_SOURCE_LIFECYCLE')
            self.assertFalse(any(g.attempts.values()))
    def test_outside_source_writes_blocked(self):
        self.assert_blocked(lambda p:Path('/tmp/forbidden-source-test.json').write_text('{}'),'outside_source_writes')
    def test_loaded_constructors_advances_provider_and_scope_observed(self):
        module=types.ModuleType('generated_finance_fixture');module.__source_guard_fixture__=True
        class GeneratedAccount:
            def __init__(self): pass
            def execute_fill(self): pass
        class GeneratedProvider:
            def __call__(self): pass
        class FreshHistoricalExecutionScope:
            def __init__(self): pass
        class CaseExecutionScope:
            def __init__(self): pass
        class NativeDailySimulator:
            def __init__(self): pass
        module.GeneratedAccount=GeneratedAccount;module.GeneratedProvider=GeneratedProvider
        module.FreshHistoricalExecutionScope=FreshHistoricalExecutionScope;module.CaseExecutionScope=CaseExecutionScope;module.NativeDailySimulator=NativeDailySimulator
        sys.modules[module.__name__]=module
        account=GeneratedAccount();provider=GeneratedProvider()
        try:
            for callback,category in ((lambda p:GeneratedAccount(),'financial_constructors'),
                (lambda p:account.execute_fill(),'financial_account_advance'),
                (lambda p:provider(),'actual_provider_calls'),
                (lambda p:FreshHistoricalExecutionScope(),'historical_scope_mints'),
                (lambda p:CaseExecutionScope(),'historical_scope_mints'),
                (lambda p:NativeDailySimulator(),'native_simulator_construct_or_advance')):
                self.assert_blocked(callback,category)
        finally: sys.modules.pop(module.__name__,None)


if __name__ == '__main__':
    unittest.main(verbosity=2)
