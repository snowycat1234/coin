"""Independent metadata-only binding audit. Does not import packet/historical code."""
from pathlib import Path
import csv,datetime,decimal,hashlib,io,json,os,re,sys,zipfile
BASE=Path.cwd(); NAME='original_follow_pair_2024_compact_source_report_20261016_v1'
ROOT=BASE/NAME
ARCHIVE=Path(sys.argv[1]) if len(sys.argv)>1 else BASE/(NAME+'.zip')
assert hashlib.sha256(ARCHIVE.read_bytes()).hexdigest()=='71d4b1726c275aa494a19d22f4b84200f2d1811de8fe5b4d7711feece0da4fef','OLD_FROZEN_ARCHIVE_SHA_REQUIRED'
with zipfile.ZipFile(ARCHIVE) as z:BODIES={i.filename.split('/',1)[1]:z.read(i) for i in z.infolist()}
OUT=Path(__file__).resolve().parent
NATIVE='original_follow_pair_next6_D_compressed_native_20261016_v1';SOURCE='original_follow_pair_D_source_20261016_v1';SIGNAL='original_follow_pair_signal_20261016_v1';SAVED='original_follow_pair_next6_D_compressed_saved_independent_review_20261016_v1';PREP=SOURCE+'/source_attempts/ACTUAL_ALL30_SOURCE_TARGET_ONLY_attempt001';ATTEMPT=NATIVE+'/financial_attempts/ACTUAL_NEXT6_2024_attempt001'
CELLS=['2024_'+s+'_'+t+'_D_INTRINSIC_LOWER_ONLY_V1' for s in ('STATIC50_FOLLOW_POOL_SAMEGROSS','STATIC50_FOLLOW_DEPENDENT_SAMEGROSS_CONTROL') for t in ('LOW','MID','HIGH')]
checks=[]
def ck(v,label):
 if not v:raise ValueError(label)
 checks.append(label)
def safe(p):return isinstance(p,str) and bool(p) and not p.startswith('/') and not any(c in p for c in ('\\',':')) and all(x not in ('','.','..') for x in p.split('/'))
def pin_bytes(b):return {'SHA256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def pin(rel):return pin_bytes(BODIES[rel])
def j(rel):return json.loads(BODIES[rel])
def cp(d):return {k:d[k] for k in ('SHA256','bytes')}
prov=j('PROVENANCE_FILE_MAP.json')['files'];orig={e['original_path']:r for r,e in prov.items()}
ck(len(orig)==178 and all(safe(p) and safe(r) for p,r in orig.items()),'178_originals_valid_unique_namespace')
def oj(p):return j(orig[p])
def op(p):return pin(orig[p])
manifest=j('MANIFEST.json');scope=j('SCOPE_AND_LIMITS.json');report=j('reviews/saved/FINAL_SIX_MATRIX.json');audit=j('reviews/saved/FINAL_INDEPENDENT_SAVED_AUDIT.json');binding=j('reviews/saved/CONTROLLER_AND_FINAL_ARTIFACT_BINDING.json');closure=j('reviews/saved/MATRIX_FINAL_CLOSURE.json');go=j('authority/EXISTING_ROOT_GO_INERT.json');frozen=oj(NATIVE+'/FROZEN_SIX_CELL_MANIFEST.json');prep=j('provenance/source_preparation/PREPARATION.json');omits=j('OMITTED_EVIDENCE_PINS.json');dep=j('DEPENDENCY_CLASSIFICATION.json')
ck(go['ordered_cells']==report['ordered_cells']==scope['ordered_cells']==[c['cell_id'] for c in frozen['cells']]==CELLS,'exact_six_2024_cell_order')
ck(go['years']==[2024] and go['old_financial_scope_or_GO_reused'] is False and go['remaining18_authorized'] is False and go['other_years_or_holdouts_authorized'] is False and go['publication_authorized'] is False,'existing_2024_only_inert_authority_scope_no_old_GO_reuse')
for d in frozen['cells']:
 ck(d['year']==2024 and d['calendar_days']==366 and d['start_us']==1704067200000000 and d['end_exclusive_us']==1735689600000000 and d['classification']=='SEEN_DEVELOPMENT_NOT_UNTOUCHED_OOS' and d['fresh_independent_wallet_per_cell'] is True and d['initial_cash_USDT']=='10000','scope_fresh_DEV_calendar:'+d['cell_id'])
for name,key in [('FINANCIAL_CODE_MANIFEST.json','financial_code_manifest_SHA256'),('FROZEN_SIX_CELL_MANIFEST.json','scope_manifest_SHA256'),('NATIVE_SOURCE_DESCRIPTOR.json','native_source_descriptor_SHA256'),('STORAGE_POLICY.json','storage_policy_SHA256')]:ck(op(NATIVE+'/'+name)['SHA256']==go[key],'GO_frozen_pin:'+name)
ck(op(SOURCE+'/CODE_MANIFEST.json')['SHA256']==go['source_code_manifest_SHA256'],'GO_source_code_pin')
ck(pin('provenance/source_preparation/PREPARATION.json')['SHA256']==go['preparation_SHA256'],'GO_source_preparation_pin')
ck(go['all_saved_target_covariance_gross_array_identities'] and len(go['all_saved_target_covariance_gross_array_identities'])==27,'27_target_covariance_gross_identities_metadata_only')
deps={};own_counts={}
for folder,name in [(SIGNAL,'CODE_MANIFEST.json'),(SOURCE,'CODE_MANIFEST.json'),(NATIVE,'FINANCIAL_CODE_MANIFEST.json')]:
 d=oj(folder+'/'+name);own_counts[folder]=len(d['files'])
 for rel,identity in d['files'].items():ck(safe(rel) and op(folder+'/'+rel)==cp(identity),'own_file:'+folder+'/'+rel)
 for p,identity in d.get('dependencies',{}).items():
  ck(safe(p),'dependency_safe:'+p);ck(p not in deps or deps[p]==cp(identity),'dependency_unique_pin:'+p);deps[p]=cp(identity)
ck(len(deps)==300 and set(deps)==set(dep['dependencies']),'300_exhaustive_dependencies')
for p,e in dep['dependencies'].items():
 included=p in orig;ck(e['pin']==deps[p] and e['included'] is included and e['packet_path']==orig.get(p) and e['classification']==('BUNDLED_INERT_BYTES' if included else 'OMITTED_INHERITED_FINANCIAL_CODE_OR_REFERENCE') and (e['reader_limitation'] is None)==included,'dependency_classification:'+p)
ck(all(p in orig for p in oj(SOURCE+'/CODE_MANIFEST.json')['dependencies']),'all_source_direct_dependencies_present')
ck(dep['financial_runtime_closure_complete'] is False,'inherited_financial_closure_explicitly_incomplete')
rows=report['rows'];fields=j('MATRIX_FIELDS.json');csvrows=list(csv.DictReader(io.StringIO(BODIES['reviews/saved/FINAL_SIX_MATRIX.csv'].decode())));csvcount=0;dual=[];cases=[]
ck(len(rows)==len(csvrows)==6 and [r['cell_id'] for r in rows]==CELLS,'six_report_rows')
for i,(r,c) in enumerate(zip(rows,csvrows)):
 cell=CELLS[i];case='cases/'+cell+'/';review=oj(r['review']['path']);receipt=j(case+'CASE_RECEIPT.json');checkpoint=j(case+'TERMINAL_CHECKPOINT.json');proof=j(case+'NATIVE40_RECONSTRUCTION_PROOF.json');risk=j(case+'ACTUAL_HELD_RISK_REPORT.json');quality=j(case+'CAUSAL_MARK_QUALITY.json');bc=binding['checked_case_artifacts'][cell]
 ck(list(c)==fields['CSV_fields'] and set(r)==set(fields['JSON_row_fields']),'exact_CSV_JSON_field_sets:'+cell)
 for k,v in c.items():ck(v==('' if r[k] is None else str(r[k])),'csv_json:'+cell+':'+k);csvcount+=1
 ck(op(r['review']['path'])==cp(r['review'])==cp(audit['per_case_reviews'][cell]),'final_audit_review_pin:'+cell)
 ck(pin(case+'TERMINAL_CHECKPOINT.json')==cp(review['terminal_checkpoint'])==cp(bc['terminal_checkpoint']),'review_controller_checkpoint_pin:'+cell)
 ck(r['completed_minutes']==r['required_minutes']==receipt['completed_minutes']==527040 and r['year']==receipt['year']==2024 and r['actual_paid_market_flat'] is True and r['full_calendar'] is True and r['terminal_status']==receipt['status']=='FULL_CALENDAR_ACTUAL_PAID_MARKET_FLAT','actual_paid_full_calendar:'+cell)
 ck(receipt['root_GO_SHA256']==op(audit['root_GO']['path'])['SHA256'] and receipt['financial_code_manifest_SHA256']==go['financial_code_manifest_SHA256'] and receipt['source_code_manifest_SHA256']==go['source_code_manifest_SHA256'] and receipt['scope_manifest_SHA256']==go['scope_manifest_SHA256'] and receipt['preparation_SHA256']==go['preparation_SHA256'] and receipt['source_identity']==go['native_source_identity'],'receipt_authority_code_source_chain:'+cell)
 ck(receipt['input_binding_SHA256']==go['per_cell_input_binding_SHA256'][cell] and receipt['prepared_source_target_review_SHA256']==go['prepared_source_target_review_SHA256'] and review['all27_array_identities']==go['all_saved_target_covariance_gross_array_identities'],'receipt_input_targets_binding:'+cell)
 ck(checkpoint['restart_financial_snapshot_permission'] is False and checkpoint['fresh_scope_revoked'] is True and checkpoint['all_evidence_fsynced'] is True,'checkpoint_sealed_no_resume:'+cell)
 ck(proof['passed'] is True and proof['status']==r['native40_reconstruction_status']=='PASS_EXACT_EVERY_NATIVE40_EVENT_STATE' and proof['exact_native40_NAV']==r['final_NAV_USDT'] and proof['trade_rows_checked']==r['paid_trade_legs'] and proof['funding_rows_checked']==r['account_applied_funding_events'] and proof['tolerance_or_epsilon_used'] is False,'prior_native40_proof_binding:'+cell)
 ck(proof['checker_SHA256']==checkpoint['checker_SHA256']==receipt['checker_SHA256']==op('bounded_native_continuation_guard50_exit_expansion_20261015/saved_native_reconciliation.py')['SHA256'] and receipt['reconstruction_proof_SHA256']==pin(case+'NATIVE40_RECONSTRUCTION_PROOF.json')['SHA256'],'proof_checker_checkpoint_receipt_chain:'+cell)
 ck(all(review[k]==0 for k in ('debt_forgiveness','internal_transfers','topups','new_capital','review_accounts_constructed','review_providers_constructed','review_source_capture_calls')),'review_zero_finance_mutations:'+cell)
 ck(review['exact_NAV']==r['final_NAV_USDT'] and r['initial_cash_USDT']==review['fresh_shared_initial_cash']=='10000' and r['unpaid_liability_USDT']=='0' and r['conditional_settled_flat'] is False and r['conditional_settlements']==0 and r['account_stop_us'] is None,'report_economics_model_scope:'+cell)
 with decimal.localcontext() as ctx:
  ctx.prec=100;ret=float((decimal.Decimal(r['final_NAV_USDT'])-decimal.Decimal('10000'))/decimal.Decimal('10000'))
 ck(ret==r['paid_net_return']==r['comparable_full_calendar_return'],'exact_NAV_return_arithmetic:'+cell)
 for logical,rawhash in checkpoint['files'].items():
  e=bc['files'][logical]
  if logical in checkpoint['storage']:
   s=checkpoint['storage'][logical];o=omits['files'][e['path']]
   ck(e['encoding']==s['encoding']=='gzip6' and e['path']==ATTEMPT+'/'+cell+'/'+logical+'.gz' and s['logical_name']==logical and s['stored_name']==logical+'.gz','dual_names:'+cell+'/'+logical)
   ck(cp(e)==s['stored']==o['pin'] and {'SHA256':e['raw_SHA256'],'bytes':e['raw_bytes']}==s['raw']==o['raw_pin'] and rawhash==e['raw_SHA256'] and e['SHA256']!=rawhash,'dual_separate_raw_stored_pins:'+cell+'/'+logical)
   ck(o['pin_namespace']=='EXACT_STORED_FILE_BYTES' and o['raw_pin_namespace']=='UNCHANGED_LOGICAL_RUNTIME_JSON_BYTES' and o['stored_pin_namespace']=='EXACT_GZIP6_FILE_BYTES' and o['raw_and_stored_pins_are_not_interchangeable'] is True,'dual_namespace_labels:'+cell+'/'+logical)
   dual.append(dict(cell_id=cell,logical=logical,stored=e['path'],stored_pin=cp(e),raw_pin=s['raw']))
  else:ck(rawhash==e['SHA256'],'checkpoint_uncompressed_digest:'+cell+'/'+logical)
  if e['path'] in orig:ck(op(e['path'])==cp(e),'checkpoint_included_original_pin:'+cell+'/'+logical)
 warning=scope['actual_risk_warnings'][i];ck(warning['cell_id']==cell and all(r[k]==v and (k=='cell_id' or risk[k]==v) for k,v in warning.items()),'all_exact_actual_risk_warnings:'+cell)
 ck(risk['nominal_tier_equality_is_not_exact_realized_risk_matching'] is True and risk['capital_limits_apply_to_risk_increases_not_continuous_marked_state'] is True and risk['omitted_nonpositive_or_later_minutes']==0,'actual_risk_qualifications:'+cell)
 q=scope['exact_saved_2024_minute_quality_impacts'][cell];ck(q==review['quality']==audit['exact_saved_2024_minute_quality_impacts'][cell],'quality_audit_review_scope_chain:'+cell)
 inter=quality['identity']['intervals'][0];imp=q['actual_saved_interval_impacts'][0]
 ck(inter['start_us']==imp['start_us']==1723456980000000 and inter['end_us']==imp['end_us']==1723457100000000 and inter['original_genuine_observation_us']==1723456920000000,'2024_exact_stale_1003_1005_clock:'+cell)
 ck(q['interval_count']==1 and q['derived_mark_cells']==10 and q['source_arrival_or_venue_mark_certified'] is False and q['stale_position_is_not_certified_genuine_mark'] is True and q['quality_block_rows']==q['source_quality_cell_count']==0,'quality_no_genuine_mark_certification:'+cell)
 ck(imp['minute_rows']==2 and imp['guard50_monitor_rows']==1 and all(imp[k]==0 for k in ('funding_rows','owned_funding_rows','paid_trades','ledger_rows','immediate_native_risk_rows','quality_blocks')) and imp['terminal_in_interval'] is False and imp['nonzero_position_minute_cells_by_symbol']=={s:(0 if i==0 and s=='SOLUSDT' else 2) for s in inter['symbols']},'stale_exact_six_event_position_impacts:'+cell)
 cases.append(dict(cell_id=cell,minutes=r['completed_minutes'],paid_net_return=r['paid_net_return'],final_NAV_USDT=r['final_NAV_USDT'],nominal_volatility=r['nominal_annual_volatility_budget'],forecast_volatility_max=r['forecast_annual_volatility_max'],breach_minutes=r['forecast_volatility_breach_minutes'],checkpoint=pin(case+'TERMINAL_CHECKPOINT.json'),proof=pin(case+'NATIVE40_RECONSTRUCTION_PROOF.json')))
ck(csvcount==318 and len(dual)==18,'318_fields_18_dual_raw_stored_pairs')
# Derive omission keys solely from immutable compact metadata. No omitted body reads.
expected={}
def expect(p,e):
 ck(safe(p),'omitted_namespace:'+p)
 if p not in orig:
  pp=cp(e);ck(p not in expected or expected[p]==pp,'omitted_unique_pin:'+p);expected[p]=pp
for c in binding['checked_case_artifacts'].values():
 for e in c['files'].values():expect(e['path'],e)
expect(binding['controller_terminal']['path'],binding['controller_terminal']);expect(audit['root_GO']['path'],audit['root_GO'])
for rel,e in prep['artifacts'].items():expect(PREP+'/'+rel,e)
def collect(d):
 if isinstance(d,dict):
  if all(k in d for k in ('path','SHA256','bytes')):expect(d['path'],d)
  for v in d.values():collect(v)
 elif isinstance(d,list):
  for v in d:collect(v)
collect(oj(NATIVE+'/NATIVE_SOURCE_DESCRIPTOR.json'));collect(oj(SOURCE+'/HLC_SOURCE_CONTRACT_MAP.json')['read_files']['2024']);collect(oj(SOURCE+'/CLOSE_PREFIX_SOURCE_MAP.json')['years']['2024'])
ck(len(expected)==196 and set(expected)==set(omits['files']),'196_exhaustive_omission_pins')
for p,e in omits['files'].items():ck(e['pin']==expected[p] and e['included'] is False and e['hashes_restore_omitted_bytes'] is False,'omission_pin_limitation:'+p)
exit=j('receipts/ROOT_OBSERVED_EXIT_CONFIRMED.json');disp=closure['final_authoritative_disposition'];ck(exit['session_id']==audit['root_session_id']==disp['root_session_id']==75308 and exit['observed_exit_code']==audit['root_observed_exit_code']==disp['root_observed_exit_code']==0,'root_75308_observed_EXIT0')
ck(cp(audit['root_observed_exit'])==pin('receipts/ROOT_OBSERVED_EXIT_CONFIRMED.json')==cp(closure['root_observed_exit']) and audit['root_observed_exit']['path']==ATTEMPT+'/ROOT_OBSERVED_EXIT_CONFIRMED.json','root_receipt_audit_closure_chain')
ck(report['root_exit_receipt_pending'] is True and j('reviews/saved/FINAL_BINDING.json')['root_exit_receipt_pending'] is True and disp['root_exit_receipt_pending'] is False and closure['immutable_matrix_field']['stored_value'] is True,'historical_pending_preserved_final_disposition_false')
ck('already existed' in closure['immutable_matrix_field']['qualification'] and 'deferred certification' in closure['immutable_matrix_field']['qualification'] and closure['original_matrix_mutated'] is False and closure['original_final_audit_mutated'] is False,'closure_unambiguously_explains_preexisting_receipt_deferred_stage')
ck(cp(closure['matrix'])==pin('reviews/saved/FINAL_SIX_MATRIX.json')==cp(audit['matrix_JSON']) and cp(closure['final_independent_audit'])==pin('reviews/saved/FINAL_INDEPENDENT_SAVED_AUDIT.json') and closure['controller_and_final_artifact_binding']==audit['controller_and_final_artifact_binding']==report['controller_and_final_artifact_binding'],'closure_matrix_audit_controller_chain')
readme=BODIES['README.md'].decode();readscope=json.loads(readme.split('SCOPE_JSON_BEGIN\n')[1].split('\nSCOPE_JSON_END')[0]);normal=json.loads((OUT/'COLD_NORMAL.json').read_bytes());optimized=json.loads((OUT/'COLD_OPTIMIZED.json').read_bytes());ck(readscope==scope==manifest['scope_and_limitations']==normal['scope_and_limitations']==optimized['scope_and_limitations'],'identical_README_SCOPE_MANIFEST_both_PASS_disclosures')
ck(scope['scope']=='COMPACT_REPORT_AND_SOURCE_BINDINGS_ONLY' and scope['limitation_sentence']=='compact report and source bindings only; omitted full event history means the public packet alone CANNOT reconstruct all native40 checks.' and scope['public_packet_alone_CANNOT_reconstruct_all_native40_checks'] is True and scope['full_event_history_omitted'] is True and scope['adaptive_DEV_only'] is True and scope['existing_authority_copy']=='INERT_EXISTING_BYTES_NOT_REISSUED_NOT_RUN_PERMISSION','actual_scope_honest_compact_only_DEV_inert_authority')
falsekeys=['risk_matched_claim','post_tier_samegross_guaranteed','continuous_risk_ceiling_guaranteed','all37_or_current_D_all30_completion_claim','remaining18_authorized','OOS_or_live_certification','deployability_established','native_venue_or_liquidation_certified','funding_units_or_arrival_certified','target_recomputation_available','financial_history_self_contained','financial_runtime_closure_complete','source_or_financial_execution_authorized','upload_authority_granted','publication_performed']
ck(all(scope[k] is False for k in falsekeys),'actual_scope_no_excess_claims')
paired=j('reviews/saved/PAIRED_ACTUAL_GROSS_AND_NOMINAL_RISK.json');ck(len(paired['rows'])==3 and paired['actual_gross_and_risk_are_not_matched'] is True and paired['continuous_risk_ceiling_guaranteed'] is False,'three_pair_marked_gross_qualifications')
for i,p in enumerate(paired['rows']):ck(p['pool']==CELLS[i] and p['dependent_control']==CELLS[i+3] and p['common_minutes']==527040 and p['actual_minutes_with_nonzero_gross_difference']==522659 and p['actual_gross_difference_max_absolute']>0 and p['risk_matched_claim'] is False and p['post_tier_samegross_guaranteed'] is False,'actual_marked_gross_nonzero:'+p['tier'])
for p,h in {'original_follow_pair_first6_compact_source_report_20261016_v1.zip':'73901dc04248d1ce3e31e88b0fab8e9b06332232a5cd70aea4ae5537b1a186f0','original_follow_pair_first6_compact_source_report_20261016_v1/MANIFEST.json':'104fa9dea4eb8bbf4c2f9fec379e1290f2b0106df0423645b0e53fcfea12c173'}.items():ck(hashlib.sha256((BASE/p).read_bytes()).hexdigest()==h,'prior2023_immutable:'+p)
result=dict(schema='FOLLOW_2024_INDEPENDENT_FACTUAL_COMPACT_BINDINGS_V1',status='PASS_FACTUAL_COMPACT_METADATA_ONLY_READER_HARDENING_DEFECTS_SEPARATE',checks=len(checks),scope=scope,cases=cases,own_file_counts=own_counts,dependencies=len(deps),included_dependencies=sum(e['included'] for e in dep['dependencies'].values()),omitted_dependencies=sum(not e['included'] for e in dep['dependencies'].values()),omission_pins=len(expected),gzip6_dual_pairs=len(dual),CSV_JSON_fields=csvcount,root_final_disposition=disp,matrix_historical_pending_true_preserved=True,closure_qualification=closure['immutable_matrix_field'],paired_marked_gross_differences=paired['rows'],omitted_bodies_read=0,new_source_or_financial_executions=0,historical_modules_imported=0,publication_or_network_actions=0,CPU_affinity=sorted(os.sched_getaffinity(0)))
(OUT/'FACTUAL_BINDINGS.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ('scope','cases','paired_marked_gross_differences')},sort_keys=True))
