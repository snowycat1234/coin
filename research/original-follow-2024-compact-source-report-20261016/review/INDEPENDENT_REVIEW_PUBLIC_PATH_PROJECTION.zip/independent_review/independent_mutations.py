"""Independent in-memory resealed compact mutations. No frozen files modified."""
from pathlib import Path
import copy,hashlib,json,os,sys,zipfile,types
ROOT=Path.cwd()/'original_follow_pair_2024_compact_source_report_20261016_v1'
OUT=Path(__file__).resolve().parent
archive=Path(sys.argv[1]) if len(sys.argv)>1 else ROOT.with_suffix('.zip')
assert hashlib.sha256(archive.read_bytes()).hexdigest()=='71d4b1726c275aa494a19d22f4b84200f2d1811de8fe5b4d7711feece0da4fef','OLD_FROZEN_ARCHIVE_SHA_REQUIRED'
with zipfile.ZipFile(archive) as z:baseline={i.filename.split('/',1)[1]:z.read(i) for i in z.infolist()}
v=types.ModuleType('independent_compact_reader');exec(compile(baseline['verify_packet.py'],str(ROOT/'verify_packet.py'),'exec'),v.__dict__)
original_read_bytes=Path.read_bytes;original_read_text=Path.read_text;original_rglob=Path.rglob;original_is_file=Path.is_file;original_is_symlink=Path.is_symlink
overlay={}
def rb(p):
 if p.resolve().is_relative_to(ROOT):
  rel=str(p.resolve().relative_to(ROOT));return overlay.get(rel,baseline.get(rel,b''))
 return original_read_bytes(p)
def rg(p,pattern):return (ROOT/rel for rel in baseline) if p.resolve()==ROOT and pattern=='*' else original_rglob(p,pattern)
def isf(p):return str(p.resolve().relative_to(ROOT)) in baseline if p.resolve().is_relative_to(ROOT) else original_is_file(p)
def iss(p):return False if p.resolve().is_relative_to(ROOT) else original_is_symlink(p)
def rt(p,encoding=None,errors=None):return rb(p).decode(encoding or 'utf-8',errors or 'strict')
Path.read_bytes=rb;Path.read_text=rt;Path.rglob=rg;Path.is_file=isf;Path.is_symlink=iss

def jget(rel):return json.loads(overlay.get(rel,baseline[rel]))
def putj(rel,d):overlay[rel]=(json.dumps(d,sort_keys=True,indent=2)+'\n').encode()
def reseal():
 m=jget('MANIFEST.json')
 for rel,body in overlay.items():
  if rel!='MANIFEST.json':m['files'][rel]={'SHA256':hashlib.sha256(body).hexdigest(),'bytes':len(body)}
 putj('MANIFEST.json',m)
def scope_change(fn):
 s=jget('SCOPE_AND_LIMITS.json');fn(s);putj('SCOPE_AND_LIMITS.json',s)
 m=jget('MANIFEST.json');m['scope_and_limitations']=s;putj('MANIFEST.json',m)
 pre,post=baseline['README.md'].decode().split('SCOPE_JSON_BEGIN\n',1);old,end=post.split('\nSCOPE_JSON_END',1)
 overlay['README.md']=(pre+'SCOPE_JSON_BEGIN\n'+json.dumps(s,sort_keys=True,indent=2)+'\nSCOPE_JSON_END'+end).encode()

def report_coordinated_risk():
 d=jget('reviews/saved/FINAL_SIX_MATRIX.json');d['rows'][0]['forecast_annual_volatility_max']=0.04;putj('reviews/saved/FINAL_SIX_MATRIX.json',d)
 p=jget('PROVENANCE_FILE_MAP.json');p['files']['reviews/saved/FINAL_SIX_MATRIX.json']['original_pin']={'SHA256':hashlib.sha256(overlay['reviews/saved/FINAL_SIX_MATRIX.json']).hexdigest(),'bytes':len(overlay['reviews/saved/FINAL_SIX_MATRIX.json'])};putj('PROVENANCE_FILE_MAP.json',p)
 scope_change(lambda s:s['actual_risk_warnings'][0].update(forecast_annual_volatility_max=0.04))
def dep_mutation(key,value):
 d=jget('DEPENDENCY_CLASSIFICATION.json');p=next(k for k,e in d['dependencies'].items() if e['included']);d['dependencies'][p][key]=value;putj('DEPENDENCY_CLASSIFICATION.json',d)
def omission_namespace():
 d=jget('OMITTED_EVIDENCE_PINS.json');p=next(iter(d['files']));d['files']['../escape']=d['files'].pop(p);putj('OMITTED_EVIDENCE_PINS.json',d)
def omission_swap():
 d=jget('OMITTED_EVIDENCE_PINS.json');e=next(e for e in d['files'].values() if 'raw_pin' in e);e['pin'],e['raw_pin']=e['raw_pin'],e['pin'];putj('OMITTED_EVIDENCE_PINS.json',d)
def closure_pending():
 rel='reviews/saved/MATRIX_FINAL_CLOSURE.json';d=jget(rel);d['final_authoritative_disposition']['root_exit_receipt_pending']=True;putj(rel,d);p=jget('PROVENANCE_FILE_MAP.json');p['files'][rel]['original_pin']={'SHA256':hashlib.sha256(overlay[rel]).hexdigest(),'bytes':len(overlay[rel])};putj('PROVENANCE_FILE_MAP.json',p)
def provenance_escape():
 d=jget('PROVENANCE_FILE_MAP.json');rel='snapshots/original_follow_pair_next6_D_compressed_independent_review_20261016_v1/FINAL_REVIEW_FACTS.json';d['files'][rel]['original_path']='../escape.json';putj('PROVENANCE_FILE_MAP.json',d)

cases=[
 ('coordinated_scope_risk_matched_true',lambda:scope_change(lambda s:s.update(risk_matched_claim=True))),
 ('coordinated_scope_financial_replay_true',lambda:scope_change(lambda s:s.update(financial_history_self_contained=True))),
 ('coordinated_scope_target_recomputation_true',lambda:scope_change(lambda s:s.update(target_recomputation_available=True))),
 ('coordinated_scope_all30_true',lambda:scope_change(lambda s:s.update(all37_or_current_D_all30_completion_claim=True))),
 ('coordinated_scope_continuous_risk_true',lambda:scope_change(lambda s:s.update(continuous_risk_ceiling_guaranteed=True))),
 ('coordinated_scope_risk_warning_value',lambda:scope_change(lambda s:s['actual_risk_warnings'][0].update(forecast_annual_volatility_max=0.04))),
 ('coordinated_scope_and_report_risk_value',report_coordinated_risk),
 ('coordinated_quality_stale_clock',lambda:scope_change(lambda s:s.update(quality_original_genuine_observation_us=1723456980000000))),
 ('coordinated_quality_venue_certification',lambda:scope_change(lambda s:s['exact_saved_2024_minute_quality_impacts'][v.CELLS[0]].update(source_arrival_or_venue_mark_certified=True))),
 ('coordinated_quality_derived_count',lambda:scope_change(lambda s:s['exact_saved_2024_minute_quality_impacts'][v.CELLS[0]].update(derived_mark_cells=0))),
 ('coordinated_closure_pending_true',closure_pending),
 ('gzip_stored_raw_swap',omission_swap),
 ('dependency_path_parent_escape',lambda:dep_mutation('packet_path','../escape.py')),
 ('dependency_path_absolute_escape',lambda:dep_mutation('packet_path','/tmp/escape.py')),
 ('dependency_included_flag_false',lambda:dep_mutation('included',False)),
 ('omission_key_parent_escape',omission_namespace),
 ('provenance_original_parent_escape',provenance_escape),
 ('coordinated_risk_prose_contradiction',lambda:scope_change(lambda s:s.update(actual_risk_interpretation='These six outcomes are risk-matched and continuous risk ceilings are guaranteed. Historical breach counts 88406 and 69176 do not limit certification.'))),
 ('coordinated_quality_prose_contradiction',lambda:scope_change(lambda s:s.update(quality_interpretation='All stale interval marks are certified genuine current venue observations; there was no stale-position exposure.'))),
 ('coordinated_scope_DEV_false',lambda:scope_change(lambda s:s.update(adaptive_DEV_only=False))),
 ('coordinated_authority_reissued_prose',lambda:scope_change(lambda s:s.update(existing_authority_copy='REISSUED_NEW_EXECUTION_PERMISSION'))),
]
results=[]
try:
 positive=v.verify(ROOT);assert positive['status']=='PASS_COMPACT_REPORT_AND_SOURCE_BINDINGS_ONLY'
 for label,action in cases:
  overlay.clear();action();reseal()
  try:
   result=v.verify(ROOT)
  except Exception as e:results.append(dict(label=label,rejected=True,error_type=type(e).__name__,message=str(e)))
  else:results.append(dict(label=label,rejected=False,status=result['status']))
finally:Path.read_bytes=original_read_bytes;Path.read_text=original_read_text;Path.rglob=original_rglob;Path.is_file=original_is_file;Path.is_symlink=original_is_symlink
out=dict(schema='FOLLOW_2024_INDEPENDENT_STRONG_MUTATIONS_V1',method='Original externally SHA-authenticated ZIP and compact reader invoked through virtual in-memory archive files and fully resealed edits; no packet/cache/original changes or duplicate extraction.',cases=len(results),rejected=sum(r['rejected'] for r in results),accepted=[r['label'] for r in results if not r['rejected']],results=results,CPU_affinity=sorted(os.sched_getaffinity(0)))
(OUT/'STRONG_MUTATIONS.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps(out,sort_keys=True))
