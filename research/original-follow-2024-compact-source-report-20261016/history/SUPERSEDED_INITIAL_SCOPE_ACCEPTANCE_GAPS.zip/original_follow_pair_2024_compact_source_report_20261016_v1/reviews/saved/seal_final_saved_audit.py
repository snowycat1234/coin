"""Distinct next-six saved-only root-exit seal and aligned gross comparisons.

Only current saved minute payloads and prepared 2024 target arrays are decoded.
No source, provider, target generation, account or claim operation is allowed.
"""
from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
import gc, gzip, json, os, sys, resource

OUT=Path(__file__).resolve().parent;ROOT=OUT.parent
MODULE=ROOT/'original_follow_pair_next6_D_compressed_native_20261016_v1'
COHORT=MODULE/'financial_attempts/ACTUAL_NEXT6_2024_attempt001'
PREP=ROOT/'original_follow_pair_D_source_20261016_v1/source_attempts/ACTUAL_ALL30_SOURCE_TARGET_ONLY_attempt001'
PRIOR=ROOT/'original_follow_pair_first6_D_recovery_saved_independent_review_20261016_v2'
GO_SHA='78b09b69f494eb0e7607f4ff2e6b6161d1c7bebf7ff52e687aa868e75948a6c4'
CODE_SHA='783e2115ab281a0acc05b9d3f03962b6c730a36906b371ed2c0a167f867e62d4'
assert sorted(os.sched_getaffinity(0))==[8]
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','POLARS_MAX_THREADS','VECLIB_MAXIMUM_THREADS','BLIS_NUM_THREADS'):assert os.environ.get(k)=='1'
resource.setrlimit(resource.RLIMIT_AS,(4_000_000_000,4_000_000_000))
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
blocked=[]
def boundary(event,args):
    if event in ('subprocess.Popen','os.system','os.fork','os.forkpty','os.posix_spawn','socket.connect'):
        blocked.append(event);raise RuntimeError('NO_EXTERNAL_ACTION_IN_SAVED_SEAL')
    if event=='open' and not isinstance(args[0],int):
        name,mode,flags=args
        if isinstance(name,(str,bytes,os.PathLike)) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND):
            path=Path(os.path.abspath(os.fsdecode(name)))
            if not path.is_relative_to(OUT):blocked.append(str(path));raise RuntimeError('CANONICAL_WRITES_FORBIDDEN')
sys.addaudithook(boundary)
def raw(path):
    assert not path.is_symlink() and all(not p.is_symlink() for p in path.parents)
    return path.read_bytes()
def obj(path):return json.loads(raw(path))
def pin(path):
    h=sha256();size=0
    with path.open('rb') as f:
        for block in iter(lambda:f.read(8*1024*1024),b''):h.update(block);size+=len(block)
    return dict(path=str(path.relative_to(ROOT)),SHA256=h.hexdigest(),bytes=size)
def put(name,value):
    b=(json.dumps(value,indent=2,sort_keys=True,allow_nan=False)+'\n').encode()
    assert len(b)<500_000
    assert sum(p.stat().st_size for p in OUT.rglob('*') if p.is_file())+len(b)<2_000_000
    st=os.statvfs(OUT);assert st.f_bavail*st.f_frsize-len(b)>=1_610_612_736
    with (OUT/name).open('xb') as f:f.write(b);f.flush();os.fsync(f.fileno())
    return pin(OUT/name)
forbidden=[]
def no_execution(frame,event,arg):
    if event!='call':return
    module=frame.f_globals.get('__name__','');name=frame.f_code.co_name;qn=frame.f_code.co_qualname
    bad=(module=='run_follow' and name in ('case','controller','load_saved_year','bootstrap')
        or module=='follow_admission' and (name=='admit_case' or qn.startswith(('FreshHistoricalExecutionScope.','CapturedMinuteProvider.')))
        or module=='follow_input_loader' and name in ('load_year','__init__')
        or module in ('follow_native_source','follow_native_source2024','follow_source') and name in ('capture_year','assemble_inputs')
        or module=='follow_claims' and name=='reserve'
        or module=='follow_process_runtime' and name in ('run_pool','controller_lease','shared_resource_lease')
        or module=='follow_native' and name in ('construct_case','_construct_case')
        or module in ('follow_signal','follow_native_signal') and name=='build_target_grid'
        or name in ('make_owned_account','make_account')
        or name=='__init__' and any(x in qn for x in ('Account.','Simulator.','Simulation.')))
    if bad:forbidden.append(dict(module=module,function=qn));raise RuntimeError('SAVED_SEAL_FORBIDDEN_EXECUTION')
sys.setprofile(no_execution)
sys.path.insert(0,str(MODULE))
import follow_finance_gate as gate,follow_native as native,follow_saved as saved
import follow_source_entry as entry,follow_native_codec as codec,follow_native_common as c
import numpy as np
assert gate.code_identity()==CODE_SHA
reuse=obj(MODULE/'REUSED_FUNCTION_MAP.json');assert len(reuse['inherited_account_methods'])==31 and len(reuse['guard_methods'])==3
for name in reuse['inherited_account_methods']:
    current=getattr(native.ExpansionAccount,name);frozen=getattr(native.D.Guard50ExitAccount,name)
    assert getattr(current,'__func__',current) is getattr(frozen,'__func__',frozen) and current.__code__ is frozen.__code__,name
for name in reuse['guard_methods']:assert getattr(native.ContinuationGuard,name).__code__ is getattr(native.D.ContinuationGuard,name).__code__,name
initial=obj(OUT/'INITIAL_BINDING.json');binding=obj(OUT/'FINAL_BINDING.json')
controller=obj(OUT/'CONTROLLER_AND_FINAL_ARTIFACT_BINDING.json');matrix=obj(OUT/'FINAL_SIX_MATRIX.json')
assert initial['root_GO']['SHA256']==GO_SHA and binding['financial_code_manifest_SHA256']==CODE_SHA
assert binding['completed_cell_count']==6 and binding['review_error_count']==0 and not binding['review_errors']
assert binding['status']=='PASS_NEXT6_2024_SAVED_ONLY' and not binding['boundary_attempts'] and not binding['review_forbidden_execution_calls']
assert controller['status']=='PASS_NEXT6_2024_EXACT_SAVED_CONTROLLER'
assert controller['required_next6_2024_minutes']==3_162_240
assert matrix['status']=='PASS_EXACT_SAVED_FULL_SIX' and len(matrix['rows'])==6
cells=initial['ordered_cells'];reports={cell:obj(OUT/(cell+'.review.json')) for cell in cells}
assert cells==obj(PREP/'PREPARATION.json')['ordered_cells'][6:12]
exit_path=COHORT/'ROOT_OBSERVED_EXIT_CONFIRMED.json';exit_value=obj(exit_path)
assert type(exit_value['session_id']) is int and exit_value['session_id']==75308
assert type(exit_value['observed_exit_code']) is int and exit_value['observed_exit_code']==0
assert isinstance(exit_value['observed_utc'],str)
checks=[];minute={}
for cell,report in reports.items():
    assert pin(OUT/(cell+'.review.json'))==binding['per_cell_reviews'][cell]
    d=COHORT/cell;assert pin(d/'TERMINAL_CHECKPOINT.json')==report['terminal_checkpoint']
    checkpoint=obj(d/'TERMINAL_CHECKPOINT.json')
    result_raw=gzip.decompress(raw(d/'NATIVE_RESULT.json.gz'))
    assert sha256(result_raw).hexdigest()==checkpoint['files']['NATIVE_RESULT.json']
    result=json.loads(result_raw);summary=result['summary'];economics=result['economics']
    assert summary['decimal_strings']['NAV']==report['exact_NAV']
    assert summary['all_observation_max_drawdown']==economics['all_observation_max_drawdown']==report['all_observation_max_drawdown']
    witnesses=[r for r in result['extrema'] if r['kind']=='MAX_DRAWDOWN']
    witness=None
    if summary['all_observation_max_drawdown']>0:
        assert len(witnesses)==1;witness=witnesses[0]
        assert witness['max_drawdown']==summary['all_observation_max_drawdown']
        assert 1-witness['NAV']/witness['peak_NAV']==witness['max_drawdown']
        assert 1704067200000000<=witness['event_us']<=1735689600000000
    assert summary['actual_caps_instantaneously_guaranteed'] is False
    assert summary['unit_certified'] is False and summary['publication_certified'] is False
    checks.append(dict(cell_id=cell,all_observation_MDD=summary['all_observation_max_drawdown'],saved_MAX_DRAWDOWN_witness=witness,
        saved_witness_arithmetic_checked=True,full_all_observation_stream_independently_replayed=False,
        maximum_actual_gross_weight_all_observations=summary['maximum_actual_gross_weight'],
        maximum_actual_asset_weights_all_observations=summary['maximum_actual_asset_weights'],
        minimum_actual_free_cash_all_observations_USDT=summary['minimum_actual_free_cash_all_observations_USDT'],
        margin_risk_observation_scope=summary['margin_risk_observation_scope'],
        actual_caps_instantaneously_guaranteed=False,
        source_funding_events=summary['funding_original_events'],observed_funding_events=summary['funding_observed_events'],
        account_applied_funding_events=summary['funding_account_applied_events'],owned_funding_events=summary['funding_owned_events'],
        fresh_flat_no_past_mark_events=summary['fresh_flat_no_past_mark_events'],funding_source_coverage_is_not_ownership=True))
    mraw=c.exact(d/'MINUTE.npz',checkpoint['files']['MINUTE.npz'])
    values,columns=saved.saved_minute(mraw,report['completed_minutes'],cell_id=cell)
    minute[cell]=(values,columns)
    del result,result_raw,mraw;gc.collect()
prep=obj(PREP/'PREPARATION.json');t=prep['artifacts']['2024/TARGETS.npz']
arrays=codec.npz(c.exact(PREP/'2024/TARGETS.npz',t['SHA256'],t['bytes']),entry.array_specs(2024))
paired=[]
for tier in ('LOW','MID','HIGH'):
    p=next(cell for cell in cells if reports[cell]['tier']==tier and reports[cell]['strategy']=='STATIC50_FOLLOW_POOL_SAMEGROSS')
    q=next(cell for cell in cells if reports[cell]['tier']==tier and reports[cell]['strategy']=='STATIC50_FOLLOW_DEPENDENT_SAMEGROSS_CONTROL')
    pv,pc=minute[p];qv,qc=minute[q];n=min(len(pv),len(qv))
    assert np.array_equal(pv[:n,pc.index('close_us')],qv[:n,qc.index('close_us')])
    diff=pv[:n,pc.index('gross_weight')]-qv[:n,qc.index('gross_weight')]
    target_diff=arrays['post_tier_pool_gross_'+tier]-arrays['post_tier_control_gross_'+tier]
    paired.append(dict(tier=tier,pool=p,dependent_control=q,comparison_scope='COMMON_POST_TRANSITION_MINUTE_CLOSE_PREFIX_ONLY',
        common_minutes=n,both_full_calendar=reports[p]['full_calendar'] and reports[q]['full_calendar'],
        actual_gross_pool_minus_control_min=float(diff.min()) if n else None,
        actual_gross_pool_minus_control_max=float(diff.max()) if n else None,
        actual_gross_pool_minus_control_mean=float(diff.mean()) if n else None,
        actual_gross_difference_max_absolute=float(np.abs(diff).max()) if n else None,
        actual_minutes_with_nonzero_gross_difference=int(np.count_nonzero(diff)),
        post_tier_target_days_with_nonzero_gross_difference=int(np.count_nonzero(target_diff)),
        post_tier_target_gross_pool_minus_control_min=float(target_diff.min()),
        post_tier_target_gross_pool_minus_control_max=float(target_diff.max()),
        post_tier_target_gross_difference_max_absolute=float(np.abs(target_diff).max()),
        intrinsic_samegross=True,post_tier_samegross_guaranteed=False,risk_matched_claim=False,
        pool_forecast_nominal_tier_breach_minutes=reports[p]['actual_held_risk_and_exposure'].get('forecast_volatility_breach_minutes'),
        control_forecast_nominal_tier_breach_minutes=reports[q]['actual_held_risk_and_exposure'].get('forecast_volatility_breach_minutes'),
        pool_forecast_annual_volatility_max=reports[p]['actual_held_risk_and_exposure'].get('forecast_annual_volatility_max'),
        control_forecast_annual_volatility_max=reports[q]['actual_held_risk_and_exposure'].get('forecast_annual_volatility_max'),
        nominal_annual_volatility_budget=reports[p]['actual_held_risk_and_exposure'].get('nominal_annual_volatility_budget')))
gross_pin=put('PAIRED_ACTUAL_GROSS_AND_NOMINAL_RISK.json',dict(schema='FOLLOW_NEXT6_2024_INDEPENDENT_ALIGNED_ACTUAL_GROSS_V1',
    status='PASS_SAVED_PAIR_ALIGNMENT_ONLY',rows=paired,continuous_risk_ceiling_guaranteed=False,
    numerical_comparisons_use_exact_saved_float64_values_no_tolerance=True,
    actual_gross_and_risk_are_not_matched=True,post_tier_samegross_guaranteed=False))
prior_final=pin(PRIOR/'FINAL_INDEPENDENT_SAVED_AUDIT.json')
prior_matrix=pin(PRIOR/'FINAL_SIX_MATRIX.json')
assert prior_final['SHA256']=='30cf740e8ce6b72fbcb0d1d91cdd9988f7452cae4ab158a346d21d5de37ee002'
assert prior_matrix['SHA256']=='f101fce42ea0528d25184fb2755b73078ea9cd68dae39c6e8df3ca78dc8ea6e5'
tids=[sorted(os.sched_getaffinity(int(t))) for t in os.listdir('/proc/self/task')]
assert tids and all(t==[8] for t in tids) and not blocked and not forbidden
final=put('FINAL_INDEPENDENT_SAVED_AUDIT.json',dict(schema='INDEPENDENT_FOLLOW_NEXT6_2024_COMPRESSED_FINAL_SAVED_AUDIT_V1',
    UTC=datetime.now(timezone.utc).isoformat(),status='PASS_NEXT6_2024_SAVED_OFFLINE_MODEL_WITH_QUALIFICATIONS_AND_ROOT_EXIT0',
    root_observed_exit=pin(exit_path),root_session_id=75308,root_observed_exit_code=0,
    root_GO=initial['root_GO'],financial_code_manifest=pin(MODULE/'FINANCIAL_CODE_MANIFEST.json'),
    initial_authority_and_code_binding=pin(OUT/'INITIAL_BINDING.json'),per_case_saved_binding=pin(OUT/'FINAL_BINDING.json'),
    controller_and_final_artifact_binding=pin(OUT/'CONTROLLER_AND_FINAL_ARTIFACT_BINDING.json'),
    matrix_JSON=pin(OUT/'FINAL_SIX_MATRIX.json'),matrix_CSV=pin(OUT/'FINAL_SIX_MATRIX.csv'),
    paired_actual_gross_and_nominal_risk=gross_pin,per_case_reviews=binding['per_cell_reviews'],
    completed_cases=6,total_completed_minutes=controller['reviewed_completed_minutes'],required_minutes=3_162_240,
    full_calendar_cases=controller['full_calendar_cases'],actual_paid_market_flat_cases=controller['actual_paid_market_flat_cases'],
    conditional_settled_cases=controller['conditional_settled_flat_cases'],
    economic_halt_cases=sum(r['terminal_status']=='NATIVE_HALT_PARTIAL_CALENDAR' for r in reports.values()),
    resource_source_validation_pause_cases=0,native40_every_event_reconstruction_verified=True,
    exact_complete_logical_and_physical_artifact_namespaces_verified=True,
    raw_and_stored_gzip6_dual_pins_independently_verified=True,MINUTE_NPZ_encoding_unchanged=True,
    all_sealed_raw_and_stored_digests_rehashed_after_controller_terminal=True,
    all27_saved_target_covariance_and_gross_array_identities_verified=True,
    exact_literal_funding_clocks_and_unscaled_raw_rates_verified=True,
    exact_all30_preparation_cells_6_through_11_only=True,
    source_and_native_scopes_revoked_and_source_guard_forbidden_attempts_zero=True,
    financial_function_and_code_object_identities=31,guard_code_object_identities=3,
    quantity_funding_BASE27_paid_terminal_restrictions_verified=True,
    no_internal_transfers_topups_new_capital_or_debt_forgiveness=True,
    all_observation_extrema_witness_checks=checks,
    exact_saved_2024_minute_quality_impacts={cell:r['quality'] for cell,r in reports.items()},
    prior2023_final_audit_preserved=prior_final,prior2023_matrix_preserved=prior_matrix,
    canonical_prior_failures_and_results_modified=False,
    intrinsic_samegross=True,independent_lower_only_tiering=True,post_tier_samegross_guaranteed=False,
    continuous_risk_ceiling_guaranteed=False,risk_matched_claim=False,target_equivalent_tiers_separate_fresh_accounts=True,
    remaining18_authorized=False,adaptive_DEV_only=True,untouched_OOS_or_candidate_qualification=False,
    model_cost_offline_only=True,source_arrival_raw_funding_units_venue_filters_and_native_liquidation_uncertified=True,
    deployability_established=False,observed_resource_qualifications=controller['resource_qualifications'],
    disk_polling_not_quota_external_writer_or_annual_envelope_guarantee=True,
    review_CPU_affinity=[8],all_review_TID_affinities=tids,numerical_pools=1,
    saved_auditor=pin(OUT/'audit_actual_saved.py'),controller_finalizer=pin(OUT/'finalize_controller_and_matrix.py'),
    final_sealer=pin(Path(__file__)),review_peak_RSS_bytes=binding['review_peak_RSS_bytes'],
    review_forbidden_execution_calls=forbidden,review_boundary_attempts=blocked,
    review_financial_replays=0,review_accounts_scopes_or_providers_constructed=0,review_source_recaptures=0,
    review_claims_or_GO_issued=0,canonical_outputs_modified=0,network_actions=0,publication_actions=0))
print(json.dumps(dict(status='PASS',evidence=final,paired_gross_risk=gross_pin),sort_keys=True))
