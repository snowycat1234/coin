"""Metadata-only next6 scope and generated in-memory authority admission."""
from copy import deepcopy
from pathlib import Path
import unittest
import numpy as np
import follow_native_common as c
import follow_native_config as config
import follow_source_entry as entry
import follow_finance_gate as gate

class NextAuthorityTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.prep=c.ordinary(c.ROOT/'original_follow_pair_D_source_20261016_v1/source_attempts/ACTUAL_ALL30_SOURCE_TARGET_ONLY_attempt001/PREPARATION.json')
  cls.audit=c.ordinary(c.ROOT/'original_follow_pair_D_prepared_independent_review_20261016_v1/PREPARED_REVIEW.json')
 def bundle(self):
  nr=c.canonical(gate.native_policy('0'*64));rr=c.canonical(gate.review_policy(self.prep,c.sha(self.audit),c.sha(nr)));go=c.canonical(gate.policy(self.prep,c.sha(rr),c.sha(self.audit),c.sha(nr),[4,5]));return go,rr,nr
 def check(self,go,rr,nr):return gate.validate(self.prep,go,c.sha(go),rr,c.sha(rr),self.audit,c.sha(self.audit),nr,c.sha(nr))
 def test_exact_frozen_all30_slice_and_leap_year_only(self):
  all30=c.exact_object(c.ordinary(c.ROOT/'original_follow_pair_D_source_20261016_v1/FROZEN_THIRTY_CELL_MANIFEST.json'))
  self.assertEqual(list(config.cells()),all30['cells'][6:12]);self.assertEqual(len(config.cells()),6)
  for year in (True,2021,2022,2023,2025,2026):
   with self.subTest(year=year),self.assertRaises(ValueError):config.source_year(year)
  self.assertEqual(config.source_year(2024)['days'],366)
 def test_all27_immutable_saved_arrays_per_cell_without_regeneration(self):
  import follow_admission as a
  p=entry.validate_preparation_metadata(self.prep);self.assertEqual(set(p['years']),{'2024'});self.assertEqual(len(entry.array_specs(2024)),27)
  self.assertEqual(p['ordered_cells'],[x['cell_id'] for x in config.cells()]);self.assertTrue(all(n.startswith('2024/') or n.startswith('SOURCE_') for n in p['artifacts']))
  arrays={name:np.frombuffer(np.zeros(shape,dtype=dtype).tobytes(),dtype=dtype).reshape(shape) for name,(shape,dtype) in entry.array_specs(2024).items()}
  for cell in config.cells():self.assertIs(a.select_saved_target(arrays,cell_id=cell['cell_id'],year=2024),arrays[cell['recipe']+'_'+cell['tier']])
  for cell in ('2023_STATIC50_FOLLOW_POOL_SAMEGROSS_LOW_D_INTRINSIC_LOWER_ONLY_V1','2025_STATIC50_FOLLOW_POOL_SAMEGROSS_LOW_D_INTRINSIC_LOWER_ONLY_V1'):
   with self.assertRaises(ValueError):a.select_saved_target(arrays,cell_id=cell,year=2024)
 def test_generated_authority_exact_scope_storage_and_resource_bindings(self):
  go=self.check(*self.bundle());self.assertEqual(go['years'],(2024,));self.assertFalse(go['remaining18_authorized']);self.assertFalse(go['all24_authorized']);self.assertFalse(go['first6_recovery_authorized'])
  self.assertEqual(go['cohort_disk_safety']['minimum_free_bytes'],1610612736);self.assertEqual(go['cohort_disk_safety']['reserved_publication_bytes'],0);self.assertEqual(go['cohort_disk_safety']['maximum_cohort_output_log_temporary_bytes'],600000000)
  self.assertEqual(go['storage_policy_SHA256'],gate.storage_policy_sha());self.assertFalse(go['continuous_risk_ceiling_claim']);self.assertFalse(go['post_tier_samegross_guaranteed']);self.assertFalse(go['risk_matched_claim'])
  with self.assertRaises(TypeError):go['remaining18_authorized']=True
 def test_every_missing_extra_and_changed_go_field_rejected(self):
  go,rr,nr=self.bundle();v=c.exact_object(go)
  for key in v:
   bad=deepcopy(v);bad.pop(key)
   with self.subTest(missing=key),self.assertRaises((ValueError,TypeError,KeyError)):self.check(c.canonical(bad),rr,nr)
  for key in ('remaining18_authorized','all24_authorized','automatic_retry_authorized','saved_targets_rebuilt_during_finance','target_byte_equivalence_execution_reuse_authorized','first6_recovery_authorized','continuous_risk_ceiling_claim'):
   with self.subTest(changed=key),self.assertRaises(ValueError):self.check(c.canonical(dict(v,**{key:True})),rr,nr)
  with self.assertRaises(ValueError):self.check(c.canonical(dict(v,extra=True)),rr,nr)
 def test_old_first6_go_and_2024_wrong_gate_rejected(self):
  go,rr,nr=self.bundle();old=c.ordinary(c.ROOT/'original_follow_pair_first6_D_native_20261016_v2/ROOT_FIRST6_RECOVERY_APPROVED_20261016_0308.json')
  with self.assertRaises(ValueError):self.check(old,rr,nr)
  for cpus in ([4],[5,4],[4,6],[True,5]):
   with self.assertRaises(ValueError):gate.policy(self.prep,'1'*64,'2'*64,'3'*64,cpus)
  with self.assertRaises(ValueError):self.check(go,c.canonical(dict(c.exact_object(rr),extra=True)),nr)
  with self.assertRaises(ValueError):self.check(go,rr,c.canonical(dict(c.exact_object(nr),financial_execution_authorized=True)))
 def test_sealed_types_cannot_be_publicly_minted(self):
  import follow_admission as a,follow_native_source_scope as s,follow_verified_wires as w,follow_input_loader as l
  with self.assertRaises((ValueError,TypeError)):a.FreshHistoricalExecutionScope(*([None]*14))
  with self.assertRaises(ValueError):s.SourcePreparationScope(2024,None,None,object())
  with self.assertRaises(ValueError):w.consume(object(),year=2024,preparation_raw=b'{}',supplied={})
  self.assertFalse(a._LIVE);self.assertFalse(s._LIVE);self.assertFalse(w._LIVE);self.assertFalse(l._LIVE)
 def test_frozen_cp437_preload_and_minute_writer_retained(self):
  import inspect,run_follow
  self.assertIn('import encodings.cp437',inspect.getsource(run_follow.load_saved_year))
  import follow_transport as t,ast
  case=next(n for n in t.admitted_tree('run_follow').body if isinstance(n,ast.FunctionDef) and n.name=='case')
  calls=[n for n in ast.walk(case) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='savez_compressed']
  self.assertEqual(len(calls),1);self.assertIn('MINUTE.npz',ast.unparse(calls[0]))
 def test_no_current_2024_claim_namespace_or_recovery_facility(self):
  self.assertFalse((c.HERE/'EXECUTION_CLAIMS').exists());self.assertFalse((c.HERE/'follow_recovery.py').exists())
  self.assertIn(c.HERE.name,gate.CLAIM_NAMESPACE);self.assertNotIn('first6',gate.CLAIM_NAMESPACE)

if __name__=='__main__':unittest.main(verbosity=2)
