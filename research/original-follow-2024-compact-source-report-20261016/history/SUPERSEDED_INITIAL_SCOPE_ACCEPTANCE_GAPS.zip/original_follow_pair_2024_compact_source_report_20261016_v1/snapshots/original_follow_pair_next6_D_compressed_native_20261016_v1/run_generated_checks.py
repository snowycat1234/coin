"""Generated-only runtime/source/storage suite; actual bodies denied."""
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','POLARS_MAX_THREADS','VECLIB_MAXIMUM_THREADS'):os.environ[key]='1'
import argparse,builtins,io,json,sys,time,unittest,resource
from pathlib import Path
from contextlib import ExitStack
from unittest.mock import patch
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
p=argparse.ArgumentParser();p.add_argument('--cpu',type=int,default=7);p.add_argument('--receipt',required=True);args=p.parse_args()
if args.cpu not in (6,7,8):raise ValueError('GENERATED_CPU6_7_8_ONLY')
os.sched_setaffinity(0,{args.cpu});os.environ['FOLLOW_GENERATED_TEST_CPU']=str(args.cpu)
counts=dict(actual_source_or_target_body_reads=0,actual_financial_body_reads=0)
def check(path):
 if isinstance(path,int) or not isinstance(path,(str,bytes,os.PathLike)):return
 path=Path(os.path.abspath(os.fsdecode(path)))
 if ROOT not in path.parents:return
 own=HERE in path.parents or (os.environ.get('FOLLOW_GENERATED_FIXTURE_ROOT') and Path(os.environ['FOLLOW_GENERATED_FIXTURE_ROOT']) in path.parents)
 if path.suffix in ('.npz','.npy','.zip','.csv','.gz') and not own:
  counts['actual_source_or_target_body_reads']+=1;raise RuntimeError('ACTUAL_BODY_READ_DENIED:'+str(path))
 if 'financial_attempts' in path.parts or 'ACTUAL_FINANCIAL' in str(path):
  counts['actual_financial_body_reads']+=1;raise RuntimeError('ACTUAL_FINANCIAL_BODY_READ_DENIED:'+str(path))
start=time.monotonic()
with ExitStack() as stack:
 for module in (builtins,io):
  original=module.open
  def opened(file,mode='r',*a,_open=original,**kw):
   if 'r' in mode or '+' in mode:check(file)
   return _open(file,mode,*a,**kw)
  stack.enter_context(patch.object(module,'open',opened))
 original=os.open
 def os_open(path,flags,*a,**kw):
  checked=path
  if isinstance(path,(str,bytes,os.PathLike)) and not os.path.isabs(path) and kw.get('dir_fd') is not None:checked=Path(os.readlink('/proc/self/fd/'+str(kw['dir_fd'])))/os.fsdecode(path)
  if not flags&os.O_WRONLY:check(checked)
  return original(path,flags,*a,**kw)
 stack.enter_context(patch.object(os,'open',os_open))
 suite=unittest.defaultTestLoader.loadTestsFromNames(['test_follow_native','test_follow_terminal_partial','test_follow_process_runtime','test_follow_disk_admission','test_next6_storage','test_next6_authority','test_next6_source2024','test_next6_cold_read','test_next6_saved_validator'])
 result=unittest.TextTestRunner(verbosity=2).run(suite)
receipt=dict(schema='FOLLOW_NEXT6_2024_COMPRESSED_AUTHOR_GENERATED_CHECKS_V1',status='PASS' if result.wasSuccessful() else 'FAIL',tests_run=result.testsRun,failures=len(result.failures),errors=len(result.errors),optimized=bool(sys.flags.optimize),CPU_affinity=sorted(os.sched_getaffinity(0)),elapsed_seconds=time.monotonic()-start,max_RSS_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,observed_forbidden_attempts=counts,actual_financial_runs=0,actual_source_recaptures=0,actual_CPU45_workers=0,actual_canonical_claims_created=0,root_financial_GO_created=False,scope='CODE_AND_GENERATED_ONLY_REQUIRES_FRESH_INDEPENDENT_ADMISSION_REVIEW')
Path(args.receipt).write_text(json.dumps(receipt,sort_keys=True,separators=(',',':'))+'\n');print(json.dumps(receipt,sort_keys=True));sys.exit(0 if result.wasSuccessful() else 1)
