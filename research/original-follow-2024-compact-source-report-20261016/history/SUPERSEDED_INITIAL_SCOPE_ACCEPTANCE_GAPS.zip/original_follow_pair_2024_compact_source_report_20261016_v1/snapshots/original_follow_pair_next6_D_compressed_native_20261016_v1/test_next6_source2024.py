"""Invented-only regressions for the real qualified 2024 source decoder."""
from copy import deepcopy
from pathlib import Path
import tempfile,unittest
import numpy as np
import follow_native_common as c
import follow_native_config as config
import follow_native_codec as codec
from follow_native_source2024 import assemble_inputs
from generated_next6_cold_read_regression import parent_fixture,_pack,generated_fixture_root
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent

class Qualified2024SourceTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.temp=tempfile.TemporaryDirectory(prefix='GENERATED_NEXT6_SOURCE2024_',dir=generated_fixture_root())
  cls.directory=Path(cls.temp.name)/'generated';cls.fixture=parent_fixture(cls.directory)
 @classmethod
 def tearDownClass(cls):cls.temp.cleanup()
 def parts(self):
  contract=deepcopy(self.fixture['contract'])
  def read(name):return (ROOT/name).read_bytes()
  return [2024,read(contract['warmup_path']),read(contract['daily_path']),read(contract['events_path']),read(contract['quality_sidecar_path']),tuple((rec['path'],read(rec['path'])) for rec in contract['months']),contract]
 def test_qualified_leap_year_565_close_union_and_ten_derived_marks(self):
  source=assemble_inputs(*self.parts());period=config.source_year(2024)
  self.assertEqual(source['close'].shape,(565,5));self.assertEqual(len(source['decisions']),366)
  self.assertEqual(int(source['clocks'][-1]),period['end']-config.DAY)
  self.assertEqual(source['sidecar']['derived_mark_cells'],10)
  self.assertEqual(c.plain(source['quality_intervals']),[[1723456980000000,1723457100000000,list(config.SYMBOLS)]])
  self.assertFalse(source['sidecar']['certifies_liquidation']);self.assertFalse(source['sidecar']['certifies_no_liquidation'])
  self.assertEqual(source['sidecar']['arrival_status'],'UNKNOWN_NOT_CERTIFIED')
  self.assertEqual(self.fixture['prefix_rows'],1826);self.assertTrue(self.fixture['full_original_prefix_retained'])
 def test_extra_source_end_close_is_excluded_before_numeric_use(self):
  parts=self.parts();rows,_,_=codec.STORED_DAILY[2024]
  arrays=codec.npz(parts[1],dict(close_available_us=((rows,),'int64'),close=((rows,5),'float64')))
  changed=arrays['close'].copy();changed[-1]=np.nan
  a=codec.daily_inputs(2024,parts[1],parts[2]);b=codec.daily_inputs(2024,_pack(close_available_us=arrays['close_available_us'],close=changed),parts[2])
  for actual,expected in zip(b,a,strict=True):self.assertEqual(actual.tobytes(),expected.tobytes())
 def test_only_declared_two_marks_per_asset_are_projected_with_derived_flags(self):
  parts=self.parts();rec=next(row for row in parts[6]['months'] if row['start']<=1723456920000000<row['start']+row['count']*codec.MINUTE)
  raw=dict(parts[5])[rec['path']];specs={'times':((rec['count'],),'int64')}
  specs.update({symbol+'_'+field:((rec['count'],),'float64') for symbol in config.SYMBOLS for field in codec.FIELDS})
  original=codec.npz(raw,specs);projected,evidence=codec.mark2024().project_month(original)
  self.assertEqual(len(evidence),10);indices=np.searchsorted(original['times'],[1723456920000000,1723456980000000]);prior=int(np.searchsorted(original['times'],1723456860000000))
  for symbol in config.SYMBOLS:
   self.assertEqual(np.flatnonzero(projected[symbol+'_mark']!=original[symbol+'_mark']).tolist(),indices.tolist())
   for i in indices:self.assertEqual(projected[symbol+'_mark'][i].tobytes(),original[symbol+'_mark'][prior].tobytes())
   for field in ('open','close','quote_volume'):self.assertEqual(projected[symbol+'_'+field].tobytes(),original[symbol+'_'+field].tobytes())
  for row in evidence:
   self.assertTrue(row['source_missing']);self.assertTrue(row['derived']);self.assertTrue(row['stale']);self.assertFalse(row['is_actual_current_venue_mark'])
   self.assertEqual(row['last_genuine_source_available_us'],1723456920000000)
 def test_interpolated_missing_values_cannot_change_causal_projection(self):
  parts=self.parts();before=assemble_inputs(*parts);months=list(parts[5]);contract=parts[6]
  i=next(i for i,row in enumerate(contract['months']) if row['start']<=1723456920000000<row['start']+row['count']*codec.MINUTE);rec=contract['months'][i]
  raw=months[i][1];specs={'times':((rec['count'],),'int64')};specs.update({symbol+'_'+field:((rec['count'],),'float64') for symbol in config.SYMBOLS for field in codec.FIELDS})
  arrays={key:value.copy() for key,value in codec.npz(raw,specs).items()};indices=np.searchsorted(arrays['times'],[1723456920000000,1723456980000000])
  for symbol in config.SYMBOLS:arrays[symbol+'_mark'][indices]=[900000.,800000.]
  changed=_pack(**arrays);months[i]=(rec['path'],changed);rec['hash']=c.sha(changed);rec['size']=len(changed);parts[5]=tuple(months)
  after=assemble_inputs(*parts)
  self.assertEqual(after['sidecar_raw'],before['sidecar_raw']);self.assertEqual(after['close'].tobytes(),before['close'].tobytes())
 def test_projected_august_hash_is_enforced_by_real_assembler(self):
  parts=self.parts();sidecar=c.exact_object(parts[4]);sidecar['causal_estimate_mark_array_SHA256'][config.SYMBOLS[0]]='0'*64;parts[4]=c.canonical(sidecar)
  with self.assertRaisesRegex(ValueError,'EXACT_2024_PINNED_CAUSAL_MARK_ARRAY_BITS_REQUIRED'):assemble_inputs(*parts)
if __name__=='__main__':unittest.main(verbosity=2)
