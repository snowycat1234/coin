"""Sealed next6 target loader and separately authorized canonical native capture."""
from dataclasses import dataclass,field
from types import MappingProxyType
from pathlib import Path
import numpy as np
import follow_native_common as c
import follow_native_config as config
import follow_source_entry as entry
import follow_native_codec as codec
import follow_native_signal as signal
import follow_verified_wires as verified
_SEAL=object();_LIVE={}

@dataclass(frozen=True,slots=True)
class LoadedInputs:
 year:int
 preparation_raw:bytes=field(repr=False)
 source:object=field(repr=False)
 arrays:object=field(repr=False)
 captured_artifacts:object=field(repr=False)
 financial_GO_SHA256:str
 verified_cell_id:str
 _token:object=field(repr=False)
 _seal:object=field(repr=False)
 def __post_init__(self):
  if self._seal is not _SEAL:raise ValueError('ENTRY_OWNED_FOLLOW_NATIVE_LOADED_INPUTS_REQUIRED')
 def validate(self):
  if _LIVE.get(self._token) is not self or self._seal is not _SEAL:raise ValueError('LIVE_NEXT6_LOADED_INPUTS_REQUIRED')
  p=entry.validate_preparation_metadata(self.preparation_raw);info=p['years']['2024'];config.cell_named(self.verified_cell_id)
  if type(self.year) is not int or self.year!=2024 or set(self.arrays)!=set(entry.array_specs(2024)):raise ValueError('EXACT_NEXT6_2024_SAVED_INPUTS_REQUIRED')
  for name,a in self.arrays.items():
   if a.flags.writeable or c.canonical(signal.array_byte_identity(a))!=c.canonical(info['array_identities'][name]):raise ValueError('EXACT_IMMUTABLE_SAVED_ARRAY_IDENTITY_REQUIRED')
  for name,raw in self.captured_artifacts.items():
   pin=p['artifacts'][name]
   if len(raw)!=pin['bytes'] or c.sha(raw)!=pin['SHA256']:raise ValueError('EXACT_SAVED_ARTIFACT_BITS_REQUIRED')
  if set(self.captured_artifacts)!=set(p['artifacts']):raise ValueError('EXACT_NEXT6_ARTIFACT_NAMESPACE_REQUIRED')
  for key,actual in [('source_rows_SHA256',c.jsha(self.source['source_rows'])),('funding_events_SHA256',c.jsha(self.source['events'])),('source_quality_sidecar_SHA256',c.sha(self.source['sidecar_raw']))]:
   if info[key]!=actual:raise ValueError('EXACT_CANONICAL_NATIVE_ROWS_FUNDING_QUALITY_REQUIRED:'+key)
  if self.source['source_identity']!=info['source_identity']:raise ValueError('EXACT_CANONICAL_NATIVE_IDENTITY_REQUIRED')
  for rec,(name,raw) in zip(self.source['contract']['months'],self.source['months'],strict=True):
   if name!=rec['path'] or len(raw)!=rec['size'] or c.sha(raw)!=rec['hash']:raise ValueError('EXACT_CAPTURED_NATIVE_MONTH_BITS_REQUIRED')
  return True

def load_year(preparation_root,*,expected_preparation_sha256,year,source_go_raw,expected_source_go_sha256,source_review_raw,expected_source_review_sha256,
 financial_go_raw,expected_financial_go_sha256,financial_review_raw,expected_financial_review_sha256,prepared_review_raw,expected_prepared_review_sha256,native_review_raw,expected_native_review_sha256,verified_binding=None):
 from follow_native_source_guard import current_guard
 guard=current_guard()
 if guard is None or not guard.active:raise ValueError('SOURCE_GUARD_BEFORE_FINANCE_IMPORT_REQUIRED')
 config.source_year(year)
 raw=c.exact(Path(preparation_root)/'PREPARATION.json',expected_preparation_sha256);p=entry.validate_preparation_metadata(raw)
 entry.validate_source_authority_metadata(source_go_raw,expected_source_go_sha256,source_review_raw,expected_source_review_sha256)
 wires={'go':financial_go_raw,'review':financial_review_raw,'prepared-review':prepared_review_raw,'native-review':native_review_raw,'source-go':source_go_raw,'source-review':source_review_raw}
 expected={'go':expected_financial_go_sha256,'review':expected_financial_review_sha256,'prepared-review':expected_prepared_review_sha256,'native-review':expected_native_review_sha256,'source-go':expected_source_go_sha256,'source-review':expected_source_review_sha256}
 go_sha=verified.consume(verified_binding,preparation_raw=raw,year=year,supplied=wires)
 if go_sha!=expected_financial_go_sha256 or dict(verified_binding.hashes)!=expected:raise ValueError('EXACT_EXTERNALLY_VERIFIED_FINANCIAL_WIRES_REQUIRED')
 artifacts={name:c.exact(Path(preparation_root)/c.relative(name),pin['SHA256'],pin['bytes']) for name,pin in p['artifacts'].items()}
 arrays=codec.npz(artifacts['2024/TARGETS.npz'],entry.array_specs(year))
 # All27 saved float/int target, covariance and gross arrays remain exact. No
 # signal, tier sizing or covariance regeneration is called during finance.
 info=p['years']['2024']
 for name,a in arrays.items():
  if c.canonical(signal.array_byte_identity(a))!=c.canonical(info['array_identities'][name]):raise ValueError('EXACT_SAVED_TARGET_COVARIANCE_GROSS_BITS_REQUIRED')
 from follow_native_source_scope import admit_capture
 import follow_native_source
 with admit_capture(verified_binding,year=year) as scope:captured=follow_native_source.capture_year(year,scope)
 import follow_entry as original_entry
 prefix_pin=original_entry.source_maps()[0]['years']['2024']['prefix_metadata'];n=prefix_pin['selected_rows']
 prefix=codec.npz(artifacts['2024/SOURCE_PREFIX_INPUTS.npz'],dict(close_available_us=((n,),'int64'),close=((n,5),'float64')))
 ids=np.searchsorted(prefix['close_available_us'],captured['clocks'])
 if (np.any(ids>=n) or prefix['close_available_us'][ids].tobytes()!=captured['clocks'].tobytes() or prefix['close'][ids].tobytes()!=captured['close'].tobytes()
     or arrays['decision_us'].tobytes()!=captured['decisions'].tobytes()):raise ValueError('EXACT_CANONICAL199_AND366_TAIL_PARITY_WITH_SAVED_FULL_ORIGINAL_PREFIX_REQUIRED')
 token=object();value=LoadedInputs(year,raw,c.immutable(captured),MappingProxyType(arrays),MappingProxyType(artifacts),go_sha,verified_binding.cell_id,token,_SEAL);_LIVE[token]=value
 try:value.validate();return value
 except BaseException:_LIVE.pop(token,None);raise

def revoke(value):
 if type(value) is not LoadedInputs or _LIVE.get(value._token) is not value:raise ValueError('LIVE_NEXT6_LOADED_INPUTS_REQUIRED')
 _LIVE.pop(value._token)
