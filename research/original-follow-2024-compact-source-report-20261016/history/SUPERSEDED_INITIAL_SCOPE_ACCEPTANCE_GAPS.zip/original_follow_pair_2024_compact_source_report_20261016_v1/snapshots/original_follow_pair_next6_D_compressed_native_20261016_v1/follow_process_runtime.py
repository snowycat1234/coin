"""FOLLOW next6 finite process safety and frozen native terminal taxonomy.

Transported from frozen HIGH365 process safety. Only scope, launcher, gate, and
cohort-cap substitutions; no launch, source capture, or financial import on import.
"""
from __future__ import annotations
import argparse
import fcntl
from contextlib import contextmanager
from datetime import datetime, timezone
from hashlib import sha256
from io import BytesIO
import json
import os
from pathlib import Path
import resource
import signal
import stat
import subprocess
import sys
import time
import traceback

HERE = Path(__file__).resolve().parent
ROOT=HERE.parent
CHECKER_ROOT=ROOT/'bounded_native_continuation_guard50_exit_expansion_20261015'
if str(CHECKER_ROOT) not in sys.path:sys.path.insert(0,str(CHECKER_ROOT))
if str(HERE) not in sys.path:sys.path.insert(0,str(HERE))
MANIFEST_SHA256 = 'eb9b65b02893dc31bcff15818da994677b6f05e820ce0c942a6885fd7d9ef33f'
LIMITS = dict(maximum_live_workers=2, threads_per_worker=1, per_case_wall_seconds=600,
    per_case_CPU_seconds=600, per_case_RSS_stop_bytes=2_000_000_000,
    per_case_AS_bytes=4_000_000_000, per_case_output_bytes=250_000_000,
    aggregate_live_worker_RSS_stop_bytes=3_500_000_000)
_CONTROLLER_LEASE_FD = None
_SHARED_RESOURCE_LEASE_FD = None
COHORT_DISK_POLICY = dict(minimum_free_bytes=1_610_612_736,
    base_free_floor_bytes=1_610_612_736,reserved_publication_bytes=0,
    maximum_cohort_output_log_temporary_bytes=600_000_000,
    initial_full_cohort_cap_admission_required=True,
    external_disk_writers_guaranteed=False, filesystem_quota_guaranteed=False,
    check_cadence='BEFORE_EACH_LAUNCH_AND_EXISTING_0.1_SECOND_POLL')
THREAD_ENV = ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS',
              'NUMEXPR_NUM_THREADS', 'POLARS_MAX_THREADS', 'VECLIB_MAXIMUM_THREADS')
TERMINAL_FILES = ('CASE_RECEIPT.json', 'ACCOUNT_FINANCIAL_AUDIT.json', 'NATIVE_RESULT.json',
    'LEGACY_PRIMARY_FINANCIAL_RECONCILIATION.json', 'PRIMARY_FINANCIAL_RECONCILIATION.json',
    'NATIVE40_RECONSTRUCTION_PROOF.json', 'ACTUAL_HELD_RISK_REPORT.json', 'MINUTE.npz',
    'GUARD_RECEIPTS.json', 'CAUSAL_MARK_QUALITY.json', 'ADMISSION_GO.json', 'ADMISSION_REVIEW.json',
    'LAUNCH_CLAIM.json', 'PROCESS_OWNERSHIP.json', 'BOOTSTRAP_READY.json')



def utc():return datetime.now(timezone.utc).isoformat()


def sha(raw):return sha256(raw).hexdigest()


def body(value):return (json.dumps(value, indent=2, sort_keys=True, allow_nan=False)+'\n').encode()


def write_bytes(path, raw):
    # Publish only fully written/fsynced immutable bytes, without replacing an
    # existing artifact. Hard-link publication is atomic on this filesystem.
    path=Path(path);temporary=path.with_name('.'+path.name+'.'+str(os.getpid())+'.'+str(time.time_ns())+'.tmp')
    try:
        with temporary.open('xb') as stream:
            stream.write(raw);stream.flush();os.fsync(stream.fileno())
        os.link(temporary,path)
        fd=os.open(path.parent,os.O_RDONLY)
        try:os.fsync(fd)
        finally:os.close(fd)
    finally:
        if temporary.exists():temporary.unlink()


def save(path, value):
    path=Path(path)
    if path.name in BIG3:
        return save_big_json(path,value)
    if path.name=='TERMINAL_CHECKPOINT.json':
        return save_terminal_checkpoint(path,value)
    write_bytes(path,body(value))


def own_bytes(path):
    total=0;seen=set()
    for item in Path(path).rglob('*'):
        try:info=item.stat()
        except (FileNotFoundError,ProcessLookupError):continue
        identity=(info.st_dev,info.st_ino)
        if stat.S_ISREG(info.st_mode) and identity not in seen:
            total+=info.st_size;seen.add(identity)
    return total


def environment():
    return dict(os.environ, PYTHONDONTWRITEBYTECODE='1', **{key:'1' for key in THREAD_ENV})


def apply_limits(cpu):
    if type(cpu) is not int or cpu not in os.sched_getaffinity(0):
        raise ValueError('REQUESTED_WORKER_CPU_MUST_BE_ACTUALLY_ALLOWED')
    os.sched_setaffinity(0, {cpu})
    for key, value in ((resource.RLIMIT_AS, LIMITS['per_case_AS_bytes']),
            (resource.RLIMIT_CPU, LIMITS['per_case_CPU_seconds']),
            (resource.RLIMIT_RSS, LIMITS['per_case_RSS_stop_bytes'])):
        resource.setrlimit(key, (value, value))
    for key in THREAD_ENV:os.environ[key] = '1'


def process_observation(pid):
    try:
        raw = Path(f'/proc/{pid}/status').read_text()
        fields = dict(line.split(':', 1) for line in raw.splitlines() if ':' in line)
        tasks = []
        for task in Path(f'/proc/{pid}/task').iterdir():
            try:tasks.append(dict(TID=int(task.name), name=(task/'comm').read_text().strip(), CPU_affinity=sorted(os.sched_getaffinity(int(task.name)))))
            except (FileNotFoundError, ProcessLookupError):pass
        return dict(tasks=tasks, PID=pid, RSS_bytes=int(fields.get('VmRSS', '0 kB').split()[0])*1024,
            threads=int(fields['Threads']), CPU_affinity=sorted(os.sched_getaffinity(pid)),
            process_start_ticks=Path(f'/proc/{pid}/stat').read_text().split(') ',1)[1].split()[19])
    except (FileNotFoundError, ProcessLookupError):return None


def host_observation():
    mem = dict(line.split(':',1) for line in Path('/proc/meminfo').read_text().splitlines())
    quota = {}
    for name in ('/sys/fs/cgroup/cpu.max', '/sys/fs/cgroup/memory.max', '/sys/fs/cgroup/memory.current'):
        try:quota[name] = Path(name).read_text().strip()
        except (FileNotFoundError, PermissionError):quota[name] = 'UNAVAILABLE'
    return dict(UTC=utc(), allowed_CPUs=sorted(os.sched_getaffinity(0)),
        MemAvailable_bytes=int(mem['MemAvailable'].split()[0])*1024, cgroup_observations=quota,
        quota_visibility='UNVERIFIED_HOST_OBSERVATIONS_ONLY', host_quota_guaranteed=False)


def choose_worker_count(requested, cpus, observation):
    if type(requested) is not int or requested not in (1,2) or type(cpus) is not list or len(cpus) != requested:
        raise ValueError('EXACT_ONE_OR_TWO_WORKERS_REQUIRED')
    if any(type(cpu) is not int or cpu not in observation['allowed_CPUs'] for cpu in cpus) or len(set(cpus)) != len(cpus):
        raise ValueError('DISTINCT_ACTUALLY_ALLOWED_WORKER_CPUS_REQUIRED')
    # Conservative headroom, reobserved before every new launch. Host readings
    # are observations, never evidence of an enforceable host resource quota.
    available = observation['MemAvailable_bytes']
    quota = observation.get('cgroup_observations', {})
    maximum, current = quota.get('/sys/fs/cgroup/memory.max'), quota.get('/sys/fs/cgroup/memory.current')
    if str(maximum).isdigit() and str(current).isdigit():available = min(available, int(maximum)-int(current))
    if available < 2_300_000_000:raise RuntimeError('INSUFFICIENT_OBSERVED_MEMORY_PAUSE_BEFORE_LAUNCH')
    count = requested if available >= 4_500_000_000 else 1
    cpu_max = quota.get('/sys/fs/cgroup/cpu.max', '').split()
    if len(cpu_max) == 2 and cpu_max[0].isdigit() and int(cpu_max[0]) < 2*int(cpu_max[1]):count = 1
    return min(requested, count)


def classify_terminal(audit, result, *, calendar, completed_minutes, stop_us):
    from decimal import Decimal as D, localcontext
    from saved_native_reconciliation import HALTS
    summary, economics = result['summary'], result['economics']
    full = completed_minutes == (calendar[1]-calendar[0])//60_000_000 and stop_us is None
    flat = all(D(p['quantity']) == 0 for p in audit['positions'].values())
    healthy = audit['status'] not in HALTS and D(audit['unpaid_liability']) == 0
    paid = bool(full and flat and healthy and not audit['settlement_journal'])
    conditional = bool(full and flat and healthy and audit['settlement_journal'])
    if not full:
        witness = audit.get('halt_witness')
        if (audit['status'] not in HALTS or not isinstance(witness,dict) or not witness
                or type(stop_us) is not int or witness.get('event_us') != stop_us or audit['clock_us'] != stop_us
                or not calendar[0] <= stop_us <= calendar[1]
                or completed_minutes != (stop_us-calendar[0]-1)//60_000_000):
            raise ValueError('INCOMPLETE_EXECUTION_IS_NOT_ECONOMIC_HALT_PAUSE_QUEUE')
        def wd(key):return D(str(witness.get('decimal_strings',{}).get(key,witness.get(key))))
        nav, debt = D(summary['decimal_strings']['NAV']), D(audit['unpaid_liability'])
        if wd('NAV') != nav or wd('unpaid_liability') != debt or debt < 0:
            raise ValueError('EXACT_NATIVE_HALT_NAV_DEBT_REQUIRED')
        with localcontext() as ctx:
            ctx.prec = 40
            if 'symbol' in witness:
                s = witness['symbol'];p = audit['positions'][s];q = D(p['quantity']);mark = D(audit['marks'][s][-1]['price'])
                equity = D(p['isolated_balance'])+q*(mark-D(p['entry_price']));mm=abs(q)*mark*D('.005')
                if (q == 0 or mark <= 0 or wd('quantity') != q or wd('mark_price') != mark
                        or wd('isolated_equity') != equity or wd('maintenance_margin') != mm
                        or audit['status'] == 'LIQUIDATION_REQUIRED_HALT' and not (0 < equity <= mm and nav > 0 and debt == 0)
                        or audit['status'] == 'BANKRUPT_HALT' and not (equity <= 0 or nav <= 0 or debt > 0)):
                    raise ValueError('EXACT_NATIVE_HALT_PREDICATE_REQUIRED')
            elif audit['status'] != 'BANKRUPT_HALT' or not (nav <= 0 or debt > 0):
                raise ValueError('EXACT_NATIVE_GLOBAL_BANKRUPTCY_PREDICATE_REQUIRED')
    classification = ('FULL_CALENDAR_ACTUAL_PAID_MARKET_FLAT' if paid else
        'FULL_CALENDAR_CONDITIONAL_SETTLED_FLAT' if conditional else
        'FULL_CALENDAR_RESIDUAL_OR_UNSETTLED_UNPAID' if full else 'NATIVE_HALT_PARTIAL_CALENDAR')
    expected_return = float(D(summary['decimal_strings']['NAV'])/D(10000)-1) if paid or conditional else None
    for key,value in dict(full_calendar=full, paid_flat=paid, actual_paid_market_flat=paid, conditional_settled_flat=conditional).items():
        if type(economics.get(key)) is not bool or economics[key] != value:raise ValueError('HONEST_SAVED_TERMINAL_TAXONOMY_REQUIRED')
    if (economics['comparable_full_calendar_return'] != expected_return
            or economics['paid_net_return'] != (expected_return if paid else None)
            or economics['conditional_model_net_return'] != (expected_return if conditional else None)
            or summary['completed_minutes'] != completed_minutes or summary['stop_us'] != stop_us):
        raise ValueError('HONEST_SAVED_TERMINAL_RETURN_CALENDAR_REQUIRED')
    if full and not (paid or conditional):raise ValueError('UNSETTLED_OR_RESIDUAL_CASE_PAUSES_FINITE_QUEUE')
    return classification


def confine_existing_threads(cpus):
    cpus=set(cpus)
    for task in Path('/proc/self/task').iterdir():
        try:os.sched_setaffinity(int(task.name),cpus)
        except ProcessLookupError:pass


@contextmanager
def cpu_envelope(cpus):
    allowed=set(os.sched_getaffinity(0))
    if any(type(cpu) is not int or cpu not in allowed for cpu in cpus):raise ValueError('ACTUALLY_ALLOWED_COORDINATOR_CPUS_REQUIRED')
    old={int(t.name):set(os.sched_getaffinity(int(t.name))) for t in Path('/proc/self/task').iterdir()}
    confine_existing_threads(cpus)
    try:yield
    finally:
        for task in Path('/proc/self/task').iterdir():
            try:os.sched_setaffinity(int(task.name),old.get(int(task.name),allowed))
            except ProcessLookupError:pass


class CohortDiskResourceStop(RuntimeError):
    failure_classification = 'RESOURCE'
    economic_halt = False
    def __init__(self, reason, observation):
        self.disk_observation = observation
        super().__init__('RESOURCE_COHORT_DISK_' + reason)


def cohort_disk_observation(output):
    output=Path(output)
    space=os.statvfs(output)
    return dict(free_bytes=space.f_bavail*space.f_frsize,
        cohort_output_log_temporary_bytes=own_bytes(output),
        **COHORT_DISK_POLICY)


def check_full_cohort_budget(output):
    """Reserve the full remaining cap plus base floor/publication headroom.

    Read-only, works before an output directory exists. A deficient admission
    cannot create output, claims, leases or workers through the controller.
    """
    output=Path(output);ancestor=output
    while not ancestor.exists():ancestor=ancestor.parent
    if output.exists() and not output.is_dir():raise ValueError('ORDINARY_COHORT_DIRECTORY_REQUIRED')
    space=os.statvfs(ancestor);free=space.f_bavail*space.f_frsize
    used=own_bytes(output) if output.exists() else 0
    remaining=max(0,COHORT_DISK_POLICY['maximum_cohort_output_log_temporary_bytes']-used)
    observation=dict(schema='FOLLOW_NEXT6_FULL_REMAINING_COHORT_BUDGET_OBSERVATION_V2',
        output=str(output.absolute()),statvfs_observed_path=str(ancestor.absolute()),
        free_bytes=free,cohort_output_log_temporary_bytes=used,
        remaining_full_cohort_cap_bytes=remaining,retained_free_after_full_cap_bytes=free-remaining,
        required_fresh_free_bytes=COHORT_DISK_POLICY['minimum_free_bytes']+remaining,
        observed_UTC=utc(),**COHORT_DISK_POLICY)
    if used>COHORT_DISK_POLICY['maximum_cohort_output_log_temporary_bytes']:
        raise CohortDiskResourceStop('OUTPUT_LOG_TEMPORARY_CAP',observation)
    if free-remaining<COHORT_DISK_POLICY['minimum_free_bytes']:
        raise CohortDiskResourceStop('FULL_COHORT_CAPACITY',observation)
    return observation


def check_cohort_disk(output, *, pending_write_bytes=0):
    if type(pending_write_bytes) is not int or pending_write_bytes < 0:
        raise ValueError('EXACT_NONNEGATIVE_PENDING_COHORT_WRITE_BYTES_REQUIRED')
    observation=cohort_disk_observation(output)
    observation=dict(observation,pending_atomic_write_bytes=pending_write_bytes,
        prospective_free_bytes=observation['free_bytes']-pending_write_bytes,
        prospective_cohort_bytes=observation['cohort_output_log_temporary_bytes']+pending_write_bytes)
    if observation['prospective_free_bytes'] < COHORT_DISK_POLICY['minimum_free_bytes']:
        raise CohortDiskResourceStop('FREE_SPACE_FLOOR',observation)
    if observation['prospective_cohort_bytes'] > COHORT_DISK_POLICY['maximum_cohort_output_log_temporary_bytes']:
        raise CohortDiskResourceStop('OUTPUT_LOG_TEMPORARY_CAP',observation)
    return observation


def save_cohort_controller(path, value):
    """Forecast exact body/temp bytes before the unchanged atomic writer."""
    path=Path(path);raw=body(value)
    check_cohort_disk(path.parent,pending_write_bytes=len(raw))
    write_bytes(path,raw)
    check_cohort_disk(path.parent)


def save_bounded_resource_stop(path, error):
    value=dict(status='RESOURCE_STOP_OWNED_WORKERS_ONLY_NO_RETRY',failure_classification='RESOURCE',
        error=str(error)[:2048],disk_resource_observation=getattr(error,'disk_observation',None),
        economic_halt_relabelled=False,automatic_retry=False,external_disk_writers_guaranteed=False,
        filesystem_quota_guaranteed=False,original_pause_preserved=getattr(error,'original_pause_preserved',False),
        saved_validation_errors=getattr(error,'saved_validation_errors',None),
        pending_not_launched=getattr(error,'pending_not_launched',None),UTC=utc())
    if len(body(value)) > 65536:
        value['saved_validation_errors']='PRESERVED_ON_RESOURCE_EXCEPTION_TOO_LARGE_FOR_BOUNDED_RECEIPT'
    if len(body(value)) > 65536:
        raise ValueError('BOUNDED_RESOURCE_STOP_RECEIPT_REQUIRED')
    try:save_cohort_controller(path,value)
    except (CohortDiskResourceStop,OSError):return False
    return True


def run_pool(jobs, output, *, requested_workers, cpus, validator, observation_callback=host_observation, before_launch=None):
    budget=check_full_cohort_budget(output)
    # Reviewed saved-only operational repair, preserving this runtime's limits,
    # distinct CPU assignments, immutable claims and both inherited leases.
    repair=ROOT/'cs_saved_minute_reporting_repair_20261015_v2'
    if str(repair) not in sys.path:sys.path.insert(0,str(repair))
    import bounded_drain
    if Path(bounded_drain.__file__).resolve()!=repair/'bounded_drain.py':raise ValueError('EXACT_OPERATIONAL_DRAIN_MODULE_REQUIRED')
    # Exceptions inside either hook use the unchanged drain's exception path:
    # stop only its active owned workers, without economic relabelling/retry.
    summary=dict(checks=0,minimum_observed_free_bytes=None,maximum_observed_cohort_bytes=0,
        policy=dict(COHORT_DISK_POLICY),initial_full_cap_admission=dict(budget))
    def disk_check():
        observation=check_cohort_disk(output);summary['checks']+=1
        old=summary['minimum_observed_free_bytes']
        summary['minimum_observed_free_bytes']=observation['free_bytes'] if old is None else min(old,observation['free_bytes'])
        summary['maximum_observed_cohort_bytes']=max(summary['maximum_observed_cohort_bytes'],observation['cohort_output_log_temporary_bytes'])
        return observation
    def observed():
        disk_check()
        return host_observation() if observation_callback is None else observation_callback()
    def before(cell,directory,cpu):
        disk_check()
        if before_launch is not None:before_launch(cell,directory,cpu)
        disk_check()
    report=bounded_drain.run_pool(jobs,output,runtime=sys.modules[__name__],requested_workers=requested_workers,cpus=cpus,
        validator=validator,observation_callback=observed,before_launch=before,
        bootstrap_launcher=HERE/'run_follow.py',
        inherited_lease_environment=({} if _SHARED_RESOURCE_LEASE_FD is None else {'LEGACY_SHARED_CPU45_LEASE_FD':_SHARED_RESOURCE_LEASE_FD}))
    disk_check();report['cohort_disk_safety']=summary
    return report


def claim_launch(registry_root, *, cell_id, manifest_sha256, metadata):
    """Permanent exclusive launch reservation, not a financial checkpoint.

    The historical caller has already validated external approval and inputs.
    Failed spawn and interrupted execution keep this claim permanently blocked.
    Tests pass only temporary registry roots; no claim is made on import.
    """
    if manifest_sha256 != MANIFEST_SHA256 or type(cell_id) is not str or not cell_id or Path(cell_id).name != cell_id:
        raise ValueError('EXACT_NEW_MANIFEST_CELL_CLAIM_REQUIRED')
    manifest_raw=(HERE/'FROZEN_SIX_CELL_MANIFEST.json').read_bytes()
    if sha(manifest_raw)!=MANIFEST_SHA256 or cell_id not in {c['cell_id'] for c in json.loads(manifest_raw)['cells']}:
        raise ValueError('EXACT_NEW_MANIFEST_CELL_CLAIM_REQUIRED')
    registry=Path(registry_root)/manifest_sha256;registry.mkdir(parents=True,exist_ok=True)
    path=registry/(cell_id+'.json')
    value=dict(schema='CANONICAL_IMMUTABLE_MANIFEST_CELL_LAUNCH_CLAIM_V1',manifest_SHA256=manifest_sha256,
        cell_id=cell_id,claim_UTC=utc(),controller_PID=os.getpid(),status='RESERVED_BEFORE_PROCESS_SPAWN',
        automatic_clear_or_retry=False,financial_snapshot_resume=False,**metadata)
    try:save(path,value)
    except FileExistsError:raise RuntimeError('PERMANENT_CANONICAL_CELL_CLAIM_EXISTS_NO_DUPLICATE_LAUNCH:'+cell_id)
    fd=os.open(registry,os.O_RDONLY)
    try:os.fsync(fd)
    finally:os.close(fd)
    return path


def shared_resource_lease_path():
    # Stable CS lock inode is a resource mutex only, never a CS runtime claim,
    # recovery packet, review, GO, or source/financial authority dependency.
    import follow_finance_gate as gate
    return ROOT/gate.SHARED_CPU_LEASE

@contextmanager
def controller_lease(registry_root):
    """Nonblocking cross-module CPU45 lock plus own permanent claim lease.

    Inherited open file descriptions retain both exclusions after parent death.
    Never LOCK_UN: surviving children must retain the same locked description.
    """
    global _CONTROLLER_LEASE_FD,_SHARED_RESOURCE_LEASE_FD
    shared=shared_resource_lease_path()
    # Production CS creates this stable lock. Do not create or modify its tree.
    shared_fd=os.open(shared,os.O_RDWR|os.O_NOFOLLOW)
    own_fd=None
    try:
        try:fcntl.flock(shared_fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:raise RuntimeError('SHARED_CS_CPU45_RESOURCE_LEASE_HELD_REFUSE_OVERLAP')
        directory=Path(registry_root)/MANIFEST_SHA256;directory.mkdir(parents=True,exist_ok=True)
        own_fd=os.open(directory/'CONTROLLER_LEASE.lock',os.O_CREAT|os.O_RDWR|os.O_NOFOLLOW,0o600)
        try:fcntl.flock(own_fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:raise RuntimeError('FOLLOW_NEXT6_CONTROLLER_LEASE_HELD_REFUSE_OVERLAP')
        old_own,old_shared=_CONTROLLER_LEASE_FD,_SHARED_RESOURCE_LEASE_FD
        _CONTROLLER_LEASE_FD,_SHARED_RESOURCE_LEASE_FD=own_fd,shared_fd
        try:yield own_fd
        finally:_CONTROLLER_LEASE_FD,_SHARED_RESOURCE_LEASE_FD=old_own,old_shared
    finally:
        if own_fd is not None:os.close(own_fd)
        os.close(shared_fd)


# The only new runtime seams are byte storage and its explicit checkpoint.
# The financial body(value) serializer and MINUTE np.savez_compressed stay exact.
BIG3=('ACCOUNT_FINANCIAL_AUDIT.json','NATIVE_RESULT.json','GUARD_RECEIPTS.json')
STORAGE_CHECKPOINT_SCHEMA='FOLLOW_NEXT6_2024_RAW_AND_STORED_TERMINAL_CHECKPOINT_V1'
_STORAGE_RECEIPTS={}

def storage_module():
    import follow_storage
    return follow_storage

def save_big_json(path,value):
    path=Path(path)
    record=storage_module().write(path.parent,path.name,body(value))
    key=(str(path.parent.absolute()),path.name)
    if key in _STORAGE_RECEIPTS:raise ValueError('IMMUTABLE_STORAGE_RECEIPT_ALREADY_BOUND')
    _STORAGE_RECEIPTS[key]=record
    return record

def checkpoint_file_hashes(directory,names):
    directory=Path(directory)
    if len(names)!=len(set(names)):raise ValueError('EXACT_UNIQUE_TERMINAL_NAMESPACE_REQUIRED')
    hashes={}
    for name in names:
        if name in BIG3:
            record=_STORAGE_RECEIPTS.get((str(directory.absolute()),name))
            if record is None:raise storage_module().u.StorageError('DURABLE_BIG3_STORAGE_RECEIPT_REQUIRED')
            storage_module().read(directory,name,record['raw']['SHA256'],receipt=record)
            hashes[name]=record['raw']['SHA256']
        else:hashes[name]=sha((directory/name).read_bytes())
    return hashes

def save_terminal_checkpoint(path,value):
    path=Path(path)
    if (type(value) is not dict or value.get('schema')!='IMMUTABLE_MATRIX_TERMINAL_CHECKPOINT_V1'
            or type(value.get('files')) is not dict):raise ValueError('EXACT_FROZEN_CHECKPOINT_CONSTRUCTION_REQUIRED')
    records={name:_STORAGE_RECEIPTS[(str(path.parent.absolute()),name)] for name in BIG3}
    checkpoint=dict(value,schema=STORAGE_CHECKPOINT_SCHEMA,
        scope_manifest_SHA256=MANIFEST_SHA256,
        storage_policy_SHA256=storage_module().policy_sha(),storage=records)
    storage_module().validate_checkpoint(checkpoint,expected_names=tuple(value['files']))
    # New checkpoint publishes only after every referenced stored artifact has
    # been reread at its independently recorded raw AND physical identity.
    storage_module().read_saved(path.parent,checkpoint,expected_names=tuple(value['files']))
    return storage_module().write_checkpoint(path.parent,path.name,body(checkpoint))


def storage_failure(error):
    import follow_storage
    return isinstance(error,(follow_storage.u.ResourceStop,follow_storage.u.PublicationError,follow_storage.u.StorageError,OSError)) or getattr(error,'failure_classification',None) in ('RESOURCE','DATA_STORAGE_VALIDATION')

def record_case_failure(directory,error):
    """Best-effort bounded evidence; construction cannot mask original failure."""
    try:
        import follow_storage
        value=dict(kind='EXECUTION_RESOURCE_DATA_OR_VALIDATION_INTERRUPTION',
            error=repr(error)[:4096],traceback=''.join(traceback.format_exception(type(error),error,error.__traceback__))[-16384:],
            UTC=utc(),automatic_retry=False,economic_halt_relabelled=False,
            failure_classification=getattr(error,'failure_classification',None) or ('RESOURCE' if isinstance(error,OSError) else 'DATA_STORAGE_VALIDATION' if storage_failure(error) else None),
            storage_publication_uncertain=bool(getattr(error,'published',False)),
            temporary_name=getattr(error,'temporary_name',None),
            file_close_failed=bool(getattr(error,'file_close_failed',False)),
            directory_close_failed=bool(getattr(error,'directory_close_failed',False)),
            temporary_cleanup_failed=bool(getattr(error,'temporary_cleanup_failed',False)),
            extra_full_account_snapshot_on_storage_failure=False)
        raw=body(value)
        if len(raw)>32768:raise ValueError('BOUNDED_FAILURE_CONSTRUCTION_REQUIRED')
        follow_storage.u.write_json_bytes(str(Path(directory).absolute()),'FAILURE.json',raw,encoding='raw',
            budget=follow_storage.budget(directory),limits=follow_storage.u.Limits(32768,32768))
        return True
    except BaseException as evidence_error:
        try:error.add_note('Bounded FAILURE.json could not be safely constructed or published: '+repr(evidence_error)[:1024])
        except BaseException:pass
        return False
