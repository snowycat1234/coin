"""Code-only checkpoint and explicit financial-code reuse proof; never root GO."""
import ast,inspect,json,hashlib
from pathlib import Path
import follow_native as native
import follow_transport as transport
import follow_native_common as c


def astsha(node):return hashlib.sha256(ast.dump(node,include_attributes=False).encode()).hexdigest()
def nodes(tree):
 out={}
 for node in tree.body:
  if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):out[node.name]=node
  if isinstance(node,ast.ClassDef):
   for child in node.body:
    if isinstance(child,(ast.FunctionDef,ast.AsyncFunctionDef)):out[node.name+'.'+child.name]=child
 return out

def main():
 spec=c.exact_object(c.ordinary(c.HERE/'TRANSPORT_PROJECTION.json'));rows={}
 for name,pin in spec['modules'].items():
  old=ast.parse(c.exact(c.ROOT/pin['origin'],pin['SHA256']));new=transport.admitted_tree(name);a,b=nodes(old),nodes(new)
  rows[name]=dict(origin=pin,functions={key:dict(origin_AST_SHA256=astsha(node),projected_AST_SHA256=astsha(b[key]),AST_unchanged=astsha(node)==astsha(b[key]),all_BinOp_arithmetic_ASTs_identical=[ast.dump(x) for x in ast.walk(node) if isinstance(x,ast.BinOp)]==[ast.dump(x) for x in ast.walk(b[key]) if isinstance(x,ast.BinOp)]) for key,node in a.items() if key in b})
 inherited={}
 for name in dir(native.ExpansionAccount):
  value=getattr(native.ExpansionAccount,name,None);old=getattr(native.D.Guard50ExitAccount,name,None)
  if hasattr(value,'__code__') and hasattr(old,'__code__') and name not in ('__init__','update_marks','contract_metadata','snapshot'):
   if getattr(value,'__func__',value) is not getattr(old,'__func__',old):raise ValueError('FINANCIAL_METHOD_FORK:'+name)
   inherited[name]=dict(same_function_object=True,same_code_object=True,origin_file=str(Path(value.__code__.co_filename).relative_to(c.ROOT)) if c.ROOT in Path(value.__code__.co_filename).parents else value.__code__.co_filename,origin_name=value.__qualname__)
 if len(inherited)<20:raise ValueError('INCOMPLETE_INHERITED_FINANCIAL_METHOD_PROOF')
 guards={}
 for name,base in [('schedule',native.D.ContinuationGuard.schedule),('_frozen_attempt',native.D.ContinuationGuard._frozen_attempt),('attempt',native.D.ContinuationGuard.attempt)]:
  method=getattr(native.ContinuationGuard,name)
  if method.__code__ is not base.__code__:raise ValueError('FINANCIAL_GUARD_FORK:'+name)
  guards[name]=dict(same_code_object=True,origin_name=base.__qualname__)
 output=dict(schema='FOLLOW_NEXT6_EXACT_FROZEN_ENGINE_REUSE_MAP_V1',financial_arithmetic_forked=False,module_file_identity_spoofing=False,new_follow_finance_source_scope_types=True,inherited_account_methods=inherited,guard_methods=guards,transport_projections=rows,permitted_transport_seams=['finite import/module-reference remapping','new FOLLOW live type admission and exact file checks','NEXT6 scope/runner/version/report labels','source guard finite own-module import set','saved native quality read bound to per-case immutable source capture','internally generated FOLLOW recipe/HLC projection','unchanged raw body bytes to reviewed big3 gzip storage','explicit raw-and-stored terminal checkpoint plus saved reader','bounded storage-failure evidence without duplicate snapshot'],keyword_map=spec.get('keyword_map',{}),legacy_quality_schema_intentionally_preserved='CSMOM21_REUSED_QUALIFIED_SOURCE_QUALITY_V2',all_financial_and_risk_arithmetic_unchanged=True)
 path=c.HERE/'REUSED_FUNCTION_MAP.json';path.write_bytes(c.canonical(output)+b'\n');print(c.sha(path.read_bytes()),len(inherited))
if __name__=='__main__':main()
