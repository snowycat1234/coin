"""Finite frozen generic source-quality helpers."""
from follow_transport import load as _load
_load('follow_native_quality',globals())
