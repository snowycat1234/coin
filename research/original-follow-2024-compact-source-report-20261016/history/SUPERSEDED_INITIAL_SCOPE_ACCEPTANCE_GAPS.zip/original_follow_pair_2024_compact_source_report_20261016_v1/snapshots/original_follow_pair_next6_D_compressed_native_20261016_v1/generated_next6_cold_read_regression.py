"""Invented 2024 bytes exercise the separate next6 cold loader boundary.

Only byte-checked generated authority/contract metadata is substituted. Genuine
NPZ decoding, guarded source capability reads, real 2024 capture/assemble and
causal mark projection, all 27 identities and full original prefix are retained.
The child stops at the postguard constructor sentinel without finance execution.
"""
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','POLARS_MAX_THREADS','VECLIB_MAXIMUM_THREADS'):os.environ[key]='1'
import json,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
WIRE_NAMES=('go','review','prepared-review','native-review','source-go','source-review')

def generated_cpu():
 value=os.environ.get('FOLLOW_GENERATED_TEST_CPU','7')
 if value not in ('6','7','8'):raise ValueError('GENERATED_REVIEW_CPU_6_7_8_ONLY')
 cpu=int(value)
 if sorted(os.sched_getaffinity(0))!=[cpu]:raise ValueError('EXACT_GENERATED_REVIEW_CPU_AFFINITY_REQUIRED')
 return cpu

def generated_fixture_root():
 chosen=Path(os.environ.get('FOLLOW_GENERATED_FIXTURE_ROOT',str(HERE)))
 if not chosen.is_absolute():chosen=ROOT/chosen
 chosen=Path(os.path.abspath(chosen))
 try:relative=chosen.relative_to(ROOT)
 except ValueError:raise ValueError('GENERATED_FIXTURE_ROOT_MUST_BE_INSIDE_WORKSPACE') from None
 if not relative.parts:raise ValueError('GENERATED_FIXTURE_SUBDIRECTORY_REQUIRED')
 for part in relative.parts:
  lower=part.lower()
  if lower.startswith('actual_') or lower in ('source_attempts','financial_attempts','execution_claims') or 'source_restore' in lower or lower.startswith('original_follow_pair_first6_'):raise ValueError('ACTUAL_OR_FIRST6_FIXTURE_ROOT_FORBIDDEN')
 if chosen.is_symlink() or any(parent.is_symlink() for parent in chosen.parents):raise ValueError('ORDINARY_GENERATED_FIXTURE_ROOT_REQUIRED')
 chosen.mkdir(parents=True,exist_ok=True)
 return chosen

def _pack(**arrays):
 from io import BytesIO
 import numpy as np
 out=BytesIO();np.savez_compressed(out,**arrays);return out.getvalue()

def _prices(clocks):
 import numpy as np
 import follow_native_config as config
 x=(clocks-config.utc('2020-01-01'))/config.DAY
 return np.column_stack([100+j*20+x*(.02+j*.003)+np.sin(x/(7+j)+j)*.4 for j in range(5)])

def parent_fixture(directory):
 generated_cpu()
 from copy import deepcopy
 import numpy as np
 import follow_native_common as c
 import follow_native_config as config
 import follow_source_entry as entry
 import follow_native_signal as signal
 import follow_native_codec as codec
 import follow_entry as original
 from follow_native_source2024 import assemble_inputs
 year=2024;contract=deepcopy(entry.descriptor()['qualified_source_contract'])
 directory=Path(directory);directory.mkdir()
 rows,first,last=codec.STORED_DAILY[year]
 clock=np.arange(first,last+config.DAY,config.DAY,dtype=np.int64)
 warm=_pack(close_available_us=clock,close=_prices(clock));period=config.source_year(year)
 decisions=np.arange(period['start'],period['end'],config.DAY,dtype=np.int64);p=_prices(decisions)
 daily=c.canonical([dict(symbol=s,close_us=int(at),close=float(p[i,j])) for i,at in enumerate(decisions) for j,s in enumerate(config.SYMBOLS)])
 clocks,close,_=codec.daily_inputs(year,warm,daily);months=[];mark_hashes={};mark_witnesses=[];final=None
 for rec in contract['months']:
  times=np.arange(rec['start'],rec['start']+rec['count']*codec.MINUTE,codec.MINUTE,dtype=np.int64);a=dict(times=times)
  for j,symbol in enumerate(config.SYMBOLS):
   for field in codec.FIELDS:a[symbol+'_'+field]=np.full(rec['count'],100+j,dtype=np.float64)
   a[symbol+'_mark'][:]=100+j+np.arange(rec['count'],dtype=np.float64)*2**-24
   for at in range(rec['start']+config.DAY,rec['start']+rec['count']*codec.MINUTE+1,config.DAY):
    k=int(np.searchsorted(clocks,at))
    if k<len(clocks) and clocks[k]==at:a[symbol+'_close'][(at-rec['start'])//codec.MINUTE-1]=close[k,j]
   if rec['start']<=1723456920000000<rec['start']+rec['count']*codec.MINUTE:
    prior=int(np.searchsorted(times,1723456860000000));indices=[int(np.searchsorted(times,at)) for at in (1723456920000000,1723456980000000)]
    for i in indices:a[symbol+'_mark'][i]=a[symbol+'_mark'][prior]+.25+(i-prior)*.125
    mark_witnesses.append(dict(symbol=symbol,prior_float64_SHA256=c.sha(a[symbol+'_mark'][prior].tobytes()),original_missing_float64_SHA256=[c.sha(a[symbol+'_mark'][i].tobytes()) for i in indices]))
  raw=_pack(**a);rec['hash']=c.sha(raw);rec['size']=len(raw);months.append((rec['path'],raw));final=a
  if rec['start']<=1723456920000000<rec['start']+rec['count']*codec.MINUTE:
   projected,_=codec.month_arrays(year,raw,rec['start'],rec['count'])
   mark_hashes={symbol:c.sha(projected[symbol+'_mark'].tobytes()) for symbol in config.SYMBOLS}
   for witness in mark_witnesses:
    symbol=witness['symbol'];prior=int(np.searchsorted(times,1723456860000000))
    for at in (1723456920000000,1723456980000000):
     i=int(np.searchsorted(times,at))
     if projected[symbol+'_mark'][i].tobytes()!=a[symbol+'_mark'][prior].tobytes() or projected[symbol+'_mark'][i].tobytes()==a[symbol+'_mark'][i].tobytes():raise ValueError('GENERATED_2024_CAUSAL_CARRY_MUST_REPLACE_UNEQUAL_INTERPOLATED_BITS')
 events=[dict(symbol=symbol,event_us=int(at+15001),raw_rate=(-1 if j%2 else 1)*.000013,reported_interval_hours=8.) for at in range(period['start'],period['end'],8*60*codec.MINUTE) for j,symbol in enumerate(sorted(config.SYMBOLS))]
 contract['events']['selected_events']=len(events);contract['events']['stored_events']=len(events)
 sidecar=c.canonical(dict(final_endpoint_close={symbol:float(final[symbol+'_close'][-1]) for symbol in config.SYMBOLS},arrival_status='UNKNOWN_NOT_CERTIFIED',certifies_liquidation=False,certifies_no_liquidation=False,causal_estimate_mark_array_SHA256=mark_hashes))
 values={contract['warmup_path']:warm,contract['daily_path']:daily,contract['events_path']:c.canonical(events),contract['quality_sidecar_path']:sidecar,**dict(months)}
 remap={name:str((directory/('SOURCE_'+str(i)+Path(name).suffix)).relative_to(ROOT)) for i,name in enumerate(values)}
 contract['read_files']={remap[name]:dict(SHA256=c.sha(raw),bytes=len(raw)) for name,raw in values.items()}
 for key in ('warmup_path','daily_path','events_path','quality_sidecar_path'):contract[key]=remap[contract[key]]
 contract['source_root']=str(directory.relative_to(ROOT))
 for rec in contract['months']:rec['path']=remap[rec['path']]
 months=tuple((remap[name],raw) for name,raw in months)
 captured=assemble_inputs(year,warm,daily,c.canonical(events),sidecar,months,contract)
 if len(captured['clocks'])!=565 or len(captured['decisions'])!=366 or captured['sidecar']['derived_mark_cells']!=10 or c.canonical(captured['quality_intervals'])!=c.canonical(contract['quality_intervals']):raise ValueError('EXACT_2024_QUALIFIED_CALENDAR_AND_DERIVED_QUALITY_REQUIRED')
 for name,raw in values.items():(ROOT/remap[name]).write_bytes(raw)
 arrays={k:np.zeros(shape,dtype=dtype) for k,(shape,dtype) in entry.array_specs(year).items()}
 for i,(name,a) in enumerate(arrays.items()):
  if a.dtype.kind=='f':a.flat[:]=np.arange(a.size,dtype=np.float64)*2**-20+i*2**-8;a.flat[0]=-0.
  elif a.dtype.kind=='b':a.flat[::2]=True
 arrays['decision_us']=captured['decisions']
 prefix_metadata=original.source_maps()[0]['years']['2024']['prefix_metadata']
 prefix_clock=np.arange(prefix_metadata['first_source_clock_us'],period['end'],config.DAY,dtype=np.int64)
 if len(prefix_clock)!=1826 or prefix_metadata['selected_rows']!=1826:raise ValueError('EXACT_FULL_ORIGINAL_2024_PREFIX_METADATA_REQUIRED')
 prefix_raw=_pack(close_available_us=prefix_clock,close=_prices(prefix_clock))
 artifacts={'2024/TARGETS.npz':_pack(**arrays),'2024/SOURCE_PREFIX_INPUTS.npz':prefix_raw}
 (directory/'2024').mkdir()
 for name,raw in artifacts.items():(directory/name).write_bytes(raw)
 wires={key:c.canonical(dict(generated_wire=key)) for key in WIRE_NAMES}
 cells=list(entry.tranche_cells(entry.NEXT6));wires['go']=c.canonical(dict(generated_wire='go',ordered_cells=cells))
 hashes={k:c.sha(v) for k,v in wires.items()}
 for key,raw in wires.items():(directory/(key+'.generated.json')).write_bytes(raw)
 meta=dict(source_identity=captured['source_identity'],source_rows_SHA256=c.jsha(captured['source_rows']),funding_events_SHA256=c.jsha(captured['events']),source_quality_sidecar_SHA256=c.sha(captured['sidecar_raw']),array_identities={k:signal.array_byte_identity(v) for k,v in arrays.items()})
 p=dict(ordered_cells=cells,years={'2024':meta},artifacts={k:dict(SHA256=c.sha(v),bytes=len(v)) for k,v in artifacts.items()},source_stage_GO_SHA256=hashes['source-go'],source_review_SHA256=hashes['source-review'])
 prep=c.canonical(dict(generated_cold_preparation=True,metadata_SHA256=c.jsha(p),contract_SHA256=c.jsha(contract)))
 (directory/'PREPARATION.json').write_bytes(prep)
 fixture=dict(preparation=p,preparation_SHA256=c.sha(prep),contract=contract,hashes=hashes,cell_id=cells[0],prefix_rows=len(prefix_clock),full_original_prefix_retained=True,prefix_SHA256=c.sha(prefix_raw),expected_native_source_sidecar_SHA256=c.sha(captured['sidecar_raw']),expected_source_read_paths=sorted(contract['read_files']),all27_arrays=len(arrays),causal_mark_witnesses=mark_witnesses,derived_mark_cells=10,all_generated_body_files=[str((directory/name).relative_to(ROOT)) for name in artifacts]+list(contract['read_files']))
 (directory/'FIXTURE_METADATA.json').write_bytes(c.canonical(fixture)+b'\n')
 return fixture

def child(directory,version):
 # Profile starts before importing the numerical, ZIP, guard or loader graph.
 # Matching exact function locations also observes any import-time prewarming.
 # importlib.metadata may attempt to open an absent runtime zip path; record
 # that failed constructor probe explicitly. No ZIP central directory is read.
 counts={name:dict(before_guard=0,inside_guard=0) for name in ('np_load','ZipFile','ZIP_central_directory_decode','native_capture','native_assemble','causal_adapter','causal_project')}
 watched={};early_calls=[];early_frames={}
 def prof(frame,event,arg):
  if event=='return' and id(frame) in early_frames:
   early_frames.pop(id(frame))['constructor_returned_without_open_fp']=getattr(frame.f_locals.get('self'),'fp',None) is None
  if event!='call':return
  code=frame.f_code;name=watched.get(code);filename=code.co_filename
  if name is None:
   if code.co_name=='load' and '/numpy/lib/' in filename and '_npyio' in filename:name='np_load'
   elif code.co_qualname=='ZipFile.__init__' and ('/zipfile/' in filename or filename.endswith('/zipfile.py')):name='ZipFile'
   elif code.co_name=='_RealGetContents' and ('/zipfile/' in filename or filename.endswith('/zipfile.py')):name='ZIP_central_directory_decode'
   elif code.co_name=='capture_year' and filename.endswith('/follow_native_source.py'):name='native_capture'
   elif code.co_name=='assemble_inputs' and filename.endswith('/follow_native_source2024.py'):name='native_assemble'
   elif code.co_name=='mark2024' and filename.endswith('/follow_native_codec.py'):name='causal_adapter'
   elif code.co_name=='project_month' and filename.endswith('/missing_mark_adapter_2024.py'):name='causal_project'
  if name:
   guard_module=sys.modules.get('follow_native_source_guard');current=getattr(guard_module,'current_guard',None)
   phase='inside_guard' if current is not None and current() is not None else 'before_guard';counts[name][phase]+=1
   if phase=='before_guard':
    chain=[];caller=frame
    while caller is not None and len(chain)<12:chain.append(caller.f_code.co_filename+':'+str(caller.f_lineno)+':'+caller.f_code.co_name);caller=caller.f_back
    row=dict(function=name,chain=chain,constructor_file=str(frame.f_locals.get('file')),constructor_file_exists=os.path.exists(frame.f_locals['file']) if name=='ZipFile' and isinstance(frame.f_locals.get('file'),(str,bytes,os.PathLike)) else None,constructor_returned_without_open_fp=False)
    early_calls.append(row);early_frames[id(frame)]=row
 sys.setprofile(prof)
 import time,types
 from contextlib import ExitStack,contextmanager
 from unittest.mock import patch
 directory=Path(directory).resolve();target=HERE
 if version!='v1':raise ValueError('ONLY_SEPARATE_NEXT6_V1_ALLOWED')
 sys.path.insert(0,str(target))
 import follow_native_common as c
 import follow_source_entry as entry
 import follow_native_config as config
 import follow_finance_gate as gate
 import follow_verified_wires as verified
 import follow_input_loader as loader
 import follow_native_source_scope as scope
 import follow_native_source as native_source
 import follow_native_source2024 as source2024
 import follow_native_codec as codec
 import follow_native_source_guard as source_guard
 import follow_entry as original
 import run_follow
 import numpy as np,zipfile
 watched.update({np.load.__code__:'np_load',zipfile.ZipFile.__init__.__code__:'ZipFile',zipfile.ZipFile._RealGetContents.__code__:'ZIP_central_directory_decode',native_source.capture_year.__code__:'native_capture',source2024.assemble_inputs.__code__:'native_assemble'})
 fixture=c.exact_object((directory/'FIXTURE_METADATA.json').read_bytes());prep=(directory/'PREPARATION.json').read_bytes();p=fixture['preparation'];contract=fixture['contract']
 if (c.sha(prep)!=fixture['preparation_SHA256'] or c.exact_object(prep)['metadata_SHA256']!=c.jsha(p) or c.exact_object(prep)['contract_SHA256']!=c.jsha(contract)):raise ValueError('GENERATED_PREPARATION_PIN_CHANGED')
 wires={k:(directory/(k+'.generated.json')).read_bytes() for k in WIRE_NAMES};hashes=fixture['hashes']
 if any(c.sha(v)!=hashes[k] for k,v in wires.items()):raise ValueError('GENERATED_WIRE_PIN_CHANGED')
 cp437_before='encodings.cp437' in sys.modules
 if cp437_before:raise ValueError('FRESH_PROCESS_CP437_ALREADY_PREWARMED')
 causal_unprimed=codec._MARK2024 is None
 if not causal_unprimed:raise ValueError('FRESH_PROCESS_2024_CAUSAL_ADAPTER_PREWARMED')
 code=gate.code_identity();claim=c.canonical(dict(cell_id=fixture['cell_id'],root_GO_SHA256=hashes['go'],preparation_SHA256=c.sha(prep),code_identity=code))
 case=directory/('CHILD_'+version);case.mkdir()
 argv=['run_follow.py','--case','--cell-id',fixture['cell_id'],'--cpu',str(generated_cpu()),'--case-output',str(case),'--preparation',str(directory),'--preparation-sha',c.sha(prep)]
 for key in WIRE_NAMES:argv+=['--'+key,str(directory/(key+'.generated.json')),'--'+key+'-sha',hashes[key]]
 def check_prep(raw):
  if raw!=prep:raise ValueError('EXACT_GENERATED_PREPARATION_REQUIRED')
  return p
 def check_source(go,go_sha,review,review_sha):
  if (go,go_sha,review,review_sha)!=(wires['source-go'],hashes['source-go'],wires['source-review'],hashes['source-review']):raise ValueError('EXACT_GENERATED_SOURCE_WIRES_REQUIRED')
  return {}
 def check_gate(pr,go,go_sha,review,review_sha,prepared,prepared_sha,native,native_sha):
  if (pr,go,go_sha,review,review_sha,prepared,prepared_sha,native,native_sha)!=(prep,wires['go'],hashes['go'],wires['review'],hashes['review'],wires['prepared-review'],hashes['prepared-review'],wires['native-review'],hashes['native-review']):raise ValueError('EXACT_GENERATED_FINANCIAL_WIRES_REQUIRED')
  return {}
 phases=[];checked=dict(all27_arrays_and_prefix_bits_checked=False,postguard_constructor_sentinel_reached=False,qualified_2024_derived_policy_preserved=False)
 class StopBeforeNative(Exception):pass
 @contextmanager
 def stop_native(loaded,**kwargs):
  if verified._LIVE or scope._LIVE or source_guard.current_guard() is not None:raise ValueError('POSTGUARD_SOURCE_BINDINGS_NOT_REVOKED')
  loaded.validate()
  if len(loaded.arrays)!=27 or not all(not a.flags.writeable for a in loaded.arrays.values()):raise ValueError('EXACT_ALL27_IMMUTABLE_ARRAYS_REQUIRED')
  if c.sha(loaded.source['sidecar_raw'])!=fixture['expected_native_source_sidecar_SHA256']:raise ValueError('NATIVE_SOURCE_EXPECTED_BITS_REQUIRED')
  if (loaded.year!=2024 or len(loaded.source['clocks'])!=565 or len(loaded.source['decisions'])!=366 or loaded.source['sidecar']['derived_mark_cells']!=10 or c.canonical(loaded.source['quality_intervals'])!=c.canonical(contract['quality_intervals']) or c.sha(loaded.captured_artifacts['2024/SOURCE_PREFIX_INPUTS.npz'])!=fixture['prefix_SHA256']):raise ValueError('QUALIFIED_2024_DERIVED_POLICY_AND_FULL_PREFIX_BITS_REQUIRED')
  checked['all27_arrays_and_prefix_bits_checked']=True;checked['postguard_constructor_sentinel_reached']=True;checked['qualified_2024_derived_policy_preserved']=True
  phases.append('POST_GUARD_CONSTRUCTOR_SENTINEL')
  raise StopBeforeNative('GENERATED_STOP_BEFORE_ACCOUNT_SCOPE_OR_PROVIDER')
  yield
 original_save=run_follow.r.save
 def recording_save(path,value):
  original_save(path,value)
  if Path(path).name=='WORKER_AUTHORITY_VERIFIED.json':phases.append('REAL_WORKER_AUTHORITY_VERIFIED')
  if Path(path).name=='WORKER_SOURCE_ACCEPTED_BEFORE_ACCOUNT.json':
   phases.append('SOURCE_ACCEPTED_GUARD_EXITED')
   if verified._LIVE or scope._LIVE or source_guard.current_guard() is not None:raise ValueError('REAL_WORKER_SOURCE_ACCEPTANCE_BEFORE_GUARD_EXIT')
   m=types.ModuleType('follow_admission');m.admit_case=stop_native;sys.modules['follow_admission']=m
   sys.modules['follow_native']=types.ModuleType('follow_native')
 def generated_limits(cpu):
  if cpu!=generated_cpu():raise ValueError('GENERATED_CPU_ONLY')
 error=None;start=time.monotonic()
 with ExitStack() as stack:
  stack.enter_context(patch.object(entry,'validate_preparation_metadata',side_effect=check_prep))
  stack.enter_context(patch.object(entry,'validate_source_authority_metadata',side_effect=check_source))
  stack.enter_context(patch.object(gate,'validate',side_effect=check_gate))
  stack.enter_context(patch.object(entry,'descriptor',return_value={'qualified_source_contract':contract}))
  stack.enter_context(patch.object(original,'source_maps',return_value=({'years':{'2024':{'prefix_metadata':{'selected_rows':fixture['prefix_rows']}}}},{})))
  stack.enter_context(patch.object(sys,'argv',argv));stack.enter_context(patch.object(run_follow.r,'apply_limits',side_effect=generated_limits))
  stack.enter_context(patch.object(run_follow,'worker_claim',return_value=claim));stack.enter_context(patch.object(run_follow.r,'save',side_effect=recording_save))
  try:run_follow.main()
  except StopBeforeNative:pass
  except BaseException as exc:error=type(exc).__name__+':'+str(exc)
  else:raise ValueError('EXACT_COLD_WORKER_STOP_CONDITION_NOT_REACHED')
 sys.setprofile(None)
 for name in ('follow_admission','follow_native'):sys.modules.pop(name,None)
 receipt_name='SOURCE_RECAPTURE_GUARD_RECEIPT.json' if error is None else 'FAILED_SOURCE_RECAPTURE_GUARD_RECEIPT.json'
 receipt=c.exact_object((case/receipt_name).read_bytes())
 observed=receipt['observed_workspace_read_paths'];expected=[str(ROOT/name) for name in fixture['expected_source_read_paths']]
 finance=[n for n in sys.modules if n in ('follow_admission','follow_native','full_d','perpetual_account','minute_provider','source_window_interface')]
 result=dict(schema='FOLLOW_NEXT6_COLD_REAL_READ_PATH_REGRESSION_V2',version=version,status='PASS',error=error,CPU_affinity=sorted(os.sched_getaffinity(0)),optimized=bool(sys.flags.optimize),profiling_started_before_numerical_zip_source_imports=True,cp437_preloaded_before_production_entry=cp437_before,cp437_loaded_after_entry='encodings.cp437' in sys.modules,causal_adapter_unprimed_before_entry=causal_unprimed,full_original_prefix_rows=fixture['prefix_rows'],real_function_call_counts=counts,preguard_import_metadata_missing_runtime_zip_probes=early_calls,real_CLI_phases=phases,**checked,real_canonical_source_reads_observed=all(x in observed for x in expected),source_guard_receipt=receipt,finance_modules_imported=finance,scopes_revoked=not verified._LIVE and not scope._LIVE and not loader._LIVE,account_provider_historical_scope_constructed=0,actual_payload_reads=0,actual_financial_runs=0,elapsed_seconds=time.monotonic()-start)
 if (any(v['before_guard'] for name,v in counts.items() if name!='ZipFile') or any(row['function']!='ZipFile' or row['constructor_file_exists'] is not False or row['constructor_returned_without_open_fp'] is not True or not any('/importlib/metadata/' in item for item in row['chain']) for row in early_calls)):
  raise ValueError('FORBIDDEN_READ_PATH_PREWARM:'+str(counts)+str(early_calls))
 if finance or not result['scopes_revoked']:raise ValueError('COLD_PROCESS_MUST_STOP_BEFORE_FINANCE')
 if error is not None or phases!=['REAL_WORKER_AUTHORITY_VERIFIED','SOURCE_ACCEPTED_GUARD_EXITED','POST_GUARD_CONSTRUCTOR_SENTINEL'] or not result['real_canonical_source_reads_observed'] or any(receipt['forbidden_attempts'].values()) or not result['all27_arrays_and_prefix_bits_checked']:raise ValueError('COLD_REAL_2024_READ_PATH_FAILED:'+str(error))
 if counts['np_load']['inside_guard']<15 or counts['native_capture']['inside_guard']!=1 or counts['native_assemble']['inside_guard']!=1:raise ValueError('EXACT_REAL_2024_LOADER_CAPTURE_ASSEMBLE_REQUIRED')
 if (not result['causal_adapter_unprimed_before_entry'] or counts['causal_adapter']['before_guard'] or counts['causal_project']['before_guard'] or counts['causal_project']['inside_guard']!=12 or not result['qualified_2024_derived_policy_preserved'] or result['full_original_prefix_rows']!=1826):raise ValueError('EXACT_UNPREWARMED_2024_CAUSAL_QUALIFIED_FULL_PREFIX_REQUIRED')
 print(json.dumps(result,sort_keys=True))

def run_parent(receipt_path):
 import subprocess,tempfile
 from hashlib import sha256
 generated_cpu()
 results=[]
 with tempfile.TemporaryDirectory(prefix='GENERATED_COLD_',dir=generated_fixture_root()) as tmp:
  root=Path(tmp)/'generated';parent_fixture(root)
  for version in ('v1',):
   command=[sys.executable,'-B']+(['-O'] if sys.flags.optimize else [])+[str(HERE/'generated_next6_cold_read_regression.py'),'--child',str(root),version]
   p=subprocess.run(command,capture_output=True,text=True,timeout=120)
   if p.returncode:raise RuntimeError('COLD_CHILD_FAILED:'+version+'\n'+p.stderr+'\n'+p.stdout[-2000:])
   results.append(json.loads(p.stdout))
 record=dict(schema='FOLLOW_NEXT6_COLD_REAL_READ_PATH_PARENT_RECEIPT_V2',status='PASS',optimized=bool(sys.flags.optimize),CPU_affinity=sorted(os.sched_getaffinity(0)),parent_produced_generated_bytes=True,real_native_capture_not_mocked=True,guard_source_logic_unchanged=True,only_additive_dependency_preload='encodings.cp437',children=results,actual_source_or_target_bodies_read=False,actual_financial_runs=0)
 raw=(json.dumps(record,sort_keys=True,separators=(',',':'))+'\n').encode();Path(receipt_path).write_bytes(raw)
 print(json.dumps(dict(status='PASS',receipt=str(receipt_path),SHA256=sha256(raw).hexdigest(),bytes=len(raw)),sort_keys=True))

if __name__=='__main__':
 if len(sys.argv)==3 and sys.argv[1]=='--parent':run_parent(sys.argv[2]);raise SystemExit(0)
 if len(sys.argv)!=4 or sys.argv[1]!='--child' or sys.argv[3]!='v1':raise SystemExit('CHILD_ONLY_EXACT_GENERATED_ARGUMENTS_REQUIRED')
 child(sys.argv[2],sys.argv[3])
