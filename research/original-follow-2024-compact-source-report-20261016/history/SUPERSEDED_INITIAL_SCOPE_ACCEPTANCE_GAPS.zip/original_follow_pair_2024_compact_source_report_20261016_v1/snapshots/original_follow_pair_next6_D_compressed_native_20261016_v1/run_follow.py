"""First6 controller; source guard exits before genuine FOLLOW finance imports."""
import os,sys
from pathlib import Path
THREAD_ENV=('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','POLARS_MAX_THREADS','VECLIB_MAXIMUM_THREADS')
for key in THREAD_ENV:os.environ[key]='1'
if __name__=='__main__' and len(sys.argv)>1 and sys.argv[1]=='--bootstrap':
 import follow_process_runtime as r
 import resource
 if len(sys.argv)<6 or sys.argv[4]!='--':raise SystemExit('EXACT_STDLIB_BOOTSTRAP_ARGUMENTS_REQUIRED')
 if any(name.split('.')[0] in ('numpy','polars','scipy') for name in sys.modules):raise ValueError('NUMERICAL_IMPORT_BEFORE_RESOURCE_LIMITS_FORBIDDEN')
 cpu=int(sys.argv[2]);directory=Path(sys.argv[3]);child=sys.argv[5:];r.apply_limits(cpu)
 r.save(directory/'BOOTSTRAP_READY.json',dict(schema='STDLIB_PRE_NUMERICAL_IMPORT_RESOURCE_BOOTSTRAP_V1',PID=os.getpid(),requested_CPU=cpu,actual_affinity=sorted(os.sched_getaffinity(0)),thread_environment={key:os.environ[key] for key in THREAD_ENV},limits={name:list(resource.getrlimit(which)) for name,which in (('AS',resource.RLIMIT_AS),('CPU',resource.RLIMIT_CPU),('RSS',resource.RLIMIT_RSS))}))
 os.execvpe(child[0],child,r.environment())
from follow_transport import load as _load
_load('run_follow',globals())
TERMINAL_FILES=TERMINAL_FILES+('SOURCE_NATIVE_QUALITY.json',)

def wires(args):
 import follow_native_common as c
 import follow_source_entry as e
 import follow_finance_gate as gate
 raw=c.exact(ordinary(args.preparation)/'PREPARATION.json',args.preparation_sha)
 prep=e.validate_preparation_metadata(raw)
 blobs={name:c.exact(ordinary(getattr(args,name.replace('-','_'))),getattr(args,name.replace('-','_')+'_sha')) for name in WIRE_NAMES}
 e.validate_source_authority_metadata(blobs['source-go'],args.source_go_sha,blobs['source-review'],args.source_review_sha)
 gate.validate(raw,blobs['go'],args.go_sha,blobs['review'],args.review_sha,blobs['prepared-review'],args.prepared_review_sha,blobs['native-review'],args.native_review_sha)
 return raw,prep,blobs

def read_paths(args,prep):
 import follow_native_common as c
 import follow_source_entry as e
 paths=[]
 for base,name in ((follow_native_bootstrap.SOURCE,'CODE_MANIFEST.json'),(HERE,'FINANCIAL_CODE_MANIFEST.json')):
  record=c.exact_object((base/name).read_bytes());paths.extend(base/key for key in record['files']);paths.extend(ROOT/key for key in record['dependencies']);paths.append(base/name)
 paths.extend(ordinary(getattr(args,name.replace('-','_'))) for name in WIRE_NAMES)
 paths.append(ordinary(args.preparation)/'PREPARATION.json');paths.extend(ordinary(args.preparation)/name for name in prep['artifacts'])
 paths.extend(ROOT/name for name in e.descriptor()['qualified_source_contract']['read_files'])
 return paths

def load_saved_year(args,prep,verified_binding):
 # ZIP central-directory ASCII member names lazily resolve the stdlib cp437
 # codec. Resolve that exact dependency before the unchanged source guard.
 import encodings.cp437
 import follow_input_loader as loader
 import follow_native_source_scope as native_scope
 import follow_native_source,follow_native_source2024,follow_native_quality,follow_native_codec
 import follow_native_signal
 from follow_native_source_guard import SourceOnlyGuard
 follow_native_signal.reviewed_signal()
 guard=SourceOnlyGuard(read_paths=read_paths(args,prep),write_roots=());loaded=None
 try:
  with guard:
   guard.checkpoint('FRESH_WORKER_FOLLOW_NEXT6_SOURCE_RECAPTURE_BEFORE_FINANCE_IMPORT')
   loaded=loader.load_year(args.preparation,expected_preparation_sha256=args.preparation_sha,year=2024,
    source_go_raw=Path(args.source_go).read_bytes(),expected_source_go_sha256=args.source_go_sha,
    source_review_raw=Path(args.source_review).read_bytes(),expected_source_review_sha256=args.source_review_sha,
    financial_go_raw=Path(args.go).read_bytes(),expected_financial_go_sha256=args.go_sha,
    financial_review_raw=Path(args.review).read_bytes(),expected_financial_review_sha256=args.review_sha,
    prepared_review_raw=Path(args.prepared_review).read_bytes(),expected_prepared_review_sha256=args.prepared_review_sha,
    native_review_raw=Path(args.native_review).read_bytes(),expected_native_review_sha256=args.native_review_sha,verified_binding=verified_binding)
   guard.checkpoint('EXACT_SAVED_FOLLOW_NEXT6_TARGETS_LOADED_WITHOUT_REGENERATION')
  receipt=guard.receipt('PASS_FINANCIAL_WORKER_SOURCE_ONLY_RECAPTURE');receipt.update(source_scopes_revoked=True,native_source_scopes_revoked=not native_scope._LIVE,saved_targets_and_covariance_rebuilt=False)
  r.write_bytes(ordinary(args.case_output)/'SOURCE_NATIVE_QUALITY.json',loaded.source['sidecar_raw'])
  return loaded,receipt
 except BaseException as error:
  if loaded is not None:loader.revoke(loaded)
  r.save(ordinary(args.case_output)/'FAILED_SOURCE_RECAPTURE_GUARD_RECEIPT.json',guard.receipt('STOP_FINANCIAL_WORKER_SOURCE_ONLY_RECAPTURE',error=repr(error)))
  raise

_frozen_controller=controller
def controller(args):
 # Exact full-cap stat admission is read-only and precedes any output/lease/claim.
 budget=r.check_full_cohort_budget(ordinary(args.output))
 print(json.dumps(budget,sort_keys=True),flush=True)
 return _frozen_controller(args)

if __name__=='__main__':main()
