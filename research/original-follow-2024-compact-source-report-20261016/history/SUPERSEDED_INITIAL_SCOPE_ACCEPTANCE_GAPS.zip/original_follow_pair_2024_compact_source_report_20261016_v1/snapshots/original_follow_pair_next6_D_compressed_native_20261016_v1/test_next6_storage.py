"""Generated integration: unchanged serializer bytes, saved/native40, stops."""
from contextlib import contextmanager
from copy import deepcopy
from pathlib import Path
from types import SimpleNamespace
import importlib,os,sys,tempfile,unittest
from unittest.mock import patch,Mock
import follow_native_common as c
import follow_process_runtime as r
import follow_storage as s
import run_follow

class StorageIntegrationTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(prefix='GENERATED_STORAGE_',dir=c.HERE);self.addCleanup(self.tmp.cleanup)
  self.root=Path(self.tmp.name);self.directory=self.root/'CASE';self.directory.mkdir()
  self.addCleanup(r._STORAGE_RECEIPTS.clear)
 def checkpoint(self):
  return dict(schema=r.STORAGE_CHECKPOINT_SCHEMA,cell_id='GENERATED',files=r.checkpoint_file_hashes(self.directory,s.BIG3),checker_SHA256='0'*64,reconstruction_proof_SHA256='1'*64,all_evidence_fsynced=True,restart_financial_snapshot_permission=False,fresh_scope_revoked=True,scope_manifest_SHA256=c.SCOPE_SHA,storage_policy_SHA256=s.policy_sha(),storage={n:r._STORAGE_RECEIPTS[(str(self.directory),n)] for n in s.BIG3})
 def write_three(self):
  values={n:dict(unicode='é',typed=[True,None,1,1.0,-0.0,'-0E-70'],journal=[{'x':'1.00000000000000000000001'},{'x':'.055044'}]) for n in s.BIG3}
  for name,value in values.items():r.save(self.directory/name,value)
  return {n:r.body(v) for n,v in values.items()}
 def test_exact_body_raw_stored_and_new_checkpoint_namespace(self):
  expected=self.write_three();cp=self.checkpoint()
  restored=s.read_saved(self.directory,cp,expected_names=s.BIG3)
  self.assertEqual(restored,expected)
  for name,raw in expected.items():
   rec=cp['storage'][name];self.assertFalse((self.directory/name).exists());self.assertTrue((self.directory/(name+'.gz')).exists())
   self.assertEqual(rec['raw'],dict(SHA256=c.sha(raw),bytes=len(raw)));self.assertEqual(rec['stored']['SHA256'],c.sha((self.directory/(name+'.gz')).read_bytes()))
  old=dict(cp,schema=s.LEGACY_SCHEMA);old={k:v for k,v in old.items() if k in s.LEGACY_FIELDS}
  with self.assertRaises(ValueError):s.read_legacy_raw_checkpoint(self.directory,old,expected_names=s.BIG3)
 def test_immutable_checkpoint_after_all_references_and_fsync(self):
  expected=self.write_three();old=dict(self.checkpoint());old['schema']=s.LEGACY_SCHEMA
  for key in ('storage','storage_policy_SHA256','scope_manifest_SHA256'):old.pop(key)
  r.save(self.directory/'TERMINAL_CHECKPOINT.json',old)
  cp=c.exact_object((self.directory/'TERMINAL_CHECKPOINT.json').read_bytes())
  self.assertEqual(cp['schema'],s.SCHEMA);self.assertEqual(s.read_saved(self.directory,cp,expected_names=s.BIG3),expected)
  with self.assertRaises((ValueError,OSError)):r.save(self.directory/'TERMINAL_CHECKPOINT.json',old)
 def test_every_missing_extra_changed_checkpoint_field_rejected(self):
  self.write_three();cp=self.checkpoint()
  for key in cp:
   bad=deepcopy(cp);bad.pop(key)
   with self.subTest(missing=key),self.assertRaises(ValueError):s.read_saved(self.directory,bad,expected_names=s.BIG3)
  for field,value in [('schema',s.LEGACY_SCHEMA),('scope_manifest_SHA256','0'*64),('storage_policy_SHA256','0'*64),('storage',{}),('extra',True)]:
   bad=dict(cp,**{field:value})
   with self.subTest(field=field),self.assertRaises(ValueError):s.read_saved(self.directory,bad,expected_names=s.BIG3)
 def test_logical_raw_and_actual_physical_pin_mutations_rejected(self):
  self.write_three();cp=self.checkpoint();name=s.BIG3[0]
  for key in ('raw','stored'):
   for field in ('SHA256','bytes'):
    bad=deepcopy(cp);bad['storage'][name][key][field]='0'*64 if field=='SHA256' else bad['storage'][name][key][field]+1
    with self.subTest(key=key,field=field),self.assertRaises(ValueError):s.read_saved(self.directory,bad,expected_names=s.BIG3)
  target=self.directory/(name+'.gz');raw=target.read_bytes();target.write_bytes(raw[:4]+b'\x01'+raw[5:])
  with self.assertRaises(ValueError):s.read_saved(self.directory,cp,expected_names=s.BIG3)
 def test_raw_gzip_ambiguity_and_extra_file_rejected(self):
  self.write_three();cp=self.checkpoint();name=s.BIG3[0]
  (self.directory/name).write_bytes(b'{}')
  with self.assertRaises(ValueError):s.read_saved(self.directory,cp,expected_names=s.BIG3)
 def test_legacy_raw_schema_remains_explicit_and_exact(self):
  raw={n:r.body({'generated':n}) for n in s.BIG3}
  for name,value in raw.items():r.write_bytes(self.directory/name,value)
  cp=dict(schema=s.LEGACY_SCHEMA,cell_id='GENERATED',files={n:c.sha(v) for n,v in raw.items()},checker_SHA256='0'*64,reconstruction_proof_SHA256='1'*64,all_evidence_fsynced=True,restart_financial_snapshot_permission=False,fresh_scope_revoked=True)
  self.assertEqual(s.read_legacy_raw_checkpoint(self.directory,cp,expected_names=s.BIG3),raw)
  with self.assertRaises(ValueError):s.read_saved(self.directory,cp,expected_names=s.BIG3)
 def test_prewrite_resource_stop_no_output_no_receipt(self):
  error=s.u.ResourceStop('GENERATED',{})
  with patch.object(s,'budget',return_value=lambda **kw:(_ for _ in ()).throw(error)):
   with self.assertRaises(s.u.ResourceStop) as caught:r.save(self.directory/s.BIG3[0],{'x':1})
  self.assertIs(caught.exception,error);self.assertFalse(list(self.directory.iterdir()));self.assertFalse(r._STORAGE_RECEIPTS);self.assertFalse(error.economic_halt)
 def test_real_case_failure_branch_storage_stop_no_snapshot_original_preserved(self):
  import follow_verified_wires as verified,follow_input_loader as loader,follow_admission as admission,follow_native as native
  error=s.u.PublicationError('GENERATED_POST_PUBLICATION_UNCERTAINTY');error.failure_classification='RESOURCE'
  account=SimpleNamespace(snapshot=Mock(side_effect=AssertionError('FULL_SNAPSHOT_FORBIDDEN')))
  sim=SimpleNamespace(cursor=1,end=1,stop=None,rows_written=0,account=account)
  @contextmanager
  def verify(**kw):yield SimpleNamespace(code_sha='0'*64)
  @contextmanager
  def admit(*a,**kw):yield sim,None,None
  keys=run_follow.WIRE_NAMES;blobs={k:b'{}' for k in keys};blobs['go']=c.canonical(dict(ordered_cells=[run_follow.claims.gate.source_entry.config.cells()[0]['cell_id']]))
  args=SimpleNamespace(cpu=7,cell_id=run_follow.claims.gate.source_entry.config.cells()[0]['cell_id'],case_output=str(self.directory),**{k.replace('-','_')+'_sha':'0'*64 for k in keys},preparation_sha='0'*64)
  with patch.object(r,'apply_limits'),patch.object(run_follow,'wires',return_value=(b'{}',{},blobs)),patch.object(run_follow,'worker_claim',return_value=b'{}'),patch.object(verified,'verify',verify),patch.object(run_follow,'load_saved_year',return_value=(object(),{})),patch.object(admission,'admit_case',admit),patch.object(native,'case_result',side_effect=error),patch.object(loader,'revoke'):
   with self.assertRaises(s.u.PublicationError) as caught:run_follow.case(args)
  self.assertIs(caught.exception,error);account.snapshot.assert_not_called();self.assertFalse((self.directory/'FAILED_ACCOUNT_FINANCIAL_AUDIT.json').exists())
  failure=c.exact_object((self.directory/'FAILURE.json').read_bytes());self.assertTrue(failure['storage_publication_uncertain']);self.assertEqual(failure['failure_classification'],'RESOURCE');self.assertFalse(failure['automatic_retry']);self.assertFalse(failure['economic_halt_relabelled'])
 def test_failure_evidence_budget_failure_cannot_mask_original(self):
  original=s.u.PublicationError('ORIGINAL')
  with patch.object(s,'budget',side_effect=s.u.ResourceStop('NO_SPACE',{})):
   self.assertFalse(r.record_case_failure(self.directory,original))
  self.assertFalse((self.directory/'FAILURE.json').exists());self.assertTrue(original.__notes__)
 def test_storage_read_errors_remain_non_economic_and_skip_snapshot_branch(self):
  for error in (s.u.StorageError('CORRUPT'),s.u.ResourceStop('STOP',{}),s.u.PublicationError('UNCERTAIN'),OSError('EIO')):
   with self.subTest(error=type(error).__name__):self.assertTrue(r.storage_failure(error))
 def test_pathological_failure_metadata_cannot_mask_original(self):
  class BadRepr(Exception):
   def __repr__(self):raise RuntimeError('GENERATED_BAD_REPR')
  error=BadRepr('ORIGINAL')
  self.assertFalse(r.record_case_failure(self.directory,error));self.assertFalse((self.directory/'FAILURE.json').exists())
  error=s.u.PublicationError('ORIGINAL');error.temporary_name=object()
  self.assertFalse(r.record_case_failure(self.directory,error));self.assertFalse((self.directory/'FAILURE.json').exists())
 def test_native40_and_existing_saved_reader_exact_equivalence(self):
  helper=importlib.import_module('test_runtime_json')
  fixtures=helper.invented_fixtures();original={n:r.body(v) for n,v in fixtures}
  checker=helper.source_module('generated_checker',helper.CHECKER);reader=helper.source_module('generated_saved_reader',helper.PACK/'saved_report.py')
  values=dict(fixtures);before=checker.reconcile_saved_native(values[s.BIG3[0]],values[s.BIG3[1]])
  for name,value in fixtures:r.save(self.directory/name,value)
  cp=self.checkpoint();saved=s.read_saved(self.directory,cp,expected_names=s.BIG3)
  self.assertEqual(saved,original)
  for name,value in fixtures:
   restored=reader.load(self.directory/name);self.assertEqual(restored,value);self.assertEqual(helper.shape(restored),helper.shape(value));self.assertGreater(helper.decimals(restored,value),0)
  after=checker.reconcile_saved_native(c.exact_object(saved[s.BIG3[0]]),c.exact_object(saved[s.BIG3[1]]))
  self.assertEqual(r.body(before),r.body(after));self.assertEqual(c.sha(r.body(after)),'4bd11d27ed580308867279ffe18b7d0211afa0ddcb345fc22caed16e112f45fc')
  changed=deepcopy(values[s.BIG3[0]]);changed['trades'][0]['decimal_strings']['fee_amount']='.05504400000000000000000000000000000000001'
  with self.assertRaises(ValueError):checker.reconcile_saved_native(changed,values[s.BIG3[1]])

if __name__=='__main__':unittest.main(verbosity=2)
