"""Reviewed big-three byte storage, explicit new checkpoint, legacy raw reader.

No financial objects are constructed here. Raw pins retain their old meaning.
The new storage record additionally binds the actual immutable physical file.
"""
from pathlib import Path
import importlib
import sys
import follow_native_common as c

UTILITY_ROOT=c.ROOT/'follow_lossless_runtime_json_20261016_v1'
UTILITY_SHA256='5fe710bc922ada9a1a46a1968100d67d65b94fc75ca04dde4d5f2a2811c4957c'
c.exact(UTILITY_ROOT/'runtime_json.py',UTILITY_SHA256)
if str(UTILITY_ROOT) not in sys.path:sys.path.insert(0,str(UTILITY_ROOT))
u=importlib.import_module('runtime_json')
if Path(u.__file__).resolve()!=UTILITY_ROOT/'runtime_json.py':raise u.StorageError('EXACT_REVIEWED_RUNTIME_JSON_MODULE_REQUIRED')
BIG3=('ACCOUNT_FINANCIAL_AUDIT.json','NATIVE_RESULT.json','GUARD_RECEIPTS.json')
SCHEMA='FOLLOW_NEXT6_2024_RAW_AND_STORED_TERMINAL_CHECKPOINT_V1'
LEGACY_SCHEMA='IMMUTABLE_MATRIX_TERMINAL_CHECKPOINT_V1'
CHECKPOINT_FIELDS={'schema','cell_id','files','checker_SHA256','reconstruction_proof_SHA256','all_evidence_fsynced','restart_financial_snapshot_permission','fresh_scope_revoked','scope_manifest_SHA256','storage_policy_SHA256','storage'}
LEGACY_FIELDS=CHECKPOINT_FIELDS-{'scope_manifest_SHA256','storage_policy_SHA256','storage'}

def policy_sha():return c.sha(c.ordinary(c.HERE/'STORAGE_POLICY.json'))

def policy():
    p=c.exact_object(c.ordinary(c.HERE/'STORAGE_POLICY.json'))
    if p['utility_SHA256']!=UTILITY_SHA256 or p['logical_names']!=list(BIG3):raise u.StorageError('EXACT_BIG3_STORAGE_POLICY_REQUIRED')
    return p

def budget(directory):
    import follow_process_runtime as r
    directory=Path(directory).absolute();cohort=directory.parent
    # Case/cohort/writer must share the actual filesystem observed by this
    # reviewed utility callback; a cross-device tree cannot borrow free space.
    if directory.stat().st_dev!=cohort.stat().st_dev:raise u.StorageError('SAME_FILESYSTEM_CASE_COHORT_WRITER_REQUIRED')
    return u.DiskBudget(str(cohort),str(directory),minimum_free_bytes=r.COHORT_DISK_POLICY['minimum_free_bytes'],maximum_cohort_bytes=r.COHORT_DISK_POLICY['maximum_cohort_output_log_temporary_bytes'],maximum_case_bytes=r.LIMITS['per_case_output_bytes'])

def limits():
    import follow_process_runtime as r
    return u.Limits(maximum_raw_bytes=r.LIMITS['per_case_output_bytes'],maximum_stored_bytes=r.LIMITS['per_case_output_bytes'])

def write(directory,name,raw):
    if name not in BIG3:raise u.StorageError('ONLY_BIG3_GZIP_SERIALIZATION_ALLOWED')
    try:return u.write_json_bytes(str(Path(directory).absolute()),name,raw,encoding='gzip6',budget=budget(directory),limits=limits())
    except BaseException as error:
        error.failure_classification='RESOURCE' if isinstance(error,(u.ResourceStop,u.PublicationError,OSError)) else 'DATA_STORAGE_VALIDATION'
        error.economic_halt=False
        if isinstance(error,u.PublicationError):error.storage_publication_uncertain=True
        raise

def read(directory,name,expected_sha256,*,receipt=None,expected_bytes=None):
    if name not in BIG3:raise u.StorageError('ONLY_BIG3_STORAGE_READER_ALLOWED')
    return u.read_exact(str(Path(directory).absolute()),name,expected_sha256,expected_bytes=expected_bytes,receipt=receipt,limits=limits())

def validate_checkpoint(checkpoint,*,expected_names):
    names=tuple(expected_names)
    if (len(names)!=len(set(names)) or not set(BIG3)<=set(names) or type(checkpoint) is not dict or set(checkpoint)!=CHECKPOINT_FIELDS
            or checkpoint['schema']!=SCHEMA or checkpoint['scope_manifest_SHA256']!=c.SCOPE_SHA
            or checkpoint['storage_policy_SHA256']!=policy_sha() or type(checkpoint['files']) is not dict
            or set(checkpoint['files'])!=set(names) or type(checkpoint['storage']) is not dict or set(checkpoint['storage'])!=set(BIG3)
            or checkpoint['all_evidence_fsynced'] is not True or checkpoint['restart_financial_snapshot_permission'] is not False
            or checkpoint['fresh_scope_revoked'] is not True):raise u.StorageError('EXACT_NEW_RAW_AND_STORED_CHECKPOINT_NAMESPACE_REQUIRED')
    for name,digest in checkpoint['files'].items():
        c.digest(digest)
        if name in BIG3:
            rec=checkpoint['storage'][name];u._check_receipt(rec,name)
            if rec['encoding']!='gzip6' or rec['raw']['SHA256']!=digest:raise u.StorageError('EXACT_RAW_AND_GZIP_STORED_CHECKPOINT_PINS_REQUIRED')
    return checkpoint

def _physical_namespace(directory,names,*,compressed):
    directory=Path(directory)
    physical={name+('.gz' if compressed and name in BIG3 else '') for name in names}
    # A successful terminal case consists only of its declared terminal files
    # plus its terminal checkpoint. Logs live in the parent cohort directory.
    actual={p.name for p in directory.iterdir()}
    allowed=physical|{'TERMINAL_CHECKPOINT.json'}
    if actual!=physical and actual!=allowed:raise u.StorageError('EXACT_TERMINAL_PHYSICAL_FILE_NAMESPACE_REQUIRED')

def read_saved(directory,checkpoint,*,expected_names):
    validate_checkpoint(checkpoint,expected_names=expected_names)
    _physical_namespace(directory,expected_names,compressed=True)
    result={}
    for name,digest in checkpoint['files'].items():
        if name in BIG3:result[name]=read(directory,name,digest,receipt=checkpoint['storage'][name])
        else:result[name]=c.exact(Path(directory)/name,digest)
    return result

def read_legacy_raw_checkpoint(directory,checkpoint,*,expected_names):
    """Explicit old-schema/raw-only compatibility; never accepts new storage."""
    names=tuple(expected_names)
    if (type(checkpoint) is not dict or set(checkpoint)!=LEGACY_FIELDS or checkpoint.get('schema')!=LEGACY_SCHEMA
            or type(checkpoint.get('files')) is not dict or set(checkpoint['files'])!=set(names)
            or checkpoint.get('all_evidence_fsynced') is not True or checkpoint.get('restart_financial_snapshot_permission') is not False
            or checkpoint.get('fresh_scope_revoked') is not True):raise u.StorageError('EXACT_LEGACY_RAW_CHECKPOINT_REQUIRED')
    _physical_namespace(directory,names,compressed=False)
    saved={}
    for name,digest in checkpoint['files'].items():
        if name in BIG3:saved[name]=u.read_exact(str(Path(directory).absolute()),name,digest,limits=limits())
        else:saved[name]=c.exact(Path(directory)/name,digest)
    return saved

def write_checkpoint(directory,name,raw):
    if name!='TERMINAL_CHECKPOINT.json':raise u.StorageError('EXACT_TERMINAL_CHECKPOINT_NAME_REQUIRED')
    # The checkpoint is intentionally raw. It is immutable, fully fsynced and
    # monitored with exactly the same prospective physical-write accounting.
    try:return u.write_json_bytes(str(Path(directory).absolute()),name,raw,encoding='raw',budget=budget(directory),limits=limits())
    except BaseException as error:
        error.failure_classification='RESOURCE' if isinstance(error,(u.ResourceStop,u.PublicationError,OSError)) else 'DATA_STORAGE_VALIDATION'
        error.economic_halt=False
        if isinstance(error,u.PublicationError):error.storage_publication_uncertain=True
        raise
