"""Finite frozen 2024 generic source decoder; no capability minted here."""
from follow_transport import load as _load
_load('follow_native_source2024',globals())
