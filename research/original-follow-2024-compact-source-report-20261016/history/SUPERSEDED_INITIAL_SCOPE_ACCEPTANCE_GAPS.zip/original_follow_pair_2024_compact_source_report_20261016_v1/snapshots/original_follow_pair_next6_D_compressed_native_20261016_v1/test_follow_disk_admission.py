"""Generated disk boundary and no-claim/no-launch full-cap admission proofs."""
import ast,io,sys,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import follow_process_runtime as r
import follow_native_common as c
import run_follow
class FullCohortDiskTests(unittest.TestCase):
 def test_exact_base_reserve_retained_floor_and_cap(self):
  p=r.COHORT_DISK_POLICY
  self.assertEqual(p['base_free_floor_bytes'],1610612736);self.assertEqual(p['reserved_publication_bytes'],0)
  self.assertEqual(p['minimum_free_bytes'],1610612736);self.assertEqual(p['maximum_cohort_output_log_temporary_bytes'],600000000)
  self.assertEqual(p['base_free_floor_bytes']+p['reserved_publication_bytes'],p['minimum_free_bytes'])
 def test_full_cap_exact_fresh_boundary_and_one_byte_deficit(self):
  with tempfile.TemporaryDirectory(prefix='GENERATED_FULL_CAP_') as td:
   output=Path(td)/'absent';need=2210612736
   with patch.object(r.os,'statvfs',return_value=SimpleNamespace(f_bavail=need,f_frsize=1)):
    value=r.check_full_cohort_budget(output);self.assertEqual(value['required_fresh_free_bytes'],need);self.assertEqual(value['retained_free_after_full_cap_bytes'],1610612736)
   for free in (need-1,1610612736,1610612736):
    with self.subTest(free=free),patch.object(r.os,'statvfs',return_value=SimpleNamespace(f_bavail=free,f_frsize=1)):
     with self.assertRaisesRegex(r.CohortDiskResourceStop,'FULL_COHORT_CAPACITY'):r.check_full_cohort_budget(output)
   self.assertFalse(output.exists())
 def test_remaining_not_double_spent_cap_boundary(self):
  with tempfile.TemporaryDirectory(prefix='GENERATED_REMAINING_CAP_') as td:
   output=Path(td);used=400000000;need=1810612736
   with patch.object(r,'own_bytes',return_value=used),patch.object(r.os,'statvfs',return_value=SimpleNamespace(f_bavail=need,f_frsize=1)):
    value=r.check_full_cohort_budget(output);self.assertEqual(value['remaining_full_cohort_cap_bytes'],200000000)
   with patch.object(r,'own_bytes',return_value=used),patch.object(r.os,'statvfs',return_value=SimpleNamespace(f_bavail=need-1,f_frsize=1)):
    with self.assertRaises(r.CohortDiskResourceStop):r.check_full_cohort_budget(output)
 def test_controller_deficient_budget_stops_before_output_leases_claims_workers(self):
  with tempfile.TemporaryDirectory(prefix='GENERATED_NO_DEFICIENT_LAUNCH_') as td:
   output=Path(td)/'absent'
   with patch.object(r.os,'statvfs',return_value=SimpleNamespace(f_bavail=2210612735,f_frsize=1)),patch.object(run_follow,'_frozen_controller') as controller:
    with self.assertRaises(r.CohortDiskResourceStop):run_follow.controller(SimpleNamespace(output=str(output)))
    controller.assert_not_called();self.assertFalse(output.exists())
 def test_initial_full_budget_then_unchanged_pointwise_launch_checks(self):
  directory=c.ROOT/'cs_saved_minute_reporting_repair_20261015_v2'
  if str(directory) not in sys.path:sys.path.insert(0,str(directory))
  import bounded_drain
  with tempfile.TemporaryDirectory(prefix='GENERATED_FULL_CAP_HOOKS_') as td:
   output=Path(td);events=[]
   def budget(*a,**kw):events.append('budget');return {'generated':True}
   def claim(*a,**kw):events.append('claim')
   def drive(*a,**kw):kw['before_launch']('GENERATED',output/'case',7);return {}
   with patch.object(r,'check_full_cohort_budget',side_effect=budget),patch.object(r,'check_cohort_disk',return_value={'free_bytes':10000000000,'cohort_output_log_temporary_bytes':0}),patch.object(r,'save_cohort_controller') as saved,patch.object(bounded_drain,'run_pool',side_effect=drive):
    r.run_pool([],output,requested_workers=2,cpus=[4,5],validator=lambda *a:None,before_launch=claim)
   self.assertEqual(events,['budget','claim']);self.assertEqual(saved.call_count,0)
 def test_frozen_terminal_math_and_resource_limits_unchanged(self):
  def functions(path):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(path.read_bytes()).body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
  old=functions(c.ROOT/'original_follow_pair_first6_D_native_20261016_v2/follow_process_runtime.py');new=functions(c.HERE/'follow_process_runtime.py')
  for name in ('classify_terminal','apply_limits','choose_worker_count','environment','process_observation','cpu_envelope'):
   with self.subTest(name=name):self.assertEqual(old[name],new[name])
if __name__=='__main__':unittest.main(verbosity=2)
