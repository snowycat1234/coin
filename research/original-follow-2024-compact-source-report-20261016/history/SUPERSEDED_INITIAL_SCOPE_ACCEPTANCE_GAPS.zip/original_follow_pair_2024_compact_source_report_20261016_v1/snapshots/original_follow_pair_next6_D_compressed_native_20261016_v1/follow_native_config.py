"""Fixed six-cell 2024 native execution descriptor; other periods stay closed."""
from types import MappingProxyType
import follow_native_bootstrap
import follow_config as source
import follow_native_common as c
VERSION=source.VERSION
CANDIDATE=source.CANDIDATE
RECIPES=source.RECIPES
SYMBOLS=source.SYMBOLS
TIERS=source.TIERS
DAY=source.DAY
utc=source.utc
TIER_BUDGETS=MappingProxyType(dict(LOW=.05,MID=.10,HIGH=.15))
TIER_GROSS_CAPS=MappingProxyType(dict(LOW=.3,MID=.6,HIGH=.9))
def cells():return tuple(source.cells()[6:12])
def cell_named(cell_id):
 for cell in cells():
  if cell['cell_id']==cell_id:return cell
 raise ValueError('ONLY_FIXED_NEXT6_2024_FOLLOW_CELLS')
def source_year(year):
 if type(year) is not int or year!=2024:raise ValueError('ONLY_2024_NEXT6_NATIVE_SOURCE_ALLOWED')
 return dict(source.source_year(year),warmup_start=source.source_year(year)['start']-199*DAY)
period_named=source_year
