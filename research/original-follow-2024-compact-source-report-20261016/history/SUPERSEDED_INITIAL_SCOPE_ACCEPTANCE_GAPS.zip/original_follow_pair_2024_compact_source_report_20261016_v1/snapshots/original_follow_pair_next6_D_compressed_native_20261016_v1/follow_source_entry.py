"""Exact audited FOLLOW metadata, projected to fixed next6 execution only."""
import follow_native_bootstrap
import follow_native_common as c
import follow_native_config as config
import follow_entry as original
NEXT6='NEXT6_2024_FOLLOW_PAIR_CURRENT_D'
PREPARATION_SHA256='231c0ac6b01dd5aab924ee70976c7349317037f0af51c89df12f6269ac808bff'
SOURCE_CODE_SHA256='96791b8573a9b0d8331d3ff92cceb0016b2294b44497be4e510953cb2c025fb4'
SOURCE_GO_SHA256='c0ee725d02cb5df3b3553c70c056381b451fdc9f6bf0a4db07c88f86cc20e22a'
SOURCE_REVIEW_SHA256='e678f47f5bbacc8e8dcab14e760439507deb9ada79bcae5f4e352be13f603827'
_ACTIVE_SOURCE=original._ACTIVE_SOURCE

def tranche_cells(tranche):
 if tranche!=NEXT6:raise ValueError('ONLY_FIXED_NEXT6_FOLLOW_NATIVE_TRANCHE')
 return tuple(x['cell_id'] for x in config.cells())
def tranche_years(tranche):tranche_cells(tranche);return (2024,)
def manifest_sha():
 raw=c.exact(c.HERE/'FROZEN_SIX_CELL_MANIFEST.json',c.SCOPE_SHA)
 if c.exact_object(raw)['cells']!=list(config.cells()):raise ValueError('EXACT_NEXT6_MANIFEST_REQUIRED')
 return c.sha(raw)
def descriptor():
 return c.exact_object(c.ordinary(c.HERE/'NATIVE_SOURCE_DESCRIPTOR.json'))
def contracts():return {'years':{'2024':{'qualified_source_contract':descriptor()['qualified_source_contract'],'read_files':descriptor()['qualified_source_contract']['read_files']}}}
def contract_sha():return c.sha(c.ordinary(c.HERE/'NATIVE_SOURCE_DESCRIPTOR.json'))
def code_identity():
 if original.code_identity()!=SOURCE_CODE_SHA256:raise ValueError('FROZEN_FOLLOW_SOURCE_CODE_CHANGED')
 return SOURCE_CODE_SHA256
array_specs=original.array_specs

def validate_source_authority_metadata(go_raw,go_sha,review_raw,review_sha):
 if go_sha!=SOURCE_GO_SHA256 or review_sha!=SOURCE_REVIEW_SHA256:raise ValueError('EXACT_FOLLOW_SOURCE_LINEAGE_REQUIRED')
 return original.validate_source_authority_metadata(go_raw,go_sha,review_raw,review_sha)

def validate_preparation_metadata(raw):
 if c.sha(raw)!=PREPARATION_SHA256:raise ValueError('EXACT_INDEPENDENTLY_AUDITED_ALL30_PREPARATION_BYTES_REQUIRED')
 p=c.exact_object(raw)
 if (p['source_stage_GO_SHA256']!=SOURCE_GO_SHA256 or p['source_review_SHA256']!=SOURCE_REVIEW_SHA256 or p['code_manifest_SHA256']!=SOURCE_CODE_SHA256
     or tuple(p['ordered_cells'][6:12])!=tranche_cells(NEXT6) or p['financial_runs']!=0 or p['historical_admission'] is not False):
  raise ValueError('EXACT_SOURCE_ONLY_ALL30_LINEAGE_REQUIRED')
 # This derived read view grants access to 2024 artifacts only. Original raw
 # PREPARATION and its independent audit retain and bind all30 metadata.
 p['ordered_cells']=list(tranche_cells(NEXT6));p['tranche']=NEXT6
 p['cells']={k:p['cells'][k] for k in p['ordered_cells']}
 p['years']={'2024':dict(p['years']['2024'],**descriptor()['source_metadata'])}
 p['artifacts']={k:v for k,v in p['artifacts'].items() if k.startswith('2024/') or k in ('SOURCE_STAGE_AUTHORIZATION.json','SOURCE_INDEPENDENT_REVIEW.json')}
 return p
