"""One-use immutable metadata admission, verified before the unchanged guard.

This is a finite reviewed worker-graph capability, not a Python sandbox or a
historical/source scope. No generated flag, callback, or public seal is accepted.
"""
from contextlib import contextmanager
from dataclasses import dataclass, field
from types import MappingProxyType

import follow_native_bootstrap
import follow_native_common as c
import follow_native_config as config
import follow_source_entry as entry
import follow_finance_gate as gate

_SEAL = object()
_LIVE = {}


@dataclass(frozen=True, slots=True)
class VerifiedWires:
    cell_id: str
    preparation_raw: bytes = field(repr=False)
    raw: object = field(repr=False)
    hashes: object = field(repr=False)
    code_sha: str
    claim_raw: bytes = field(repr=False)
    claim_sha: str
    _token: object = field(repr=False)
    _seal: object = field(repr=False)

    def __post_init__(self):
        if self._seal is not _SEAL:
            raise ValueError('INTERNALLY_VERIFIED_IMMUTABLE_WIRES_REQUIRED')

    def consume(self, *, preparation_raw, year, supplied):
        record = _LIVE.get(self._token)
        if record is None or record[0] is not self or record[1] != 'OPEN' or self._seal is not _SEAL:
            if record is not None and record[0] is self:
                _LIVE.pop(self._token, None)
            raise ValueError('LIVE_UNUSED_VERIFIED_WIRES_REQUIRED')
        try:
            if (type(year) is not int or config.cell_named(self.cell_id)['year'] != year
                    or type(preparation_raw) is not bytes or preparation_raw != self.preparation_raw
                    or gate.code_identity() != self.code_sha or type(supplied) is not dict
                    or set(supplied) != set(self.raw)
                    or any(type(supplied[k]) is not bytes or supplied[k] != self.raw[k]
                           or c.sha(supplied[k]) != self.hashes[k] for k in supplied)):
                _LIVE.pop(self._token, None)
                raise ValueError('EXACT_PREVERIFIED_YEAR_CODE_PREPARATION_AND_WIRE_BYTES_REQUIRED')
            if (c.sha(self.claim_raw) != self.claim_sha or c.exact_object(self.claim_raw).get('cell_id') != self.cell_id):
                raise ValueError('EXACT_VERIFIED_WORKER_CLAIM_BYTES_REQUIRED')
        except BaseException:
            _LIVE.pop(self._token, None)
            raise
        _LIVE[self._token] = (self, 'CONSUMED')
        return self.hashes['go']


def exact_preparation_shape(preparation_raw):
    # Frozen source validator already enforces every wrapper, year, artifact,
    # array descriptor, recipe, calendar and tier keyset exactly.
    return entry.validate_preparation_metadata(preparation_raw)


@contextmanager
def verify(*, preparation_raw, cell_id, raw, hashes, claim_raw):
    from follow_native_source_guard import current_guard
    if current_guard() is not None:
        raise ValueError('FINANCIAL_WIRE_VALIDATION_MUST_PRECEDE_SOURCE_GUARD')
    if (type(preparation_raw) is not bytes or type(raw) is not dict or type(hashes) is not dict
            or set(raw) != {'go', 'review', 'prepared-review', 'native-review', 'source-go', 'source-review'}
            or set(raw) != set(hashes) or any(type(v) is not bytes for v in raw.values())
            or any(c.sha(raw[k]) != c.digest(hashes[k]) for k in raw)):
        raise ValueError('EXACT_EXTERNALLY_HASHED_IMMUTABLE_WIRES_REQUIRED')
    prep = exact_preparation_shape(preparation_raw)
    if (tuple(prep['ordered_cells']) != entry.tranche_cells(entry.NEXT6)
            or set(prep['years']) != {'2024'} or cell_id not in prep['ordered_cells']):
        raise ValueError('EXACT_PREPARED_CELL_REQUIRED')
    entry.validate_source_authority_metadata(raw['source-go'], hashes['source-go'], raw['source-review'], hashes['source-review'])
    gate.validate(preparation_raw, raw['go'], hashes['go'], raw['review'], hashes['review'],
                  raw['prepared-review'], hashes['prepared-review'], raw['native-review'], hashes['native-review'])
    if (prep['source_stage_GO_SHA256'] != hashes['source-go'] or prep['source_review_SHA256'] != hashes['source-review']):
        raise ValueError('EXACT_VERIFIED_SOURCE_LINEAGE_REQUIRED')
    code_sha = gate.code_identity()
    claim = c.exact_object(claim_raw)
    if (claim.get('cell_id') != cell_id or claim.get('root_GO_SHA256') != hashes['go']
            or claim.get('preparation_SHA256') != c.sha(preparation_raw) or claim.get('code_identity') != code_sha):
        raise ValueError('EXACT_VERIFIED_WORKER_CLAIM_CELL_GO_PREPARATION_CODE_REQUIRED')
    if any(v[0].cell_id == cell_id or v[0].claim_sha == c.sha(claim_raw) for v in _LIVE.values()):
        raise ValueError('CONFLICTING_LIVE_VERIFIED_CELL_OR_CLAIM_BINDING')
    token = object()
    value = VerifiedWires(cell_id, preparation_raw, MappingProxyType(dict(raw)), MappingProxyType(dict(hashes)),
                          code_sha, claim_raw, c.sha(claim_raw), token, _SEAL)
    _LIVE[token] = (value, 'OPEN')
    try:
        yield value
    finally:
        _LIVE.pop(token, None)


def consume(value, **kwargs):
    if type(value) is not VerifiedWires:
        raise ValueError('EXACT_SEALED_PREVERIFIED_FINANCIAL_WIRES_REQUIRED')
    return value.consume(**kwargs)


def require_consumed(value,*,year):
    """Native-source-only lifetime check; no authority body is serialized."""
    record=_LIVE.get(getattr(value,'_token',None))
    if (type(value) is not VerifiedWires or record is None or record[0] is not value
            or record[1]!='CONSUMED' or value._seal is not _SEAL
            or type(year) is not int or config.cell_named(value.cell_id)['year']!=year
            or gate.code_identity()!=value.code_sha):
        raise ValueError('LIVE_CONSUMED_EXACT_FINANCIAL_WIRE_NATIVE_SOURCE_BINDING_REQUIRED')
    return True
