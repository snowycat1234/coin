"""Frozen saved validator with explicit new storage checkpoint seam."""
from follow_transport import load as _load
_load('follow_saved',globals())
