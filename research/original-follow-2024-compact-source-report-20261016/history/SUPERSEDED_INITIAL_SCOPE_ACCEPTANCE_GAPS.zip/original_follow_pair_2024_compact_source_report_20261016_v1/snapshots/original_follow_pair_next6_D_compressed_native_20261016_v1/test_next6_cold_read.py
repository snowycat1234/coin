"""Cold children never construct/predecode their fixtures or native capture."""
import json,os,subprocess,sys,tempfile,unittest
from pathlib import Path
from generated_next6_cold_read_regression import parent_fixture,generated_fixture_root
HERE=Path(__file__).resolve().parent
class ColdReadTests(unittest.TestCase):
 def test_real_target_npz_native_capture_and_prefix_in_cold_process(self):
  with tempfile.TemporaryDirectory(prefix='GENERATED_COLD_',dir=generated_fixture_root()) as tmp:
   root=Path(tmp)/'generated';parent_fixture(root)
   for version in ('v1',):
    command=[sys.executable,'-B']+(['-O'] if sys.flags.optimize else [])+[str(HERE/'generated_next6_cold_read_regression.py'),'--child',str(root),version]
    p=subprocess.run(command,capture_output=True,text=True,timeout=120)
    with self.subTest(version=version):
     self.assertEqual(p.returncode,0,p.stderr+'\n'+p.stdout[-1000:]);r=json.loads(p.stdout)
     self.assertFalse(r['cp437_preloaded_before_production_entry']);self.assertTrue(r['scopes_revoked']);self.assertFalse(r['finance_modules_imported'])
     self.assertTrue(r['all27_arrays_and_prefix_bits_checked']);self.assertTrue(r['real_canonical_source_reads_observed'])
     self.assertTrue(r['causal_adapter_unprimed_before_entry']);self.assertTrue(r['qualified_2024_derived_policy_preserved']);self.assertEqual(r['full_original_prefix_rows'],1826)
     self.assertEqual(r['real_function_call_counts']['causal_project'],dict(before_guard=0,inside_guard=12))
if __name__=='__main__':unittest.main(verbosity=2)
