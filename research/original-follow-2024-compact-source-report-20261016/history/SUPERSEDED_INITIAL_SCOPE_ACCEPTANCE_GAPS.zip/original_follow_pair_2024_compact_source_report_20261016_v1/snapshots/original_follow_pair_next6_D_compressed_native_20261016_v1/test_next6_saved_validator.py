"""Full projected saved validator over invented gzip/native40 terminal evidence.

Only authority, preparation, claim and lease metadata paths are substituted.
Financial reconciliation, account contract, terminal taxonomy, minute decoding,
all27 identities, risk recomputation, quality and resource validation stay real.
No account, provider, source capability or historical execution is constructed.
"""
from copy import deepcopy
from dataclasses import fields
from decimal import Decimal
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import importlib,tempfile,unittest
import numpy as np
import follow_native_common as c
import follow_native_config as config
import follow_native_signal as signal
import follow_source_entry as entry
import follow_finance_gate as gate
import follow_process_runtime as r
import follow_storage as storage
import follow_saved as saved
import follow_native as native
import run_follow as run
from generated_next6_cold_read_regression import _pack,generated_fixture_root,generated_cpu

class FullSavedValidatorTests(unittest.TestCase):
 def test_real_projected_saved_terminal_with_invented_full_calendar_gzip(self):
  generated_cpu()
  with tempfile.TemporaryDirectory(prefix='GENERATED_FULL_SAVED_',dir=generated_fixture_root()) as temp:
   root=Path(temp);directory=root/'CASE';directory.mkdir();preparation=root/'PREPARATION';(preparation/'2024').mkdir(parents=True)
   helper=importlib.import_module('test_runtime_json');values=dict(helper.invented_fixtures())
   audit=values['ACCOUNT_FINANCIAL_AUDIT.json'];result=values['NATIVE_RESULT.json'];receipts=values['GUARD_RECEIPTS.json']['receipts']
   cell=config.cells()[0];cell_id=cell['cell_id'];tier=cell['tier'];year=2024;calendar=[cell['start_us'],cell['end_exclusive_us']];minutes=366*1440
   cfg=native.V2.ENGINE.PerpetualConfig(initial_cash='10000',max_gross_weight=str(config.TIER_GROSS_CAPS[tier]),max_asset_weight='.30',leverage='1',half_spread_bps='4',slippage_bps='4')
   audit['config']={f.name:str(getattr(cfg,f.name)) for f in fields(cfg)}
   profile=c.exact_object(c.exact(c.ROOT/'bounded_account_continuation_20261015/QUANTITY_PROFILE.json','94b2238b25ed345a24a1fa148c6f35523b8efe9bf47496958028844432cb8ebf'))
   profiles={symbol:native.V2.ENGINE.InstrumentProfile(quantity_step=profile['rows'][symbol]['quantity_step'],min_notional='10').metadata() for symbol in native.S}
   audit.update(instrument_profiles=profiles,closing_min_notional_exempt=True,cost_context=None,bound_nominal_tier=tier,historical_execution_admitted=True,continuation_policy=native.VERSION)
   audit['contract'].update(symbols=list(native.S),bound_nominal_tier=tier,free_cash_floor='1000',total_isolated_ceiling='8500',leverage=1,nominal_roundtrip_bps=27.,taker_fee_bps_per_side=5.5,topup_enabled=False,policy_variant='GUARD50_EXIT_ONLY',quantity_profile_binding='FROZEN_COARSE_RESEARCH_PROFILE',historical_execution_admitted=True,generated_only=False,closing_min_notional_exempt=True,instrument_profiles=profiles,continuation_policy=native.VERSION)
   result['common_execution_policy']=dict(tier=tier,gross_ceiling=config.TIER_GROSS_CAPS[tier],asset_ceiling=.30,annual_covariance_volatility_ceiling=config.TIER_BUDGETS[tier],initial_cash='10000',free_cash_increase_floor='1000',actual_isolated_margin_ceiling='8500',automatic_topup=False,policy_variant='GUARD50_EXIT_ONLY',historical_execution_admitted=True)
   for rows in (audit['trades'],audit['funding'],audit['financial_ledger'],result['trades'],result['funding']):
    for row in rows:
     for key in ('event_us','signal_us','rate_available_us','mark_close_us'):
      if key in row:row[key]+=calendar[0]
   for history in audit['marks'].values():
    for row in history:row['close_us']+=calendar[0]
   result['summary'].update(completed_minutes=minutes,stop_us=None,NAV=9999.63,free_cash=9999.63,isolated_balance=0.,gross_weight=0.)
   net_return=float(Decimal('9999.630000')/Decimal('10000')-1)
   result['economics'].update(full_calendar=True,paid_flat=True,actual_paid_market_flat=True,conditional_settled_flat=False,comparable_full_calendar_return=net_return,paid_net_return=net_return,conditional_model_net_return=None)
   result['primary_financial_reconciliation']={'generated_raw100_legacy_report':True}
   sidecar=dict(year=2024,cells=[],qualified_source_identity='f'*64,arrival_status='UNKNOWN_NOT_CERTIFIED',original_source_age_and_arrival_flags_preserved=True,actual_CS_event_impacts='PENDING_CS_SAVED_EXECUTION',actual_CS_position_interval_impacts='PENDING_CS_SAVED_EXECUTION_NOT_INHERITED_FROM_D',quality_intervals=[[1723456980000000,1723457100000000,list(native.S)]],derived_mark_cells=10)
   sidecar_raw=r.body(sidecar)
   arrays={key:np.zeros(shape,dtype=dtype) for key,(shape,dtype) in entry.array_specs(year).items()};arrays['decision_us']=np.arange(calendar[0],calendar[1],config.DAY,dtype=np.int64)
   target_raw=_pack(**arrays);(preparation/'2024/TARGETS.npz').write_bytes(target_raw)
   year_info=dict(source_identity='f'*64,source_quality_sidecar_SHA256=c.sha(sidecar_raw),quality_cells_SHA256=c.jsha([]),array_identities={key:signal.array_byte_identity(value) for key,value in arrays.items()})
   prep=dict(years={'2024':year_info},cells={cell_id:dict(input_binding_SHA256='e'*64)},artifacts={'2024/TARGETS.npz':dict(SHA256=c.sha(target_raw),bytes=len(target_raw))});prep_raw=r.body(dict(generated_only=True))
   blobs={key:r.body(dict(generated_wire=key)) for key in run.WIRE_NAMES}
   args=SimpleNamespace(preparation=str(preparation),**{key.replace('-','_')+'_sha':c.sha(raw) for key,raw in blobs.items()})
   code=gate.code_identity();checker=importlib.import_module('saved_native_reconciliation')
   receipt=dict(schema='FINITE_ORIGINAL_FOLLOW_NEXT6_ORIGINAL_D_CASE_V1',cell_id=cell_id,year=year,strategy=cell['recipe'],tier=tier,config=cell['recipe']+'_'+tier,calendar=calendar,cost='BASE27',policy_variant=native.POLICY_VARIANT,adaptive_DEV_only=True,root_GO_SHA256=args.go_sha,independent_review_SHA256=args.review_sha,prepared_source_target_review_SHA256=args.prepared_review_sha,native_generated_review_SHA256=args.native_review_sha,preparation_SHA256=c.sha(prep_raw),scope_manifest_SHA256=run.SCOPE_SHA,source_identity='f'*64,source_code_manifest_SHA256=gate.SOURCE_CODE_SHA256,financial_code_manifest_SHA256=code,input_binding_SHA256='e'*64,checker_SHA256=checker.checker_sha256(),required_minutes=minutes,limits=r.LIMITS,no_halt_reset=True,snapshot_restart_certified=False,automatic_retry=False,native_exchange_or_funding_publication_certified=False,locked_source_reads=0,publication_actions=0,status='FULL_CALENDAR_ACTUAL_PAID_MARKET_FLAT',completed_minutes=minutes,account_stop_us=None,requested_CPU=4,PID=12345,controller_PID=12344,process_start_ticks='56789',actual_CPU_affinity=[4],all_TID_affinities=[[4]],thread_environment={key:'1' for key in r.THREAD_ENV},total_wall_seconds=1.,CPU_seconds=1.,max_RSS_bytes=1000000)
   binding={key:receipt[key] for key in ('cell_id','year','strategy','config','preparation_SHA256','source_identity','root_GO_SHA256','independent_review_SHA256','policy_variant','source_code_manifest_SHA256','financial_code_manifest_SHA256','input_binding_SHA256','prepared_source_target_review_SHA256','native_generated_review_SHA256')};binding.update(quality_sidecar_sha256=c.sha(sidecar_raw),quality_intervals=sidecar['quality_intervals'])
   audit['historical_execution_scope']=binding;audit['contract']['scope_binding']=binding
   quality_identity=saved.quality_identity(sidecar,year_info,native.V2.quality_module.VERSION);quality_sha=c.jsha(quality_identity)
   result['target_meta']=dict(mark_quality_policy_identity=quality_sha,mark_quality_guard_version=native.V2.quality_module.VERSION)
   proof=checker.reconcile_saved_native(audit,result,expected_continuation_version=native.VERSION);receipt['reconstruction_proof_SHA256']=c.sha(r.body(proof))
   columns=['close_us','nav','free_cash','isolated_balance','gross_weight']+[symbol+'_signed_weight' for symbol in native.S]
   matrix=np.zeros((minutes,len(columns)),dtype=np.float64);matrix[:,0]=calendar[0]+np.arange(1,minutes+1,dtype=np.int64)*60_000_000;matrix[:,1:3]=9999.63
   minute_raw=_pack(values=matrix,columns=np.array(columns));risk=run.held_risk(matrix,columns,SimpleNamespace(arrays=arrays),tier,receipts,cell['recipe'])
   del matrix
   from follow_native_source_guard import SourceOnlyGuard
   zeros={key:0 for key in SourceOnlyGuard.CATEGORIES}
   guard=dict(schema='OBSERVED_FOLLOW_PAIR_INTRINSIC_SOURCE_GUARD_V1',status='PASS_FINANCIAL_WORKER_SOURCE_ONLY_RECAPTURE',forbidden_attempts=zeros,error=None,attempted_targets=[],guard_active=False,historical_execution_authorized=False,financial_execution_authorized=False,source_scopes_revoked=True,native_source_scopes_revoked=True,saved_targets_and_covariance_rebuilt=False,checkpoints=[dict(label=label,attempts=zeros) for label in ('FRESH_WORKER_FOLLOW_NEXT6_SOURCE_RECAPTURE_BEFORE_FINANCE_IMPORT','EXACT_SAVED_FOLLOW_NEXT6_TARGETS_LOADED_WITHOUT_REGENERATION')],observed_workspace_read_paths={'GENERATED_SOURCE_BYTES_ONLY':1})
   guard_raw=r.body(guard);registry=root/'GENERATED_REGISTRY';(registry/run.SCOPE_SHA).mkdir(parents=True);lease=registry/run.SCOPE_SHA/'CONTROLLER_LEASE.lock';lease.write_bytes(b'GENERATED_METADATA_ONLY');shared=root/'GENERATED_SHARED_LEASE.lock';shared.write_bytes(b'GENERATED_METADATA_ONLY')
   receipt.update(controller_lease_inode=lease.stat().st_ino,shared_CPU45_lease_inode=shared.stat().st_ino)
   claim=dict(generated_metadata_only=True,controller_PID=receipt['controller_PID'],controller_output=str(directory.parent));claim_raw=r.body(claim);claim_path=root/'GENERATED_CLAIM_METADATA.json';claim_path.write_bytes(claim_raw)
   phase_fixed=dict(schema='FOLLOW_NEXT6_WORKER_PREFINANCE_PHASE_V1',cell_id=cell_id,root_GO_SHA256=args.go_sha,preparation_SHA256=c.sha(prep_raw),PID=receipt['PID'],historical_scopes_constructed=0,providers_constructed=0,accounts_constructed=0,UTC='2026-10-16T00:00:00+00:00')
   first=dict(phase_fixed,phase='EXACT_EXECUTABLE_GO_VERIFIED_OUTSIDE_UNCHANGED_SOURCE_GUARD',financial_code_manifest_SHA256=code,claim_SHA256=c.sha(claim_raw),source_capture_started=False);second=dict(phase_fixed,phase='SOURCE_RECAPTURE_AND_SAVED_TARGET_BINDING_ACCEPTED_GUARD_EXITED',source_guard_receipt_SHA256=c.sha(guard_raw),verified_wires_revoked=True)
   bootstrap=dict(schema='STDLIB_PRE_NUMERICAL_IMPORT_RESOURCE_BOOTSTRAP_V1',PID=receipt['PID'],requested_CPU=4,actual_affinity=[4],limits={name:[value,value] for name,value in (('AS',r.LIMITS['per_case_AS_bytes']),('CPU',r.LIMITS['per_case_CPU_seconds']),('RSS',r.LIMITS['per_case_RSS_stop_bytes']))},thread_environment={key:'1' for key in r.THREAD_ENV})
   owner=dict(cell_id=cell_id,PID=receipt['PID'],CPU=4,controller_PID=receipt['controller_PID'],process_start_ticks=receipt['process_start_ticks'])
   objects={'CASE_RECEIPT.json':receipt,'ACCOUNT_FINANCIAL_AUDIT.json':audit,'NATIVE_RESULT.json':result,'GUARD_RECEIPTS.json':receipts,'LEGACY_PRIMARY_FINANCIAL_RECONCILIATION.json':result['primary_financial_reconciliation'],'PRIMARY_FINANCIAL_RECONCILIATION.json':proof,'NATIVE40_RECONSTRUCTION_PROOF.json':proof,'ACTUAL_HELD_RISK_REPORT.json':risk,'CAUSAL_MARK_QUALITY.json':dict(identity=quality_identity,policy_SHA256=quality_sha,original_interpolated_marks_execution_admitted=False,actual_legacy_event_and_position_impacts='REQUIRE_SEPARATE_SAVED_AUDIT_NOT_INHERITED_FROM_D'),'SOURCE_NATIVE_QUALITY.json':sidecar,'SOURCE_RECAPTURE_GUARD_RECEIPT.json':guard,'WORKER_AUTHORITY_VERIFIED.json':first,'WORKER_SOURCE_ACCEPTED_BEFORE_ACCOUNT.json':second,'PROCESS_OWNERSHIP.json':owner,'BOOTSTRAP_READY.json':bootstrap,'LAUNCH_CLAIM.json':claim}
   raw_files={name:r.body(value) for name,value in objects.items()};raw_files['MINUTE.npz']=minute_raw
   for name,key in (('ADMISSION_GO.json','go'),('ADMISSION_REVIEW.json','review'),('PREPARED_TARGET_REVIEW.json','prepared-review'),('NATIVE_GENERATED_REVIEW.json','native-review')):raw_files[name]=blobs[key]
   self.assertEqual(set(raw_files),set(run.TERMINAL_FILES))
   for name,raw in raw_files.items():
    if name in storage.BIG3:r.save(directory/name,objects[name])
    else:r.write_bytes(directory/name,raw)
   checkpoint=dict(schema=storage.LEGACY_SCHEMA,cell_id=cell_id,files=r.checkpoint_file_hashes(directory,run.TERMINAL_FILES),checker_SHA256=checker.checker_sha256(),reconstruction_proof_SHA256=receipt['reconstruction_proof_SHA256'],all_evidence_fsynced=True,restart_financial_snapshot_permission=False,fresh_scope_revoked=True)
   r.save(directory/'TERMINAL_CHECKPOINT.json',checkpoint)
   with patch.object(run,'wires',return_value=(prep_raw,prep,blobs)),patch.object(run.claims,'claim_path',return_value=claim_path),patch.object(run.claims,'registry_root',return_value=registry),patch.object(run,'expected_claim',return_value=claim),patch.object(r,'shared_resource_lease_path',return_value=shared),patch.object(saved,'saved_account_contract',wraps=saved.saved_account_contract) as account_check,patch.object(checker,'reconcile_saved_native',wraps=checker.reconcile_saved_native) as native40,patch.object(r,'classify_terminal',wraps=r.classify_terminal) as classify,patch.object(saved,'saved_minute',wraps=saved.saved_minute) as minute_check,patch.object(run,'held_risk',wraps=run.held_risk) as risk_check:
    answer=saved.validate_saved_terminal(directory,args=args,cell_id=cell_id)
    for check in (account_check,native40,classify,minute_check,risk_check):self.assertEqual(check.call_count,1)
   self.assertEqual(answer,receipt);self.assertTrue(proof['passed']);self.assertEqual(proof['trade_rows_checked'],2);self.assertEqual(proof['funding_rows_checked'],2)
   self.assertEqual(risk['observation_count'],minutes);self.assertLess(r.own_bytes(root),20_000_000)
   for name in storage.BIG3:self.assertFalse((directory/name).exists());self.assertTrue((directory/(name+'.gz')).exists())
   r._STORAGE_RECEIPTS.clear()
if __name__=='__main__':unittest.main(verbosity=2)
