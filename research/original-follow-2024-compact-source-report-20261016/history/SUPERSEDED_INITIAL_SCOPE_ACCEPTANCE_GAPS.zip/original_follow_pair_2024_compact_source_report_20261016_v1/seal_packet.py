"""Seal only this newly prepared packet. Does not inspect or modify originals."""
from pathlib import Path
import hashlib, io, json, zipfile

ROOT=Path(__file__).resolve().parent

def pin(body):return {'SHA256':hashlib.sha256(body).hexdigest(),'bytes':len(body)}

def main():
    files={str(p.relative_to(ROOT)):pin(p.read_bytes()) for p in sorted(ROOT.rglob('*')) if p.is_file() and p.name!='MANIFEST.json'}
    if sum(x['bytes'] for x in files.values())>=4_500_000:raise ValueError('PACKET_BODY_BOUND')
    scope=json.loads((ROOT/'SCOPE_AND_LIMITS.json').read_bytes())
    (ROOT/'MANIFEST.json').write_text(json.dumps({'schema':'FOLLOW_2024_COMPACT_SOURCE_REPORT_V1','scope_and_limitations':scope,'files':files},sort_keys=True,indent=2)+'\n')
    def archive():
        output=io.BytesIO()
        with zipfile.ZipFile(output,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as handle:
            for path in sorted(ROOT.rglob('*')):
                if path.is_file():
                    info=zipfile.ZipInfo(ROOT.name+'/'+str(path.relative_to(ROOT)),date_time=(2026,10,16,0,0,0))
                    info.create_system=3;info.external_attr=0o100644<<16;info.compress_type=zipfile.ZIP_DEFLATED
                    handle.writestr(info,path.read_bytes(),compresslevel=9)
        return output.getvalue()
    body=archive()
    if archive()!=body:raise ValueError('NONDETERMINISTIC_ARCHIVE')
    (ROOT.parent/(ROOT.name+'.zip')).write_bytes(body)
    print(json.dumps({'ZIP':pin(body),'manifest':pin((ROOT/'MANIFEST.json').read_bytes()),
        'launcher':pin((ROOT/'run_isolated_cold.py').read_bytes()),'packet_bytes':sum(p.stat().st_size for p in ROOT.rglob('*') if p.is_file()),
        'packet_files':len(files)+1,'deterministic_archive_compared_twice':True,'CPU_affinity':sorted(__import__('os').sched_getaffinity(0))},sort_keys=True))

if __name__=='__main__':main()
