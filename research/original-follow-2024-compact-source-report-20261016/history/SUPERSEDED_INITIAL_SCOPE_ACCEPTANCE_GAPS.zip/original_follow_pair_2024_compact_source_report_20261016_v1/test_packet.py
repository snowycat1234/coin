"""Generated stdlib-only tests for the compact integrity checker and ZIP gate."""
import hashlib
from pathlib import Path
import tempfile
import os
import unittest
import zipfile
import run_isolated_cold as cold
import verify_packet as packet

class GeneratedTests(unittest.TestCase):
    def test_metadata_and_JSON_controls(self):
        self.assertEqual(packet.generated_checks()['report_rejections'],14)

    def test_included_reviews_and_contradictory_dependency_flags(self):
        self.assertEqual(packet.generated_checks()['dependency_contradiction_rejections'],4)

    def archive(self,names,external_attr=None):
        temporary=tempfile.TemporaryDirectory(dir=os.environ['GENERATED_FIXTURE_ROOT'],prefix='follow_first6_packet_generated_')
        temporary._finalizer.detach()
        path=Path(temporary.name)/'generated.zip'
        with zipfile.ZipFile(path,'x') as handle:
            for name in names:
                info=zipfile.ZipInfo(name)
                info.external_attr=external_attr if external_attr is not None else 0o100644<<16
                handle.writestr(info,b'GENERATED_ONLY')
        return path,hashlib.sha256(path.read_bytes()).hexdigest()

    def test_positive_members(self):
        p,h=self.archive([packet.NAME+'/generated.txt'])
        self.assertEqual(len(cold.archive_members(p,h)),1)

    def test_wrong_outer_hash(self):
        p,_=self.archive([packet.NAME+'/generated.txt'])
        with self.assertRaisesRegex(ValueError,'SHA256_MISMATCH'):
            cold.archive_members(p,'0'*64)

    def test_no_archive_import_before_authentication(self):
        p,_=self.archive([packet.NAME+'/verify_packet.py'])
        with self.assertRaisesRegex(ValueError,'TRUSTED_SHA256_REQUIRED'):
            cold.archive_members(p,'untrusted')

    def test_parent_traversal(self):
        p,h=self.archive([packet.NAME+'/../escape'])
        with self.assertRaisesRegex(ValueError,'UNSAFE_MEMBER_PATH'):
            cold.archive_members(p,h)

    def test_absolute_path(self):
        p,h=self.archive(['/escape'])
        with self.assertRaisesRegex(ValueError,'UNSAFE_MEMBER_PATH'):
            cold.archive_members(p,h)

    def test_case_collision(self):
        p,h=self.archive([packet.NAME+'/A',packet.NAME+'/a'])
        with self.assertRaisesRegex(ValueError,'COLLIDING_MEMBER'):
            cold.archive_members(p,h)

    def test_symlink(self):
        p,h=self.archive([packet.NAME+'/link'],0o120777<<16)
        with self.assertRaisesRegex(ValueError,'NONREGULAR_MEMBER'):
            cold.archive_members(p,h)

    def test_windows_separator(self):
        p,h=self.archive([packet.NAME+'/a\\b'])
        with self.assertRaisesRegex(ValueError,'UNSAFE_MEMBER_PATH'):
            cold.archive_members(p,h)

    def test_wrong_root(self):
        p,h=self.archive(['other_packet/generated.txt'])
        with self.assertRaisesRegex(ValueError,'UNSAFE_MEMBER_PATH'):
            cold.archive_members(p,h)

    def test_expansion_bound(self):
        p,h=self.archive([packet.NAME+'/a',packet.NAME+'/b'])
        before=cold.MAX_TOTAL
        try:
            cold.MAX_TOTAL=25
            with self.assertRaisesRegex(ValueError,'ARCHIVE_BOUND'):
                cold.archive_members(p,h)
        finally:
            cold.MAX_TOTAL=before

    def test_actual_total_expansion_bound(self):
        temporary=tempfile.TemporaryDirectory(dir=os.environ['GENERATED_FIXTURE_ROOT'],prefix='follow_first6_expansion_')
        temporary._finalizer.detach()
        p=Path(temporary.name)/'generated.zip'
        with zipfile.ZipFile(p,'x',compression=zipfile.ZIP_DEFLATED) as handle:
            handle.writestr(packet.NAME+'/a',b'x'*500)
            handle.writestr(packet.NAME+'/b',b'x'*500)
        h=hashlib.sha256(p.read_bytes()).hexdigest()
        before=cold.MAX_TOTAL
        try:
            cold.MAX_TOTAL=700
            with self.assertRaisesRegex(ValueError,'TOTAL_EXPANSION_BOUND'):
                cold.archive_members(p,h)
        finally:
            cold.MAX_TOTAL=before

    def test_member_count(self):
        p,h=self.archive([packet.NAME+'/a',packet.NAME+'/b'])
        before=cold.MAX_MEMBERS
        try:
            cold.MAX_MEMBERS=1
            with self.assertRaisesRegex(ValueError,'MEMBER_COUNT_BOUND'):
                cold.archive_members(p,h)
        finally:
            cold.MAX_MEMBERS=before

    def test_directory_member(self):
        p,h=self.archive([packet.NAME+'/directory/'])
        with self.assertRaisesRegex(ValueError,'UNSAFE_MEMBER_PATH'):
            cold.archive_members(p,h)

    def test_colon_path(self):
        p,h=self.archive([packet.NAME+'/C:file'])
        with self.assertRaisesRegex(ValueError,'UNSAFE_MEMBER_PATH'):
            cold.archive_members(p,h)

    def test_missing_dependency_classification(self):
        with self.assertRaisesRegex(ValueError,'EXHAUSTIVE_DEPENDENCY_KEYS'):
            packet.check_dependencies({'dependencies':{},'financial_runtime_closure_complete':False},
                                      {'required.py':{'SHA256':'0'*64,'bytes':1}}, {})

    def test_manifest_disclosure_omitted(self):
        with self.assertRaisesRegex(ValueError,'MANIFEST_SCOPE_DISCLOSURE_CROSS_BINDING'):
            packet.check_disclosure({}, {'case_count':6}, [])

    def test_manifest_disclosure_contradictory(self):
        with self.assertRaisesRegex(ValueError,'MANIFEST_SCOPE_DISCLOSURE_CROSS_BINDING'):
            packet.check_disclosure({'scope_and_limitations':{'target_recomputation_available':True}},
                                    {'target_recomputation_available':False}, [])

class DualPinTests(unittest.TestCase):
    def test_dual_pin_raw_stored_separation(self):
        identity={'encoding':'gzip6','SHA256':'a'*64,'bytes':10,'raw_SHA256':'b'*64,'raw_bytes':100,'path':'case/A.json.gz'}
        storage={'encoding':'gzip6','stored':{'SHA256':'a'*64,'bytes':10},'raw':{'SHA256':'b'*64,'bytes':100},'logical_name':'A.json','stored_name':'A.json.gz'}
        packet.check_dual_pin(identity,storage,'b'*64)
        with self.assertRaisesRegex(ValueError,'RAW_NAMESPACE'):packet.check_dual_pin(identity,storage,'a'*64)
        bad=dict(identity,raw_SHA256='a'*64,raw_bytes=10)
        with self.assertRaises(ValueError):packet.check_dual_pin(bad,storage,'a'*64)

if __name__=='__main__':
    unittest.main()
