"""Stdlib-only report/source-binding reader. Historical source is inert bytes."""
from pathlib import Path
import copy, csv, decimal, hashlib, io, json, re

NAME='original_follow_pair_2024_compact_source_report_20261016_v1'
NATIVE='original_follow_pair_next6_D_compressed_native_20261016_v1'
SOURCE='original_follow_pair_D_source_20261016_v1'
SIGNAL='original_follow_pair_signal_20261016_v1'
SAVED='original_follow_pair_next6_D_compressed_saved_independent_review_20261016_v1'
ATTEMPT=NATIVE+'/financial_attempts/ACTUAL_NEXT6_2024_attempt001'
PREP=SOURCE+'/source_attempts/ACTUAL_ALL30_SOURCE_TARGET_ONLY_attempt001'
GO='78b09b69f494eb0e7607f4ff2e6b6161d1c7bebf7ff52e687aa868e75948a6c4'
FIN='783e2115ab281a0acc05b9d3f03962b6c730a36906b371ed2c0a167f867e62d4'
SOURCE_SHA='96791b8573a9b0d8331d3ff92cceb0016b2294b44497be4e510953cb2c025fb4'
AUDIT='6b88cdf2b0b15382d2df84f88944369a2e0a12b5af3fe2518bb269af1d698bd2'
REPORT='c25305dd33b745d44e88ab2d596900bed28a189b4152941a847571770c57e0b9'
CSV='00d353e21cc66b6418cc8164fcdfd7c9956ca7be4651e19194bd64e7fb50e456'
EXIT='5d77940510d8d125a76eb208a98e088bf225b006861056787510f6c99830e6ca'
CELLS=tuple('2024_'+strategy+'_'+tier+'_D_INTRINSIC_LOWER_ONLY_V1' for strategy in ('STATIC50_FOLLOW_POOL_SAMEGROSS','STATIC50_FOLLOW_DEPENDENT_SAMEGROSS_CONTROL') for tier in ('LOW','MID','HIGH'))

def require(value,message):
    if not value:raise ValueError(message)

def valid_relative(value):
    return isinstance(value,str) and bool(value) and '\\' not in value and ':' not in value and not value.startswith('/') and all(x not in ('','.','..') for x in value.split('/'))

def decode(raw):
    def pairs(values):
        out={}
        for key,value in values:
            require(key not in out,'DUPLICATE_JSON_KEY');out[key]=value
        return out
    def invalid(value):raise ValueError('NONFINITE_JSON:'+value)
    return json.loads(raw,object_pairs_hook=pairs,parse_constant=invalid)

def pin(path):
    body=path.read_bytes();return {'SHA256':hashlib.sha256(body).hexdigest(),'bytes':len(body)}

def load(root,relative):
    require(valid_relative(relative),'UNSAFE_READER_PATH')
    return decode((root/relative).read_bytes())

def clean_pin(value):return {k:value[k] for k in ('SHA256','bytes')}

def check_disclosure(manifest,scope,rows):
    require(manifest.get('scope_and_limitations')==scope,'MANIFEST_SCOPE_DISCLOSURE_CROSS_BINDING')
    require(scope['scope']=='COMPACT_REPORT_AND_SOURCE_BINDINGS_ONLY' and scope['case_count']==6 and scope['year']==2024,'DISCLOSURE_SIX_ONLY_SCOPE')
    require(scope['historical_code_snapshots']=='INERT_BYTES_ONLY_NEVER_IMPORTED','DISCLOSURE_INERT_SNAPSHOTS')
    require(scope['full_event_history_omitted'] is True and scope['public_packet_alone_CANNOT_reconstruct_all_native40_checks'] is True,'DISCLOSURE_NATIVE40_OMISSION')
    require(scope['limitation_sentence']=='compact report and source bindings only; omitted full event history means the public packet alone CANNOT reconstruct all native40 checks.','DISCLOSURE_EXACT_LIMITATION_SENTENCE')
    for key in ('source_and_signal_own_file_snapshots_complete','source_direct_manifest_dependencies_complete','financial_own_file_snapshots_complete','raw_and_stored_gzip6_pins_are_not_interchangeable'):
        require(scope[key] is True,'DISCLOSURE_OWN_FILE_COMPLETENESS:'+key)
    for key in ('target_recomputation_available','financial_history_self_contained','financial_runtime_closure_complete','risk_matched_claim','post_tier_samegross_guaranteed','continuous_risk_ceiling_guaranteed','funding_units_or_arrival_certified','native_venue_or_liquidation_certified','OOS_or_live_certification','deployability_established','future_performance_established'):
        require(scope[key] is False,'DISCLOSURE_REQUIRED_FALSE:'+key)
    warnings=scope['actual_risk_warnings'];require(len(warnings)==6,'SIX_RISK_WARNINGS')
    for row,warning in zip(rows,warnings):
        require(warning['cell_id']==row['cell_id'],'DISCLOSURE_RISK_CELL')
        for key,value in warning.items():require(row[key]==value,'DISCLOSURE_EXACT_RISK_VALUE:'+key)
    require('88406' in scope['actual_risk_interpretation'] and '69176' in scope['actual_risk_interpretation'],'CONCRETE_RISK_WARNING')
    require(scope['quality_original_genuine_observation_us']==1723456920000000,'ORIGINAL_GENUINE_MARK_CLOCK')
    require(scope['quality_interval_UTC']=='2024-08-12T10:03:00Z inclusive to 2024-08-12T10:05:00Z exclusive; original genuine observation 2024-08-12T10:02:00Z','QUALITY_UTC_CLOCK')
    return scope

def check_dual_pin(identity,storage,checkpoint_digest):
    require(identity['encoding']==storage['encoding']=='gzip6','GZIP6_ENCODING')
    require(clean_pin(identity)==storage['stored'],'STORED_GZIP_PIN')
    require({'SHA256':identity['raw_SHA256'],'bytes':identity['raw_bytes']}==storage['raw'],'UNCHANGED_RAW_PIN')
    require(checkpoint_digest==identity['raw_SHA256'],'CHECKPOINT_IS_RAW_NAMESPACE')
    require(identity['path'].endswith('/'+storage['stored_name']) and storage['stored_name']==storage['logical_name']+'.gz','DUAL_LOGICAL_STORED_NAME')
    require(identity['SHA256']!=identity['raw_SHA256'] and identity['bytes']!=identity['raw_bytes'],'RAW_STORED_NOT_INTERCHANGEABLE')


def check_rows(report):
    require(report['schema']=='INDEPENDENT_FOLLOW_NEXT6_2024_COMPRESSED_COMPACT_SAVED_ECONOMICS_MATRIX_V2','REPORT_SCHEMA')
    require(report['status']=='PASS_EXACT_SAVED_FULL_SIX','REPORT_STATUS')
    require(report['ordered_cells']==list(CELLS),'REPORT_ORDER')
    rows=report['rows'];require(len(rows)==6,'SIX_ROWS')
    require([r['cell_id'] for r in rows]==list(CELLS),'ROW_IDENTITY')
    for index,row in enumerate(rows):
        require(type(row['year']) is int and row['year']==2024,'ROW_YEAR')
        require(type(row['completed_minutes']) is int and row['completed_minutes']==527040 and row['required_minutes']==527040,'ROW_CALENDAR')
        require(row['full_calendar'] is True and row['actual_paid_market_flat'] is True,'ROW_PAID_CALENDAR')
        require(row['terminal_status']=='FULL_CALENDAR_ACTUAL_PAID_MARKET_FLAT','ROW_STATUS')
        require(row['conditional_settled_flat'] is False and row['conditional_settlements']==0 and row['account_stop_us'] is None,'ROW_NO_CONDITIONAL_OR_HALT')
        require(row['unpaid_liability_USDT']=='0' and row['initial_cash_USDT']=='10000','ROW_FRESH_CASH_AND_NO_DEBT')
        require(row['quality_intervals']==1 and row['source_quality_cells']==row['quality_block_rows']==0,'ROW_QUALITY_EXACT')
        require(row['nominal_annual_volatility_budget']==(.05,.1,.15)[index%3],'NOMINAL_TIER')
        require(row['native40_reconstruction_status']=='PASS_EXACT_EVERY_NATIVE40_EVENT_STATE','PRIOR_PROOF_STATUS')
        require(row['paid_net_return']==row['comparable_full_calendar_return'],'RETURN_SCOPE')
        with decimal.localcontext() as ctx:
            ctx.prec=100
            expected=float((decimal.Decimal(row['final_NAV_USDT'])-decimal.Decimal('10000'))/decimal.Decimal('10000'))
        require(expected==row['paid_net_return'],'RETURN_NAV_ARITHMETIC')
    return rows

def check_dependencies(data,expected,by_original,root=None):
    actual=data['dependencies'];require(set(actual)==set(expected),'EXHAUSTIVE_DEPENDENCY_KEYS')
    for original,identity in expected.items():
        entry=actual[original];included=original in by_original
        require(entry['pin']==identity,'DEPENDENCY_PIN')
        require(type(entry['included']) is bool and entry['included'] is included,'DEPENDENCY_INCLUDED_FLAG')
        require(entry['packet_path']==by_original.get(original),'DEPENDENCY_PACKET_PATH')
        require(entry['classification']==('BUNDLED_INERT_BYTES' if included else 'OMITTED_INHERITED_FINANCIAL_CODE_OR_REFERENCE'),'DEPENDENCY_CLASSIFICATION')
        require((entry['reader_limitation'] is None) is included,'DEPENDENCY_LIMITATION')
        if included and root is not None:require(pin(root/entry['packet_path'])==identity,'INCLUDED_DEPENDENCY_BYTES')
    require(data['financial_runtime_closure_complete'] is False,'NO_FINANCIAL_CLOSURE_CLAIM')

def generated_checks():
    base={'schema':'INDEPENDENT_FOLLOW_NEXT6_2024_COMPRESSED_COMPACT_SAVED_ECONOMICS_MATRIX_V2','status':'PASS_EXACT_SAVED_FULL_SIX','ordered_cells':list(CELLS),'rows':[]}
    for i,cell in enumerate(CELLS):
        base['rows'].append(dict(cell_id=cell,year=2024,completed_minutes=527040,required_minutes=527040,full_calendar=True,
            actual_paid_market_flat=True,terminal_status='FULL_CALENDAR_ACTUAL_PAID_MARKET_FLAT',conditional_settled_flat=False,
            conditional_settlements=0,account_stop_us=None,unpaid_liability_USDT='0',initial_cash_USDT='10000',
            quality_intervals=1,source_quality_cells=0,quality_block_rows=0,nominal_annual_volatility_budget=(.05,.1,.15)[i%3],
            native40_reconstruction_status='PASS_EXACT_EVERY_NATIVE40_EVENT_STATE',paid_net_return=.1,comparable_full_calendar_return=.1,final_NAV_USDT='11000'))
    check_rows(base);bad=[]
    for key,value in (('year',True),('completed_minutes',1),('full_calendar',False),('actual_paid_market_flat',False),
                      ('terminal_status','CONDITIONAL'),('conditional_settled_flat',True),('conditional_settlements',1),
                      ('unpaid_liability_USDT','1'),('initial_cash_USDT','20000'),('quality_intervals',2),
                      ('nominal_annual_volatility_budget',.9),('final_NAV_USDT','11001')):
        x=copy.deepcopy(base);x['rows'][0][key]=value;bad.append(x)
    x=copy.deepcopy(base);x['rows'].pop();bad.append(x)
    x=copy.deepcopy(base);x['rows'][0]=copy.deepcopy(x['rows'][1]);bad.append(x)
    for value in bad:
        try:check_rows(value)
        except (ValueError,KeyError):continue
        raise ValueError('GENERATED_BAD_REPORT_ACCEPTED')
    for raw in (b'{"x":1,"x":2}',b'{"x":NaN}',b'{"x":Infinity}'):
        try:decode(raw)
        except ValueError:continue
        raise ValueError('GENERATED_BAD_JSON_ACCEPTED')
    require(all(not valid_relative(x) for x in ('../a','/a','a//b','a/./b','a\\b','C:/a')),'GENERATED_BAD_PATH_ACCEPTED')
    expected={'x.py':{'SHA256':'0'*64,'bytes':1}}
    dep={'dependencies':{'x.py':{'pin':expected['x.py'],'included':True,'packet_path':'snapshots/x.py','classification':'BUNDLED_INERT_BYTES','reader_limitation':None}},'financial_runtime_closure_complete':False}
    check_dependencies(dep,expected,{'x.py':'snapshots/x.py'});n=0
    for key,value in (('included',False),('packet_path',None),('classification','OMITTED_INHERITED_FINANCIAL_CODE_OR_REFERENCE'),('reader_limitation','missing')):
        x=copy.deepcopy(dep);x['dependencies']['x.py'][key]=value
        try:check_dependencies(x,expected,{'x.py':'snapshots/x.py'})
        except ValueError:n+=1;continue
        raise ValueError('GENERATED_BAD_DEPENDENCY_ACCEPTED')
    return {'report_rejections':len(bad),'JSON_rejections':3,'path_rejections':6,'dependency_contradiction_rejections':n}

def verify(root):
    root=Path(root).resolve();manifest=load(root,'MANIFEST.json')
    require(manifest['schema']=='FOLLOW_2024_COMPACT_SOURCE_REPORT_V1','PACKET_SCHEMA')
    expected=manifest['files'];require(all(valid_relative(x) for x in expected),'MANIFEST_PATHS')
    actual={}
    for path in sorted(root.rglob('*')):
        require(not path.is_symlink(),'SYMLINK_FORBIDDEN')
        if path.is_file() and path!=root/'MANIFEST.json':actual[str(path.relative_to(root))]=pin(path)
    require(actual==expected,'EXACT_INVENTORY_AND_PINS')
    require(sum(x['bytes'] for x in actual.values())<4_500_000,'PACKET_BODY_BOUND')
    for rel in actual:
        require(not rel.endswith(('.npz','.npy','.parquet','.zip','.pyc','.gz')),'NO_ARRAY_OR_ARCHIVE_BODIES')
        require(Path(rel).name not in ('LAUNCH_CLAIM.json','ACCOUNT_FINANCIAL_AUDIT.json','NATIVE_RESULT.json','GUARD_RECEIPTS.json'),'NO_AUTHORITY_OR_FULL_HISTORY_BODIES')
    provenance=load(root,'PROVENANCE_FILE_MAP.json');require(provenance['all_copies_exact_original_bytes'] is True,'EXACT_COPY_POLICY')
    by_original={}
    for rel,value in provenance['files'].items():
        require(valid_relative(rel) and value['transformation']=='EXACT_EXISTING_BYTES','COPY_TRANSFORMATION')
        require(pin(root/rel)==value['original_pin'],'EXACT_ORIGINAL_BYTES:'+rel)
        require(value['original_path'] not in by_original,'DUPLICATE_ORIGINAL_COPY')
        by_original[value['original_path']]=rel
    def original(path):
        require(path in by_original,'MISSING_ORIGINAL:'+path);return load(root,by_original[path])
    def original_pin(path):return pin(root/by_original[path])
    deps={}
    for folder,filename in ((SIGNAL,'CODE_MANIFEST.json'),(SOURCE,'CODE_MANIFEST.json'),(NATIVE,'FINANCIAL_CODE_MANIFEST.json')):
        frozen=original(folder+'/'+filename)
        for rel,identity in frozen['files'].items():require(original_pin(folder+'/'+rel)==clean_pin(identity),'OWN_FILE_MANIFEST:'+folder+'/'+rel)
        for path,identity in frozen.get('dependencies',{}).items():
            identity=clean_pin(identity);require(path not in deps or deps[path]==identity,'CONTRADICTORY_FROZEN_PIN');deps[path]=identity
    require(original_pin(NATIVE+'/FINANCIAL_CODE_MANIFEST.json')['SHA256']==FIN,'FINAL_CODE_IDENTITY')
    require(original_pin(SOURCE+'/CODE_MANIFEST.json')['SHA256']==SOURCE_SHA,'SOURCE_CODE_IDENTITY')
    classification=load(root,'DEPENDENCY_CLASSIFICATION.json');check_dependencies(classification,deps,by_original,root)
    require(classification['FOLLOW_source_direct_manifest_dependencies_complete'] is True,'SOURCE_DIRECT_CLOSURE_FLAG')
    require(all(path in by_original for path in original(SOURCE+'/CODE_MANIFEST.json')['dependencies']),'SOURCE_DIRECT_CLOSURE_BYTES')
    for name,digest in (('FINAL_INDEPENDENT_SAVED_AUDIT.json',AUDIT),('FINAL_SIX_MATRIX.json',REPORT),('FINAL_SIX_MATRIX.csv',CSV)):
        require(pin(root/'reviews/saved'/name)['SHA256']==digest,'EXACT_FINAL:'+name)
    audit=load(root,'reviews/saved/FINAL_INDEPENDENT_SAVED_AUDIT.json')
    report=load(root,'reviews/saved/FINAL_SIX_MATRIX.json');rows=check_rows(report)
    require(audit['status']=='PASS_NEXT6_2024_SAVED_OFFLINE_MODEL_WITH_QUALIFICATIONS_AND_ROOT_EXIT0','FINAL_AUDIT_STATUS')
    require(audit['completed_cases']==audit['actual_paid_market_flat_cases']==6 and audit['total_completed_minutes']==3162240,'FINAL_AUDIT_COVERAGE')
    require(audit['financial_code_manifest']['SHA256']==FIN and audit['root_GO']['SHA256']==GO,'AUDIT_CODE_GO')
    require(audit['root_session_id']==75308 and audit['root_observed_exit_code']==0,'AUDIT_ROOT_EXIT')
    for key in ('conditional_settled_cases','economic_halt_cases','resource_source_validation_pause_cases','review_accounts_scopes_or_providers_constructed','review_source_recaptures','review_financial_replays','review_claims_or_GO_issued','network_actions','publication_actions'):
        require(audit[key]==0,'AUDIT_REQUIRED_ZERO:'+key)
    require(audit['remaining18_authorized'] is False and audit['risk_matched_claim'] is False and audit['post_tier_samegross_guaranteed'] is False,'AUDIT_QUALIFICATIONS')
    require(load(root,'FINAL_INPUT_PINS.json')['final_saved_audit']==audit,'FINAL_INPUT_CROSS_BINDING')
    require(original_pin(audit['controller_and_final_artifact_binding']['path'])==clean_pin(audit['controller_and_final_artifact_binding']),'CONTROLLER_BINDING_IDENTITY')
    binding=original(audit['controller_and_final_artifact_binding']['path'])
    require(report['controller_and_final_artifact_binding']==audit['controller_and_final_artifact_binding'],'REPORT_CONTROLLER_BINDING')
    csv_rows=list(csv.DictReader(io.StringIO((root/'reviews/saved/FINAL_SIX_MATRIX.csv').read_text())))
    require(len(csv_rows)==6,'CSV_ROWS');csv_fields=0
    for row,csv_row in zip(rows,csv_rows):
        for key,value in csv_row.items():
            require(key in row and value==('' if row[key] is None else str(row[key])),'EXACT_CSV_JSON_FIELD:'+row['cell_id']+':'+key);csv_fields+=1
        require(set(row)==set(load(root,'MATRIX_FIELDS.json')['JSON_row_fields']),'EXACT_JSON_FIELDS')
        require(list(csv_row)==load(root,'MATRIX_FIELDS.json')['CSV_fields'],'EXACT_CSV_FIELDS')
        cell=row['cell_id'];review=original(row['review']['path'])
        require(original_pin(row['review']['path'])==clean_pin(row['review'])==clean_pin(audit['per_case_reviews'][cell]),'CELL_REVIEW_IDENTITY')
        require(review['cell_id']==cell and review['status']=='PASS_SAVED_ONLY','CELL_REVIEW_STATUS')
        aliases={'final_NAV_USDT':'exact_NAV','initial_cash_USDT':'fresh_shared_initial_cash','actual_paid_market_flat':'paid_flat','paid_trade_legs':'trade_legs','unpaid_liability_USDT':'unpaid_liability','target_identity':'saved_target_identity'}
        for key,value in row.items():
            review_key=aliases.get(key,key)
            if review_key in review:require(value==review[review_key],'REVIEW_REPORT_FIELD:'+key)
        for key,value in review['actual_held_risk_and_exposure'].items():
            if key in row:require(value==row[key],'NESTED_REVIEW_RISK:'+key)
        require(review['quality']==audit['exact_saved_2024_minute_quality_impacts'][cell],'QUALITY_AUDIT_REVIEW_BINDING')
        for key in ('debt_forgiveness','internal_transfers','topups','new_capital'):require(review[key]==0,'RESTRICTION_ZERO')
        checkpoint=load(root,'cases/'+cell+'/TERMINAL_CHECKPOINT.json')
        require(pin(root/'cases'/cell/'TERMINAL_CHECKPOINT.json')==clean_pin(review['terminal_checkpoint']),'CHECKPOINT_REVIEW_PIN')
        require(checkpoint['cell_id']==cell and checkpoint['restart_financial_snapshot_permission'] is False,'CHECKPOINT_SCOPE')
        for filename,digest in checkpoint['files'].items():
            identity=binding['checked_case_artifacts'][cell]['files'][filename]
            if filename in checkpoint.get('storage',{}):check_dual_pin(identity,checkpoint['storage'][filename],digest)
            else:require(identity['SHA256']==digest,'SEALED_FULL_HISTORY_HASH')
            if identity['path'] in by_original:require(original_pin(identity['path'])==clean_pin(identity),'SEALED_INCLUDED_CASE_BYTES')
        receipt=load(root,'cases/'+cell+'/CASE_RECEIPT.json')
        require(receipt['financial_code_manifest_SHA256']==FIN and receipt['root_GO_SHA256']==GO and receipt['source_code_manifest_SHA256']==SOURCE_SHA,'CASE_CODE_SOURCE_GO')
        require(receipt['completed_minutes']==527040 and receipt['status']==row['terminal_status'],'CASE_CALENDAR_STATUS')
        risk=load(root,'cases/'+cell+'/ACTUAL_HELD_RISK_REPORT.json')
        for key in row.keys()&risk.keys():require(row[key]==risk[key],'HELD_RISK_FIELD:'+key)
        require(risk['nominal_tier_equality_is_not_exact_realized_risk_matching'] is True and risk['omitted_nonpositive_or_later_minutes']==0,'HELD_RISK_QUALIFICATION')
        proof=load(root,'cases/'+cell+'/NATIVE40_RECONSTRUCTION_PROOF.json')
        require(proof['passed'] is True and proof['status']==row['native40_reconstruction_status'],'PRIOR_PROOF_PASSED')
        require(proof['exact_native40_NAV']==row['final_NAV_USDT'] and proof['trade_rows_checked']==row['paid_trade_legs'] and proof['funding_rows_checked']==row['account_applied_funding_events'],'PRIOR_PROOF_ECONOMIC_BINDING')
        require(proof['checker_SHA256']==original_pin('bounded_native_continuation_guard50_exit_expansion_20261015/saved_native_reconciliation.py')['SHA256'],'PRIOR_CHECKER_BYTES')
        require(receipt['reconstruction_proof_SHA256']==pin(root/'cases'/cell/'NATIVE40_RECONSTRUCTION_PROOF.json')['SHA256'],'RECEIPT_PROOF_BINDING')
    exit_receipt=load(root,'receipts/ROOT_OBSERVED_EXIT_CONFIRMED.json')
    require(pin(root/'receipts/ROOT_OBSERVED_EXIT_CONFIRMED.json')['SHA256']==EXIT and exit_receipt['session_id']==75308 and exit_receipt['observed_exit_code']==0,'EXACT_ROOT_EXIT')
    omissions=load(root,'OMITTED_EVIDENCE_PINS.json');omitted=omissions['files']
    required_omitted={}
    def expect_omitted(path,identity):
        if path not in by_original:
            identity=clean_pin(identity);require(path not in required_omitted or required_omitted[path]==identity,'OMIT_CONFLICT');required_omitted[path]=identity
    for case in binding['checked_case_artifacts'].values():
        for identity in case['files'].values():expect_omitted(identity['path'],identity)
    expect_omitted(binding['controller_terminal']['path'],binding['controller_terminal']);expect_omitted(audit['root_GO']['path'],audit['root_GO'])
    preparation=original(PREP+'/PREPARATION.json')
    require(original_pin(PREP+'/PREPARATION.json')==clean_pin(binding['source_preparation']),'SOURCE_PREPARATION_BINDING')
    for rel,identity in preparation['artifacts'].items():expect_omitted(PREP+'/'+rel,identity)
    def collect(value):
        if isinstance(value,dict):
            if all(k in value for k in ('SHA256','bytes','path')):expect_omitted(value['path'],value)
            for child in value.values():collect(child)
        elif isinstance(value,list):
            for child in value:collect(child)
    collect(original(NATIVE+'/NATIVE_SOURCE_DESCRIPTOR.json'))
    collect(original(SOURCE+'/HLC_SOURCE_CONTRACT_MAP.json')['read_files']['2024'])
    collect(original(SOURCE+'/CLOSE_PREFIX_SOURCE_MAP.json')['years']['2024'])
    require(set(omitted)==set(required_omitted),'EXHAUSTIVE_OMITTED_EVIDENCE_KEYS')
    for path,identity in required_omitted.items():
        item=omitted[path];require(item['pin']==identity and item['included'] is False and item['hashes_restore_omitted_bytes'] is False,'OMISSION_PIN_AND_LIMIT')
    scope=load(root,'SCOPE_AND_LIMITS.json');require(scope['ordered_cells']==list(CELLS) and scope['completed_minutes']==3162240,'SCOPE_COVERAGE')
    check_disclosure(manifest,scope,rows)
    require(scope['exact_saved_2024_minute_quality_impacts']==audit['exact_saved_2024_minute_quality_impacts'],'QUALITY_SCOPE_AUDIT_BINDING')
    readme=(root/'README.md').read_text();require(readme.count('SCOPE_JSON_BEGIN')==readme.count('SCOPE_JSON_END')==1,'README_SCOPE_MARKERS')
    require(decode(readme.split('SCOPE_JSON_BEGIN\n',1)[1].split('\nSCOPE_JSON_END',1)[0])==scope,'README_IDENTICAL_SCOPE')
    for row in rows:
        cell=row['cell_id'];causal=load(root,'cases/'+cell+'/CAUSAL_MARK_QUALITY.json');interval=causal['identity']['intervals'][0]
        require(interval['original_genuine_observation_us']==1723456920000000 and interval['start_us']==1723456980000000 and interval['end_us']==1723457100000000,'EXACT_STALE_MARK_CLOCK')
        q=scope['exact_saved_2024_minute_quality_impacts'][cell];imp=q['actual_saved_interval_impacts'][0]
        require(q['interval_count']==1 and q['derived_mark_cells']==10 and q['quality_block_rows']==q['source_quality_cell_count']==0,'QUALITY_EXACT_COUNTS')
        require(imp['start_us']==interval['start_us'] and imp['end_us']==interval['end_us'] and imp['symbols']==interval['symbols'],'QUALITY_INTERVAL_BINDING')
        require(imp['minute_rows']==2 and imp['guard50_monitor_rows']==1 and imp['terminal_in_interval'] is False,'QUALITY_SAVED_EVENT_IMPACTS')
        for k in ('funding_rows','owned_funding_rows','paid_trades','ledger_rows','immediate_native_risk_rows','quality_blocks'):require(imp[k]==0,'QUALITY_ZERO_EVENT:'+k)
        require(imp['nonzero_position_minute_cells_by_symbol']=={sym:(0 if cell==CELLS[0] and sym=='SOLUSDT' else 2) for sym in interval['symbols']},'QUALITY_POSITION_IMPACTS')
    for case in binding['checked_case_artifacts'].values():
        for identity in case['files'].values():
            if identity.get('encoding')=='gzip6':
                item=omitted[identity['path']]
                require(item['raw_pin']=={'SHA256':identity['raw_SHA256'],'bytes':identity['raw_bytes']} and item['raw_and_stored_pins_are_not_interchangeable'] is True,'OMITTED_DUAL_PIN_NAMESPACE')
                require(item['pin_namespace']=='EXACT_STORED_FILE_BYTES' and item['raw_pin_namespace']=='UNCHANGED_LOGICAL_RUNTIME_JSON_BYTES' and item['stored_pin_namespace']=='EXACT_GZIP6_FILE_BYTES','OMITTED_NAMESPACE_LABELS')
    require(omissions['raw_and_stored_pins_are_not_interchangeable'] is True,'OMISSION_DUAL_PIN_POLICY')
    require(original_pin(audit['root_GO']['path'])==clean_pin(audit['root_GO']),'EXACT_INERT_EXISTING_AUTHORITY')
    closure=load(root,'reviews/saved/MATRIX_FINAL_CLOSURE.json')
    require(pin(root/'reviews/saved/MATRIX_FINAL_CLOSURE.json')['SHA256']=='2b36a5e85262e8054108bfa05105213565f40022891453f03b3fbc1ea6c2dcb6','EXACT_FINAL_CLOSURE')
    require(closure['final_independent_audit']==dict(path=SAVED+'/FINAL_INDEPENDENT_SAVED_AUDIT.json',**pin(root/'reviews/saved/FINAL_INDEPENDENT_SAVED_AUDIT.json')),'CLOSURE_AUDIT')
    require(closure['matrix']==audit['matrix_JSON'] and closure['root_observed_exit']==audit['root_observed_exit'] and closure['controller_and_final_artifact_binding']==audit['controller_and_final_artifact_binding'],'CLOSURE_BINDINGS')
    disposition=closure['final_authoritative_disposition']
    require(disposition['root_exit_receipt_pending'] is False and disposition['root_session_id']==75308 and disposition['root_observed_exit_code']==0 and disposition['completed_minutes']==3162240,'FINAL_COMPLETE_DISPOSITION')
    paired=load(root,'reviews/saved/PAIRED_ACTUAL_GROSS_AND_NOMINAL_RISK.json')
    require(pin(root/'reviews/saved/PAIRED_ACTUAL_GROSS_AND_NOMINAL_RISK.json')==clean_pin(audit['paired_actual_gross_and_nominal_risk']),'EXACT_PAIRED_RISK')
    for i,pair in enumerate(paired['rows']):
        require(pair['pool']==CELLS[i] and pair['dependent_control']==CELLS[i+3] and pair['common_minutes']==527040,'PAIR_IDENTITY_CALENDAR')
        require(pair['actual_minutes_with_nonzero_gross_difference']==522659 and pair['post_tier_samegross_guaranteed'] is False and pair['risk_matched_claim'] is False,'PAIR_DIFFERENCE_QUALIFICATION')
    for key in ('publication_performed','upload_authority_granted','source_or_financial_execution_authorized','target_recomputation_available','financial_history_self_contained','financial_runtime_closure_complete','hashes_restore_omitted_bytes','all37_or_current_D_all30_completion_claim','remaining18_authorized','OOS_or_live_certification','deployability_established','risk_matched_claim','post_tier_samegross_guaranteed','funding_units_or_arrival_certified','native_venue_or_liquidation_certified','originals_modified'):
        require(scope[key] is False,'SCOPE_REQUIRED_FALSE:'+key)
    require(scope['public_packet_alone_CANNOT_reconstruct_all_native40_checks'] is True,'NATIVE40_READER_LIMIT')
    require(rows[3]['forecast_volatility_breach_minutes']==88406 and rows[3]['forecast_annual_volatility_max']==0.1158969858786537,'CONTROL_LOW_ACTUAL_RISK_QUALIFICATION')
    return {'status':'PASS_COMPACT_REPORT_AND_SOURCE_BINDINGS_ONLY','case_count':6,'completed_minutes':3162240,
        'files_verified':len(actual)+1,'CSV_JSON_fields_checked':csv_fields,'direct_dependencies_classified':len(deps),
        'omitted_evidence_files_pinned':len(omitted),'generated_checks':generated_checks(),
        'historical_modules_imported':0,'source_capture_or_target_recomputation':0,'financial_replays':0,
        'public_packet_alone_CANNOT_reconstruct_all_native40_checks':True,'target_recomputation_available':False,
        'native40_status_is_prior_full_audit_evidence_not_a_rerun':True,'publication_actions':0,
        'scope_and_limitations':scope,'final_authoritative_disposition':disposition,'raw_and_stored_gzip6_pin_pairs_checked':18}

if __name__=='__main__':print(json.dumps(verify(Path(__file__).resolve().parent),sort_keys=True))
