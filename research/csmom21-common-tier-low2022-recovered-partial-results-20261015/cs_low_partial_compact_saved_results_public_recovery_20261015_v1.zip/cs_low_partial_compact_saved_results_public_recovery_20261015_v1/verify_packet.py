#!/usr/bin/env python3
"""Stdlib-only cold verifier for exact compact LOW economics and partial status."""
import argparse,ast,gzip,hashlib,json,os,sys
from pathlib import Path
from saved_report import *
from saved_native_reconciliation import reconcile_saved_native,checker_sha256
FROZEN_PINS={
 'financial/ACCOUNT_FINANCIAL_AUDIT.json.gz':('077feef07274da3a0320e8bdd5eb491bef0af42fd381464e0fea51c63e89709c',19719829),
 'financial/NATIVE_RESULT.json.gz':('e00734a22df1abedcbbaef93b11162ade470785c1c08f93ec07339ef02b136de',10402867),
 'financial/NATIVE40_RECONSTRUCTION_PROOF.json':('3ca56854c1433b8e26eaff4ce258fcf0cba49a65cd14a27884fe0045d1a89d92',1434),
 'financial/PRIMARY_FINANCIAL_RECONCILIATION.json':('3ca56854c1433b8e26eaff4ce258fcf0cba49a65cd14a27884fe0045d1a89d92',1434),
 'financial/LEGACY_PRIMARY_FINANCIAL_RECONCILIATION.json':('43baa85f31e72284a9aa4574bbd6b6edb270b3a090adb808f7945d4279b571d2',1024),
 'financial/TERMINAL_CHECKPOINT.json':('eee3fcba990c9790c55f2fb0dcc7226017df93398e3da8ec9c6e2a56dd58f094',2462),
 'reviews/LOW_ECONOMIC_REVIEW.json':('0e0be07fca4a8518b0c32e6ee14f06082ca32a91ef4233e61c3498ac9d7ac102',404820),
 'provenance/cs_saved_frozen.py':('17b0ac47da90402565de776f505523743e0f187b07e9e7872b1d50441bd88449',21163),
 'provenance/cs_saved_reporting.py':('b3073f4f4933ebdfccb48b8e130e2a6b2ec14565a7822d0190c75eb719ed2cd5',21201),
}
def digest(b):return hashlib.sha256(b).hexdigest()
def raw(path):
 path=Path(path);b=path.read_bytes();return gzip.decompress(b) if path.suffix=='.gz' else b
def pin(path):
 b=Path(path).read_bytes();return dict(SHA256=digest(b),bytes=len(b))
def files(root):return {str(p.relative_to(root)):pin(p) for p in sorted(root.rglob('*')) if p.is_file() and p.name!='MANIFEST.json' and '__pycache__' not in p.parts}
def verify_scope(s):
 require(s['original_controller_exit_code']==1 and s['original_controller_status']=='EXIT1_PAUSE_PRESERVED','ORIGINAL_EXIT1_REQUIRED')
 require(s['original_frozen_validator_status']=='FAIL' and s['original_frozen_validator_error']=='ORDINARY_NUMERIC_SAVED_MINUTE_HEADER_REQUIRED','FROZEN_VALIDATOR_FAILURE_REQUIRED')
 require(s['reporting_recovery_status']=='INDEPENDENT_PASS_LOW_ONLY','SAVED_ONLY_LOW_RECOVERY_REQUIRED')
 require(s['original_exact_six_success'] is False and s['sealed_financial_cases']==1 and s['original_started_financial_cases']==2,'PARTIAL_NOT_COMPLETED_SIX_REQUIRED')
 require(s['case_statuses']=={CELL:'RECOVERED_SAVED_FULL_CALENDAR_PAID_FLAT','2022_CSMOM21_COMMON_TIER_MID_D':'UNVERIFIED_INVALID_ZIP_NO_FINALS','2022_CSMOM21_COMMON_TIER_HIGH_D':'UNSTARTED','2023_CSMOM21_COMMON_TIER_LOW_D':'UNSTARTED','2023_CSMOM21_COMMON_TIER_MID_D':'UNSTARTED','2023_CSMOM21_COMMON_TIER_HIGH_D':'UNSTARTED'},'EXACT_LOW_MID_FOUR_UNSTARTED_REQUIRED')
 require(s['MID_economics_published'] is False and s['unstarted_cells']==4 and s['drain_module_approved_by_this_packet'] is False,'NO_MID_ECONOMICS_OR_DRAIN_APPROVAL')
 require(s['financial_rerun_authorized'] is False and s['claims_cleared']==0 and s['source_or_target_rebuilds']==0,'NO_NEW_AUTHORITY_OR_REBUILD')
def verify(root):
 root=Path(root);m=load(root/'MANIFEST.json');require(m['files']==files(root),'MANIFEST_FILESET_OR_BYTES_MISMATCH')
 require(m['source_verified_commit']==SOURCE_COMMIT and m['sole_future_publication_parent']==SOURCE_COMMIT,'EXACT_VERIFIED_SOURCE_PARENT_REQUIRED')
 for rel,(sha,size) in FROZEN_PINS.items():
  b=raw(root/rel);require(digest(b)==sha and len(b)==size,'EXACT_FROZEN_ORIGINAL_REQUIRED:'+rel)
 require(checker_sha256()==CHECKER,'EXACT_PURE_NATIVE40_CHECKER_REQUIRED')
 transforms=load(root/'PROVENANCE_TRANSFORMATIONS.json')
 for rel,rec in transforms['files'].items():
  require(pin(root/rel)==rec['public_stored_pin'],'PUBLIC_TRANSFORM_PIN_MISMATCH:'+rel)
  b=raw(root/rel);require(digest(b)==rec['public_uncompressed_pin']['SHA256'] and len(b)==rec['public_uncompressed_pin']['bytes'],'PUBLIC_DECOMPRESSED_PIN_MISMATCH')
  require(rec['transformation'] in ('EXACT_ORIGINAL_BYTES','LOSSLESS_GZIP_EXACT_ORIGINAL_BYTES','EXPLICIT_JSON_PRIVACY_DERIVATIVE','EXPLICIT_JSON_SELECTED_FIELD_DERIVATIVE'),'EXPLICIT_TRANSFORM_REQUIRED')
  if rec['transformation'] in ('EXACT_ORIGINAL_BYTES','LOSSLESS_GZIP_EXACT_ORIGINAL_BYTES'):require(rec['original_pin']==rec['public_uncompressed_pin'],'EXACT_ORIGINAL_TRANSFORM_NOT_EXACT')
 a=load(root/'financial/ACCOUNT_FINANCIAL_AUDIT.json.gz');r=load(root/'financial/NATIVE_RESULT.json.gz');p=reconcile_saved_native(a,r,expected_continuation_version=VERSION)
 require(p==load(root/'financial/NATIVE40_RECONSTRUCTION_PROOF.json')==load(root/'financial/PRIMARY_FINANCIAL_RECONCILIATION.json'),'EXACT_SAVED_NATIVE40_PROOF_REQUIRED')
 require(r['primary_financial_reconciliation']==load(root/'financial/LEGACY_PRIMARY_FINANCIAL_RECONCILIATION.json'),'RAW100_DIAGNOSTIC_UNCHANGED_REQUIRED')
 checkpoint=load(root/'financial/TERMINAL_CHECKPOINT.json');pins=load(root/'ORIGINAL_EVIDENCE_HASH_PINS.json')['files']
 for name,sha in checkpoint['files'].items():require(pins['original_cs_mom21_D_20261015_v5/financial_attempts/FIRST6_attempt002/'+CELL+'/'+name]['SHA256']==sha,'ALL20_ORIGINAL_SEALED_PINS_REQUIRED')
 require(checkpoint['checker_SHA256']==CHECKER and checkpoint['all_evidence_fsynced'] is True,'EXACT_ORIGINAL_CHECKPOINT_REQUIRED')
 verify_scope(load(root/'PARTIAL_ATTEMPT_STATUS.json'))
 source=load(root/'SOURCE_PUBLICATION_REFERENCE.json');require(source['source_commit']==SOURCE_COMMIT and source['verified_payload_receipt_pin']['SHA256']=='c39582da0f5ee553c95e348c8c1f21fc034f5f61334d7aa48f44527379254509' and source['every_remote_byte_verified'] is True,'VERIFIED_SOURCE_REFERENCE_REQUIRED')
 frozen=(root/'provenance/cs_saved_frozen.py').read_text();corrected=(root/'provenance/cs_saved_reporting.py').read_text();old='if fortran or dtype.hasobject:';new="if (fortran and member.filename != 'values.npy') or dtype.hasobject:"
 require(frozen.count(old)==1 and corrected==frozen.replace(old,new),'EXACT_SINGLE_REPORTING_PREDICATE_ONLY')
 required_report=build(root);require(required_report==load(root/'summary/REPORT.json'),'EXACT_DERIVED_REPORT_REQUIRED')
 require((root/'summary/REPORT.txt').read_text()==render(required_report),'EXACT_TEXT_REPORT_REQUIRED')
 require((root/'summary/RESULTS.csv').read_text()==csv_text(required_report['rows']),'EXACT_RESULT_TABLE_REQUIRED')
 require((root/'summary/COSTS.csv').read_text()==csv_text(required_report['exact_cost_rows']),'EXACT_COST_TABLE_REQUIRED')
 rm=load(root/'READMAP.json');require(rm['full_minute_regeneration_self_contained'] is False and rm['native40_compact_financial_reconstruction_self_contained'] is True,'HONEST_COMPACT_READMAP_REQUIRED')
 for path in root.rglob('*'):
  if not path.is_file() or '__pycache__' in path.parts:continue
  require(path.suffix not in ('.npz','.npy','.log'),'NO_RAW_ARRAY_OR_LOG_UPLOAD')
  b=raw(path)
  for token in (b'/'+b'workspace/',b'/'+b'tmp/',b'/'+b'home/agent/',b'/'+b'Users/',b'-----BEGIN '+b'PRIVATE KEY',b'github_'+b'pat_',b'gh'+b'p_'):
   require(token not in b,'PRIVATE_PREFIX_OR_SECRET_MARKER:'+str(path.relative_to(root)))
 return dict(schema='COMPACT_RECOVERED_CS_LOW_SAVED_VERIFICATION_V1',status='PASS_COMPACT_SAVED_NATIVE40_AND_EXACT_PARTIAL_SCOPE',native40_ledger_events=p['financial_ledger_rows_checked'],native40_trades=p['trade_rows_checked'],native40_account_funding_rows=p['funding_rows_checked'],original_controller_EXIT1_preserved=True,MID_unverified=True,unstarted_cells=4,all20_sealed_artifact_pins_retained=True,financial_values_or_original_files_changed=False,minute_risk_regenerated=False,account_provider_or_source_runtime_imports=False,source_verified_commit=SOURCE_COMMIT)
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('root',nargs='?',default=str(Path(__file__).resolve().parent));x=a.parse_args();print(json.dumps(verify(Path(x.root)),sort_keys=True))
