#!/usr/bin/env python3
"""Bounded CPU1 saved-only tests, including real tiny financial corruptions."""
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','POLARS_MAX_THREADS','VECLIB_MAXIMUM_THREADS'):os.environ[key]='1'
os.sched_setaffinity(0,{1})
import copy,json,sys,time
from decimal import Decimal,localcontext
from pathlib import Path
from saved_report import load,CELL,VERSION,require
from saved_native_reconciliation import reconcile_saved_native
from verify_packet import verify,verify_scope

def run(root):
 started=time.monotonic();positive=verify(root);a=load(root/'financial/ACCOUNT_FINANCIAL_AUDIT.json.gz');r=load(root/'financial/NATIVE_RESULT.json.gz');tests=[]
 for field in ('free_cash','unpaid_liability','isolated_balance'):
  for step in ('1','1e-40'):
   changed=copy.deepcopy(a);target=changed['positions']['BTCUSDT'] if field=='isolated_balance' else changed
   before=target[field]
   with localcontext() as c:
    c.prec=100;target[field]=str(Decimal(before)+Decimal(step))
   require(target[field]!=before and Decimal(target[field])!=Decimal(before),'GENUINE_CHANGED_DECIMAL_REQUIRED')
   changed=json.loads(json.dumps(changed));require(changed!=a,'SERIALIZED_MUTATION_MUST_CHANGE')
   try:reconcile_saved_native(changed,r,expected_continuation_version=VERSION)
   except ValueError as e:tests.append(dict(field=field,increment=step,before=before,after=target[field],rejected=True,error=str(e)))
   else:raise AssertionError('GENUINE_FINANCIAL_CORRUPTION_NOT_REJECTED')
 scope=load(root/'PARTIAL_ATTEMPT_STATUS.json');scopes=[]
 changes=[('false_full_six',lambda s:s.update(original_exact_six_success=True)),('false_MID_complete',lambda s:s['case_statuses'].update({'2022_CSMOM21_COMMON_TIER_MID_D':'FULL_CALENDAR_ACTUAL_PAID_MARKET_FLAT'})),('false_MID_economics',lambda s:s.update(MID_economics_published=True)),('erase_original_failure',lambda s:s.update(original_controller_exit_code=0)),('false_drain_approval',lambda s:s.update(drain_module_approved_by_this_packet=True))]
 for name,change in changes:
  changed=copy.deepcopy(scope);change(changed)
  try:verify_scope(changed)
  except ValueError as e:scopes.append(dict(name=name,rejected=True,error=str(e)))
  else:raise AssertionError('FALSE_SCOPE_CLAIM_NOT_REJECTED')
 return dict(schema='AUTHOR_BOUNDED_PUBLIC_SAVED_ONLY_TESTS_V1',status='PASS',positive=positive,genuine_financial_corruptions=tests,false_scope_claims=scopes,original_files_changed=False,account_provider_or_source_runtime_imports=False,financial_replay=False,CPU_affinity=sorted(os.sched_getaffinity(0)),numerical_pools=1,thread_environment={k:os.environ[k] for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','POLARS_MAX_THREADS','VECLIB_MAXIMUM_THREADS')},wall_seconds=time.monotonic()-started)
if __name__=='__main__':print(json.dumps(run(Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent),sort_keys=True))
