#!/usr/bin/env python3
"""Generated-only regression from exact frozen/corrected decoder source AST."""
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','POLARS_MAX_THREADS','VECLIB_MAXIMUM_THREADS'):os.environ[key]='1'
os.sched_setaffinity(0,{1})
import ast,hashlib,io,json,stat,sys,zipfile
from pathlib import Path
from types import SimpleNamespace
import numpy as np
from saved_report import load,require

def decoder(root,name):
 source=(root/'provenance'/name).read_text();node=next(n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name=='saved_minute');text=ast.get_source_segment(source,node)
 env=dict(np=np,BytesIO=io.BytesIO,zipfile=zipfile,stat=stat,r=SimpleNamespace(LIMITS={'per_case_output_bytes':1073741824}));exec(compile(text,name+':saved_minute','exec'),env);return env['saved_minute']
def encode(values,columns):
 out=io.BytesIO();np.savez_compressed(out,values=values,columns=np.asarray(columns));return out.getvalue()
def run(root):
 frozen=decoder(root,'cs_saved_frozen.py');corrected=decoder(root,'cs_saved_reporting.py');checks=[]
 for order in ('C','F'):
  values=np.array([[1.,-0.,3.5],[4.25,5.,6.]],dtype=np.float64,order=order);b=encode(values,['a','b','c']);before=hashlib.sha256(b).hexdigest();out,cols=corrected(b,2);require(np.array_equal(out.view('uint64'),values.view('uint64')) and cols==['a','b','c'],'BIT_EXACT_GENERATED_LAYOUT_REQUIRED')
  try:frozen(b,2)
  except ValueError:require(order=='F','FROZEN_C_MUST_PASS');status='FAIL'
  else:require(order=='C','FROZEN_F_MUST_FAIL');status='PASS'
  require(hashlib.sha256(b).hexdigest()==before,'NPZ_MUST_REMAIN_UNCHANGED');checks.append(dict(case='generated_'+order,frozen=status,corrected='PASS',NPZ_unchanged=True))
 negatives=[('float32',encode(np.ones((2,2),dtype='float32'),['a','b']),2),('object',encode(np.array([[object()]],dtype=object),['a']),1),('nonfinite',encode(np.array([[float('nan')]]),['a']),1),('wrong_rows',encode(np.ones((2,2)),['a','b']),3),('duplicate_columns',encode(np.ones((2,2)),['a','a']),2),('bad_zip',b'not a zip',1),('row_bound',encode(np.ones((1,1)),['a']),525601)]
 for name,b,rows in negatives:
  try:corrected(b,rows)
  except (ValueError,zipfile.BadZipFile):checks.append(dict(case=name,rejected=True))
  else:raise AssertionError('INVALID_GENERATED_CODEC_ACCEPTED:'+name)
 # Polars is optional for users of the stdlib-only financial checker. When present,
 # exercise its real default matrix and the exact original writer AST statements.
 try:import polars as pl
 except ImportError:polars=dict(status='NOT_RUN_POLARS_NOT_INSTALLED')
 else:
  receipt=load(root/'reviews/INDEPENDENT_PARSER_REVIEW_RECEIPT.json');proof=receipt['default_Polars_and_exact_original_writer'];minute=pl.DataFrame({'a':[1.,2.],'b':[3.,4.]});env=dict(minute=minute,np=np)
  exec(compile(proof['assignment_source'],'saved-original-assignment','exec'),env);values=env['values'];cols=env['columns'];require(values.flags.f_contiguous,'REAL_DEFAULT_POLARS_F_REQUIRED')
  b=encode(values,cols);frozen_error=None
  try:frozen(b,2)
  except ValueError as e:frozen_error=str(e)
  require(frozen_error=='ORDINARY_NUMERIC_SAVED_MINUTE_HEADER_REQUIRED','EXACT_FROZEN_POLARS_FAILURE_REQUIRED');decoded,c=corrected(b,2);require(np.array_equal(decoded.view('uint64'),values.view('uint64')),'EXACT_POLARS_BITS_REQUIRED')
  polars=dict(status='PASS_DEFAULT_POLARS_F_FROZEN_FAIL_CORRECTED_PASS',threads=pl.thread_pool_size(),assignment_source=proof['assignment_source'],original_writer_source=proof['writer_source'],financial_or_source_runtime_imported=False)
 return dict(schema='PUBLIC_GENERATED_SAVED_CODEC_ONLY_REGRESSIONS_V1',status='PASS',CPU_affinity=sorted(os.sched_getaffinity(0)),numerical_pools=1,checks=checks,default_polars=polars,no_accounts_providers_sources_targets_or_historical_arrays_used=True)
if __name__=='__main__':print(json.dumps(run(Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent),sort_keys=True))
