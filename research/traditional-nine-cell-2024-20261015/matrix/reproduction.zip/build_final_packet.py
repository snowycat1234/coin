"""Project the exact independently sealed 2024 matrix; no finance imports/replay."""
from pathlib import Path
import csv,hashlib,json,zipfile
R=Path(__file__).resolve().parent.parent
I=R/'traditional_three_tier_independent_review_20261015'
C=R/'traditional_three_tier_freeze_20261015'
O=R/'traditional_2024_nine_cell_matrix_public_recovery_20261015_v1'
REPORT_SHA='e276aef14d20c25e64a1c682e9a9fc48113c5165a87be47989e370a8ce373506'
AUDIT_SHA='a2a956b907d285b0ccd0cde13084a8b66e7f41be00b5e552284faab2e4c203ee'

def sha(b):return hashlib.sha256(b).hexdigest()
def put(n,b):p=O/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
def jp(n,v):put(n,(json.dumps(v,indent=2,allow_nan=False)+'\n').encode())
def pct(value):return 'undefined' if value is None else f'{value*100:.6f}%'
def build():
 report_raw=(I/'ANNUAL_2024_FINAL_HONEST_MATRIX_REPORT.json').read_bytes();audit_raw=(I/'ANNUAL_2024_MATRIX_FINAL_INDEPENDENT_AUDIT_RECEIPT.json').read_bytes()
 assert sha(report_raw)==REPORT_SHA and sha(audit_raw)==AUDIT_SHA
 report=json.loads(report_raw);audit=json.loads(audit_raw)
 assert report['publication_eligible'] and report['status_counts']['PAID_FULL_YEAR']==3 and report['status_counts']['NATIVE_ECONOMIC_HALT_UNPAID_PARTIAL']==6 and report['status_counts']['ENGINEERING_BLOCKED']==0
 assert len({row['config'] for row in report['rows']})==9
 O.mkdir(exist_ok=False);put('MATRIX.json',report_raw);put('FINAL_INDEPENDENT_AUDIT_RECEIPT.json',audit_raw)
 for name in ('REPORTING_2024_FINAL_INDEPENDENT_REVIEW.json','ANNUAL_2024_STATIC50_BATCH_INDEPENDENT_REVIEW.json',
  'ANNUAL_2024_H090_BATCH_INDEPENDENT_REVIEW.json','ANNUAL_2024_VOL_MANAGED_HOLD_BATCH_INDEPENDENT_REVIEW.json',
  'ANNUAL_2024_SIX_NATIVE_HALT_SOURCE_CROSSINGS_ADDENDUM.json','ANNUAL_2024_HOLD_ALL_THREE_PEAK_RISK_ADDENDUM.json'):
  put('reviews/'+name,(I/name).read_bytes())
 for row in report['rows']:
  config=row['config'];old=config=='STATIC50_MID';p=C/('actual_2024_pilot_attempt001' if old else 'actual_2024_remaining_attempt001')/config
  for name in ('RESULT.json','OBSERVED_RISK.json','CASE_RECEIPT.json'):
   put('cases/'+config+'/'+name,(p/name).read_bytes())
  n='ANNUAL_2024_PILOT_FINAL_INDEPENDENT_REVIEW_RECEIPT.json' if old else 'ANNUAL_2024_MATRIX_'+config+'_SAVED_REVIEW.json'
  put('reviews/'+n,(I/n).read_bytes())
 for name in ('summarize_matrix.py','test_summarize_matrix.py','TEST_LOG.txt'):
  put('report_code/'+name,(R/'traditional_2024_matrix_reporting_20261015'/name).read_bytes())
 put('report_code/test_reporting_2024_generated_independent.py',(I/'test_reporting_2024_generated_independent.py').read_bytes())
 columns=['config','terminal_status','completed_minutes','full_calendar','paid_annual_return','marked_partial_return','all_observation_MDD','MDD_scope',
  'end_UTC','residual_marked_notional','unpaid_liability','native_account_status','whole_wallet_marked_NAV','actual_liquidation_fills',
  'fees_USDT','execution_cost_USDT','funding_USDT','actual_gross_max','actual_gross_mean','realized_daily_vol_annualized',
  'realized_vol_sample_complete_days','forecast_vol_max','forecast_breach_minutes','forecast_breach_max_absolute','same_period_full_annual_excess_vs_HOLD','excess_status']
 with (O/'MATRIX.csv').open('x',newline='') as f:
  writer=csv.DictWriter(f,fieldnames=columns);writer.writeheader()
  for row in report['rows']:writer.writerow({k:row.get(k) for k in columns})
 text=['# 2024 traditional strategies: all nine requested cells retained','',
  'The first frozen 2024 matrix is complete as nine terminal experiments: three HOLD cells completed the full paid-flat year; six STATIC50/H090 cells stopped with native isolated-position economic HALTs. There were no engineering failures or financial reruns. A terminal experiment is not necessarily a complete annual return.','',
  '| Config | Terminal | Written minutes | Paid full-year return | Marked partial return | Path MDD |',
  '|---|---|---:|---:|---:|---:|']
 for row in report['rows']:
  label='Paid full year' if row['terminal_status']=='PAID_FULL_YEAR' else row['native_account_status']
  text.append(f"| {row['config']} | {label} | {row['completed_minutes']} | {pct(row['paid_annual_return'])} | {pct(row['marked_partial_return'])} | {pct(row['all_observation_MDD'])} |")
 text.extend(['','MDD is full-year only for paid full-year rows, and partial-to-stop for HALTs. Returns from different stop dates are not a common-period comparison. Annual paid return/APR is null for all six HALTs. No annual mean excluding halted cells, cross-risk-tier mean, or actual-riskmatched excess is claimed. Full-year STATIC50/H090 excess over HOLD is undefined because those comparators halted.','',
  '## What the stops mean','',
  'The LOW pair stopped November16 09:24UTC on an XRP short whose isolated equity became negative. The MID pair stopped November6 02:57UTC when DOGE isolated equity fell below maintenance. The HIGH pair stopped November6 03:08UTC when DOGE isolated equity became negative. Each whole-wallet marked NAV remained positive. The native name BANKRUPT_HALT does not imply the whole wallet went to zero. Exact witnesses, stop clocks, retained positions and uncharged future funding are preserved in the linked batch evidence and included independent receipts.','',
  'No liquidation execution was simulated, no margin was transferred, and no stopped baseline account was restarted or extended. Actual liquidation-fill count is zero because the baseline account stops with a witness. Global free cash does not automatically support an isolated short under the frozen no-topup policy. A separately registered bounded-margin/position-liquidation continuation study is a new policy, not a repair to these results.','',
  'All same-tier STATIC50/H090 saved minute matrices, actual trade rows and applied funding rows are exactly equal over their observed paths. These requested cells were run separately; their observed equality is not independent alpha or a general mathematical-equivalence claim.','',
  '## Risk and execution qualification','',
  'This is a native-account offline proxy with coarse assumed quantity steps BTC0.001, ETH0.01, SOL1, XRP100 and DOGE1000, not verified historical/current venue filters or venue liquidation execution. Fresh entry guards passed all1196 independently inspected actual OPEN legs. Admission volatility budgets do not ensure continuous held-inventory forecast volatility, realized risk or ongoing isolated-position solvency. The own-path peak-risk addendum separately explains all three HOLD peaks using native covariance/mark drift and coarse sublot remainders.','',
  'HOLD LOW/MID/HIGH realized daily annualized volatility is6.0994%/11.1768%/16.4504%, versus nominal5%/10%/15% sizing targets. Forecast peaks are10.6047%/15.8447%/22.2013%; breach-minute counts280778/252443/242940. These are same-parameter-budget comparisons, not equal-realized-risk matches. Halted-row volatility uses its explicitly reported partial sample of complete UTC days.','',
  'All cells use fresh10000USDT, isolated1x, common1000cashfloor/8500isolated-margin ceiling, BASE27 friction/fees, original prior-quote capacity, charged partial ladder, true-reduction priority and paid terminal60. Funding remains raw-as-fraction conditional; provider arrival, native exchange filters and liquidation equivalence are unproved. The separately admitted causal2024 mark adapter carries only the last genuine completed mark across two missing observations and blocks increases until genuine recovery is actually installed. No stale-interval order attempt occurred in these historical cases, so zero saved blocks is not an observed denial test; generated owned-account tests cover that seam.','',
  '## Audit and recovery','',
  f"Independent saved-only audit checked{audit['total_actual_trade_legs_checked']} trade legs,{audit['total_applied_funding_receipts_checked']} applied funding receipts and{audit['total_saved_completed_minute_rows_checked']} written minute rows. Maximum Decimal NAV reconciliation error is1E-35 USDT; actual-opening admission violations0. Maximum case wall230.21seconds/RSS787.31MB/final output92.75MB, within600seconds/1CPU/2GBRSS/4GBAS/250MB per case. No financial account was rerun for review or packaging.",
  '', 'MATRIX.json is the exact independently sealed machine-readable report, not a recomputed rendering. MATRIX.csv is a column projection. Each case RESULT/OBSERVED_RISK/CASE_RECEIPT and all final review receipts are included. Full unique economic rows, lossless funding journals and deterministic minute/daily evidence are in the separately hash-pinned three-tier batch packages. Large raw source, full minute matrices and duplicate snapshots are not duplicated here. Public base code/source pins are in PUBLIC_BASES.json. Historical2023/2024 are seen development evidence, not untouched OOS. Essential2025 source remains blocked; a genuinely untouched future window must be fixed after final selection and executable feed readiness.'])
 put('REPORT.md',('\n'.join(text)+'\n').encode())
 put('README.md',b'Read REPORT.md and MATRIX.json first. Nine terminal experiments comprise three paid full years and six retained unpaid economic HALTs. Verify hashes with verify_packet.py. No financial rerun, source download or financial-policy change was performed for this report packet.\n')
 jp('PUBLIC_BASES.json',dict(repository='snowycat1234/coin',
  source2024=dict(commit='b3de53d613489ec90f9c70874cdf712cf70db5a8',prefix='research/native-2024-source-recovery-20261015'),
  causal_module=dict(commit='d1dae15a2d964fad986c15496f8439728f56f812',prefix='research/traditional-2024-causal-module-20261015'),
  terminal_controller=dict(commit='db4d5c0a068276886fbb492945e8b2638e54f661',prefix='research/traditional-2024-terminal-controller-20261015'),
  original_mid_halt=dict(commit='545185a72306eb71a1fda8bf62b3ec12617e0ca7',prefix='research/traditional-static50-mid-2024-halt-20261015'),
  detailed_batch_archive_identities=[dict(file=n,SHA256=h) for n,h in [
   ('traditional_2024_static50_batch_public_recovery_20261015_v2.zip','39eceef1bb9daffcdce5002be47ba32fc676a7f94d8e4f14d8e474fcf6df6b70'),
   ('traditional_2024_h090_batch_public_recovery_20261015_v2.zip','a2b47c4ef5f2af577a54d56b770b8e6922fa96c39423362ed5fb2bc8fa5d4dbb'),
   ('traditional_2024_vol_managed_hold_batch_public_recovery_20261015_v1.zip','e646568978355504cddbf8d7e2b515f9fb8e8872b1b5285714259a60372772a8')]]))
 put('verify_packet.py',b"from pathlib import Path\nimport hashlib,json\nr=Path(__file__).resolve().parent\nm=json.loads((r/'MANIFEST.json').read_bytes())\nfor n,v in m['files'].items():\n b=(r/n).read_bytes();assert len(b)==v['bytes'] and hashlib.sha256(b).hexdigest()==v['SHA256'],n\nprint('PASS',len(m['files']),'exact files')\n")
 put('build_final_packet.py',Path(__file__).read_bytes())
 files={}
 for p in sorted(O.rglob('*')):
  if p.is_file():
   b=p.read_bytes()
   if p.suffix in ('.json','.py','.md','.txt'):
    for bad in (b'/'+b'workspace/',b'/home/'+b'agent/',b'/'+b'tmp/'):
     if bad in b:raise ValueError('PRIVATE_PATH_SCAN:'+str(p))
   files[str(p.relative_to(O))]=dict(bytes=len(b),SHA256=sha(b))
 jp('MANIFEST.json',dict(schema='EXACT_REVIEWED2024_NINE_CELL_HONEST_MATRIX_PUBLIC_RECOVERY_V1',files=files,
  report_SHA256=REPORT_SHA,final_financial_audit_SHA256=AUDIT_SHA,actual_financial_reruns=0))
 zpath=O.with_suffix('.zip')
 with zipfile.ZipFile(zpath,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p in sorted(O.rglob('*')):
   if p.is_file():z.write(p,str(p.relative_to(O)))
 b=zpath.read_bytes();(O/'ARCHIVE.json').write_text(json.dumps(dict(file=zpath.name,bytes=len(b),SHA256=sha(b),files=len(files)+1),indent=2)+'\n')
 print(zpath.name,len(b),sha(b))

if __name__=='__main__':build()
