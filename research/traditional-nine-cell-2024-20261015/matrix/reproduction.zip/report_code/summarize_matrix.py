"""Finite saved-output status/report only. No account import, run or replay."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os
from decimal import Decimal
ROOT=Path(__file__).resolve().parent.parent
CORE=ROOT/'traditional_three_tier_freeze_20261015'
STRATEGIES=('STATIC50','H090','VOL_MANAGED_HOLD');TIERS=('LOW','MID','HIGH')
CONFIGS=tuple(s+'_'+t for s in STRATEGIES for t in TIERS)
PREP_SHA='657317bb8c025d8ab926e66a57078bfcf2a8d684be6dcc40a0ac8e7502b29b46'
GO_OLD='a6a3f4b36a7fe008d99a140b32bc41a86f14c8bae281f068aac3b684c8a43851'
GO_NEW='ab8f768beef74b0d45d8231a743fa5d25a919a6230cb166a71fd56d891e9a4b7'
MID_REVIEW='9f955374797b9752cfaca43447e16336bb6ebb8f77669f6f3dc1216ded93dea6'

def sha(b):return hashlib.sha256(b).hexdigest()
def parse(body):
 def reject(value):raise ValueError('NONFINITE_JSON_NOT_REPORTABLE:'+value)
 return json.loads(body,parse_constant=reject)
def read(p):return parse(Path(p).read_bytes())
def utc(us):return datetime.fromtimestamp(us/1e6,timezone.utc).isoformat() if us is not None else None
def finite(value):
 try:v=Decimal(str(value))
 except Exception as error:raise ValueError('FINITE_REPORTED_ECONOMICS_REQUIRED') from error
 if not v.is_finite():raise ValueError('FINITE_REPORTED_ECONOMICS_REQUIRED')
 return v
def file_sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as handle:
  for block in iter(lambda:handle.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def verify_evidence(directory,identities,captured=None):
 if not isinstance(identities,dict) or not identities:raise ValueError('NONEMPTY_REVIEWED_EVIDENCE_MAP_REQUIRED')
 captured=captured or {}
 for name,digest in identities.items():
  if Path(name).name!=name or len(digest)!=64 or any(c not in '0123456789abcdef' for c in digest):
   raise ValueError('SAFE_EXACT_CASE_EVIDENCE_IDENTITY_REQUIRED')
  actual=sha(captured[name]) if name in captured else file_sha(Path(directory)/name)
  if actual!=digest:raise ValueError('REVIEWED_SAVED_EVIDENCE_CHANGED:'+name)

def cell_row(config,directory,expected_go,prep,*,review_reference=None):
 p=Path(directory);base=dict(config=config,strategy=config.rsplit('_',1)[0],tier=config.rsplit('_',1)[1],year=2024,
  requested_calendar=[1704067200000000,1735689600000000],requested_minutes=527040,
  terminal_status='QUEUED_ROOT_GO_BOUND',full_calendar=False,paid_annual_return=None,marked_partial_return=None,
  annual_APR=None,same_period_full_annual_excess_vs_HOLD=None,riskmatched_excess=None,
  result_review=dict(status='PENDING_SAVED_REVIEW'),financial_rerun_required=False)
 if not p.exists():return base
 failure=p/'CASE_FAILURE.json';receipt=p/'CASE_RECEIPT.json'
 if not receipt.exists():
  base['terminal_status']='ENGINEERING_BLOCKED' if failure.exists() else 'RUNNING_OR_EVIDENCE_WRITE_PENDING'
  if failure.exists():base['failure_SHA256']=sha(failure.read_bytes())
  return base
 old=config=='STATIC50_MID' and expected_go==GO_OLD
 barrier=p.parent/('CASE_TERMINAL_'+config+'.json')
 if not old and not failure.exists() and not barrier.exists():
  base['terminal_status']='RUNNING_OR_EVIDENCE_WRITE_PENDING';return base
 rb=receipt.read_bytes();r=parse(rb);result_raw=(p/'RESULT.json').read_bytes();result=parse(result_raw);e=result['economics']
 if (r['config']!=config or result['config']!=config or r['root_GO_SHA256']!=expected_go
   or r['preparation_SHA256']!=PREP_SHA or r['code_identity']!=prep['code_identity']
   or r['source_identity']!=prep['source_identity'] or r['calendar']!=base['requested_calendar']
   or r['required_minutes']!=527040 or r['original_interpolated_mark_execution_admitted'] is not False
   or result['target_meta']['source_target_identity']!=prep['target_identity']['SHA256_by_config'][config]
   or result['target_meta']['root_GO_SHA256']!=expected_go or result['target_meta']['preparation_SHA256']!=PREP_SHA
   or result['target_meta']['config']!=config or result['target_meta']['original_interpolated_mark_execution_admitted'] is not False):
  raise ValueError('EXACT_FINITE_SAVED2024_CELL_REQUIRED:'+config)
 if barrier.exists() and read(barrier)['case_receipt_SHA256']!=sha(rb):raise ValueError('ATOMIC_CONTROLLER_TERMINAL_RECEIPT_HASH_REQUIRED')
 if failure.exists() and not old:status='ENGINEERING_BLOCKED'
 elif r['paid_comparison_eligible'] is True:
  if r['completed_minutes']!=527040 or not e['paid_flat'] or not e['full_calendar'] or r['account_stop_us'] is not None:
   raise ValueError('PAID_FULL_ANNUAL_SCOPE_REQUIRED')
  if (e['liquidation_required_halt'] or e['bankruptcy_halt'] or result['summary']['account_status']!='ACTIVE'
      or finite(e['residual_marked_notional'])!=0 or finite(e['unpaid_liability'])!=0):
   raise ValueError('PAID_SCOPE_CANNOT_OVERRIDE_NATIVE_HALT_OR_RESIDUAL')
  finite(e['paid_net_return'])
  status='PAID_FULL_YEAR'
 elif (e['liquidation_required_halt'] or e['bankruptcy_halt']) and (old or not failure.exists()):
  if (e['paid_flat'] or e['paid_net_return'] is not None or r['account_stop_us'] is None
      or e['full_calendar'] is not False or not 0<=r['completed_minutes']<527040
      or not 1704067200000000<r['account_stop_us']<=1735689600000000
      or 1704067200000000+r['completed_minutes']*60000000>r['account_stop_us']
      or bool(e['liquidation_required_halt'])==bool(e['bankruptcy_halt'])
      or result['summary']['account_status']!=('BANKRUPT_HALT' if e['bankruptcy_halt'] else 'LIQUIDATION_REQUIRED_HALT')):
   raise ValueError('NATIVE_HALT_CANNOT_HAVE_ANNUAL_PAID_RETURN')
  finite(e['marked_net_return'])
  status='NATIVE_ECONOMIC_HALT_UNPAID_PARTIAL'
 else:status='ENGINEERING_BLOCKED'
 risk_raw=(p/'OBSERVED_RISK.json').read_bytes();risk=parse(risk_raw)
 base.update(terminal_status=status,completed_minutes=r['completed_minutes'],
  full_calendar=bool(e['full_calendar']) if status=='PAID_FULL_YEAR' else False,
  end_us=r['account_stop_us'] if r['account_stop_us'] is not None else 1735689600000000,
  end_UTC=utc(r['account_stop_us'] if r['account_stop_us'] is not None else 1735689600000000),
  paid_annual_return=e['paid_net_return'] if status=='PAID_FULL_YEAR' else None,
  marked_partial_return=e['marked_net_return'] if status!='PAID_FULL_YEAR' else None,
  all_observation_MDD=e['all_observation_max_drawdown'],MDD_scope='FULL_YEAR' if status=='PAID_FULL_YEAR' else 'PARTIAL_TO_NATIVE_STOP',
  residual_marked_notional=e['residual_marked_notional'],unpaid_liability=e['unpaid_liability'],
  liquidation_required_halt=e['liquidation_required_halt'],bankruptcy_halt=e['bankruptcy_halt'],
  native_account_status=result['summary']['account_status'],whole_wallet_marked_NAV=result['summary']['NAV'],
  native_halt_witness=result['summary'].get('halt_witness'),
  actual_liquidation_fills=e['actual_liquidation_fills'],liquidation_fill_model=e['liquidation_fill_model'],
  fees_USDT=e['fees_USDT'],execution_cost_USDT=e['execution_cost_USDT'],funding_USDT=e['funding_USDT'],
  actual_gross_max=risk['gross_exposure_max'],actual_gross_mean=risk['gross_exposure_mean'],
  realized_daily_vol_annualized=risk['realized_daily_simple_return_annual_volatility'],
  realized_vol_sample_complete_days=risk['complete_calendar_days'],
  forecast_vol_max=risk['forecast_annual_volatility_max'],forecast_breach_minutes=risk['forecast_volatility_breach_minutes'],
  forecast_breach_max_absolute=risk['forecast_volatility_breach_max_absolute'],
  receipt_SHA256=sha(rb),result_SHA256=sha(result_raw),root_GO_SHA256=expected_go,
  source_target_identity=result['target_meta']['source_target_identity'],
  observed_risk_SHA256=sha(risk_raw),
  do_not_rerun=status in ('PAID_FULL_YEAR','NATIVE_ECONOMIC_HALT_UNPAID_PARTIAL'))
 if e['bankruptcy_halt']:
  witness=result['summary']['halt_witness'];exact=witness.get('decimal_strings',{})
  base['native_bankruptcy_triggers']=[label for label,key in (
   ('ISOLATED_LEG_EQUITY_NONPOSITIVE','isolated_equity'),('WHOLE_WALLET_NAV_NONPOSITIVE','NAV'))
   if key in witness and finite(exact.get(key,witness[key]))<=0]
  if finite(e['unpaid_liability'])>0:base['native_bankruptcy_triggers'].append('UNPAID_LIABILITY_POSITIVE')
  if not base['native_bankruptcy_triggers']:raise ValueError('NATIVE_BANKRUPTCY_REQUIRES_ACTUAL_RETAINED_TRIGGER')
  base['native_BANKRUPT_HALT_does_not_imply_whole_wallet_zero']=True
 if review_reference:
  rr=Path(review_reference['path']).read_bytes()
  if sha(rr)!=review_reference['SHA256']:raise ValueError('EXACT_SAVED_RESULT_REVIEW_REQUIRED')
  v=parse(rr)
  if old:
   if (v.get('schema')!='INDEPENDENT_SAVED2024_PILOT_FINAL_REVIEW_RECEIPT_V1'
       or v.get('status')!='PASS_EXPECTED_NATIVE_ECONOMIC_HALT_WITH_HONEST_PARTIAL_OUTPUTS'
       or v.get('source_code_identity')!=prep['code_identity']):
    raise ValueError('EXACT_ORIGINAL_PILOT_REVIEW_SCHEMA_REQUIRED')
  elif (v.get('schema')!='INDEPENDENT_SAVED2024_MATRIX_CELL_REVIEW_V1' or 'errors' not in v or v['errors']!=[]
      or v.get('config')!=config or v.get('status')!=('PASS_SAVED_FULL_YEAR_PAID_FLAT' if status=='PAID_FULL_YEAR' else 'PASS_SAVED_NATIVE_ECONOMIC_HALT')):
   raise ValueError('EXACT_MATRIX_REVIEW_SCHEMA_STATUS_CONFIG_AND_ERRORS_REQUIRED')
  saved=v.get('saved_evidence_SHA256',v.get('saved_case_evidence_SHA256',{}))
  if (v.get('root_GO_SHA256')!=expected_go
      or v.get('preparation_SHA256')!=PREP_SHA
      or v.get('config',config)!=config or v.get('errors',[])!=[]
      or saved.get('CASE_RECEIPT.json')!=sha(rb)
      or saved.get('RESULT.json')!=sha(result_raw) or saved.get('OBSERVED_RISK.json')!=sha(risk_raw)):
   raise ValueError('REVIEW_MUST_BIND_EXACT_ORIGINAL_CASE_RECEIPT_AND_GO')
  captured={'CASE_RECEIPT.json':rb,'RESULT.json':result_raw,'OBSERVED_RISK.json':risk_raw}
  verify_evidence(p,saved,captured)
  if old:
   for key,name in [('saved_finance_review_SHA256','ANNUAL_2024_PILOT_SAVED_FINANCE_HALT_REVIEW.json'),
       ('saved_quality_review_SHA256','ACTUAL_2024_PILOT_SAVED_QUALITY_REVIEW.json')]:
    detail=(Path(review_reference['path']).parent/name).read_bytes()
    if sha(detail)!=v.get(key):raise ValueError('EXACT_ORIGINAL_PILOT_FINANCE_QUALITY_CHAIN_REQUIRED')
    linked=parse(detail)
    if key=='saved_finance_review_SHA256':
     if (linked.get('schema')!='INDEPENDENT_SAVED_PARTIAL2024_PILOT_FINANCE_AND_HALT_REVIEW_V1'
         or linked.get('status')!='PASS_EXPECTED_NATIVE_ECONOMIC_HALT_SAVED_EVIDENCE' or linked.get('errors')!=[]
         or linked.get('root_GO_SHA256')!=expected_go or linked.get('preparation_SHA256')!=PREP_SHA):
      raise ValueError('EXACT_ORIGINAL_PILOT_FINANCE_REVIEW_REQUIRED')
     verify_evidence(p,linked['saved_evidence_SHA256'],captured)
    elif (linked.get('schema')!='INDEPENDENT_ACTUAL2024_STATIC50_MID_SAVED_QUALITY_REVIEW_V1'
        or linked.get('status')!='PASS_SAVED_CAUSAL_VALUATION_AND_NO_STALE_OPEN_PARTIAL_HALT_ONLY'):
     raise ValueError('EXACT_ORIGINAL_PILOT_QUALITY_REVIEW_REQUIRED')
  base['result_review']=dict(status=v['status'],SHA256=sha(rr))
 return base

def build(*,review_map=None):
 prepraw=(CORE/'annual_2024_source_preparation_attempt002/PREPARATION.json').read_bytes()
 if sha(prepraw)!=PREP_SHA:raise ValueError('EXACT_FROZEN_PREPARATION_REQUIRED')
 prep=json.loads(prepraw);reviews=review_map or {}
 if 'STATIC50_MID' not in reviews:
  reviews={**reviews,'STATIC50_MID':dict(path=str(ROOT/'traditional_three_tier_independent_review_20261015/ANNUAL_2024_PILOT_FINAL_INDEPENDENT_REVIEW_RECEIPT.json'),SHA256=MID_REVIEW)}
 rows=[]
 for c in CONFIGS:
  old=c=='STATIC50_MID';folder=CORE/('actual_2024_pilot_attempt001' if old else 'actual_2024_remaining_attempt001')
  try:
   if sha((folder/'ROOT_GO.json').read_bytes())!=(GO_OLD if old else GO_NEW):raise ValueError('EXACT_ORIGINAL_ROOT_GO_REQUIRED')
   row=cell_row(c,folder/c,GO_OLD if old else GO_NEW,prep,review_reference=reviews.get(c))
  except Exception as error:
   row=dict(config=c,tier=c.rsplit('_',1)[1],year=2024,terminal_status='ENGINEERING_BLOCKED',
    full_calendar=False,paid_annual_return=None,annual_APR=None,marked_partial_return=None,
    engineering_block_reason=type(error).__name__+': '+str(error),evidence_directory=str(folder/c),
    result_review=dict(status='BLOCKED_UNVALIDATED_EVIDENCE_OR_REVIEW'),financial_rerun_required=False)
  rows.append(row)
 return assemble_report(rows)

def assemble_report(rows):
 if len(rows)!=9 or {r['config'] for r in rows}!=set(CONFIGS):raise ValueError('EXACT_NINE_REQUESTED_CONFIG_ROWS_REQUIRED')
 by={r['config']:r for r in rows}
 blocked=any(r['terminal_status']=='ENGINEERING_BLOCKED' for r in rows)
 for row in rows:
  row['same_period_full_annual_excess_vs_HOLD']=None
  row['riskmatched_excess']=None
  if row['terminal_status']!='PAID_FULL_YEAR':row['paid_annual_return']=None
  hold=by['VOL_MANAGED_HOLD_'+row['tier']]
  if not blocked and row['terminal_status']==hold['terminal_status']=='PAID_FULL_YEAR':
   row['same_period_full_annual_excess_vs_HOLD']=row['paid_annual_return']-hold['paid_annual_return']
   row['excess_status']='SAME_PARAMETER_BUDGET_FULL_YEAR_NOT_REALIZED_RISK_MATCHED'
  else:row['excess_status']='UNDEFINED_UNLESS_BOTH_FULL_YEAR_PAID'
 counts={s:sum(r['terminal_status']==s for r in rows) for s in
  ('PAID_FULL_YEAR','NATIVE_ECONOMIC_HALT_UNPAID_PARTIAL','ENGINEERING_BLOCKED','RUNNING_OR_EVIDENCE_WRITE_PENDING','QUEUED_ROOT_GO_BOUND')}
 terminal=sum(counts[k] for k in ('PAID_FULL_YEAR','NATIVE_ECONOMIC_HALT_UNPAID_PARTIAL','ENGINEERING_BLOCKED'))
 reviewed=all(str(r.get('result_review',{}).get('status','')).startswith('PASS_') for r in rows)
 return dict(schema='FINITE2024_NINE_REQUESTED_CELLS_HONEST_TERMINAL_MATRIX_V1',UTC=datetime.now(timezone.utc).isoformat(),
  report_status='BLOCKED_EVIDENCE_OR_REVIEW' if blocked else 'ALL_TERMINALS_INDEPENDENTLY_REVIEWED' if terminal==9 and reviewed else 'PENDING_TERMINALS_OR_SAVED_REVIEW',
  publication_eligible=bool(not blocked and terminal==9 and reviewed),comparisons_eligible=not blocked,
  requested_cells=9,status_counts=counts,terminal_cells=terminal,all_requested_cells_terminal=terminal==9,
  all_cells_full_year_paid=counts['PAID_FULL_YEAR']==9,annual_average_return=None,
  annual_average_policy='NOT_COMPUTED_EXCLUDING_HALTED_CELLS',riskmatched_excess_method='NOT_PREREGISTERED_NOT_CLAIMED',
  comparison_role='SAME_NOMINAL_BUDGET_WITH_FULL_OR_PARTIAL_PATH_QUALIFICATION',
  execution_label='NATIVE_ACCOUNT_OFFLINE_PROXY_WITH_COARSE_ASSUMED_QUANTITY_PROFILE',
  ongoing_isolated_solvency_guaranteed_by_admission_vol_budget=False,
  original_interpolated_mark_execution_admitted=False,rows=rows)

def save_checkpoint(path,value):
 p=Path(path);p.parent.mkdir(parents=True,exist_ok=True);t=p.with_name(p.name+'.partial')
 with t.open('xb') as f:f.write((json.dumps(value,indent=2,allow_nan=False)+'\n').encode());f.flush();os.fsync(f.fileno())
 os.link(t,p);t.unlink()

if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('--output',required=True);p.add_argument('--review-map')
 a=p.parse_args();save_checkpoint(a.output,build(review_map=read(a.review_map) if a.review_map else None))
