"""Saved/generated metadata-only report checks. No finance imports or replay."""
from copy import deepcopy
import json
from pathlib import Path
import tempfile,unittest
import summarize_matrix as s

class Honest2024ReportingTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.prep=s.read(s.CORE/'annual_2024_source_preparation_attempt002/PREPARATION.json')
  cls.old=s.CORE/'actual_2024_pilot_attempt001/STATIC50_MID'
 def row(self):return s.cell_row('STATIC50_MID',self.old,s.GO_OLD,self.prep)
 def test_original_mid_halt_never_becomes_annual_return_or_full_year(self):
  r=self.row();self.assertEqual(r['terminal_status'],'NATIVE_ECONOMIC_HALT_UNPAID_PARTIAL')
  self.assertIsNone(r['paid_annual_return']);self.assertIsNone(r['annual_APR']);self.assertFalse(r['full_calendar'])
  self.assertEqual(r['completed_minutes'],446576);self.assertEqual(r['MDD_scope'],'PARTIAL_TO_NATIVE_STOP')
 def test_missing_case_and_in_progress_are_not_terminal_success(self):
  with tempfile.TemporaryDirectory() as t:
   d=Path(t)/'case';r=s.cell_row('STATIC50_LOW',d,s.GO_NEW,self.prep)
   self.assertEqual(r['terminal_status'],'QUEUED_ROOT_GO_BOUND');d.mkdir()
   self.assertEqual(s.cell_row('STATIC50_LOW',d,s.GO_NEW,self.prep)['terminal_status'],'RUNNING_OR_EVIDENCE_WRITE_PENDING')
 def fixture_case(self,root,*,paid=True,with_barrier=True):
  p=Path(root)/'STATIC50_LOW';p.mkdir();r=s.read(self.old/'CASE_RECEIPT.json');o=s.read(self.old/'RESULT.json')
  r.update(config='STATIC50_LOW',root_GO_SHA256=s.GO_NEW,status='COMPLETED_NATIVE_PATH',paid_comparison_eligible=paid,
   completed_minutes=527040 if paid else 461363,account_stop_us=None if paid else 1731749040000000)
  o['config']='STATIC50_LOW';o['target_meta'].update(config='STATIC50_LOW',root_GO_SHA256=s.GO_NEW,preparation_SHA256=s.PREP_SHA,original_interpolated_mark_execution_admitted=False);o['summary'].update(account_status='ACTIVE' if paid else 'LIQUIDATION_REQUIRED_HALT',halt_witness=None if paid else o['summary']['halt_witness']);o['target_meta']['source_target_identity']=self.prep['target_identity']['SHA256_by_config']['STATIC50_LOW']
  o['economics'].update(residual_marked_notional=0 if paid else 50,unpaid_liability='0',paid_flat=paid,full_calendar=paid,paid_net_return=.1 if paid else None,
   liquidation_required_halt=not paid,bankruptcy_halt=False)
  for n,v in [('CASE_RECEIPT.json',r),('RESULT.json',o),('OBSERVED_RISK.json',s.read(self.old/'OBSERVED_RISK.json'))]:
   (p/n).write_text(json.dumps(v))
  if with_barrier:(p.parent/'CASE_TERMINAL_STATIC50_LOW.json').write_text(json.dumps(dict(case_receipt_SHA256=s.sha((p/'CASE_RECEIPT.json').read_bytes()))))
  return p,r,o
 def test_paid_full_year_only_reports_paid_annual_scope(self):
  with tempfile.TemporaryDirectory() as t:
   p,_,_=self.fixture_case(t);r=s.cell_row('STATIC50_LOW',p,s.GO_NEW,self.prep)
   self.assertEqual(r['paid_annual_return'],.1);self.assertIsNone(r['marked_partial_return']);self.assertTrue(r['full_calendar'])
 def test_receipt_before_atomic_controller_barrier_is_pending(self):
  with tempfile.TemporaryDirectory() as t:
   p,_,_=self.fixture_case(t,with_barrier=False)
   self.assertEqual(s.cell_row('STATIC50_LOW',p,s.GO_NEW,self.prep)['terminal_status'],'RUNNING_OR_EVIDENCE_WRITE_PENDING')
 def test_false_paid_partial_missingminutes_rejects(self):
  with tempfile.TemporaryDirectory() as t:
   p,r,_=self.fixture_case(t);r['completed_minutes']=1;(p/'CASE_RECEIPT.json').write_text(json.dumps(r))
   (p.parent/'CASE_TERMINAL_STATIC50_LOW.json').write_text(json.dumps(dict(case_receipt_SHA256=s.sha((p/'CASE_RECEIPT.json').read_bytes()))))
   with self.assertRaisesRegex(ValueError,'PAID_FULL_ANNUAL'):s.cell_row('STATIC50_LOW',p,s.GO_NEW,self.prep)
 def test_wrong_target_source_or_code_pins_reject(self):
  for what in ('source_identity','code_identity','root_GO_SHA256'):
   with tempfile.TemporaryDirectory() as t:
    p,r,_=self.fixture_case(t);r[what]='BAD';(p/'CASE_RECEIPT.json').write_text(json.dumps(r))
    with self.subTest(what=what),self.assertRaises(ValueError):s.cell_row('STATIC50_LOW',p,s.GO_NEW,self.prep)
 def test_review_requires_exact_receipt_and_go_not_just_pass_string(self):
  with tempfile.TemporaryDirectory() as t:
   p,r,_=self.fixture_case(t);v=dict(schema='INDEPENDENT_SAVED2024_MATRIX_CELL_REVIEW_V1',status='PASS_SAVED_FULL_YEAR_PAID_FLAT',config='STATIC50_LOW',errors=[],preparation_SHA256=s.PREP_SHA,root_GO_SHA256=s.GO_NEW,saved_case_evidence_SHA256={'CASE_RECEIPT.json':s.sha((p/'CASE_RECEIPT.json').read_bytes()),'RESULT.json':s.sha((p/'RESULT.json').read_bytes()),'OBSERVED_RISK.json':s.sha((p/'OBSERVED_RISK.json').read_bytes())})
   f=Path(t)/'review.json';f.write_text(json.dumps(v));ref=dict(path=str(f),SHA256=s.sha(f.read_bytes()))
   self.assertEqual(s.cell_row('STATIC50_LOW',p,s.GO_NEW,self.prep,review_reference=ref)['result_review']['status'],'PASS_SAVED_FULL_YEAR_PAID_FLAT')
   v['root_GO_SHA256']='0'*64;f.write_text(json.dumps(v));ref['SHA256']=s.sha(f.read_bytes())
   with self.assertRaisesRegex(ValueError,'EXACT_ORIGINAL'):s.cell_row('STATIC50_LOW',p,s.GO_NEW,self.prep,review_reference=ref)
 def test_isolated_negative_equity_is_not_whole_wallet_bankruptcy(self):
  case=s.CORE/'actual_2024_remaining_attempt001/STATIC50_LOW'
  r=s.cell_row('STATIC50_LOW',case,s.GO_NEW,self.prep)
  self.assertIn('ISOLATED_LEG_EQUITY_NONPOSITIVE',r['native_bankruptcy_triggers'])
  self.assertNotIn('WHOLE_WALLET_NAV_NONPOSITIVE',r['native_bankruptcy_triggers'])
  self.assertGreater(r['whole_wallet_marked_NAV'],10000);self.assertIsNone(r['paid_annual_return'])
 def test_all_nine_terminal_can_include_halt_without_annual_average_or_false_completion(self):
  rows=[dict(config=c,tier=c.rsplit('_',1)[1],terminal_status='PAID_FULL_YEAR',paid_annual_return=.1) for c in s.CONFIGS]
  rows[0].update(terminal_status='NATIVE_ECONOMIC_HALT_UNPAID_PARTIAL',paid_annual_return=None)
  r=s.assemble_report(rows)
  self.assertTrue(r['all_requested_cells_terminal']);self.assertFalse(r['all_cells_full_year_paid'])
  self.assertEqual(r['status_counts']['PAID_FULL_YEAR'],8);self.assertEqual(r['status_counts']['NATIVE_ECONOMIC_HALT_UNPAID_PARTIAL'],1)
  self.assertIsNone(r['annual_average_return']);self.assertIsNone(rows[0].get('same_period_full_annual_excess_vs_HOLD'))
  self.assertEqual(rows[0]['excess_status'],'UNDEFINED_UNLESS_BOTH_FULL_YEAR_PAID')
 def test_halted_hold_means_same_period_annual_excess_undefined_for_whole_tier(self):
  rows=[dict(config=c,tier=c.rsplit('_',1)[1],terminal_status='PAID_FULL_YEAR',paid_annual_return=.1,same_period_full_annual_excess_vs_HOLD=None) for c in s.CONFIGS]
  next(r for r in rows if r['config']=='VOL_MANAGED_HOLD_MID').update(terminal_status='NATIVE_ECONOMIC_HALT_UNPAID_PARTIAL',paid_annual_return=None)
  s.assemble_report(rows)
  self.assertTrue(all(r['same_period_full_annual_excess_vs_HOLD'] is None for r in rows if r['tier']=='MID'))
 def test_missing_or_duplicate_requested_cells_cannot_claim_matrix_completion(self):
  rows=[dict(config=c,tier=c.rsplit('_',1)[1],terminal_status='PAID_FULL_YEAR',paid_annual_return=.1) for c in s.CONFIGS]
  with self.assertRaises(ValueError):s.assemble_report(rows[:-1])
  rows[-1]['config']=rows[0]['config']
  with self.assertRaises(ValueError):s.assemble_report(rows)
 def test_exclusive_atomic_status_checkpoint_preserves_old_file(self):
  with tempfile.TemporaryDirectory() as t:
   p=Path(t)/'checkpoint.json';s.save_checkpoint(p,{'first':True})
   with self.assertRaises(FileExistsError):s.save_checkpoint(p,{'first':False})
   self.assertTrue(json.loads(p.read_bytes())['first'])

if __name__=='__main__':unittest.main(verbosity=2)
