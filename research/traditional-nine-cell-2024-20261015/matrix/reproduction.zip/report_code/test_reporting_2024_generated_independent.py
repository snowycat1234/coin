"""Independent reporting-only metadata fixtures. No account/source imports or replay."""
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent.parent
MODULE = ROOT / 'traditional_2024_matrix_reporting_20261015/summarize_matrix.py'
spec = importlib.util.spec_from_file_location('reporting_candidate', MODULE)
s = importlib.util.module_from_spec(spec)
spec.loader.exec_module(s)

class GeneratedReportingReview(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.config = 'STATIC50_LOW'
        self.prep = {'code_identity': {'generated.py': 'code'}, 'source_identity': 'source',
                     'target_identity': {'SHA256_by_config': {self.config: 'target', 'STATIC50_MID': 'old-target'}}}

    def write(self, path, value):
        path.write_text(json.dumps(value))

    def fixture(self, paid=True, old=False):
        c = 'STATIC50_MID' if old else self.config
        p = self.root / c
        p.mkdir()
        go = s.GO_OLD if old else s.GO_NEW
        r = {'schema': 'FINITE_FULL2024_CASE_RECEIPT_V1', 'status': 'COMPLETED_NATIVE_PATH' if paid or old else 'NATIVE_ECONOMIC_HALT_UNPAID_PARTIAL',
             'config': c, 'root_GO_SHA256': go, 'preparation_SHA256': s.PREP_SHA,
             'code_identity': self.prep['code_identity'], 'source_identity': self.prep['source_identity'],
             'calendar': [1704067200000000, 1735689600000000], 'required_minutes': 527040,
             'original_interpolated_mark_execution_admitted': False,
             'paid_comparison_eligible': paid, 'completed_minutes': 527040 if paid else 100,
             'account_stop_us': None if paid else 1704073200000000}
        e = {'calendar': [1704067200000000, 1735689600000000], 'paid_flat': paid, 'full_calendar': paid, 'paid_net_return': .1 if paid else None,
             'marked_net_return': .1, 'all_observation_max_drawdown': .03,
             'residual_marked_notional': 0 if paid else 50, 'unpaid_liability': 0,
             'liquidation_required_halt': not paid, 'bankruptcy_halt': False,
             'actual_liquidation_fills': 0, 'liquidation_fill_model': 'NOT_IMPLEMENTED_NATIVE_ACCOUNT_STOPS_WITH_WITNESS',
             'fees_USDT': 1, 'execution_cost_USDT': 1, 'funding_USDT': -1}
        o = {'config': c, 'economics': e,
             'target_meta': {'config': c, 'root_GO_SHA256': go, 'preparation_SHA256': s.PREP_SHA,
                             'source_target_identity': self.prep['target_identity']['SHA256_by_config'][c],
                             'original_interpolated_mark_execution_admitted': False},
             'summary': {'account_status': 'ACTIVE' if paid else 'LIQUIDATION_REQUIRED_HALT', 'NAV': 10100,
                         'terminal_cash_realized': paid, 'stop_us': r['account_stop_us'],
                         'completed_minutes': r['completed_minutes'], 'required_minutes': 527040,
                         'positions': {} if paid else {'GENERATED': {'quantity': 1}},
                         'halt_witness': None if paid else {'isolated_equity': .2, 'NAV': 10100}}}
        risk = {'gross_exposure_max': .3, 'gross_exposure_mean': .2,
                'realized_daily_simple_return_annual_volatility': .05, 'complete_calendar_days': 366 if paid else 0,
                'forecast_annual_volatility_max': .05, 'forecast_volatility_breach_minutes': 0,
                'forecast_volatility_breach_max_absolute': 0}
        self.write(p / 'CASE_RECEIPT.json', r)
        self.write(p / 'RESULT.json', o)
        self.write(p / 'OBSERVED_RISK.json', risk)
        self.barrier(p)
        return p, r, o, risk

    def barrier(self, p):
        self.write(p.parent / ('CASE_TERMINAL_' + p.name + '.json'),
                   {'case_receipt_SHA256': s.sha((p / 'CASE_RECEIPT.json').read_bytes())})

    def row(self, p, **kwargs):
        return s.cell_row(p.name, p, s.GO_OLD if p.name == 'STATIC50_MID' else s.GO_NEW, self.prep, **kwargs)

    def review(self, p, old=False):
        v = {'schema': 'INDEPENDENT_SAVED2024_PILOT_FINAL_REVIEW_RECEIPT_V1' if old else 'INDEPENDENT_SAVED2024_MATRIX_CELL_REVIEW_V1',
             'status': 'PASS_EXPECTED_NATIVE_ECONOMIC_HALT_WITH_HONEST_PARTIAL_OUTPUTS' if old else 'PASS_SAVED_FULL_YEAR_PAID_FLAT',
             'config': p.name, 'errors': [], 'root_GO_SHA256': s.GO_OLD if old else s.GO_NEW,
             'preparation_SHA256': s.PREP_SHA,
             'saved_case_evidence_SHA256' if old else 'saved_evidence_SHA256':
                 {file.name: s.sha(file.read_bytes()) for file in p.iterdir() if file.is_file()}}
        if old:
            finance = {'schema': 'INDEPENDENT_SAVED_PARTIAL2024_PILOT_FINANCE_AND_HALT_REVIEW_V1',
                       'status': 'PASS_EXPECTED_NATIVE_ECONOMIC_HALT_SAVED_EVIDENCE', 'errors': [],
                       'root_GO_SHA256': s.GO_OLD, 'preparation_SHA256': s.PREP_SHA,
                       'saved_evidence_SHA256': v['saved_case_evidence_SHA256']}
            quality = {'schema': 'INDEPENDENT_ACTUAL2024_STATIC50_MID_SAVED_QUALITY_REVIEW_V1',
                       'status': 'PASS_SAVED_CAUSAL_VALUATION_AND_NO_STALE_OPEN_PARTIAL_HALT_ONLY',
                       'evidence_SHA256': {str(p / name): digest for name, digest in v['saved_case_evidence_SHA256'].items()}}
            for filename, content, field in (
                ('ANNUAL_2024_PILOT_SAVED_FINANCE_HALT_REVIEW.json', finance, 'saved_finance_review_SHA256'),
                ('ACTUAL_2024_PILOT_SAVED_QUALITY_REVIEW.json', quality, 'saved_quality_review_SHA256')):
                self.write(self.root / filename, content)
                v[field] = s.sha((self.root / filename).read_bytes())
            v['source_code_identity'] = self.prep['code_identity']
        f = self.root / 'review.json'
        self.write(f, v)
        return v, f, {'path': str(f), 'SHA256': s.sha(f.read_bytes())}

    def update_review(self, v, f, ref):
        self.write(f, v)
        ref['SHA256'] = s.sha(f.read_bytes())

    def test_generated_build_preserves_all_nine_with_malformed_terminal_cell(self):
        core = self.root / 'generated_core'
        prepdir = core / 'annual_2024_source_preparation_attempt002'
        prepdir.mkdir(parents=True)
        prep = {'code_identity': self.prep['code_identity'], 'source_identity': self.prep['source_identity'],
                'target_identity': {'SHA256_by_config': {c: 'generated-' + c for c in s.CONFIGS}}}
        self.write(prepdir / 'PREPARATION.json', prep)
        for name in ('actual_2024_pilot_attempt001', 'actual_2024_remaining_attempt001'):
            folder = core / name
            folder.mkdir()
            self.write(folder / 'ROOT_GO.json', {'generated': True})
        folder = core / 'actual_2024_remaining_attempt001'
        case = folder / self.config
        case.mkdir()
        (case / 'CASE_RECEIPT.json').write_text('{')
        self.barrier(case)
        go = s.sha((folder / 'ROOT_GO.json').read_bytes())
        with patch.object(s, 'CORE', core), patch.object(s, 'PREP_SHA', s.sha((prepdir / 'PREPARATION.json').read_bytes())), \
             patch.object(s, 'GO_OLD', go), patch.object(s, 'GO_NEW', go):
            report = s.build(review_map={'STATIC50_MID': {'path': 'unused-queued-review', 'SHA256': 'unused'}})
        self.assertEqual(len(report['rows']), 9)
        self.assertEqual({r['config'] for r in report['rows']}, set(s.CONFIGS))
        blocked = next(r for r in report['rows'] if r['config'] == self.config)
        self.assertEqual(blocked['terminal_status'], 'ENGINEERING_BLOCKED')
        self.assertEqual(report['status_counts']['ENGINEERING_BLOCKED'], 1)
        self.assertEqual(report['status_counts']['QUEUED_ROOT_GO_BOUND'], 8)
        self.assertFalse(report['all_cells_full_year_paid'])
        self.assertIsNone(report['annual_average_return'])
        self.assertTrue(blocked.get('engineering_block_reason'))
        self.assertEqual(blocked.get('evidence_directory'), str(case))

    def test_review_binds_other_present_quality_and_terminal_evidence(self):
        p, _, _, _ = self.fixture()
        for filename in ('CAUSAL_MARK_QUALITY.json', 'TERMINAL_CHECKPOINT.json'):
            self.write(p / filename, {'generated': 'original'})
            v, f, ref = self.review(p)
            v['saved_evidence_SHA256'][filename] = s.sha((p / filename).read_bytes())
            self.update_review(v, f, ref)
            self.write(p / filename, {'generated': 'changed'})
            with self.subTest(filename=filename), self.assertRaises(ValueError): self.row(p, review_reference=ref)

    def test_valid_generated_paid_case(self):
        p, _, _, _ = self.fixture()
        self.assertEqual(self.row(p)['terminal_status'], 'PAID_FULL_YEAR')

    def test_positive_wallet_nav_isolated_bankruptcy_is_partial(self):
        p, _, o, _ = self.fixture(paid=False)
        o['economics']['bankruptcy_halt'] = True
        o['economics']['liquidation_required_halt'] = False
        o['summary'].update(account_status='BANKRUPT_HALT', halt_witness={'isolated_equity': '-0.2', 'NAV': '10100'})
        self.write(p / 'RESULT.json', o)
        r = self.row(p)
        self.assertEqual(r['native_bankruptcy_triggers'], ['ISOLATED_LEG_EQUITY_NONPOSITIVE'])
        self.assertGreater(r['whole_wallet_marked_NAV'], 0)
        self.assertIsNone(r['paid_annual_return'])
        self.assertIsNone(r['annual_APR'])

    def test_receipt_before_result_and_barrier_is_pending(self):
        p, _, _, _ = self.fixture()
        (p / 'RESULT.json').unlink()
        (p.parent / ('CASE_TERMINAL_' + p.name + '.json')).unlink()
        self.assertEqual(self.row(p)['terminal_status'], 'RUNNING_OR_EVIDENCE_WRITE_PENDING')

    def test_partial_receipt_before_barrier_preserves_pending_row(self):
        p, _, _, _ = self.fixture()
        (p / 'CASE_RECEIPT.json').write_text('{')
        (p.parent / ('CASE_TERMINAL_' + p.name + '.json')).unlink()
        self.assertEqual(self.row(p)['terminal_status'], 'RUNNING_OR_EVIDENCE_WRITE_PENDING')

    def test_wrong_review_schema_rejected(self):
        p, _, _, _ = self.fixture()
        v, f, ref = self.review(p)
        v['schema'] = 'UNRELATED_REVIEW'
        self.update_review(v, f, ref)
        with self.assertRaises(ValueError): self.row(p, review_reference=ref)

    def test_unrecognized_or_terminal_mismatched_review_status_rejected(self):
        p, _, _, _ = self.fixture()
        for status in ('PASS_UNRELATED', 'PASS_SAVED_NATIVE_ECONOMIC_HALT'):
            v, f, ref = self.review(p)
            v['status'] = status
            self.update_review(v, f, ref)
            with self.subTest(status=status), self.assertRaises(ValueError): self.row(p, review_reference=ref)

    def test_bankruptcy_requires_an_actual_native_trigger(self):
        p, _, o, _ = self.fixture(paid=False)
        o['economics'].update(bankruptcy_halt=True, liquidation_required_halt=False)
        o['summary'].update(account_status='BANKRUPT_HALT', halt_witness={'isolated_equity': '2', 'NAV': '10100'})
        self.write(p / 'RESULT.json', o)
        with self.assertRaises(ValueError): self.row(p)

    def test_matrix_review_requires_explicit_config_and_errors(self):
        p, _, _, _ = self.fixture()
        for key in ('config', 'errors'):
            v, f, ref = self.review(p)
            del v[key]
            self.update_review(v, f, ref)
            with self.subTest(missing=key), self.assertRaises(ValueError): self.row(p, review_reference=ref)

    def test_review_binds_observed_risk_used_in_report(self):
        p, _, _, risk = self.fixture()
        _, _, ref = self.review(p)
        risk['gross_exposure_max'] = 999
        self.write(p / 'OBSERVED_RISK.json', risk)
        with self.assertRaises(ValueError): self.row(p, review_reference=ref)

    def test_result_target_meta_go_prep_and_execution_pins_reject(self):
        p, _, o, _ = self.fixture()
        for key, invalid in (('root_GO_SHA256', 'wrong-go'), ('preparation_SHA256', 'wrong-prep'),
                             ('config', 'STATIC50_HIGH'), ('original_interpolated_mark_execution_admitted', True)):
            original = o['target_meta'][key]
            o['target_meta'][key] = invalid
            self.write(p / 'RESULT.json', o)
            with self.subTest(key=key), self.assertRaises(ValueError): self.row(p)
            o['target_meta'][key] = original

    def test_new_case_failure_cannot_be_paid_full(self):
        p, _, _, _ = self.fixture()
        self.write(p / 'CASE_FAILURE.json', {'status': 'ENGINEERING_FAILURE'})
        self.assertNotEqual(self.row(p)['terminal_status'], 'PAID_FULL_YEAR')

    def test_paid_eligibility_cannot_override_native_halt(self):
        p, _, o, _ = self.fixture()
        o['economics']['liquidation_required_halt'] = True
        o['summary']['account_status'] = 'LIQUIDATION_REQUIRED_HALT'
        self.write(p / 'RESULT.json', o)
        with self.assertRaises(ValueError): self.row(p)

    def test_paid_full_requires_finite_paid_return(self):
        p, _, o, _ = self.fixture()
        for value in (None, float('nan'), float('inf')):
            o['economics']['paid_net_return'] = value
            self.write(p / 'RESULT.json', o)
            with self.subTest(value=value), self.assertRaises(ValueError): self.row(p)

    def test_halt_requires_consistent_partial_calendar(self):
        p, r, o, _ = self.fixture(paid=False)
        r['completed_minutes'] = 527040
        o['economics']['full_calendar'] = True
        self.write(p / 'CASE_RECEIPT.json', r)
        self.write(p / 'RESULT.json', o)
        self.barrier(p)
        with self.assertRaises(ValueError): self.row(p)

    def test_annual_excess_cleared_after_hold_becomes_partial(self):
        rows = [dict(config=c, tier=c.rsplit('_', 1)[1], terminal_status='PAID_FULL_YEAR', paid_annual_return=.1)
                for c in s.CONFIGS]
        s.assemble_report(rows)
        hold = next(r for r in rows if r['config'] == 'VOL_MANAGED_HOLD_LOW')
        hold.update(terminal_status='NATIVE_ECONOMIC_HALT_UNPAID_PARTIAL', paid_annual_return=None)
        s.assemble_report(rows)
        for r in rows:
            if r['tier'] == 'LOW': self.assertIsNone(r['same_period_full_annual_excess_vs_HOLD'])

    def test_original_pilot_review_schema_and_failure_can_remain_economic_halt(self):
        p, _, _, _ = self.fixture(paid=False, old=True)
        self.write(p / 'CASE_FAILURE.json', {'status': 'ORIGINAL_EXPECTED_NATIVE_HALT'})
        v, f, ref = self.review(p, old=True)
        del v['config']
        del v['errors']
        self.update_review(v, f, ref)
        self.assertEqual(self.row(p, review_reference=ref)['terminal_status'], 'NATIVE_ECONOMIC_HALT_UNPAID_PARTIAL')

    def test_original_pilot_supporting_review_hash_tampering_rejects(self):
        p, _, _, _ = self.fixture(paid=False, old=True)
        for filename in ('ANNUAL_2024_PILOT_SAVED_FINANCE_HALT_REVIEW.json', 'ACTUAL_2024_PILOT_SAVED_QUALITY_REVIEW.json'):
            _, _, ref = self.review(p, old=True)
            self.write(self.root / filename, {'changed': True})
            with self.subTest(filename=filename), self.assertRaises(ValueError): self.row(p, review_reference=ref)

    def test_original_pilot_finance_go_and_preparation_pins_reject(self):
        p, _, _, _ = self.fixture(paid=False, old=True)
        for key in ('root_GO_SHA256', 'preparation_SHA256'):
            v, f, ref = self.review(p, old=True)
            path = self.root / 'ANNUAL_2024_PILOT_SAVED_FINANCE_HALT_REVIEW.json'
            finance = json.loads(path.read_bytes())
            finance[key] = 'wrong-identity'
            self.write(path, finance)
            v['saved_finance_review_SHA256'] = s.sha(path.read_bytes())
            self.update_review(v, f, ref)
            with self.subTest(key=key), self.assertRaises(ValueError): self.row(p, review_reference=ref)

    def test_original_pilot_requires_exact_final_status(self):
        p, _, _, _ = self.fixture(paid=False, old=True)
        v, f, ref = self.review(p, old=True)
        v['status'] = 'PASS_SAVED_NATIVE_ECONOMIC_HALT'
        self.update_review(v, f, ref)
        with self.assertRaises(ValueError): self.row(p, review_reference=ref)

    def test_wrong_review_receipt_hash_rejected(self):
        p, _, _, _ = self.fixture()
        v, f, ref = self.review(p)
        v['saved_evidence_SHA256']['CASE_RECEIPT.json'] = '0' * 64
        self.update_review(v, f, ref)
        with self.assertRaises(ValueError): self.row(p, review_reference=ref)

    def test_all_nine_rows_and_halt_safe_aggregate(self):
        rows = [dict(config=c, tier=c.rsplit('_', 1)[1], terminal_status='NATIVE_ECONOMIC_HALT_UNPAID_PARTIAL',
                     paid_annual_return=None, same_period_full_annual_excess_vs_HOLD=None) for c in s.CONFIGS]
        report = s.assemble_report(rows)
        self.assertEqual(len(report['rows']), 9)
        self.assertTrue(report['all_requested_cells_terminal'])
        self.assertFalse(report['all_cells_full_year_paid'])
        self.assertIsNone(report['annual_average_return'])
        self.assertTrue(all(r['same_period_full_annual_excess_vs_HOLD'] is None for r in report['rows']))

if __name__ == '__main__': unittest.main(verbosity=2)
