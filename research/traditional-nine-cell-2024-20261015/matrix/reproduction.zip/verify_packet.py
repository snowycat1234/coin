from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parent
m=json.loads((r/'MANIFEST.json').read_bytes())
for n,v in m['files'].items():
 b=(r/n).read_bytes();assert len(b)==v['bytes'] and hashlib.sha256(b).hexdigest()==v['SHA256'],n
print('PASS',len(m['files']),'exact files')
