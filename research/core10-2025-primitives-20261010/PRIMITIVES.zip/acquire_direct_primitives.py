"""Serial checksum-verified full2025 primitive archive acquisition; no trading."""
import csv,io,json,hashlib,zipfile,time
from pathlib import Path
import requests
ROOT=Path(__file__).parent; inventory=json.loads((ROOT/'DIRECT_PATH_PLAN.json').read_text());assert len(inventory['records'])==9; records=[x for group in inventory['records'] for x in group['selected_2025']];assert len(records)==108
D=ROOT/'archives';D.mkdir(exist_ok=True);R=ROOT/'receipts';R.mkdir(exist_ok=True);session=requests.Session();results=[]
for i,x in enumerate(records):
    key=x['key'];name=key.split('/')[-1];family=x['family'];stem=x['symbol']+'_'+family+'_'+name
    receipt=R/(stem+'.json');path=D/stem
    if receipt.exists():
        old=json.loads(receipt.read_text());assert path.exists() and hashlib.sha256(path.read_bytes()).hexdigest()==old['SHA256'];results.append(old);continue
    response=session.get(x['checksum_url'],timeout=30);response.raise_for_status();assert response.url.startswith('https://data.binance.vision/');assert len(response.content)<1000;parts=response.text.split();assert len(parts)==2 and parts[1]==name;expected=parts[0];assert len(expected)==64
    if path.exists():body=path.read_bytes()
    else:
        response=session.get(x['url'],timeout=30);response.raise_for_status();assert response.url.startswith('https://data.binance.vision/');body=response.content;assert len(body)<1000000;path.write_bytes(body)
    assert hashlib.sha256(body).hexdigest()==expected
    archive=zipfile.ZipFile(io.BytesIO(body));assert archive.testzip() is None;assert len(archive.namelist())==1;member=archive.namelist()[0];assert member.endswith('.csv');assert archive.getinfo(member).file_size<2*2**20
    rows=list(csv.reader(io.StringIO(archive.read(member).decode())));header=None
    if rows and not rows[0][0].isdigit():header=rows.pop(0)
    times=[int(row[0]) for row in rows];assert times and times==sorted(set(times));assert all(1735689600000<=t<1767225600000 for t in times)
    if family!='fundingRate':
        assert all(len(row)==12 for row in rows);assert all(t%86400000==0 for t in times)
    else:assert all(len(row)==3 for row in rows)
    x=dict(x,bytes=len(body));result=dict(x,SHA256=expected,CSV_member=member,rows=len(rows),header=header,first_ms=times[0],last_ms=times[-1],archive_crc_pass=True)
    receipt.write_text(json.dumps(result,indent=2)+'\n');results.append(result)
    (ROOT/'DIRECT_PROGRESS.json').write_text(json.dumps({'complete':False,'verified_archives':len(results),'expected_archives':len(records),'bytes':sum(v['bytes'] for v in results)},indent=2)+'\n')
    if (i+1)%12==0:print('verified',i+1,'/',len(records),x['symbol'],family,flush=True)
(ROOT/'ACQUIRED_DIRECT_2025.json').write_text(json.dumps({'complete':True,'records':results,'bytes':sum(v['bytes'] for v in results),'stage':'7 of10 feature assets: CORE5 plus ORDI/WLD; remaining3 metadata uncovered after LIST host policy denial. Dailyfeature+signedfundingprimitives, no execution tapes, no certified economic training interval'},indent=2)+'\n');print('COMPLETE',len(results),flush=True)
