"""Validate source primitives without inventing execution or funding mark inputs."""
from pathlib import Path
import json,csv,zipfile,io,hashlib,calendar
import pandas as pd,numpy as np
R=Path(__file__).parent;receipts=[json.loads(p.read_text()) for p in (R/'receipts').glob('*.json')];groups={}
for x in receipts:groups.setdefault((x['symbol'],x['family']),[]).append(x)
out=[];D=R/'derived';D.mkdir(exist_ok=True)
for (sym,family),items in sorted(groups.items()):
 if len(items)!=12:continue
 rows=[]
 for x in sorted(items,key=lambda x:x['key']):
  name=x['symbol']+'_'+family+'_'+x['key'].split('/')[-1];p=R/'archives'/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==x['SHA256']
  z=zipfile.ZipFile(p);a=list(csv.reader(io.StringIO(z.read(x['CSV_member']).decode())))
  if not a[0][0].isdigit():a.pop(0)
  rows.extend(a)
 t=np.array([int(a[0]) for a in rows],dtype=np.int64);assert len(t)==len(np.unique(t)) and np.all(np.diff(t)>0)
 if family!='fundingRate':
  cols=['open_time_ms','open','high','low','close','volume','close_time_ms','quote_volume','trades','taker_buy_volume','taker_buy_quote_volume','ignore'];d=pd.DataFrame(rows,columns=cols).apply(pd.to_numeric);expected=np.arange(1735689600000,1767225600000,86400000);missing=np.setdiff1d(expected,t);assert not np.setdiff1d(t,expected).size
  v=d[['open','high','low','close']].to_numpy();assert np.isfinite(v).all();assert np.all(v[:,1]>=v[:,2]);assert np.all(v[:,1]>=v[:,[0,3]].max(1));assert np.all(v[:,2]<=v[:,[0,3]].min(1))
  if family=='klines':assert np.all(v>0) and np.all(d.volume>=0)
  close_t=d.close_time_ms.to_numpy();assert np.all(close_t==t+86400000-1)
  gaps={'missing_daily_open_times_ms':missing.tolist()}
 else:
  d=pd.DataFrame(rows,columns=['calc_time_ms','funding_interval_hours','last_funding_rate']).apply(pd.to_numeric);assert np.isfinite(d.to_numpy()).all();assert np.all(d.funding_interval_hours>0)
  gaps={'event_interval_hours_counts':{str(k):int(v) for k,v in d.funding_interval_hours.value_counts().items()},'event_time_delta_hours_counts':{str(k):int(v) for k,v in pd.Series(np.diff(t)/3600000).value_counts().items()},'note':'Cadence variations retained, no8hour assumption. Rates without source marks cannot yet certify paid funding PnL.'}
 p=D/(sym+'_'+family+'.parquet');d.to_parquet(p,index=False);out.append({'symbol':sym,'family':family,'rows':len(d),'first_ms':int(t[0]),'last_ms':int(t[-1]),'derived_bytes':p.stat().st_size,'derived_SHA256':hashlib.sha256(p.read_bytes()).hexdigest(),**gaps})
(R/'VALIDATED_PRIMITIVES.json').write_text(json.dumps({'groups':out,'complete_groups':len(out),'expected_groups':30,'archive_count':len(receipts),'financial_readiness':'NOT_READY: real00:01 execution prices and strict-prior minute fundingmarks still required, plus exact feature/expert reconstruction and masks.','no_training':True},indent=2)+'\n');print('validated groups',len(out));print([(x['symbol'],x['family'],x['rows']) for x in out])
