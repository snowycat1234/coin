import urllib.request,urllib.parse,xml.etree.ElementTree as ET,json,time
from pathlib import Path
R=Path(__file__).parent;D=R/'listings';D.mkdir(exist_ok=True)
S=['BTCUSDT','ETHUSDT','SOLUSDT','XRPUSDT','DOGEUSDT','ORDIUSDT','WLDUSDT','WIFUSDT','1000PEPEUSDT','1000SATSUSDT'];F=['klines','premiumIndexKlines','fundingRate'];base='https://s3-ap-northeast-1.amazonaws.com/data.binance.vision';ns={'s':'http://s3.amazonaws.com/doc/2006-03-01/'};out=[]
for symbol in S:
 for family in F:
  prefix=f'data/futures/um/monthly/{family}/{symbol}/'+('1d/' if family!='fundingRate' else '');token=None;rows=[];page=0
  while True:
   q={'list-type':'2','prefix':prefix,'max-keys':1000}
   if token:q['continuation-token']=token
   u=base+'?'+urllib.parse.urlencode(q);p=D/f'{symbol}_{family}_{page}.xml'
   if p.exists():b=p.read_bytes()
   else:
    with urllib.request.urlopen(u,timeout=30) as resp:b=resp.read(1000001);assert len(b)<=1000000
    p.write_bytes(b)
   root=ET.fromstring(b)
   for n in root.findall('s:Contents',ns):rows.append({'key':n.findtext('s:Key',namespaces=ns),'bytes':int(n.findtext('s:Size',namespaces=ns)),'modified':n.findtext('s:LastModified',namespaces=ns)})
   trunc=root.findtext('s:IsTruncated',namespaces=ns)=='true';token=root.findtext('s:NextContinuationToken',namespaces=ns);page+=1
   if not trunc:break
   assert token
  z=[x for x in rows if x['key'].endswith('.zip')];keys={x['key'] for x in rows};chosen=[dict(x,symbol=symbol,family=family,url='https://data.binance.vision/'+x['key'],checksum_url='https://data.binance.vision/'+x['key']+'.CHECKSUM') for x in z if '-2025-' in x['key'] and x['key']+'.CHECKSUM' in keys]
  out.append({'symbol':symbol,'family':family,'pages':page,'first':z[0]['key'] if z else None,'last':z[-1]['key'] if z else None,'selected_2025':chosen});(R/'INVENTORY_2025.json').write_text(json.dumps({'complete':False,'records':out},indent=2)+'\n');print(symbol,family,len(z),len(chosen),flush=True)
(R/'INVENTORY_2025.json').write_text(json.dumps({'complete':True,'records':out,'selected_zip_bytes':sum(x['bytes'] for a in out for x in a['selected_2025']),'scope':'Full2025 ten-asset daily feature primitives, signedfunding. Not execution tapes or certified training samples. Existing2020–2024 cache reused;2026 metadata only, no outcomes downloaded.'},indent=2)+'\n')
