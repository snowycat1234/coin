"""Descriptive fixed causal regimes; no sampling or model changes."""
from pathlib import Path
import numpy as np,pandas as pd,json,hashlib
S=Path(__file__).parent.parent; raw=S/'feature-input/verified/source_tables_not_model_inputs/daily_features';symbols=['BTCUSDT','ETHUSDT','SOLUSDT','XRPUSDT','DOGEUSDT'];series=[];hashes={}
for sym in symbols:
 p=raw/(sym+'.parquet');d=pd.read_parquet(p);series.append(d.set_index('dt')['close'].rename(sym));hashes[sym]=hashlib.sha256(p.read_bytes()).hexdigest()
prices=pd.concat(series,axis=1).sort_index();days=prices.index.asi8//1000+86400000000;z=np.load(S/'training-request-diagnostic/REQUESTS.npz');rows=[]
for k in range(6):
 for t in z[f'decision_us_{k}'][:-1]:
  i=np.searchsorted(days,t,side='right')-1;assert i>=30
  block=prices.iloc[i-30:i+1].to_numpy();assert np.isfinite(block).all();assert np.all(np.diff(days[i-30:i+1])==86400000000);assert days[i]<=t
  r30=float(np.mean(block[-1]/block[0]-1));r5=float(np.mean(block[-1]/block[-6]-1))
  if abs(r30)<=.05:group='sideways_prior30_within5pct'
  elif r30>.05:group='uptrend' if r5>=0 else 'uptrend_pullback'
  else:group='downtrend' if r5<=0 else 'downtrend_rebound'
  rows.append({'decision_us':int(t),'wallet':k,'year':pd.Timestamp(t,unit='us',tz='UTC').year,'regime':group,'prior30_equal_asset_return':r30,'prior5_equal_asset_return':r5})
d=pd.DataFrame(rows);assert len(d)==1137 and d.decision_us.is_unique;counts=d.regime.value_counts().to_dict();out={'status':'DESCRIPTIVE_CAUSAL_TRAINING_COUNTS_ONLY','active_intervals':len(d),'rule':'Completed real31dailycloses; equal-weight5asset prior30 compoundedreturns, ±5%sideways, prior5sign distinguishes continuation/reversal. Fixed descriptive bins, no PnL-optimizedthresholds; not universal market truth.','counts':counts,'by_year':{str(y):g.regime.value_counts().to_dict() for y,g in d.groupby('year')},'source_SHA256':hashes,'no_new_fits':True,'no_changed_weights':True};d.to_csv(S/'data-expansion/TRAIN_REGIMES.csv',index=False);(S/'data-expansion/TRAIN_REGIMES.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
