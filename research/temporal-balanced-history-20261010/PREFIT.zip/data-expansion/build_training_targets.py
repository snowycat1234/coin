"""Rebuild four original targets over the repaired pre-May2024 causal history."""
from pathlib import Path
import json,hashlib,importlib.util
import numpy as np,polars as pl
from modules.temporal_july_transfer.data import recipe,RISK_SOURCES,SHORT_SOURCE_SHA
from modules.temporal_two_expert.inputs import CORE5,DAY_US
R=Path(__file__).resolve().parent;O=R/'training1290';O.mkdir(exist_ok=True);F=R/'repaired_features';repo=Path.cwd()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for p,h in RISK_SOURCES.items():assert sha(repo/p)==h,p
path=repo/'modules/temporal_april_transfer/upstream/momentum_short_pool_target.py';assert sha(path)==SHORT_SOURCE_SHA
spec=importlib.util.spec_from_file_location('_repaired_short_recipe',path);short=importlib.util.module_from_spec(spec);spec.loader.exec_module(short)
f=np.load(F/'FEATURES.npz');mask=f['completed_day_available_us']<=1714435200000000;t=f['completed_day_available_us'][mask];close=f['close'][mask];dec=np.arange(1602720000000000,1714521600000000,DAY_US,dtype=np.int64);assert dec[-1]==1714435200000000
r=recipe();bars=r.bar_frame(F,CORE5).filter(pl.col('available_us')<=int(dec[-1]));a=[r.existing_targets(dict(recipe=n,mechanism=n),bars,dec,close,t,CORE5) for n in ['CASH','VOL_MANAGED_HOLD','CSMOM21']];sf,_=short.fixed_targets(bars,dec,symbols=CORE5)
target=np.concatenate([np.stack([v[0] for v in a],1),sf['target_weight'].to_numpy().reshape(len(dec),1,5)],axis=1);eligible=np.concatenate([np.stack([v[2] for v in a],1),(sf['eligibility_reason'].to_numpy().reshape(len(dec),1,5)=='ELIGIBLE').any(2)],axis=1)
ix=np.searchsorted(t,dec);np.testing.assert_array_equal(t[ix],dec);past=np.stack([np.diff(close[i-30:i+1],axis=0)/close[i-30:i] for i in ix]);assert np.isfinite(past).all() and np.isfinite(target).all();assert (abs(target).sum(2)<=.60000001).all();assert (abs(target)<=.30000001).all()
# Independently re-invoke the exact producers on a history truncated at2021year end.
cut=int(np.searchsorted(dec,1640995200000000));pc=close[t<=dec[cut-1]];pt=t[t<=dec[cut-1]];pb=bars.filter(pl.col('available_us')<=int(dec[cut-1]))
for j,n in enumerate(['CASH','VOL_MANAGED_HOLD','CSMOM21']):
 b=r.existing_targets(dict(recipe=n,mechanism=n),pb,dec[:cut],pc,pt,CORE5);np.testing.assert_array_equal(b[0],target[:cut,j]);np.testing.assert_array_equal(b[2],eligible[:cut,j])
b,_=short.fixed_targets(pb,dec[:cut],symbols=CORE5);np.testing.assert_array_equal(b['target_weight'].to_numpy().reshape(cut,5),target[:cut,3])
np.savez_compressed(O/'TARGETS.npz',decision_us=dec,expert_targets=target,expert_eligible=eligible,past_returns30=past,symbol_order=CORE5,expert_order=['CASH','VOL_MANAGED_HOLD','CSMOM21','MOMENTUM30_SHORT'])
(O/'TARGET_RECEIPT.json').write_text(json.dumps({'status':'UNCHANGED_TARGET_RECIPES_RECONSTRUCTED','calendar_decisions':len(dec),'prefix_invariant_rows':cut,'funded_training_active_intervals_pending_packet_admission':1290,'source_SHA256':sha(F/'FEATURES.npz'),'target_SHA256':sha(O/'TARGETS.npz'),'no_future2025_inputs':True,'no_fitting':True},indent=2)+'\n');print('REBUILT',len(dec),eligible.sum(0))
