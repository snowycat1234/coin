"""Extend original causal feature formulas from verified official daily primitives."""
from pathlib import Path
import json,hashlib
import numpy as np,pandas as pd
from modules.temporal_july_transfer.data import build_features
from modules.temporal_two_expert.inputs import MARKET_CONTEXT,CORE5,DAY_US
from modules.collector_research.pipeline.normalize import funding_windows
R=Path(__file__).resolve().parent;S=R.parent;O=R/'repaired_features';O.mkdir(exist_ok=True);(O/'daily_features').mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
frames={};checks=[]
for s in MARKET_CONTEXT:
 p=R/'gap-repair/repaired/daily_features'/f'{s}.parquet';old=pd.read_parquet(p)
 k=pd.read_parquet(R/'derived'/f'{s}_klines.parquet');pr=pd.read_parquet(R/'derived'/f'{s}_premiumIndexKlines.parquet');f=pd.read_parquet(R/'derived'/f'{s}_fundingRate.parquet');f['past_mark_price']=np.nan
 days=pd.to_datetime(k.open_time_ms,unit='ms',utc=True);fw=funding_windows(f,pd.DatetimeIndex(days))
 new=k[['open','high','low','close','volume','quote_volume']].copy();new.insert(0,'dt',days);new['complete_kline']=True
 np.testing.assert_array_equal(pr.open_time_ms,k.open_time_ms)
 new['premium']=pr.close.to_numpy();new['complete_premium']=True;new['funding']=fw.funding.to_numpy();new['complete_funding']=fw.complete_funding.to_numpy();new['symbol']=s
 overlap=old[old.dt.isin(new.dt)].copy();comparison=[]
 for row in overlap.itertuples():
  b=new[new.dt.eq(row.dt)].iloc[0]
  for c in ['open','high','low','close','volume','quote_volume','premium']:
   a=float(getattr(row,c));v=float(b[c]);comparison.append({'column':c,'cached':a,'official_daily':v,'absolute_difference':abs(a-v)})
   if bool(row.complete_kline) and c!='premium':np.testing.assert_allclose(a,v,rtol=1e-7,atol=1e-7)
   if c=='premium' and bool(row.complete_premium):np.testing.assert_allclose(a,v,rtol=1e-7,atol=1e-10)
 # Retain exact cached overlap bytes/values. New first day needs prior bracket; existing cached day supplies it.
 new=new[~new.dt.isin(old.dt)]
 assert new.complete_funding.all(),s
 merged=pd.concat([old,new],ignore_index=True).sort_values('dt').reset_index(drop=True)
 assert not merged.dt.duplicated().any();np.testing.assert_array_equal(np.diff(pd.DatetimeIndex(merged.dt).as_unit('us').asi8),DAY_US)
 frames[s]=merged;merged.to_parquet(O/'daily_features'/f'{s}.parquet',index=False)
 checks.append({'symbol':s,'cached_SHA256':sha(p),'new_rows':len(new),'overlap_rows':len(overlap),'overlap_comparison':comparison,'new_daily_source_flags':'official complete 1d records; minute-grid equivalence not asserted for context-only assets'})
end=int(pd.Timestamp('2026-01-01',tz='UTC').value//1000)
t,x,m,obs,close=build_features(frames,end_us=end)
# Verify untouched prior history bitwise against frozen old array, including NaNs and masks.
z=np.load(S/'feature-input/verified/features/CORE5_PRE_MAY2024.npz');refclock=z['completed_day_available_us'];unaffected=(refclock<1645920000000000)|(refclock>=1672531200000000);ix=np.searchsorted(t,refclock[unaffected]);np.testing.assert_array_equal(t[ix],z['completed_day_available_us'][unaffected]);np.testing.assert_array_equal(x[ix],z['x'][unaffected]);np.testing.assert_array_equal(m[ix],z['feature_observed_mask'][unaffected]&z['close_observed_mask'][unaffected,...,None])
np.savez_compressed(O/'FEATURES.npz',completed_day_available_us=t,x=x,feature_observed_mask=m,close_observed_mask=obs,close=close,symbol_order=CORE5)
report={'status':'FEATURE_FORMULAS_RECONSTRUCTED_NO_MODEL_TRAINING','rows':len(t),'prior_rows_bitwise_equal':len(ix),'source_checks':checks,'artifacts':[{ 'path':str(p.relative_to(O)),'bytes':p.stat().st_size,'SHA256':sha(p)} for p in O.rglob('*') if p.is_file()]}
(O/'REPORT.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n');print(report['status'],len(t))
