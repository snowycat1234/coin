import csv,json
from pathlib import Path
import numpy as np
p=Path('../coin_single_state/paired-once');r=json.loads((p/'RESULT.json').read_text());out={}
for name in ('FULL773_256','EXPANDED1137_256'):
 with (p/(name+'_DAILY.csv')).open() as f: rows=list(csv.DictReader(f))
 print(name,'columns',list(rows[0]))
 with np.load(p/(name+'_PATH.npz'),allow_pickle=False) as z:
  nav=z['nav'];out[name]={'July_net':float(nav[31]-nav[0]),'August_net':float(nav[62]-nav[31]),'September_paid_close':float(nav[63]-nav[62])}
print(json.dumps(out,indent=2))
(p/'MONTHLY_READONLY.json').write_text(json.dumps(out,indent=2)+'\n')
