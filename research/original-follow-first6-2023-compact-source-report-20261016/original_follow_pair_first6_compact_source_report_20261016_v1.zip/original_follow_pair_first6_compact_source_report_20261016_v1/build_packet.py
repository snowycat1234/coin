"""Local packaging only. Never imports any historical module or reads market bodies."""
from pathlib import Path
import hashlib, json, shutil, zipfile

ROOT = Path(__file__).resolve().parent.parent
OUT = Path(__file__).resolve().parent
NAME = OUT.name
NATIVE = 'original_follow_pair_first6_D_native_20261016_v2'
SOURCE = 'original_follow_pair_D_source_20261016_v1'
SIGNAL = 'original_follow_pair_signal_20261016_v1'
SAVED = 'original_follow_pair_first6_D_recovery_saved_independent_review_20261016_v2'
ATTEMPT = NATIVE+'/financial_attempts/ACTUAL_FIRST6_RECOVERY_attempt001'
PREP = SOURCE+'/source_attempts/ACTUAL_ALL30_SOURCE_TARGET_ONLY_attempt001'
COPIES = {}

def require(value, message):
    if not value: raise ValueError(message)

def pin(path):
    raw=path.read_bytes()
    return {'SHA256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}

def obj(path): return json.loads(path.read_bytes())

def write(name, data):
    path=OUT/name;path.parent.mkdir(parents=True,exist_ok=True)
    raw=(json.dumps(data,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
    with path.open('xb') as stream: stream.write(raw)

def copy(original, target=None, expected=None):
    source=ROOT/original; target=target or 'snapshots/'+original
    require(source.is_file() and not source.is_symlink(),'NOT_REGULAR:'+original)
    identity=pin(source)
    if expected: require(identity=={k:expected[k] for k in ('SHA256','bytes')},'PIN:'+original)
    path=OUT/target;path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as stream:stream.write(source.read_bytes())
    COPIES[target]={'original_path':original,'original_pin':identity,'transformation':'EXACT_EXISTING_BYTES'}
    return target

def main():
    require(shutil.disk_usage(OUT).free>1_610_612_736+10_000_000,'FREE_FLOOR')
    for folder,filename in ((SIGNAL,'CODE_MANIFEST.json'),(SOURCE,'CODE_MANIFEST.json'),(NATIVE,'FINANCIAL_CODE_MANIFEST.json')):
        manifest=obj(ROOT/folder/filename)
        copy(folder+'/'+filename)
        for rel,identity in manifest['files'].items():copy(folder+'/'+rel,expected=identity)
    for original in (
        'original_follow_pair_signal_independent_review_20261016_v1/REVIEW.json',
        'original_follow_pair_D_source_independent_review_20261016_v1/SOURCE_REVIEW.json',
        'original_follow_pair_D_prepared_independent_review_20261016_v1/PREPARED_REVIEW.json',
        'original_follow_pair_first6_D_recovery_independent_review_20261016_v2/INDEPENDENT_REVIEW.json',
        'bounded_native_continuation_guard50_exit_expansion_20261015/saved_native_reconciliation.py',
        'cs_saved_calendar_exact_20261015_v1/cs_saved_calendar.py',
    ):
        if original not in {v['original_path'] for v in COPIES.values()}:copy(original)
    copy('original_follow_pair_first6_compact_independent_review_20261016_v1/INITIAL_DISCLOSURE_FINDINGS.json','reviews/compact_initial/INITIAL_DISCLOSURE_FINDINGS.json')
    for name in ('PREPARATION.json','SOURCE_INDEPENDENT_REVIEW.json','OBSERVED_SOURCE_TARGET_GUARD_RECEIPT.json'):
        copy(PREP+'/'+name,'provenance/source_preparation/'+name)
    for path in sorted((ROOT/SAVED).iterdir()):
        if path.is_file() and path.suffix in ('.json','.csv','.py','.log'):
            copy(str(path.relative_to(ROOT)),'reviews/saved/'+path.name)
    copy(ATTEMPT+'/ROOT_OBSERVED_EXIT_CONFIRMED.json','receipts/ROOT_OBSERVED_EXIT_CONFIRMED.json')
    audit=obj(ROOT/SAVED/'FINAL_INDEPENDENT_SAVED_AUDIT.json')
    report=obj(ROOT/SAVED/'FINAL_SIX_MATRIX.json')
    binding=obj(ROOT/SAVED/'CONTROLLER_AND_FINAL_ARTIFACT_BINDING.json')
    cells=report['ordered_cells']
    selected=('TERMINAL_CHECKPOINT.json','CASE_RECEIPT.json','ACTUAL_HELD_RISK_REPORT.json',
              'NATIVE40_RECONSTRUCTION_PROOF.json','PRIMARY_FINANCIAL_RECONCILIATION.json',
              'LEGACY_PRIMARY_FINANCIAL_RECONCILIATION.json','CAUSAL_MARK_QUALITY.json',
              'SOURCE_NATIVE_QUALITY.json','SOURCE_RECAPTURE_GUARD_RECEIPT.json')
    for cell in cells:
        for name in selected:copy(ATTEMPT+'/'+cell+'/'+name,'cases/'+cell+'/'+name)
    recovery=obj(ROOT/NATIVE/'RECOVERY_EVIDENCE.json')
    old_history=[]
    for item in recovery['evidence_files']:
        original=item['relative_path']
        if Path(original).name in ('FAILURE.json',) or original.endswith('.log'):
            rel=copy(original,'history/'+original,expected=item);old_history.append(rel)
    by_original={value['original_path']:rel for rel,value in COPIES.items()}
    dependencies={}
    for folder,filename in ((SIGNAL,'CODE_MANIFEST.json'),(SOURCE,'CODE_MANIFEST.json'),(NATIVE,'FINANCIAL_CODE_MANIFEST.json')):
        for original,identity in obj(ROOT/folder/filename).get('dependencies',{}).items():
            identity={k:identity[k] for k in ('SHA256','bytes')}
            require(original not in dependencies or dependencies[original]['pin']==identity,'CONTRADICTORY_PIN')
            included=original in by_original
            if included:require(COPIES[by_original[original]]['original_pin']==identity,'DEPENDENCY_COPY_PIN')
            dependencies[original]={'pin':identity,'included':included,'packet_path':by_original.get(original),
                'classification':'BUNDLED_INERT_BYTES' if included else 'OMITTED_INHERITED_FINANCIAL_CODE_OR_REFERENCE',
                'reader_limitation':None if included else 'Historical financial runtime closure is incomplete; never import or execute it from this packet.'}
    write('DEPENDENCY_CLASSIFICATION.json',{'schema':'EXHAUSTIVE_DIRECT_MANIFEST_DEPENDENCIES_V1','dependencies':dependencies,
        'financial_runtime_closure_complete':False,'FOLLOW_signal_and_source_manifest_own_files_complete':True,
        'FOLLOW_source_direct_manifest_dependencies_complete':all(x in by_original for x in obj(ROOT/SOURCE/'CODE_MANIFEST.json')['dependencies'])})
    evidence={}
    def omitted(original, identity, role):
        if original in by_original:return
        identity={k:identity[k] for k in ('SHA256','bytes')}
        if original in evidence:require(evidence[original]['pin']==identity,'OMISSION_PIN_CONFLICT');return
        evidence[original]={'pin':identity,'role':role,'included':False,'hashes_restore_omitted_bytes':False}
    for cell,case in binding['checked_case_artifacts'].items():
        for name,identity in case['files'].items():omitted(identity['path'],identity,'SEALED_FIRST6_CASE_ARTIFACT:'+name)
    omitted(binding['controller_terminal']['path'],binding['controller_terminal'],'FULL_CONTROLLER_OBSERVATION_TRACE')
    omitted(audit['root_GO']['path'],audit['root_GO'],'EXISTING_ROOT_AUTHORITY_BODY_NOT_BUNDLED_OR_REISSUED')
    for item in recovery['evidence_files']:omitted(item['relative_path'],item,'PRESERVED_V1_ZERO_ACCOUNT_INTERRUPTION_EVIDENCE')
    prep=obj(ROOT/PREP/'PREPARATION.json')
    for rel,identity in prep['artifacts'].items():omitted(PREP+'/'+rel,identity,'SOURCE_PREPARATION_OUTPUT'+(':2023_REQUIRED' if rel.startswith('2023/') else ':OUT_OF_SCOPE_OTHER_YEAR_OR_AUTHORITY'))
    def collect(value,role):
        if isinstance(value,dict):
            if all(k in value for k in ('SHA256','bytes','path')):omitted(value['path'],value,role)
            for child in value.values():collect(child,role)
        elif isinstance(value,list):
            for child in value:collect(child,role)
    collect(obj(ROOT/NATIVE/'NATIVE_SOURCE_DESCRIPTOR.json'),'QUALIFIED_2023_NATIVE_SOURCE_INPUT')
    collect(obj(ROOT/SOURCE/'HLC_SOURCE_CONTRACT_MAP.json')['read_files']['2023'],'2023_HLC_ORIGINAL_CALLER_SOURCE')
    collect(obj(ROOT/SOURCE/'CLOSE_PREFIX_SOURCE_MAP.json')['years']['2023'],'2023_FULL_PAST_CLOSE_PREFIX_INPUT')
    write('OMITTED_EVIDENCE_PINS.json',{'schema':'EXACT_OMITTED_FIRST6_HISTORY_AND_SOURCE_PIN_INVENTORY_V1','files':evidence,
        'inventory_source':'Exact sealed audit/controller/checkpoint and source-manifest metadata; bulky omitted bodies were not reread during packaging.',
        'scope':'All omitted files in all six final checkpoints; controller trace; V1 recovery evidence; all preparation outputs; exact qualified 2023 native and HLC/prefix source file pointers.',
        'transitive_raw_archive_members':'Original archive/member inventories remain in the bundled HLC map; no raw archive/member bodies are bundled.',
        'public_packet_alone_CANNOT_reconstruct_all_native40_checks':True,'hashes_restore_omitted_bytes':False})
    write('PROVENANCE_FILE_MAP.json',{'all_copies_exact_original_bytes':True,'files':COPIES})
    write('SCOPE_AND_LIMITS.json',{'schema':'FOLLOW_FIRST6_COMPACT_REPORT_SOURCE_BINDINGS_ONLY_V1','case_count':6,
        'year':2023,'ordered_cells':cells,'completed_minutes':3_153_600,'scope':'COMPACT_REPORT_AND_SOURCE_BINDINGS_ONLY',
        'publication_performed':False,'upload_authority_granted':False,'source_or_financial_execution_authorized':False,
        'target_recomputation_available':False,'financial_history_self_contained':False,'financial_runtime_closure_complete':False,
        'public_packet_alone_CANNOT_reconstruct_all_native40_checks':True,'hashes_restore_omitted_bytes':False,
        'all37_or_current_D_all30_completion_claim':False,'remaining24_authorized':False,
        'adaptive_DEV_only':True,'OOS_or_live_certification':False,'deployability_established':False,
        'risk_matched_claim':False,'post_tier_samegross_guaranteed':False,'funding_units_or_arrival_certified':False,
        'native_venue_or_liquidation_certified':False,'originals_modified':False,
        'historical_code_snapshots':'INERT_BYTES_ONLY_NEVER_IMPORTED','full_event_history_omitted':True,'future_performance_established':False,
        'source_and_signal_own_file_snapshots_complete':True,'source_direct_manifest_dependencies_complete':True,'financial_own_file_snapshots_complete':True,
        'limitation_sentence':'compact report and source bindings only; omitted full event history means the public packet alone CANNOT reconstruct all native40 checks.',
        'control_LOW_actual_risk_warning':{'cell_id':cells[3],
            'nominal_annual_volatility_budget':report['rows'][3]['nominal_annual_volatility_budget'],
            'forecast_annual_volatility_max':report['rows'][3]['forecast_annual_volatility_max'],
            'forecast_volatility_breach_minutes':report['rows'][3]['forecast_volatility_breach_minutes'],
            'control_realized_daily_simple_return_annual_volatility':report['rows'][3]['realized_daily_simple_return_annual_volatility'],
            'pool_LOW_realized_daily_simple_return_annual_volatility':report['rows'][0]['realized_daily_simple_return_annual_volatility'],
            'interpretation':'Control LOW forecast-held volatility max 27.11395% versus nominal 5%, with 74631 breach minutes. Nominal tiers are not risk-matched evidence; post-tier samegross is not guaranteed.'},
        'target_recomputation_gap':'Qualified 2023 HLC, full-prefix and saved target bodies are omitted and pinned. No historical modules are imported. A later separately authorized complete source-only proof would need those exact bytes and their runtime dependencies.',
        'financial_reconstruction_gap':'Full ACCOUNT_FINANCIAL_AUDIT.json, NATIVE_RESULT.json, MINUTE.npz and GUARD_RECEIPTS.json histories and portions of inherited financial runtime closure are omitted; exact proofs and their hashes are retained as evidence of the prior full audit, not rerun proof.'})
    write('FINAL_INPUT_PINS.json',{'final_saved_audit':audit,'note':'Exact final audit body copied separately; this structured binding is for report-source integrity only.'})
    write('DIAGNOSTIC_HISTORY.json',{'V1':'Two cp437 interruptions occurred before financial account construction; original failures, logs, and claims were preserved. This packet copies failures/logs, pins omitted evidence and does not authorize retry.',
        'V1_failure_logs_and_bodies':old_history,'V2':'The root-approved recovery completed all six fixed 2023 accounts. EXIT0 was independently sealed afterward.',
        'pre_exit_metadata':'Frozen FINAL_SIX_MATRIX and earlier saved bindings retain root_exit_receipt_pending=true. Final independent saved audit plus exact root exit receipt resolve it additively; old bytes were not changed.',
        'saved_reviewer_iterations':'Earlier stopped harness and finalization/sealing attempts remain copied in reviews/saved, with final audit disclosure. They are not extra financial executions.',
        'no_remaining24_or_all37_financial_completion':True})
    (OUT/'README.md').write_text('''# FOLLOW pair first6: compact report and source bindings only

LOCAL PREPARATION ONLY. No upload, publication, Git operation, new authority,
claim, source capture, target recomputation, account, provider or financial run.

All six fixed 2023 accounts completed 525600 simulated minutes each, total
3153600, and ended actual paid market-flat with no conditional settlement,
economic halt, resource pause, debt, topup, transfer or new capital. Each wallet
started fresh at 10000 USDT. No cross-account compounding. Only this pair's six
2023 accounts are financially complete; later24 were not authorized. Bundled
source maps/definitions contain other years as inert reference metadata only.

Paid net returns (pool / dependent control): LOW 6.8324% / 13.0157%, MID 9.0240%
/ 10.4816%, HIGH 10.0519% / 10.3036%. Intrinsic samegross precedes independent
lower-only tier adaptation; post-tier samegross is not guaranteed. These are
same-nominal-tier outcomes, not risk-matched evidence. Control LOW forecast-held
volatility reached 27.11395% against the nominal 5% budget, with 74631 breach
minutes; realized annualized daily volatility was 6.8841%, versus pool LOW
4.6361%. Nominal-tier lag does not establish a risk-matched comparison.

Funding uses literal saved rates and clocks without rescaling; raw units and
historical publication/arrival are unconfirmed. Paid fees, combined adverse
spread/slippage and signed funding remain distinct. Embedded execution costs
must not be deducted twice. Actual-held risk is post-transition minute-close;
MDD covers all saved observations, with independently checked extrema witnesses,
not independent replay of the full observation stream. Capital/risk limits
constrain admitted increases and are not continuous marked-state guarantees.
All 2023 quality intervals and block rows are zero. Source arrival, venue filters,
risk tiers and native liquidation remain uncertified. This is adaptive DEV
research only, with no deployability, future-performance or untouched OOS claim.

The packet is compact report and source bindings only; omitted full event
history means the public packet alone CANNOT reconstruct all native40 checks.
Exact prior full-audit proof receipts and hashes are preserved. The cold reader
checks included bytes and report/source/proof cross-bindings without importing
historical modules. It neither reproduces nor reruns native40 financial checks.
Target recomputation is also unavailable: qualified 2023 HLC/full-prefix/target
bodies are omitted and pinned. Hashes cannot restore missing bytes.

FOLLOW signal and source manifest own-file snapshots and source direct
dependencies are complete as inert bytes. Financial own files are exact, but
the inherited financial runtime closure is deliberately incomplete. Every
direct frozen manifest dependency is classified in DEPENDENCY_CLASSIFICATION.
Omitted checkpoint histories, authority bodies, controller trace, preparation
outputs and exact qualified2023 source inputs have hashes and byte sizes in
OMITTED_EVIDENCE_PINS. The HLC map retains raw archive/member provenance.

V1's two zero-account cp437 failures and explicit V2 recovery remain visible.
Frozen earlier reports still say exit pending; the additive final saved audit
and root-owned EXIT0 receipt establish completion. No old byte was rewritten.

Read RECOVERY.md. Authenticate the ZIP and launcher through an independent
trusted receipt before running the isolated stdlib-only cold reader. A fresh
independent compact review and root-controlled publication decision are still
required. This preparation grants no publication authority.
''')
    (OUT/'RECOVERY.md').write_text('''# Cold report/source-binding recovery

1. Authenticate the ZIP SHA256 and run_isolated_cold.py SHA256 independently.
2. Use Python 3.12 (stdlib only). No package installation is required.
3. Run: python -I -S -B run_isolated_cold.py PACKET.zip --trusted-zip-sha256 TRUSTED_SHA256 --receipt NEW_RECEIPT.json
4. Repeat with -O if desired. All actual integrity checks use explicit exceptions
   and generated tests use unittest methods; they remain effective under -O.

The launcher verifies the outer digest before reading code, rejects unsafe ZIP
paths, case collisions, nonregular/encrypted entries, and size/count overruns.
It extracts into a fresh temporary directory, then prohibits external file reads,
historical execution/imports, network/process actions and all writes except the
fresh receipt. Its own external-read/process/import/exec controls must fail.
Only the authenticated top-level verify_packet.py is executed. Snapshot source
is read as bytes and never imported. The tiny extraction is retained for review.

Report JSON and CSV are exact final saved bytes. The reader crosschecks every
CSV field against its JSON value, all six row identities/statuses/economics,
actual-held risk summaries, proof/checkpoint chains, root exit, final audit,
source preparation identity and exhaustive dependency/omission classifications.
It does not read or reconstruct omitted financial bodies. The source-byte
snapshots and metadata are portable; their historical absolute/path literals
are inert data and are never followed by this reader.

The manifest authenticates all packet files except itself and requires exact
inventory. Authenticate the outer ZIP separately to protect the manifest too.
All historical manifests, prior review scripts and builder are inert reference
material, not authorized entry points. Never run historical financial CLIs.
''')
    write('READMAP.json',{'start':['README.md','SCOPE_AND_LIMITS.json','RECOVERY.md'],
        'report':['reviews/saved/FINAL_SIX_MATRIX.json','reviews/saved/FINAL_SIX_MATRIX.csv'],
        'final_completion':['reviews/saved/FINAL_INDEPENDENT_SAVED_AUDIT.json','receipts/ROOT_OBSERVED_EXIT_CONFIRMED.json'],
        'omissions':['DEPENDENCY_CLASSIFICATION.json','OMITTED_EVIDENCE_PINS.json'],
        'cold_entry':'run_isolated_cold.py','historical_code_policy':'INERT_BYTES_ONLY_NEVER_IMPORTED'})
    files={str(p.relative_to(OUT)):pin(p) for p in sorted(OUT.rglob('*')) if p.is_file() and p.name!='MANIFEST.json'}
    require(sum(x['bytes'] for x in files.values())<4_500_000,'PACKET_SIZE')
    write('MANIFEST.json',{'schema':'FOLLOW_FIRST6_COMPACT_SOURCE_REPORT_V1','scope_and_limitations':obj(OUT/'SCOPE_AND_LIMITS.json'),'files':files})
    archive=ROOT/(NAME+'.zip')
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as handle:
        for path in sorted(OUT.rglob('*')):
            if path.is_file():
                info=zipfile.ZipInfo(NAME+'/'+str(path.relative_to(OUT)),date_time=(2026,10,16,0,0,0))
                info.create_system=3;info.external_attr=0o100644<<16;info.compress_type=zipfile.ZIP_DEFLATED
                handle.writestr(info,path.read_bytes(),compresslevel=9)
    print(json.dumps({'packet_files':len(files)+1,'packet_bytes':sum(p.stat().st_size for p in OUT.rglob('*') if p.is_file()),'ZIP':pin(archive),'launcher':pin(OUT/'run_isolated_cold.py'),'dependencies':len(dependencies),'omitted_evidence_files':len(evidence)},sort_keys=True))

if __name__=='__main__':main()
