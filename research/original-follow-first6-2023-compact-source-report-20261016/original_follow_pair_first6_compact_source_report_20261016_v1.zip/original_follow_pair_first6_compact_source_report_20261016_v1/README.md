# FOLLOW pair first6: compact report and source bindings only

LOCAL PREPARATION ONLY. No upload, publication, Git operation, new authority,
claim, source capture, target recomputation, account, provider or financial run.

All six fixed 2023 accounts completed 525600 simulated minutes each, total
3153600, and ended actual paid market-flat with no conditional settlement,
economic halt, resource pause, debt, topup, transfer or new capital. Each wallet
started fresh at 10000 USDT. No cross-account compounding. Only this pair's six
2023 accounts are financially complete; later24 were not authorized. Bundled
source maps/definitions contain other years as inert reference metadata only.

Paid net returns (pool / dependent control): LOW 6.8324% / 13.0157%, MID 9.0240%
/ 10.4816%, HIGH 10.0519% / 10.3036%. Intrinsic samegross precedes independent
lower-only tier adaptation; post-tier samegross is not guaranteed. These are
same-nominal-tier outcomes, not risk-matched evidence. Control LOW forecast-held
volatility reached 27.11395% against the nominal 5% budget, with 74631 breach
minutes; realized annualized daily volatility was 6.8841%, versus pool LOW
4.6361%. Nominal-tier lag does not establish a risk-matched comparison.

Funding uses literal saved rates and clocks without rescaling; raw units and
historical publication/arrival are unconfirmed. Paid fees, combined adverse
spread/slippage and signed funding remain distinct. Embedded execution costs
must not be deducted twice. Actual-held risk is post-transition minute-close;
MDD covers all saved observations, with independently checked extrema witnesses,
not independent replay of the full observation stream. Capital/risk limits
constrain admitted increases and are not continuous marked-state guarantees.
All 2023 quality intervals and block rows are zero. Source arrival, venue filters,
risk tiers and native liquidation remain uncertified. This is adaptive DEV
research only, with no deployability, future-performance or untouched OOS claim.

The packet is compact report and source bindings only; omitted full event
history means the public packet alone CANNOT reconstruct all native40 checks.
Exact prior full-audit proof receipts and hashes are preserved. The cold reader
checks included bytes and report/source/proof cross-bindings without importing
historical modules. It neither reproduces nor reruns native40 financial checks.
Target recomputation is also unavailable: qualified 2023 HLC/full-prefix/target
bodies are omitted and pinned. Hashes cannot restore missing bytes.

FOLLOW signal and source manifest own-file snapshots and source direct
dependencies are complete as inert bytes. Financial own files are exact, but
the inherited financial runtime closure is deliberately incomplete. Every
direct frozen manifest dependency is classified in DEPENDENCY_CLASSIFICATION.
Omitted checkpoint histories, authority bodies, controller trace, preparation
outputs and exact qualified2023 source inputs have hashes and byte sizes in
OMITTED_EVIDENCE_PINS. The HLC map retains raw archive/member provenance.

V1's two zero-account cp437 failures and explicit V2 recovery remain visible.
Frozen earlier reports still say exit pending; the additive final saved audit
and root-owned EXIT0 receipt establish completion. No old byte was rewritten.

Read RECOVERY.md. Authenticate the ZIP and launcher through an independent
trusted receipt before running the isolated stdlib-only cold reader. A fresh
independent compact review and root-controlled publication decision are still
required. This preparation grants no publication authority.
