"""Typed source requirements only. There is no market-file reader or admission API."""
from dataclasses import dataclass
from follow_pair_config import period_named,SYMBOLS,DAY

@dataclass(frozen=True)
class GenuineTradeHLCSpec:
 year:int
 decision_start_us:int
 decision_end_exclusive_us:int
 first_hlc_completed_available_us:int
 last_hlc_completed_available_us:int
 first_risk_completed_available_us:int
 symbol_order:tuple
 hlc_domain:str='ACTUAL_TRADE_KLINE_HIGH_LOW_CLOSE'
 mark_substitution_allowed:bool=False
 close_or_open_synthesized_extrema_allowed:bool=False
 require_complete_minutes:bool=True
 require_exact_risk_close_parity:bool=True
 source_body_read_authorized:bool=False
 source_admitted:bool=False
 financial_authorized:bool=False

def spec_named(year):
 p=period_named(year)
 return GenuineTradeHLCSpec(year,p['start'],p['end'],p['start']-20*DAY,p['end']-DAY,p['start']-199*DAY,SYMBOLS)

SPECS=tuple(spec_named(y) for y in (2023,2024,2025,2021,2022))
