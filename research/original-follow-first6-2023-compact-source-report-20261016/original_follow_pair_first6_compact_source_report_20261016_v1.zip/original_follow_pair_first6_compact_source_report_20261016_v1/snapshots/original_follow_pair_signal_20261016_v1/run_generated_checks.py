"""Generate descriptors only for deterministic engineering fixtures; zero wallets."""
from pathlib import Path
import json
import numpy as np
import follow_pair_signal as signal
import follow_pair_config as config
from test_follow_pair_signal import GeneratedChecks

HERE=Path(__file__).absolute().parent

def run():
 cases={}
 for n in (274,365,366):
  arrays,proofs=GeneratedChecks().build(n)
  target_keys=[r+'_'+t[0] for r in signal.RECIPES for t in signal.TIERS]
  groups={}
  for key in target_keys:groups.setdefault(signal.array_byte_identity(arrays[key])['descriptor_and_bytes_SHA256'],[]).append(key)
  cases[str(n)]=dict(rows=n,array_identities={k:signal.array_byte_identity(v) for k,v in arrays.items()},
   generated_exact_target_byte_groups=list(groups.values()),execution_alias_proved=False,
   intrinsic_max_abs_pool_minus_control_gross=float(np.abs(arrays['intrinsic_pool_minus_control_gross']).max()),
   post_tier_max_abs_pool_minus_control_gross={tier:float(np.abs(arrays['post_tier_pool_minus_control_gross_'+tier]).max()) for tier,*_ in signal.TIERS},
   source_admitted=False,financial_authorized=False)
 report=dict(schema='ORIGINAL_FOLLOW_PAIR_GENERATED_EQUIVALENCE_RECEIPT_V1',status='PASS_GENERATED_ONLY',cases=cases,
  source_pinmap_SHA256=signal.SOURCE_PINS_SHA256,original_AST_SHA256=signal.originals().AST_SHA256,
  new_scientific_recipe_claimed=False,intrinsic_samegross=True,post_tier_samegross_guaranteed=False,
  market_bodies_read=0,financial_runs=0,source_authority_granted=False,financial_authority_granted=False,publication_authority_granted=False)
 (HERE/'GENERATED_EQUIVALENCE_RECEIPT.json').write_text(json.dumps(report,sort_keys=True,indent=2,allow_nan=False)+'\n')
 (HERE/'FROZEN_THIRTY_CELL_MANIFEST.json').write_text(json.dumps(config.manifest(),sort_keys=True,indent=2,allow_nan=False)+'\n')
 print(json.dumps(dict(status=report['status'],generated_calendar_rows=[274,365,366],cell_count=30,source_runs=0,financial_runs=0)))

if __name__=='__main__':run()
