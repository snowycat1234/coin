"""Original FOLLOW/samegross pair, with downward-only common D tier ceilings.

Pure caller-array math and pinned-code reads only. No market-file reader,
historical source admission, financial constructor, launch or publication API.
"""
from __future__ import annotations
import ast
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace
import numpy as np
import pandas as pd

HERE=Path(__file__).absolute().parent
DAY=86_400_000_000
SYMBOLS=('BTCUSDT','ETHUSDT','SOLUSDT','XRPUSDT','DOGEUSDT')
RECIPES=('STATIC50_FOLLOW_POOL_SAMEGROSS','STATIC50_FOLLOW_DEPENDENT_SAMEGROSS_CONTROL')
TIERS=(('LOW',.30,.05,.30),('MID',.60,.10,.30),('HIGH',.90,.15,.30))
SOURCE_PINS_SHA256='57a5c35772aed59b0058784303f53a5952b1b32f10706570b92aea7480b8865b'
VERSION='ORIGINAL_FOLLOW_PAIR_INTRINSIC_LOWER_ONLY_GENERATED_V1'


def sha(raw):return hashlib.sha256(raw).hexdigest()


def ordinary(path):
    path=Path(path).absolute()
    if path.is_symlink() or any(p.is_symlink() for p in path.parents) or not path.is_file():
        raise ValueError('ORDINARY_PINNED_CODE_REQUIRED')
    return path.read_bytes()


def verify_sources():
    raw=ordinary(HERE/'SOURCE_PINS.json')
    if sha(raw)!=SOURCE_PINS_SHA256:raise ValueError('EXACT_CODE_PINMAP_REQUIRED')
    pins=json.loads(raw)
    for name,pin in pins['files'].items():
        rel=Path(name)
        if rel.is_absolute() or '..' in rel.parts or rel.parts[0]!='pinned':raise ValueError('PINNED_CODE_NAMESPACE_REQUIRED')
        body=ordinary(HERE/rel)
        blob=hashlib.sha1(b'blob '+str(len(body)).encode()+b'\0'+body).hexdigest()
        if len(body)!=pin['bytes'] or sha(body)!=pin['SHA256'] or blob!=pin['GitBlobSHA1']:
            raise ValueError('EXACT_ORIGINAL_CODE_BYTES_CHANGED:'+name)
    return pins


def originals():
    verify_sources()
    ns=dict(np=np,pd=pd,DAY=DAY,DAY_US=DAY,WEEK_US=7*DAY,ANCHOR_US=1704067200000000,
        SYMBOLS=SYMBOLS,EXPERTS=('SMA200_SIGNED','CSMOM21_CORE5','HOLD','CASH'),
        ARMS=('CS_MATCHED','VOL_MATCHED','STATIC50'),ANNUAL_BUDGET=.10,ASSET_CAP=.30,GROSS_CAP=.60)
    selections=(('public_sma_perpetual.py',('require','symbol_order','signed_risk_weights')),
        ('portfolio.py',('market_neutral',)),('public_cross_section_momentum.py',('public_targets',)),
        ('joint_expert_information.py',('signed_intents',)),('match_core.py',('match',)),
        ('risk_budget.py',('scale','allocate')),('follow_original.py',('rejection','targets')),
        ('same_gross_original.py',('validate','common_gross')))
    ast_pins={}
    for filename,names in selections:
        path=HERE/'pinned'/filename;tree=ast.parse(ordinary(path),filename=str(path))
        nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names]
        if tuple(n.name for n in nodes)!=names:raise ValueError('EXACT_ORIGINAL_FUNCTION_INVENTORY_REQUIRED')
        for node in nodes:ast_pins[filename+'::'+node.name]=sha(ast.dump(node,include_attributes=False).encode())
        if filename=='follow_original.py':ns['risk']=SimpleNamespace(scale=ns['scale'])
        exec(compile(ast.Module(body=nodes,type_ignores=[]),str(path),'exec'),ns)
    # Original common_gross uses this exact constant, not the match/allocate arms.
    ns['ARMS']=('STATIC50_SAMEGROSS','FOLLOW_POOL_SAMEGROSS')
    path=HERE/'pinned/hold_feature_original.py';tree=ast.parse(ordinary(path),filename=str(path))
    weights=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='weights')
    nodes=[n for n in weights.body if isinstance(n,ast.Assign) and any(
        isinstance(t,ast.Name) and t.id in ('mean','signal') for t in n.targets)]
    if len(nodes)!=2:raise ValueError('EXACT_ORIGINAL_HOLD_FEATURE_REQUIRED')
    feature_code=compile(ast.Module(body=nodes,type_ignores=[]),str(path),'exec')
    # allocate resolves ARMS dynamically, so restore its own exact three-arm namespace.
    alloc_ns=ns.copy();alloc_ns['ARMS']=('CS_MATCHED','VOL_MATCHED','STATIC50')
    allocate_node=next(n for n in ast.parse(ordinary(HERE/'pinned/risk_budget.py')).body if isinstance(n,ast.FunctionDef) and n.name=='allocate')
    exec(compile(ast.Module(body=[allocate_node],type_ignores=[]),str(HERE/'pinned/risk_budget.py'),'exec'),alloc_ns)
    return SimpleNamespace(**{n:ns[n] for n in ('signed_intents','match','targets','rejection','common_gross','scale')},
        allocate=alloc_ns['allocate'],feature_code=feature_code,AST_SHA256=ast_pins)


def supported(value,dtype=None):
    a=np.asarray(value)
    if (a.dtype.fields is not None or a.dtype.subdtype is not None or a.dtype.hasobject
        or (a.dtype.kind,a.dtype.itemsize) not in (('b',1),('i',8),('f',8))):
        raise ValueError('PLAIN_BOOL_INT64_FLOAT64_ONLY')
    if dtype is not None and a.dtype!=np.dtype(dtype):raise ValueError('EXACT_NATIVE_DTYPE_REQUIRED')
    return a


def immutable(value):
    a=supported(value);return np.frombuffer(a.tobytes(order='C'),dtype=a.dtype).reshape(a.shape)


def array_byte_identity(value):
    a=supported(value);desc=dict(dtype=a.dtype.str,shape=list(a.shape),order='C')
    header=json.dumps(desc,sort_keys=True,separators=(',',':')).encode()
    return dict(**desc,raw_bytes_SHA256=sha(a.tobytes(order='C')),
        descriptor_and_bytes_SHA256=sha(header+b'\0'+a.tobytes(order='C')))


def clock(value):
    a=supported(value,'int64')
    if a.ndim!=1 or not len(a) or np.any(a<0) or np.any(a%DAY) or np.any(np.diff(a)!=DAY):
        raise ValueError('COMPLETE_UTC_DAILY_INT64_CLOCK_REQUIRED')
    return a


def covariance_checked(value):
    c=supported(value,'float64')
    if c.shape!=(5,5) or not np.isfinite(c).all() or not np.allclose(c,c.T,rtol=0,atol=1e-14):
        raise ValueError('FINITE_SYMMETRIC_CORE5_COVARIANCE_REQUIRED')
    if np.linalg.eigvalsh(c).min() < -1e-12:raise ValueError('NON_PSD_COVARIANCE')
    return c


def lower_only(weight,covariance,tier_name):
    try:_,gc,vc,ac=next(t for t in TIERS if t[0]==tier_name)
    except StopIteration:raise ValueError('EXACT_FIXED_TIER_REQUIRED') from None
    w=supported(weight,'float64');c=covariance_checked(covariance)
    if w.shape!=(5,) or not np.isfinite(w).all() or np.abs(w).max()>.30+1e-12 or np.abs(w).sum()>.60+1e-12:
        raise ValueError('FINITE_ORIGINAL_INTRINSIC_ENVELOPE_REQUIRED')
    gross=float(np.abs(w).sum());largest=float(np.abs(w).max());variance=float(w@c@w)
    if variance < -1e-15 or not np.isfinite(variance):raise ValueError('NONNEGATIVE_RISK_REQUIRED')
    sigma=float(np.sqrt(max(0.,variance)))
    factor=min(1.,vc/sigma if sigma>0 else 1.,gc/gross if gross>0 else 1.,ac/largest if largest>0 else 1.)
    out=w.copy() if factor==1. else w*factor;post=float(np.sqrt(max(0.,float(out@c@out))))
    if (not 0<=factor<=1. or np.any(np.abs(out)>np.abs(w)+1e-15) or np.abs(out).sum()>gc+1e-12
        or np.abs(out).max()>ac+1e-12 or post>vc+1e-12):raise ValueError('LOWER_ONLY_POSTCONDITION_FAILED')
    return immutable(out),dict(factor=factor,raw_sigma=sigma,post_sigma=post,reexpanded=False)


def from_components(decisions,static50_retargeted,follow,covariance,*,symbols=SYMBOLS):
    """Original exact samegross first; independently cap each completed arm.

    Intrinsic target gross is equal. Post-tier target gross need not be equal:
    per-arm covariance volatility caps can bind differently. No new common
    scaling rule or post-pool risk retarget is introduced to force equality.
    """
    if tuple(symbols)!=SYMBOLS:raise ValueError('EXACT_ORDERED_CORE5_REQUIRED')
    d=clock(decisions);s=supported(static50_retargeted,'float64');f=supported(follow,'float64');cov=supported(covariance,'float64')
    if s.shape!=(len(d),5) or f.shape!=s.shape or cov.shape!=(len(d),5,5):raise ValueError('EXACT_COMPONENT_SHAPES_REQUIRED')
    o=originals();pair=o.common_gross(d,SYMBOLS,s,d,SYMBOLS,f)
    intrinsic={RECIPES[0]:pair['FOLLOW_POOL_SAMEGROSS'],RECIPES[1]:pair['STATIC50_SAMEGROSS']}
    arrays=dict(decision_us=d,annual_covariance=cov,STATIC50_RETARGETED=s,FOLLOW_ORIGINAL=f,
        POOL_RAW=pair['POOL_RAW'],intrinsic_common_gross=pair['common_gross'])
    arrays.update({'intrinsic_'+name:w for name,w in intrinsic.items()})
    arrays['intrinsic_pool_gross']=np.abs(intrinsic[RECIPES[0]]).sum(axis=1)
    arrays['intrinsic_control_gross']=np.abs(intrinsic[RECIPES[1]]).sum(axis=1)
    arrays['intrinsic_pool_minus_control_gross']=arrays['intrinsic_pool_gross']-arrays['intrinsic_control_gross']
    proofs=[]
    for i,at in enumerate(d):
        tiers={}
        for recipe in RECIPES:
            for tier,*_ in TIERS:
                key=recipe+'_'+tier
                if key not in arrays:arrays[key]=np.empty_like(s)
                arrays[key][i],tiers[key]=lower_only(intrinsic[recipe][i],cov[i],tier)
        gross_diagnostics={}
        for tier,*_ in TIERS:
            pool_gross=float(np.abs(arrays[RECIPES[0]+'_'+tier][i]).sum())
            control_gross=float(np.abs(arrays[RECIPES[1]+'_'+tier][i]).sum())
            gross_diagnostics[tier]=dict(pool_gross=pool_gross,control_gross=control_gross,
                pool_minus_control_gross=pool_gross-control_gross)
        proofs.append(dict(decision_us=int(at),intrinsic_common_gross=float(pair['common_gross'][i]),
            intrinsic_pool_gross=float(arrays['intrinsic_pool_gross'][i]),
            intrinsic_control_gross=float(arrays['intrinsic_control_gross'][i]),
            intrinsic_pool_minus_control_gross=float(arrays['intrinsic_pool_minus_control_gross'][i]),
            intrinsic_static_factor=float(pair['static_factor'][i]),intrinsic_pool_factor=float(pair['pool_factor'][i]),
            tiers=tiers,post_tier_gross=gross_diagnostics,post_tier_samegross_guaranteed=False,source_admitted=False,financial_authorized=False))
    for tier,*_ in TIERS:
        pool_gross=np.abs(arrays[RECIPES[0]+'_'+tier]).sum(axis=1)
        control_gross=np.abs(arrays[RECIPES[1]+'_'+tier]).sum(axis=1)
        arrays['post_tier_pool_gross_'+tier]=pool_gross
        arrays['post_tier_control_gross_'+tier]=control_gross
        arrays['post_tier_pool_minus_control_gross_'+tier]=pool_gross-control_gross
    return {key:immutable(value) for key,value in arrays.items()},proofs


def build_target_grid(close,close_us,available_us,decisions,hlc_available_us,high,low,trade_close,ready,*,symbols=SYMBOLS):
    """Exact original STATIC50 and genuine-HLC FOLLOW equations on supplied arrays.

    HLC must cover each event and previous20 completed days, all five symbols,
    with exact risk-close parity. Source provenance is a separate future gate.
    Unknown required HLC fails the pair rather than creating tradable CASH.
    """
    if tuple(symbols)!=SYMBOLS:raise ValueError('EXACT_ORDERED_CORE5_REQUIRED')
    p=supported(close,'float64');t=clock(close_us);a=clock(available_us);d=clock(decisions);ht=clock(hlc_available_us)
    h=supported(high,'float64');l=supported(low,'float64');hc=supported(trade_close,'float64');r=supported(ready,'bool')
    if p.shape!=(len(t),5) or not np.array_equal(t,a):raise ValueError('EXACT_COMPLETED_CLOSE_AVAILABILITY_REQUIRED')
    if h.shape!=l.shape or h.shape!=hc.shape or h.shape!=r.shape or h.shape!=(len(ht),5):raise ValueError('EXACT_TRADE_HLC_SHAPES_REQUIRED')
    ids=np.searchsorted(t,d);hi=np.searchsorted(ht,d)
    if np.any(ids>=len(t)) or not np.array_equal(t[ids],d) or np.any(ids<199):raise ValueError('ORIGINAL_200_CLOSE_ADMISSION_REQUIRED')
    if np.any(hi>=len(ht)) or not np.array_equal(ht[hi],d) or np.any(hi<20):raise ValueError('ORIGINAL_21_COMPLETED_TRADE_CANDLES_REQUIRED')
    end=int(ids[-1])+1;p=p[:end].copy();t=t[:end].copy()
    lo=int(hi[0])-20;he=int(hi[-1])+1;ht=ht[lo:he].copy();h=h[lo:he].copy();l=l[lo:he].copy();hc=hc[lo:he].copy();r=r[lo:he].copy()
    if not r.all() or not np.isfinite(h).all() or not np.isfinite(l).all() or not np.isfinite(hc).all() or np.any(l<=0) or np.any(l>hc) or np.any(hc>h):
        raise ValueError('COMPLETE_GENUINE_TRADE_HLC_SOURCE_REQUIRED_NO_CASH_IMPUTATION')
    pi=np.searchsorted(t,ht)
    if np.any(pi>=len(t)) or not np.array_equal(t[pi],ht) or not np.array_equal(p[pi],hc):raise ValueError('EXACT_TRADE_HLC_RISK_CLOSE_PARITY_REQUIRED')
    hold_ready=np.zeros(p.shape,dtype=bool)
    for k in range(199,len(t)):hold_ready[k]=np.all(np.isfinite(p[k-199:k+1]) & (p[k-199:k+1]>0),axis=0)
    if not hold_ready[ids].all():raise ValueError('FULL_FIVE_ORIGINAL_200_CLOSE_HOLD_REQUIRED')
    o=originals();feature_ns=dict(np=np,pd=pd,p=p);exec(o.feature_code,feature_ns)
    hold=o.signed_intents(p,feature_ns['signal'],t,SYMBOLS)[ids,2,:]
    matched,mp,states,diag=o.match(t,p,d,hold,hold_ready[ids])
    if any(row['status']!='READY' for row in mp) or not np.asarray(diag['current_eligible'],bool).all():raise ValueError('FULL_FIVE_ORIGINAL_CS_MATCH_REQUIRED')
    old=.5*matched['CS_MATCHED']+.5*matched['VOL_MATCHED']
    retargeted,cov,rp=o.allocate(t,p,d,dict(CS_MATCHED=matched['CS_MATCHED'],VOL_MATCHED=matched['VOL_MATCHED'],STATIC50=old))
    follow,fp=o.targets(ht,h,l,hc,r,t,p,d)
    arrays,proofs=from_components(d,retargeted['STATIC50'],follow['FOLLOW'],cov)
    arrays.update(STATIC50_OLD_NO_REEXPANSION=immutable(old))
    for i,(at,k) in enumerate(zip(d,ids)):
        proofs[i].update(HOLD_oldest_completed_close_us=int(t[k-199]),latest_completed_close_us=int(t[k]),
            CS_weekly_rank_us=int(diag['rank_us'][i]),source_match=mp[i],STATIC50_original_retarget=rp[i]['arms']['STATIC50'],
            FOLLOW_original=fp[i],actual_HLC_provenance_established=False,same_D_execution_unchanged_required=True)
    return arrays,proofs
