import ast
from pathlib import Path
import unittest
from types import SimpleNamespace
import numpy as np
import follow_pair_signal as m
import follow_pair_config as config

class GeneratedChecks(unittest.TestCase):
 def fixture(self,n=300):
  k=np.arange(n+240);t=(k+18000).astype(np.int64)*m.DAY
  p=100*np.exp(.001*k[:,None]+.08*np.sin(k[:,None]*np.arange(1,6)*.19))
  h=p*1.015;l=p*.985;r=np.ones(p.shape,bool)
  for i in range(200,len(t),11):
   h[i,0]=max(h[i-20:i,0].max()*1.2,h[i,0])
   l[i,1]=min(l[i-20:i,1].min()*.8,l[i,1])
  d=t[240:240+n]
  return p,t,d,h,l,r
 def build(self,n=40):
  p,t,d,h,l,r=self.fixture(n)
  return m.build_target_grid(p,t,t,d,t,h,l,p,r)
 def test_exact_original_pinmap_and_source_hashes(self):
  pins=m.verify_sources();self.assertEqual(pins['files']['pinned/follow_original.py']['SHA256'],'d5ff0269d8690e0fc692e063ef7cf19924df0753eace682c6315596637235a8a')
  self.assertEqual(pins['files']['pinned/same_gross_original.py']['SHA256'],'38799b1e93cbbc3d8e94ea702b49bca48ef5aad97478af2c8eaf6f35730a5a9c')
 def test_full_calendar_sizes_and_ceiling_envelopes(self):
  for n in (274,365,366):
   arrays,proofs=self.build(n)
   self.assertEqual(len(proofs),n)
   for recipe in m.RECIPES:
    base=arrays['intrinsic_'+recipe]
    for tier,gc,vc,ac in m.TIERS:
     w=arrays[recipe+'_'+tier];self.assertEqual(w.shape,(n,5));self.assertFalse(w.flags.writeable)
     self.assertTrue(np.all(np.abs(w)<=np.abs(base)+1e-15));self.assertTrue(np.all(np.abs(w).sum(1)<=gc+1e-12))
     vol=np.sqrt(np.maximum(0,np.einsum('ni,nij,nj->n',w,arrays['annual_covariance'],w)))
     self.assertTrue(np.all(vol<=vc+1e-12))
 def test_exact_original_follow_and_samegross_equivalence(self):
  p,t,d,h,l,r=self.fixture(70);arrays,proofs=m.build_target_grid(p,t,t,d,t,h,l,p,r);o=m.originals()
  f,fp=o.targets(t,h,l,p,r,t,p,d)
  np.testing.assert_array_equal(arrays['FOLLOW_ORIGINAL'],f['FOLLOW'])
  pair=o.common_gross(d,m.SYMBOLS,arrays['STATIC50_RETARGETED'],d,m.SYMBOLS,f['FOLLOW'])
  np.testing.assert_array_equal(arrays['intrinsic_'+m.RECIPES[0]],pair['FOLLOW_POOL_SAMEGROSS'])
  np.testing.assert_array_equal(arrays['intrinsic_'+m.RECIPES[1]],pair['STATIC50_SAMEGROSS'])
  self.assertEqual([x['FOLLOW_original'] for x in proofs],fp)
 def test_future_suffix_has_no_prefix_effect(self):
  p,t,d,h,l,r=self.fixture(70);cut=35;want,_=m.build_target_grid(p,t,t,d[:cut],t,h,l,p,r)
  suffix=t>d[cut-1];p[suffix]=np.nan;h[suffix]=np.nan;l[suffix]=np.nan;r[suffix]=False
  got,_=m.build_target_grid(p,t,t,d[:cut],t,h,l,p,r)
  for key in want:np.testing.assert_array_equal(got[key],want[key])
 def test_missing_hlc_is_pair_stop(self):
  p,t,d,h,l,r=self.fixture(40);r[240,2]=False
  with self.assertRaisesRegex(ValueError,'NO_CASH_IMPUTATION'):m.build_target_grid(p,t,t,d,t,h,l,p,r)
 def test_close_parity_is_exact(self):
  p,t,d,h,l,r=self.fixture(40);hc=p.copy();hc[241,2]=np.nextafter(hc[241,2],np.inf)
  with self.assertRaisesRegex(ValueError,'PARITY'):m.build_target_grid(p,t,t,d,t,h,l,hc,r)
 def test_strict_event_boundaries_dual_and_unknown(self):
  o=m.originals();h=np.full(21,110.);l=np.full(21,90.);c=np.full(21,100.);r=np.ones(21,bool)
  h[-1]=120;self.assertEqual(o.rejection(h,l,c,r),(-1,'UPPER_BREAK_REJECTED'))
  c[-1]=110;self.assertEqual(o.rejection(h,l,c,r),(0,'NO_REJECTED_BREAK'))
  c[-1]=100;l[-1]=80;self.assertEqual(o.rejection(h,l,c,r),(0,'BOTH_SIDES_ORDER_UNKNOWN'))
  r[5]=False;self.assertEqual(o.rejection(h,l,c,r),(0,'UNKNOWN_SOURCE'))
 def test_cash_follow_halves_both_not_original_static(self):
  d=np.arange(2,dtype=np.int64)*m.DAY;s=np.tile([.12,.06,-.06,0.,0.],(2,1));f=np.zeros_like(s);c=np.tile(np.eye(5)[None,:,:],(2,1,1))
  arrays,_=m.from_components(d,s,f,c)
  for recipe in m.RECIPES:np.testing.assert_array_equal(arrays['intrinsic_'+recipe],.5*s)
 def test_exact_cancellation_positive_zero(self):
  d=np.arange(2,dtype=np.int64)*m.DAY;s=np.tile([.12,.06,-.06,0.,0.],(2,1));c=np.tile(np.eye(5)[None,:,:],(2,1,1));arrays,_=m.from_components(d,s,-s,c)
  for recipe in m.RECIPES:
   w=arrays['intrinsic_'+recipe];self.assertFalse(np.any(w));self.assertFalse(np.any(np.signbit(w)))
 def test_type_order_clock_covariance_fail_closed(self):
  p,t,d,h,l,r=self.fixture(4)
  for changes in (dict(symbols=m.SYMBOLS[::-1]),):
   with self.assertRaises(ValueError):m.build_target_grid(p,t,t,d,t,h,l,p,r,**changes)
  with self.assertRaises(ValueError):m.build_target_grid(p.astype('float32'),t,t,d,t,h,l,p,r)
  with self.assertRaises(ValueError):m.clock(np.array([0,2*m.DAY],np.int64))
  with self.assertRaises(ValueError):m.covariance_checked(-np.eye(5))
 def test_original_tight_samegross_rounding_guard_is_preserved(self):
  p,t,d,h,l,r=self.fixture(366)
  # The original guard can reject finite bounded arithmetic at its literal
  # 2e-16 tolerance; preserve a direct deterministic input exercising it.
  o=m.originals();rng=np.random.default_rng(9001)
  found=False
  for _ in range(2000):
   s=rng.normal(size=(1,5));s*=.6/np.abs(s).sum()
   f=rng.normal(size=(1,5));f*=.6/np.abs(f).sum()
   if np.abs(s).max()>.3 or np.abs(f).max()>.3:continue
   try:o.common_gross(np.array([0],np.int64),m.SYMBOLS,s,np.array([0],np.int64),m.SYMBOLS,f)
   except ValueError as error:
    if str(error)=='Common target gross equality failed':
     found=True
     with self.assertRaisesRegex(ValueError,'Common target gross equality failed'):m.from_components(np.array([0],np.int64),s,f,np.eye(5)[None,:,:])
     break
  self.assertTrue(found)
 def test_pre_post_gross_diagnostics(self):
  arrays,proofs=self.build(30)
  for i,row in enumerate(proofs):
   self.assertAlmostEqual(row['intrinsic_pool_minus_control_gross'],0.,delta=2e-16)
   for tier,*_ in m.TIERS:
    self.assertEqual(row['post_tier_gross'][tier]['pool_minus_control_gross'],arrays['post_tier_pool_minus_control_gross_'+tier][i])
 def test_typed_specs_preserve_hlc_channel_and_hold_warmup(self):
  import source_spec
  self.assertEqual(len(source_spec.SPECS),5)
  for spec in source_spec.SPECS:
   self.assertEqual(spec.first_hlc_completed_available_us,spec.decision_start_us-20*m.DAY)
   self.assertEqual(spec.first_risk_completed_available_us,spec.decision_start_us-199*m.DAY)
   self.assertFalse(spec.mark_substitution_allowed);self.assertFalse(spec.source_body_read_authorized)
 def test_manifest_all_thirty_fixed(self):
  cells=config.cells();self.assertEqual(len(cells),30);self.assertEqual(len({x['cell_id'] for x in cells}),30)
  self.assertEqual({x['year'] for x in cells},{2021,2022,2023,2024,2025})
  for c in cells:self.assertFalse(c['current_source_admission']);self.assertFalse(c['current_financial_admission'])
  with self.assertRaises(ValueError):config.period_named(2026)
  with self.assertRaises(ValueError):config.period_named(True)

if __name__=='__main__':unittest.main()
