"""Instrumented author/reviewer suite. Never launches historical finance."""
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','POLARS_MAX_THREADS','VECLIB_MAXIMUM_THREADS'):os.environ[key]='1'
import argparse,builtins,io,json,sys,time,unittest
from pathlib import Path
from contextlib import ExitStack
from unittest.mock import patch
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
parser=argparse.ArgumentParser();parser.add_argument('--cpu',type=int,default=7);parser.add_argument('--receipt',required=True);args=parser.parse_args()
if args.cpu not in (6,7,8):raise ValueError('GENERATED_AUTHOR_OR_REVIEW_CPU_ONLY')
os.sched_setaffinity(0,{args.cpu});os.environ['FOLLOW_GENERATED_TEST_CPU']=str(args.cpu)
# Exact read-only exception for the pinned zero-finance failure metadata only.
# Economic files, arrays, other attempts and every nonlisted path stay denied.
import follow_recovery as recovery
recovery_map=recovery._map()
allowed_recovery_paths={ROOT/pin['relative_path'] for pin in recovery_map['evidence_files']}
counts=dict(actual_source_or_target_body_reads=0,actual_financial_body_reads=0,exact_failed_prefinance_metadata_reads=0)
def check(path):
 if isinstance(path,int) or not isinstance(path,(str,bytes,os.PathLike)):return
 p=Path(os.path.abspath(os.fsdecode(path)))
 if ROOT not in p.parents:return
 if p.suffix in ('.npz','.npy','.zip','.csv','.gz') and HERE not in p.parents:
  counts['actual_source_or_target_body_reads']+=1;raise RuntimeError('GENERATED_SUITE_ACTUAL_PAYLOAD_READ_DENIED:'+str(p))
 if p in allowed_recovery_paths:
  counts['exact_failed_prefinance_metadata_reads']+=1;return
 if 'financial_attempts' in p.parts or 'ACTUAL_FINANCIAL' in str(p):
  counts['actual_financial_body_reads']+=1;raise RuntimeError('GENERATED_SUITE_ACTUAL_FINANCIAL_BODY_READ_DENIED:'+str(p))
start=time.monotonic()
with ExitStack() as stack:
 for module in (builtins,io):
  original=module.open
  def opened(file,mode='r',*a,_open=original,**kw):
   if 'r' in mode or '+' in mode:check(file)
   return _open(file,mode,*a,**kw)
  stack.enter_context(patch.object(module,'open',opened))
 original=os.open
 def os_open(path,flags,*a,**kw):
  checked=path
  if isinstance(path,(str,bytes,os.PathLike)) and not os.path.isabs(path) and kw.get('dir_fd') is not None:
   checked=Path(os.readlink('/proc/self/fd/'+str(kw['dir_fd'])))/os.fsdecode(path)
  if not flags & os.O_WRONLY:check(checked)
  return original(path,flags,*a,**kw)
 stack.enter_context(patch.object(os,'open',os_open))
 suite=unittest.defaultTestLoader.loadTestsFromNames(['test_follow_native','test_follow_source_and_authority','test_follow_terminal_partial','test_follow_gate','test_follow_cli','test_follow_process_runtime','test_follow_cold_read','test_follow_recovery','test_follow_disk_admission'])
 result=unittest.TextTestRunner(verbosity=2).run(suite)
receipt=dict(schema='FOLLOW_FIRST6_AUTHOR_GENERATED_CHECKS_V2_CP437_RECOVERY',status='PASS' if result.wasSuccessful() else 'FAIL',tests_run=result.testsRun,failures=len(result.failures),errors=len(result.errors),optimized=bool(sys.flags.optimize),CPU_affinity=sorted(os.sched_getaffinity(0)),elapsed_seconds=time.monotonic()-start,observed_forbidden_attempts={k:v for k,v in counts.items() if k!='exact_failed_prefinance_metadata_reads'},exact_failed_prefinance_metadata_reads=counts['exact_failed_prefinance_metadata_reads'],actual_financial_runs=0,actual_source_recaptures=0,actual_CPU45_workers=0,actual_canonical_claims_created=0,root_financial_GO_created=False,scope='CODE_AND_GENERATED_ONLY_REQUIRES_FRESH_INDEPENDENT_ADMISSION_REVIEW')
Path(args.receipt).write_text(json.dumps(receipt,sort_keys=True,separators=(',',':'))+'\n');print(json.dumps(receipt,sort_keys=True));sys.exit(0 if result.wasSuccessful() else 1)
