"""Finite transparent frozen transport projection; see TRANSPORT_PROJECTION.json."""
from follow_transport import load as _load
_load('follow_quality',globals())
