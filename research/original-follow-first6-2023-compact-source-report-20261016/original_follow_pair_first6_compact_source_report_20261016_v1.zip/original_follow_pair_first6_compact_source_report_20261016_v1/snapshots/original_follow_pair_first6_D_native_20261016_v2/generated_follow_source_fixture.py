"""Invented 2023 canonical minute bytes; metadata does not confer authority."""
from io import BytesIO
from copy import deepcopy
import numpy as np
import follow_native_common as c
import follow_native_config as config
import follow_native_codec as codec
import follow_source_entry as entry

def pack(**arrays):
 out=BytesIO();np.savez_compressed(out,**arrays);return out.getvalue()
def prices(clocks):
 x=(clocks-config.utc('2020-01-01'))/config.DAY
 return np.column_stack([100+j*20+x*(.02+j*.003)+np.sin(x/(7+j)+j)*.4 for j in range(5)])
def fake_source():
 contract=deepcopy(entry.descriptor()['qualified_source_contract']);year=2023
 rows,first,last=codec.STORED_DAILY[year];clock=np.arange(first,last+config.DAY,config.DAY,dtype=np.int64)
 warm=pack(close_available_us=clock,close=prices(clock));period=config.source_year(year)
 decisions=np.arange(period['start'],period['end'],config.DAY,dtype=np.int64);p=prices(decisions)
 daily=c.canonical([dict(symbol=s,close_us=int(at),close=float(p[i,j])) for i,at in enumerate(decisions) for j,s in enumerate(config.SYMBOLS)])
 clocks,close,_=codec.daily_inputs(year,warm,daily);months=[]
 for rec in contract['months']:
  times=np.arange(rec['start'],rec['start']+rec['count']*codec.MINUTE,codec.MINUTE,dtype=np.int64);a=dict(times=times)
  for j,s in enumerate(config.SYMBOLS):
   for field in codec.FIELDS:a[s+'_'+field]=np.full(rec['count'],100+j,dtype=np.float64)
   for at in range(rec['start']+config.DAY,rec['start']+rec['count']*codec.MINUTE+1,config.DAY):
    k=int(np.searchsorted(clocks,at))
    if k<len(clocks) and clocks[k]==at:a[s+'_close'][(at-rec['start'])//codec.MINUTE-1]=close[k,j]
  raw=pack(**a);rec['hash']=c.sha(raw);rec['size']=len(raw);months.append((rec['path'],raw))
 events=[dict(symbol=s,event_us=int(at+15001),raw_rate=(-1 if j%2 else 1)*.000013,reported_interval_hours=8.) for at in decisions for j,s in enumerate(sorted(config.SYMBOLS))]
 contract['events']['selected_events']=len(events)
 sidecar=c.canonical(dict(original200_quality=contract['quality_summary']))
 return year,warm,daily,c.canonical(events),sidecar,tuple(months),contract
