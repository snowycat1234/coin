"""Paid partial/retry/terminal60/native40 generated regression through FOLLOW."""
from copy import deepcopy
from decimal import Decimal as D,localcontext
import ast,unittest
from pathlib import Path
import numpy as np
import follow_native_generated as g
import follow_process_runtime as r

def marks(a,at,overrides=None):
 overrides=overrides or {};base=(50000,2000,20,.5,.05)
 return a.update_marks(at,{s:dict(price=str(overrides.get(s,base[j])),close_us=at,available_us=at) for j,s in enumerate(a.symbols)})
class TerminalTests(unittest.TestCase):
 def test_paid_partial_capacity_renewal_and_latency_through_quality(self):
  e=g.native_reference()
  with g.generated_fixture(days=1) as f:
   sim,guard=g.construct_generated_case(g.project_generated(f),'MID');a=sim.account;start=sim.start;event=start+e.MINUTE+1;marks(a,event-1)
   a.execute_fill('BTCUSDT','SELL','.02',event,start,'GENERATED_INITIAL',execution_mid_price='50000',quote_available_us=event-1,available_quantity='.02')
   at=start+2*e.MINUTE;marks(a,at,{'BTCUSDT':75000});sim.risk_schedule(at)
   a._quality_intervals=((at+e.MINUTE,at+9*e.MINUTE,e.S),);sim.previous_quote={s:75000. if s=='BTCUSDT' else 1e10 for s in e.S}
   base=(50000,2000,20,.5,.05);market={s:dict(open=75000. if s=='BTCUSDT' else base[j],close=75000. if s=='BTCUSDT' else base[j],mark=75000. if s=='BTCUSDT' else base[j],quote_volume=1e10) for j,s in enumerate(e.S)}
   before=abs(a.positions['BTCUSDT'].quantity)
   for k in range(1,6):
    clock=at+k*e.MINUTE;marks(a,clock,{'BTCUSDT':75000});sim.attempt(clock,market)
    rows=[row for row in a.trades if row['event_us']==clock+1];self.assertEqual(sum((D(row['decimal_strings']['quantity']) for row in rows),D(0)),D('.001'))
   self.assertEqual(abs(a.positions['BTCUSDT'].quantity),before-D('.005'));self.assertEqual(a.pending_exits['BTCUSDT']['renewals'],1)
   frozen=a.positions['BTCUSDT'].quantity
   marks(a,at+6*e.MINUTE,{'BTCUSDT':75000});sim.attempt(at+6*e.MINUTE,market);self.assertEqual(a.positions['BTCUSDT'].quantity,frozen)
   marks(a,at+7*e.MINUTE,{'BTCUSDT':75000});sim.attempt(at+7*e.MINUTE,market);self.assertEqual(a.positions['BTCUSDT'].quantity,frozen+D('.001'));self.assertFalse(a.transfer_journal)
 def test_terminal60_and_fraction_ladder_are_frozen(self):
  e=g.native_reference();runtime=e.V2.native.runtime();terminal=runtime[0] if hasattr(runtime[0],'TERMINAL_OPENS') else None
  import sys
  terminal=next(m for m in sys.modules.values() if m is not None and getattr(m,'TERMINAL_OPENS',None)==60 and hasattr(m,'EarlierTerminalSimulator'))
  self.assertEqual(terminal.TERMINAL_OPENS,60);self.assertEqual(tuple(str(x) for x in sys.modules['candidate'].FRACTIONS),('1','0.75','0.5','0.25','0'))
  with g.generated_fixture(days=1) as f:
   sim,guard=g.construct_generated_case(g.project_generated(f),'LOW')
   self.assertEqual(sim.terminal_signal_us,sim.end-61*e.MINUTE)
   while sim.cursor<sim.end and sim.stop is None:sim.advance_day()
   result=e.case_result(sim,guard);self.assertTrue(result['economics']['paid_flat']);self.assertTrue(result['economics']['full_calendar']);self.assertGreater(sim.account.fees,0)
 def test_native40_rejects_decimal_sub_ulp_and_false_paid_flat(self):
  e=g.native_reference();import follow_process_runtime
  from saved_native_reconciliation import reconcile_saved_native
  with g.generated_fixture(days=1) as f:
   sim,guard=g.construct_generated_case(g.project_generated(f),'LOW')
   while sim.cursor<sim.end and sim.stop is None:sim.advance_day()
   result=e.case_result(sim,guard);result.pop('minute');result['targets']=result['targets'].to_dicts();result=e.V2.OWNED.export_tree(result);audit=e.V2.OWNED.export_tree(sim.account.snapshot())
   self.assertTrue(reconcile_saved_native(audit,result,expected_continuation_version=e.VERSION)['passed'])
   for key in ('free_cash','unpaid_liability'):
    bad=deepcopy(audit)
    with localcontext() as ctx:ctx.prec=100;bad[key]=str(D(bad[key])+D('1e-38'))
    with self.assertRaises(ValueError):reconcile_saved_native(bad,result,expected_continuation_version=e.VERSION)
   bad=deepcopy(result);bad['economics']['actual_paid_market_flat']=False
   with self.assertRaises(ValueError):r.classify_terminal(audit,bad,calendar=[sim.start,sim.end],completed_minutes=sim.rows_written,stop_us=sim.stop)
if __name__=='__main__':unittest.main(verbosity=2)
