"""Real gate contracts exercised with generated authority bytes in memory only."""
import unittest
from copy import deepcopy
import follow_native_common as c
import follow_finance_gate as gate
import follow_source_entry as entry
class GateTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.prep=c.ordinary(c.ROOT/'original_follow_pair_D_source_20261016_v1/source_attempts/ACTUAL_ALL30_SOURCE_TARGET_ONLY_attempt001/PREPARATION.json')
  cls.audit=c.ordinary(c.ROOT/'original_follow_pair_D_prepared_independent_review_20261016_v1/PREPARED_REVIEW.json')
 def bundle(self):
  nr=c.canonical(gate.native_policy('0'*64));rr=c.canonical(gate.review_policy(self.prep,c.sha(self.audit),c.sha(nr)))
  go=c.canonical(gate.policy(self.prep,c.sha(rr),c.sha(self.audit),c.sha(nr),[4,5]));return go,rr,nr
 def check(self,go,rr,nr):return gate.validate(self.prep,go,c.sha(go),rr,c.sha(rr),self.audit,c.sha(self.audit),nr,c.sha(nr))
 def test_exact_real_gate_positive_all6_in_memory(self):
  value=self.check(*self.bundle());self.assertEqual(len(value['ordered_cells']),6);self.assertFalse(value['remaining24_authorized'])
  with self.assertRaises(TypeError):value['remaining24_authorized']=True
 def test_every_missing_extra_and_changed_go_field_rejected(self):
  go,rr,nr=self.bundle();value=c.exact_object(go)
  for key in value:
   bad=deepcopy(value);bad.pop(key)
   with self.subTest(missing=key),self.assertRaises((ValueError,KeyError,TypeError)):self.check(c.canonical(bad),rr,nr)
  for key in ('remaining24_authorized','automatic_retry_authorized','topup_authorized','saved_targets_rebuilt_during_finance','target_byte_equivalence_execution_reuse_authorized','other_years_or_holdouts_authorized'):
   bad=deepcopy(value);bad[key]=True
   with self.subTest(changed=key),self.assertRaises(ValueError):self.check(c.canonical(bad),rr,nr)
  bad=dict(value,unreviewed_extra=True)
  with self.assertRaises(ValueError):self.check(c.canonical(bad),rr,nr)
 def test_exact_old_v1_GO_rejected_with_new_valid_reviews(self):
  go,rr,nr=self.bundle()
  old=c.ordinary(c.ROOT/'original_follow_pair_first6_D_native_20261016_v1/ROOT_FIRST6_FINANCIAL_APPROVED_20261016_0245.json')
  with self.assertRaisesRegex(ValueError,'FRESH_FIRST6_ROOT_FINANCIAL_AUTHORITY'):self.check(old,rr,nr)
  self.assertNotEqual(c.exact_object(old)['schema'],gate.GO_SCHEMA)
 def test_guard_transport_and_frozen_source_bytes_unchanged(self):
  old=c.ROOT/'original_follow_pair_first6_D_native_20261016_v1'
  for name in ('follow_transport.py','follow_native_source_guard.py','follow_native_codec.py','follow_native_source.py','follow_native_source2023.py','follow_input_loader.py','follow_admission.py','follow_native.py'):
   with self.subTest(name=name):self.assertEqual(c.ordinary(c.HERE/name),c.ordinary(old/name))
 def test_review_and_native_extra_fields_rejected(self):
  go,rr,nr=self.bundle()
  with self.assertRaises(ValueError):self.check(go,c.canonical(dict(c.exact_object(rr),unreviewed=True)),nr)
  with self.assertRaises(ValueError):self.check(go,rr,c.canonical(dict(c.exact_object(nr),financial_execution_authorized=True)))
if __name__=='__main__':unittest.main(verbosity=2)
