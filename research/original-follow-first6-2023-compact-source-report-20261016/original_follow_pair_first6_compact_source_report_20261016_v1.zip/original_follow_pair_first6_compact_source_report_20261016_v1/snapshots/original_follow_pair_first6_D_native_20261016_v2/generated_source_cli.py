"""Fresh-process source-boundary integration using invented bytes only.

Mocks apply only to generated metadata and source retrieval. They are not
production APIs, authority files, or historical execution capabilities.
"""
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','POLARS_MAX_THREADS','VECLIB_MAXIMUM_THREADS'):os.environ[key]='1'
import json,sys,tempfile
from pathlib import Path
from contextlib import ExitStack
from unittest.mock import patch
import numpy as np
import follow_native_bootstrap
import follow_native_common as c
import follow_native_config as config
import follow_source_entry as entry
import follow_finance_gate as gate
import follow_verified_wires as verified
import follow_input_loader as loader
import follow_native_source as native_source
import follow_native_source_scope as scope
import follow_native_signal as signal
from follow_native_source_guard import SourceOnlyGuard,SourceBoundaryViolation
from generated_follow_source_fixture import fake_source,pack
import follow_entry as original
from follow_native_source2023 import assemble_inputs

def main(mode):
 if sorted(os.sched_getaffinity(0)) not in ([6],[7],[8]):raise ValueError('GENERATED_REVIEW_CPU_REQUIRED')
 captured=assemble_inputs(*fake_source());signal.reviewed_signal()
 arrays={k:np.zeros(shape,dtype=dtype) for k,(shape,dtype) in entry.array_specs(2023).items()};arrays['decision_us']=captured['decisions']
 identities={k:signal.array_byte_identity(v) for k,v in arrays.items()}
 meta=dict(source_identity=captured['source_identity'],source_rows_SHA256=c.jsha(captured['source_rows']),funding_events_SHA256=c.jsha(captured['events']),source_quality_sidecar_SHA256=c.sha(captured['sidecar_raw']),array_identities=identities)
 wires={key:c.canonical(dict(generated_wire=key)) for key in ('go','review','prepared-review','native-review','source-go','source-review')};wires['go']=c.canonical(dict(generated_wire='go',ordered_cells=list(entry.tranche_cells(entry.FIRST6))));hashes={k:c.sha(v) for k,v in wires.items()};cell=config.cells()[0]['cell_id']
 source_raw=c.canonical(dict(generated_preparation=True));code='a'*64
 artifacts={'2023/TARGETS.npz':pack(**arrays),'2023/SOURCE_PREFIX_INPUTS.npz':pack(close_available_us=captured['clocks'],close=captured['close'])}
 p=dict(ordered_cells=list(entry.tranche_cells(entry.FIRST6)),years={'2023':meta},artifacts={k:dict(SHA256=c.sha(v),bytes=len(v)) for k,v in artifacts.items()},source_stage_GO_SHA256=hashes['source-go'],source_review_SHA256=hashes['source-review'])
 claim=c.canonical(dict(cell_id=cell,root_GO_SHA256=hashes['go'],preparation_SHA256=c.sha(source_raw),code_identity=code))
 with tempfile.TemporaryDirectory(prefix='GENERATED_FOLLOW_CLI_ONLY_') as td,ExitStack() as stack:
  root=Path(td);(root/'2023').mkdir();(root/'PREPARATION.json').write_bytes(source_raw)
  for name,raw in artifacts.items():(root/name).write_bytes(raw)
  stack.enter_context(patch.object(entry,'validate_preparation_metadata',return_value=p));stack.enter_context(patch.object(entry,'validate_source_authority_metadata',return_value={}))
  stack.enter_context(patch.object(gate,'validate',return_value={}));stack.enter_context(patch.object(gate,'code_identity',return_value=code))
  stack.enter_context(patch.object(original,'source_maps',return_value=({'years':{'2023':{'prefix_metadata':{'selected_rows':len(captured['clocks'])}}}},{})))
  def capture(year,value):
   if type(value) is not scope.SourcePreparationScope:raise ValueError('GENUINE_FOLLOW_NATIVE_SCOPE_REQUIRED')
   value.validate_current(year=year)
   if mode=='capture_failure':raise ValueError('GENERATED_CAPTURE_FAILURE')
   return captured
  stack.enter_context(patch.object(native_source,'capture_year',side_effect=capture))
  allow=[root/'PREPARATION.json',*(root/name for name in artifacts)]
  code_manifest=c.exact_object(c.ordinary(c.HERE/'FINANCIAL_CODE_MANIFEST.json'))
  allow.extend(c.HERE/name for name in code_manifest['files']);allow.extend(c.ROOT/name for name in code_manifest['dependencies']);allow.append(c.HERE/'FINANCIAL_CODE_MANIFEST.json')
  guard=SourceOnlyGuard(read_paths=allow,write_roots=());loaded=None;error=None
  try:
   with verified.verify(preparation_raw=source_raw,cell_id=cell,raw=wires,hashes=hashes,claim_raw=claim) as binding:
    with guard:
     guard.checkpoint('FRESH_WORKER_FOLLOW_FIRST6_SOURCE_RECAPTURE_BEFORE_FINANCE_IMPORT')
     if mode=='guard_failure':
      try:__import__('subprocess').run(['GENERATION_MUST_NOT_LAUNCH'])
      except SourceBoundaryViolation:pass
     loaded=loader.load_year(root,expected_preparation_sha256=c.sha(source_raw),year=2023,
      source_go_raw=wires['source-go'],expected_source_go_sha256=hashes['source-go'],source_review_raw=wires['source-review'],expected_source_review_sha256=hashes['source-review'],
      financial_go_raw=wires['go'],expected_financial_go_sha256=hashes['go'],financial_review_raw=wires['review'],expected_financial_review_sha256=hashes['review'],
      prepared_review_raw=wires['prepared-review'],expected_prepared_review_sha256=hashes['prepared-review'],native_review_raw=wires['native-review'],expected_native_review_sha256=hashes['native-review'],verified_binding=binding)
     guard.checkpoint('EXACT_SAVED_FOLLOW_FIRST6_TARGETS_LOADED_WITHOUT_REGENERATION')
    loaded.validate()
  except BaseException as exc:error=type(exc).__name__+':'+str(exc)
  finally:
   if loaded is not None:loader.revoke(loaded)
  phases=[]
  if mode=='positive' and error is None:
   # Exercise the real parser and worker dispatch, with a constructor sentinel
   # after the guarded loader. Production CPU limits are deliberately
   # reassigned to this generated review CPU; no CPU4/5 process exists.
   import run_follow,types
   from contextlib import contextmanager
   class StopBeforeNative(Exception):pass
   out=root/'case';out.mkdir();argv=['run_follow.py','--case','--cell-id',cell,'--cpu',str(min(os.sched_getaffinity(0))),'--case-output',str(out),'--preparation',str(root),'--preparation-sha',c.sha(source_raw)]
   for key,raw in wires.items():
    wire_path=root/(key+'.generated.json');wire_path.write_bytes(raw);argv+=['--'+key,str(wire_path),'--'+key+'-sha',hashes[key]]
   @contextmanager
   def stop_native(*args,**kwargs):
    assert not verified._LIVE and not scope._LIVE
    assert __import__('follow_native_source_guard').current_guard() is None
    phases.append('POST_GUARD_CONSTRUCTOR_SENTINEL')
    raise StopBeforeNative('GENERATED_STOP_BEFORE_ACCOUNT_SCOPE_OR_PROVIDER')
    yield
   original_save=run_follow.r.save
   def recording_save(path,value):
    original_save(path,value)
    if Path(path).name=='WORKER_AUTHORITY_VERIFIED.json':phases.append('REAL_WORKER_AUTHORITY_VERIFIED')
    if Path(path).name=='WORKER_SOURCE_ACCEPTED_BEFORE_ACCOUNT.json':
     phases.append('SOURCE_ACCEPTED_GUARD_EXITED')
     m=types.ModuleType('follow_admission');m.admit_case=stop_native;sys.modules['follow_admission']=m
     sys.modules['follow_native']=types.ModuleType('follow_native')
   with patch.object(sys,'argv',argv),patch.object(run_follow.r,'apply_limits',side_effect=lambda cpu:None),patch.object(run_follow,'worker_claim',return_value=claim),patch.object(run_follow.r,'save',side_effect=recording_save):
    try:run_follow.main()
    except StopBeforeNative:pass
    else:raise AssertionError('CONSTRUCTOR_SENTINEL_NOT_REACHED')
   for name in ('follow_admission','follow_native'):sys.modules.pop(name,None)
   assert phases==['REAL_WORKER_AUTHORITY_VERIFIED','SOURCE_ACCEPTED_GUARD_EXITED','POST_GUARD_CONSTRUCTOR_SENTINEL'],phases
   assert not loader._LIVE and not verified._LIVE and not scope._LIVE
   real_receipt=c.exact_object((out/'SOURCE_RECAPTURE_GUARD_RECEIPT.json').read_bytes())
   assert not any(real_receipt['forbidden_attempts'].values()),real_receipt
  receipt=guard.receipt('PASS_FINANCIAL_WORKER_SOURCE_ONLY_RECAPTURE' if error is None else 'STOP_GENERATED')
  receipt.update(real_CLI_phases=phases,mode=mode,error=error,scopes_revoked=not verified._LIVE and not scope._LIVE and not loader._LIVE,finance_modules_imported=[n for n in sys.modules if n in ('follow_admission','follow_native')],CPU_affinity=sorted(os.sched_getaffinity(0)),actual_financial_runs=0,actual_payload_reads=0)
  print(json.dumps(receipt,sort_keys=True))
  if mode=='positive' and error:raise RuntimeError(error)
  if mode!='positive' and error is None:raise RuntimeError('EXPECTED_GENERATED_FAILURE_NOT_OBSERVED')

if __name__=='__main__':main(sys.argv[1])
