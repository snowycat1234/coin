"""Bind genuine FOLLOW source modules; no native finance import occurs here."""
from pathlib import Path
import sys
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
SOURCE=ROOT/'original_follow_pair_D_source_20261016_v1'
if str(SOURCE) not in sys.path:sys.path.insert(0,str(SOURCE))
import follow_common,follow_config,follow_codec,follow_entry,follow_signal
for name in ('follow_common','follow_config','follow_codec','follow_entry','follow_signal'):
 if Path(sys.modules[name].__file__).resolve()!=SOURCE/(name+'.py'):
  raise ValueError('EXACT_FROZEN_FOLLOW_SOURCE_MODULE_REQUIRED:'+name)
