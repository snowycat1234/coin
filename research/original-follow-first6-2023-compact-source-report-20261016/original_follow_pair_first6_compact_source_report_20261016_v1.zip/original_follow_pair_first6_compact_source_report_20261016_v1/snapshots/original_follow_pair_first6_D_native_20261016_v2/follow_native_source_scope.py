"""Finite native-source recapture capability; never source-stage authority.

Only an externally verified, already-consumed financial wire binding can mint
this scope. The frozen source-only scope keeps its separate saved-input universe.
No historical scope, provider, account or CS authority exists in this module.
"""
from contextlib import contextmanager
from dataclasses import dataclass, field
from pathlib import Path
from types import SimpleNamespace
import follow_native_bootstrap
import follow_native_common as c
import follow_native_config as config
import follow_source_entry as source_entry
import follow_verified_wires as verified

_SEAL=object();_LIVE={}
HERE=Path(__file__).resolve().parent


def contracts():
    return {'years':{year:record['qualified_source_contract']
        for year,record in source_entry.contracts()['years'].items()}}


@dataclass(frozen=True,slots=True)
class SourcePreparationScope:
    year:int
    _binding:object=field(repr=False)
    _token:object=field(repr=False)
    _seal:object=field(repr=False)
    def __post_init__(self):
        if self._seal is not _SEAL:raise ValueError('EXACT_FINANCIAL_NATIVE_SOURCE_RECAPTURE_SEAL_REQUIRED')
    def validate_current(self,*,year=None):
        from follow_native_source_guard import current_guard
        guard=current_guard()
        if (_LIVE.get(self._token) is not self or self._seal is not _SEAL
                or guard is None or not guard.active):
            raise ValueError('LIVE_GUARDED_FINANCIAL_NATIVE_SOURCE_CAPTURE_REQUIRED')
        verified.require_consumed(self._binding,year=self.year)
        if year is not None and (type(year) is not int or year!=self.year):
            raise ValueError('EXACT_NATIVE_SOURCE_CAPTURE_YEAR_REQUIRED')
        guard.checkpoint('SOURCE_SCOPE_CHECK');return True
    def source_root(self,year):
        self.validate_current(year=year)
        return c.ROOT/c.relative(contracts()['years'][str(year)]['source_root'])
    def qualification_for(self,year):
        self.validate_current(year=year)
        return SimpleNamespace(source_identity=contracts()['years'][str(year)]['source_identity'])
    def read_source(self,year,name,expected_sha256,expected_bytes=None):
        self.validate_current(year=year);name=c.relative(name)
        pin=contracts()['years'][str(year)]['read_files'].get(name)
        if (pin is None or pin['SHA256']!=expected_sha256
                or expected_bytes is not None and (type(expected_bytes) is not int or expected_bytes!=pin['bytes'])):
            raise ValueError('EXACT_REVIEWED_NATIVE_SOURCE_ONLY_ALLOWLIST_REQUIRED_NO_TARGETS_OR_CS_AUTHORITY')
        return c.exact(c.ROOT/name,expected_sha256,pin['bytes'])


@contextmanager
def admit_capture(binding,*,year):
    config.source_year(year);verified.require_consumed(binding,year=year)
    token=object();scope=SourcePreparationScope(year,binding,token,_SEAL);_LIVE[token]=scope
    try:scope.validate_current(year=year);yield scope
    finally:_LIVE.pop(token,None)
