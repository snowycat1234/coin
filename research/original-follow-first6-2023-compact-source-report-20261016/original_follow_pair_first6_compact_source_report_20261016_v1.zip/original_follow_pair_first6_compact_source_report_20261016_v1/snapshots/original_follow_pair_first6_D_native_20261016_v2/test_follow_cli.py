"""CPU7 fresh CLI guard, typed source capability and immutable loader checks."""
import json,os,subprocess,sys,unittest
from pathlib import Path
class CliTests(unittest.TestCase):
 def test_fresh_generated_cli_positive_and_failures(self):
  for mode in ('positive','capture_failure','guard_failure'):
   command=[sys.executable,'-B']+(['-O'] if sys.flags.optimize else [])+[str(Path(__file__).with_name('generated_source_cli.py')),mode]
   p=subprocess.run(command,capture_output=True,text=True,check=False)
   with self.subTest(mode=mode):
    self.assertEqual(p.returncode,0,p.stderr+'\n'+p.stdout[-500:]);r=json.loads(p.stdout)
    self.assertTrue(r['scopes_revoked']);self.assertEqual(r['finance_modules_imported'],[]);self.assertEqual(r['actual_financial_runs'],0)
    self.assertEqual(r['CPU_affinity'],sorted(os.sched_getaffinity(0)))
    if mode=='positive':self.assertFalse(any(r['forbidden_attempts'].values()));self.assertIsNone(r['error'])
    if mode=='guard_failure':self.assertGreater(r['forbidden_attempts']['process_launches'],0)
 def test_real_follow_cli_help_no_financial_authority_or_workers(self):
  p=subprocess.run([sys.executable,'-B',str(Path(__file__).with_name('run_follow.py')),'--help'],capture_output=True,text=True)
  self.assertEqual(p.returncode,0,p.stderr);self.assertIn('--go-sha',p.stdout)
if __name__=='__main__':unittest.main(verbosity=2)
