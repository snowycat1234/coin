"""FOLLOW first6 generated process/disk/claim transport tests.

Only simulated logical workers use CPU4/5. The test controller and any actual
stdlib resource probe must be explicitly assigned CPU7. No market body reads.
"""
import os
def selected_cpu():
    value=int(os.environ.get('FOLLOW_GENERATED_TEST_CPU','7'))
    if value not in (6,7,8):raise ValueError('GENERATED_AUTHOR_REVIEW_CPU6_7_8_ONLY')
    return value
from contextlib import contextmanager
import fcntl
from pathlib import Path
from types import SimpleNamespace
import sys
import tempfile
import unittest
from unittest.mock import patch
import follow_process_runtime as frozen
HERE=Path(__file__).resolve().parent
REPAIR=HERE.parent/'cs_saved_minute_reporting_repair_20261015_v2'
if str(REPAIR) not in sys.path:sys.path.insert(0,str(REPAIR))
import bounded_drain as d
class Model:
    def __init__(self, root, *, fault=None, fail=('A',), durations=None):
        self.root=Path(root);self.now=100.;self.processes={};self.spawned=[];self.killed=[]
        self.claims=[];self.validated=[];self.lock_checks=[];self.fault=fault;self.fail=set(fail)
        self.durations=durations or {'A':.2,'B':.7,'C':.1};self.fd=None
        self.runtime=SimpleNamespace(**{k:getattr(frozen,k) for k in
            ('LIMITS','HERE','utc','sha','save','own_bytes','environment')})
        self.runtime.choose_worker_count=lambda requested,cpus,obs:2
        self.runtime.process_observation=self.observation
        self.runtime.host_observation=lambda:{'generated_model_only':True}
        self.runtime._CONTROLLER_LEASE_FD=None

    def lock_held(self):
        if self.fd is None:raise ValueError('GENERATED_LEASE_DESCRIPTOR_REQUIRED')
        p=self.root/'registry'/frozen.MANIFEST_SHA256/'CONTROLLER_LEASE.lock'
        with p.open('r+') as stream:
            try:fcntl.flock(stream.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
            except BlockingIOError:self.lock_checks.append(True);return
            fcntl.flock(stream.fileno(),fcntl.LOCK_UN)
            raise AssertionError('LEASE_LOST_DURING_DRAIN')

    def observation(self,pid):
        if self.fd is not None:self.lock_held()
        p=self.processes.get(pid)
        if not p:return None
        rss=1000
        if self.fault=='AGGREGATE':rss=1_800_000_000
        if self.now>=100.4:
            if self.fault=='RSS':rss=2_000_000_001
        cpu=p.cpu
        if self.fault=='AFFINITY' and self.now>=100.4:cpu=8
        return dict(PID=pid,RSS_bytes=rss,CPU_affinity=[cpu],tasks=[dict(CPU_affinity=[cpu])],process_start_ticks=str(pid))

    def popen(self,command,**kwargs):
        if self.fault=='DENIED_SPAWN':raise PermissionError('GENERATED_DENIED_PROCESS_LAUNCH')
        # Simulated workers only: logical labels never select a real CPU.
        cpu=int(command[4]);directory=Path(command[5]);cell=directory.name
        self.assert_lease(kwargs)
        pid=90000+len(self.spawned)
        self.spawned.append(cell)
        model=self
        class Process:
            def __init__(self):
                self.pid=pid;self.cpu=cpu;self.start=model.now;self.directory=directory;self.dead=False
            def poll(self):
                if self.dead:return -9
                if model.fault=='WALL' and cell=='B':return None
                if model.fault=='BOOTSTRAP' and cell=='B':return None
                if model.now-self.start<model.durations[cell]-1e-8:return None
                if model.fault=='PROCESS' and cell=='B':return 7
                if not (directory/'TERMINAL_CHECKPOINT.json').exists():
                    frozen.save(directory/'TERMINAL_CHECKPOINT.json',dict(generated=True,cell=cell))
                return 0
            def wait(self):self.dead=True;return -9
        p=Process();self.processes[pid]=p
        if not (self.fault=='BOOTSTRAP' and cell=='B'):
            frozen.save(directory/'BOOTSTRAP_READY.json',dict(generated=True))
        return p

    def assert_lease(self,kwargs):
        if kwargs['pass_fds'] != (self.fd,frozen._SHARED_RESOURCE_LEASE_FD):raise ValueError('EXACT_GENERATED_INHERITED_DESCRIPTORS_REQUIRED')
        if kwargs['env']['LEGACY_SHARED_CPU45_LEASE_FD'] != str(frozen._SHARED_RESOURCE_LEASE_FD):raise ValueError('GENERATED_SHARED_LEASE_REQUIRED')
        if kwargs['env']['MATRIX_CONTROLLER_LEASE_FD'] != str(self.fd):raise ValueError('GENERATED_CONTROLLER_LEASE_REQUIRED')
        self.lock_held()

    def kill(self,pid,sig):self.killed.append(pid);self.processes[pid].dead=True
    def sleep(self,seconds):
        self.now+=200. if self.fault=='WALL' and 'A' in self.validated else seconds
        if self.fault=='OUTPUT' and self.now>=100.4:
            b=self.root/'output'/'B'/'oversized.generated'
            with b.open('wb') as stream:stream.truncate(250_000_001)
    def validator(self,directory,cell):
        self.validated.append(cell)
        if cell in self.fail:raise ValueError('GENERATED_SAVED_VALIDATOR_FAIL:'+cell)
        self.lock_held();return dict(status='GENERATED_TERMINAL')
    def before(self,cell,directory,cpu):
        self.claims.append(cell);frozen.save(self.root/(cell+'.generated_claim.json'),dict(cell=cell,generated_only=True))
    def run(self):
        jobs=[(c,lambda directory,cpu,c=c:['generated-no-real-process',c]) for c in ('A','B','C')]
        shared=self.root/'GENERATED_SHARED_CPU45.lock';shared.touch()
        @contextmanager
        def fake_envelope(cpus):
            if cpus != [4,5] or sorted(os.sched_getaffinity(0)) != [selected_cpu()]:
                raise ValueError('GENERATED_MODEL_EXACT_CPU7_AFFINITY_REQUIRED')
            yield
        with patch.object(frozen,'shared_resource_lease_path',return_value=shared):
            with frozen.controller_lease(self.root/'registry') as fd:
                self.fd=fd;self.runtime._CONTROLLER_LEASE_FD=fd
                with patch.object(d.subprocess,'Popen',self.popen),patch.object(d.os,'killpg',self.kill),patch.object(d.time,'monotonic',lambda:self.now),patch.object(d.time,'sleep',self.sleep),patch.object(frozen,'choose_worker_count',self.runtime.choose_worker_count),patch.object(frozen,'process_observation',self.observation),patch.object(frozen,'cpu_envelope',fake_envelope),patch.object(frozen,'check_full_cohort_budget',return_value={'generated_full_cap_admission':True}):
                    return frozen.run_pool(jobs,self.root/'output',requested_workers=2,cpus=[4,5],validator=self.validator,observation_callback=self.runtime.host_observation,before_launch=self.before)


class RuntimeModelTests(unittest.TestCase):

    def model(self, **kwargs):
        temp = tempfile.TemporaryDirectory(prefix='GENERATED_FOLLOW_MODEL_')
        self.addCleanup(temp.cleanup)
        return Model(temp.name, **kwargs)

    def test_saved_failure_drains_peer_preserves_pause_no_C_spawn_no_retry(self):
        m = self.model()
        with self.assertRaises(d.SavedValidationPause) as caught:
            m.run()
        report = caught.exception.report
        self.assertEqual(m.spawned, ['A', 'B'])
        self.assertEqual(m.claims, ['A', 'B'])
        self.assertEqual(m.validated, ['A', 'B'])
        self.assertEqual(m.killed, [])
        self.assertEqual(report['pending_not_launched'], ['C'])
        self.assertEqual(report['cases'][0]['cell_id'], 'B')
        self.assertEqual(report['status'], 'SAVED_VALIDATION_PAUSE_DRAINED_NO_RETRY')
        self.assertTrue(report['original_pause_preserved'])
        self.assertTrue(report['no_automatic_retry'])
        self.assertTrue(all(m.lock_checks))
        self.assertGreater(len(m.lock_checks), 4)
        self.assertFalse((m.root / 'output' / 'C').exists())

    def test_both_saved_validators_fail_original_nonzero_pause_retained(self):
        m = self.model(fail=('A', 'B'))
        with self.assertRaises(d.SavedValidationPause) as caught:
            m.run()
        self.assertEqual([r['cell_id'] for r in caught.exception.report['saved_validation_errors']], ['A', 'B'])
        self.assertEqual(m.spawned, ['A', 'B'])
        self.assertEqual(m.killed, [])

    def test_resource_faults_during_drain_immediately_stop_peer(self):
        for fault, expected in [('RSS', 'WORKER_RSS_LIMIT'), ('AFFINITY', 'WORKER_AFFINITY_LIMIT'), ('OUTPUT', 'WORKER_OUTPUT_LIMIT'), ('WALL', 'WORKER_WALL_LIMIT'), ('BOOTSTRAP', 'WORKER_BOOTSTRAP_STARTUP_LIMIT'), ('PROCESS', 'WORKER_FAILED_EXECUTION')]:
            with self.subTest(fault=fault):
                m = self.model(fault=fault)
                with self.assertRaisesRegex(RuntimeError, expected) as caught:
                    m.run()
                self.assertNotIsInstance(caught.exception, d.SavedValidationPause)
                self.assertEqual(m.spawned, ['A', 'B'])
                self.assertEqual(m.claims, ['A', 'B'])
                self.assertTrue(caught.exception.original_pause_preserved)
                self.assertEqual(caught.exception.saved_validation_errors[0]['cell_id'], 'A')
                if fault != 'PROCESS':
                    self.assertTrue(m.killed)

    def test_initial_saved_failure_never_spawns_pending(self):
        m = self.model()
        p = m.root / 'output' / 'A'
        p.mkdir(parents=True)
        frozen.save(p / 'TERMINAL_CHECKPOINT.json', dict(generated=True))
        with self.assertRaisesRegex(ValueError, 'GENERATED_SAVED_VALIDATOR_FAIL:A'):
            m.run()
        self.assertEqual(m.spawned, [])
        self.assertEqual(m.claims, [])
        self.assertFalse((m.root / 'output' / 'B').exists())

    def test_aggregate_RSS_fault_kills_immediately_before_saved_pause(self):
        m = self.model(fault='AGGREGATE')
        with self.assertRaisesRegex(RuntimeError, 'AGGREGATE_LIVE_RSS_LIMIT'):
            m.run()
        self.assertEqual(m.spawned, ['A', 'B'])
        self.assertEqual(len(m.killed), 2)
        self.assertEqual(m.validated, [])

    def test_drain_does_not_reapply_new_launch_memory_admission(self):
        m = self.model()

        def capacity(*args):
            if m.validated:
                raise AssertionError('NEW_LAUNCH_ADMISSION_USED_DURING_PAUSE')
            return 2
        m.runtime.choose_worker_count = capacity
        with self.assertRaises(d.SavedValidationPause):
            m.run()
        self.assertEqual(m.validated, ['A', 'B'])

    def test_unfinished_existing_directory_not_retried(self):
        m = self.model()
        (m.root / 'output' / 'A').mkdir(parents=True)
        with self.assertRaisesRegex(RuntimeError, 'EXISTING_UNFINISHED_CASE_PAUSE_NO_RETRY'):
            m.run()
        self.assertEqual(m.spawned, [])

    def test_happy_path_all_jobs_once(self):
        m = self.model(fail=())
        report = m.run()
        self.assertEqual(m.spawned, ['A', 'B', 'C'])
        self.assertEqual(m.claims, ['A', 'B', 'C'])
        self.assertEqual(report['status'], 'ALL_ADMITTED_ORDERED_CELLS_TERMINAL')
        self.assertEqual(report['saved_validation_errors'], [])

    def test_exact_runtime_limits_CPU7_only_and_no_live_leases_after_model(self):
        self.assertEqual(frozen.LIMITS,d.EXACT_LIMITS)
        self.assertEqual(sorted(os.sched_getaffinity(0)),[selected_cpu()])
        self.assertIsNone(frozen._CONTROLLER_LEASE_FD);self.assertIsNone(frozen._SHARED_RESOURCE_LEASE_FD)


r=frozen

def observed(*,free=10_000_000_000,used=0):
    return dict(free_bytes=free,cohort_output_log_temporary_bytes=used,**r.COHORT_DISK_POLICY)


class DiskSafetyTests(unittest.TestCase):
    def test_exact_thresholds_and_boundary_values_are_resource_not_economic(self):
        self.assertEqual(r.COHORT_DISK_POLICY['minimum_free_bytes'],1810612736)
        self.assertEqual(r.COHORT_DISK_POLICY['maximum_cohort_output_log_temporary_bytes'],1100000000)
        self.assertFalse(r.COHORT_DISK_POLICY['external_disk_writers_guaranteed'])
        with patch.object(r,'cohort_disk_observation',return_value=observed(free=1810612736,used=1100000000)):
            r.check_cohort_disk('/INVENTED')
        for value,reason in ((observed(free=1810612735),'FREE_SPACE_FLOOR'),
                (observed(used=1100000001),'OUTPUT_LOG_TEMPORARY_CAP')):
            with self.subTest(reason=reason),patch.object(r,'cohort_disk_observation',return_value=value):
                with self.assertRaisesRegex(r.CohortDiskResourceStop,reason) as caught:r.check_cohort_disk('/INVENTED')
                self.assertEqual(caught.exception.failure_classification,'RESOURCE')
                self.assertFalse(caught.exception.economic_halt)

    def test_whole_cohort_counts_case_outputs_root_logs_hidden_temporaries_once(self):
        with tempfile.TemporaryDirectory(prefix='GENERATED_COHORT_DISK_') as td:
            root=Path(td);(root/'A').mkdir()
            for name,n in (('A/result.json',11),('A.log',13),('.controller.atomic.tmp',17)):
                (root/name).write_bytes(b'x'*n)
            os.link(root/'.controller.atomic.tmp',root/'same_inode_published.json')
            value=r.cohort_disk_observation(root)
            self.assertEqual(value['cohort_output_log_temporary_bytes'],41)
            self.assertGreater(value['free_bytes'],0)

    def test_prospective_serialized_controller_body_and_atomic_temporary_are_budgeted(self):
        with tempfile.TemporaryDirectory(prefix='GENERATED_CONTROLLER_BUDGET_') as td:
            root=Path(td);path=root/'CONTROLLER_RECEIPT.json';value={'report':['invented']*1024};raw=r.body(value)
            for space,reason in ((observed(free=1810612736+len(raw)-1),'FREE_SPACE_FLOOR'),
                    (observed(used=1100000000-len(raw)+1),'OUTPUT_LOG_TEMPORARY_CAP')):
                with self.subTest(reason=reason),patch.object(r,'cohort_disk_observation',return_value=space),patch.object(r,'write_bytes') as write:
                    with self.assertRaisesRegex(r.CohortDiskResourceStop,reason):r.save_cohort_controller(path,value)
                    write.assert_not_called();self.assertFalse(path.exists())
            link=os.link;seen=[]
            def publish(src,dst):
                self.assertTrue(Path(src).name.startswith('.CONTROLLER_RECEIPT.json.'))
                seen.append(r.own_bytes(root));return link(src,dst)
            with patch.object(r.os,'link',side_effect=publish):r.save_cohort_controller(path,value)
            self.assertEqual(seen,[len(raw)]);self.assertEqual(path.read_bytes(),raw)
            self.assertEqual(r.own_bytes(root),len(raw))

    def test_bounded_resource_receipt_never_embeds_the_large_report_or_forces_a_write(self):
        with tempfile.TemporaryDirectory(prefix='GENERATED_RESOURCE_STOP_') as td:
            path=Path(td)/'RESOURCE_PAUSE.json'
            error=r.CohortDiskResourceStop('OUTPUT_LOG_TEMPORARY_CAP',observed(used=1100000001))
            error.saved_validation_errors=[{'error':'x'*100000}];error.original_pause_preserved=True
            self.assertTrue(r.save_bounded_resource_stop(path,error));self.assertLessEqual(path.stat().st_size,65536)
            other=Path(td)/'NO_BUDGET.json'
            with patch.object(r,'cohort_disk_observation',return_value=observed(free=1810612735)):
                self.assertFalse(r.save_bounded_resource_stop(other,error));self.assertFalse(other.exists())

    def model(self,root,**kwargs):return Model(root,**kwargs)

    def test_floor_or_cap_before_launch_cannot_claim_or_spawn(self):
        for observation in (observed(free=1810612735),observed(used=1100000001)):
            with tempfile.TemporaryDirectory(prefix='GENERATED_DISK_PRELAUNCH_') as td:
                model=self.model(td,fail=())
                with patch.object(r,'cohort_disk_observation',return_value=observation),self.assertRaises(r.CohortDiskResourceStop):model.run()
                self.assertEqual(model.spawned,[]);self.assertEqual(model.claims,[]);self.assertEqual(model.killed,[])
                self.assertIsNone(r._CONTROLLER_LEASE_FD);self.assertIsNone(r._SHARED_RESOURCE_LEASE_FD)

    def test_poll_floor_or_cap_stops_only_active_owned_workers_and_no_pending_launch(self):
        for fault in ('floor','cap'):
            with tempfile.TemporaryDirectory(prefix='GENERATED_DISK_LIVE_') as td:
                model=self.model(td,fail=())
                def observation(_):
                    return observed(free=1810612735) if fault=='floor' and model.now>=100.1 else observed(used=1100000001) if fault=='cap' and model.now>=100.1 else observed()
                with patch.object(r,'cohort_disk_observation',side_effect=observation),self.assertRaises(r.CohortDiskResourceStop):model.run()
                self.assertEqual(model.spawned,['A','B']);self.assertEqual(model.claims,['A','B'])
                self.assertEqual(set(model.killed),set(model.processes));self.assertEqual(model.validated,[])
                self.assertTrue(all(model.lock_checks));self.assertFalse((Path(td)/'output'/'C').exists())

    def test_disk_breach_during_saved_validation_drain_preserves_original_pause(self):
        for fault in ('floor','cap'):
            with tempfile.TemporaryDirectory(prefix='GENERATED_DISK_DRAIN_') as td:
                model=self.model(td)
                def observation(_):
                    return observed(free=1810612735) if fault=='floor' and model.validated else observed(used=1100000001) if fault=='cap' and model.validated else observed()
                with patch.object(r,'cohort_disk_observation',side_effect=observation),self.assertRaises(r.CohortDiskResourceStop) as caught:model.run()
                self.assertTrue(caught.exception.original_pause_preserved)
                self.assertEqual(caught.exception.saved_validation_errors[0]['cell_id'],'A')
                self.assertEqual(caught.exception.pending_not_launched,['C'])
                self.assertEqual(model.spawned,['A','B']);self.assertEqual(model.validated,['A'])
                self.assertEqual(model.killed,[model.processes[90001].pid]);self.assertTrue(all(model.lock_checks))

    def test_after_launch_hook_recheck_refuses_spawn_and_keeps_existing_claim(self):
        with tempfile.TemporaryDirectory(prefix='GENERATED_DISK_AFTER_HOOK_') as td:
            model=self.model(td,fail=())
            def observation(_):return observed(free=1810612735) if model.claims else observed()
            with patch.object(r,'cohort_disk_observation',side_effect=observation),self.assertRaises(r.CohortDiskResourceStop):model.run()
            self.assertEqual(model.claims,['A']);self.assertEqual(model.spawned,[])
            self.assertTrue((Path(td)/'A.generated_claim.json').is_file())

    def test_success_report_records_observed_disk_limits_and_unchanged_case_caps(self):
        with tempfile.TemporaryDirectory(prefix='GENERATED_DISK_SUCCESS_') as td:
            model=self.model(td,fail=())
            with patch.object(r,'cohort_disk_observation',return_value=observed()):report=model.run()
            self.assertEqual(report['status'],'ALL_ADMITTED_ORDERED_CELLS_TERMINAL')
            self.assertGreater(report['cohort_disk_safety']['checks'],3)
            self.assertEqual(report['limits']['per_case_output_bytes'],250000000)
            self.assertEqual(report['limits'],r.LIMITS)





class ClaimAndResourceTests(unittest.TestCase):
    def test_frozen_resource_and_terminal_math_transports_without_code_delta(self):
        import ast
        reference=HERE.parent/'original_high365_D_native_20261016_v1/high365_process_runtime.py'
        raw=reference.read_bytes()
        self.assertEqual(r.sha(raw),'1e8295c6d02a09fb5725a7dedd3e4e501748145fc8ae03438cfb30295fe59ab9')
        def functions(raw):
            return {node.name:ast.dump(node,include_attributes=False) for node in ast.parse(raw).body
                if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef))}
        before=functions(raw);after=functions((HERE/'follow_process_runtime.py').read_bytes())
        changed={'run_pool','claim_launch','shared_resource_lease_path','controller_lease'}
        after.pop('check_full_cohort_budget')
        self.assertEqual(set(before),set(after))
        for name in set(before)-changed:
            with self.subTest(function=name):self.assertEqual(after[name],before[name])

    def test_exact_first6_manifest_pins_and_claims_exclude_later24(self):
        import json
        raw=(HERE/'FROZEN_SIX_CELL_MANIFEST.json').read_bytes()
        self.assertEqual(r.sha(raw),r.MANIFEST_SHA256)
        cells=json.loads(raw)['cells']
        self.assertEqual(len(cells),6)
        self.assertEqual({row['year'] for row in cells},{2023})
        self.assertEqual([row['tier'] for row in cells],['LOW','MID','HIGH']*2)
        with tempfile.TemporaryDirectory(prefix='GENERATED_FOLLOW_CLAIM_') as td:
            registry=Path(td)/'claims'
            for cell in cells:
                path=r.claim_launch(registry,cell_id=cell['cell_id'],manifest_sha256=r.MANIFEST_SHA256,
                    metadata={'generated_claim_only':True})
                before=path.read_bytes()
                self.assertTrue(json.loads(before)['generated_claim_only'])
                with self.assertRaisesRegex(RuntimeError,'PERMANENT_CANONICAL_CELL_CLAIM_EXISTS'):
                    r.claim_launch(registry,cell_id=cell['cell_id'],manifest_sha256=r.MANIFEST_SHA256,metadata={})
                self.assertEqual(path.read_bytes(),before)
            for cell in (cells[0]['cell_id'].replace('2023_','2024_'),
                         cells[0]['cell_id'].replace('2023_','2022_'),
                         '2024_STATIC50_MID','../escape','',True,None):
                with self.subTest(cell=cell),self.assertRaises(ValueError):
                    r.claim_launch(registry,cell_id=cell,manifest_sha256=r.MANIFEST_SHA256,metadata={})
            self.assertEqual(len(list((registry/r.MANIFEST_SHA256).glob('*.json'))),6)
            with self.assertRaises(ValueError):
                r.claim_launch(registry,cell_id=cells[0]['cell_id'],manifest_sha256='a'*64,metadata={})

    def test_missing_or_changed_manifest_refuses_before_registry_write(self):
        import json
        cell=json.loads((HERE/'FROZEN_SIX_CELL_MANIFEST.json').read_bytes())['cells'][0]['cell_id']
        with tempfile.TemporaryDirectory(prefix='GENERATED_FOLLOW_BAD_MANIFEST_') as td:
            registry=Path(td)/'claims'
            with patch.object(r,'HERE',Path(td)),self.assertRaises(FileNotFoundError):
                r.claim_launch(registry,cell_id=cell,manifest_sha256=r.MANIFEST_SHA256,metadata={})
            (Path(td)/'FROZEN_SIX_CELL_MANIFEST.json').write_bytes(b'{}')
            with patch.object(r,'HERE',Path(td)),self.assertRaises(ValueError):
                r.claim_launch(registry,cell_id=cell,manifest_sha256=r.MANIFEST_SHA256,metadata={})
            self.assertFalse(registry.exists())

    def test_nonblocking_shared_mutex_denies_before_own_namespace(self):
        with tempfile.TemporaryDirectory(prefix='GENERATED_FOLLOW_SHARED_LOCK_') as td:
            root=Path(td);shared=root/'FAKE_SHARED_CPU45.lock';shared.touch();registry=root/'registry'
            held=os.open(shared,os.O_RDWR)
            try:
                fcntl.flock(held,fcntl.LOCK_EX|fcntl.LOCK_NB)
                with patch.object(r,'shared_resource_lease_path',return_value=shared):
                    with self.assertRaisesRegex(RuntimeError,'SHARED_CS_CPU45_RESOURCE_LEASE_HELD'):
                        with r.controller_lease(registry):self.fail('GENERATED_LOCK_OVERLAP')
                self.assertFalse(registry.exists())
            finally:os.close(held)
            self.assertIsNone(r._CONTROLLER_LEASE_FD);self.assertIsNone(r._SHARED_RESOURCE_LEASE_FD)

    def test_owned_mutex_denies_and_never_unlocks_inherited_open_descriptions(self):
        with tempfile.TemporaryDirectory(prefix='GENERATED_FOLLOW_INHERITED_LOCK_') as td:
            root=Path(td);shared=root/'FAKE_SHARED_CPU45.lock';shared.touch();registry=root/'registry'
            own=registry/r.MANIFEST_SHA256/'CONTROLLER_LEASE.lock';own.parent.mkdir(parents=True);own.touch()
            held=os.open(own,os.O_RDWR)
            try:
                fcntl.flock(held,fcntl.LOCK_EX|fcntl.LOCK_NB)
                with patch.object(r,'shared_resource_lease_path',return_value=shared):
                    with self.assertRaisesRegex(RuntimeError,'FOLLOW_FIRST6_CONTROLLER_LEASE_HELD'):
                        with r.controller_lease(registry):self.fail('GENERATED_LOCK_OVERLAP')
            finally:os.close(held)
            duplicates=[]
            try:
                with patch.object(r,'shared_resource_lease_path',return_value=shared):
                    with r.controller_lease(registry) as fd:
                        duplicates=[os.dup(fd),os.dup(r._SHARED_RESOURCE_LEASE_FD)]
                self.assertIsNone(r._CONTROLLER_LEASE_FD);self.assertIsNone(r._SHARED_RESOURCE_LEASE_FD)
                for path in (own,shared):
                    probe=os.open(path,os.O_RDWR)
                    try:
                        with self.assertRaises(BlockingIOError):fcntl.flock(probe,fcntl.LOCK_EX|fcntl.LOCK_NB)
                    finally:os.close(probe)
            finally:
                for fd in duplicates:os.close(fd)
            for path in (own,shared):
                probe=os.open(path,os.O_RDWR)
                try:fcntl.flock(probe,fcntl.LOCK_EX|fcntl.LOCK_NB)
                finally:os.close(probe)

    def test_shared_lock_missing_or_symlink_never_created_or_followed(self):
        with tempfile.TemporaryDirectory(prefix='GENERATED_FOLLOW_LOCK_PATH_') as td:
            root=Path(td);shared=root/'ABSENT.lock';registry=root/'registry'
            with patch.object(r,'shared_resource_lease_path',return_value=shared):
                with self.assertRaises(FileNotFoundError):
                    with r.controller_lease(registry):self.fail('MISSING_LOCK_ACCEPTED')
            target=root/'REAL.lock';target.touch();shared.symlink_to(target)
            with patch.object(r,'shared_resource_lease_path',return_value=shared):
                with self.assertRaises(OSError):
                    with r.controller_lease(registry):self.fail('SYMLINK_LOCK_ACCEPTED')
            self.assertFalse(registry.exists())

    def test_immutable_atomic_writes_refuse_overwrite(self):
        with tempfile.TemporaryDirectory(prefix='GENERATED_FOLLOW_ATOMIC_') as td:
            root=Path(td);path=root/'claim.json';r.save(path,{'value':1});raw=path.read_bytes()
            with self.assertRaises(FileExistsError):r.save(path,{'value':2})
            self.assertEqual(path.read_bytes(),raw)
            self.assertEqual([p.name for p in root.iterdir()],['claim.json'])

    def test_exact_caps_threads_and_conservative_capacity_admission(self):
        self.assertEqual(r.LIMITS,d.EXACT_LIMITS)
        self.assertEqual(r.LIMITS['per_case_wall_seconds'],600)
        self.assertEqual(r.LIMITS['per_case_CPU_seconds'],600)
        self.assertEqual(r.LIMITS['per_case_AS_bytes'],4000000000)
        self.assertEqual(r.LIMITS['per_case_RSS_stop_bytes'],2000000000)
        self.assertEqual(r.LIMITS['aggregate_live_worker_RSS_stop_bytes'],3500000000)
        self.assertEqual(r.LIMITS['maximum_live_workers'],2)
        self.assertEqual(r.LIMITS['threads_per_worker'],1)
        self.assertTrue(all(r.environment()[name]=='1' for name in r.THREAD_ENV))
        observation=dict(allowed_CPUs=[4,5],MemAvailable_bytes=5000000000,cgroup_observations={})
        self.assertEqual(r.choose_worker_count(2,[4,5],observation),2)
        observation['MemAvailable_bytes']=3000000000
        self.assertEqual(r.choose_worker_count(2,[4,5],observation),1)
        observation['MemAvailable_bytes']=2299999999
        with self.assertRaisesRegex(RuntimeError,'INSUFFICIENT_OBSERVED_MEMORY'):
            r.choose_worker_count(2,[4,5],observation)
        observation['MemAvailable_bytes']=5000000000
        observation['cgroup_observations']={'/sys/fs/cgroup/memory.max':'5000000000',
            '/sys/fs/cgroup/memory.current':'2000000000'}
        self.assertEqual(r.choose_worker_count(2,[4,5],observation),1)
        observation['cgroup_observations']={'/sys/fs/cgroup/cpu.max':'100000 100000'}
        self.assertEqual(r.choose_worker_count(2,[4,5],observation),1)
        for count,cpus in ((True,[4]),(0,[]),(3,[4,5,7]),(2,[4,4]),(2,[7,8]),
                           (2,[True,5]),(2,(4,5)),(2,[4])):
            with self.subTest(count=count,cpus=cpus),self.assertRaises(ValueError):
                r.choose_worker_count(count,cpus,observation)

    def test_generated_denied_spawn_keeps_claim_and_partial_directory(self):
        with tempfile.TemporaryDirectory(prefix='GENERATED_FOLLOW_DENIED_SPAWN_') as td:
            m=Model(td,fault='DENIED_SPAWN',fail=())
            with self.assertRaisesRegex(PermissionError,'GENERATED_DENIED_PROCESS_LAUNCH'):m.run()
            self.assertEqual(m.claims,['A']);self.assertEqual(m.spawned,[])
            self.assertTrue((Path(td)/'A.generated_claim.json').is_file())
            self.assertTrue((Path(td)/'output'/'A').is_dir())
            self.assertFalse((Path(td)/'output'/'B').exists())
            with self.assertRaisesRegex(RuntimeError,'EXISTING_UNFINISHED_CASE_PAUSE_NO_RETRY'):m.run()
            self.assertEqual(m.claims,['A']);self.assertEqual(m.spawned,[])

    def test_invalid_affinity_denied_before_any_resource_mutation(self):
        import resource
        for cpu in (True,None,4,5,8):
            with self.subTest(cpu=cpu),patch.object(r.os,'sched_getaffinity',return_value={7}),\
                 patch.object(r.os,'sched_setaffinity') as affinity,patch.object(r.resource,'setrlimit') as limit:
                with self.assertRaisesRegex(ValueError,'REQUESTED_WORKER_CPU_MUST_BE_ACTUALLY_ALLOWED'):
                    r.apply_limits(cpu)
                affinity.assert_not_called();limit.assert_not_called()

    def test_actual_stdlib_only_resource_probe_is_explicit_cpu7(self):
        import json
        import subprocess
        if sorted(os.sched_getaffinity(0)) != [selected_cpu()]:
            raise ValueError('ACTUAL_GENERATED_RESOURCE_PROBE_REQUIRES_CPU7')
        script="""import json,os,resource; import follow_process_runtime as r
r.apply_limits(7)
print(json.dumps(dict(affinity=sorted(os.sched_getaffinity(0)),
    limits={n:list(resource.getrlimit(k)) for n,k in
        [('AS',resource.RLIMIT_AS),('CPU',resource.RLIMIT_CPU),('RSS',resource.RLIMIT_RSS)]},
    threads={n:os.environ[n] for n in r.THREAD_ENV})))
"""
        script=script.replace('r.apply_limits(7)','r.apply_limits('+str(selected_cpu())+')')
        completed=subprocess.run([sys.executable,'-B','-c',script],cwd=HERE,env=r.environment(),
            stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True,timeout=10)
        value=json.loads(completed.stdout)
        self.assertEqual(value['affinity'],[selected_cpu()])
        self.assertEqual(value['limits'],{'AS':[4000000000]*2,'CPU':[600]*2,'RSS':[2000000000]*2})
        self.assertEqual(value['threads'],dict.fromkeys(r.THREAD_ENV,'1'))


if __name__=='__main__':unittest.main(verbosity=2)
