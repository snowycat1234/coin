"""New permanent recovery claims; the two old prefinance claims stay blocked."""
from pathlib import Path
import os
import follow_native_common as c
import follow_finance_gate as gate

SCOPE_SHA='58726deb8f7a1c7345317d863fb7fce07a44585c1b88dcee320c872ed55f3b68'
STABLE_REGISTRY_REL=gate.CLAIM_NAMESPACE

def registry_root():return c.ROOT/STABLE_REGISTRY_REL

def claim_path(cell_id):
    import follow_source_entry as entry
    if cell_id not in entry.tranche_cells(entry.FIRST6):raise ValueError('ONLY_FIRST6_LEGACY_FRESH_GENESIS_CLAIMS_REQUIRED')
    return registry_root()/SCOPE_SHA/(cell_id+'.json')

def reserve(*,cell_id,metadata,go):
    import follow_process_runtime as r
    import follow_source_entry as entry
    import follow_recovery as recovery
    if cell_id not in entry.tranche_cells(entry.FIRST6):raise ValueError('ONLY_FIRST6_LEGACY_FRESH_GENESIS_CLAIMS_REQUIRED')
    if (go.get('separate_fresh_genesis_claim_namespace')!=STABLE_REGISTRY_REL
            or go.get('shared_CS_CPU45_lease')!=gate.SHARED_CPU_LEASE
            or go.get('shared_CPU45_lease_nonblocking') is not True
            or go.get('fresh_genesis_only') is not True or go.get('automatic_retry_authorized') is not False):
        raise ValueError('EXACT_NEW_ORIGINAL_HIGH365_FRESH_GENESIS_CLAIM_POLICY_REQUIRED')
    recovered=recovery.validate_recovery()
    if c.canonical(go.get('zero_finance_failed_attempt_recovery'))!=c.canonical(recovered):
        raise ValueError('EXACT_FRESH_EVIDENCE_BOUND_ZERO_FINANCE_RECOVERY_AUTHORITY_REQUIRED')
    if r._CONTROLLER_LEASE_FD is None or r._SHARED_RESOURCE_LEASE_FD is None:
        raise ValueError('OWN_AND_SHARED_CPU45_CONTROLLER_LEASE_REQUIRED')
    for fd,path in ((r._CONTROLLER_LEASE_FD,registry_root()/SCOPE_SHA/'CONTROLLER_LEASE.lock'),
                    (r._SHARED_RESOURCE_LEASE_FD,r.shared_resource_lease_path())):
        held=os.fstat(fd);canonical=path.stat()
        if (held.st_dev,held.st_ino)!=(canonical.st_dev,canonical.st_ino):raise ValueError('EXACT_LIVE_OWN_AND_SHARED_LEASE_INODES_REQUIRED')
    additions=dict(zero_finance_failed_attempt_recovery_map_SHA256=recovery.MAP_SHA256,
        prior_failed_prefinance_claim_SHA256=recovered['exact_old_claim_SHA256'].get(cell_id),
        prior_financial_account_constructed=False,old_failed_evidence_and_claims_preserved=True)
    if any(key in metadata and c.canonical(metadata[key])!=c.canonical(value) for key,value in additions.items()):
        raise ValueError('RECOVERY_CLAIM_METADATA_COLLISION')
    return r.claim_launch(registry_root(),cell_id=cell_id,manifest_sha256=SCOPE_SHA,metadata=dict(metadata,**additions))
