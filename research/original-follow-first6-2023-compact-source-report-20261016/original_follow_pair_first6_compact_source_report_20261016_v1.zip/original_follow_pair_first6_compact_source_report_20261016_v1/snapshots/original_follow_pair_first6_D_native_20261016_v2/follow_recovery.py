"""Exact, read-only recovery of two proved pre-account cp437 interruptions.

This is not a resume or a general retry facility.  The old immutable claims and
all failed evidence remain in place.  No caller can supply evidence paths or a
replacement map to the production validator.  Pure caller-byte checks below
exist for generated corruption tests, and confer no execution capability.
"""
from pathlib import Path
import os
import stat
import follow_native_common as c

MAP_SHA256='ab6c2ca0018548625277511399eb992475ace580205881fcd3ddc787fca431e6'
OLD_CODE='5db8cb5371f80004841eca3c0071951f4d01af429aa94d819fa42862ee69a493'
OLD_GO='a4dc2318b089ef0c9534aa8295006398859c84dc49cadb92f1e39561d151bcc1'
PHASE_AUDIT='0220c737479e4f23ab28f7e0302623b4dfb49bf68e1bd349783b8c46fbe75dbc'
INVENTORY_AUDIT='e927368ad0d5bb4bc811f0b6ea52432476df1581f9ca1d510e56c18d3019a6bb'
SCOPE='58726deb8f7a1c7345317d863fb7fce07a44585c1b88dcee320c872ed55f3b68'
PREPARATION='231c0ac6b01dd5aab924ee70976c7349317037f0af51c89df12f6269ac808bff'
NAMESPACE='original_follow_pair_first6_D_native_20261016_v2/EXECUTION_CLAIMS'
OLD_BASE='original_follow_pair_first6_D_native_20261016_v1'
OLD_ATTEMPT=OLD_BASE+'/financial_attempts/ACTUAL_FIRST6_attempt001'
OLD_REGISTRY=OLD_BASE+'/EXECUTION_CLAIMS/'+SCOPE
CASE_FILES=('BOOTSTRAP_READY.json','FAILED_SOURCE_RECAPTURE_GUARD_RECEIPT.json',
 'FAILURE.json','LAUNCH_CLAIM.json','PROCESS_OWNERSHIP.json','WORKER_AUTHORITY_VERIFIED.json')

def _map():
    return c.exact_object(c.exact(c.HERE/'RECOVERY_EVIDENCE.json',MAP_SHA256))

def recovery_policy():
    """Metadata only. Frozen code binds this exact descriptor in each new GO."""
    m=_map()
    return dict(schema='EXACT_FIRST6_PREFINANCE_ZERO_ACCOUNT_RECOVERY_POLICY_V1',
      evidence_map_SHA256=MAP_SHA256,independent_failed_attempt_review_SHA256=PHASE_AUDIT,
      independent_failed_output_and_oldclaims_inventory_SHA256=INVENTORY_AUDIT,
      old_financial_code_SHA256=OLD_CODE,old_root_GO_SHA256=OLD_GO,
      old_failed_attempt=OLD_ATTEMPT,old_claim_registry=OLD_REGISTRY,
      recovered_prefinance_cells=m['failed_before_finance_cells'],
      original_first_launch_cells=m['first_launch_cells'],ordered_cells=m['ordered_cells'],
      exact_old_claim_SHA256={p['relative_path'].split('/')[-1][:-5]:p['SHA256']
        for p in m['evidence_files'] if p['relative_path'].startswith(OLD_REGISTRY+'/') and p['relative_path'].endswith('.json')},
      new_permanent_claim_namespace=NAMESPACE,old_claims_and_failed_evidence_preserved=True,
      only_zero_account_provider_scope_advance_failure_recoverable=True,
      scientific_or_successful_financial_experiment_rerun_authorized=False,
      snapshot_resume_authorized=False,automatic_retry_authorized=False,
      further_recovery_after_new_launch_authorized=False,remaining24_authorized=False)

def _integer_zero(value):
    return type(value) is int and value==0

def _validate_evidence(m,bodies):
    """Pure semantic checks over already captured bytes. No authority or I/O."""
    import json
    cells=m['ordered_cells'];failed=m['failed_before_finance_cells']
    if (m.get('schema')!='FOLLOW_FIRST6_EXACT_ZERO_FINANCE_RECOVERY_EVIDENCE_V1'
        or len(cells)!=6 or failed!=cells[:2] or m['first_launch_cells']!=cells[2:]
        or m['old_attempt_relative']!=OLD_ATTEMPT or m['old_claim_registry_relative']!=OLD_REGISTRY
        or m['old_financial_code_SHA256']!=OLD_CODE or m['old_root_GO_SHA256']!=OLD_GO
        or m['source_PREPARATION_SHA256']!=PREPARATION or m['scope_manifest_SHA256']!=SCOPE
        or m['new_permanent_claim_namespace']!=NAMESPACE
        or m['financial_execution_authorized'] is not False
        or m['automatic_retry_or_snapshot_resume_authorized'] is not False
        or m['old_evidence_or_claim_removal_authorized'] is not False
        or m['recovery_requires_fresh_v2_review_and_root_GO'] is not True):
        raise ValueError('EXACT_ZERO_FINANCE_RECOVERY_MAP_REQUIRED')
    expected={OLD_ATTEMPT+'/ADMISSION_'+OLD_GO+'.json',OLD_ATTEMPT+'/CONTROLLER_PAUSE_'+OLD_GO+'.json',
              OLD_ATTEMPT+'/ROOT_OBSERVED_EXIT_CONFIRMED.json',OLD_REGISTRY+'/CONTROLLER_LEASE.lock'}
    for cell in failed:
        expected.add(OLD_ATTEMPT+'/'+cell+'.log');expected.add(OLD_REGISTRY+'/'+cell+'.json')
        expected.update(OLD_ATTEMPT+'/'+cell+'/'+name for name in CASE_FILES)
    pins={p['relative_path']:p for p in m['evidence_files']}
    if len(pins)!=20 or set(pins)!=expected or set(bodies)!=expected:
        raise ValueError('EXACT_FAILED_FILES_AND_ONLY_TWO_OLD_CLAIMS_REQUIRED')
    for name,raw in bodies.items():
        if type(raw) is not bytes or len(raw)!=pins[name]['bytes'] or c.sha(raw)!=pins[name]['SHA256']:
            raise ValueError('OLD_FAILED_EVIDENCE_BITS_CHANGED')
    def obj(name):return c.exact_object(bodies[name])
    if c.sha(bodies[OLD_ATTEMPT+'/ADMISSION_'+OLD_GO+'.json'])!=OLD_GO:
        raise ValueError('EXACT_OLD_ADMISSION_REQUIRED')
    exit_record=obj(OLD_ATTEMPT+'/ROOT_OBSERVED_EXIT_CONFIRMED.json')
    if (type(exit_record.get('session_id')) is not int or exit_record['session_id']!=75230
        or type(exit_record.get('observed_exit_code')) is not int or exit_record['observed_exit_code']!=1):
        raise ValueError('EXACT_CLOSED_FAILED_ROOT_SESSION_REQUIRED')
    pause=obj(OLD_ATTEMPT+'/CONTROLLER_PAUSE_'+OLD_GO+'.json')
    if (pause.get('status')!='EXECUTION_RESOURCE_DATA_OR_VALIDATION_PAUSE'
        or pause.get('automatic_retry') is not False or pause.get('economic_halt_relabelled') is not False):
        raise ValueError('HONEST_NON_ECONOMIC_INTERRUPTION_REQUIRED')
    for index,cell in enumerate(failed):
        prefix=OLD_ATTEMPT+'/'+cell+'/'
        authority=obj(prefix+'WORKER_AUTHORITY_VERIFIED.json')
        if (any(not _integer_zero(authority.get(k)) for k in ('accounts_constructed','providers_constructed','historical_scopes_constructed'))
            or authority.get('source_capture_started') is not False
            or authority.get('phase')!='EXACT_EXECUTABLE_GO_VERIFIED_OUTSIDE_UNCHANGED_SOURCE_GUARD'
            or authority.get('financial_code_manifest_SHA256')!=OLD_CODE
            or authority.get('root_GO_SHA256')!=OLD_GO or authority.get('preparation_SHA256')!=PREPARATION
            or authority.get('cell_id')!=cell):
            raise ValueError('ONLY_EXACT_ZERO_CONSTRUCTOR_PRE_SOURCE_PHASE_RECOVERABLE')
        claim_raw=bodies[OLD_REGISTRY+'/'+cell+'.json'];claim=c.exact_object(claim_raw)
        if (bodies[prefix+'LAUNCH_CLAIM.json']!=claim_raw or authority.get('claim_SHA256')!=c.sha(claim_raw)
            or claim.get('cell_id')!=cell or claim.get('code_identity')!=OLD_CODE or claim.get('root_GO_SHA256')!=OLD_GO
            or claim.get('preparation_SHA256')!=PREPARATION or claim.get('manifest_SHA256')!=SCOPE
            or claim.get('status')!='RESERVED_BEFORE_PROCESS_SPAWN' or claim.get('automatic_clear_or_retry') is not False
            or claim.get('financial_snapshot_resume') is not False
            or claim.get('separate_fresh_genesis_claim_namespace')!=OLD_BASE+'/EXECUTION_CLAIMS'):
            raise ValueError('EXACT_UNREMOVED_OLD_PERMANENT_CLAIM_REQUIRED')
        guard=obj(prefix+'FAILED_SOURCE_RECAPTURE_GUARD_RECEIPT.json');attempts=guard.get('forbidden_attempts')
        if (type(attempts) is not dict or set(attempts)!={'actual_provider_calls','canonical_financial_claims_or_leases','financial_GO_writes','financial_account_advance','financial_constructors','financial_imports','historical_scope_mints','native_simulator_construct_or_advance','network_calls','nonallowlisted_file_reads','outside_source_writes','process_launches'}
            or any(type(value) is not int or value!=(1 if key=='financial_imports' else 0) for key,value in attempts.items())
            or guard.get('guard_active') is not False or guard.get('financial_execution_authorized') is not False
            or guard.get('historical_execution_authorized') is not False
            or guard.get('status')!='STOP_FINANCIAL_WORKER_SOURCE_ONLY_RECAPTURE'
            or guard.get('attempted_targets')!=[{'category':'financial_imports','target':'SourceFileLoader.exec_module'}]):
            raise ValueError('ONLY_ONE_DENIED_IMPORT_AND_ZERO_FINANCIAL_ACTIVITY_RECOVERABLE')
        checkpoints=guard.get('checkpoints')
        if (type(checkpoints) is not list or len(checkpoints)!=1
            or checkpoints[0].get('label')!='FRESH_WORKER_FOLLOW_FIRST6_SOURCE_RECAPTURE_BEFORE_FINANCE_IMPORT'
            or set(checkpoints[0].get('attempts',{}))!=set(attempts)
            or any(not _integer_zero(v) for v in checkpoints[0]['attempts'].values())):
            raise ValueError('NO_POST_GUARD_OR_FINANCIAL_PHASE_RECOVERABLE')
        failure=obj(prefix+'FAILURE.json');trace=failure.get('traceback','')
        if (failure.get('kind')!='EXECUTION_RESOURCE_DATA_OR_VALIDATION_INTERRUPTION'
            or failure.get('automatic_retry') is not False
            or any(s not in trace for s in ("artifacts['2023/TARGETS.npz']",'cp437','search_function','SourceFileLoader.exec_module','FORBIDDEN_ATTEMPTS_FATAL_EVEN_IF_CAUGHT'))):
            raise ValueError('EXACT_CP437_PRE_ACCOUNT_FAILURE_REQUIRED')
    return True

def _filesystem_inventory(roots):
    files=set();directories=set()
    for relative,only_child in ((OLD_BASE+'/EXECUTION_CLAIMS',SCOPE),
                                (OLD_BASE+'/financial_attempts','ACTUAL_FIRST6_attempt001')):
        parent=c.ROOT/relative
        if parent.is_symlink() or any(p.is_symlink() for p in parent.parents) or not parent.is_dir():
            raise ValueError('ORDINARY_OLD_CLAIM_AND_ATTEMPT_NAMESPACE_REQUIRED')
        if {p.name for p in parent.iterdir()}!={only_child}:
            raise ValueError('OTHER_OLD_CLAIMS_OR_FINANCIAL_ATTEMPTS_FORBIDDEN')
    for relative in roots:
        root=c.ROOT/c.relative(relative)
        if root.is_symlink() or not root.is_dir() or any(p.is_symlink() for p in root.parents):
            raise ValueError('ORDINARY_IMMUTABLE_OLD_EVIDENCE_DIRECTORY_REQUIRED')
        for current,dirs,names in os.walk(root,followlinks=False):
            directory=Path(current);directories.add(str(directory.relative_to(c.ROOT)))
            for name in dirs+names:
                child=directory/name
                if child.is_symlink():raise ValueError('OLD_EVIDENCE_LINK_FORBIDDEN')
            for name in names:
                child=directory/name
                if not stat.S_ISREG(child.stat().st_mode):raise ValueError('OLD_EVIDENCE_SPECIAL_FILE_FORBIDDEN')
                files.add(str(child.relative_to(c.ROOT)))
    return files,directories

def validate_recovery():
    """Exact local read-only evidence gate; must execute before source guard."""
    from follow_native_source_guard import current_guard
    if current_guard() is not None:raise ValueError('RECOVERY_EVIDENCE_VALIDATION_MUST_PRECEDE_SOURCE_GUARD')
    m=_map();bodies={}
    files,directories=_filesystem_inventory((OLD_ATTEMPT,OLD_REGISTRY))
    if files!={p['relative_path'] for p in m['evidence_files']} or directories!=set(m['exact_directories']):
        raise ValueError('CHANGED_EXTRA_MISSING_OR_POSTGUARD_OLD_EVIDENCE_FORBIDDEN')
    for pin in m['evidence_files']:
        path=c.ROOT/c.relative(pin['relative_path']);before=path.stat()
        if (before.st_dev,before.st_ino)!=(pin['device'],pin['inode']):raise ValueError('EXACT_PRESERVED_OLD_EVIDENCE_INODE_REQUIRED')
        bodies[pin['relative_path']]=c.exact(path,pin['SHA256'],pin['bytes'])
        after=path.stat()
        if (after.st_dev,after.st_ino)!=(pin['device'],pin['inode']):raise ValueError('OLD_EVIDENCE_CHANGED_DURING_VALIDATION')
    _validate_evidence(m,bodies)
    for name,expected in (('independent_phase_review',PHASE_AUDIT),('independent_inventory',INVENTORY_AUDIT)):
        pin=m[name]
        if pin['SHA256']!=expected:raise ValueError('EXACT_INDEPENDENT_ZERO_FINANCE_AUDIT_REQUIRED')
        value=c.exact_object(c.exact(c.ROOT/c.relative(pin['path']),expected,pin['bytes']))
        if name=='independent_phase_review':
            if (value.get('status')!='SEALED_FAILED_ATTEMPT_PREFINANCE_ZERO_ACTIVITY_CONFIRMED'
                or value.get('errors')!=[] or value.get('financial_run_or_result') is not False
                or any(not _integer_zero(value.get(k)) for k in ('accounts_constructed','actual_provider_calls','historical_scope_mints','native_source_scopes_minted','sealed_successful_financial_cases'))
                or value.get('prefinance_interrupted_cases')!=2 or value.get('not_launched_cases')!=4
                or value.get('original_claims_preserved') is not True or value.get('originals_modified') is not False):
                raise ValueError('INDEPENDENT_ZERO_FINANCE_FAILURE_CONFIRMATION_REQUIRED')
        elif (value.get('independent_phase_review_SHA256')!=PHASE_AUDIT or value.get('no_financial_or_postguard_success_artifacts') is not True
              or value.get('launched_cells')!=m['failed_before_finance_cells'] or value.get('old_claim_count')!=2):
            raise ValueError('EXACT_INDEPENDENT_FAILED_INVENTORY_REQUIRED')
    for pin in m['old_phase_code_files']:c.exact(c.ROOT/c.relative(pin['path']),pin['SHA256'],pin['bytes'])
    # Detect additions/replacements occurring while the fixed bodies were read.
    if _filesystem_inventory((OLD_ATTEMPT,OLD_REGISTRY))!=(files,directories):
        raise ValueError('OLD_EVIDENCE_DIRECTORY_CHANGED_DURING_VALIDATION')
    return recovery_policy()
