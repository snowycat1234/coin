"""Auditable finite module-admission projection over the frozen generic engine.

Never aliases old modules or spoofs __file__. Only explicitly listed import,
module-reference and transport-identity AST nodes change. Financial/risk function
bodies retain their AST and inherited code objects. No arbitrary caller source.
"""
import ast
from pathlib import Path
import follow_native_common as c

def admitted_tree(name):
 spec=c.exact_object(c.ordinary(c.HERE/'TRANSPORT_PROJECTION.json'))
 pin=spec['modules'].get(name)
 if pin is None:raise ValueError('FINITE_DECLARED_TRANSPORT_MODULE_REQUIRED')
 origin=c.ROOT/c.relative(pin['origin']);raw=c.exact(origin,pin['SHA256'])
 tree=ast.parse(raw);mapping=spec['module_map'];literals=spec['literal_map']
 class Transport(ast.NodeTransformer):
  def visit_Import(self,node):
   for item in node.names:item.name=mapping.get(item.name,item.name)
   return node
  def visit_ImportFrom(self,node):node.module=mapping.get(node.module,node.module);return node
  def visit_Name(self,node):node.id=mapping.get(node.id,node.id);return node
  def visit_Attribute(self,node):
   self.generic_visit(node)
   if node.attr=='ALL15':node.attr='FIRST6'
   return node
  def visit_keyword(self,node):
   self.generic_visit(node)
   node.arg=spec.get('keyword_map',{}).get(node.arg,node.arg)
   return node
  def visit_Constant(self,node):
   if isinstance(node.value,str):node.value=literals.get(node.value,node.value)
   return node
 tree=Transport().visit(tree);ast.fix_missing_locations(tree)
 return tree

def load(name,namespace):
 if Path(namespace.get('__file__','')).resolve()!=c.HERE/(name+'.py'):
  raise ValueError('GENUINE_NEW_TRANSPORT_MODULE_FILE_REQUIRED')
 tree=admitted_tree(name)
 # Explicitly replaced transport-only functions are defined by the wrapper.
 excluded={'run_follow':{'wires','read_paths','load_saved_year'},
           'follow_saved':set(),
           'follow_native_generated':{'project_generated'},
           'follow_native_source_guard':set()}.get(name,set())
 tree.body=[node for node in tree.body if not isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)) or node.name not in excluded]
 if name=='follow_saved':
  for node in tree.body:
   if isinstance(node,ast.FunctionDef) and node.name=='validate_saved_terminal':
    replacement=[]
    for statement in node.body:
     if isinstance(statement,ast.Assign) and any(isinstance(x,ast.Name) and x.id in {'quality_name','quality_pin','sidecar_raw'} for target in statement.targets for x in ast.walk(target)):
      if any(isinstance(x,ast.Name) and x.id=='sidecar_raw' for target in statement.targets for x in ast.walk(target)):
       replacement.extend(ast.parse("sidecar_raw=saved['SOURCE_NATIVE_QUALITY.json']").body)
      continue
     replacement.append(statement)
    node.body=replacement
  ast.fix_missing_locations(tree)
 if name=='run_follow':
  # Main executes only after the wrapper installs its source/authority seams.
  tree.body=[node for node in tree.body if not (isinstance(node,ast.If) and isinstance(node.test,ast.Compare) and any(isinstance(x,ast.Constant) and x.value=='__main__' for x in ast.walk(node.test)))]
 if name=='follow_native_source_guard':
  # Imports are preloaded; own finite FOLLOW native transport module names may
  # resolve. Financial imports/constructors/providers remain blocked verbatim.
  for node in ast.walk(tree):
   if isinstance(node,ast.Set) and any(isinstance(x,ast.Constant) and x.value=='follow_entry' for x in node.elts):
    node.elts += [ast.Constant(x) for x in ('follow_native_bootstrap','follow_native_common','follow_native_config','follow_source_entry','follow_finance_gate','follow_verified_wires','follow_input_loader','follow_native_source','follow_native_source2023','follow_native_codec','follow_native_source_scope','follow_native_signal','follow_native_source_guard','follow_transport')]
  ast.fix_missing_locations(tree)
 exec(compile(tree,str(c.HERE/(name+'.py')),'exec'),namespace)
