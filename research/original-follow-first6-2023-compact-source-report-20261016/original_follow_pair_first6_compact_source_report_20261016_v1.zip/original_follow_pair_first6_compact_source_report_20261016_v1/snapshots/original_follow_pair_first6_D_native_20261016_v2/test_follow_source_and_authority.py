"""Generated source/authority/header/saved-calendar checks; no actual payloads."""
import ast,json,unittest
from copy import deepcopy
from io import BytesIO
from pathlib import Path
from unittest.mock import patch
import numpy as np
import follow_native_bootstrap
import follow_native_common as c
import follow_native_config as config
import follow_source_entry as entry
import follow_native_codec as codec
import follow_native_source2023 as source
from generated_follow_source_fixture import fake_source,pack

class SourceTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.parts=fake_source()
 def test_exact_synthetic_canonical199_and365_funding_quality(self):
  value=source.assemble_inputs(*self.parts)
  self.assertEqual(value['close'].shape,(564,5));self.assertEqual(value['decisions'].shape,(365,))
  self.assertFalse(value['close'].flags.writeable);self.assertEqual(value['quality_cells'],());self.assertEqual(value['quality_intervals'],())
  self.assertEqual([r['event_us'] for r in value['events']],[r['event_us'] for r in c.object_json(self.parts[3])])
  self.assertTrue(any(r['raw_rate']<0 for r in value['events']));self.assertTrue(all(r['event_us']%1000==1 for r in value['events']))
  self.assertFalse(value['sidecar']['certifies_liquidation']);self.assertFalse(value['sidecar']['certifies_no_liquidation']);self.assertEqual(value['sidecar']['arrival_status'],'UNKNOWN_NOT_CERTIFIED')
 def test_funding_rejects_duplicate_wrong_interval_unit_and_order(self):
  rows=c.object_json(self.parts[3]);contract=self.parts[6]
  for change in ('duplicate','interval','field','clock','order'):
   bad=deepcopy(rows)
   if change=='duplicate':bad[1]=bad[0]
   if change=='interval':bad[0]['reported_interval_hours']=4
   if change=='field':bad[0]['raw_rate_unit']='CERTIFIED'
   if change=='clock':bad[0]['event_us']=True
   if change=='order':bad[:2]=reversed(bad[:2])
   with self.subTest(change=change),self.assertRaises(ValueError):source.funding_events(2023,c.canonical(bad),contract)
 def test_month_count_bits_quality_and_tail_parity_reject(self):
  for kind in ('count','bits','quality','tail'):
   parts=list(self.parts);contract=deepcopy(parts[6]);parts[6]=contract
   if kind=='count':parts[5]=parts[5][:-1]
   if kind=='bits':contract['months'][0]['hash']='0'*64
   if kind=='quality':contract['derived_mark_cells']=1
   if kind=='tail':
    rows=c.object_json(parts[2]);rows[0]['close']+=1;parts[2]=c.canonical(rows)
   with self.subTest(kind=kind),self.assertRaises(ValueError):source.assemble_inputs(*parts)
 def test_other_years_native_source_denied(self):
  for year in (True,2021,2022,2024,2025,2026):
   with self.assertRaises(ValueError):config.source_year(year)
 def test_bool_plain_header_and_signed_zero_bits(self):
  arrays=dict(mask=np.array([[True,False]]),clock=np.array([1],dtype=np.int64),value=np.array([0.,-0.]))
  specs=dict(mask=((1,2),'bool'),clock=((1,),'int64'),value=((2,),'float64'))
  decoded=codec.npz(pack(**arrays),specs)
  for key,a in arrays.items():self.assertEqual(decoded[key].tobytes(),a.tobytes());self.assertFalse(decoded[key].flags.writeable)
  for bad in (np.zeros((1,2),dtype=float),np.zeros((1,2),dtype=object)):
   with self.assertRaises(ValueError):codec.npz(pack(**dict(arrays,mask=bad)),specs)

class AuthorityTests(unittest.TestCase):
 def test_first6_metadata_and_all27_saved_arrays_bound(self):
  raw=c.ordinary(c.ROOT/'original_follow_pair_D_source_20261016_v1/source_attempts/ACTUAL_ALL30_SOURCE_TARGET_ONLY_attempt001/PREPARATION.json')
  p=entry.validate_preparation_metadata(raw)
  self.assertEqual(len(p['ordered_cells']),6);self.assertEqual(set(p['years']),{'2023'});self.assertEqual(len(entry.array_specs(2023)),27)
  self.assertTrue(all(k.startswith('2023/') or k.startswith('SOURCE_') for k in p['artifacts']))
  self.assertEqual(p['ordered_cells'],[x['cell_id'] for x in config.cells()])
 def test_source_prep_modification_cannot_admit(self):
  with self.assertRaisesRegex(ValueError,'AUDITED'):entry.validate_preparation_metadata(b'{}')
 def test_fresh_scopes_cannot_be_publicly_minted(self):
  import follow_admission as admission,follow_native_source_scope as scope,follow_verified_wires as wires,follow_input_loader as loader
  with self.assertRaises((ValueError,TypeError)):admission.FreshHistoricalExecutionScope(*([None]*14))
  with self.assertRaises(ValueError):scope.SourcePreparationScope(2023,None,None,object())
  with self.assertRaises(ValueError):wires.consume(object(),year=2023,preparation_raw=b'{}',supplied={})
  self.assertFalse(admission._LIVE);self.assertFalse(scope._LIVE);self.assertFalse(loader._LIVE);self.assertFalse(wires._LIVE)
 def test_all6_target_selection_is_tier_guard_separate(self):
  import follow_admission as a
  arrays={name:np.frombuffer(np.zeros(shape,dtype=dtype).tobytes(),dtype=dtype).reshape(shape) for name,(shape,dtype) in entry.array_specs(2023).items()}
  for cell in config.cells():self.assertIs(a.select_saved_target(arrays,cell_id=cell['cell_id'],year=2023),arrays[cell['recipe']+'_'+cell['tier']])
  for cell in ('2024_STATIC50_FOLLOW_POOL_SAMEGROSS_LOW_D_INTRINSIC_LOWER_ONLY_V1','2023_STATIC50_HIGH365_REFERENCE_HOLD_LOW_D_INTRINSIC_LOWER_ONLY_V1',None):
   with self.assertRaises(ValueError):a.select_saved_target(arrays,cell_id=cell,year=2023)
 def test_old_and_invalid_authority_rejected(self):
  import follow_finance_gate as gate
  prep=c.ordinary(c.ROOT/'original_follow_pair_D_source_20261016_v1/source_attempts/ACTUAL_ALL30_SOURCE_TARGET_ONLY_attempt001/PREPARATION.json')
  raw=c.canonical({'schema':'ROOT_FINANCIAL_ORIGINAL_HIGH365_ALL15_CURRENT_D_V1','status':'APPROVED'})
  with self.assertRaises(ValueError):gate.validate(prep,raw,c.sha(raw),raw,c.sha(raw),raw,c.sha(raw),raw,c.sha(raw))
  for cpus in ([4],[5,4],[4,6],[True,5]):
   with self.assertRaises(ValueError):gate.policy(prep,'1'*64,'2'*64,'3'*64,cpus)
 def test_saved_calendar_bounded_exact_dtype_and_layout(self):
  import follow_saved as saved
  matrix=np.asfortranarray(np.arange(20,dtype=np.float64).reshape(10,2));matrix[0,0]=-0.
  for cell in config.cells():
   raw=pack(values=matrix,columns=np.array(['close_us','nav']))
   value,columns=saved.saved_minute(raw,10,cell_id=cell['cell_id']);self.assertEqual(value.tobytes(),matrix.tobytes());self.assertEqual(columns,['close_us','nav'])
   self.assertEqual(saved.admitted_calendar_minutes(cell['cell_id']),525600)
   for rows in (True,-1,525601):
    with self.assertRaises(ValueError):saved.saved_minute(raw,rows,cell_id=cell['cell_id'])
  with self.assertRaises(ValueError):saved.saved_minute(pack(values=matrix.astype('float32'),columns=np.array(['a','b'])),10,cell_id=config.cells()[0]['cell_id'])

if __name__=='__main__':unittest.main(verbosity=2)
