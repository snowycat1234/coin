"""Fake quality cells for generated accounts; never actual source authority."""
from dataclasses import dataclass
@dataclass(frozen=True)
class QualityCell:
    symbol:str
    minute_open_us:int
    completed_us:int
    available_us:int
    price_text:str
    anchor_minute_open_us:int
    anchor_completed_us:int
    anchor_available_us:int
    anchor_installed_us:int
    anchor_observation_us:int
    anchor_source_SHA256:str
    anchor_record_id:str
    arrival_status:str='UNKNOWN_NOT_CERTIFIED'
    def validate(self):
        if not self.anchor_source_SHA256 or not self.anchor_record_id:raise ValueError('GENERATED_ANCHOR_REQUIRED')
        return True
class _Fixture:
    QualityCell=QualityCell
def original_quality():return _Fixture
