"""Pure/metadata-only negatives; never creates or clears a production claim."""
import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import follow_native_common as c
import follow_recovery as r

def fixture():
    m=r._map()
    bodies={p['relative_path']:c.exact(c.ROOT/p['relative_path'],p['SHA256'],p['bytes']) for p in m['evidence_files']}
    return m,bodies

def replace(m,bodies,name,value,*,repin=True):
    raw=c.canonical(value);bodies[name]=raw
    if repin:
        pin=next(p for p in m['evidence_files'] if p['relative_path']==name)
        pin['SHA256']=c.sha(raw);pin['bytes']=len(raw)

class ExactPrefinanceRecoveryTests(unittest.TestCase):
    def test_exact_saved_failure_metadata_only(self):
        self.assertEqual(r.validate_recovery(),r.recovery_policy())
        policy=r.recovery_policy()
        self.assertEqual(len(policy['recovered_prefinance_cells']),2)
        self.assertEqual(len(policy['original_first_launch_cells']),4)
        self.assertFalse(policy['scientific_or_successful_financial_experiment_rerun_authorized'])
        self.assertFalse(policy['snapshot_resume_authorized'])
        self.assertFalse(policy['further_recovery_after_new_launch_authorized'])

    def test_pure_exact_fixture(self):
        m,b=fixture();self.assertTrue(r._validate_evidence(m,b))

    def test_nonzero_or_boolean_activity_never_recoverable(self):
        for key in ('financial_constructors','financial_account_advance','actual_provider_calls',
                    'historical_scope_mints','native_simulator_construct_or_advance','network_calls',
                    'process_launches','financial_GO_writes'):
            for value in (1,False):
                with self.subTest(key=key,value=value):
                    m,b=fixture();name=r.OLD_ATTEMPT+'/'+m['failed_before_finance_cells'][0]+'/FAILED_SOURCE_RECAPTURE_GUARD_RECEIPT.json'
                    guard=c.exact_object(b[name]);guard['forbidden_attempts'][key]=value;replace(m,b,name,guard)
                    with self.assertRaises(ValueError):r._validate_evidence(m,b)

    def test_sourceaccepted_or_second_checkpoint_rejected(self):
        m,b=fixture();name=r.OLD_ATTEMPT+'/'+m['failed_before_finance_cells'][0]+'/FAILED_SOURCE_RECAPTURE_GUARD_RECEIPT.json'
        guard=c.exact_object(b[name]);guard['checkpoints'].append(dict(label='EXACT_SAVED_FOLLOW_FIRST6_TARGETS_LOADED_WITHOUT_REGENERATION',attempts=dict(guard['checkpoints'][0]['attempts'])))
        replace(m,b,name,guard)
        with self.assertRaises(ValueError):r._validate_evidence(m,b)

    def test_any_constructor_or_source_capture_phase_rejected(self):
        for key,value in (('accounts_constructed',1),('providers_constructed',1),('historical_scopes_constructed',1),('source_capture_started',True),('accounts_constructed',False)):
            with self.subTest(key=key,value=value):
                m,b=fixture();name=r.OLD_ATTEMPT+'/'+m['failed_before_finance_cells'][0]+'/WORKER_AUTHORITY_VERIFIED.json'
                row=c.exact_object(b[name]);row[key]=value;replace(m,b,name,row)
                with self.assertRaises(ValueError):r._validate_evidence(m,b)

    def test_changed_missing_and_extra_artifact_rejected(self):
        m,b=fixture();name=next(iter(b));b[name]=b[name]+b' '
        with self.assertRaises(ValueError):r._validate_evidence(m,b)
        m,b=fixture();b.pop(next(iter(b)))
        with self.assertRaises(ValueError):r._validate_evidence(m,b)
        m,b=fixture();b[r.OLD_ATTEMPT+'/ACCOUNT_FINANCIAL_AUDIT.json']=b'{}'
        with self.assertRaises(ValueError):r._validate_evidence(m,b)

    def test_wrong_successful_root_exit_rejected_even_after_repin(self):
        m,b=fixture();name=r.OLD_ATTEMPT+'/ROOT_OBSERVED_EXIT_CONFIRMED.json';row=c.exact_object(b[name]);row['observed_exit_code']=0;replace(m,b,name,row)
        with self.assertRaises(ValueError):r._validate_evidence(m,b)

    def test_resume_or_old_claim_mismatch_rejected(self):
        m,b=fixture();cell=m['failed_before_finance_cells'][0];name=r.OLD_REGISTRY+'/'+cell+'.json'
        row=c.exact_object(b[name]);row['financial_snapshot_resume']=True;replace(m,b,name,row)
        with self.assertRaises(ValueError):r._validate_evidence(m,b)

    def test_only_exact_two_recoverable_not_six(self):
        m,b=fixture();m['failed_before_finance_cells']=m['ordered_cells']
        with self.assertRaises(ValueError):r._validate_evidence(m,b)

    def test_other_old_namespace_and_successful_files_rejected(self):
        with tempfile.TemporaryDirectory(prefix='GENERATED_FOLLOW_RECOVERY_ONLY_') as td,patch.object(c,'ROOT',Path(td)):
            attempt=c.ROOT/r.OLD_ATTEMPT;registry=c.ROOT/r.OLD_REGISTRY
            attempt.mkdir(parents=True);registry.mkdir(parents=True)
            self.assertEqual(r._filesystem_inventory((r.OLD_ATTEMPT,r.OLD_REGISTRY)),(set(),{r.OLD_ATTEMPT,r.OLD_REGISTRY}))
            extra=registry.parent/'another_scope';extra.mkdir()
            with self.assertRaises(ValueError):r._filesystem_inventory((r.OLD_ATTEMPT,r.OLD_REGISTRY))
            extra.rmdir();extra=attempt.parent/'another_attempt';extra.mkdir()
            with self.assertRaises(ValueError):r._filesystem_inventory((r.OLD_ATTEMPT,r.OLD_REGISTRY))
            extra.rmdir();link=attempt/'fake';link.symlink_to(registry)
            with self.assertRaises(ValueError):r._filesystem_inventory((r.OLD_ATTEMPT,r.OLD_REGISTRY))

    def test_recovery_evidence_must_stay_outside_source_guard(self):
        import follow_native_source_guard as guard
        with patch.object(guard,'current_guard',return_value=object()):
            with self.assertRaisesRegex(ValueError,'MUST_PRECEDE_SOURCE_GUARD'):r.validate_recovery()

if __name__=='__main__':unittest.main()
