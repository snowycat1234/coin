"""Fresh FOLLOW first6 finance authority. Source/old finance GOs cannot admit it."""
import follow_native_bootstrap
import follow_native_common as c
import follow_native_config as config
import follow_source_entry as source_entry
SOURCE_CODE_SHA256=source_entry.SOURCE_CODE_SHA256
PREPARED_SOURCE_AUDIT_SHA256='775bb72cf7ea5480fbf3ce1a6b15dc75e0165f7ebd9e4f83efab8ec4a4eb05fd'
PLAN_SHA256='38ad7bb83c356c61b91a2e0720ad3e8df80e970d7b3fb51081e3c5dbb9fe1912'
REVIEW_SCHEMA='INDEPENDENT_FOLLOW_FIRST6_FINANCIAL_ADMISSION_V2_CP437_RECOVERY'
NATIVE_REVIEW_SCHEMA='INDEPENDENT_FOLLOW_FIRST6_NATIVE_GENERATED_ADMISSION_V2_CP437_RECOVERY'
GO_SCHEMA='ROOT_FINANCIAL_FOLLOW_FIRST6_CURRENT_D_V2_CP437_RECOVERY'
CLAIM_NAMESPACE='original_follow_pair_first6_D_native_20261016_v2/EXECUTION_CLAIMS'
SHARED_CPU_LEASE='original_cs_mom21_D_20261015_v4/EXECUTION_CLAIMS/9a5ef547d61272d5eb0bfb1b61fef8005a752d82f4e0007d18cbe65f06445a8a/CONTROLLER_LEASE.lock'

def code_identity():
 source_entry.code_identity();source_entry.manifest_sha()
 raw=c.ordinary(c.HERE/'FINANCIAL_CODE_MANIFEST.json');m=c.exact_object(raw)
 if m.get('schema')!='FOLLOW_FIRST6_ADDITIVE_THIN_NATIVE_FINANCIAL_CODE_V2_CP437_RECOVERY' or m.get('source_code_manifest_SHA256')!=SOURCE_CODE_SHA256:
  raise ValueError('EXACT_FIRST6_FINANCIAL_CODE_MANIFEST_REQUIRED')
 for name,pin in m['files'].items():c.exact(c.HERE/c.relative(name),pin['SHA256'],pin['bytes'])
 for name,pin in m['dependencies'].items():c.exact(c.ROOT/c.relative(name),pin['SHA256'],pin['bytes'])
 return c.sha(raw)

def base(preparation_raw):
 import follow_recovery
 p=source_entry.validate_preparation_metadata(preparation_raw)
 return dict(candidate=config.CANDIDATE,adaptation_version=config.VERSION,financial_adapter_version='FIRST6_V2_EXACT_CP437_PRELOAD_ZERO_FINANCE_RECOVERY',zero_finance_failed_attempt_recovery=follow_recovery.recovery_policy(),financial_code_manifest_SHA256=code_identity(),source_code_manifest_SHA256=SOURCE_CODE_SHA256,
  scope_manifest_SHA256=source_entry.manifest_sha(),native_source_descriptor_SHA256=source_entry.contract_sha(),native_source_identity=source_entry.descriptor()['qualified_source_contract']['source_identity'],
  preparation_SHA256=c.sha(preparation_raw),plan_SHA256=PLAN_SHA256,independent_prepared_source_audit_SHA256=PREPARED_SOURCE_AUDIT_SHA256,
  source_stage_GO_SHA256=p['source_stage_GO_SHA256'],source_independent_review_SHA256=p['source_review_SHA256'],tranche=source_entry.FIRST6,ordered_cells=p['ordered_cells'],years=[2023],
  per_cell_input_binding_SHA256={k:v['input_binding_SHA256'] for k,v in p['cells'].items()},all_saved_target_covariance_gross_array_identities=p['years']['2023']['array_identities'])

def native_policy(resource_probe_sha):
 return dict(schema=NATIVE_REVIEW_SCHEMA,status='PASS',financial_code_manifest_SHA256=code_identity(),scope_manifest_SHA256=source_entry.manifest_sha(),native_source_descriptor_SHA256=source_entry.contract_sha(),
  ordered_cells=list(source_entry.tranche_cells(source_entry.FIRST6)),years=[2023],generated_resource_probe_SHA256=c.digest(resource_probe_sha),
  native_financial_gate_reviewed=True,generated_source_native_authority_quality_terminal_partial_saved40_process_disk_reviewed=True,
  genuine_new_follow_admission_types_reviewed=True,frozen_financial_and_risk_code_objects_unchanged=True,exact_cp437_preguard_preload_reviewed=True,unchanged_source_import_guard_reviewed=True,cold_process_real_npz_and_native_capture_read_path_reviewed=True,zero_finance_evidence_bound_claim_recovery_reviewed=True,
  financial_execution_authorized=False,actual_source_or_target_bodies_read=False,actual_CPU45_resource_probe_run=False,annual_historical_resource_envelope_certified=False,
  generated_physical_CPUs_allowed=[6,7,8],production_worker_CPUs=[4,5],maximum_live_workers=2,remaining24_authorized=False)

def review_policy(preparation_raw,prepared_review_sha,native_review_sha):
 return dict(base(preparation_raw),schema=REVIEW_SCHEMA,status='PASS',prepared_source_target_review_SHA256=c.digest(prepared_review_sha),native_generated_review_SHA256=c.digest(native_review_sha),
  financial_execution_authorized=False,native_financial_gate_reviewed=True,shared_CPU45_lease_exclusion_reviewed=True,separate_permanent_first6_claims_reviewed=True,remaining24_authorized=False)

def policy(preparation_raw,review_sha,prepared_review_sha,native_review_sha,worker_cpus):
 if type(worker_cpus) is not list or worker_cpus!=[4,5] or any(type(x) is not int for x in worker_cpus):raise ValueError('EXACT_MAX2_CPU4_5_WORKERS_REQUIRED')
 return dict(base(preparation_raw),schema=GO_SCHEMA,status='APPROVED_FRESH_EXACT_FIRST6',action='RUN_FRESH_2023_FOLLOW_POOL_THEN_DEPENDENT_CONTROL_LOW_MID_HIGH_CURRENT_D_ONLY',
  target_financial_independent_review_SHA256=c.digest(review_sha),prepared_source_target_review_SHA256=c.digest(prepared_review_sha),native_generated_review_SHA256=c.digest(native_review_sha),
  requested_worker_count=2,worker_CPUs=[4,5],resource_limits=dict(per_case_wall_seconds=600,per_case_CPU_seconds=600,per_case_RSS_stop_bytes=2000000000,per_case_AS_bytes=4000000000,per_case_output_bytes=250000000,aggregate_live_worker_RSS_stop_bytes=3500000000,compute_pool_threads_max=1),
  cohort_disk_safety=dict(minimum_free_bytes=1810612736,base_free_floor_bytes=1610612736,reserved_publication_bytes=200000000,maximum_cohort_output_log_temporary_bytes=1100000000,initial_full_cohort_cap_admission_required=True,full_cap_admission_before_output_claims_leases_workers=True,external_disk_writers_guaranteed=False,filesystem_quota_guaranteed=False,check_cadence='BEFORE_EACH_LAUNCH_AND_EXISTING_0.1_SECOND_POLL'),
  separate_fresh_genesis_claim_namespace=CLAIM_NAMESPACE,shared_CS_CPU45_lease=SHARED_CPU_LEASE,shared_CPU45_lease_nonblocking=True,global_inherited_flock_required=True,permanent_cross_output_cell_claim_required=True,
  policy_variant='GUARD50_EXIT_ONLY',cost='BASE27',initial_cash_USDT='10000',isolated_margin_ceiling_USDT='8500',free_cash_floor_USDT='1000',
  quantity_profile_SHA256='94b2238b25ed345a24a1fa148c6f35523b8efe9bf47496958028844432cb8ebf',quantity_collar='.99',latency='1min+1us',opening_minimum_USDT='10',paid_closing_exemption=True,paid_terminal_attempts=60,partial_fractions=['1','.75','.5','.25','0'],capacity='PRIOR_COMPLETED_MINUTE_QUOTE_VOLUME_TIMES_.001',
  funding_before_fill=True,reductions_before_increases=True,intrinsic_samegross=True,post_tier_samegross_guaranteed=False,risk_matched_claim=False,independent_lower_only_tier_after_complete_intrinsic=True,
  native_source_capture_authorized=True,source_stage_native_capture_authorized=False,source_and_native_capture_capabilities_separate=True,canonical_2023_source_descriptor_exact=True,canonical199_and365_close_tail_matches_saved_original_full_prefix=True,
  actual_provider_iteration_authorized=True,account_construction_authorized=True,financial_execution_authorized=True,fresh_genesis_only=True,
  saved_targets_rebuilt_during_finance=False,covariance_rebuilt_during_finance=False,literal_funding_event_clocks_preserved=True,funding_rate_rescale_authorized=False,
  automatic_retry_authorized=False,halted_snapshot_resume_authorized=False,other_controller_overlap_authorized=False,internal_margin_transfers_authorized=False,topup_authorized=False,new_capital_authorized=False,
  target_byte_equivalence_execution_reuse_authorized=False,old_financial_scope_or_GO_reused=False,remaining24_authorized=False,other_years_or_holdouts_authorized=False,publication_authorized=False)

def prepared_review(preparation_raw,raw,expected_sha):
 source_entry.validate_preparation_metadata(preparation_raw)
 if expected_sha!=PREPARED_SOURCE_AUDIT_SHA256:raise ValueError('EXACT_INDEPENDENT_ALL30_PREPARED_AUDIT_REQUIRED')
 r=c.checked_external(raw,expected_sha)
 if r.get('PREPARATION_SHA256')!=c.sha(preparation_raw) or r.get('financial_execution_authorized') is not False or r.get('status')!='PASS_EXACT_ALL30_PREPARED_SOURCE_TARGET_ONLY_NO_FINANCIAL_ADMISSION':raise ValueError('EXACT_PREPARED_SOURCE_TARGET_REVIEW_REQUIRED')
 return c.immutable(r)
def native_review(raw,expected_sha):
 r=c.checked_external(raw,expected_sha)
 if c.canonical(r)!=c.canonical(native_policy(r.get('generated_resource_probe_SHA256'))):raise ValueError('EXACT_FIRST6_NATIVE_GENERATED_REVIEW_REQUIRED')
 return c.immutable(r)
def validate(preparation_raw,go_raw,expected_go_sha,review_raw,expected_review_sha,prepared_review_raw,expected_prepared_review_sha,native_review_raw,expected_native_review_sha):
 prepared_review(preparation_raw,prepared_review_raw,expected_prepared_review_sha);native_review(native_review_raw,expected_native_review_sha)
 r=c.checked_external(review_raw,expected_review_sha)
 if c.canonical(r)!=c.canonical(review_policy(preparation_raw,expected_prepared_review_sha,expected_native_review_sha)):raise ValueError('EXACT_FRESH_FIRST6_FINANCIAL_REVIEW_REQUIRED')
 go=c.checked_external(go_raw,expected_go_sha)
 if c.canonical(go)!=c.canonical(policy(preparation_raw,expected_review_sha,expected_prepared_review_sha,expected_native_review_sha,go.get('worker_CPUs'))):raise ValueError('EXACT_FRESH_FIRST6_ROOT_FINANCIAL_AUTHORITY_REQUIRED')
 import follow_recovery
 follow_recovery.validate_recovery()
 return c.immutable(go)
