"""Finite new FOLLOW native-source capture, canonical 2023 tape only."""
import follow_native_common as c
import follow_native_source_scope as entry
from follow_native_source2023 import assemble_inputs

def capture_year(year,source_scope):
 if type(source_scope) is not entry.SourcePreparationScope:raise ValueError('EXACT_NEW_FOLLOW_NATIVE_CAPTURE_SCOPE_REQUIRED')
 source_scope.validate_current(year=year)
 contract=entry.contracts()['years'][str(year)]
 def read(name):
  pin=contract['read_files'][name]
  return source_scope.read_source(year,name,pin['SHA256'],pin['bytes'])
 result=assemble_inputs(year,read(contract['warmup_path']),read(contract['daily_path']),read(contract['events_path']),read(contract['quality_sidecar_path']),tuple((rec['path'],read(rec['path'])) for rec in contract['months']),contract)
 source_scope.validate_current(year=year)
 return result
