"""Pure FOLLOW target adapter for internally generated checks only."""
import follow_native_bootstrap
import follow_native_config as config
import follow_signal as source
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
DAY=config.DAY
SYMBOLS=config.SYMBOLS
RECIPES=config.RECIPES
supported_array=source.supported_array
_PURE=None
def reviewed_signal():
 global _PURE
 if _PURE is None:_PURE=source.reviewed_signal()
 return _PURE
def array_byte_identity(a):return reviewed_signal().array_byte_identity(a)
def build_target_grid(*args):return reviewed_signal().build_target_grid(*args)
