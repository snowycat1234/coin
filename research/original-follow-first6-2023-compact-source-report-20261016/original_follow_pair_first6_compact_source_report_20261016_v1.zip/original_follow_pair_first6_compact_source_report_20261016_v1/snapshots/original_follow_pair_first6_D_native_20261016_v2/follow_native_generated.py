"""Internally invented FOLLOW fixtures; no caller arrays, paths or history."""
from follow_transport import load as _load
_load('follow_native_generated',globals())

def project_generated(fixture,recipe=signal.RECIPES[0]):
 if type(fixture) is not GeneratedFixture:raise ValueError('LIVE_INTERNALLY_GENERATED_FIXTURE_REQUIRED')
 fixture.validate()
 if recipe not in signal.RECIPES:raise ValueError('EXACT_FOLLOW_RECIPE_REQUIRED')
 prices=fixture.close
 grid,proofs=signal.build_target_grid(prices,fixture.close_us,fixture.available_us,fixture.decisions,fixture.close_us,prices*1.01,prices*.99,prices,np.ones(prices.shape,dtype=bool))
 raw=original=grid['intrinsic_'+recipe]
 targets={tier:grid[recipe+'_'+tier] for tier in TIERS};cov=grid['annual_covariance']
 diagnostics_json=json.dumps(dict(recipe=recipe,complete_original_intrinsic_then_downward_only=True,reexpansion=False),sort_keys=True,separators=(',',':'))
 proofs_json=json.dumps(proofs,sort_keys=True,separators=(',',':'),allow_nan=False)
 arrays=[frozen_array(raw),frozen_array(original),*(frozen_array(targets[tier]) for tier in TIERS),frozen_array(cov)]
 digest=array_digest(*arrays)+sha256((diagnostics_json+proofs_json).encode()).hexdigest()
 obj=GeneratedTargets(fixture,arrays[0],arrays[1],MappingProxyType(dict(zip(TIERS,arrays[2:5]))),arrays[5],diagnostics_json,proofs_json,digest)
 _LIVE_TARGETS[id(obj)]=(weakref.ref(obj),obj.digest)
 return obj.validate()
