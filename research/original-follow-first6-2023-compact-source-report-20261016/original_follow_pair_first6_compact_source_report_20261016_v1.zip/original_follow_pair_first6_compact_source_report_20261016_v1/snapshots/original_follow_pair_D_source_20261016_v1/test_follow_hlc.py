from io import BytesIO
import copy
import csv
import json
import unittest
import zipfile
import numpy as np
import follow_hlc as h


def zipped(body,symbol='BTCUSDT',period='2022-01-01',name=None):
 out=BytesIO()
 with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:z.writestr(name or f'{symbol}-1m-{period}.csv',body)
 return out.getvalue()


def rows(period='2022-01-01',missing=(),header=False):
 left,right=h.period_bounds(period);out=[]
 if header:out.append(','.join(h.COLUMNS))
 for i,at in enumerate(range(left,right,h.MINUTE)):
  if i in missing:continue
  price=100+(i%17)*.01
  values=[str(at//1000),str(price),str(price+2),str(price-3),str(price+.5),'1',str(at//1000+59999),'100','2','.5','50','0']
  out.append(','.join(values))
 return out


def parsed(period='2022-01-01',missing=()):return h.parse_original_trade_zip(zipped('\n'.join(rows(period,missing))+'\n',period=period),symbol='BTCUSDT',period=period)


class GenuineHLCGeneratedChecks(unittest.TestCase):
 def test_true_extrema_and_actual_close_availability(self):
  p=parsed();daily=h.aggregate_trade_daily(p);left,right=h.period_bounds('2022-01-01')
  self.assertEqual(daily['available_us'].tolist(),[right]);self.assertEqual(daily['high'][0],np.max(p.values[:,2]));self.assertEqual(daily['low'][0],np.min(p.values[:,3]));self.assertEqual(daily['close'][0],p.values[-1,4]);self.assertFalse(daily['high'].flags.writeable)
 def test_header_all_twelve_aliases_and_order(self):
  p=h.parse_original_trade_zip(zipped('\n'.join(rows(header=True))+'\n'),symbol='BTCUSDT',period='2022-01-01');self.assertTrue(p.provenance['header_present'])
  values=rows(header=True);header=values[0].split(',');header[2],header[3]=header[3],header[2];values[0]=','.join(header)
  with self.assertRaisesRegex(ValueError,'HEADER'):h.parse_original_trade_zip(zipped('\n'.join(values)+'\n'),symbol='BTCUSDT',period='2022-01-01')
 def test_no_mark_candle_substitution_or_wrong_symbol(self):
  raw=zipped('\n'.join(rows())+'\n')
  with self.assertRaisesRegex(ValueError,'NO_MARK'):h.parse_original_trade_zip(raw,symbol='BTCUSDT',period='2022-01-01',family='markPriceKlines')
  with self.assertRaises(ValueError):h.parse_original_trade_zip(raw,symbol='ETHUSDT',period='2022-01-01')
 def test_incomplete_minute_cannot_be_daily_candle(self):
  with self.assertRaisesRegex(ValueError,'1440'):h.aggregate_trade_daily(parsed(missing=(200,)))
 def test_close_time_and_envelope_fields_fail_closed(self):
  for column,replacement in ((6,'1640995200000'),(2,'1'),(3,'200'),(5,'-1'),(8,'1.5'),(11,'NaN')):
   data=rows();r=data[0].split(',');r[column]=replacement;data[0]=','.join(r)
   with self.assertRaises(ValueError):h.parse_original_trade_zip(zipped('\n'.join(data)+'\n'),symbol='BTCUSDT',period='2022-01-01')
 def test_exact_csv_hash_and_single_regular_member(self):
  raw=zipped('\n'.join(rows())+'\n')
  with self.assertRaisesRegex(ValueError,'CSV_HASH'):h.parse_original_trade_zip(raw,symbol='BTCUSDT',period='2022-01-01',expected_csv_sha256='0'*64)
  with self.assertRaises(ValueError):h.parse_original_trade_zip(zipped('\n'.join(rows()),name='../BTCUSDT-1m-2022-01-01.csv'),symbol='BTCUSDT',period='2022-01-01')
 def test_original_duplicate_policies_exact(self):
  values=rows();values.append(values[0]);raw=zipped('\n'.join(values)+'\n')
  for policy in ('IDENTICAL_NUMERIC_ALLOWED','IDENTICAL_TEXT_ALLOWED'):
   self.assertEqual(h.parse_original_trade_zip(raw,symbol='BTCUSDT',period='2022-01-01',duplicate_policy=policy).provenance['identical_duplicates_removed'],1)
  with self.assertRaisesRegex(ValueError,'DUPLICATE'):h.parse_original_trade_zip(raw,symbol='BTCUSDT',period='2022-01-01',duplicate_policy='FORBID_ALL')
  r=values[-1].split(',');r[4]='101';values[-1]=','.join(r)
  with self.assertRaisesRegex(ValueError,'CONFLICT'):h.parse_original_trade_zip(zipped('\n'.join(values)+'\n'),symbol='BTCUSDT',period='2022-01-01')
 def test_daily_genuine_repair_only_original_absences(self):
  month=parsed(period='2022-02',missing=(0,));day=parsed(period='2022-02-01');left,_=h.period_bounds('2022-02')
  fixed=h.repair_original_month(month,[(day,1)],expected_missing_open_ms=[left//1000]);self.assertEqual(len(fixed.open_us),28*1440)
  self.assertEqual(fixed.values[0,2],day.values[0,2]);h.aggregate_trade_daily(fixed)
  with self.assertRaises(ValueError):h.repair_original_month(month,[(day,0)],expected_missing_open_ms=[left//1000])
  with self.assertRaises(ValueError):h.repair_original_month(month,[],expected_missing_open_ms=[left//1000])
 def test_source_future_period_and_bad_dates_are_closed(self):
  for period in ('2026-01','2025-02-30','2022-13','2022-01/../2026-01'):
   with self.assertRaises(ValueError):h.period_bounds(period)
  with self.assertRaises(ValueError):h.year_bounds(True)
 def test_wrapper_only_selected_genuine_member_decompressed(self):
  raw=zipped('\n'.join(rows())+'\n');stream=BytesIO();member='raw/klines/BTCUSDT/BTCUSDT-1m-2022-01-01.zip'
  with zipfile.ZipFile(stream,'w') as z:z.writestr(member,raw);z.writestr('raw/markPriceKlines/unknown.zip',b'never decode')
  got,_=h.selected_wrapper_member(stream.getvalue(),member=member);self.assertEqual(got,raw)
  with self.assertRaises(ValueError):h.selected_wrapper_member(stream.getvalue(),member='raw/markPriceKlines/unknown.zip')
 def capture_bytes(self):
  start,end=h.period_bounds('2021-01');t=np.arange(start+h.DAY,end+h.DAY,h.DAY,dtype=np.int64);p=np.full((len(t),5),100.);arrays=dict(available_us=t,symbol_order=np.array(h.SYMBOLS),ready=np.ones(p.shape,bool),open=p,high=p+2,low=p-3,close=p+.5,volume=p,quote_volume=p)
  out=BytesIO();np.savez_compressed(out,**arrays);return start,end,arrays,out.getvalue()
 def test_qualified_capture_schema_headers_values(self):
  start,end,arrays,raw=self.capture_bytes();out=h.decode_qualified_daily_capture(raw,expected_start_us=start,expected_end_us=end);self.assertEqual(out['high'].shape,(31,5));self.assertFalse(out['ready'].flags.writeable)
  arrays['high']=arrays['high'].astype('float32');stream=BytesIO();np.savez_compressed(stream,**arrays)
  with self.assertRaisesRegex(ValueError,'HEADER'):h.decode_qualified_daily_capture(stream.getvalue(),expected_start_us=start,expected_end_us=end)
 def test_exact_scoped_callback_identity_and_purpose(self):
  raw=b'generated';pin=dict(path='generated/source.zip',bytes=len(raw),SHA256=h.sha(raw),purpose='GENUINE_TRADE_HLC_ARCHIVE');allowed={tuple(pin[k] for k in ('path','SHA256','bytes','purpose'))};seen=[]
  callback=lambda *args:(seen.append(args) or raw)
  self.assertEqual(h._checked_read(2023,pin,callback,allowed),raw);self.assertEqual(seen[0],(2023,pin['path'],pin['SHA256'],pin['bytes'],pin['purpose']))
  with self.assertRaises(ValueError):h._checked_read(2023,pin,lambda *args:b'changed',allowed)
  wrong=dict(pin,path='../escape.zip')
  with self.assertRaises(ValueError):h._checked_read(2023,wrong,callback,allowed)
 def test_split_exact_offsets_and_zip_identity(self):
  raw=zipped('\n'.join(rows())+'\n');a,b=raw[:100],raw[100:];pins=[dict(path=f'generated/p{i}',bytes=len(v),SHA256=h.sha(v),purpose='GENUINE_TRADE_HLC_SPLIT_PART') for i,v in enumerate((a,b))];allowed={tuple(p[k] for k in ('path','SHA256','bytes','purpose')) for p in pins};parts=[dict(offset=0,read_file=pins[0]),dict(offset=100,read_file=pins[1])]
  stream=dict(family='klines',symbol='BTCUSDT',transport='SPLIT_PARTS',parts=parts,ZIP_bytes=len(raw),ZIP_SHA256=h.sha(raw))
  got,_=h._original_stream_bytes(2023,stream,lambda year,path,*args:a if path.endswith('p0') else b,allowed,{})
  self.assertEqual(got,raw);parts[1]['offset']=99
  with self.assertRaisesRegex(ValueError,'OFFSETS'):h._original_stream_bytes(2023,stream,lambda year,path,*args:a if path.endswith('p0') else b,allowed,{})


class ContractTopologyGeneratedChecks(unittest.TestCase):
 def test_current_exact_metadata_topology_all_five_with_generated_rows(self):
  from pathlib import Path
  from unittest.mock import patch
  contract=json.loads((Path(__file__).absolute().parent/'HLC_SOURCE_CONTRACT_MAP.json').read_bytes())
  # Only the actual metadata topology is read. All minute/capture arrays below
  # are invented constant engineering values; no original file callback runs.
  def fake_parse(year,spec,read_source,allowed,wrapper_cache):
   left,right=h.period_bounds(spec['period']);t=np.arange(left,right,h.MINUTE,dtype=np.int64)
   absent=set(spec.get('expected_missing_open_ms',[]));t=t[np.array([int(x)//1000 not in absent for x in t],bool)]
   v=np.tile(np.array([0,100,102,97,100.5,1,0,100,2,.5,50,0],float),(len(t),1));v[:,0]=t//1000;v[:,6]=t//1000+59999
   return h.ParsedTrade(spec['symbol'],spec['period'],h.immutable(t),h.immutable(v),dict(generated_fixture=True,symbol=spec['symbol'],period=spec['period']))
  def fake_capture(raw,expected_start_us,expected_end_us):
   t=np.arange(expected_start_us+h.DAY,expected_end_us+h.DAY,h.DAY,dtype=np.int64);p=np.full((len(t),5),100.5)
   return dict(available_us=t,high=p+1.5,low=p-3.5,close=p,ready=np.ones_like(p,bool))
  with patch.object(h,'_checked_read',return_value=b'GENERATED_ONLY'),patch.object(h,'decode_qualified_daily_capture',side_effect=fake_capture),patch.object(h,'_parse_stream',side_effect=fake_parse):
   for year in (2021,2022,2023,2024,2025):
    result=h.capture_year_hlc(year,lambda *args:(_ for _ in ()).throw(AssertionError('NO_ACTUAL_READ_ALLOWED')),contract_map=contract)
    start,end=h.year_bounds(year);self.assertEqual(result['arrays']['high'].shape,(((end-start)//h.DAY)+20,5));self.assertTrue(result['arrays']['ready'].all());self.assertFalse(result['provenance']['financial_authorized'])

if __name__=='__main__':unittest.main()
