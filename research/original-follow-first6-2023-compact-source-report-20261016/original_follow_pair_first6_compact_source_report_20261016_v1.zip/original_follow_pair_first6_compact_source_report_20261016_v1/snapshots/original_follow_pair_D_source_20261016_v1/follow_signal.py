"""Exact independently reviewed pure adapter, selected without Python file loaders."""
from pathlib import Path
from types import ModuleType
import follow_common as c

PURE=c.ROOT/'original_follow_pair_signal_20261016_v1'
PURE_MANIFEST_SHA256='9b35a110dfb2fd91d0be0bbb7bdaad3c7840f865b96b5739b3f2b8bf83907494'
PURE_REVIEW_SHA256='5e871a15828a3e2cae7d16f3ed4ee72fa32a2c47f082a33fc9ff1e8eed2959bd'

def reviewed_signal():
 raw=c.exact(PURE/'CODE_MANIFEST.json',PURE_MANIFEST_SHA256);manifest=c.exact_object(raw)
 for name,pin in manifest['files'].items():
  c.exact(PURE/c.relative(name),pin['SHA256'],pin['bytes'])
 review=c.exact_object(c.exact(c.ROOT/'original_follow_pair_signal_independent_review_20261016_v1/REVIEW.json',PURE_REVIEW_SHA256))
 if review.get('status') != 'PASS_CODE_AND_GENERATED_ONLY_WITH_SOURCE_FINANCIAL_GATES_CLOSED':
  raise ValueError('EXACT_INDEPENDENT_GENERATED_SIGNAL_REVIEW_REQUIRED')
 path=PURE/'follow_pair_signal.py';module=ModuleType('_exact_reviewed_original_follow_pair_signal');module.__file__=str(path)
 exec(compile(c.ordinary(path),str(path),'exec'),module.__dict__)
 module.verify_sources()
 return module


def supported_array(value):
    import numpy as np
    a=np.asarray(value)
    if a.dtype.fields is not None or a.dtype.subdtype is not None or a.dtype.hasobject or (a.dtype.kind,a.dtype.itemsize) not in (('b',1),('i',8),('f',8)):
        raise ValueError('PLAIN_BOOL_INT64_FLOAT64_ONLY')
    return a
