"""The same fixed30cells; no runtime tier or parameter search."""
import ast
from pathlib import Path
import follow_common as c

PURE= c.ROOT/'original_follow_pair_signal_20261016_v1'

def _pure_config():
 raw=c.exact(PURE/'follow_pair_config.py','5095a7deaad8b389a50403c87c030766ef950a4fdae43221aff707ac4a632c34',2503);ns={'__file__':str(PURE/'follow_pair_config.py')}
 exec(compile(raw,str(PURE/'follow_pair_config.py'),'exec'),ns)
 return ns

_CONFIG=_pure_config()
VERSION=_CONFIG['VERSION'];RECIPES=_CONFIG['RECIPES'];SYMBOLS=_CONFIG['SYMBOLS'];DAY=_CONFIG['DAY'];PERIODS=_CONFIG['PERIODS']
CANDIDATE='ORIGINAL_FOLLOW_PAIR_INTRINSIC_INDEPENDENT_LOWER_ONLY_FIXED30'
TIERS=('LOW','MID','HIGH')
cells=_CONFIG['cells'];cell_named=_CONFIG['cell_named'];period_named=_CONFIG['period_named'];utc=_CONFIG['utc']
source_year=period_named
