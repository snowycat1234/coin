"""Source-only genuine HLC + qualified past closes; no account/provider entry."""
from io import BytesIO
from pathlib import Path
import re
import os
import numpy as np
import follow_common as c
import follow_config as config
import follow_codec as codec
import follow_entry as entry
import follow_signal as signal
import follow_hlc


def blob(arrays):
 stream=BytesIO();np.savez_compressed(stream,**arrays);return stream.getvalue()


def decode_prefix(year,raw,pin):
 period=config.source_year(year);meta=pin['prefix_metadata'];n=meta['selected_rows']
 if (type(n) is not int or not period['days']+199<=n<=4096 or meta['last_source_clock_us']!=period['end']-config.DAY
     or meta['future_close_rows_interpreted']!=0 or meta['unselected_numerical_arrays_interpreted'] is not False
     or meta['prefix_first_row_retained'] is not True or meta['source_fields']!=['symbol_order','close_available_us','close']):
  raise ValueError('EXACT_ORIGINAL_CAUSAL_PAST_CLOSE_PREFIX_METADATA_REQUIRED')
 arrays=codec.npz(raw,dict(close_available_us=((n,),'int64'),close=((n,5),'float64')))
 t,p=arrays['close_available_us'],arrays['close'];pure=signal.reviewed_signal()
 for name,identity in (('close_available_us',meta['clock_identity']),('close',meta['close_identity'])):
  if c.canonical(pure.array_byte_identity(arrays[name]))!=c.canonical(identity):raise ValueError('EXACT_QUALIFIED_PREFIX_DTYPE_SHAPE_RAW_BYTES_REQUIRED')
 if (t[0]!=meta['first_source_clock_us'] or t[-1]!=period['end']-config.DAY or np.any(np.diff(t)!=config.DAY)
     or np.any(t<0) or np.any(t%config.DAY) or np.isinf(p).any() or np.any(p[np.isfinite(p)]<=0)):
  raise ValueError('EXACT_PAST_ONLY_ORIGINAL_PREFIX_CLOCK_PRICE_REQUIRED')
 return arrays


def validate_hlc(year,arrays):
 period=config.source_year(year);expected=np.arange(period['start']-20*config.DAY,period['end'],config.DAY,dtype=np.int64)
 if type(arrays) is not dict or set(arrays)!={'available_us','high','low','close','ready'}:
  raise ValueError('EXACT_GENUINE_TRADE_HLC_ARRAY_NAMESPACE_REQUIRED')
 for name,value in arrays.items():
  a=signal.supported_array(value);dtype='int64' if name=='available_us' else 'bool' if name=='ready' else 'float64'
  shape=(len(expected),) if name=='available_us' else (len(expected),5)
  if a.dtype!=np.dtype(dtype) or a.shape!=shape:raise ValueError('EXACT_HLC_PLAIN_DTYPE_SHAPE_REQUIRED')
 if not np.array_equal(arrays['available_us'],expected) or not arrays['ready'].all():raise ValueError('EXACT_FULL_COMPLETED_HLC_CALENDAR_REQUIRED')
 h,l,p=(arrays[k] for k in ('high','low','close'))
 if not np.isfinite(h).all() or not np.isfinite(l).all() or not np.isfinite(p).all() or np.any(l<=0) or np.any(l>p) or np.any(p>h):
  raise ValueError('COMPLETE_GENUINE_TRADE_HLC_ENVELOPE_REQUIRED')
 return arrays


def validate_source_pair(year,prefix,hlc):
 validate_hlc(year,hlc);t,p=prefix['close_available_us'],prefix['close'];at=hlc['available_us'];ids=np.searchsorted(t,at)
 if np.any(ids>=len(t)) or not np.array_equal(t[ids],at) or not np.array_equal(p[ids],hlc['close']):
  raise ValueError('EXACT_GENUINE_TRADE_HLC_RISK_CLOSE_PARITY_REQUIRED')
 return True


def capture_year(year,scope):
 if type(scope) is not entry.FollowPairSourcePreparationScope:raise ValueError('EXACT_FRESH_FOLLOW_PAIR_SOURCE_SCOPE_REQUIRED')
 scope.validate_current(year);close_map,hlc_map=entry.source_maps();pin=close_map['years'][str(year)]
 raw=scope.read_source(year,pin['path'],pin['SHA256'],pin['bytes'],pin['purpose'])
 prefix=decode_prefix(year,raw,pin)
 result=follow_hlc.capture_year_hlc(year,scope.read_source,contract_map=hlc_map)
 if type(result) is not dict or set(result)!={'arrays','provenance'}:raise ValueError('EXACT_HLC_CAPTURE_RESULT_REQUIRED')
 hlc=validate_hlc(year,result['arrays']);validate_source_pair(year,prefix,hlc);scope.validate_current(year)
 return dict(prefix=prefix,prefix_raw=raw,HLC=hlc,HLC_provenance=result['provenance'])


def project_targets(year,source):
 period=config.source_year(year);validate_source_pair(year,source['prefix'],source['HLC']);p=source['prefix'];h=source['HLC']
 pure=signal.reviewed_signal();d=np.arange(period['start'],period['end'],config.DAY,dtype=np.int64)
 arrays,proofs=pure.build_target_grid(p['close'],p['close_available_us'],p['close_available_us'],d,h['available_us'],h['high'],h['low'],h['close'],h['ready'])
 if set(arrays)!=set(entry.array_specs(year)):raise ValueError('EXACT_PAIRED_INTRINSIC_TIERS_GROSS_DIAGNOSTIC_NAMESPACE_REQUIRED')
 for key,(shape,dtype) in entry.array_specs(year).items():
  a=arrays[key]
  if a.dtype!=np.dtype(dtype) or a.shape!=shape or not np.isfinite(a).all():raise ValueError('EXACT_FINITE_PAIRED_TARGET_ARRAY_SHAPES_REQUIRED')
 return arrays,proofs


def write_artifact(output,name,raw):
 if type(raw) is not bytes:raise ValueError('EXACT_OUTPUT_ARTIFACT_BYTES_REQUIRED')
 disk=os.statvfs(output);size=sum(p.stat().st_size for p in output.rglob('*') if p.is_file())
 if size+len(raw)>134217728 or disk.f_bavail*disk.f_frsize-len(raw)<1610612736:raise ValueError('SOURCE_OUTPUT_CAP_AND_DISK_FLOOR_REQUIRED')
 path=output/c.relative(name);path.parent.mkdir(parents=True,exist_ok=True)
 with path.open('xb') as stream:stream.write(raw)
 return dict(bytes=len(raw),SHA256=c.sha(raw))


def prepare_source_only(output_directory,*,source_go_raw,expected_source_go_sha256,review_raw,expected_review_sha256):
 authority=entry.validate_source_authority_metadata(source_go_raw,expected_source_go_sha256,review_raw,expected_review_sha256)
 from follow_source_guard import current_guard
 guard=current_guard()
 if guard is None or not guard.active:raise ValueError('WHOLE_INVOCATION_FOLLOW_PAIR_SOURCE_ONLY_GUARD_REQUIRED')
 output=Path(output_directory).absolute();base=c.HERE/'source_attempts'
 if (output.parent!=base or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,100}',output.name)
     or output.is_symlink() or any(p.is_symlink() for p in output.parents) or output.exists()):
  raise ValueError('EXCLUSIVE_NEW_FOLLOW_PAIR_SOURCE_ATTEMPT_REQUIRED')
 output.mkdir(parents=True);artifacts={};years={};cells={};captured={};target_stops={};pure=signal.reviewed_signal()
 with entry.admit_source_stage(source_go_raw,expected_source_go_sha256,review_raw,expected_review_sha256) as scope:
  for year in entry.tranche_years(entry.ALL30):
   source=capture_year(year,scope);prefix=str(year)+'/'
   # Retain source capture before target arithmetic, so a genuine target STOP
   # cannot erase qualified HLC work or force another expensive original read.
   for name,raw in {'SOURCE_PREFIX_INPUTS.npz':source['prefix_raw'],'GENUINE_TRADE_HLC.npz':blob(source['HLC']),
      'GENUINE_TRADE_HLC_PROVENANCE.json':c.canonical(source['HLC_provenance'])+b'\n'}.items():
    artifacts[prefix+name]=write_artifact(output,prefix+name,raw)
   source_receipt=dict(schema='FOLLOW_PAIR_REUSABLE_GENUINE_HLC_SOURCE_CAPTURE_V1',year=year,status='PASS_SOURCE_CAPTURE_ONLY_NO_TARGET_OR_FINANCE_ADMISSION',
    source_map_identity=entry.source_map_identity(),source_GO_SHA256=expected_source_go_sha256,source_review_SHA256=expected_review_sha256,
    prefix_array_identities={k:pure.array_byte_identity(v) for k,v in source['prefix'].items()},
    HLC_array_identities={k:pure.array_byte_identity(v) for k,v in source['HLC'].items()},
    artifacts={k:v for k,v in artifacts.items() if k.startswith(prefix)},historical_execution_authorized=False,financial_execution_authorized=False)
   artifacts[prefix+'SOURCE_CAPTURE_RECEIPT.json']=write_artifact(output,prefix+'SOURCE_CAPTURE_RECEIPT.json',c.canonical(source_receipt)+b'\n')
   captured[year]=(source,source_receipt)
   guard.checkpoint('SOURCE_CAPTURED_'+str(year)+'_GENUINE_HLC_PARITY_NO_ACCOUNT')
  # Complete the mandatory five-period source gate before any target stage.
  guard.checkpoint('ALL_FIVE_GENUINE_HLC_SOURCE_CAPTURES_COMPLETE_NO_TARGET_SELECTION')
  for year in entry.tranche_years(entry.ALL30):
   source,source_receipt=captured[year];prefix=str(year)+'/'
   try:targets,proofs=project_targets(year,source)
   except ValueError as exc:
    stopped=dict(schema='FOLLOW_PAIR_ORIGINAL_TARGET_PREPARATION_STOP_V1',year=year,status='STOP_TARGET_ARITHMETIC_OR_ADMISSION_NO_FINANCE',error=type(exc).__name__+':'+str(exc),source_capture_receipt_SHA256=artifacts[prefix+'SOURCE_CAPTURE_RECEIPT.json']['SHA256'],original_function_or_tolerance_changes_applied=False,historical_execution_authorized=False,financial_execution_authorized=False)
    artifacts[prefix+'STOP_TARGET_PREPARATION.json']=write_artifact(output,prefix+'STOP_TARGET_PREPARATION.json',c.canonical(stopped)+b'\n')
    target_stops[str(year)]=stopped
    continue
   for name,raw in {'TARGETS.npz':blob(targets),'TARGET_PROOFS.json':c.canonical(dict(intrinsic_samegross=True,post_tier_samegross_guaranteed=False,proofs=proofs))+b'\n'}.items():
    artifacts[prefix+name]=write_artifact(output,prefix+name,raw)
   info=dict(year=year,source_capture_receipt_SHA256=artifacts[prefix+'SOURCE_CAPTURE_RECEIPT.json']['SHA256'],
    array_identities={k:pure.array_byte_identity(v) for k,v in targets.items()},
    intrinsic_samegross=True,post_tier_samegross_guaranteed=False,source_admitted_for_preparation_only=True,financial_authorized=False)
   years[str(year)]=info
   for cell in config.cells():
    if cell['year']!=year:continue
    key=cell['recipe']+'_'+cell['tier'];binding=dict(cell=cell,source_maps_SHA256=entry.source_map_identity(),source_capture_receipt_SHA256=info['source_capture_receipt_SHA256'],target_array_identity=info['array_identities'][key],covariance_identity=info['array_identities']['annual_covariance'],source_stage_GO_SHA256=expected_source_go_sha256,source_review_SHA256=expected_review_sha256,financial_admission=False)
    cells[cell['cell_id']]=dict(descriptor=cell,input_binding=binding,input_binding_SHA256=c.jsha(binding))
   guard.checkpoint('TARGETS_PREPARED_'+str(year)+'_PAIRED_INTRINSIC_LOWER_ONLY_NO_ACCOUNT')
 if entry._ACTIVE_SOURCE:raise ValueError('SOURCE_SCOPES_NOT_REVOKED')
 if target_stops:
  stopped=dict(schema='FOLLOW_PAIR_ALL_FIVE_SOURCE_RETAINED_TARGET_STOPS_V1',status='STOP_NO_FULL_THIRTY_TARGET_ADMISSION',target_stops=target_stops,valid_source_capture_years=list(captured),valid_target_years=list(years),artifacts=artifacts,historical_execution_authorized=False,financial_execution_authorized=False)
  write_artifact(output,'ALL_SOURCE_CAPTURES_RETAINED_TARGET_STOPS.json',c.canonical(stopped)+b'\n')
  raise ValueError('ORIGINAL_TARGET_PREPARATION_STOP_YEARS:'+','.join(target_stops))
 for name,raw in {'SOURCE_STAGE_AUTHORIZATION.json':source_go_raw,'SOURCE_INDEPENDENT_REVIEW.json':review_raw}.items():artifacts[name]=write_artifact(output,name,raw)
 prep=dict(schema=entry.PREPARATION_SCHEMA,status='PASS_SOURCE_TARGET_ONLY_NO_FINANCIAL_ADMISSION',candidate=config.CANDIDATE,adaptation_version=config.VERSION,tranche=entry.ALL30,
  ordered_cells=list(entry.tranche_cells(entry.ALL30)),years=years,cells=cells,code_manifest_SHA256=entry.code_identity(),scope_manifest_SHA256=entry.manifest_sha(),source_maps_SHA256=entry.source_map_identity(),
  source_stage_GO_SHA256=expected_source_go_sha256,source_review_SHA256=expected_review_sha256,artifacts=artifacts,source_only=True,
  historical_admission=False,financial_runs=0,accounts_created=0,accounts_advanced=0,provider_iterations=0,process_launches=0,canonical_claims_created=0,real_financial_GO_written=0,publication_actions=0)
 write_artifact(output,'PREPARATION.json',c.canonical(prep)+b'\n');return prep
