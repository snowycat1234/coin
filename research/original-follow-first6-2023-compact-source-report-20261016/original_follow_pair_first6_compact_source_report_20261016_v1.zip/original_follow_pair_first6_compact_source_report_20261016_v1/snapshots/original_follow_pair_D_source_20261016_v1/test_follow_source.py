import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import numpy as np
import numpy.testing
import follow_common as c
import follow_config as config
import follow_entry as entry
import follow_source as source
import follow_signal as signal
from follow_source_guard import SourceOnlyGuard,SourceBoundaryViolation

class SourceGeneratedChecks(unittest.TestCase):
 def fixture(self,year=2023):
  period=config.source_year(year);t=np.arange(config.utc('2020-01-02'),period['end'],config.DAY,dtype=np.int64);k=np.arange(len(t))
  p=100*np.exp(.001*k[:,None]+.08*np.sin(k[:,None]*np.arange(1,6)*.19));selected=t>=period['start']-20*config.DAY
  ht=t[selected];hc=p[selected];h=hc*1.015;l=hc*.985;r=np.ones(hc.shape,bool)
  for i in range(20,len(ht),11):h[i,0]=max(h[i-20:i,0].max()*1.2,h[i,0]);l[i,1]=min(l[i-20:i,1].min()*.8,l[i,1])
  return dict(prefix=dict(close_available_us=t,close=p),HLC=dict(available_us=ht,high=h,low=l,close=hc,ready=r))
 def test_exact_reviewed_pure_code_dependency(self):
  pure=signal.reviewed_signal();self.assertEqual(pure.VERSION,'ORIGINAL_FOLLOW_PAIR_INTRINSIC_LOWER_ONLY_GENERATED_V1');pure.originals()
 def test_generated_source_pair_and_targets_all_years(self):
  for year in (2021,2022,2023,2024,2025):
   fixture=self.fixture(year);self.assertTrue(source.validate_source_pair(year,fixture['prefix'],fixture['HLC']))
   arrays,proofs=source.project_targets(year,fixture);self.assertEqual(set(arrays),set(entry.array_specs(year)));self.assertEqual(len(proofs),config.source_year(year)['days'])
 def test_hlc_missing_readiness_or_changed_close_stops(self):
  fixture=self.fixture();fixture['HLC']['ready'][20,0]=False
  with self.assertRaisesRegex(ValueError,'FULL_COMPLETED'):source.validate_source_pair(2023,fixture['prefix'],fixture['HLC'])
  fixture=self.fixture();fixture['HLC']['close'][20,0]=np.nextafter(fixture['HLC']['close'][20,0],np.inf)
  with self.assertRaisesRegex(ValueError,'PARITY'):source.validate_source_pair(2023,fixture['prefix'],fixture['HLC'])
 def test_hlc_clock_dtype_envelope_shape(self):
  for key,change in (('available_us',lambda a:a+1),('high',lambda a:a.astype('float32')),('low',lambda a:np.zeros_like(a)),('ready',lambda a:a.astype('int64'))):
   fixture=self.fixture();fixture['HLC'][key]=change(fixture['HLC'][key])
   with self.assertRaises(ValueError):source.validate_hlc(2023,fixture['HLC'])
 def test_prefix_decode_exact_bytes_and_historical_nan_membership(self):
  fixture=self.fixture();prefix=fixture['prefix'];prefix['close'][0,2]=np.nan;pure=signal.reviewed_signal();n=len(prefix['close_available_us'])
  pin=dict(prefix_metadata=dict(selected_rows=n,last_source_clock_us=int(prefix['close_available_us'][-1]),first_source_clock_us=int(prefix['close_available_us'][0]),future_close_rows_interpreted=0,unselected_numerical_arrays_interpreted=False,prefix_first_row_retained=True,source_fields=['symbol_order','close_available_us','close'],clock_identity=pure.array_byte_identity(prefix['close_available_us']),close_identity=pure.array_byte_identity(prefix['close'])))
  decoded=source.decode_prefix(2023,source.blob(prefix),pin);np.testing.assert_array_equal(decoded['close'],prefix['close'])
  changed=copy.deepcopy(pin);changed['prefix_metadata']['close_identity']['raw_bytes_SHA256']='0'*64
  with self.assertRaisesRegex(ValueError,'RAW_BYTES'):source.decode_prefix(2023,source.blob(prefix),changed)
 def test_authority_requires_exact_fresh_review_and_go(self):
  with patch.object(entry,'code_identity',return_value='1'*64),patch.object(entry,'manifest_sha',return_value='2'*64),patch.object(entry,'source_map_identity',return_value='3'*64):
   review=c.canonical(entry.review_policy());rs=c.sha(review);go=c.canonical(entry.source_policy(rs));gs=c.sha(go)
   auth=entry.validate_source_authority_metadata(go,gs,review,rs);self.assertEqual(auth['policy']['ordered_cells'],entry.tranche_cells(entry.ALL30))
   for field in ('historical_execution_authorized','financial_execution_authorized','account_construction_authorized','downloads_authorized'):
    changed=c.exact_object(go);changed[field]=True;raw=c.canonical(changed)
    with self.assertRaises(ValueError):entry.validate_source_authority_metadata(raw,c.sha(raw),review,rs)
   with self.assertRaises(ValueError):entry.validate_source_authority_metadata(go,'0'*64,review,rs)
 def test_scope_never_minted_without_active_guard(self):
  with self.assertRaises(ValueError):entry.FollowPairSourcePreparationScope(b'',b'','0'*64,'0'*64,'0'*64,object(),object())
 def test_whole_guard_denies_network_process_and_unlisted_source_read(self):
  import socket,subprocess
  for action in (lambda:socket.create_connection(('example.invalid',443)),lambda:subprocess.run(['true']),lambda:(c.HERE/'not_allowlisted_market.npz').read_bytes()):
   guard=SourceOnlyGuard()
   with self.assertRaises(SourceBoundaryViolation):
    with guard:action()
   self.assertTrue(any(guard.attempts.values()));self.assertFalse(guard.active)
 def test_whole_guard_denies_finance_content_and_preserves_caught_attempt(self):
  guard=SourceOnlyGuard()
  with self.assertRaises(SourceBoundaryViolation):
   with guard:
    try:json.dumps(dict(schema='FINANCIAL_GO_V1',historical_execution_authorized=True))
    except SourceBoundaryViolation:pass
  self.assertEqual(guard.attempts['financial_GO_writes'],1)
 def test_no_later_calendar_or_renamed_recipe(self):
  with self.assertRaises(ValueError):config.source_year(2026)
  with self.assertRaises(ValueError):entry.tranche_cells('FIRST6')
  self.assertEqual(len(config.cells()),30)


class GuardedIntegrationGeneratedChecks(unittest.TestCase):
 fixture=SourceGeneratedChecks.fixture
 def test_all30_guarded_generated_preparation(self):
  import uuid
  root=c.HERE/'source_attempts'/('GENERATED_ONLY_'+uuid.uuid4().hex)
  fixtures={year:self.fixture(year) for year in (2023,2024,2025,2021,2022)}
  for fixture in fixtures.values():
   fixture.update(prefix_raw=source.blob(fixture['prefix']),HLC_provenance=dict(schema='GENERATED_REAL_HLC_SCHEMA_FIXTURE_V1',invented_for_engineering_only=True))
  with patch.object(entry,'code_identity',return_value='1'*64),patch.object(entry,'manifest_sha',return_value='2'*64),patch.object(entry,'source_map_identity',return_value='3'*64),patch.object(source,'capture_year',side_effect=lambda year,scope:fixtures[year]):
   review=c.canonical(entry.review_policy());rs=c.sha(review);go=c.canonical(entry.source_policy(rs));gs=c.sha(go)
   deps=c.exact_object(c.ordinary(c.HERE/'DEPENDENCY_PINS.json'))['files'];reads=[c.ROOT/name for name in deps]
   reads += [c.HERE/'DEPENDENCY_PINS.json']
   signal.reviewed_signal().originals()
   guard=SourceOnlyGuard(write_roots=(root,),read_paths=reads)
   with guard:
    prepared=source.prepare_source_only(root,source_go_raw=go,expected_source_go_sha256=gs,review_raw=review,expected_review_sha256=rs)
   self.assertEqual(len(prepared['cells']),30);self.assertFalse(entry._ACTIVE_SOURCE);self.assertFalse(any(guard.attempts.values()));self.assertEqual(len(prepared['years']),5)
   self.assertTrue((root/'PREPARATION.json').is_file())


class FinalBoundaryGeneratedChecks(unittest.TestCase):
 def test_selected_output_guard_denies_sibling_attempts(self):
  import uuid
  selected=c.HERE/'source_attempts'/('GENERATED_SELECTED_'+uuid.uuid4().hex)
  sibling=c.HERE/'source_attempts'/('GENERATED_SIBLING_'+uuid.uuid4().hex)
  sibling.mkdir();(sibling/'invented.txt').write_text('invented source fixture')
  for action in (lambda:(sibling/'invented.txt').read_bytes(),lambda:(sibling/'other.txt').write_text('denied')):
   guard=SourceOnlyGuard(write_roots=(selected,))
   with self.assertRaises(SourceBoundaryViolation):
    with guard:action()
   self.assertTrue(any(guard.attempts.values()))
 def test_final_receipt_uses_bounded_writer_and_includes_own_size(self):
  import uuid
  import prepare_follow_source as runner
  output=c.HERE/'source_attempts'/('GENERATED_FINAL_RECEIPT_'+uuid.uuid4().hex);output.mkdir();(output/'invented.bin').write_bytes(b'1234567')
  receipt=dict(schema='GENERATED_ONLY_FINAL_RECEIPT',status='PASS_GENERATED_ONLY',output_bytes=7)
  pin=runner.persist_final_receipt(output,'FINAL.json',receipt,include_own_size=True)
  actual=sum(p.stat().st_size for p in output.rglob('*') if p.is_file());self.assertEqual(receipt['output_bytes'],actual);self.assertEqual(pin['bytes'],(output/'FINAL.json').stat().st_size)
  stopped=dict(schema='GENERATED_ONLY_STOP',historical_execution_authorized=False,financial_execution_authorized=False)
  with patch.object(source,'write_artifact',side_effect=ValueError('SOURCE_OUTPUT_CAP_AND_DISK_FLOOR_REQUIRED')):
   with self.assertRaisesRegex(ValueError,'DISK_FLOOR'):runner.persist_final_receipt(output,'STOP.json',stopped)

if __name__=='__main__':unittest.main()
