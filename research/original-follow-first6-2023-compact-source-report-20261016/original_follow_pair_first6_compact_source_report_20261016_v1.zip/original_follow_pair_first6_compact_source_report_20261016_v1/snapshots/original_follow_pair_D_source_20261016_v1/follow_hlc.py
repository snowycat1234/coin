"""Genuine trade-HLC projection, with no filesystem or financial entry point.

All source bytes enter through a caller-issued exact scoped callback. Pure byte
parsers below are intentionally usable with generated fixtures; they confer no
source admission, launch permission, historical arrival or financial authority.
"""
from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from io import BytesIO, StringIO
import csv
import hashlib
import math
import re
import stat
import zipfile
import numpy as np

SYMBOLS = ('BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'XRPUSDT', 'DOGEUSDT')
DAY = 86_400_000_000
MINUTE = 60_000_000
SCHEMA = 'ORIGINAL_FOLLOW_PAIR_GENUINE_TRADE_HLC_SOURCE_CONTRACT_V1'
COLUMNS = ('timestamp_ms', 'open', 'high', 'low', 'close', 'volume', 'close_time_ms',
           'quote_volume', 'trades', 'taker_buy_volume', 'taker_buy_quote_volume', 'ignore')
ALIASES = ({'timestamp_ms', 'open_time', 'open_time_ms', 'open_timestamp'}, {'open'}, {'high'}, {'low'},
           {'close'}, {'volume'}, {'close_time', 'close_timestamp', 'close_time_ms'},
           {'quote_volume', 'quote_asset_volume'}, {'count', 'trades', 'number_of_trades'},
           {'taker_buy_volume', 'taker_buy_base_asset_volume'},
           {'taker_buy_quote_volume', 'taker_buy_quote_asset_volume'}, {'ignore'})
PURPOSES = {'GENUINE_TRADE_HLC_CAPTURE', 'GENUINE_TRADE_HLC_ARCHIVE',
            'GENUINE_TRADE_HLC_WRAPPER', 'GENUINE_TRADE_HLC_SPLIT_PART'}
CSV_CAP = 64 * 1024 * 1024
ARCHIVE_CAP = 16 * 1024 * 1024
WRAPPER_CAP = 128 * 1024 * 1024
CAPTURE_CAP = 2 * 1024 * 1024
SPLIT_PART_CAP = 2 * 1024 * 1024
POLICIES = ('IDENTICAL_NUMERIC_ALLOWED', 'IDENTICAL_TEXT_ALLOWED', 'FORBID_ALL')


class HLCSourceStop(ValueError):
    """Fail closed before any partial daily value can become a feature."""


def require(condition, message):
    if not condition:
        raise HLCSourceStop(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def immutable(a):
    a = np.asarray(a)
    require(a.dtype in (np.dtype('int64'), np.dtype('float64'), np.dtype('bool')),
            'PLAIN_NATIVE_INT64_FLOAT64_BOOL_REQUIRED')
    return np.frombuffer(a.tobytes(order='C'), dtype=a.dtype).reshape(a.shape)


def period_bounds(period):
    require(type(period) is str and re.fullmatch(r'202[1-5]-(?:0[1-9]|1[0-2])(?:-(?:0[1-9]|[12][0-9]|3[01]))?', period),
            'EXACT_DEV_MONTH_OR_DAY_REQUIRED_HOLDOUT_CLOSED')
    try:
        left = datetime.fromisoformat(period + ('-01' if len(period) == 7 else '')).replace(tzinfo=timezone.utc)
    except ValueError as exc:
        raise HLCSourceStop('EXACT_VALID_UTC_PERIOD_REQUIRED') from exc
    right = (left.replace(year=left.year + 1, month=1) if left.month == 12
             else left.replace(month=left.month + 1)) if len(period) == 7 else left + timedelta(days=1)
    return int(left.timestamp()) * 1_000_000, int(right.timestamp()) * 1_000_000


def year_bounds(year):
    require(type(year) is int and year in (2021, 2022, 2023, 2024, 2025),
            'EXACT_FIVE_DEV_PERIODS_REQUIRED_HOLDOUT_CLOSED')
    start = datetime(year, 4, 2, tzinfo=timezone.utc) if year == 2021 else datetime(year, 1, 1, tzinfo=timezone.utc)
    end = datetime(year + 1, 1, 1, tzinfo=timezone.utc)
    return int(start.timestamp()) * 1_000_000, int(end.timestamp()) * 1_000_000


def regular_member(info):
    mode = info.external_attr >> 16
    require(not info.is_dir() and not (info.flag_bits & 1) and not stat.S_ISLNK(mode)
            and (stat.S_IFMT(mode) in (0, stat.S_IFREG)), 'REGULAR_UNENCRYPTED_SOURCE_MEMBER_REQUIRED')


def member_metadata(info):
    return dict(member=info.filename, bytes=info.file_size, compressed_bytes=info.compress_size,
                CRC=info.CRC, compression=info.compress_type, header_offset=info.header_offset,
                encrypted=bool(info.flag_bits & 1), regular=not info.is_dir() and not stat.S_ISLNK(info.external_attr >> 16))


def validate_member_pin(info, expected):
    actual = member_metadata(info)
    for key, value in (expected or {}).items():
        if key in actual:
            require(type(value) is type(actual[key]) and value == actual[key], 'EXACT_SELECTED_SOURCE_MEMBER_METADATA_REQUIRED:' + key)
    return actual


def selected_wrapper_member(raw, *, member, expected_metadata=None):
    """Only selected original ZIP bytes are decompressed; never whole testzip."""
    require(type(raw) is bytes and type(member) is str and member and not member.startswith('/')
            and '\\' not in member and all(x not in ('', '.', '..') for x in member.split('/'))
            and '/klines/' in '/' + member, 'EXACT_GENUINE_TRADE_WRAPPER_MEMBER_REQUIRED')
    try:
        with zipfile.ZipFile(BytesIO(raw)) as archive:
            names = archive.namelist()
            require(len(names) == len(set(names)), 'DUPLICATE_WRAPPER_MEMBER_FORBIDDEN')
            matches = [i for i in archive.infolist() if i.filename == member]
            require(len(matches) == 1, 'EXACT_SELECTED_WRAPPER_MEMBER_REQUIRED')
            info = matches[0]
            regular_member(info)
            require(0 < info.file_size <= ARCHIVE_CAP, 'SELECTED_ORIGINAL_ZIP_SIZE_CAP')
            metadata = validate_member_pin(info, expected_metadata)
            body = archive.read(info)
    except (zipfile.BadZipFile, RuntimeError, EOFError, OSError) as exc:
        raise HLCSourceStop('SELECTED_WRAPPER_CRC_OR_ARCHIVE_FAILURE') from exc
    return body, metadata


@dataclass(frozen=True)
class ParsedTrade:
    symbol: str
    period: str
    open_us: np.ndarray
    values: np.ndarray  # all twelve numeric source columns, never projected before validation
    provenance: dict


def parse_original_trade_zip(raw, *, symbol, period, family='klines',
                             duplicate_policy='IDENTICAL_NUMERIC_ALLOWED', expected_csv_member=None,
                             expected_csv_sha256=None, expected_csv_bytes=None, expected_inner_metadata=None):
    """Strict actual twelve-column klines parser. MARK is never a substitute."""
    require(symbol in SYMBOLS and family == 'klines', 'EXACT_CORE5_GENUINE_TRADE_KLINES_REQUIRED_NO_MARK')
    require(duplicate_policy in POLICIES, 'EXACT_SOURCE_DUPLICATE_POLICY_REQUIRED')
    require(type(raw) is bytes and 0 < len(raw) <= ARCHIVE_CAP, 'BOUNDED_ORIGINAL_TRADE_ZIP_BYTES_REQUIRED')
    left, right = period_bounds(period)
    expected = f'{symbol}-1m-{period}.csv'
    require(expected_csv_member is None or expected_csv_member == expected, 'EXACT_ORIGINAL_TRADE_CSV_BASENAME_REQUIRED')
    try:
        with zipfile.ZipFile(BytesIO(raw)) as archive:
            infos = archive.infolist()
            require(len(infos) == 1 and infos[0].filename == expected, 'EXACT_SINGLE_ORIGINAL_TRADE_CSV_REQUIRED')
            info = infos[0]
            regular_member(info)
            require(0 < info.file_size <= CSV_CAP, 'ORIGINAL_CSV_SIZE_CAP')
            metadata = validate_member_pin(info, expected_inner_metadata)
            source = archive.read(info)
    except (zipfile.BadZipFile, RuntimeError, EOFError, OSError) as exc:
        raise HLCSourceStop('ORIGINAL_TRADE_CRC_OR_ARCHIVE_FAILURE') from exc
    require(expected_csv_bytes is None or len(source) == expected_csv_bytes, 'EXACT_ORIGINAL_CSV_BYTE_COUNT_REQUIRED')
    require(expected_csv_sha256 is None or sha(source) == expected_csv_sha256, 'EXACT_ORIGINAL_CSV_HASH_REQUIRED')
    try:
        text = source.decode('utf-8-sig')
    except UnicodeError as exc:
        raise HLCSourceStop('ORIGINAL_SOURCE_UTF8_REQUIRED') from exc
    rows = {}
    header = False
    duplicates = 0
    raw_rows = 0
    try:
        for index, row in enumerate(csv.reader(StringIO(text), strict=True)):
            require(len(row) == 12, 'EXACT_ORIGINAL_TWELVE_SOURCE_COLUMNS_REQUIRED')
            names = tuple(x.strip().lower().replace(' ', '_') for x in row)
            if index == 0 and names[0] in ALIASES[0]:
                require(all(name in accepted for name, accepted in zip(names, ALIASES)), 'EXACT_RECOGNIZED_UNREORDERED_SOURCE_HEADER_REQUIRED')
                header = True
                continue
            require(re.fullmatch(r'[0-9]+', row[0]) is not None and re.fullmatch(r'[0-9]+', row[6]) is not None,
                    'INTEGER_ORIGINAL_MILLISECOND_CLOCK_REQUIRED')
            opened_ms, closed_ms = int(row[0]), int(row[6])
            opened = opened_ms * 1000
            require(left <= opened < right and opened % MINUTE == 0 and closed_ms == opened_ms + 59999,
                    'EXACT_RAW_OPEN_INCLUSIVE_CLOSE_MAPPING_REQUIRED')
            try:
                values = tuple(float(x) for x in row)
            except (ValueError, OverflowError) as exc:
                raise HLCSourceStop('EXACT_NUMERIC_ORIGINAL_SOURCE_ROW_REQUIRED') from exc
            require(all(math.isfinite(x) for x in values), 'FINITE_ALL_TWELVE_ORIGINAL_SOURCE_FIELDS_REQUIRED')
            require(all(values[k] > 0 for k in (1, 2, 3, 4))
                    and values[3] <= min(values[1], values[4])
                    and values[2] >= max(values[1], values[4]) and values[3] <= values[2], 'FINITE_GENUINE_SOURCE_OHLC_ENVELOPE_REQUIRED')
            require(all(values[k] >= 0 for k in (5, 7, 8, 9, 10)) and values[8].is_integer(),
                    'NONNEGATIVE_GENUINE_TRADE_VOLUME_INTEGER_COUNT_REQUIRED')
            raw_rows += 1
            if opened in rows:
                require(duplicate_policy != 'FORBID_ALL', 'ORIGINAL_DUPLICATE_ROWS_FORBIDDEN')
                previous, original_text = rows[opened]
                equal = tuple(row) == original_text if duplicate_policy == 'IDENTICAL_TEXT_ALLOWED' else values == previous
                require(equal, 'CONFLICTING_DUPLICATE_ORIGINAL_SOURCE_ROW')
                duplicates += 1
            else:
                rows[opened] = (values, tuple(row))
    except csv.Error as exc:
        raise HLCSourceStop('STRICT_ORIGINAL_SOURCE_CSV_REQUIRED') from exc
    require(bool(rows), 'NONEMPTY_ORIGINAL_SOURCE_ROWS_REQUIRED')
    clocks = np.array(sorted(rows), dtype=np.int64)
    values = np.array([rows[int(at)][0] for at in clocks], dtype=np.float64)
    provenance = dict(symbol=symbol, period=period, family='klines', ZIP_SHA256=sha(raw), ZIP_bytes=len(raw),
                      CSV_SHA256=sha(source), CSV_bytes=len(source), CSV_member=expected, inner_metadata=metadata,
                      header_present=header, raw_rows=raw_rows, numeric_rows=len(clocks),
                      identical_duplicates_removed=duplicates, duplicate_policy=duplicate_policy,
                      actual_first_open_us=int(clocks[0]), actual_last_open_us=int(clocks[-1]),
                      completion_clock='(actual_close_time_ms+1)*1000', historical_arrival_certified=False)
    return ParsedTrade(symbol, period, immutable(clocks), immutable(values), provenance)


def repair_original_month(month, repairs, *, expected_missing_open_ms, expected_union_missing_open_ms=()):
    """Original monthly priority; genuine daily rows fill only original absences."""
    require(isinstance(month, ParsedTrade) and len(month.period) == 7, 'ORIGINAL_MONTHLY_TRADE_REQUIRED')
    left, right = period_bounds(month.period)
    grid = np.arange(left, right, MINUTE, dtype=np.int64)
    absent = set(map(int, np.setdiff1d(grid, month.open_us)))
    require(absent == {int(x) * 1000 for x in expected_missing_open_ms}, 'EXACT_ORIGINAL_TRADE_ABSENCE_MASK_REQUIRED')
    rows = {int(at): row for at, row in zip(month.open_us, month.values)}
    proof = []
    for daily, expected_added in repairs:
        require(isinstance(daily, ParsedTrade) and daily.symbol == month.symbol and len(daily.period) == 10
                and daily.period[:7] == month.period and type(expected_added) is int and expected_added >= 0,
                'EXACT_GENUINE_DAILY_SAME_MONTH_REPAIR_REQUIRED')
        added = 0
        for at, row in zip(daily.open_us, daily.values):
            at = int(at)
            if at not in absent:
                continue
            if at in rows:
                require(np.array_equal(rows[at], row), 'CONFLICTING_GENUINE_REPAIR_SOURCE')
            else:
                rows[at] = row
                added += 1
        require(added == expected_added, 'EXACT_GENUINE_DAILY_ADDED_MINUTES_REQUIRED')
        proof.append(dict(**daily.provenance, genuine_added_asset_minutes=added,
                          priority='ONLY_FILL_ORIGINALLY_ABSENT_CLOCKS'))
    missing = set(map(int, grid)) - set(rows)
    require(missing == {int(x) * 1000 for x in expected_union_missing_open_ms}, 'EXACT_UNION_TRADE_ABSENCE_MASK_REQUIRED')
    require(not missing, 'NO_GENUINE_TRADE_MINUTE_GAPS_ADMITTED')
    ordered = np.array(sorted(rows), dtype=np.int64)
    values = np.asarray([rows[int(at)] for at in ordered], dtype=np.float64)
    provenance = dict(month.provenance, genuine_daily_repairs=proof, original_missing_minutes=len(absent),
                      union_missing_minutes=0, original_monthly_has_priority=True,
                      mark_substitution=False, synthetic_extrema=False)
    return ParsedTrade(month.symbol, month.period, immutable(ordered), immutable(values), provenance)


def aggregate_trade_daily(parsed):
    require(isinstance(parsed, ParsedTrade), 'VALIDATED_GENUINE_TRADE_ROWS_REQUIRED')
    left, right = period_bounds(parsed.period)
    expected = np.arange(left, right, MINUTE, dtype=np.int64)
    require(np.array_equal(parsed.open_us, expected), 'COMPLETE_ACTUAL_1440_MINUTE_DAILY_GRID_REQUIRED')
    days = (right - left) // DAY
    require(days > 0 and len(expected) == days * 1440 and parsed.values.shape == (len(expected), 12),
            'COMPLETE_UTC_DAILY_SOURCE_SHAPE_REQUIRED')
    v = parsed.values
    available = ((v[1439::1440, 6].astype(np.int64) + 1) * 1000).astype(np.int64)
    require(np.array_equal(available, np.arange(left + DAY, right + DAY, DAY, dtype=np.int64)),
            'DAILY_AVAILABILITY_FROM_ACTUAL_FINAL_MINUTE_CLOSE_TIME_REQUIRED')
    return dict(available_us=immutable(available), high=immutable(v[:, 2].reshape(days, 1440).max(axis=1)),
                low=immutable(v[:, 3].reshape(days, 1440).min(axis=1)),
                close=immutable(v[1439::1440, 4]), ready=immutable(np.ones(days, dtype=bool)))


def decode_qualified_daily_capture(raw, *, expected_start_us, expected_end_us):
    """Only the already-qualified full-2021 genuine OHLC capture is reusable."""
    require(type(raw) is bytes, 'EXACT_CAPTURE_BYTES_REQUIRED')
    fields = {'available_us', 'symbol_order', 'ready', 'open', 'high', 'low', 'close', 'volume', 'quote_volume'}
    try:
        with zipfile.ZipFile(BytesIO(raw)) as archive:
            infos = archive.infolist()
            require({i.filename for i in infos} == {k + '.npy' for k in fields} and len(infos) == len(fields),
                    'EXACT_QUALIFIED_DAILY_OHLC_CAPTURE_NAMESPACE_REQUIRED')
            n=(expected_end_us-expected_start_us)//DAY
            require(type(expected_start_us) is int and type(expected_end_us) is int and expected_end_us>expected_start_us and expected_start_us%DAY==expected_end_us%DAY==0 and n<=366, 'EXACT_BOUNDED_DAILY_CAPTURE_CALENDAR_REQUIRED')
            for info in infos:
                regular_member(info)
                require(0 < info.file_size <= CAPTURE_CAP, 'DAILY_CAPTURE_MEMBER_SIZE_CAP')
                key=info.filename[:-4]
                with archive.open(info) as stream:
                    version=np.lib.format.read_magic(stream)
                    require(version in ((1,0),(2,0)), 'EXACT_SUPPORTED_CAPTURE_NPY_VERSION_REQUIRED')
                    reader=np.lib.format.read_array_header_1_0 if version==(1,0) else np.lib.format.read_array_header_2_0
                    shape,fortran,dtype=reader(stream,max_header_size=4096)
                    expected_shape=(5,) if key=='symbol_order' else (n,) if key=='available_us' else (n,5)
                    wanted_dtype='bool' if key=='ready' else 'int64' if key=='available_us' else 'float64'
                    valid_dtype=(dtype.kind=='U' and 0<dtype.itemsize<=128) if key=='symbol_order' else dtype==np.dtype(wanted_dtype)
                    require(shape==expected_shape and not fortran and dtype.fields is None and dtype.subdtype is None and not dtype.hasobject and valid_dtype, 'EXACT_BOUNDED_CAPTURE_NPY_HEADER_REQUIRED')
                    require(stream.tell()+int(np.prod(shape))*dtype.itemsize==info.file_size, 'EXACT_CAPTURE_NPY_PAYLOAD_LENGTH_REQUIRED')
        with np.load(BytesIO(raw), allow_pickle=False) as source:
            require(set(source.files) == fields, 'EXACT_QUALIFIED_DAILY_OHLC_CAPTURE_FIELDS_REQUIRED')
            symbols = source['symbol_order']
            require(symbols.dtype.kind == 'U' and symbols.shape == (5,) and tuple(symbols.tolist()) == SYMBOLS,
                    'EXACT_QUALIFIED_CAPTURE_SYMBOL_ORDER_REQUIRED')
            times = source['available_us']
            expected = np.arange(expected_start_us + DAY, expected_end_us + DAY, DAY, dtype=np.int64)
            require(times.dtype == np.dtype('int64') and np.array_equal(times, expected), 'EXACT_QUALIFIED_CAPTURE_DAILY_CLOCK_REQUIRED')
            arrays = {key: source[key] for key in fields - {'symbol_order', 'available_us'}}
            require(all(a.shape == (len(expected), 5) for a in arrays.values()), 'EXACT_QUALIFIED_CAPTURE_CORE5_SHAPES_REQUIRED')
            require(arrays['ready'].dtype == np.dtype('bool') and arrays['ready'].all(), 'ALL_QUALIFIED_GENUINE_DAYS_READY_REQUIRED')
            for key in ('open', 'high', 'low', 'close', 'volume', 'quote_volume'):
                a = arrays[key]
                require(a.dtype == np.dtype('float64') and np.isfinite(a).all(), 'FINITE_FLOAT64_GENUINE_CAPTURE_REQUIRED')
                require(np.all(a > 0) if key in ('open', 'high', 'low', 'close') else np.all(a >= 0),
                        'POSITIVE_GENUINE_CAPTURE_PRICES_NONNEGATIVE_VOLUME_REQUIRED')
            require(np.all(arrays['low'] <= np.minimum(arrays['open'], arrays['close']))
                    and np.all(arrays['high'] >= np.maximum(arrays['open'], arrays['close']))
                    and np.all(arrays['low'] <= arrays['high']), 'GENUINE_CAPTURE_OHLC_ENVELOPE_REQUIRED')
            return {key: immutable(value) for key, value in dict(available_us=times,
                    **{k: arrays[k] for k in ('high', 'low', 'close', 'ready')}).items()}
    except (zipfile.BadZipFile, EOFError, OSError, TypeError) as exc:
        raise HLCSourceStop('QUALIFIED_DAILY_CAPTURE_DECODE_FAILURE') from exc


def _checked_read(year, pin, read_source, allowed):
    require(type(pin) is dict and set(('path', 'SHA256', 'bytes', 'purpose')).issubset(pin), 'EXACT_SCOPED_SOURCE_READ_PIN_REQUIRED')
    identity = tuple(pin[k] for k in ('path', 'SHA256', 'bytes', 'purpose'))
    require(identity in allowed and pin['purpose'] in PURPOSES, 'EXACT_YEAR_PURPOSE_ALLOWLIST_REQUIRED')
    require(type(pin['path']) is str and not pin['path'].startswith('/') and '\\' not in pin['path']
            and ':' not in pin['path'] and all(p not in ('', '.', '..') for p in pin['path'].split('/'))
            and type(pin['SHA256']) is str and re.fullmatch('[0-9a-f]{64}', pin['SHA256'])
            and type(pin['bytes']) is int and pin['bytes'] > 0, 'EXACT_ORDINARY_SOURCE_FILE_PIN_REQUIRED')
    caps = dict(GENUINE_TRADE_HLC_CAPTURE=CAPTURE_CAP, GENUINE_TRADE_HLC_ARCHIVE=ARCHIVE_CAP,
                GENUINE_TRADE_HLC_WRAPPER=WRAPPER_CAP, GENUINE_TRADE_HLC_SPLIT_PART=SPLIT_PART_CAP)
    require(pin['bytes'] <= caps[pin['purpose']], 'EXACT_PURPOSE_SOURCE_BYTE_CAP_REQUIRED')
    raw = read_source(year, *identity)
    require(type(raw) is bytes and len(raw) == pin['bytes'] and sha(raw) == pin['SHA256'], 'EXACT_SCOPED_SOURCE_BYTES_REQUIRED')
    return raw


def _original_stream_bytes(year, stream, read_source, allowed, wrapper_cache):
    require(stream.get('family') == 'klines' and stream.get('symbol') in SYMBOLS,
            'ONLY_GENUINE_TRADE_SOURCE_STREAMS_ALLOWED')
    kind = stream.get('transport')
    transport = {}
    if kind == 'DIRECT':
        raw = _checked_read(year, stream['read_file'], read_source, allowed)
    elif kind == 'WRAPPER_MEMBER':
        pin = stream['read_file']
        key = tuple(pin[k] for k in ('path', 'SHA256', 'bytes', 'purpose'))
        if key not in wrapper_cache:
            wrapper_cache.clear()
            wrapper_cache[key] = _checked_read(year, pin, read_source, allowed)
        raw, selected = selected_wrapper_member(wrapper_cache[key], member=stream['member'],
                       expected_metadata=stream.get('outer_metadata'))
        transport = dict(wrapper=dict(pin), selected_outer_member=selected)
    elif kind == 'SPLIT_PARTS':
        parts = []
        offset = 0
        require(bool(stream.get('parts')), 'EXACT_ORDERED_SPLIT_SOURCE_PARTS_REQUIRED')
        for part in stream['parts']:
            require(part.get('offset') == offset, 'EXACT_CONTIGUOUS_SPLIT_PART_OFFSETS_REQUIRED')
            pin = part.get('read_file', part)
            block = _checked_read(year, pin, read_source, allowed)
            parts.append(block)
            offset += len(block)
        raw = b''.join(parts)
        transport = dict(parts=stream['parts'], reassembled_in_memory_only=True)
    else:
        raise HLCSourceStop('EXACT_SOURCE_TRANSPORT_REQUIRED')
    require(len(raw) == stream['ZIP_bytes'] and sha(raw) == stream['ZIP_SHA256'], 'EXACT_ORIGINAL_TRADE_ZIP_IDENTITY_REQUIRED')
    return raw, transport


def _parse_stream(year, stream, read_source, allowed, wrapper_cache):
    raw, transport = _original_stream_bytes(year, stream, read_source, allowed, wrapper_cache)
    parsed = parse_original_trade_zip(raw, symbol=stream['symbol'], period=stream['period'],
            family=stream['family'], duplicate_policy=stream.get('duplicate_policy',
            'FORBID_ALL' if stream['period'].startswith('2025-') else 'IDENTICAL_TEXT_ALLOWED'
            if stream['period'].startswith('2022-') else 'IDENTICAL_NUMERIC_ALLOWED'),
            expected_csv_member=stream.get('CSV_member'), expected_csv_sha256=stream.get('CSV_SHA256'),
            expected_csv_bytes=stream.get('CSV_bytes'), expected_inner_metadata=stream.get('inner_metadata'))
    return ParsedTrade(parsed.symbol, parsed.period, parsed.open_us, parsed.values,
                       dict(parsed.provenance, transport=transport, source_lineage=stream))


def validate_daily_hlc(arrays, *, year):
    start, end = year_bounds(year)
    expected = np.arange(start - 20 * DAY, end, DAY, dtype=np.int64)
    require(type(arrays) is dict and set(arrays) == {'available_us', 'high', 'low', 'close', 'ready'}, 'EXACT_DAILY_HLC_ARRAY_NAMESPACE_REQUIRED')
    t = arrays['available_us']
    require(isinstance(t, np.ndarray) and t.dtype == np.dtype('int64') and np.array_equal(t, expected),
            'EXACT_DECISION_MINUS20_THROUGH_LAST_DECISION_HLC_CLOCK_REQUIRED')
    shape = (len(expected), 5)
    for field in ('high', 'low', 'close'):
        a = arrays[field]
        require(isinstance(a, np.ndarray) and a.dtype == np.dtype('float64') and a.shape == shape
                and np.isfinite(a).all() and np.all(a > 0), 'FINITE_FLOAT64_COMPLETE_HLC_SHAPE_REQUIRED')
    ready = arrays['ready']
    require(isinstance(ready, np.ndarray) and ready.dtype == np.dtype('bool') and ready.shape == shape and ready.all(),
            'ALL_REQUIRED_GENUINE_DAILY_HLC_CELLS_READY_REQUIRED')
    require(np.all(arrays['low'] <= arrays['close']) and np.all(arrays['close'] <= arrays['high']), 'DAILY_GENUINE_HLC_ENVELOPE_REQUIRED')
    return arrays


def capture_year_hlc(year, read_source, *, contract_map):
    """No source path is opened here; the root owns fresh review/GO and reads."""
    start, end = year_bounds(year)
    require(callable(read_source) and type(contract_map) is dict, 'CALLER_SCOPED_READ_CALLBACK_AND_CONTRACT_REQUIRED')
    require(contract_map.get('schema') == 'ORIGINAL_FOLLOW_PAIR_GENUINE_TRADE_HLC_SOURCE_CONTRACT_MAP_V1' and contract_map.get('symbol_order') == list(SYMBOLS), 'EXACT_FIVE_PERIOD_GENUINE_TRADE_HLC_CONTRACT_MAP_REQUIRED')
    contract = contract_map['years'][str(year)]
    require(contract['decision_start_us'] == start and contract['decision_end_exclusive_us'] == end
            and contract['first_available_us'] == start - 20 * DAY and contract['last_available_us'] == end - DAY,
            'EXACT_FROZEN_HLC_SOURCE_YEAR_BOUNDS_REQUIRED')
    pins = contract_map['read_files'][str(year)]
    allowed = {tuple(pin[k] for k in ('path', 'SHA256', 'bytes', 'purpose')) for pin in pins}
    require(len(allowed) == len(pins), 'UNIQUE_YEAR_SOURCE_READ_FILES_REQUIRED')
    expected = np.arange(start - 20 * DAY, end, DAY, dtype=np.int64)
    values = {name: np.full((len(expected), 5), np.nan, dtype=np.float64) for name in ('high', 'low', 'close')}
    ready = np.zeros((len(expected), 5), dtype=bool)
    origins = []
    def add(daily, symbols, origin):
        t = daily['available_us']
        for i, at in enumerate(t):
            if int(at) < int(expected[0]) or int(at) > int(expected[-1]):
                continue
            k = int((int(at) - int(expected[0])) // DAY)
            require(int(expected[k]) == int(at), 'EXACT_DAILY_SOURCE_AVAILABILITY_ALIGNMENT_REQUIRED')
            for j, symbol in enumerate(symbols):
                dest = SYMBOLS.index(symbol)
                require(not ready[k, dest], 'DUPLICATE_DAILY_HLC_ORIGIN_FORBIDDEN')
                ok = daily['ready'][i, j] if daily['ready'].ndim == 2 else daily['ready'][i]
                require(bool(ok), 'UNREADY_GENUINE_DAILY_HLC_FORBIDDEN')
                for field in ('high', 'low', 'close'):
                    a = daily[field]
                    values[field][k, dest] = a[i, j] if a.ndim == 2 else a[i]
                ready[k, dest] = True
        origins.append(origin)
    for capture in contract.get('captures', []):
        raw = _checked_read(year, capture.get('read_file', capture), read_source, allowed)
        daily = decode_qualified_daily_capture(raw, expected_start_us=capture['calendar_start_us'], expected_end_us=capture['calendar_end_us'])
        add(daily, SYMBOLS, dict(kind='REUSE_QUALIFIED_GENUINE_DAILY_OHLC', file=capture,
                               exact_file_SHA256=sha(raw), historical_arrival_certified=False))
    wrapper_cache = {}
    declared_streams = contract.get('streams', [])
    require(all(s.get('frequency') in ('MONTHLY','DAILY_REPAIR') for s in declared_streams), 'EXACT_MONTHLY_OR_GENUINE_DAILY_REPAIR_SOURCE_REQUIRED')
    by_id = {s['stream_id']:s for s in declared_streams}
    require(len(by_id)==len(declared_streams), 'UNIQUE_DECLARED_GENUINE_STREAM_IDENTITIES_REQUIRED')
    streams = [s for s in declared_streams if s.get('frequency')=='MONTHLY']
    referenced_repairs={r['stream_id'] for s in streams for r in s.get('repairs',[])}
    require(referenced_repairs=={s['stream_id'] for s in declared_streams if s.get('frequency')=='DAILY_REPAIR'}, 'EXACT_REFERENCED_GENUINE_DAILY_REPAIR_SET_REQUIRED')
    # Group exact wrapper members so each opaque wrapper is held/read once.
    order = lambda s: (s.get('read_file', {}).get('path', '') if s.get('transport') == 'WRAPPER_MEMBER' else '', s['period'], s['symbol'])
    for stream in sorted(streams, key=order):
        require(stream.get('frequency', 'MONTHLY') == 'MONTHLY', 'TOP_LEVEL_GENUINE_MONTHLY_STREAM_REQUIRED')
        parsed = _parse_stream(year, stream, read_source, allowed, wrapper_cache)
        repairs = []
        for repair_ref in stream.get('repairs', []):
            require(set(repair_ref)=={'stream_id','expected_genuine_added_asset_minutes','priority'} and repair_ref['stream_id'] in by_id, 'EXACT_GENUINE_DAILY_REPAIR_REFERENCE_REQUIRED')
            repair=by_id[repair_ref['stream_id']]
            require(repair['frequency']=='DAILY_REPAIR' and repair['symbol']==stream['symbol'] and repair['period'][:7]==stream['period'], 'EXACT_SAME_SYMBOL_MONTH_DAILY_REPAIR_REQUIRED')
            daily = _parse_stream(year, repair, read_source, allowed, wrapper_cache)
            # Each genuine daily repair must itself contain its complete UTC day.
            aggregate_trade_daily(daily)
            repairs.append((daily, repair_ref['expected_genuine_added_asset_minutes']))
        parsed = repair_original_month(parsed, repairs,
                 expected_missing_open_ms=stream.get('expected_missing_open_ms', []),
                 expected_union_missing_open_ms=stream.get('expected_union_missing_open_ms', []))
        add(aggregate_trade_daily(parsed), (parsed.symbol,), parsed.provenance)
    arrays = dict(available_us=immutable(expected), **{key: immutable(value) for key, value in values.items()}, ready=immutable(ready))
    validate_daily_hlc(arrays, year=year)
    provenance = dict(schema='ORIGINAL_FOLLOW_PAIR_GENUINE_TRADE_HLC_CAPTURE_V1', year=year,
        symbol_order=list(SYMBOLS), first_available_us=int(expected[0]), last_available_us=int(expected[-1]),
        decision_start_us=start, decision_end_exclusive_us=end, completed_days=len(expected),
        complete_cells=int(ready.sum()), source_origins=origins,
        per_decision_availability=[dict(decision_us=at, oldest_completed_HLC_available_us=at-20*DAY,
                                        latest_completed_HLC_available_us=at, available_by_decision=True)
                                   for at in range(start, end, DAY)],
        daily_high='max(actual minute high)', daily_low='min(actual minute low)', daily_close='last actual minute close',
        daily_available_us='(actual final minute close_time_ms+1)*1000',
        source_completion_is_not_arrival_certification=True, historical_arrival_certified=False,
        mark_substitution=False, close_or_open_synthesized_extrema=False, forward_fill=False,
        source_admitted=False, financial_authorized=False)
    return dict(arrays=arrays, provenance=provenance)
