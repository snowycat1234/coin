"""Freeze code/metadata only. Never reads market sources or creates authority."""
from pathlib import Path
import json
import hashlib
import follow_common as c
import follow_config as config
import follow_entry as entry

HERE=Path(__file__).absolute().parent

def run():
 fixed=dict(schema=config.VERSION,candidate=config.CANDIDATE,cell_count=30,cells=list(config.cells()),source_checkpoint=entry.ALL30,source_enabled_cells=[v['cell_id'] for v in config.cells()],financial_entry_implemented=False,original_execution_replication=False,financial_reuse_allowed=False)
 (HERE/'FROZEN_THIRTY_CELL_MANIFEST.json').write_text(json.dumps(fixed,sort_keys=True,indent=2)+'\n')
 files={}
 for p in sorted(HERE.iterdir()):
  if p.is_file() and p.name!='CODE_MANIFEST.json' and p.suffix in ('.py','.json','.md','.txt'):
   raw=p.read_bytes();files[p.name]=dict(bytes=len(raw),SHA256=hashlib.sha256(raw).hexdigest())
 deps=c.exact_object(c.ordinary(HERE/'DEPENDENCY_PINS.json'))['files']
 manifest=dict(schema='FOLLOW_PAIR_ALL30_SOURCE_ONLY_CODE_IDENTITY_V1',files=files,dependencies=deps,financial_entry_implemented=False,source_GO_granted=False,financial_GO_granted=False)
 (HERE/'CODE_MANIFEST.json').write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n')
 print(json.dumps(dict(status='FROZEN_CODE_METADATA_ONLY',code_manifest_SHA256=entry.code_identity(),scope_manifest_SHA256=entry.manifest_sha(),source_maps_SHA256=entry.source_map_identity(),cells=30,source_runs=0,financial_runs=0)))

if __name__=='__main__':run()
