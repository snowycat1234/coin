"""Fresh30-cell SOURCE-only authority. There is no financial authority type."""
from contextlib import contextmanager
from dataclasses import dataclass,field
from pathlib import Path
import follow_common as c
import follow_config as config

ALL30='ALL30_FIVE_DEV_PERIODS_ORIGINAL_FOLLOW_PAIR_ALL_THREE_TIERS'
SOURCE_SCHEMA='ROOT_SOURCE_TARGET_FOLLOW_PAIR_INTRINSIC_ALL30_V1'
SOURCE_REVIEW_SCHEMA='INDEPENDENT_FOLLOW_PAIR_ALL30_SOURCE_GENERATED_REVIEW_V1'
PREPARATION_SCHEMA='PREPARED_FOLLOW_PAIR_ALL30_SOURCE_TARGET_ONLY_V1'
PURE_MANIFEST_SHA256='9b35a110dfb2fd91d0be0bbb7bdaad3c7840f865b96b5739b3f2b8bf83907494'
PURE_REVIEW_SHA256='5e871a15828a3e2cae7d16f3ed4ee72fa32a2c47f082a33fc9ff1e8eed2959bd'
_SOURCE_SEAL=object();_ACTIVE_SOURCE={}


def manifest():
 value=c.exact_object(c.ordinary(c.HERE/'FROZEN_THIRTY_CELL_MANIFEST.json'))
 fixed=dict(schema=config.VERSION,candidate=config.CANDIDATE,cell_count=30,cells=list(config.cells()),source_checkpoint=ALL30,source_enabled_cells=[v['cell_id'] for v in config.cells()],financial_entry_implemented=False,original_execution_replication=False,financial_reuse_allowed=False)
 if c.canonical(value)!=c.canonical(fixed):raise ValueError('EXACT_FROZEN_THIRTY_CELL_MANIFEST_REQUIRED')
 return value


def manifest_sha():manifest();return c.sha(c.ordinary(c.HERE/'FROZEN_THIRTY_CELL_MANIFEST.json'))


def tranche_cells(tranche):
 if tranche!=ALL30:raise ValueError('ONLY_EXACT_FIXED_FOLLOW_PAIR_ALL30_SOURCE_CHECKPOINT')
 return tuple(v['cell_id'] for v in config.cells())


def tranche_years(tranche):tranche_cells(tranche);return tuple(dict.fromkeys(v['year'] for v in config.cells()))


def source_maps():
 close=c.exact_object(c.ordinary(c.HERE/'CLOSE_PREFIX_SOURCE_MAP.json'));hlc=c.exact_object(c.ordinary(c.HERE/'HLC_SOURCE_CONTRACT_MAP.json'))
 if close.get('schema')!='FOLLOW_PAIR_QUALIFIED_PAST_CLOSE_PREFIX_MAP_V1' or set(close.get('years',{}))!={'2021','2022','2023','2024','2025'}:raise ValueError('EXACT_FIVE_QUALIFIED_PAST_CLOSE_PREFIX_SPECS_REQUIRED')
 if set(hlc.get('years',{}))!={'2021','2022','2023','2024','2025'}:raise ValueError('EXACT_FIVE_GENUINE_TRADE_HLC_SOURCE_SPECS_REQUIRED')
 return close,hlc


def source_map_identity():
 source_maps();return c.jsha({name:c.sha(c.ordinary(c.HERE/name)) for name in ('CLOSE_PREFIX_SOURCE_MAP.json','HLC_SOURCE_CONTRACT_MAP.json')})


def code_identity():
 raw=c.ordinary(c.HERE/'CODE_MANIFEST.json');m=c.exact_object(raw)
 if m.get('schema')!='FOLLOW_PAIR_ALL30_SOURCE_ONLY_CODE_IDENTITY_V1':raise ValueError('EXACT_FOLLOW_PAIR_SOURCE_ONLY_CODE_MANIFEST_REQUIRED')
 for name,pin in m['files'].items():c.exact(c.HERE/c.relative(name),pin['SHA256'],pin['bytes'])
 deps=c.exact_object(c.ordinary(c.HERE/'DEPENDENCY_PINS.json'))['files']
 if c.canonical(m['dependencies'])!=c.canonical(deps):raise ValueError('EXACT_CODE_METADATA_DEPENDENCIES_REQUIRED')
 for name,pin in deps.items():
  path=c.ROOT/c.relative(name)
  if path.suffix not in ('.py','.json','.md','.txt','.log'):raise ValueError('CODE_METADATA_DEPENDENCIES_ONLY')
  c.exact(path,pin['SHA256'],pin['bytes'])
 return c.sha(raw)


def review_policy():
 return dict(schema=SOURCE_REVIEW_SCHEMA,status='PASS',candidate=config.CANDIDATE,adaptation_version=config.VERSION,tranche=ALL30,ordered_cells=list(tranche_cells(ALL30)),years=list(tranche_years(ALL30)),code_manifest_SHA256=code_identity(),scope_manifest_SHA256=manifest_sha(),source_maps_SHA256=source_map_identity(),pure_signal_code_manifest_SHA256=PURE_MANIFEST_SHA256,pure_signal_independent_review_SHA256=PURE_REVIEW_SHA256,genuine_trade_HLC_schema_completeness_clock_parity_reviewed=True,source_only_guard_generated_boundary_reviewed=True,source_native_financial_approval=False,old_source_or_financial_authority_reused=False)


def source_policy(review_sha):
 return dict(schema=SOURCE_SCHEMA,status='APPROVED_SOURCE_TARGET_ONLY',action='PREPARE_EXACT_'+ALL30+'_SOURCE_TARGETS_ONLY',candidate=config.CANDIDATE,adaptation_version=config.VERSION,tranche=ALL30,ordered_cells=list(tranche_cells(ALL30)),years=list(tranche_years(ALL30)),code_manifest_SHA256=code_identity(),scope_manifest_SHA256=manifest_sha(),source_maps_SHA256=source_map_identity(),independent_review_SHA256=c.digest(review_sha),pure_signal_code_manifest_SHA256=PURE_MANIFEST_SHA256,pure_signal_independent_review_SHA256=PURE_REVIEW_SHA256,canonical_source_capture_authorized=True,genuine_trade_high_low_capture_authorized=True,target_generation_authorized=True,old_source_or_financial_authority_reused=False,historical_execution_authorized=False,financial_execution_authorized=False,account_construction_authorized=False,provider_iteration_authorized=False,process_launch_authorized=False,canonical_claims_authorized=False,financial_GO_authorized=False,publication_authorized=False,downloads_authorized=False,source_limits=dict(CPU=0,CPU_seconds=900,wall_seconds=1800,AS_bytes=3000000000,output_bytes=134217728,minimum_free_disk_bytes=1610612736,process_count=1,numerical_pools=1))


def validate_source_authority_metadata(go_raw,go_sha,review_raw,review_sha):
 go=c.checked_external(go_raw,go_sha);review=c.checked_external(review_raw,review_sha)
 if c.canonical(review)!=c.canonical(review_policy()):raise ValueError('EXACT_FRESH_FOLLOW_PAIR_SOURCE_GENERATED_REVIEW_REQUIRED')
 if c.canonical(go)!=c.canonical(source_policy(review_sha)):raise ValueError('EXACT_FRESH_ROOT_FOLLOW_PAIR_SOURCE_ONLY_GO_REQUIRED')
 return c.immutable(dict(policy=go,root_go_SHA256=go_sha,review_SHA256=review_sha))


def read_specs(year):
 config.source_year(year);close,hlc=source_maps();item=close['years'][str(year)]
 out={item['path']:{k:item[k] for k in ('SHA256','bytes','purpose')}}
 for pin in hlc['years'][str(year)]['read_files']:
  path=pin['path'];pin={k:pin[k] for k in ('SHA256','bytes','purpose')}
  c.relative(path);c.digest(pin['SHA256'])
  if type(pin['bytes']) is not int or pin['bytes']<=0 or type(pin['purpose']) is not str:raise ValueError('EXACT_TYPED_SOURCE_READ_SPEC_REQUIRED')
  if path in out and out[path]!=pin:raise ValueError('CONFLICTING_SOURCE_READ_SPEC')
  out[path]=pin
 return out


@dataclass(frozen=True,slots=True)
class FollowPairSourcePreparationScope:
 go_raw:bytes=field(repr=False)
 review_raw:bytes=field(repr=False)
 go_sha:str
 review_sha:str
 _code:str=field(repr=False)
 _token:object=field(repr=False)
 _seal:object=field(repr=False)
 def __post_init__(self):
  if self._seal is not _SOURCE_SEAL:raise ValueError('FRESH_FOLLOW_PAIR_SOURCE_ONLY_SEAL_REQUIRED')
 def validate_current(self,year=None):
  if _ACTIVE_SOURCE.get(self._token) is not self or self._code!=code_identity():raise ValueError('LIVE_CURRENT_FOLLOW_PAIR_SOURCE_SCOPE_REQUIRED')
  validate_source_authority_metadata(self.go_raw,self.go_sha,self.review_raw,self.review_sha)
  if year is not None:config.source_year(year)
  from follow_source_guard import current_guard
  guard=current_guard()
  if guard is None or not guard.active:raise ValueError('WHOLE_INVOCATION_FOLLOW_PAIR_SOURCE_ONLY_GUARD_REQUIRED')
  guard.checkpoint('SOURCE_SCOPE_CHECK');return True
 def read_source(self,year,path,expected_sha,expected_bytes,purpose):
  self.validate_current(year);path=c.relative(path);pin=read_specs(year).get(path)
  if pin is None or pin['SHA256']!=expected_sha or pin['bytes']!=expected_bytes or pin['purpose']!=purpose:raise ValueError('EXACT_TYPED_GENUINE_HLC_PAST_CLOSE_READ_ALLOWLIST_REQUIRED')
  return c.exact(c.ROOT/path,expected_sha,expected_bytes)


@contextmanager
def admit_source_stage(go_raw,go_sha,review_raw,review_sha):
 authority=validate_source_authority_metadata(go_raw,go_sha,review_raw,review_sha)
 from follow_source_guard import current_guard
 guard=current_guard()
 if guard is None or not guard.active:raise ValueError('WHOLE_INVOCATION_FOLLOW_PAIR_SOURCE_ONLY_GUARD_REQUIRED')
 token=object();scope=FollowPairSourcePreparationScope(go_raw,review_raw,go_sha,review_sha,code_identity(),token,_SOURCE_SEAL);_ACTIVE_SOURCE[token]=scope
 try:
  scope.validate_current();yield scope
 finally:_ACTIVE_SOURCE.pop(token,None)


def array_specs(year):
 n=config.source_year(year)['days'];spec=dict(decision_us=((n,),'int64'),annual_covariance=((n,5,5),'float64'))
 for name in ('STATIC50_RETARGETED','FOLLOW_ORIGINAL','POOL_RAW','STATIC50_OLD_NO_REEXPANSION'):
  spec[name]=((n,5),'float64')
 for recipe in config.RECIPES:
  spec['intrinsic_'+recipe]=((n,5),'float64')
  for tier in config.TIERS:spec[recipe+'_'+tier]=((n,5),'float64')
 for name in ('intrinsic_common_gross','intrinsic_pool_gross','intrinsic_control_gross','intrinsic_pool_minus_control_gross'):
  spec[name]=((n,),'float64')
 for tier in config.TIERS:
  for name in ('post_tier_pool_gross_','post_tier_control_gross_','post_tier_pool_minus_control_gross_'):
   spec[name+tier]=((n,),'float64')
 return spec
