"""Finite exact30 SOURCE-only entry. Fresh independent review and root GO required."""
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','POLARS_MAX_THREADS','VECLIB_MAXIMUM_THREADS','BLIS_NUM_THREADS'):
 os.environ[key]='1'
import encodings.cp437
import encodings.utf_8_sig
import numpy.testing
import argparse
import json
from pathlib import Path
import resource
import re
import signal
import time


def assign_source_cpu(cpu):
 if cpu!=0 or cpu not in os.sched_getaffinity(0):raise ValueError('ACTUALLY_ALLOWED_ASSIGNED_SOURCE_CPU0_REQUIRED')
 os.sched_setaffinity(0,{cpu})


def persist_final_receipt(output,name,receipt,*,include_own_size=False):
 import follow_common as c
 import follow_source as source
 if include_own_size:
  size=sum(p.stat().st_size for p in output.rglob('*') if p.is_file())
  receipt['output_bytes_includes_final_receipt']=True
  receipt['output_bytes']=size
  for _ in range(8):
   raw=c.canonical(receipt)+b'\n';total=size+len(raw)
   if receipt['output_bytes']==total:break
   receipt['output_bytes']=total
  else:raise ValueError('FINAL_RECEIPT_LENGTH_DID_NOT_STABILIZE')
 else:raw=c.canonical(receipt)+b'\n'
 return source.write_artifact(output,name,raw)


def main():
 parser=argparse.ArgumentParser()
 for name in ('output','source-go','source-go-sha','source-review','source-review-sha'):parser.add_argument('--'+name,required=True)
 parser.add_argument('--cpu',required=True,type=int);args=parser.parse_args();assign_source_cpu(args.cpu)
 resource.setrlimit(resource.RLIMIT_CPU,(900,900));resource.setrlimit(resource.RLIMIT_AS,(3000000000,3000000000))
 signal.signal(signal.SIGALRM,lambda *_:(_ for _ in ()).throw(TimeoutError('SOURCE_STAGE_WALL_CAP')));signal.alarm(1800)
 import follow_common as c
 import follow_entry as entry
 import follow_source as source
 import follow_signal as pure
 from follow_source_guard import SourceOnlyGuard
 go=c.exact(Path(args.source_go),args.source_go_sha);review=c.exact(Path(args.source_review),args.source_review_sha)
 authority=entry.validate_source_authority_metadata(go,args.source_go_sha,review,args.source_review_sha)
 pure.reviewed_signal().originals()
 code=c.exact_object(c.ordinary(c.HERE/'CODE_MANIFEST.json'))
 reads=[c.HERE/name for name in code['files']]+[c.ROOT/name for name in code['dependencies']]
 reads += [c.HERE/'CODE_MANIFEST.json',Path(args.source_go).absolute(),Path(args.source_review).absolute()]
 for year in entry.tranche_years(entry.ALL30):reads += [c.ROOT/name for name in entry.read_specs(year)]
 output=Path(args.output).absolute()
 if (output.parent!=c.HERE/'source_attempts' or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,100}',output.name)
     or output.exists() or output.is_symlink() or any(p.is_symlink() for p in output.parents)):
  raise ValueError('EXCLUSIVE_EXACT_NEW_SOURCE_ATTEMPT_OUTPUT_REQUIRED')
 disk=os.statvfs(c.HERE);free=disk.f_bavail*disk.f_frsize
 if free<1610612736+134217728:raise ValueError('SOURCE_OUTPUT_CAP_AND_1P5_GIB_FREE_DISK_FLOOR_REQUIRED')
 guard=SourceOnlyGuard(write_roots=(output,),read_paths=reads);began,cpu=time.monotonic(),time.process_time()
 try:
  with guard:
   guard.checkpoint('ENTER_FRESH_ALL30_GENUINE_HLC_SOURCE_ONLY_PROCESS')
   preparation=source.prepare_source_only(output,source_go_raw=go,expected_source_go_sha256=args.source_go_sha,review_raw=review,expected_review_sha256=args.source_review_sha)
   guard.checkpoint('ALL30_SOURCE_SCOPES_REVOKED_NO_FINANCE')
  elapsed=time.monotonic()-began;size=sum(p.stat().st_size for p in output.rglob('*') if p.is_file());disk=os.statvfs(c.HERE)
  if elapsed>1800 or time.process_time()-cpu>900 or size>134217728 or disk.f_bavail*disk.f_frsize<1610612736:raise ValueError('SOURCE_STAGE_RESOURCE_OR_DISK_CAP')
  receipt=guard.receipt('PASS_SOURCE_TARGET_ONLY_NO_FINANCIAL_ADMISSION')
  receipt.update(source_scopes_revoked=not entry._ACTIVE_SOURCE,elapsed_wall_seconds=elapsed,elapsed_CPU_seconds=time.process_time()-cpu,output_bytes=size,actual_CPU_affinity=sorted(os.sched_getaffinity(0)),all_TID_affinities=[sorted(os.sched_getaffinity(int(t))) for t in os.listdir('/proc/self/task')],
   final_free_disk_bytes=disk.f_bavail*disk.f_frsize,AS_limit_bytes=resource.getrlimit(resource.RLIMIT_AS)[0],CPU_limit_seconds=resource.getrlimit(resource.RLIMIT_CPU)[0],numerical_pools=1)
  persist_final_receipt(output,'OBSERVED_SOURCE_TARGET_GUARD_RECEIPT.json',receipt,include_own_size=True)
  size=receipt['output_bytes']
  print(json.dumps(dict(status=receipt['status'],forbidden_attempts=receipt['forbidden_attempts'],output_bytes=size)))
 except BaseException as exc:
  stopped=guard.receipt('STOP_SOURCE_TARGET_ONLY_NO_FINANCIAL_ADMISSION',type(exc).__name__+':'+str(exc))
  stopped.update(source_scopes_revoked=not entry._ACTIVE_SOURCE,elapsed_wall_seconds=time.monotonic()-began,elapsed_CPU_seconds=time.process_time()-cpu)
  try:
   if output.is_symlink() or any(p.is_symlink() for p in output.parents):raise ValueError('STOP_OUTPUT_SYMLINK_FORBIDDEN')
   output.mkdir(parents=True,exist_ok=True)
   persist_final_receipt(output,'STOP_SOURCE_TARGET_PREPARATION.json',stopped)
  except BaseException as receipt_error:print(json.dumps(dict(status='STOP_RECEIPT_PERSISTENCE_FAILED',receipt_error=type(receipt_error).__name__,observed_stop=stopped)))
  raise
 finally:signal.alarm(0)


if __name__=='__main__':main()
