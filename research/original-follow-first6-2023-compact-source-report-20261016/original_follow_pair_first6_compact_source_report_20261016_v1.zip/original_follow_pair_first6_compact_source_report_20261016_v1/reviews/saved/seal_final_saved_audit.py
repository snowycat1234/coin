"""Read-only final saved evidence, extrema witness and root-owned exit seal."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from decimal import Decimal,localcontext
import json,os,sys,resource
OUT=Path(__file__).resolve().parent;ROOT=OUT.parent
NATIVE=ROOT/'original_follow_pair_first6_D_native_20261016_v2'
COHORT=NATIVE/'financial_attempts/ACTUAL_FIRST6_RECOVERY_attempt001'
GO_SHA='7ce4f9ab2fc3f7e19a08896d572607a00bc7577d5c8a507b55da583c53b0485c'
CODE_SHA='d4683f8d61c50c966740d05548f0f82ee169c2008da3bd4cfd5a8ef8a32150a5'
assert sorted(os.sched_getaffinity(0))==[8]
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','POLARS_MAX_THREADS','VECLIB_MAXIMUM_THREADS','BLIS_NUM_THREADS'):assert os.environ.get(key)=='1'
blocked=[]
def boundary(event,args):
    if event in ('subprocess.Popen','os.system','os.fork','os.forkpty','os.posix_spawn','socket.connect'):
        blocked.append(event);raise RuntimeError('SAVED_SEAL_EXTERNAL_OPERATION_FORBIDDEN')
    if event=='open' and not isinstance(args[0],int):
        name,mode,flags=args
        if isinstance(name,(str,bytes,os.PathLike)) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND):
            path=Path(os.path.abspath(os.fsdecode(name)))
            if not path.is_relative_to(OUT):blocked.append(str(path));raise RuntimeError('CANONICAL_WRITES_FORBIDDEN')
sys.addaudithook(boundary)
def raw(path):
    assert not path.is_symlink() and all(not p.is_symlink() for p in path.parents)
    return path.read_bytes()
def obj(path):return json.loads(raw(path))
def pin(path):
    body=raw(path);return dict(path=str(path.relative_to(ROOT)),SHA256=sha256(body).hexdigest(),bytes=len(body))
def write(name,value):
    encoded=(json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
    assert len(encoded)<500_000
    stat=os.statvfs(OUT);assert stat.f_bavail*stat.f_frsize-len(encoded)>=1_810_612_736
    assert sum(p.stat().st_size for p in OUT.rglob('*') if p.is_file())+len(encoded)<10_000_000
    with (OUT/name).open('xb') as stream:stream.write(encoded);stream.flush();os.fsync(stream.fileno())
    return pin(OUT/name)
initial=obj(OUT/'INITIAL_BINDING.json');binding=obj(OUT/'FINAL_BINDING.json')
controller_binding=obj(OUT/'CONTROLLER_AND_FINAL_ARTIFACT_BINDING.json')
matrix=obj(OUT/'FINAL_SIX_MATRIX.json')
assert initial['root_GO']['SHA256']==GO_SHA and binding['financial_code_manifest_SHA256']==CODE_SHA
assert binding['completed_cell_count']==6 and binding['review_error_count']==0 and binding['status']=='PASS_FIRST6_SAVED_ONLY'
assert not binding['review_forbidden_execution_calls'] and not binding['boundary_attempts']
assert controller_binding['status']=='PASS_FIRST6_EXACT_SAVED_CONTROLLER'
assert controller_binding['reviewed_completed_minutes']==controller_binding['required_first6_minutes']==3_153_600
assert controller_binding['actual_paid_market_flat_cases']==controller_binding['full_calendar_cases']==6
assert controller_binding['conditional_settled_flat_cases']==0
assert matrix['status']=='PASS_EXACT_SAVED_FULL_SIX' and len(matrix['rows'])==6
cells=initial['ordered_cells'];reports={cell:obj(OUT/(cell+'.review.json')) for cell in cells}
checks=[]
for cell,report in reports.items():
    assert pin(OUT/(cell+'.review.json'))==binding['per_cell_reviews'][cell]
    directory=COHORT/cell
    assert pin(directory/'TERMINAL_CHECKPOINT.json')==report['terminal_checkpoint']
    checkpoint=obj(directory/'TERMINAL_CHECKPOINT.json')
    for name,digest in checkpoint['files'].items():assert pin(directory/name)['SHA256']==digest,(cell,name)
    result=obj(directory/'NATIVE_RESULT.json');summary=result['summary'];economics=result['economics']
    assert summary['decimal_strings']['NAV']==report['exact_NAV']
    assert summary['all_observation_max_drawdown']==economics['all_observation_max_drawdown']==report['all_observation_max_drawdown']
    witnesses=[r for r in result['extrema'] if r['kind']=='MAX_DRAWDOWN']
    if summary['all_observation_max_drawdown']>0:
        assert len(witnesses)==1
        witness=witnesses[0]
        assert witness['max_drawdown']==summary['all_observation_max_drawdown']
        assert 1-witness['NAV']/witness['peak_NAV']==witness['max_drawdown']
        assert 1672531200000000<=witness['event_us']<=1704067200000000
    else:witness=None
    assert summary['actual_caps_instantaneously_guaranteed'] is False
    assert summary['unit_certified'] is False and summary['publication_certified'] is False
    checks.append(dict(cell_id=cell,all_observation_MDD=summary['all_observation_max_drawdown'],saved_maximum_drawdown_witness=witness,
        all_observation_MDD_witness_arithmetic_exact=True,all_observation_MDD_full_observation_stream_independently_replayed=False,
        maximum_actual_gross_weight_all_observations=summary['maximum_actual_gross_weight'],
        maximum_actual_asset_weights_all_observations=summary['maximum_actual_asset_weights'],
        minimum_actual_free_cash_all_observations_USDT=summary['minimum_actual_free_cash_all_observations_USDT'],
        margin_risk_observation_scope=summary['margin_risk_observation_scope'],
        actual_caps_instantaneously_guaranteed=False,
        funding_unit_certified=False,funding_arrival_or_publication_certified=False,
        original_result=pin(directory/'NATIVE_RESULT.json')))
# Immutable replay-free authority/recovery checks use no provider/source/account constructor.
sys.path.insert(0,str(NATIVE))
import follow_finance_gate as gate,follow_recovery as recovery,follow_native as native
assert gate.code_identity()==CODE_SHA
assert recovery.validate_recovery()==recovery.recovery_policy()
reuse=obj(NATIVE/'REUSED_FUNCTION_MAP.json');assert len(reuse['inherited_account_methods'])==31 and len(reuse['guard_methods'])==3
for name in reuse['inherited_account_methods']:
    current=getattr(native.ExpansionAccount,name);frozen=getattr(native.D.Guard50ExitAccount,name)
    assert getattr(current,'__func__',current) is getattr(frozen,'__func__',frozen) and current.__code__ is frozen.__code__,name
for name in reuse['guard_methods']:assert getattr(native.ContinuationGuard,name).__code__ is getattr(native.D.ContinuationGuard,name).__code__,name
exit_path=COHORT/'ROOT_OBSERVED_EXIT_CONFIRMED.json';exit_value=obj(exit_path)
assert type(exit_value['session_id']) is int and exit_value['session_id']==75039
assert type(exit_value['observed_exit_code']) is int and exit_value['observed_exit_code']==0
assert isinstance(exit_value['observed_utc'],str)
assert not blocked
tids=[sorted(os.sched_getaffinity(int(t))) for t in os.listdir('/proc/self/task')];assert tids and all(row==[8] for row in tids)
result=write('FINAL_INDEPENDENT_SAVED_AUDIT.json',dict(schema='INDEPENDENT_FOLLOW_FIRST6_V2_RECOVERY_FINAL_SAVED_AUDIT_V1',
    UTC=datetime.now(timezone.utc).isoformat(),status='PASS_FIRST6_SAVED_OFFLINE_MODEL_WITH_SOURCE_QUALIFICATIONS_AND_ROOT_EXIT0',
    root_observed_exit=pin(exit_path),root_session_id=75039,root_observed_exit_code=0,
    root_GO=initial['root_GO'],financial_code_manifest=pin(NATIVE/'FINANCIAL_CODE_MANIFEST.json'),
    initial_authority_and_code_binding=pin(OUT/'INITIAL_BINDING.json'),per_case_saved_binding=pin(OUT/'FINAL_BINDING.json'),
    controller_and_final_artifact_binding=pin(OUT/'CONTROLLER_AND_FINAL_ARTIFACT_BINDING.json'),
    final_matrix_JSON=pin(OUT/'FINAL_SIX_MATRIX.json'),final_matrix_CSV=pin(OUT/'FINAL_SIX_MATRIX.csv'),
    per_case_reviews=binding['per_cell_reviews'],completed_cases=6,total_completed_minutes=3_153_600,
    full_calendar_actual_paid_market_flat_cases=6,conditional_settled_cases=0,economic_halt_cases=0,resource_source_validation_pause_cases=0,
    native40_every_event_reconstruction_verified=True,all27_saved_target_covariance_and_gross_array_identities_verified=True,
    all_sealed_artifact_digests_rehashed_after_controller_terminal=True,
    exact_literal_funding_clocks_and_unscaled_raw_rates_verified=True,all2023_source_quality_cells_and_intervals_zero=True,
    source_scopes_and_native_source_scopes_revoked=True,all_source_guard_forbidden_attempts_zero=True,
    exact_recovery_evidence_map=pin(NATIVE/'RECOVERY_EVIDENCE.json'),all_old20_failed_evidence_bodies_and_two_claims_preserved=True,
    financial_account_method_function_and_code_object_identity_count=31,guard_method_code_object_identity_count=3,
    all_final_restrictions_debt_no_transfer_no_topup_no_new_capital_verified=True,
    independently_checked_saved_MDD_extrema_and_all_observation_qualifications=checks,
    intrinsic_samegross=True,post_tier_samegross_guaranteed=False,independent_lower_only_tiering=True,risk_matched_claim=False,
    target_equivalent_tiers_separate_fresh_accounts=True,remaining24_authorized=False,
    source_arrival_raw_funding_units_venue_filters_and_native_liquidation_uncertified=True,
    adaptive_DEV_only=True,untouched_OOS_or_candidate_qualification=False,deployability_established=False,
    observed_resource_qualifications=controller_binding['resource_qualifications'],
    final_observed_free_disk_bytes=controller_binding['final_observed_free_disk_bytes'],
    disk_polling_not_quota_external_writer_or_annual_envelope_guarantee=True,
    review_CPU_affinity=[8],all_review_TID_affinities=tids,numerical_pools=1,
    review_peak_RSS_bytes=binding['review_peak_RSS_bytes'],review_boundary_attempts=binding['boundary_attempts'],
    reviewer_startup_harness_iteration_disclosure='First startup compared GO disk policy directly with runtime policy, omitting the extra mandatory full_cap_admission_before_output_claims_leases_workers flag. It stopped before any saved case validation or output receipt. Preserved attempt002 checks runtime policy plus that exact flag. No production source, code, claims or outputs were modified.',
    initial_stopped_harness_log=pin(OUT/'audit_actual_saved.log'),successful_saved_auditor=pin(OUT/'audit_actual_saved_attempt002.py'),
    review_financial_replays=0,review_accounts_scopes_or_providers_constructed=0,review_source_recaptures=0,
    review_claims_or_GO_issued=0,canonical_outputs_modified=0,network_actions=0,publication_actions=0))
print(json.dumps(dict(status='PASS',evidence=result),sort_keys=True))
