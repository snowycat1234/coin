"""Independent saved-only review of the exact approved FOLLOW first6 V2 recovery attempt.

No worker, source recapture, scope, provider or financial account is invoked.
This program runs on CPU8 and verifies the frozen validator, then adds direct
saved funding-clock and quality-impact checks. Only this review directory is
written. No canonical claim or target output is modified.
"""
from pathlib import Path
from hashlib import sha256
from types import SimpleNamespace
from datetime import datetime, timezone
from decimal import Decimal as D
import gc, json, os, sys, time, traceback, resource

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
MODULE = ROOT/'original_follow_pair_first6_D_native_20261016_v2'
ATTEMPT = MODULE/'financial_attempts/ACTUAL_FIRST6_RECOVERY_attempt001'
PREP = ROOT/'original_follow_pair_D_source_20261016_v1/source_attempts/ACTUAL_ALL30_SOURCE_TARGET_ONLY_attempt001'
PRIOR = ROOT/'original_follow_pair_first6_D_recovery_independent_review_20261016_v2'
assert sorted(os.sched_getaffinity(0)) == [8]
resource.setrlimit(resource.RLIMIT_AS,(4_000_000_000,4_000_000_000))
resource.setrlimit(resource.RLIMIT_RSS,(2_000_000_000,2_000_000_000))
resource.setrlimit(resource.RLIMIT_CPU,(600,600))
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','POLARS_MAX_THREADS','VECLIB_MAXIMUM_THREADS','BLIS_NUM_THREADS'):
    assert os.environ.get(key) == '1', key
boundary_attempts=[]
def audit_boundary(event,arguments):
    if event in ('subprocess.Popen','os.system','os.fork','os.forkpty','os.posix_spawn','socket.connect'):
        boundary_attempts.append(dict(event=event))
        raise RuntimeError('SAVED_REVIEW_NO_EXTERNAL_ACTION:'+event)
    if event!='open' or isinstance(arguments[0],int):return
    name,mode,flags=arguments
    if not isinstance(name,(str,bytes,os.PathLike)):return
    path=Path(os.path.abspath(os.fsdecode(name)))
    write=bool(flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))
    if write and not path.is_relative_to(OUT):
        boundary_attempts.append(dict(event='WRITE_OUTSIDE_REVIEW',path=str(path)))
        raise RuntimeError('SAVED_REVIEW_READ_ONLY_CANONICAL_OUTPUTS:'+str(path))
    if not write:
        allowed=path.is_relative_to(ATTEMPT) or path.is_relative_to(PREP)
        stdlib=path==Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/python/lib/python312.zip')
        old_finance=False  # Frozen recovery validator must read the exact old 20 zero-finance evidence bodies; no old numerical bodies are allowed.
        body=path.suffix.lower() in ('.npz','.npy','.zip','.csv','.tsv','.parquet','.arrow','.ipc')
        if old_finance or (body and not allowed and not stdlib):
            boundary_attempts.append(dict(event='UNAUTHORIZED_NUMERIC_OR_OLD_FINANCE_READ',path=str(path)))
            raise RuntimeError('SAVED_REVIEW_ONLY_CURRENT_SAVED_TARGETS_AND_COHORT:'+str(path))
sys.addaudithook(audit_boundary)
sys.path.insert(0, str(MODULE))
import follow_saved as saved
import run_follow as runner
import follow_finance_gate as gate
import follow_native as native
import follow_native_common as c
import follow_native_config as config
import numpy as np

GO_SHA = '7ce4f9ab2fc3f7e19a08896d572607a00bc7577d5c8a507b55da583c53b0485c'
FIN_SHA = 'd4683f8d61c50c966740d05548f0f82ee169c2008da3bd4cfd5a8ef8a32150a5'
SOURCE_SHA = '96791b8573a9b0d8331d3ff92cceb0016b2294b44497be4e510953cb2c025fb4'
PREP_SHA = '231c0ac6b01dd5aab924ee70976c7349317037f0af51c89df12f6269ac808bff'
args = SimpleNamespace(
    preparation=str(PREP), preparation_sha=PREP_SHA,
    go=str(MODULE/'ROOT_FIRST6_RECOVERY_APPROVED_20261016_0308.json'), go_sha=GO_SHA,
    review=str(PRIOR/'FINANCIAL_ADMISSION_REVIEW.json'), review_sha='d542fbda9d6be74d451529f39a0b91e4b0b84b70cbc2c439633568a3b8dbd9a8',
    prepared_review=str(ROOT/'original_follow_pair_D_prepared_independent_review_20261016_v1/PREPARED_REVIEW.json'), prepared_review_sha='775bb72cf7ea5480fbf3ce1a6b15dc75e0165f7ebd9e4f83efab8ec4a4eb05fd',
    native_review=str(PRIOR/'NATIVE_GENERATED_REVIEW.json'), native_review_sha='78f3d9b907f2344facd7daa38d3aac6d6183f2b9e26b540d336627f1e4bc9596',
    source_go=str(ROOT/'original_follow_pair_D_source_20261016_v1/ROOT_FOLLOW_ALL30_SOURCE_ONLY_APPROVED_20261016_0208.json'), source_go_sha='c0ee725d02cb5df3b3553c70c056381b451fdc9f6bf0a4db07c88f86cc20e22a',
    source_review=str(ROOT/'original_follow_pair_D_source_independent_review_20261016_v1/SOURCE_REVIEW.json'), source_review_sha='e678f47f5bbacc8e8dcab14e760439507deb9ada79bcae5f4e352be13f603827',
    output=str(ATTEMPT))

def utc(): return datetime.now(timezone.utc).isoformat()
def pin(path):
    h=sha256();count=0
    with path.open('rb') as stream:
        for part in iter(lambda:stream.read(8*1024*1024),b''):h.update(part);count+=len(part)
    return dict(path=str(path.relative_to(ROOT)), SHA256=h.hexdigest(), bytes=count)
def put(name, value):
    raw=(json.dumps(value,indent=2,sort_keys=True,allow_nan=False)+'\n').encode()
    path=OUT/name
    assert not path.exists(), path
    free=os.statvfs(OUT).f_bavail*os.statvfs(OUT).f_frsize
    check(sum(x.stat().st_size for x in OUT.rglob('*') if x.is_file())+len(raw)<10_000_000,'REVIEW_UNDER_10MB')
    check(free-len(raw)>=1_810_612_736,'PRESERVE_1_5GIB_PLUS_200MB')
    with path.open('xb') as stream:stream.write(raw);stream.flush();os.fsync(stream.fileno())
    return pin(path)
def log(value): print(json.dumps(value,sort_keys=True,allow_nan=False),flush=True)
def check(ok, why):
    if not ok: raise ValueError(why)

# A profile hook rejects entry into executable financial or capture paths.
# It observes the real validator without replacing any frozen function.
forbidden=[]
def no_execution(frame, event, arg):
    if event != 'call': return
    fn=frame.f_code.co_name; qn=frame.f_code.co_qualname
    mod=frame.f_globals.get('__name__','')
    bad=(mod=='run_follow' and fn in ('case','controller','load_saved_year','bootstrap')
         or mod=='follow_admission' and (fn=='admit_case' or qn.startswith(('FreshHistoricalExecutionScope.','CapturedMinuteProvider.')))
         or mod=='follow_input_loader' and fn in ('load_year','__init__')
         or mod in ('follow_native_source','follow_native_source2023','follow_source') and fn in ('capture_year','assemble_inputs')
         or mod=='follow_claims' and fn=='reserve'
         or mod=='follow_process_runtime' and fn in ('run_pool','controller_lease','shared_resource_lease')
         or mod=='follow_native' and fn in ('construct_case','_construct_case')
         or mod in ('follow_signal','follow_native_signal') and fn=='build_target_grid'
         or fn in ('make_owned_account','make_account')
         or fn=='__init__' and any(word in qn for word in ('Account.','Simulator.','Simulation.')))
    if bad:
        forbidden.append(dict(module=mod,function=qn))
        raise RuntimeError('SAVED_REVIEW_FORBIDS_EXECUTION:'+mod+'.'+qn)

sys.setprofile(no_execution)
prep_raw, prep, blobs=runner.wires(args)
check(gate.code_identity()==FIN_SHA, 'PINNED_FINANCIAL_CODE')
check(gate.SOURCE_CODE_SHA256==SOURCE_SHA, 'PINNED_SOURCE_CODE')
go=c.exact_object(blobs['go']); cells=go['ordered_cells']
check(gate.code_identity()==FIN_SHA and len(cells)==6,'EXACT_FROZEN_FOLLOW_FIRST6_RECOVERY_CODE_AND_GO')
check(go['cohort_disk_safety']==runner.r.COHORT_DISK_POLICY,'EXACT_ROOT_DISK_POLICY')
reuse=c.exact_object(c.ordinary(MODULE/'REUSED_FUNCTION_MAP.json'))
check(len(reuse['inherited_account_methods'])==31 and len(reuse['guard_methods'])==3,'EXACT_31_PLUS_3_REUSE_MAP')
for name in reuse['inherited_account_methods']:
    current=getattr(native.ExpansionAccount,name); frozen=getattr(native.D.Guard50ExitAccount,name)
    check(getattr(current,'__func__',current) is getattr(frozen,'__func__',frozen) and current.__code__ is frozen.__code__,'UNCHANGED_FINANCIAL_CODE_OBJECT:'+name)
for name in reuse['guard_methods']:
    check(getattr(native.ContinuationGuard,name).__code__ is getattr(native.D.ContinuationGuard,name).__code__,'UNCHANGED_GUARD_CODE_OBJECT:'+name)
check(go['remaining24_authorized'] is False,'NO_REMAINING24_AUTHORITY')
check(go['cohort_disk_safety']['minimum_free_bytes']==1810612736 and go['cohort_disk_safety']['maximum_cohort_output_log_temporary_bytes']==1100000000,'EXACT_V2_DISK_POLICY')
sys.setprofile(None)
initial=put('INITIAL_BINDING.json',dict(schema='INDEPENDENT_FOLLOW_FIRST6_RECOVERY_SAVED_REVIEW_INITIAL_V1',
    UTC=utc(), status='PASS_EXACT_AUTHORITY_AND_FROZEN_CODE', CPU_affinity=sorted(os.sched_getaffinity(0)),
    numerical_pools=1, root_GO=pin(Path(args.go)), financial_code_manifest=pin(MODULE/'FINANCIAL_CODE_MANIFEST.json'),
    preparation=pin(PREP/'PREPARATION.json'), ordered_cells=cells,
    validator=pin(MODULE/'follow_saved.py'), prior_native_final_receipt=pin(PRIOR/'INDEPENDENT_REVIEW.json'),
    forbidden_execution_calls=forbidden, financial_accounts_constructed=0, providers_constructed=0,
    source_capture_calls=0, claims_reserved=0, canonical_outputs_modified=0,
    exact_source_audit_SHA256=gate.PREPARED_SOURCE_AUDIT_SHA256,
    configured_cohort_disk_safety=go['cohort_disk_safety'],external_or_interpoll_disk_writers_guaranteed=False))
log(dict(event='INITIAL_BINDING_PASS', evidence=initial))

def artifact(year, filename):
    name=str(year)+'/'+filename; spec=prep['artifacts'][name]
    return c.exact(PREP/name,spec['SHA256'],spec['bytes'])

def quality_impacts(audit,result,quality,values,columns,sidecar):
    """Account-specific saved interval intersections; never inherited D counts."""
    intervals=sidecar['quality_intervals']; clocks=values[:,columns.index('close_us')]
    counts=[]
    for a,b,symbols in intervals:
        select=(clocks>=a)&(clocks<b)
        position={s:int(np.count_nonzero(values[select,columns.index(s+'_signed_weight')])) for s in symbols}
        def hit(row): return a<=row['event_us']<b and (row.get('symbol') in symbols or row.get('symbol') is None)
        trades=[x for x in audit['trades'] if hit(x)]
        # New exposure is forbidden while the actual source is declared stale.
        # Native trade rows retain reduce_only, so reductions remain allowed.
        check(all(x.get('reduce_only') is True for x in trades),'NO_NEW_RISK_TRADE_IN_DECLARED_STALE_INTERVAL')
        counts.append(dict(start_us=a,end_us=b,symbols=symbols,
            minute_rows=int(np.count_nonzero(select)), nonzero_position_minute_cells_by_symbol=position,
            paid_trades=len(trades), owned_funding_rows=sum(hit(x) and x['owned'] for x in audit['funding']),
            funding_rows=sum(hit(x) for x in result['funding']),
            ledger_rows=sum(hit(x) for x in audit['financial_ledger']),
            immediate_native_risk_rows=sum(hit(x) and x['kind']=='NATIVE_MARK_RISK' for x in audit['financial_ledger']),
            guard50_monitor_rows=sum(hit(x) for x in audit['monitor_journal']),
            quality_blocks=sum(hit(x) for x in quality['receipts']),
            terminal_in_interval=a<=audit['clock_us']<b))
    return dict(interval_count=len(intervals),source_quality_cell_count=len(sidecar['cells']),
        derived_mark_cells=sidecar.get('derived_mark_cells'), actual_saved_interval_impacts=counts,
        quality_block_rows=len(quality['receipts']), source_arrival_or_venue_mark_certified=False,
        stale_position_is_not_certified_genuine_mark=True)

def review(cell_id):
    directory=ATTEMPT/cell_id
    terminal_pin=pin(directory/'TERMINAL_CHECKPOINT.json')
    sys.setprofile(no_execution)
    try: receipt=saved.validate_saved_terminal(directory,args=args,cell_id=cell_id)
    finally: sys.setprofile(None)
    check(pin(directory/'TERMINAL_CHECKPOINT.json')==terminal_pin,'UNCHANGED_TERMINAL_DURING_REVIEW')
    checkpoint=c.exact_object((directory/'TERMINAL_CHECKPOINT.json').read_bytes())
    def get(name): return c.exact_object(c.exact(directory/name,checkpoint['files'][name]))
    audit=get('ACCOUNT_FINANCIAL_AUDIT.json'); result=get('NATIVE_RESULT.json')
    proof=get('NATIVE40_RECONSTRUCTION_PROOF.json'); legacy=get('LEGACY_PRIMARY_FINANCIAL_RECONCILIATION.json')
    sidecar=get('SOURCE_NATIVE_QUALITY.json')
    quality=get('CAUSAL_MARK_QUALITY.json')
    info=prep['years'][str(receipt['year'])]
    import follow_source_entry as source_entry
    import follow_native_codec as codec
    import follow_native_signal as signal
    arrays=codec.npz(artifact(receipt['year'],'TARGETS.npz'),source_entry.array_specs(receipt['year']))
    check(set(arrays)==set(info['array_identities']) and len(arrays)==27,'EXACT_FOLLOW_27_ARRAY_NAMESPACE')
    for key,value in arrays.items():
        check(c.canonical(signal.array_byte_identity(value))==c.canonical(info['array_identities'][key]),'EXACT_SAVED_ARRAY_IDENTITY:'+key)
        check(not value.flags.writeable,'IMMUTABLE_SAVED_ARRAY:'+key)
    saved_target_identity=signal.array_byte_identity(arrays[receipt['strategy']+'_'+receipt['tier']])
    values,columns=saved.saved_minute(c.exact(directory/'MINUTE.npz',checkpoint['files']['MINUTE.npz']),receipt['completed_minutes'],cell_id=cell_id)
    # Compare every observed record to the separately pinned prepared raw events.
    # Account funding omits fresh-flat/no-past-mark observations; result keeps them.
    event_pin=source_entry.descriptor()['qualified_source_contract']['events']['file']
    raw_events=c.object_json(c.exact(ROOT/event_pin['path'],event_pin['SHA256'],event_pin['bytes']))
    source={(x['symbol'],x['event_us']):x for x in raw_events}
    check(len(source)==len(raw_events),'UNIQUE_SAVED_SOURCE_FUNDING_IDENTITIES')
    observed=result['funding']; actual={(x['symbol'],x['event_us']):x for x in observed}
    check(len(actual)==len(observed),'UNIQUE_SAVED_OBSERVED_FUNDING_IDENTITIES')
    for key,row in actual.items():
        check(key in source,'EXACT_LITERAL_SAVED_FUNDING_CLOCK')
        original=source[key]
        for field in ('raw_rate','reported_interval_hours'):
            check(row[field]==original[field],'UNCHANGED_SAVED_FUNDING_'+field)
        check(row.get('raw_rate_unit')=='UNCONFIRMED' and row.get('conditional_rate_scale')==1.,'RAW_RATE_NOT_RESCALED_OR_CERTIFIED')
        check(D(row['assumed_fraction_decimal'])==D(str(original['raw_rate'])),'EXACT_RAW_FRACTION_DECIMAL')
    if receipt['account_stop_us'] is None:
        check(set(actual)==set(source),'COMPLETE_FULL_CALENDAR_LITERAL_FUNDING_EVENT_SET')
    else:
        stop=receipt['account_stop_us']
        check(all(key in actual for key in source if key[1]<stop),'COMPLETE_PREHALT_LITERAL_FUNDING_EVENT_SET')
        check(all(key[1]<=stop for key in actual),'NO_POSTHALT_FUNDING_APPLIED')
    for row in audit['funding']:
        key=row['symbol'],row['event_us']
        check(key in actual and D(row['decimal_strings']['rate_fraction'])==D(str(source[key]['raw_rate'])),'ACCOUNT_FUNDING_LITERAL_CLOCK_AND_RATE')
    check(audit['transfer_journal']==[] and audit['transfer_ids']=={},'ZERO_TRANSFER_AND_TOPUP')
    check(all(not any(x in row['kind'] for x in ('TOPUP','CAPITAL','FORGIVE')) for row in audit['financial_ledger']),'ZERO_CAPITAL_OR_DEBT_FORGIVENESS_EVENT')
    check(proof['account_objects_constructed']==0 and proof['financial_clocks_advanced']==0 and proof['tolerance_or_epsilon_used'] is False and proof['financial_values_changed'] is False,'EXACT_UNALTERED_SAVED_RECONSTRUCTION')
    check(audit['config']['initial_cash']=='10000' and audit['config']['fee_rate']=='0.00055','SHARED_WALLET_BASE27')
    q=quality_impacts(audit,result,quality,values,columns,sidecar)
    summary=result['summary']; economics=result['economics']
    risk=get('ACTUAL_HELD_RISK_REPORT.json')
    guard_receipts=c.object_json(c.exact(directory/'GUARD_RECEIPTS.json',checkpoint['files']['GUARD_RECEIPTS.json']))
    check(D(audit['unpaid_liability'])>=0,'NONNEGATIVE_DEBT')
    report=dict(schema='INDEPENDENT_FOLLOW_FIRST6_RECOVERY_SAVED_CELL_REVIEW_V1',UTC=utc(),status='PASS_SAVED_ONLY',
        cell_id=cell_id,year=receipt['year'],tier=receipt['tier'],terminal_checkpoint=terminal_pin,
        source_output=str(directory.relative_to(ROOT)),real_frozen_saved_validator_passed=True,
        terminal_status=receipt['status'], completed_minutes=receipt['completed_minutes'],required_minutes=receipt['required_minutes'],
        full_calendar=economics['full_calendar'], paid_flat=economics['paid_flat'],
        conditional_settled_flat=economics['conditional_settled_flat'], account_status=audit['status'],
        account_stop_us=receipt['account_stop_us'],exact_NAV=summary['decimal_strings']['NAV'],
        eligibility='VALIDATED_SAVED_CASE_WITH_EXACT_NATIVE40_ACCOUNT_SOURCE_TARGET27_AND_AUTHORITY_BINDING',
        input_binding_SHA256=receipt['input_binding_SHA256'],all27_array_identities=info['array_identities'],
        saved_target_identity=saved_target_identity, strategy=receipt['strategy'], canonical_execution_warmup_rows=199,
        no_same_target_execution_reuse=True,financial_code_manifest_SHA256=FIN_SHA,
        paid_net_return=economics['paid_net_return'],comparable_full_calendar_return=economics['comparable_full_calendar_return'],
        halted_prefix_return=economics['halted_prefix_return'],
        fees_USDT=summary['decimal_strings']['fees_USDT'],execution_cost_USDT=summary['decimal_strings']['execution_cost_USDT'],
        funding_USDT=summary['decimal_strings']['funding_USDT'],unpaid_liability=audit['unpaid_liability'],
        gross_fill_turnover_USDT=summary['decimal_strings']['gross_fill_turnover_USDT'],
        trade_legs=len(audit['trades']),conditional_settlements=len(audit['settlement_journal']),
        all_observation_max_drawdown=summary.get('all_observation_max_drawdown'),
        actual_held_risk_and_exposure=risk, guard_receipt_count=len(guard_receipts),
        all_sealed_artifact_digests={name:pin(directory/name) for name in checkpoint['files']},
        full_economics=economics, initial_and_final_account_restrictions_verified=True,
        native40_reconstruction_status=proof['status'],native40_financial_ledger_rows=proof['financial_ledger_rows_checked'],
        native40_secondary_PnL_bridge_residual=proof['native40_secondary_PnL_bridge_residual'],
        raw_precision100_residuals=proof['raw_precision100_stored_delta_terminal_residuals'],
        legacy_raw_diagnostic_passed=legacy.get('passed'), legacy_raw_diagnostic_authoritative=False,
        strict_native40_residual_explanation_passed=True,
        source_scopes_revoked=get('SOURCE_RECAPTURE_GUARD_RECEIPT.json')['source_scopes_revoked'],
        native_source_scopes_revoked=get('SOURCE_RECAPTURE_GUARD_RECEIPT.json')['native_source_scopes_revoked'],source_guard_forbidden_attempts=get('SOURCE_RECAPTURE_GUARD_RECEIPT.json')['forbidden_attempts'],
        exact_literal_funding_clocks_and_rates=True,source_funding_events=len(source),observed_funding_events=len(actual),
        account_applied_funding_events=len(audit['funding']),
        nonminute_literal_funding_clocks=sum(x['event_us']%60_000_000!=0 for x in raw_events),
        quality=q,internal_transfers=0,topups=0,new_capital=0,debt_forgiveness=0,
        fresh_shared_initial_cash='10000',BASE27_nominal_roundtrip_bps=27.,taker_fee_rate='0.00055',
        actual_worker_CPU=receipt['requested_CPU'],actual_worker_PID=receipt['PID'],
        worker_wall_seconds=receipt['total_wall_seconds'],worker_CPU_seconds=receipt['CPU_seconds'],
        worker_max_RSS_bytes=receipt['max_RSS_bytes'],review_CPU_affinity=sorted(os.sched_getaffinity(0)),
        all_review_TID_affinities=[sorted(os.sched_getaffinity(int(t))) for t in os.listdir('/proc/self/task')],
        review_accounts_constructed=0,review_scopes_constructed=0,review_providers_constructed=0,
        review_source_capture_calls=0,review_claim_mutations=0,review_forbidden_calls=forbidden,
        limitations=['DEV research only; source arrival, raw funding units, venue filters and native liquidation remain uncertified.',
            'These six independent 2023 full-year wallets start fresh at 10000 each and are not compounded; remaining24 is not authorized.',
            'Intrinsic samegross precedes independent lower-only tiers; post-tier samegross is not guaranteed and there is no risk-matched claim.'])
    output_pin=put(cell_id+'.review.json',report)
    log(dict(event='CELL_PASS',cell_id=cell_id,status=receipt['status'],NAV=report['exact_NAV'],paid_net_return=report['paid_net_return'],evidence=output_pin))
    check(all(row==[8] for row in report['all_review_TID_affinities']),'ALL_REVIEW_THREADS_CPU8')
    check(not forbidden and not boundary_attempts,'SAVED_ONLY_REVIEW_BOUNDARY_CLEAN')
    del audit,result,values,arrays
    gc.collect()
    return report,output_pin

reports={}; errors={}; report_pins={}
while True:
    for cell_id in cells:
        if cell_id in reports or cell_id in errors or not (ATTEMPT/cell_id/'TERMINAL_CHECKPOINT.json').exists(): continue
        try:
            reports[cell_id],report_pins[cell_id]=review(cell_id)
        except Exception as error:
            record=dict(UTC=utc(),cell_id=cell_id,error=repr(error),traceback=traceback.format_exc(),financial_rerun_authorized=False)
            errors[cell_id]=record
            error_pin=put(cell_id+'.REVIEW_ERROR.json',record)
            log(dict(event='REVIEW_ERROR',cell_id=cell_id,error=repr(error),evidence=error_pin))
    controller_files=list(ATTEMPT.glob('CONTROLLER_RECEIPT_*.json'))+list(ATTEMPT.glob('CONTROLLER_PAUSE_*.json'))
    if controller_files:
        # The controller only publishes after workers drain and saved validation.
        # A checkpoint can have been published during this sweep; drain the
        # terminal set once more before freezing the exact final disposition.
        missing_terminal=[cell for cell in cells if cell not in reports and cell not in errors and (ATTEMPT/cell/'TERMINAL_CHECKPOINT.json').is_file()]
        if missing_terminal:continue
        break
    time.sleep(15)

terminal=put('FINAL_BINDING.json',dict(schema='INDEPENDENT_FOLLOW_FIRST6_RECOVERY_SAVED_RESULTS_FINAL_V1',UTC=utc(),
    status='PASS_FIRST6_SAVED_ONLY' if len(reports)==6 and not errors else 'INCOMPLETE_OR_REVIEW_BLOCKED',
    initial_binding=initial,root_GO_SHA256=GO_SHA,financial_code_manifest_SHA256=FIN_SHA,
    source_code_manifest_SHA256=SOURCE_SHA,preparation_SHA256=PREP_SHA,
    ordered_cells=cells,completed_cell_count=len(reports),review_error_count=len(errors),
    per_cell_reviews=report_pins,review_errors=errors,
    controller_terminal_files=[pin(x) for x in controller_files],
    statuses={cell:report['terminal_status'] for cell,report in reports.items()},
    CPU_affinity=sorted(os.sched_getaffinity(0)),numerical_pools=1,
    review_forbidden_execution_calls=forbidden,financial_accounts_constructed=0,
    financial_scopes_constructed=0,providers_constructed=0,source_capture_calls=0,
    financial_reruns=0,claims_modified=0,canonical_output_files_modified=0,
    publication_actions=0,network_actions=0,boundary_attempts=boundary_attempts,
    review_peak_RSS_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,
    pending_cells=[cell for cell in cells if cell not in reports],
    root_process_exit_checked=False,root_exit_receipt_pending=True,
    cohort_disk_floor_is_observed_polling_not_filesystem_quota=True))
log(dict(event='FINAL_BINDING',completed=len(reports),errors=len(errors),evidence=terminal))
