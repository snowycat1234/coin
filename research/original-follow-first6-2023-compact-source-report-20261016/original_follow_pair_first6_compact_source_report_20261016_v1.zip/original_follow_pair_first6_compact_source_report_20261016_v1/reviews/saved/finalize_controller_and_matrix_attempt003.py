"""Final current-cohort saved hashes/controller/resource disposition only."""
from collections import Counter
from datetime import datetime, timezone
from hashlib import sha256
import json
import os
from pathlib import Path
import sys

OUT=Path(__file__).resolve().parent
ROOT=OUT.parent
MODULE=ROOT/'original_follow_pair_first6_D_native_20261016_v2'
ATTEMPT=MODULE/'financial_attempts/ACTUAL_FIRST6_RECOVERY_attempt001'
FIN_SHA='d4683f8d61c50c966740d05548f0f82ee169c2008da3bd4cfd5a8ef8a32150a5'
GO_SHA='7ce4f9ab2fc3f7e19a08896d572607a00bc7577d5c8a507b55da583c53b0485c'
assert sorted(os.sched_getaffinity(0))==[8]
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','POLARS_MAX_THREADS','VECLIB_MAXIMUM_THREADS','BLIS_NUM_THREADS'):
    assert os.environ.get(key)=='1'
attempted=[]
def boundary(event,args):
    if event in ('subprocess.Popen','os.system','os.fork','os.forkpty','os.posix_spawn','socket.connect'):
        attempted.append(event);raise RuntimeError('SAVED_FINAL_REVIEW_NO_EXTERNAL_ACTION')
    if event=='open' and not isinstance(args[0],int):
        name,mode,flags=args
        if isinstance(name,(str,bytes,os.PathLike)) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND):
            path=Path(os.path.abspath(os.fsdecode(name)))
            if not path.is_relative_to(OUT):
                attempted.append(str(path));raise RuntimeError('SAVED_FINAL_REVIEW_CANONICAL_OUTPUTS_READ_ONLY')
sys.addaudithook(boundary)
sys.path.insert(0,str(MODULE))
import follow_finance_gate as gate,follow_process_runtime as runtime
assert gate.code_identity()==FIN_SHA
def obj(path):return json.loads(path.read_bytes())
def pin(path):
    h=sha256();count=0
    with path.open('rb') as stream:
        for part in iter(lambda:stream.read(8*1024*1024),b''):h.update(part);count+=len(part)
    return dict(path=str(path.relative_to(ROOT)),SHA256=h.hexdigest(),bytes=count)
def write(name,value):
    raw=(json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
    assert len(raw)<500_000
    space=os.statvfs(OUT);free=space.f_bavail*space.f_frsize
    assert free-len(raw)>=1_810_612_736
    assert sum(x.stat().st_size for x in OUT.rglob('*') if x.is_file())+len(raw)<10_000_000
    with (OUT/name).open('xb') as stream:stream.write(raw)
    return pin(OUT/name)
initial=obj(OUT/'INITIAL_BINDING.json')
binding=obj(OUT/'FINAL_BINDING.json')
cells=initial['ordered_cells']
assert initial['root_GO']['SHA256']==GO_SHA and len(cells)==6
assert not binding['review_errors'] and not binding['boundary_attempts'] and not binding['review_forbidden_execution_calls']
assert binding['financial_code_manifest_SHA256']==FIN_SHA and binding['root_GO_SHA256']==GO_SHA
reports={}
artifacts={}
logical=0
for cell in cells:
    path=OUT/(cell+'.review.json')
    if not path.is_file():continue
    report=obj(path)
    assert report['cell_id']==cell and report['status']=='PASS_SAVED_ONLY'
    assert pin(path)==binding['per_cell_reviews'][cell]
    directory=ATTEMPT/cell
    assert pin(directory/'TERMINAL_CHECKPOINT.json')==report['terminal_checkpoint']
    checkpoint=obj(directory/'TERMINAL_CHECKPOINT.json')
    checked={}
    for name,digest in checkpoint['files'].items():
        checked[name]=pin(directory/name)
        assert checked[name]['SHA256']==digest,(cell,name)
        logical+=checked[name]['bytes']
    claim=(MODULE/'EXECUTION_CLAIMS'/runtime.MANIFEST_SHA256/(cell+'.json'))
    assert pin(claim)['SHA256']==checked['LAUNCH_CLAIM.json']['SHA256']
    reports[cell]=report
    artifacts[cell]=dict(terminal_checkpoint=report['terminal_checkpoint'],files=checked)
controller_receipts=list(ATTEMPT.glob('CONTROLLER_RECEIPT_*.json'))
controller_pauses=list(ATTEMPT.glob('CONTROLLER_PAUSE_*.json'))
assert len(controller_receipts)+len(controller_pauses)==1
controller_path=(controller_receipts+controller_pauses)[0]
controller=obj(controller_path)
success=bool(controller_receipts)
resource_summary={}
if success:
    assert controller['status']=='ALL_ADMITTED_ORDERED_CELLS_TERMINAL'
    assert controller['root_GO_SHA256']==GO_SHA and controller['scope_manifest_SHA256']==runtime.MANIFEST_SHA256
    assert len(reports)==6 and len(controller['cases'])==6
    assert not controller['pending_not_launched'] and not controller['saved_validation_errors']
    assert controller['limits']==runtime.LIMITS and controller['compute_thread_pools_maximum']==1
    assert controller['no_automatic_retry'] and controller['no_financial_snapshot_resume']
    assert controller['automatic_claim_clears']==0 and not controller['host_quota_guaranteed']
    assert {row['cell_id'] for row in controller['cases']}==set(cells)
    for row in controller['cases']:
        report=reports[row['cell_id']]
        assert row['status']==report['terminal_status'] and not row['reused_saved_terminal']
        assert row['checkpoint_SHA256']==report['terminal_checkpoint']['SHA256']
        assert row['PID']==report['actual_worker_PID'] and row['CPU']==report['actual_worker_CPU']
    max_live=0;max_rss=0;wide_startup_rows=0
    for observation in controller['observations']:
        workers=observation['workers']
        max_live=max(max_live,len(workers));max_rss=max(max_rss,observation['aggregate_live_RSS_bytes'])
        assert len(workers)<=2 and observation['aggregate_live_RSS_bytes']<=3_500_000_000
        assert sum(row['RSS_bytes'] for row in workers)==observation['aggregate_live_RSS_bytes']
        exact_cpus=[]
        for row in workers:
            assert row['RSS_bytes']<=2_000_000_000
            assert set(row['CPU_affinity'])<= {4,5} and row['CPU_affinity']
            assert all(set(task['CPU_affinity'])<= {4,5} and task['CPU_affinity'] for task in row['tasks'])
            if len(row['CPU_affinity'])==1:exact_cpus.append(row['CPU_affinity'][0])
            else:wide_startup_rows+=1
        assert len(exact_cpus)==len(set(exact_cpus))
    disk=controller['cohort_disk_safety']
    assert disk['policy']==runtime.COHORT_DISK_POLICY and disk['checks']>0
    assert disk['minimum_observed_free_bytes']>=1_810_612_736
    assert disk['maximum_observed_cohort_bytes']<=1_100_000_000
    admission=disk['initial_full_cap_admission']
    used=admission['cohort_output_log_temporary_bytes'];remaining=admission['remaining_full_cohort_cap_bytes']
    assert remaining==max(0,1_100_000_000-used),admission
    assert admission['required_fresh_free_bytes']==1_810_612_736+remaining,admission
    assert admission['free_bytes']>=admission['required_fresh_free_bytes'],admission
    assert admission['retained_free_after_full_cap_bytes']==admission['free_bytes']-remaining>=1_810_612_736,admission
    assert used==pin(ATTEMPT/('ADMISSION_'+GO_SHA+'.json'))['bytes'],admission
    resource_summary=dict(maximum_observed_live_workers=max_live,maximum_observed_aggregate_worker_RSS_bytes=max_rss,
        observed_prebootstrap_wide_CPU45_rows=wide_startup_rows,
        postbootstrap_exact_affinities_individually_verified_by_frozen_saved_validator=True,
        observed_disk_summary=disk)
else:
    assert controller.get('economic_halt_relabelled') is False
    resource_summary=dict(controller_pause_status=controller.get('status'),
        failure_classification=controller.get('failure_classification'),error=controller.get('error'),
        original_saved_pause_preserved=controller.get('original_saved_validation_pause_preserved',controller.get('original_pause_preserved')),
        pending_not_launched=controller.get('pending_not_launched'))
observed_bytes=runtime.own_bytes(ATTEMPT)
space=os.statvfs(ATTEMPT);free=space.f_bavail*space.f_frsize
assert observed_bytes<=1_100_000_000
assert not attempted
tids=[sorted(os.sched_getaffinity(int(t))) for t in os.listdir('/proc/self/task')]
assert tids and all(row==[8] for row in tids)
status_counts=dict(Counter(report['terminal_status'] for report in reports.values()))
final=write('CONTROLLER_AND_FINAL_ARTIFACT_BINDING.json',dict(
    schema='INDEPENDENT_FOLLOW_FIRST6_RECOVERY_CURRENT_FIRST6_CONTROLLER_AND_FINAL_SAVED_BINDING_V1',
    status='PASS_FIRST6_EXACT_SAVED_CONTROLLER' if success else 'PASS_EXACT_PUBLISHED_PARTIAL_SAVED_DISPOSITION',
    UTC=datetime.now(timezone.utc).isoformat(),financial_code_manifest=pin(MODULE/'FINANCIAL_CODE_MANIFEST.json'),
    root_GO=initial['root_GO'],source_preparation=initial['preparation'],initial_binding=pin(OUT/'INITIAL_BINDING.json'),
    incremental_saved_review=pin(OUT/'FINAL_BINDING.json'),controller_terminal=pin(controller_path),
    completed_reviewed_cases=len(reports),pending_or_unvalidated_cells=[cell for cell in cells if cell not in reports],
    reviewed_completed_minutes=sum(row['completed_minutes'] for row in reports.values()),
    required_first6_minutes=sum(row['required_minutes'] for row in reports.values()) if len(reports)==6 else 3_153_600,
    terminal_status_counts=status_counts,full_calendar_cases=sum(row['full_calendar'] for row in reports.values()),
    actual_paid_market_flat_cases=sum(row['paid_flat'] for row in reports.values()),
    conditional_settled_flat_cases=sum(row['conditional_settled_flat'] for row in reports.values()),
    all_current_checkpoint_artifact_bytes_rehashed=True,all_current_canonical_claim_bytes_match_saved_claims=True,
    checked_case_artifacts=artifacts,checked_case_artifact_logical_bytes=logical,
    complete_current_cohort_logical_bytes=observed_bytes,final_observed_free_disk_bytes=free,
    resource_qualifications=resource_summary,external_or_interpoll_writers_guaranteed=False,
    filesystem_quota_or_annual_resource_envelope_certified=False,
    source_arrival_funding_units_venue_and_liquidation_uncertified=True,
    no_same_target_or_old_financial_execution_reuse=True,
    review_CPU_affinity=[8],all_review_TID_affinities=tids,numerical_pools=1,
    actual_financial_replays=0,actual_source_recaptures=0,accounts_or_providers_constructed=0,
    claims_or_GO_issued=0,canonical_outputs_modified=0,boundary_attempts=attempted,
    root_process_exit_checked=False,root_process_exit_binding_pending=True))
print(json.dumps(dict(status='PASS',completed=len(reports),controller_success=success,evidence=final),sort_keys=True))

# Compact matrix preserves exact saved monetary strings and lower-only risk qualifiers.
rows=[]
for cell in cells:
    if cell not in reports:continue
    report=reports[cell]; risk=report['actual_held_risk_and_exposure']; e=report['full_economics']
    rows.append(dict(cell_id=cell,year=report['year'],strategy=report['strategy'],tier=report['tier'],
        terminal_status=report['terminal_status'],completed_minutes=report['completed_minutes'],required_minutes=report['required_minutes'],
        full_calendar=report['full_calendar'],actual_paid_market_flat=report['paid_flat'],conditional_settled_flat=report['conditional_settled_flat'],
        account_stop_us=report['account_stop_us'],initial_cash_USDT='10000',final_NAV_USDT=report['exact_NAV'],
        paid_net_return=report['paid_net_return'],comparable_full_calendar_return=report['comparable_full_calendar_return'],halted_prefix_return=report['halted_prefix_return'],
        fees_USDT=report['fees_USDT'],execution_cost_USDT=report['execution_cost_USDT'],funding_USDT=report['funding_USDT'],
        gross_fill_turnover_USDT=report['gross_fill_turnover_USDT'],unpaid_liability_USDT=report['unpaid_liability'],
        conditional_settlements=report['conditional_settlements'],paid_trade_legs=report['trade_legs'],
        all_observation_max_drawdown=report['all_observation_max_drawdown'],
        realized_daily_simple_return_annual_volatility=risk.get('realized_daily_simple_return_annual_volatility'),
        nominal_annual_volatility_budget=risk.get('nominal_annual_volatility_budget'),
        forecast_annual_volatility_max=risk.get('forecast_annual_volatility_max'),
        forecast_annual_volatility_mean=risk.get('forecast_annual_volatility_mean'),
        forecast_volatility_breach_minutes=risk.get('forecast_volatility_breach_minutes'),
        forecast_volatility_breach_max_absolute=risk.get('forecast_volatility_breach_max_absolute'),
        gross_exposure_max=risk.get('gross_exposure_max'),gross_exposure_mean=risk.get('gross_exposure_mean'),
        asset_exposure_absolute_max=risk.get('asset_exposure_absolute_max'),
        actual_net_signed_weight_min=risk.get('actual_net_signed_weight_min'),actual_net_signed_weight_max=risk.get('actual_net_signed_weight_max'),
        actual_net_signed_weight_mean=risk.get('actual_net_signed_weight_mean'),
        minimum_observed_free_cash_USDT=risk.get('minimum_observed_free_cash_USDT'),maximum_observed_isolated_margin_USDT=risk.get('maximum_observed_isolated_margin_USDT'),
        minutes_observed_free_cash_below1000=risk.get('minutes_observed_free_cash_below1000'),minutes_observed_margin_above8500=risk.get('minutes_observed_margin_above8500'),
        guard_receipt_count=report['guard_receipt_count'],guard_selection_counts=risk.get('guard_selection_counts'),
        guard_rejected_candidate_reason_counts=risk.get('guard_rejected_candidate_reason_counts'),
        binding_counts_include_repeated_previews_not_unique_fills=True,half_spread_bps='4',slippage_bps='4',
        quality_intervals=report['quality']['interval_count'],source_quality_cells=report['quality']['source_quality_cell_count'],
        quality_block_rows=report['quality']['quality_block_rows'],source_funding_events=report['source_funding_events'],
        observed_funding_events=report['observed_funding_events'],account_applied_funding_events=report['account_applied_funding_events'],
        target_identity=report['saved_target_identity'],worker_PID=report['actual_worker_PID'],worker_CPU=report['actual_worker_CPU'],
        native40_reconstruction_status=report['native40_reconstruction_status'],review=pin(OUT/(cell+'.review.json'))))
assert len({r['worker_PID'] for r in rows})==len(rows)
groups={}
for row in rows:groups.setdefault(row['target_identity']['descriptor_and_bytes_SHA256'],[]).append(row['cell_id'])
equivalent=[dict(target_descriptor_and_bytes_SHA256=digest,cells=group,separate_fresh_accounts_verified=True) for digest,group in groups.items() if len(group)>1]
comparisons=[]
for tier in ('LOW','MID','HIGH'):
    pool=next((r for r in rows if r['tier']==tier and r['strategy']=='STATIC50_FOLLOW_POOL_SAMEGROSS'),None)
    control=next((r for r in rows if r['tier']==tier and r['strategy']=='STATIC50_FOLLOW_DEPENDENT_SAMEGROSS_CONTROL'),None)
    if pool and control:
        comparable=pool['paid_net_return'] is not None and control['paid_net_return'] is not None
        comparisons.append(dict(tier=tier,comparison_scope='SAME_NOMINAL_TIER_ADAPTIVE_DEV_NOT_RISK_MATCHED',
            pool=pool['cell_id'],control=control['cell_id'],both_actual_paid_full_calendar=comparable,
            pool_minus_control_paid_net_return=(pool['paid_net_return']-control['paid_net_return']) if comparable else None))
matrix=write('FINAL_SIX_MATRIX.json',dict(schema='INDEPENDENT_FOLLOW_FIRST6_RECOVERY_COMPACT_SAVED_ECONOMICS_MATRIX_V2',
    status='PASS_EXACT_SAVED_FULL_SIX' if len(rows)==6 else 'PARTIAL_SAVED_DISPOSITION',ordered_cells=cells,rows=rows,
    same_nominal_tier_comparisons=comparisons,target_equivalent_separately_executed_groups=equivalent,
    monetary_strings_preserved=True,funding_sign='SIGNED_SAVED_CASH_FLOW_NO_UNITS_CERTIFICATION_OR_RESCALE',
    assumptions_and_qualifications=[
      'All six accounts begin independently at 10000 USDT with one shared CORE5 wallet per account; no cross-account compounding or reuse.',
      'Intrinsic samegross is applied before independent lower-only tiering; post-tier samegross is not guaranteed.',
      'Nominal risk ceilings constrain admitted increases. Observed post-transition marked risk can drift; actual breach statistics are reported. No exact realized-risk matching is claimed.',
      'MDD includes all observations; held risk/exposure diagnostics use post-transition minute-close observations.',
      'Funding clocks and raw rates are literal, unscaled saved observations; raw units and historical publication/arrival remain uncertified.',
      'No internal transfers, automatic topup, new capital or debt forgiveness. Conditional settlement and economic halt statuses must remain distinct from paid-flat.',
      'This is adaptive 2023 DEV research only, without untouched OOS/candidate qualification, original execution replication or native venue/liquidation certification.',
      'The old V1 two pre-account cp437 interruptions are preserved with claims; V2 does not authorize further recovery, snapshot resume, automatic retries or remaining24.',
      'Observed resource/disk safeguards are sampled stops and do not guarantee quotas or exclude external writers.'
    ],controller_and_final_artifact_binding=final,root_exit_receipt_pending=True))
import csv,io
csvrows=[]
for row in rows:csvrows.append({key:value for key,value in row.items() if not isinstance(value,(dict,list))})
if csvrows:
    stream=io.StringIO();writer=csv.DictWriter(stream,fieldnames=list(csvrows[0]));writer.writeheader();writer.writerows(csvrows)
    raw=stream.getvalue().encode();assert len(raw)<100_000
    assert os.statvfs(OUT).f_bavail*os.statvfs(OUT).f_frsize-len(raw)>=1_810_612_736
    with (OUT/'FINAL_SIX_MATRIX.csv').open('xb') as output:output.write(raw)
print(json.dumps(dict(event='FINAL_SIX_MATRIX',evidence=matrix,rows=len(rows),target_equivalent_groups=equivalent),sort_keys=True))
