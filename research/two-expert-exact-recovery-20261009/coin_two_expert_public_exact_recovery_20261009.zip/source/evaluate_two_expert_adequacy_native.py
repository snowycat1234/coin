"""Two continued frozen heads; all four original reference wallets reused."""
from pathlib import Path
import argparse,json
import evaluate_two_expert_direct_native as core
from modules.native_action import two_expert_direct as learned
from modules.native_action.runner import exclusive_json
from modules.native_action.e5_inputs import sha

ORIGINAL=core.OUT
core.FIT=core.O/'two_expert_direct_adequacy_fit'
core.OUT=core.O/'two_expert_direct_adequacy_native61'
BASE_SOURCES=core.sources
OPTIMIZER=core.bridge.ROOT/'modules/native_action/two_expert_adequacy.py'

def ready():
    r=json.loads((core.FIT/'FIT_READY.json').read_text())
    if r['actual_continuations']!=2 or r['optimizer_source_SHA256']!=sha(OPTIMIZER):
        raise ValueError('Exactly two frozen bounded continuations required')
    if any(not 256<=int(r['terminal_epochs'][a])<=1024 for a in learned.ARMS):
        raise ValueError('Predeclared training-only stopping budget')
    return r

def frozen_head(tag):
    r=ready();m=json.loads((core.FIT/(tag+'_MODEL.json')).read_text())
    if m['optimizer_source_SHA256']!=r['optimizer_source_SHA256'] or m['final_epoch']!=r['terminal_epochs'][tag]:
        raise ValueError('Bound continuation source and terminal epoch')
    return learned.load_frozen(core.FIT/(tag+'.npz'),m,
        expected_model_sha256=r['model_SHA256'][tag],cash_enabled=tag=='WITH_CASH')

def sources():
    s=BASE_SOURCES()
    s['evaluate_two_expert_adequacy_native.py']=sha(Path(__file__))
    s['modules/native_action/two_expert_adequacy.py']=sha(OPTIMIZER)
    return s

core.sources=sources
core.frozen_head=frozen_head

def prepare():
    r=ready();old=json.loads((ORIGINAL/'RESULTS.json').read_text())
    if old['native_wallet_count']!=6 or old['actual_fit_count']!=2:
        raise ValueError('Completed original study required')
    core.prepare()
    references={}
    for tag in core.FIXED:
        e=ORIGINAL/tag/'ECONOMICS.json';audit=ORIGINAL/tag/'INDEPENDENT_AUDIT.json'
        economics=json.loads(e.read_text())
        if economics['completed_minutes']!=87840 or not economics['terminal_cash_realized']:
            raise ValueError('Complete original reference required')
        target=core.OUT/tag;target.mkdir(exist_ok=False)
        exclusive_json(target/'ECONOMICS.json',economics)
        references[tag]=dict(original_economics_path=str(e),original_economics_SHA256=sha(e),
            original_audit_path=str(audit),original_audit_SHA256=sha(audit),replayed=False)
        exclusive_json(target/'REFERENCE_REUSED.json',references[tag])
    exclusive_json(core.OUT/'EXECUTION_SCOPE.json',dict(new_native_wallets=2,reused_references=references,
        actual_continuations=2,old_fit_count=2,training_only_stop_receipt_SHA256=sha(core.FIT/'FIT_READY.json'),
        model_SHA256=r['model_SHA256'],terminal_epochs=r['terminal_epochs'],stopping_reasons=r['stopping_reasons'],
        study_role='Optimization-adequacy continuation after observed development failure; no validation-selected epochs'))

def summarize():
    result={tag:json.loads((core.OUT/tag/'ECONOMICS.json').read_text()) for tag in core.POLICIES}
    scope=json.loads((core.OUT/'EXECUTION_SCOPE.json').read_text());gates={}
    for tag,r in result.items():
        if r['completed_minutes']!=87840 or not r['terminal_cash_realized'] or not r['audit_status'].startswith('PASS_'):
            raise ValueError('Complete audited comparison '+tag)
    original=json.loads((ORIGINAL/'RESULTS.json').read_text())
    for tag in learned.ARMS:
        r=result[tag]
        gates[tag]=dict(passes_primary_gate=r['liquidations']==0 and all(
            r['native_daily_utility_sum']>result[c]['native_daily_utility_sum'] for c in list(core.FIXED)[:3]),
            utility_difference_vs_fixed={c:r['native_daily_utility_sum']-result[c]['native_daily_utility_sum'] for c in core.FIXED},
            net_PnL_difference_vs_fixed={c:r['net_PnL']-result[c]['net_PnL'] for c in core.FIXED},
            utility_difference_vs_original64=r['native_daily_utility_sum']-original['results'][tag]['native_daily_utility_sum'],
            net_PnL_difference_vs_original64=r['net_PnL']-original['results'][tag]['net_PnL'],
            utility_difference_vs_cash=r['native_daily_utility_sum'])
    report=dict(status='COMPLETE_TWO_TRAINING_ONLY_CONTINUATIONS_TWO_NEW_NATIVE_WALLETS',results=result,gates=gates,
        execution_scope=scope,new_native_wallets=2,reused_reference_wallets=4,total_initial_fits=2,
        new_continuations=2,calendar_days=61,cash_analytic_reference=dict(net_PnL_USDT=0,native_daily_utility_sum=0),
        original_results_SHA256=sha(ORIGINAL/'RESULTS.json'),plan_SHA256=sha(core.OUT/'PLAN.json'),
        fit_ready_SHA256=sha(core.FIT/'FIT_READY.json'),
        history_role='Already-seen chronological development validation after earlier failed recipe; no pristine OOS claim')
    exclusive_json(core.OUT/'RESULTS.json',report)
    print(json.dumps({k:v for k,v in report.items() if k!='results'}),flush=True)

def main():
    p=argparse.ArgumentParser();p.add_argument('mode',choices=('prepare','summarize',*learned.ARMS));a=p.parse_args()
    if a.mode=='prepare':prepare()
    elif a.mode=='summarize':summarize()
    else:core.evaluate(a.mode)

if __name__=='__main__':main()
