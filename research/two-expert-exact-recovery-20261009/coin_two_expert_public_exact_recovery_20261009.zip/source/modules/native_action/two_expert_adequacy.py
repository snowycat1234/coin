"""One bounded Adam continuation of each frozen tiny two-expert head.

Import/check never fit. The original 64-step states are recovered from zero and
must match the frozen parameter bytes before either arm takes another step.
Training-only checkpoints determine stopping; validation follows FIT_READY.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import time

import numpy as np

from modules.native_action import two_expert_direct as direct

INITIAL_EPOCH = 64
CHECKPOINT_INTERVAL = 64
MINIMUM_EPOCH = 256
MAXIMUM_EPOCH = 1024
PLATEAU_ABSOLUTE_DELTA = 1e-6
PLATEAU_CONSECUTIVE_DELTAS = 2
MAX_TOTAL_SECONDS = 120
OUTPUT_NAME = "two_expert_direct_adequacy_fit"
ORIGINAL_FIT_NAME = "two_expert_direct_fit"
ORIGINAL_SOURCE_SHA256 = "f4797892c07c73a7516676c060aeef9f89168b4ee60c0ad34f36bfa51a6f0442"
ORIGINAL_MODEL_SHA256 = {
    "NO_CASH": "25730ad657e7de45dc3740df0c88f116bc80391e61dbb50844f1698b9a0c7ec6",
    "WITH_CASH": "2bcaf32353ba123512cd58157a25e2c0bd6bbad83f893ee6815d3c6d2266f4df",
}


def optimizer_source_hash():
    return direct.sha(Path(__file__))


def coefficient_hashes(head):
    return {name: hashlib.sha256(value.tobytes(order="C")).hexdigest()
            for name, value in head.parameters.items()}


def _budget(began_wall, began_cpu):
    if (time.monotonic() - began_wall >= MAX_TOTAL_SECONDS
            or time.process_time() - began_cpu >= MAX_TOTAL_SECONDS):
        raise TimeoutError("Combined recovery/continuation120-second CPU/wall budget exhausted; no restart")


def _adam_update(head, gradient, first, second, step):
    """Same operation order as the original fixed fit, including norm clipping."""
    norm = float(np.sqrt(sum(float((g * g).sum()) for g in gradient.values())))
    if not np.isfinite(norm):
        raise ValueError("Nonfinite own-path gradient; stop both arms")
    clip = min(1., 1. / norm) if norm else 1.
    for name, p in head.parameters.items():
        g = gradient[name] * clip
        first[name] = .9 * first[name] + .1 * g
        second[name] = .999 * second[name] + .001 * g * g
        m = first[name] / (1 - .9 ** step)
        v = second[name] / (1 - .999 ** step)
        p -= direct.LEARNING_RATE * m / (np.sqrt(v) + 1e-8)
    if any(not np.isfinite(value).all()
           for group in (head.parameters, first, second) for value in group.values()):
        raise ValueError("Nonfinite coefficient or Adam state; stop both arms")
    return norm, clip


def _step(state, train):
    # The unchanged gradient routine necessarily returns its objective too.
    # It is checked for finiteness here, never used for checkpoint selection.
    loss, gradient, _ = direct.path_loss_and_gradient(state["head"], train)
    if not np.isfinite(loss):
        raise ValueError("Nonfinite own-path loss; stop both arms")
    step = state["step"] + 1
    _adam_update(state["head"], gradient, state["first"], state["second"], step)
    state["step"] = step


def _verify_exact_recovery(recovered, frozen):
    """Require element equality AND exact array bytes/dtypes, not tolerance."""
    recovered_arrays = dict(mean=recovered.mean, scale=recovered.scale, **recovered.parameters)
    frozen_arrays = dict(mean=frozen.mean, scale=frozen.scale, **frozen.parameters)
    if set(recovered_arrays) != set(frozen_arrays):
        raise ValueError("Recovered model array names differ from frozen original")
    for name, value in recovered_arrays.items():
        expected = frozen_arrays[name]
        if (value.shape != expected.shape or value.dtype != expected.dtype
                or not np.array_equal(value, expected)
                or value.tobytes(order="C") != expected.tobytes(order="C")):
            raise ValueError("Exact optimizer recovery failed for array " + name)


def _checkpoint(state, train):
    epoch = state["step"]
    if epoch % CHECKPOINT_INTERVAL:
        raise ValueError("Training diagnostics only at completed64-step checkpoints")
    loss, gradient, _ = direct.path_loss_and_gradient(state["head"], train)
    if not np.isfinite(loss) or any(not np.isfinite(g).all() for g in gradient.values()):
        raise ValueError("Nonfinite completed-checkpoint training loss/gradient; stop both arms")
    loss = float(loss)
    previous = state["previous_checkpoint_loss"]
    delta = None if previous is None else abs(loss - previous)
    if delta is not None and delta < PLATEAU_ABSOLUTE_DELTA:
        state["consecutive_small_deltas"] += 1
    else:
        state["consecutive_small_deltas"] = 0
    state["previous_checkpoint_loss"] = loss
    losses = [entry["training_loss"] for entry in state["checkpoints"]] + [loss]
    plateau = plateau_decision(losses, epoch)
    record = dict(epoch=epoch, training_loss=loss, absolute_checkpoint_loss_change=delta,
                  consecutive_small_absolute_changes=state["consecutive_small_deltas"],
                  plateau=plateau, coefficient_SHA256=coefficient_hashes(state["head"]))
    state["checkpoints"].append(record)
    return record, plateau


def plateau_decision(losses, epoch):
    """Pure stop-rule helper for zero-fit tests and diagnostic audits."""
    if epoch < MINIMUM_EPOCH or len(losses) < 3:
        return False
    return all(abs(float(b) - float(a)) < PLATEAU_ABSOLUTE_DELTA
               for a, b in zip(losses[-3:-1], losses[-2:]))


def _load_inputs(pack, expected_index_sha256, frozen_fit):
    pack, frozen_fit = Path(pack).resolve(), Path(frozen_fit).resolve()
    if (expected_index_sha256 != direct.INDEX_SHA or direct.EPOCHS != INITIAL_EPOCH
            or direct.LEARNING_RATE != .001):
        raise ValueError("Exact frozen64-epoch data/optimizer declaration required")
    if frozen_fit != pack.parent / ORIGINAL_FIT_NAME:
        raise ValueError("Original sibling two_expert_direct_fit required")
    ready = json.loads((frozen_fit / "FIT_READY.json").read_text())
    if (ready.get("status") != "FIT_READY" or ready.get("actual_fits") != 2
            or ready.get("final_epoch") != INITIAL_EPOCH
            or ready.get("model_SHA256") != ORIGINAL_MODEL_SHA256):
        raise ValueError("Both original64-epoch heads must be frozen before continuation")
    train, validation, meta = direct.load_training_and_validation(pack, expected_index_sha256)
    direct.verify_schema(meta)
    mean, scale = direct.training_standardizer(train)
    sources = direct.source_hashes()
    if sources.get("modules/native_action/two_expert_direct.py") != ORIGINAL_SOURCE_SHA256:
        raise ValueError("Frozen original two_expert_direct source SHA required")
    originals, original_metadata = {}, {}
    for arm in direct.ARMS:
        record = json.loads((frozen_fit / (arm + "_MODEL.json")).read_text())
        model_sha = ready["model_SHA256"][arm]
        if record.get("final_epoch") != INITIAL_EPOCH or record.get("source_SHA256") != sources:
            raise ValueError("Original frozen source and64-epoch metadata required")
        originals[arm] = direct.load_frozen(frozen_fit / (arm + ".npz"), record,
            expected_model_sha256=model_sha, cash_enabled=arm == "WITH_CASH")
        original_metadata[arm] = record
    return train, validation, meta, mean, scale, sources, originals, original_metadata


def check(pack, expected_index_sha256, frozen_fit):
    train, validation, _, _, _, sources, originals, _ = _load_inputs(
        pack, expected_index_sha256, frozen_fit)
    return dict(status="READY_ZERO_FIT_CONTINUATION", fit_count=0, continuations=0,
        new_native_wallets=0, training_rows=sum(len(f["contexts"]) for f in train),
        validation_rows=len(validation["contexts"]),
        original_model_SHA256={arm: head.model_sha256 for arm, head in originals.items()},
        source_SHA256=sources, optimizer_source_SHA256=optimizer_source_hash(),
        initial_epoch=INITIAL_EPOCH, minimum_total_epochs=MINIMUM_EPOCH,
        maximum_total_epochs=MAXIMUM_EPOCH, checkpoint_interval=CHECKPOINT_INTERVAL,
        plateau_absolute_loss_change=PLATEAU_ABSOLUTE_DELTA,
        plateau_consecutive_changes=PLATEAU_CONSECUTIVE_DELTAS,
        maximum_combined_cpu_wall_seconds=MAX_TOTAL_SECONDS)


def _save_state(path, state):
    with Path(path).open("xb") as stream:
        np.savez(stream, step=np.asarray(state["step"], dtype=np.int64),
                 **{"first_" + name: value for name, value in state["first"].items()},
                 **{"second_" + name: value for name, value in state["second"].items()})
    return direct.sha(path)


def _save_model(output, arm, state, meta, sources, optimizer_sha, original, recovery):
    head = state["head"]
    path = output / (arm + ".npz")
    with path.open("xb") as stream:
        np.savez(stream, mean=head.mean, scale=head.scale, **head.parameters)
    record = direct.model_metadata(head, arm, meta, sources, direct.sha(path))
    record.update(final_epoch=state["step"], optimizer_source_SHA256=optimizer_sha,
                  original_model_SHA256=original.model_sha256,
                  coefficient_SHA256=coefficient_hashes(head),
                  stopping_reason=state["stopping_reason"],
                  optimizer_state_SHA256=_save_state(output / (arm + "_ADAM.npz"), state),
                  optimizer_step=state["step"],
                  checkpoint_selection="final_terminal_head_only_no_validation_selection",
                  study_history=dict(original_fit_epochs=INITIAL_EPOCH,
                      original_fit_source_SHA256=sources,
                      original_model_SHA256=original.model_sha256,
                      continuation_count=1, optimizer_state_recovery=recovery,
                      checkpoint_interval=CHECKPOINT_INTERVAL,
                      minimum_total_epochs=MINIMUM_EPOCH,
                      maximum_total_epochs=MAXIMUM_EPOCH,
                      plateau_absolute_loss_change=PLATEAU_ABSOLUTE_DELTA,
                      plateau_consecutive_changes=PLATEAU_CONSECUTIVE_DELTAS))
    direct._exclusive_json(output / (arm + "_MODEL.json"), record)
    return record


def continue_fixed_pair(pack, expected_index_sha256, frozen_fit, output):
    """Recover both originals, then continue each once within one combined budget."""
    began_wall, began_cpu = time.monotonic(), time.process_time()
    direct._require_bounded()
    output, pack = Path(output).resolve(), Path(pack).resolve()
    if output != pack.parent / OUTPUT_NAME:
        raise ValueError("Exclusive sibling two_expert_direct_adequacy_fit output required")
    loaded = _load_inputs(pack, expected_index_sha256, frozen_fit)
    train, validation, meta, mean, scale, sources, originals, _ = loaded
    optimizer_sha = optimizer_source_hash()
    # An existing directory is a no-restart guard, including partial attempts.
    output.mkdir(exist_ok=False)
    direct._exclusive_json(output / "FIT_STARTED.json", dict(
        planned_continuations=2, arms=list(direct.ARMS), source_SHA256=sources,
        optimizer_source_SHA256=optimizer_sha,
        original_model_SHA256={a: h.model_sha256 for a, h in originals.items()},
        fragment_index_SHA256=direct.INDEX_SHA, initial_epoch=INITIAL_EPOCH,
        minimum_total_epochs=MINIMUM_EPOCH, maximum_total_epochs=MAXIMUM_EPOCH,
        maximum_combined_cpu_wall_seconds=MAX_TOTAL_SECONDS,
        single_cpu=True, address_limit_bytes=1_000_000_000,
        checkpoint_interval=CHECKPOINT_INTERVAL,
        plateau_absolute_loss_change=PLATEAU_ABSOLUTE_DELTA,
        plateau_consecutive_changes=PLATEAU_CONSECUTIVE_DELTAS))
    states, recoveries, records, traces = {}, {}, {}, {}
    try:
        recovery_wall, recovery_cpu = time.monotonic(), time.process_time()
        for arm in direct.ARMS:
            _budget(began_wall, began_cpu)
            started_wall, started_cpu = time.monotonic(), time.process_time()
            head = direct.TwoExpertHead(mean, scale, cash_enabled=arm == "WITH_CASH")
            state = dict(head=head, first={k: np.zeros_like(p) for k, p in head.parameters.items()},
                         second={k: np.zeros_like(p) for k, p in head.parameters.items()},
                         step=0, previous_checkpoint_loss=None, consecutive_small_deltas=0,
                         checkpoints=[], stopping_reason=None)
            states[arm] = state
            for _ in range(INITIAL_EPOCH):
                _budget(began_wall, began_cpu)
                _step(state, train)
                _budget(began_wall, began_cpu)
            _verify_exact_recovery(head, originals[arm])
            recoveries[arm] = dict(status="EXACT_ELEMENT_AND_ARRAY_BYTES_MATCH",
                reconstructed_step=state["step"], coefficient_SHA256=coefficient_hashes(head),
                original_model_SHA256=originals[arm].model_sha256,
                cpu_seconds=time.process_time() - started_cpu,
                wall_seconds=time.monotonic() - started_wall,
                recovered_optimizer_state_SHA256=_save_state(
                    output / (arm + "_RECOVERED_ADAM64.npz"), state))
        recovery = dict(arms=recoveries, both_originals_matched_before_new_steps=True,
                        cpu_seconds=time.process_time() - recovery_cpu,
                        wall_seconds=time.monotonic() - recovery_wall)
        direct._exclusive_json(output / "OPTIMIZER_RECOVERY.json", recovery)
        # No epoch65 can be reached until both exact original matches succeeded.
        for arm, state in states.items():
            traces[arm] = (output / (arm + "_TRAINING.jsonl")).open("x")
            _budget(began_wall, began_cpu)
            checkpoint, _ = _checkpoint(state, train)
            traces[arm].write(json.dumps(checkpoint, allow_nan=False) + "\n")
            traces[arm].flush()
            _budget(began_wall, began_cpu)
        # Interleave updates so neither arm consumes the shared budget first.
        while any(state["stopping_reason"] is None for state in states.values()):
            for arm, state in states.items():
                if state["stopping_reason"] is not None:
                    continue
                _budget(began_wall, began_cpu)
                _step(state, train)
                _budget(began_wall, began_cpu)
                if state["step"] % CHECKPOINT_INTERVAL == 0:
                    checkpoint, plateau = _checkpoint(state, train)
                    traces[arm].write(json.dumps(checkpoint, allow_nan=False) + "\n")
                    traces[arm].flush()
                    _budget(began_wall, began_cpu)
                    if plateau:
                        state["stopping_reason"] = "TRAINING_ABSOLUTE_PLATEAU_TWO_CONSECUTIVE_CHECKPOINT_CHANGES"
                    elif state["step"] == MAXIMUM_EPOCH:
                        state["stopping_reason"] = "MAXIMUM_TOTAL_EPOCHS1024"
        if (direct.source_hashes() != sources or optimizer_source_hash() != optimizer_sha
                or any(direct.sha(head.model_path) != ORIGINAL_MODEL_SHA256[arm]
                       for arm, head in originals.items())):
            raise ValueError("Frozen source changed during optimizer recovery/continuation")
        for arm, state in states.items():
            records[arm] = _save_model(output, arm, state, meta, sources, optimizer_sha,
                                       originals[arm], recoveries[arm])
        frozen = {arm: direct.load_frozen(output / (arm + ".npz"), record,
            expected_model_sha256=record["model_SHA256"], cash_enabled=arm == "WITH_CASH")
            for arm, record in records.items()}
        if optimizer_source_hash() != optimizer_sha:
            raise ValueError("Optimizer source changed before freeze gate")
        _budget(began_wall, began_cpu)
        ready = dict(status="FIT_READY", actual_continuations=2, refits=0,
            model_SHA256={arm: r["model_SHA256"] for arm, r in records.items()},
            original_model_SHA256={arm: h.model_sha256 for arm, h in originals.items()},
            terminal_epochs={arm: s["step"] for arm, s in states.items()},
            stopping_reasons={arm: s["stopping_reason"] for arm, s in states.items()},
            source_SHA256=sources, optimizer_source_SHA256=optimizer_sha,
            optimizer_state_SHA256={arm: r["optimizer_state_SHA256"] for arm, r in records.items()},
            optimizer_recovery=recovery, elapsed_seconds=time.monotonic() - began_wall,
            cpu_seconds=time.process_time() - began_cpu, validation_scored=False)
        # Both terminal heads and metadata are persisted/verified before this gate.
        direct._exclusive_json(output / "FIT_READY.json", ready)
        print(json.dumps(ready, allow_nan=False), flush=True)
        results = {}
        for arm, head in frozen.items():
            _budget(began_wall, began_cpu)
            loss, _, reports = direct.path_loss_and_gradient(head, [validation])
            if not np.isfinite(loss):
                raise ValueError("Nonfinite frozen-head proxy validation loss")
            report = reports[0]
            request = head.request(np.asarray([c.features() for c in validation["contexts"]]))
            with (output / (arm + "_VALIDATION_REQUESTS.npz")).open("xb") as stream:
                np.savez(stream, request=request,
                    decision_us=np.asarray([c.decision_us for c in validation["contexts"]], np.int64))
            results[arm] = dict(loss=loss, **{key: report[key] for key in
                ("utility_sum", "net_PnL", "fees", "spread", "slippage", "funding", "gross",
                 "terminal_cash_realized", "status")})
            if direct.sha(head.model_path) != head.model_sha256:
                raise ValueError("Frozen continuation model changed during validation")
            _budget(began_wall, began_cpu)
        if direct.source_hashes() != sources or optimizer_source_hash() != optimizer_sha:
            raise ValueError("Frozen source changed during proxy validation")
        _budget(began_wall, began_cpu)
        result = dict(status="PASS_FIXED_TWO_CONTINUATIONS_PROXY_VALIDATION_ONLY",
            actual_continuations=2, refits=0, new_native_wallets=0, arms=results,
            elapsed_seconds=time.monotonic() - began_wall, cpu_seconds=time.process_time() - began_cpu)
        direct._exclusive_json(output / "VALIDATION_RESULTS.json", result)
        return result
    except Exception as error:
        reason = "COMBINED_DEADLINE" if isinstance(error, TimeoutError) else "NONFINITE_OR_CONTRACT_FAILURE"
        for arm, state in states.items():
            if state["stopping_reason"] is None:
                state["stopping_reason"] = reason
            # Preserve moments and completed step counts for diagnosis only.
            failure_path = output / (arm + "_STOPPED_ADAM.npz")
            if not failure_path.exists():
                _save_state(failure_path, state)
            stopped_path = output / (arm + "_STOPPED_COEFFICIENTS.npz")
            if not stopped_path.exists():
                with stopped_path.open("xb") as stream:
                    np.savez(stream, mean=state["head"].mean, scale=state["head"].scale,
                             **state["head"].parameters)
        direct._exclusive_json(output / "FIT_FAILED.json", dict(status="STOP_NO_RESTART",
            error_type=type(error).__name__, error=str(error),
            completed_frozen_models=list(records),
            terminal_epochs={arm: state["step"] for arm, state in states.items()},
            stopping_reasons={arm: state["stopping_reason"] for arm, state in states.items()},
            recovery=recoveries, elapsed_seconds=time.monotonic() - began_wall,
            cpu_seconds=time.process_time() - began_cpu))
        raise
    finally:
        for trace in traces.values():
            trace.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("check", "continue"))
    parser.add_argument("--pack", type=Path, required=True)
    parser.add_argument("--index-sha256", required=True)
    parser.add_argument("--frozen-fit", type=Path, required=True)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if args.mode == "check":
        if args.output is not None:
            parser.error("check is read-only and takes no output directory")
        result = check(args.pack, args.index_sha256, args.frozen_fit)
    else:
        if args.output is None:
            parser.error("continue requires the exclusive continuation output directory")
        result = continue_fixed_pair(args.pack, args.index_sha256, args.frozen_fit, args.output)
    print(json.dumps(result, allow_nan=False), flush=True)


if __name__ == "__main__":
    main()
