"""Fixed 3/6-parameter own-path experiment over two existing causal fields.

No fitting on import. ``check`` performs zero learning and ``fit`` performs
exactly one 64-epoch fit of each arm, with exclusive on-disk start guards.
The financial mathematics are imported unchanged from the frozen prototype.
Sigmoids can approach CASH; exact terminal/risk/availability CASH remains a
mechanical property of the existing mapper and native account.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import resource
import time

import numpy as np

from modules.direct_path.data_adapter import load_training_and_validation
from modules.direct_path.prototype import CORE5, E5, FEATURES, finite, loss_and_gradient
from modules.direct_path.training import EPOCHS, LEARNING_RATE, WINDOWS, validate_fragment

ROOT = Path(__file__).resolve().parents[2]
INDEX_SHA = "e4fecc49cd1bb05f72dc0f8d24e793a5d7e4d2436c89a18bd9d7c625a7849be8"
SCHEMA_SHA = "c8739e22495ecca14fc3c9e78e9b160e9ad7cc026fca1e1abc6bf8c81904d632"
FEATURE_NAMES = ("market.BTC_mom20", "market.BTC_vol30")
FEATURE_INDICES = (2, 5)
MARKET_ORDER = ("BTC_mom1", "BTC_mom5", "BTC_mom20", "BTC_mom60", "BTC_mom200",
                "BTC_vol30", "BTC_vol200", "BTC_dist50", "BTC_dist200", "BTC_funding",
                "breadth20", "dispersion20", "market_vol20")
FULL_FEATURE_NAMES = (["market." + n for n in MARKET_ORDER]
                      + ["expert." + e + "." + s for e in E5 for s in CORE5]
                      + ["eligible." + e for e in E5])
ARMS = ("NO_CASH", "WITH_CASH")
MAX_TOTAL_SECONDS = 120
SOURCE_FILES = ("modules/native_action/two_expert_direct.py",
                "modules/direct_path/prototype.py", "modules/direct_path/data_adapter.py",
                "modules/direct_path/training.py", "modules/native_action/e5_inputs.py",
                "scripts/research/conditional_selector_core.py",
                "scripts/investment/regime_ranking_screen.py")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def source_hashes():
    return {name: sha(ROOT / name) for name in SOURCE_FILES}


def verify_schema(meta):
    """Resolve the chosen indices from the bound original named 43-schema."""
    names = meta.get("feature_names")
    if (names != FULL_FEATURE_NAMES or len(names) != FEATURES
            or meta.get("feature_schema_SHA256") != SCHEMA_SHA
            or hashlib.sha256(json.dumps(names, sort_keys=True).encode()).hexdigest() != SCHEMA_SHA):
        raise ValueError("Exact bound original43 feature schema required")
    indices = tuple(names.index(name) for name in FEATURE_NAMES)
    if indices != FEATURE_INDICES:
        raise ValueError("Exact selected field indices required")
    for entry in meta.get("fragments", []):
        if entry.get("feature_names") != names:
            raise ValueError("Every bound fragment must have the same feature schema")
    return indices


def training_standardizer(fragments):
    """All 182 training rows only, including their common terminal rows."""
    if [f.get("window_id") for f in fragments] != list(WINDOWS)[:3]:
        raise ValueError("Exactly Nov2022, Jan2023 and Jan-Apr2024 training fragments")
    identities = [validate_fragment(f, f["window_id"]) for f in fragments]
    if [len(f["contexts"]) for f in fragments] != [30, 31, 121]:
        raise ValueError("Exactly 182 training observations required")
    for key in ("expert_identity_sha256", "mapper_sha256"):
        if len({i[key] for i in identities}) != 1:
            raise ValueError("Same frozen expert and mapper identity required")
    selected = np.concatenate([
        np.asarray([c.features() for c in f["contexts"]])[:, FEATURE_INDICES]
        for f in fragments
    ])
    mean, scale = selected.mean(axis=0), selected.std(axis=0, ddof=0)
    return mean, np.where(scale > 1e-8, scale, 1.)


def _sigmoid(logits):
    """Stable sigmoid without clipping or imputing the logits."""
    value = np.asarray(logits, dtype=np.float64)
    if not np.isfinite(value).all():
        raise ValueError("Finite affine logits required")
    result = np.empty_like(value)
    positive = value >= 0
    result[positive] = 1. / (1. + np.exp(-value[positive]))
    exp_value = np.exp(value[~positive])
    result[~positive] = exp_value / (1. + exp_value)
    return result


class TwoExpertHead:
    """Bias/momentum20/volatility30 coefficients; zero initialization only."""
    def __init__(self, mean, scale, *, cash_enabled=False):
        if type(cash_enabled) is not bool:
            raise ValueError("Explicit boolean cash-enabled flag required")
        self.cash_enabled = cash_enabled
        self.mean = finite(mean, (2,), "training-only means2").copy()
        self.scale = finite(scale, (2,), "training-only scales2").copy()
        if np.any(self.scale <= 0):
            raise ValueError("Positive training-only scales required")
        self.parameters = {"w": np.zeros(3, dtype=np.float64)}
        if cash_enabled:
            self.parameters["s"] = np.zeros(3, dtype=np.float64)

    def forward(self, original43):
        value = np.asarray(original43, dtype=np.float64)
        if value.ndim != 2 or value.shape[1] != FEATURES or not np.isfinite(value).all():
            raise ValueError("Complete finite original43 matrix required")
        selected = (value[:, FEATURE_INDICES] - self.mean) / self.scale
        design = np.column_stack((np.ones(len(value)), selected))
        w = _sigmoid(design @ self.parameters["w"])
        s = _sigmoid(design @ self.parameters["s"]) if self.cash_enabled else np.ones(len(value))
        requests = np.zeros((len(value), 5), dtype=np.float64)
        requests[:, 0] = 1. - s
        requests[:, 1] = s * (1. - w)
        requests[:, 4] = s * w
        if (not np.isfinite(requests).all() or np.any(requests < 0)
                or np.any(np.abs(requests.sum(axis=1) - 1.) > 1e-12)):
            raise ValueError("Ordered finite E5 simplex required")
        return requests, (design, w, s)

    def backward(self, request_gradient, cache):
        design, w, s = cache
        gradient = finite(request_gradient, (len(design), 5), "request gradient")
        dw = s * (gradient[:, 4] - gradient[:, 1]) * w * (1. - w)
        result = {"w": design.T @ dw}
        if self.cash_enabled:
            ds = (-gradient[:, 0] + (1. - w) * gradient[:, 1] + w * gradient[:, 4])
            result["s"] = design.T @ (ds * s * (1. - s))
        return result

    def request(self, original43):
        return self.forward(original43)[0]


def path_loss_and_gradient(head, fragments):
    """Unmodified daily log-NAV/downside own-path objective; no teacher loss."""
    return loss_and_gradient(head, fragments, "DIRECT_PATH_UTILITY")


def _exclusive_json(path, record):
    with Path(path).open("x") as stream:
        json.dump(record, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write("\n")


def model_metadata(head, arm, meta, source_sha, model_sha):
    return dict(schema="TWO_EXPERT_DIRECT_FROZEN_V1", arm=arm,
                cash_enabled=head.cash_enabled, model_SHA256=model_sha,
                parameter_count=sum(p.size for p in head.parameters.values()),
                coefficient_order=["bias", *FEATURE_NAMES],
                selected_feature_names=list(FEATURE_NAMES),
                selected_feature_indices=list(FEATURE_INDICES),
                feature_names=meta["feature_names"], feature_schema_SHA256=SCHEMA_SHA,
                fragment_index_SHA256=INDEX_SHA, training_rows=182,
                training_fragments=meta["fragments"][:3],
                validation_fragment=meta["fragments"][3],
                standardizer="training182_selected2_mean_std_ddof0_scale_le_1e-8_to1_no_clip",
                initial_parameters="all_zero", final_epoch=EPOCHS,
                optimizer=dict(name="Adam", learning_rate=LEARNING_RATE, beta1=.9,
                               beta2=.999, epsilon=1e-8, gradient_norm_clip=1.),
                objective="daily_log_NAV_ratio_minus5_negative_daily_return_squared",
                checkpoint_selection="final_epoch_only", source_SHA256=source_sha)


def save_model(head, output, arm, meta, source_sha):
    path = Path(output) / (arm + ".npz")
    # Plain arrays only; no pickle, classes, object dtypes or opaque estimator.
    with path.open("xb") as stream:
        np.savez(stream, mean=head.mean, scale=head.scale, **head.parameters)
    record = model_metadata(head, arm, meta, source_sha, sha(path))
    _exclusive_json(Path(output) / (arm + "_MODEL.json"), record)
    return record


def load_frozen(path, metadata, *, expected_model_sha256, cash_enabled):
    """Validate exact bytes, current sources, schema, flag and plain shapes."""
    if not isinstance(metadata, dict):
        metadata = json.loads(Path(metadata).read_text())
    arm = "WITH_CASH" if cash_enabled else "NO_CASH"
    if (type(cash_enabled) is not bool or metadata.get("schema") != "TWO_EXPERT_DIRECT_FROZEN_V1"
            or metadata.get("arm") != arm or metadata.get("cash_enabled") is not cash_enabled
            or metadata.get("model_SHA256") != expected_model_sha256
            or sha(path) != expected_model_sha256):
        raise ValueError("Exact model SHA and cash-enabled flag required")
    verify_schema(metadata)
    if (metadata.get("selected_feature_names") != list(FEATURE_NAMES)
            or metadata.get("selected_feature_indices") != list(FEATURE_INDICES)
            or metadata.get("coefficient_order") != ["bias", *FEATURE_NAMES]
            or metadata.get("source_SHA256") != source_hashes()
            or metadata.get("fragment_index_SHA256") != INDEX_SHA):
        raise ValueError("Exact source/schema/data hash and selected feature indices required")
    shapes = dict(mean=(2,), scale=(2,), w=(3,))
    if cash_enabled:
        shapes["s"] = (3,)
    with np.load(path, allow_pickle=False) as archive:
        if set(archive.files) != set(shapes):
            raise ValueError("Only approved plain model arrays required")
        arrays = {name: archive[name].copy() for name in archive.files}
    for name, shape in shapes.items():
        a = arrays[name]
        if a.shape != shape or a.dtype.kind != "f" or not np.isfinite(a).all():
            raise ValueError("Complete finite frozen array: " + name)
    count = 6 if cash_enabled else 3
    if metadata.get("parameter_count") != count or np.any(arrays["scale"] <= 0):
        raise ValueError("Exact parameter count and positive frozen scales required")
    head = TwoExpertHead(arrays["mean"], arrays["scale"], cash_enabled=cash_enabled)
    head.parameters = {name: arrays[name] for name in ("w", "s") if name in arrays}
    for a in (head.mean, head.scale, *head.parameters.values()):
        a.flags.writeable = False
    head.model_path = Path(path)
    head.model_sha256 = expected_model_sha256
    return head


def check(pack, expected_index_sha256):
    if expected_index_sha256 != INDEX_SHA:
        raise ValueError("Exact predeclared index SHA required")
    train, validation, meta = load_training_and_validation(pack, expected_index_sha256)
    indices = verify_schema(meta)
    mean, scale = training_standardizer(train)
    return dict(status="READY_ZERO_FIT", fit_count=0, new_native_wallets=0,
                training_rows=182, validation_rows=len(validation["contexts"]),
                selected_feature_names=list(FEATURE_NAMES), selected_feature_indices=list(indices),
                mean=mean.tolist(), scale=scale.tolist(), arms=list(ARMS),
                parameter_counts=[3, 6], source_SHA256=source_hashes(),
                feature_schema_SHA256=SCHEMA_SHA, fragment_index_SHA256=INDEX_SHA)


def _require_bounded():
    address_limit = resource.getrlimit(resource.RLIMIT_AS)[0]
    if (os.environ.get("COIN_CLOUD_BOUNDED") != "1" or len(os.sched_getaffinity(0)) != 1
            or not 0 < address_limit <= 1_000_000_000
            or os.environ.get("CUDA_VISIBLE_DEVICES") != ""
            or any(os.environ.get(name) != "1" for name in
                   ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "POLARS_MAX_THREADS"))
            or len(Path("/proc/swaps").read_text().splitlines()) != 1):
        raise RuntimeError("Existing bounded launcher with 1 CPU, 1GB, no swap/GPU required")


def _deadline(began):
    if time.monotonic() - began >= MAX_TOTAL_SECONDS:
        raise TimeoutError("Fixed total120-second two-fit budget exhausted; no restart or retuning")


def fit_fixed_pair(pack, expected_index_sha256, output):
    """Exactly two fixed fits; exclusive guards prohibit restart in this output."""
    began = time.monotonic()
    _require_bounded()
    if expected_index_sha256 != INDEX_SHA:
        raise ValueError("Exact predeclared index SHA required")
    train, validation, meta = load_training_and_validation(pack, expected_index_sha256)
    verify_schema(meta)
    mean, scale = training_standardizer(train)
    before = source_hashes()
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    _exclusive_json(output / "FIT_STARTED.json", dict(arms=list(ARMS), planned_fits=2,
        fragment_index_SHA256=INDEX_SHA, source_SHA256=before, epochs=EPOCHS,
        maximum_total_seconds=MAX_TOTAL_SECONDS, single_cpu=True, address_limit_bytes=1_000_000_000))
    records = {}
    try:
        for arm in ARMS:
            _deadline(began)
            _exclusive_json(output / (arm + "_FIT_STARTED.json"), dict(arm=arm, fit_number=len(records) + 1))
            head = TwoExpertHead(mean, scale, cash_enabled=arm == "WITH_CASH")
            first = {k: np.zeros_like(p) for k, p in head.parameters.items()}
            second = {k: np.zeros_like(p) for k, p in head.parameters.items()}
            with (output / (arm + "_TRAINING.jsonl")).open("x") as trace:
                for epoch in range(1, EPOCHS + 1):
                    _deadline(began)
                    loss, gradient, _ = path_loss_and_gradient(head, train)
                    norm = float(np.sqrt(sum(float((g * g).sum()) for g in gradient.values())))
                    if not np.isfinite(loss) or not np.isfinite(norm):
                        raise ValueError("Nonfinite own-path loss or gradient; stop both arms")
                    clip = min(1., 1. / norm) if norm else 1.
                    for name, p in head.parameters.items():
                        g = gradient[name] * clip
                        first[name] = .9 * first[name] + .1 * g
                        second[name] = .999 * second[name] + .001 * g * g
                        m = first[name] / (1 - .9 ** epoch)
                        v = second[name] / (1 - .999 ** epoch)
                        p -= LEARNING_RATE * m / (np.sqrt(v) + 1e-8)
                    trace.write(json.dumps(dict(epoch=epoch, training_loss=loss,
                                                gradient_norm=norm, clip=clip), allow_nan=False) + "\n")
                    trace.flush()
                    _deadline(began)
            records[arm] = save_model(head, output, arm, meta, before)
        if source_hashes() != before:
            raise ValueError("Source changed during fitting")
        frozen = {arm: load_frozen(output / (arm + ".npz"), record,
                  expected_model_sha256=record["model_SHA256"], cash_enabled=arm == "WITH_CASH")
                  for arm, record in records.items()}
        # Both model byte streams and metadata are frozen BEFORE validation.
        ready = dict(status="FIT_READY", actual_fits=2, refits=0, final_epoch=EPOCHS,
                     model_SHA256={arm: r["model_SHA256"] for arm, r in records.items()},
                     source_SHA256=before, elapsed_seconds=time.monotonic() - began,
                     validation_scored=False)
        _exclusive_json(output / "FIT_READY.json", ready)
        print(json.dumps(ready), flush=True)
        results = {}
        for arm, head in frozen.items():
            _deadline(began)
            loss, _, reports = path_loss_and_gradient(head, [validation])
            report = reports[0]
            request = head.request(np.asarray([c.features() for c in validation["contexts"]]))
            with (output / (arm + "_VALIDATION_REQUESTS.npz")).open("xb") as stream:
                np.savez(stream, request=request,
                         decision_us=np.asarray([c.decision_us for c in validation["contexts"]], np.int64))
            results[arm] = dict(loss=loss, **{k: report[k] for k in
                ("utility_sum", "net_PnL", "fees", "spread", "slippage", "funding", "gross",
                 "terminal_cash_realized", "status")})
            if sha(head.model_path) != head.model_sha256:
                raise ValueError("Frozen model changed during validation")
        _deadline(began)
        result = dict(status="PASS_FIXED_TWO_FITS_PROXY_VALIDATION_ONLY", actual_fits=2,
                      refits=0, new_native_wallets=0, arms=results,
                      elapsed_seconds=time.monotonic() - began)
        _exclusive_json(output / "VALIDATION_RESULTS.json", result)
        return result
    except Exception as error:
        _exclusive_json(output / "FIT_FAILED.json", dict(status="STOP_NO_RESTART", error_type=type(error).__name__,
                        error=str(error), completed_frozen_models=list(records),
                        elapsed_seconds=time.monotonic() - began))
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("check", "fit"))
    parser.add_argument("--pack", type=Path, required=True)
    parser.add_argument("--index-sha256", required=True)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if args.mode == "check":
        if args.output is not None:
            parser.error("check is read-only and takes no output directory")
        result = check(args.pack, args.index_sha256)
    else:
        if args.output is None:
            parser.error("fit requires a unique --output directory")
        result = fit_fixed_pair(args.pack, args.index_sha256, args.output)
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
