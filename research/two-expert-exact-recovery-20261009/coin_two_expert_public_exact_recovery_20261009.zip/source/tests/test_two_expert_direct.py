"""Zero-fit arithmetic, actual native mapper, provenance and gradient checks."""
from copy import deepcopy
import inspect
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pytest

from modules.direct_path.data_adapter import load_training_and_validation
from modules.direct_path.prototype import (Context, CORE5, DAY_US, daily_proxy, mapped_path,
                                           mapping_vjp)
from modules.native_action.e5_inputs import mapper
from modules.native_action import two_expert_direct as direct

PACK = Path(__file__).resolve().parents[2] / "direct_path_fragments"


@pytest.fixture(scope="module")
def bound_data():
    return load_training_and_validation(PACK, direct.INDEX_SHA)


def contexts(count=26, release=True):
    result = []
    for t in range(count):
        decision = (19700 + t) * DAY_US
        market = np.linspace(-.03, .04, 13)
        market[2] = .02 * np.sin(t * .71)
        market[5] = .07 + .013 * np.cos(t * .43)
        targets = np.array([[0.] * 5, [.08, .025, .012, -.01, .003],
                            [-.035, .011, 0., 0., 0.], [0., -.04, 0., 0., 0.],
                            [-.03, .018, -.016, .008, -.002]])
        eligible = np.ones(5, dtype=bool)
        if release and t in (9, 16):
            eligible[1 if t == 9 else 4] = False
        past = np.zeros((30, 5))
        past[:, 0] = np.tile([-.001, .001], 15)
        result.append(Context(decision, decision, targets, eligible, past, market,
                              np.full(5, decision, np.int64)))
    return result


def fragment(cs):
    n = len(cs)
    t = np.arange(n + 1)[:, None]
    prices = 100. * np.exp(.002 * np.sin(t * .81 + np.arange(5)[None, :]))
    funding = np.tile(np.array([.008, -.002, .001, 0., -.001]), (n, 1))
    return dict(contexts=cs, prices=prices, funding_coeff=funding)


def head(cash_enabled, *, nonzero=False):
    h = direct.TwoExpertHead(np.array([0., .07]), np.array([.03, .02]), cash_enabled=cash_enabled)
    if nonzero:
        h.parameters["w"][:] = [.17, .31, -.22]
        if cash_enabled:
            h.parameters["s"][:] = [-.3, .11, .28]
    return h


@pytest.mark.parametrize("cash_enabled,count,initial", [
    (False, 3, [0., .5, 0., 0., .5]),
    (True, 6, [.5, .25, 0., 0., .25]),
])
def test_simplex_exact_parameter_counts_and_cash_activity(cash_enabled, count, initial):
    h = head(cash_enabled)
    x = np.asarray([c.features() for c in contexts(5)])
    requests = h.request(x)
    assert sum(p.size for p in h.parameters.values()) == count
    assert all(np.array_equal(p, np.zeros(3)) for p in h.parameters.values())
    np.testing.assert_array_equal(requests, np.tile(initial, (len(x), 1)))
    assert np.array_equal(requests[:, 2:4], np.zeros((len(x), 2)))
    assert np.array_equal(requests.sum(axis=1), np.ones(len(x)))
    assert np.all(requests >= 0)
    assert not hasattr(h, "fit")
    assert len(direct.FEATURE_NAMES) == 2


def test_constant_zero_head_source_and_stable_sigmoid_have_no_seed_or_clipping():
    source = inspect.getsource(direct.TwoExpertHead.__init__)
    assert "np.zeros(3" in source
    assert "random" not in source and "seed" not in source
    assert "clip" not in inspect.getsource(direct.TwoExpertHead.forward)
    values = direct._sigmoid(np.array([-1000., -3., 0., 3., 1000.]))
    np.testing.assert_allclose(values, [0., 1. / (1. + np.exp(3.)), .5,
                                      1. / (1. + np.exp(-3.)), 1.])
    with pytest.raises(ValueError, match="logits"):
        direct._sigmoid(np.array([np.nan]))


@pytest.mark.parametrize("cash_enabled", [False, True])
def test_only_two_fields_and_each_causal_row_affect_requests(cash_enabled):
    h = head(cash_enabled, nonzero=True)
    x = np.asarray([c.features() for c in contexts(6)])
    before = h.request(x)
    auxiliary = [i for i in range(43) if i not in direct.FEATURE_INDICES]
    modified = x.copy()
    modified[:, auxiliary] = np.arange(len(auxiliary)) + 1000.
    np.testing.assert_array_equal(h.request(modified), before)
    # Changing a past row or a later row never changes the current row request.
    modified = x.copy()
    modified[0, 2] += 1.
    modified[-1, 5] += 1.
    np.testing.assert_array_equal(h.request(modified)[1:-1], before[1:-1])
    assert not np.array_equal(h.request(modified)[[0, -1]], before[[0, -1]])
    for name in direct.FEATURE_INDICES:
        modified = x.copy()
        modified[:, name] += .01
        assert not np.array_equal(h.request(modified), before)
    bad = x.copy()
    bad[0, 11] = np.nan
    with pytest.raises(ValueError, match="original43"):
        h.request(bad)
    with pytest.raises(ValueError, match="original43"):
        h.request(x[:, :2])


def test_bound_feature_names_indices_and_training_only_ddof_zero(bound_data):
    train, val, meta = bound_data
    assert direct.verify_schema(meta) == (2, 5)
    mean, scale = direct.training_standardizer(train)
    original = np.concatenate([np.asarray([c.features() for c in f["contexts"]]) for f in train])
    assert original.shape == (182, 43)
    selected = original[:, [2, 5]]
    np.testing.assert_array_equal(mean, selected.mean(axis=0))
    np.testing.assert_array_equal(scale, np.where(selected.std(axis=0, ddof=0) > 1e-8,
                                                selected.std(axis=0, ddof=0), 1.))
    altered = deepcopy(train)
    for f in altered:
        for c in f["contexts"]:
            c.market13[[2, 5]] = [17., 29.]
    constant_mean, constant_scale = direct.training_standardizer(altered)
    np.testing.assert_array_equal(constant_mean, [17., 29.])
    np.testing.assert_array_equal(constant_scale, [1., 1.])
    with pytest.raises(ValueError, match="training fragments"):
        direct.training_standardizer([*train, val])
    bad = deepcopy(meta)
    bad["feature_names"][2], bad["feature_names"][5] = bad["feature_names"][5], bad["feature_names"][2]
    with pytest.raises(ValueError, match="schema"):
        direct.verify_schema(bad)
    report = direct.check(PACK, direct.INDEX_SHA)
    assert report["status"] == "READY_ZERO_FIT" and report["fit_count"] == 0
    assert report["parameter_counts"] == [3, 6] and report["validation_rows"] == 61


@pytest.mark.parametrize("cash_enabled", [False, True])
def test_exact_existing_native_mapper_release_l1_and_forced_terminal(cash_enabled):
    cs = contexts()
    requests = head(cash_enabled, nonzero=True).request(np.asarray([c.features() for c in cs]))
    targets, records = mapped_path(requests, cs)
    prior = np.eye(5)[0]
    release_seen = False
    for t, (c, request, record) in enumerate(zip(cs, requests, records, strict=True)):
        native_context = SimpleNamespace(expert_eligible=c.eligible, expert_targets=c.expert_targets,
            past_returns30=c.past_returns30, decision_us=c.decision_us,
            binding={"symbol_order": list(CORE5)})
        actual = mapper(prior, request, native_context)
        np.testing.assert_allclose(actual.budget, record["budget"], rtol=0, atol=1e-12)
        np.testing.assert_allclose(actual.targets, record["targets"], rtol=0, atol=1e-12)
        assert np.abs(record["budget"] - record["released_prior"]).sum() <= .1 + 1e-12
        if not c.eligible.all():
            release_seen |= not np.array_equal(record["released_prior"], prior)
            assert record["budget"][~c.eligible].sum() == 0.
        if t < len(cs) - 1:
            np.testing.assert_array_equal(targets[t], record["targets"])
        prior = np.asarray(actual.budget)
    assert release_seen
    np.testing.assert_array_equal(targets[-1], np.zeros(5))
    gradient = np.arange(len(cs) * 5).reshape(len(cs), 5) / 100.
    np.testing.assert_array_equal(mapping_vjp(gradient, records, cs)[-1], np.zeros(5))
    terminal_only = np.zeros_like(gradient)
    terminal_only[-1] = 1.
    np.testing.assert_array_equal(mapping_vjp(terminal_only, records, cs), np.zeros_like(gradient))


@pytest.mark.parametrize("cash_enabled", [False, True])
def test_head_analytic_gradient_matches_each_parameter_difference(cash_enabled):
    h = head(cash_enabled, nonzero=True)
    x = np.asarray([c.features() for c in contexts(6)])
    request, cache = h.forward(x)
    request_gradient = np.linspace(-.41, .53, request.size).reshape(request.shape)
    analytic = h.backward(request_gradient, cache)
    step = 1e-6
    for name, p in h.parameters.items():
        for i in range(3):
            original = p[i]
            p[i] = original + step
            plus = float((h.request(x) * request_gradient).sum())
            p[i] = original - step
            minus = float((h.request(x) * request_gradient).sum())
            p[i] = original
            assert analytic[name][i] == pytest.approx((plus - minus) / (2 * step), abs=1e-9)


@pytest.mark.parametrize("cash_enabled", [False, True])
def test_own_path_full_chain_gradient_both_arms_and_no_teacher(cash_enabled):
    h = head(cash_enabled, nonzero=True)
    f = fragment(contexts())  # no teacher labels supplied or consulted
    before = {name: p.copy() for name, p in h.parameters.items()}
    loss, analytic, reports = direct.path_loss_and_gradient(h, [f])
    assert np.isfinite(loss)
    assert reports[0]["terminal_cash_realized"]
    assert reports[0]["fees"] > 0 and reports[0]["spread"] > 0 and reports[0]["slippage"] > 0
    assert reports[0]["funding"] != 0
    assert np.any(reports[0]["net_return"] < 0)
    np.testing.assert_array_equal(reports[0]["quantity"][-1], np.zeros(5))
    assert loss == -reports[0]["utility_sum"] / len(f["contexts"])
    step = 1e-5
    for name, p in h.parameters.items():
        for i in range(3):
            original = p[i]
            p[i] = original + step
            plus = direct.path_loss_and_gradient(h, [f])[0]
            p[i] = original - step
            minus = direct.path_loss_and_gradient(h, [f])[0]
            p[i] = original
            assert analytic[name][i] == pytest.approx((plus - minus) / (2 * step), abs=2e-9)
        np.testing.assert_array_equal(p, before[name])
    targets, records = mapped_path(h.request(np.asarray([c.features() for c in f["contexts"]])), f["contexts"])
    proxy = daily_proxy(targets, f["prices"], f["funding_coeff"])
    np.testing.assert_array_equal(proxy["nav"], reports[0]["nav"])
    assert proxy["utility_sum"] == reports[0]["utility_sum"]


@pytest.mark.parametrize("cash_enabled", [False, True])
def test_plain_npz_frozen_round_trip_and_metadata_validation(tmp_path, bound_data, cash_enabled):
    _, _, meta = bound_data
    h = head(cash_enabled, nonzero=True)
    arm = "WITH_CASH" if cash_enabled else "NO_CASH"
    record = direct.save_model(h, tmp_path, arm, meta, direct.source_hashes())
    path = tmp_path / (arm + ".npz")
    frozen = direct.load_frozen(path, record, expected_model_sha256=record["model_SHA256"],
                                cash_enabled=cash_enabled)
    x = np.asarray([c.features() for c in contexts(4)])
    np.testing.assert_array_equal(frozen.request(x), h.request(x))
    assert all(not p.flags.writeable for p in (frozen.mean, frozen.scale, *frozen.parameters.values()))
    with np.load(path, allow_pickle=False) as z:
        assert set(z.files) == ({"mean", "scale", "w", "s"} if cash_enabled else {"mean", "scale", "w"})
    for key, value in [("selected_feature_indices", [5, 2]), ("source_SHA256", {}),
                       ("feature_schema_SHA256", "0" * 64), ("parameter_count", 397),
                       ("cash_enabled", not cash_enabled), ("fragment_index_SHA256", "0" * 64)]:
        invalid = deepcopy(record)
        invalid[key] = value
        with pytest.raises(ValueError):
            direct.load_frozen(path, invalid, expected_model_sha256=record["model_SHA256"],
                               cash_enabled=cash_enabled)
    with pytest.raises(ValueError):
        direct.load_frozen(path, record, expected_model_sha256="0" * 64, cash_enabled=cash_enabled)


@pytest.mark.parametrize("fault", ["extra", "shape", "nan", "zero_scale", "integer", "missing_s"])
def test_bad_model_arrays_rejected(tmp_path, bound_data, fault):
    _, _, meta = bound_data
    h = head(True)
    arrays = dict(mean=h.mean.copy(), scale=h.scale.copy(), **{k: p.copy() for k, p in h.parameters.items()})
    if fault == "extra":
        arrays["unapproved"] = np.zeros(1)
    elif fault == "shape":
        arrays["w"] = np.zeros(4)
    elif fault == "nan":
        arrays["s"][0] = np.nan
    elif fault == "zero_scale":
        arrays["scale"][0] = 0.
    elif fault == "integer":
        arrays["w"] = np.zeros(3, dtype=np.int64)
    elif fault == "missing_s":
        del arrays["s"]
    path = tmp_path / "invalid.npz"
    np.savez(path, **arrays)
    digest = direct.sha(path)
    record = direct.model_metadata(h, "WITH_CASH", meta, direct.source_hashes(), digest)
    with pytest.raises(ValueError):
        direct.load_frozen(path, record, expected_model_sha256=digest, cash_enabled=True)


def test_exclusive_start_guard_and_runtime_budget_checks(tmp_path, monkeypatch):
    path = tmp_path / "FIT_STARTED.json"
    direct._exclusive_json(path, {"planned_fits": 2})
    before = path.read_bytes()
    with pytest.raises(FileExistsError):
        direct._exclusive_json(path, {"planned_fits": 4})
    assert path.read_bytes() == before
    direct._require_bounded()  # tests themselves must use the bounded launcher
    monkeypatch.setenv("COIN_CLOUD_BOUNDED", "0")
    with pytest.raises(RuntimeError, match="1 CPU, 1GB"):
        direct._require_bounded()
    monkeypatch.setattr(direct.time, "monotonic", lambda: 121.)
    with pytest.raises(TimeoutError, match="total120"):
        direct._deadline(0.)
