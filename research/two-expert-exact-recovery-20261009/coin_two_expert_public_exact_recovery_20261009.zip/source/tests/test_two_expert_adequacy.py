"""Synthetic zero-fit checks for continuation math and stopping contracts.

Only pure helper definitions are loaded. No data, wallet, objective, or fit
entrypoint is imported or executed, including when the repository is missing.
"""
import ast
from pathlib import Path
from types import SimpleNamespace
import unittest

import numpy as np


def helpers():
    here = Path(__file__).resolve()
    candidates = (here.parent / "two_expert_adequacy.py",
                  here.parent.parent / "modules/native_action/two_expert_adequacy.py")
    source = next(path for path in candidates if path.is_file())
    tree = ast.parse(source.read_text(), filename=str(source))
    constants = {"CHECKPOINT_INTERVAL", "MINIMUM_EPOCH", "PLATEAU_ABSOLUTE_DELTA",
                 "PLATEAU_CONSECUTIVE_DELTAS"}
    functions = {"_adam_update", "_verify_exact_recovery", "_checkpoint", "plateau_decision"}
    nodes = [node for node in tree.body
             if isinstance(node, ast.FunctionDef) and node.name in functions
             or isinstance(node, ast.Assign) and any(
                 isinstance(target, ast.Name) and target.id in constants for target in node.targets)]
    direct = SimpleNamespace(LEARNING_RATE=.001)
    namespace = {"np": np, "direct": direct, "coefficient_hashes": lambda head: {}}
    exec(compile(ast.Module(body=nodes, type_ignores=[]), str(source), "exec"), namespace)
    return SimpleNamespace(**namespace)


class AdequacyZeroFitTests(unittest.TestCase):
    def setUp(self):
        self.h = helpers()

    def test_plateau_is_absolute_and_requires_two_changes_and_minimum(self):
        plateau = self.h.plateau_decision
        self.assertFalse(plateau([2., 2. + 2e-7, 2. + 4e-7], 192))
        self.assertFalse(plateau([2., 2. + 2e-7], 256))
        self.assertTrue(plateau([2., 2. + 2e-7, 2. + 4e-7], 256))
        self.assertTrue(plateau([2., 2. - 2e-7, 2. - 4e-7], 256))
        self.assertFalse(plateau([2., 1., 0.], 256))
        self.assertFalse(plateau([0., 1e-6, 2e-6], 256))
        self.assertFalse(plateau([2., 2., float("nan")], 256))

    def test_adam_matches_original_operation_order_for64_synthetic_steps(self):
        for names in (("w",), ("w", "s")):
            head = SimpleNamespace(parameters={name: np.zeros(3, np.float64) for name in names})
            first = {name: np.zeros(3, np.float64) for name in names}
            second = {name: np.zeros(3, np.float64) for name in names}
            reference = {name: np.zeros(3, np.float64) for name in names}
            ref_first = {name: np.zeros(3, np.float64) for name in names}
            ref_second = {name: np.zeros(3, np.float64) for name in names}
            for epoch in range(1, 65):
                gradient = {name: np.asarray([np.sin(epoch + i), np.cos(epoch + i),
                                               epoch / 10.], np.float64)
                            for i, name in enumerate(names)}
                norm = float(np.sqrt(sum(float((g * g).sum()) for g in gradient.values())))
                clip = min(1., 1. / norm) if norm else 1.
                for name, p in reference.items():
                    g = gradient[name] * clip
                    ref_first[name] = .9 * ref_first[name] + .1 * g
                    ref_second[name] = .999 * ref_second[name] + .001 * g * g
                    m = ref_first[name] / (1 - .9 ** epoch)
                    v = ref_second[name] / (1 - .999 ** epoch)
                    p -= .001 * m / (np.sqrt(v) + 1e-8)
                actual_norm, actual_clip = self.h._adam_update(head, gradient, first, second, epoch)
                self.assertEqual(actual_norm, norm)
                self.assertEqual(actual_clip, clip)
                for actual, expected in ((head.parameters, reference), (first, ref_first),
                                         (second, ref_second)):
                    for name in names:
                        self.assertEqual(actual[name].tobytes(), expected[name].tobytes())

    def test_recovery_rejects_roundoff_and_signed_zero(self):
        def head(value):
            return SimpleNamespace(mean=np.zeros(2), scale=np.ones(2),
                                   parameters={"w": np.asarray(value, np.float64)})
        self.h._verify_exact_recovery(head([0., 1., 2.]), head([0., 1., 2.]))
        with self.assertRaises(ValueError):
            self.h._verify_exact_recovery(head([0., 1., 2.]), head([-0., 1., 2.]))
        with self.assertRaises(ValueError):
            self.h._verify_exact_recovery(head([0., 1., 2.]),
                                         head([0., 1., np.nextafter(2., 3.)]))

    def test_checkpoint_loss_uses_completed_parameters_and_absolute_changes(self):
        state = dict(head=SimpleNamespace(parameters={"w": np.zeros(3)}), step=64,
                     previous_checkpoint_loss=None, consecutive_small_deltas=0, checkpoints=[])
        for epoch, loss in ((64, 3.), (128, 2.), (192, 2. + 2e-7), (256, 2. + 4e-7)):
            state["step"] = epoch
            self.h.direct.path_loss_and_gradient = lambda head, fragments: (loss, {}, [])
            checkpoint, plateau = self.h._checkpoint(state, [])
            self.assertEqual(checkpoint["training_loss"], loss)
            self.assertEqual(plateau, epoch == 256)
        state["step"] = 257
        self.h.direct.path_loss_and_gradient = lambda *_: self.fail("Non-checkpoint objective call")
        with self.assertRaises(ValueError):
            self.h._checkpoint(state, [])

    def test_nonfinite_gradient_stops_before_update(self):
        head = SimpleNamespace(parameters={"w": np.zeros(3)})
        first, second = {"w": np.zeros(3)}, {"w": np.zeros(3)}
        with self.assertRaises(ValueError):
            self.h._adam_update(head, {"w": np.array([float("nan"), 0., 0.])}, first, second, 1)
        self.assertEqual(head.parameters["w"].tobytes(), np.zeros(3).tobytes())


if __name__ == "__main__":
    unittest.main()
