# Fixed optimizer-adequacy continuation

Restore the original exact recovery ZIP at commit 11ac7267dd1a7e4a77a57c47e4308539730abb64, overlay runtime-delta from commit 4984b5a73a707001a342c1c4940215e62fd8ade1, then extract this supplement into the same workspace. All paths are relative. Exact original math, inputs and both64-step checkpoint arrays reproduced before continuation. Both arms reached the predeclared1024-step cap; neither met the training-only plateau criterion. Terminal models and full Adam states are saved. No additional model fit or native wallet was performed by this preservation operation.

May-June2024 daily-proxy validation is development evidence, not native execution certification. Native validation remains dependent on recovery of the unchanged engine, complete original-minute sources and reference-control evidence. The four original control results are transcribed in the original recovery ZIP; their lost journal bodies are not represented as recovered here.

The regime_ranking_screen source body is included only to reproduce the explicitly verified current provenance. e5_inputs and conditional_selector_core remain labelled unavailable historical provenance-only bodies. They are not imported into fitting. Check verify_completed_output before a native consumer loads any head with bound_runtime().
