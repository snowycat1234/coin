# Frozen two-origin development diagnostic

Start with REPORT.md. This packet is prepared locally and has not been published.

- code/shared_selector.py: the frozen 15-parameter weighted linear solver and reporting logic.
- inputs/raw_fixture.json: one clean derived raw-feature fixture, excluding the old full-506 scaler and z fields. The original supervised mask describes label completeness under its preparation cutoff; fold training separately applies the stricter origin-specific label cutoff. Forecast selection uses available_mask only.
- inputs/*_prefix_standardized.json: audit exports under each saved prefix-only scaler, with null missing vectors and exact fold weights. These are preprocessing outputs, not alternative training fixtures or models.
- models/: the two sealed coefficient/scaler objects and fit receipts.
- protocol/: legal protocol, metadata-only feasibility, original definitions and blocked-plan correction history.
- results/: all 36 forecasts and controls, per-fold frozen choices, and primary/secondary summaries.
- tests/: nine pre-fit tests and no-refit post-fit verification, plus execution outputs.
- receipts/: authorization, actual timestamps, versions, objective/gradient checks and run log.

JSON arrays follow the ordered experts and feature_names in the raw fixture. The first ten model parameters are shared feature weights; the next five are penalized biases for noncash experts in original order. The CASH score is always zero.

Running tests/test_structural.py only solves a synthetic system; tests/verify_sealed.py checks the saved real models without solving. Do not rerun code/shared_selector.py: it deliberately refuses when any sealed model exists. Reproduction requiring another real fit is a separate authorization decision.

All results are utility diagnostics on already-known development data. The five primary separated dates do not establish independence. No investment, advantage, APR, fresh-OOS or deployment conclusion is supported.

## Unpack and verify without refitting

Unzip the complete reproduction archive, then run these commands from its public_package directory:

    python tests/test_structural.py
    python tests/verify_sealed.py
    python tests/check_saved_outputs.py .

The structural suite uses synthetic data only for its solver test; the other checkers read sealed coefficients and never refit. Do not invoke code/shared_selector.py on the real fixture. The manifest lists the size and SHA-256 of every packaged derived file (except the manifest itself). Separate archive metadata identifies the complete ZIP.
