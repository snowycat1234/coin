# Run authorization and scope

The coordinating task explicitly authorized only the November 12 and December 10 legal folds after the final reporting clarification. This authorization superseded the historical NO FIT preparation status solely for those two origins. The historical July/October plan remained blocked by the November 4 pool-knowledge clock.

Exactly one actual solve per legal origin completed on October 15, 2026. The actual start/end UTC timestamps are recorded in fit_receipts.json. Both model files were sealed before their forecast choices and outcomes were evaluated. No later outcome-dependent model changes or additional fits occurred. No full-506 fit, 2024 scoring, new external download, hidden holdout access, publication, or trading was authorized or performed.

The original raw training fixture had previously been source-audited, including per-expert causal rank receipts. The current run used only a new sanitized derived fixture with raw features and available utility labels; the original full-fixture scaler and z fields were deliberately omitted. Each model uses only its permitted prefix for fitting and scaling. The pool clock is checked separately and literally. Original source hashes and private paths are intentionally omitted from this clean packet.
