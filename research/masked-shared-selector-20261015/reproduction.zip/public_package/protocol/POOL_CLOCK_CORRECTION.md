# Pool knowledge clock correction — no fitting

The July 1 and October 1 proposal is BLOCKED. ROLLING_DEV_PROTOCOL.md retains its entire earlier text with a blocking notice; its 22 primary dates and 170 secondary dates must not be scored under that proposal.

Exact binding evidence: pool_selection_available_us is 1699056000000000, equivalent to 2023-11-04 00:00:00 UTC. Its pool_selection_rule is "Fixed unscreened structural mechanism library; no scoring utility or profit used to select experts". The original run_conditional_selector.py, lines 552–553, checks `if int(binding["pool_selection_available_us"]) > folds[0]["start_us"]:` and raises `ValueError("Expert pool selection occurs after the first validation start")`.

Thus this is an explicit pool-level validation-start gate, in addition to per-expert target/model clocks. Earlier valid expert receipts do not imply that the final expert pool was admissibly known then. A retrospective disclaimer does not waive that guard. The locally recovered source includes the binding artifact and its consumer, but no construction statement assigning that timestamp was located; its derivation cannot be asserted to be merely the latest model completion. Until authoritative construction evidence proves otherwise, retain the literal gate and do not backdate the pool.

The source also explicitly says these are previously seen chronological development data and that current code versions are not claimed to have existed historically. A later origin can satisfy the saved simulated availability contract, but cannot establish real contemporaneous issuance or genuinely unseen validation.

Metadata-only alternatives were counted without using outcomes to choose dates: December 1 alone leaves 17 daily states and only three disjoint dates. The parent-predeclared November 12 and December 10 origins preserve more permitted 2023 coverage: 36 daily states and five globally disjoint dates. LEGAL_TWO_ORIGIN_PROTOCOL.md freezes that sole next candidate. It remains NO FIT pending root GO.
