"""Checks sealed parameters and reported arithmetic without fitting or solving."""
import sys,json,math
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'code'))
import shared_selector as s
import numpy as np
p=json.loads((s.ROOT/'inputs/raw_fixture.json').read_text());results=json.loads((s.ROOT/'results/all_36_dates.json').read_text());summary=json.loads((s.ROOT/'results/summary.json').read_text())
cash=p['experts'].index('CASH');sources={r['date']:r for r in p['rows']}
for origin in s.ORIGINS:
    model=json.loads((s.ROOT/'models'/f'{origin}.json').read_text());train=s.prefix(p['rows'],origin,p['pool_selection_available_us'])
    X,y,q,scaler=s.design(train,cash);theta=np.asarray(model['theta']);assert scaler==model['scaler']
    assert max(abs(s.gradient(theta,X,y,q)))<=1e-8 and len(theta)==15
    assert model['receipt']['fit_number_for_origin']==1 and model['receipt']['one_cpu_affinity']==1
    assert model['receipt']['elapsed_seconds']<=120
    s.validate(train,cash)
    for r in [r for r in results if r['origin']==origin]:
        source=sources[r['date']];score=s.scores({'x':source['x'],'available_mask':source['available_mask']},model,cash)
        assert score==r['scores'] and p['experts'][s.choose(score,cash)]==r['choice']
        assert r['chosen_utility']==source['utility'][p['experts'].index(r['choice'])]
        assert r['oracle_utility']==max(source['utility'])
        assert r['regret']==r['oracle_utility']-r['chosen_utility']
assert len(results)==36 and len({r['date'] for r in results})==36
assert [r['date'] for r in results if r['primary']]==s.disjoint(results)==summary['primary_dates']
for view in ['primary_5','secondary_36']:
    subset=[r for r in results if r['primary']] if view=='primary_5' else results
    for group in ['pooled',*s.ORIGINS]:
        rows=[r for r in subset if group=='pooled' or r['origin']==group];m=summary[view][group];n=len(rows)
        assert m['dates']==n
        for metric,field in [('mean_chosen_utility','chosen_utility'),('mean_regret','regret'),('mean_oracle_utility','oracle_utility')]:
            assert math.isclose(m[metric],math.fsum(r[field] for r in rows)/n,abs_tol=1e-15)
        for j,e in enumerate(p['experts']):
            c=m['controls'][e]
            assert c['available_dates']==n and c['cash_fallback_dates']==0
            assert math.isclose(c['mean_utility'],math.fsum(r['controls'][e]['utility'] for r in rows)/n,abs_tol=1e-15)
            assert math.isclose(c['mean_paired_chosen_minus_control'],math.fsum(r['chosen_utility']-r['controls'][e]['utility'] for r in rows)/n,abs_tol=1e-15)
print('PASS: sealed-model gradients and prefix scalers, all 36 choices/utilities, global primary admissions, direct equal-date means, all paired controls and availability counts; no solve or refit.')
s.write(s.ROOT/'receipts/post_fit_checks.json',{'passed':True,'completed_utc':s.now(),'additional_fits':0,'dates_verified':36,'primary_dates_verified':5})
