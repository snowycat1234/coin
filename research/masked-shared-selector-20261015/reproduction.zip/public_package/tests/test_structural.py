"""Synthetic tests first; real-data checks inspect admission metadata only, no actual fits."""
import sys,json,copy,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'code'))
import shared_selector as s
import numpy as np

def row(t,available=(True,True,False,False,False,False),value=1):
    return {'date':str(t),'decision_us':t,'label_available_us':t+7*s.DAY+120000001,
        'available_mask':list(available),'supervised_mask':list(available),
        'x':[[value]*10 if a else None for a in available],
        'utility':[0 if j==0 else float(value+j) if a else None for j,a in enumerate(available)]}

class Structural(unittest.TestCase):
    def test_pool_rejects_old_origins(self):
        for origin in ['2023-07-01','2023-10-01']:
            with self.assertRaisesRegex(ValueError,'pool selection'):s.prefix([],origin,s.us('2023-11-04'))
    def test_strict_cutoff_both_origins(self):
        for origin in s.ORIGINS:
            cutoff=s.us(origin)-7*s.DAY
            rows=[{'decision_us':cutoff-8*s.DAY,'label_available_us':cutoff+d} for d in [-1,0,1]]
            self.assertEqual(s.prefix(rows,origin,s.us('2023-11-04')),[rows[0]])
    def test_loss_weighting_excludes_cash_missing(self):
        rows=[row(0),row(s.DAY,(True,True,True,False,False,False),3)]
        X,y,q,scaler=s.design(rows,0)
        np.testing.assert_array_equal(q,[.5,.25,.25]);self.assertEqual(X.shape,(3,15))
        self.assertAlmostEqual(scaler['mean'][0],2)
        self.assertAlmostEqual(scaler['variance'][0],1)
        np.testing.assert_allclose(np.sum(X[:,:10]*q[:,None],axis=0),0,atol=1e-15)
        altered=copy.deepcopy(rows);altered[0]['x'][0]=[1e100]*10
        np.testing.assert_array_equal(X,s.design(altered,0)[0])
        theta=np.arange(15)/10
        manual=sum(.5*q[i]*(X[i]@theta-y[i])**2 for i in range(3))+.5*sum(theta**2)
        self.assertAlmostEqual(s.objective(theta,X,y,q),manual)
    def test_zero_variance_and_cash_ties(self):
        X,y,q,scaler=s.design([row(0)],0)
        self.assertTrue(all(scaler['zero_variance_mask']));self.assertTrue(np.all(X[:,:10]==0))
        model={'theta':[0.0]*15,'scaler':scaler}
        self.assertEqual(s.scores({'x':row(0)['x'],'available_mask':row(0)['available_mask']},model,0),[0,0,None,None,None,None])
        self.assertEqual(s.choose([0,0,None,None,None,None],0),0)
        self.assertEqual(s.choose([0,1,1,None,None,None],0),1)
        self.assertEqual(s.choose([0,-1,None,None,None,None],0),0)
    def test_normal_equations_and_finite_difference_gradient(self):
        rng=np.random.default_rng(1221);X=rng.normal(size=(40,15));y=rng.normal(size=40);q=np.full(40,1/40)
        theta,loss,g=s.solve(X,y,q);self.assertLess(g,1e-12)
        np.testing.assert_allclose((X.T@(q[:,None]*X)+np.eye(15))@theta,X.T@(q*y),atol=1e-12)
        probe=rng.normal(size=15);eps=1e-6
        fd=np.asarray([(s.objective(probe+eps*np.eye(15)[k],X,y,q)-s.objective(probe-eps*np.eye(15)[k],X,y,q))/(2*eps) for k in range(15)])
        np.testing.assert_allclose(s.gradient(probe,X,y,q),fd,atol=1e-8)
    def test_global_nonoverlap_no_origin_reset(self):
        rows=[row(s.us('2023-11-12')+i*s.DAY) for i in range(36)]
        self.assertEqual(s.disjoint(rows),[rows[i]['date'] for i in [0,8,16,24,32]])
        self.assertNotIn(rows[28]['date'],s.disjoint(rows))
    def test_prefix_only_no_global_standardizer(self):
        origin=s.ORIGINS[0];rows=[row(s.us('2023-10-20')),row(s.us('2023-10-21'),value=2),row(s.us('2023-11-12'),value=1e100)]
        train=s.prefix(rows,origin,s.us('2023-11-04'));a=s.design(train,0)
        rows[-1]['x'][1]=[-1e100]*10
        b=s.design(s.prefix(rows,origin,s.us('2023-11-04')),0)
        self.assertEqual(a[3],b[3]);self.assertAlmostEqual(a[3]['mean'][0],1.5)
        raw=json.loads((s.ROOT/'inputs/raw_fixture.json').read_text())
        self.assertNotIn('scaler',raw);self.assertTrue(all('z' not in r for r in raw['rows']))
    def test_forecast_independent_of_future_labels(self):
        r=row(0);_,_,_,scaler=s.design([r],0);model={'theta':[0.0]*10+[.1]*5,'scaler':scaler}
        expected=s.scores(r,model,0);del r['utility'];del r['supervised_mask'];del r['label_available_us']
        self.assertEqual(s.scores(r,model,0),expected)
    def test_real_metadata_counts(self):
        p=json.loads((s.ROOT/'inputs/raw_fixture.json').read_text());all_forecast=[]
        for origin,end,expected in zip(s.ORIGINS,s.ENDS,s.EXPECTED):
            train=s.prefix(p['rows'],origin,p['pool_selection_available_us'])
            forecast=[r for r in p['rows'] if s.us(origin)<=r['decision_us']<s.us(end)]
            self.assertEqual((len(train),len(s.disjoint(train)),sum(sum(r['supervised_mask'])-1 for r in train),len(forecast)),expected)
            self.assertTrue(all(all(r['available_mask']) for r in forecast));all_forecast+=forecast
        self.assertEqual(s.disjoint(all_forecast),['2023-11-12','2023-11-20','2023-11-28','2023-12-06','2023-12-14'])

if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Structural))
    if not result.wasSuccessful():sys.exit(1)
    s.write(s.ROOT/'tests/PASS.json',{'passed':True,'tests':result.testsRun,'completed_utc':s.now(),'actual_data_fits':0,'synthetic_solve_only':True})
