"""Read-only portable audit. Usage: python check_saved_outputs.py PACKAGE_DIRECTORY.
Never imports experiment code, solves, optimizes, fits, or reads outside the package.
"""
import json, sys, datetime as dt
from pathlib import Path
import numpy as np
root=Path(sys.argv[1])
def read(p): return json.loads((root/p).read_text())
def close(a,b): np.testing.assert_allclose(a,b,rtol=1e-11,atol=1e-13)
def us(s):return int(dt.datetime.fromisoformat(s).replace(tzinfo=dt.timezone.utc).timestamp()*1e6)
def disjoint(rows):
    stop=-1; dates=[]
    for r in rows:
        if r['decision_us']>=stop:dates.append(r['date']);stop=r['label_available_us']
    return dates
p=read('inputs/raw_fixture.json'); rows=p['rows']; experts=p['experts']; cash=experts.index('CASH'); nc=[j for j in range(6) if j!=cash]; day=86400000000
assert len(rows)==506 and all(r['date']<'2024' for r in rows)
assert p['pool_selection_available_us']==us('2023-11-04')
assert len({r['date'] for r in rows})==506 and rows==sorted(rows,key=lambda r:r['decision_us'])
for r in rows:
    assert r['decision_us']==us(r['date']) and r['label_available_us']==r['decision_us']+7*day+120000001
    assert len(r['available_mask'])==len(r['supervised_mask'])==6
    assert r['utility'][cash]==0
    for j in range(6):
        a=r['available_mask'][j];m=r['supervised_mask'][j]
        assert not m or a
        assert (r['utility'][j] is not None)==bool(m)
        if a:
            assert np.shape(r['x'][j])==(10,) and np.isfinite(r['x'][j]).all()
            c=r['clocks'][j];assert c['target_available_us']<=r['decision_us'] and c['latest_feedback_available_us']<r['decision_us']
            assert c['feedback_count']==30 and c['feedback_last_decision_us']<r['decision_us']
            assert c['feedback_last_decision_us']-c['feedback_first_decision_us']==29*day
        else: assert r['x'][j] is None and r['clocks'][j] is None
receipts=read('receipts/fit_receipts.json'); all_results=read('results/all_36_dates.json'); summary=read('results/summary.json')
assert len(receipts)==2 and len(all_results)==36
report={'audit_mode':'Read-only saved-coefficient reconstruction; no fit, solve, optimizer, new data, or holdout access.','folds':[]}
for i,(origin,end,N,D,M,V) in enumerate([('2023-11-12','2023-12-10',456,64,2042,28),('2023-12-10','2023-12-18',484,68,2182,8)]):
    assert p['pool_selection_available_us']<=us(origin)
    train=[r for r in rows if r['decision_us']<us(origin) and r['label_available_us']<us(origin)-7*day]
    val=[r for r in rows if us(origin)<=r['decision_us']<us(end)]
    assert (len(train),len(disjoint(train)),len(val))==(N,D,V)
    xs=[];ys=[];qs=[];bias=[]
    for r in train:
        eligible=[j for j in nc if r['supervised_mask'][j]]
        assert eligible
        for j in eligible:xs.append(r['x'][j]);ys.append(r['utility'][j]);qs.append(1/(N*len(eligible)));bias.append(nc.index(j))
    x=np.array(xs);y=np.array(ys);q=np.array(qs);assert len(y)==M;close(sum(q),1)
    mu=(x*q[:,None]).sum(axis=0);var=((x-mu)**2*q[:,None]).sum(axis=0);zero=var==0;scale=np.where(zero,1,np.sqrt(var));z=(x-mu)/scale;z[:,zero]=0
    X=np.concatenate((z,np.eye(5)[bias]),axis=1)
    model=read('models/'+origin+'.json');theta=np.array(model['theta']);assert theta.shape==(15,) and np.isfinite(theta).all()
    assert model['parameters']==15 and model['lambda']==1 and model['cash_score']==0 and model['origin']==origin
    assert model['experts']==experts and model['feature_names']==p['feature_names']
    for key,value in [('mean',mu),('variance',var),('scale',scale),('zero_variance_mask',zero)]:close(model['scaler'][key],value)
    residual=X@theta-y;objective=.5*sum(q*residual**2)+.5*sum(theta**2)
    gradient=X.T@(q*residual)+theta;normal=(X.T@(q[:,None]*X)+np.eye(15))@theta-X.T@(q*y)
    assert max(abs(gradient))<=1e-8 and max(abs(normal))<=1e-8
    receipt=receipts[i];assert receipt==model['receipt'] and receipt['origin']==origin and receipt['fit_number_for_origin']==1
    assert receipt['training_dates']==N and receipt['training_disjoint_admissions']==D and receipt['training_noncash_observations']==M
    assert receipt['training_disjoint_dates']==disjoint(train)
    assert receipt['training_first_date']==train[0]['date'] and receipt['training_last_date']==train[-1]['date']
    assert receipt['training_label_strict_cutoff_us']==us(origin)-7*day
    assert receipt['maximum_training_label_available_us']==max(r['label_available_us'] for r in train)
    assert receipt['training_per_expert']=={e:sum(r['supervised_mask'][j] for r in train) for j,e in enumerate(experts)}
    assert receipt['one_cpu_affinity']==receipt['blas_threads']==1 and receipt['elapsed_seconds']<=120
    assert not receipt['historical_issuance_claim'];close(receipt['objective'],objective);close(receipt['gradient_infinity_norm'],max(abs(gradient)))
    frozen=read('results/'+origin+'_frozen_choices.json');assert len(frozen)==V
    for r,f in zip(val,frozen):
        assert all(r['available_mask']);scores=[0.0]*6
        for b,j in enumerate(nc):
            v=(np.array(r['x'][j])-mu)/scale;v[zero]=0;scores[j]=float(v@theta[:10]+theta[10+b])
        chosen=cash
        for j in nc:
            if scores[j]>scores[chosen]:chosen=j
        close(f['scores'],scores);assert f['date']==r['date'] and f['origin']==origin and f['choice']==experts[chosen]
        result=next(a for a in all_results if a['date']==r['date'])
        for k in f:assert result[k]==f[k]
        assert result['decision_us']==r['decision_us'] and result['label_available_us']==r['label_available_us'] and result['available_mask']==r['available_mask']
        close(result['chosen_utility'],r['utility'][chosen]);close(result['oracle_utility'],max(r['utility']));close(result['regret'],max(r['utility'])-r['utility'][chosen])
        for j,e in enumerate(experts):assert result['controls'][e]=={'choice':e,'utility':r['utility'][j]}
    report['folds'].append({'origin':origin,'training_dates':N,'disjoint_training_admissions':D,'forecast_dates':V,'objective':objective,'gradient_infinity_norm':float(max(abs(gradient))),'normal_equation_infinity_norm':float(max(abs(normal)))})
assert all_results==sorted(all_results,key=lambda r:r['decision_us'])
primary=disjoint(all_results);assert primary==summary['primary_dates']==['2023-11-12','2023-11-20','2023-11-28','2023-12-06','2023-12-14']
assert all(r['primary']==(r['date'] in primary) for r in all_results)
for setname in ('primary_5','secondary_36'):
    sample=[r for r in all_results if setname=='secondary_36' or r['primary']]
    for group,s in summary[setname].items():
        rr=[r for r in sample if group=='pooled' or r['origin']==group];assert s['dates']==len(rr)
        for key,field in [('mean_chosen_utility','chosen_utility'),('mean_oracle_utility','oracle_utility'),('mean_regret','regret')]:close(s[key],np.mean([r[field] for r in rr]))
        assert s['choice_counts']=={e:sum(r['choice']==e for r in rr) for e in experts}
        for j,e in enumerate(experts):
            c=s['controls'][e];close(c['mean_utility'],np.mean([r['controls'][e]['utility'] for r in rr]));close(c['mean_paired_chosen_minus_control'],np.mean([r['chosen_utility']-r['controls'][e]['utility'] for r in rr]))
            assert c['available_dates']==sum(r['available_mask'][j] for r in rr) and c['cash_fallback_dates']==sum(not r['available_mask'][j] for r in rr)
close(summary['primary_5']['pooled']['mean_chosen_utility'],-.0004418059841612062);close(summary['secondary_36']['pooled']['mean_chosen_utility'],.000537621041828531)
assert summary['primary_5']['pooled']['choice_counts']['CASH']==4 and summary['primary_5']['pooled']['choice_counts']['DONCHIAN_EXIT10']==1
assert summary['secondary_36']['pooled']['choice_counts']['CASH']==31 and summary['secondary_36']['pooled']['choice_counts']['DONCHIAN_EXIT10']==5
log=(root/'receipts/run_log.txt').read_text().splitlines();assert sum(x.startswith('FIT_START ') for x in log)==2 and sum(x.startswith('FIT_SEALED ') for x in log)==2
assert 'BLOCKED' in (root/'protocol/ROLLING_DEV_PROTOCOL.md').read_text()
report.update(status='PASS',primary_dates=primary,primary_utility=summary['primary_5']['pooled']['mean_chosen_utility'],secondary_utility=summary['secondary_36']['pooled']['mean_chosen_utility'],limits='Tiny known-development source-utility diagnostic only. Receipts record two actual fits; absence of unrecorded activity is not independently provable from artifacts. No return, advantage, independence, or fresh-OOS claim.')
print(json.dumps(report,indent=2))
