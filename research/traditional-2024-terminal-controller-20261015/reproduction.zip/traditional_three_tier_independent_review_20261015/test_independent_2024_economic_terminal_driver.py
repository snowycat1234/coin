"""Pure generated/saved-metadata tests; never construct or advance an account."""
from pathlib import Path
from copy import deepcopy
from tempfile import TemporaryDirectory
from types import SimpleNamespace
from unittest.mock import patch, Mock
import ast, hashlib, json, sys, unittest

ROOT=Path(__file__).resolve().parent.parent;B=ROOT/'traditional_three_tier_freeze_20261015'
sys.path.insert(0,str(B))
import annual_entry_2024 as a
import run_actual_2024 as v1
import run_actual_2024_economic_terminal_v2 as v2
import test_run_actual_2024_economic_terminal_v2 as fixture

raw=fixture.raw

class IndependentEconomicTerminalDriver(unittest.TestCase):
    def test_actual_saved_mid_classifies_only_as_unpaid_partial_metadata(self):
        f=B/'actual_2024_pilot_attempt001/STATIC50_MID'
        receipt=json.loads((f/'CASE_RECEIPT.json').read_bytes());result=json.loads((f/'RESULT.json').read_bytes())
        old=(raw(receipt),raw(result));terminal=v2.economic_terminal_record(receipt,result)
        self.assertEqual(terminal['stop_us'],1730861820000000)
        self.assertEqual(terminal['completed_minutes'],446576)
        self.assertIsNone(terminal['annual_paid_net_return']);self.assertIsNone(terminal['annual_APR'])
        self.assertFalse(terminal['paid_comparison_eligible'])
        self.assertEqual(terminal['retained_positions']['DOGEUSDT']['quantity'],-2000)
        self.assertEqual(old,(raw(receipt),raw(result)))

    def test_summary_clock_count_and_completion_cannot_disagree_with_receipt(self):
        p,g,_,_=fixture.fixture();r,z=fixture.terminal_values(p,g,'STATIC50_LOW',True)
        for key,value in [('completed_minutes',2),('required_minutes',525600),('stop_us',a.END),
                          ('completion','NOT_EVALUABLE_UNEXECUTABLE_ASSET_EXIT')]:
            bad=deepcopy(z);bad['summary'][key]=value
            with self.subTest(field=key),self.assertRaises((ValueError,KeyError)):
                v2.economic_terminal_record(r,bad)

    def test_count_cannot_claim_writing_at_or_after_its_halting_mark(self):
        p,g,_,_=fixture.fixture();r,z=fixture.terminal_values(p,g,'STATIC50_LOW',True)
        bad=deepcopy(r);bad['completed_minutes']=20;z['summary']['completed_minutes']=20
        with self.assertRaises(ValueError):v2.economic_terminal_record(bad,z)

    def test_account_snapshot_mutation_is_rejected_even_with_updated_checkpoint_hash(self):
        p,g,_,_=fixture.fixture()
        for halt in (True,False):
            with TemporaryDirectory(prefix='generated-economic-snapshot-') as td:
                f=Path(td)/'case';fixture.install_case(f,p,g,'STATIC50_LOW',halt)
                path=f/'ACCOUNT_FINANCIAL_AUDIT_SNAPSHOT.json';body=json.loads(path.read_bytes());body['status']='ACTIVE' if halt else 'LIQUIDATION_REQUIRED_HALT'
                path.write_bytes(raw(body));cp=json.loads((f/'TERMINAL_CHECKPOINT.json').read_bytes())
                cp['account_financial_audit_SHA256']=v2.sha(path.read_bytes());(f/'TERMINAL_CHECKPOINT.json').write_bytes(raw(cp))
                with self.subTest(halt=halt),self.assertRaises((ValueError,KeyError)):
                    v2.validate_saved_terminal(f,g,p,expected_go_sha256=v2.sha(raw(g)),config='STATIC50_LOW')

    def test_saved_halt_record_risk_or_result_mutation_never_promotes_terminal(self):
        p,g,_,_=fixture.fixture()
        for filename in ('ECONOMIC_TERMINAL.json','OBSERVED_RISK.json','RESULT.json'):
            with TemporaryDirectory(prefix='generated-economic-tamper-') as td:
                f=Path(td)/'case';fixture.install_case(f,p,g,'STATIC50_LOW',True)
                (f/filename).write_bytes(b'{}')
                with self.subTest(file=filename),self.assertRaises((ValueError,KeyError)):
                    v2.validate_saved_terminal(f,g,p,expected_go_sha256=v2.sha(raw(g)),config='STATIC50_LOW')

    def test_native_bankruptcy_witness_without_any_held_position_is_supported(self):
        p,g,_,_=fixture.fixture();r,z=fixture.terminal_values(p,g,'STATIC50_LOW',True)
        z['summary'].update(account_status='BANKRUPT_HALT',positions={},halt_witness=dict(event_us=r['account_stop_us'],phase='FUNDING',NAV='-1',unpaid_liability='1'))
        z['economics'].update(bankruptcy_halt=True,liquidation_required_halt=False,unpaid_liability='1',residual_marked_notional='0')
        self.assertEqual(v2.economic_terminal_record(r,z)['account_status'],'BANKRUPT_HALT')

    def test_healthy_witness_cannot_be_relabelled_bankrupt_or_maintenance_halt(self):
        p,g,_,_=fixture.fixture();r,z=fixture.terminal_values(p,g,'STATIC50_LOW',True)
        for status in ('BANKRUPT_HALT','LIQUIDATION_REQUIRED_HALT'):
            zz=deepcopy(z);zz['summary']['account_status']=status
            zz['summary']['halt_witness'].update(isolated_equity='100',maintenance_margin='1',NAV='10000',unpaid_liability='0')
            zz['economics'].update(bankruptcy_halt=status=='BANKRUPT_HALT',liquidation_required_halt=status=='LIQUIDATION_REQUIRED_HALT')
            with self.subTest(status=status),self.assertRaises(ValueError):v2.economic_terminal_record(r,zz)

    def test_policy_and_prior_review_are_exact_explicit_generated_metadata(self):
        p,g,rv,_=fixture.fixture(['STATIC50_LOW']);b=raw(g)
        self.assertEqual(v2.validate_controller_go(p,b,v2.sha(b),rv,v2.sha(rv))['permitted_configs'],['STATIC50_LOW'])
        for key,value in [('allow_recognized_native_economic_terminal_to_advance_queue',False),
                          ('economic_terminal_policy_version','UNREVIEWED'),('permitted_configs',[]),
                          ('permitted_configs',['STATIC50_LOW']*2)]:
            bad={**g,key:value};body=raw(bad)
            with self.subTest(field=key),self.assertRaises(ValueError):v2.validate_controller_go(p,body,v2.sha(body),rv,v2.sha(rv))
        bad={**g,'prior_economic_terminal_cases':[dict(config='STATIC50_MID',case_receipt_SHA256='0'*64,result_SHA256='1'*64,root_GO_SHA256='2'*64,independent_saved_review_SHA256='3'*64)]};body=raw(bad)
        with self.assertRaisesRegex(ValueError,'BOUND_INDEPENDENT_SAVED_REVIEW'):v2.validate_controller_go(p,body,v2.sha(body),rv,v2.sha(rv))

    def test_v1_financial_execution_and_quality_seams_are_unchanged_ast(self):
        old=ast.parse((B/'run_actual_2024.py').read_text());new=ast.parse((B/'run_actual_2024_economic_terminal_v2.py').read_text())
        def function(tree,name):return next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name==name)
        for name in ('limits','validate_installed_quality'):
            self.assertEqual(ast.dump(function(old,name),include_attributes=False),ast.dump(function(new,name),include_attributes=False))
        def before_result(tree):
            body=function(tree,'case').body;tr=next(x for x in body if isinstance(x,ast.Try));out=[]
            for stmt in tr.body:
                if isinstance(stmt,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='economic_halt' for t in stmt.targets):break
                out.append(stmt)
            # The V1 code reaches receipt construction directly; compare through
            # the shared source/target, advance, accounting and evidence prefix.
            for i,s in enumerate(out):
                if isinstance(s,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='receipt' for t in s.targets):return out[:i]
            return out
        self.assertEqual([ast.dump(x,include_attributes=False) for x in before_result(old)],
                         [ast.dump(x,include_attributes=False) for x in before_result(new)])

    def test_missing_quality_still_fails_before_first_advance_in_direct_case(self):
        p,g,rv,rs=fixture.fixture()
        with TemporaryDirectory(prefix='generated-economic-quality-') as td:
            t=Path(td);(t/'go.json').write_bytes(raw(g));(t/'review.json').write_bytes(rv)
            args=SimpleNamespace(preparation=str(B/'annual_2024_source_preparation_attempt002'),go=str(t/'go.json'),go_sha=v2.sha(raw(g)),review=str(t/'review.json'),review_sha=rs,source='NO_SOURCE',case_output=str(t/'fake'),config='STATIC50_MID')
            advance=Mock(side_effect=AssertionError('NO_HISTORICAL_ADVANCE'))
            sim=SimpleNamespace(account=SimpleNamespace(snapshot=lambda:{'GENERATED_ONLY':True}),cursor=a.START,end=a.END,stop=None,rows_written=0,advance_day=advance)
            guard=SimpleNamespace(receipts=[])
            with patch.object(v2,'limits'),patch.object(v2.threading,'Thread',return_value=Mock()),patch.object(a,'make_annual_case',return_value=(sim,guard)),patch.object(a.n,'runtime',side_effect=AssertionError('NO_ACCOUNT_RUNTIME')):
                with self.assertRaisesRegex(ValueError,'BEFORE_ADVANCE'):v2.case(args)
            advance.assert_not_called()

if __name__=='__main__':unittest.main(verbosity=2)
