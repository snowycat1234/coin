"""Synthetic-only boundary tests; no source scope or account is constructed."""
import json,socket,subprocess,tempfile,unittest
from pathlib import Path
import source_stage_guard as g

class GuardTests(unittest.TestCase):
    def assert_blocked(self,category,action):
        guard=g.SourceOnlyGuard()
        with self.assertRaises(g.SourceBoundaryViolation):
            with guard:
                try:action()
                except g.SourceBoundaryViolation:pass
        self.assertEqual(guard.attempts[category],1)

    def test_empty_guard_preserves_code_identity_and_zero_observations(self):
        before=g.entry.code_identity()
        with g.SourceOnlyGuard() as guard:
            guard.checkpoint('FAKE_PREPARATION');guard.checkpoint('FAKE_CALLBACKS')
            self.assertEqual(g.entry.code_identity(),before)
        self.assertFalse(any(guard.attempts.values()));self.assertEqual(len(guard.checkpoints),2)

    def test_financial_constructor_blocked_and_caught_attempt_is_fatal(self):
        self.assert_blocked('financial_constructors',lambda:g.integration.ExpansionAccount())

    def test_financial_advance_blocked_before_object_access(self):
        self.assert_blocked('financial_account_advance',lambda:g.integration.ExpansionAccount.update_marks(None,0,{}))

    def test_history_and_provider_boundaries_blocked(self):
        self.assert_blocked('historical_scope_mints',lambda:g.entry.FreshHistoricalExecutionScope.__post_init__(object()))
        self.assert_blocked('actual_provider_calls',lambda:g.entry.s.CapturedMinuteProvider(2022,())())

    def test_process_and_network_blocked_before_any_external_call(self):
        self.assert_blocked('process_launches',lambda:subprocess.Popen(['false']))
        self.assert_blocked('network_calls',lambda:socket.create_connection(('example.com',443)))

    def test_claim_and_lease_blocked_without_writes(self):
        self.assert_blocked('canonical_financial_claims_or_leases',lambda:g.runner.claim_launch('/tmp/NEVER_CREATED',cell_id='FAKE',manifest_sha256='a'*64,metadata={}))
        self.assert_blocked('canonical_financial_claims_or_leases',lambda:g.runner.controller_lease('/tmp/NEVER_CREATED'))

    def test_financial_GO_and_claim_file_writes_blocked(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'ROOT_GO_APPROVED.json'
            self.assert_blocked('financial_GO_writes',lambda:p.write_text('{}'))
            self.assertFalse(p.exists())
            c=Path(td)/'LAUNCH_CLAIM.json'
            self.assert_blocked('canonical_financial_claims_or_leases',lambda:c.write_text('{}'))
            self.assertFalse(c.exists())

    def test_financial_GO_serialization_blocked_at_any_filename(self):
        self.assert_blocked('financial_GO_writes',lambda:json.dumps(dict(schema=g.entry.GO_SCHEMA,action=g.entry.ACTION)))

    def test_source_GO_artifact_and_fake_recording_scopes_remain_allowed(self):
        with tempfile.TemporaryDirectory() as td:
            prep=dict(cells={cell:dict(input_binding_SHA256='a'*64) for cell in g.entry.tranche_cells()})
            held=[]
            with g.SourceOnlyGuard() as guard:
                (Path(td)/'SOURCE_PREP_GO.json').write_text(json.dumps(dict(schema='ROOT_SOURCE_PREP_FULL2022_V1',action='INVALID_FAKE_FIXTURE')))
                result=g.entry._record_metadata_cells(prep,'b'*64,lambda scope,metadata:(held.append(scope),metadata)[1],domain='GENERATED_FAKE_METADATA')
                guard.checkpoint('AFTER_FAKE_RECORDING_CALLBACKS')
            self.assertEqual(guard.allowed['recording_metadata_scopes'],9);self.assertFalse(any(guard.attempts.values()))
            self.assertEqual(result['recording_scopes_revoked'],9)
            for scope in held:
                with self.assertRaisesRegex(ValueError,'REVOKED'):scope.validate_current()

class AllowedSourceArtifactsTests(unittest.TestCase):
    def test_explicit_invalid_financial_template_and_source_GO_copy_allowed(self):
        with tempfile.TemporaryDirectory() as td:
            template=g.entry.invalid_go_template()
            with g.SourceOnlyGuard() as guard:
                (Path(td)/'ROOT_GO_TEMPLATE_UNAPPROVED.json').write_text(json.dumps(template))
                (Path(td)/'SOURCE_PREP_GO.json').write_bytes(b'{"schema":"ROOT_SOURCE_PREP_FULL2022_V1","action":"INVALID_FAKE_SOURCE"}')
            self.assertFalse(any(guard.attempts.values()))
    def test_raw_executable_financial_authority_in_template_name_is_blocked(self):
        with tempfile.TemporaryDirectory() as td:
            raw=json.dumps(dict(schema=g.entry.GO_SCHEMA,action=g.entry.ACTION)).encode()
            guard=g.SourceOnlyGuard()
            with self.assertRaises(g.SourceBoundaryViolation):
                with guard:(Path(td)/'ROOT_GO_TEMPLATE_UNAPPROVED.json').write_bytes(raw)
            self.assertEqual(guard.attempts['financial_GO_writes'],1)

if __name__=='__main__':unittest.main()
