"""Separately reviewed source-only launcher with observed no-finance boundaries.

This module changes no frozen file or financial formula. Runtime blockers are
installed only around source preparation and recording-only metadata callbacks.
"""
import os
THREAD_KEYS=('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','POLARS_MAX_THREADS','VECLIB_MAXIMUM_THREADS')
for _key in THREAD_KEYS:os.environ[_key]='1'
import argparse,builtins,fcntl,http.client,json,socket,subprocess,sys,urllib.request
from contextlib import ExitStack
from copy import deepcopy
from hashlib import sha256
from pathlib import Path
from unittest.mock import patch

HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
EXECUTION=ROOT/'traditional_D_full2022_20261015_v2'
if str(EXECUTION) not in sys.path:sys.path.insert(0,str(EXECUTION))
import full_entry as entry
import full_d as integration
import run_full as runner
if Path(entry.__file__).resolve()!=EXECUTION/'full_entry.py':raise ValueError('EXACT_REVIEWED_V2_ENTRY_REQUIRED')

class SourceBoundaryViolation(RuntimeError):pass


def launcher_code_identity():
    return {str(Path(__file__).resolve().relative_to(ROOT)):sha256(Path(__file__).read_bytes()).hexdigest()}


class SourceOnlyGuard:
    CATEGORIES=('financial_constructors','financial_account_advance','native_simulator_construct_or_advance',
        'historical_scope_mints','actual_provider_calls','process_launches','network_calls',
        'canonical_financial_claims_or_leases','financial_GO_writes')
    def __init__(self):
        self.attempts=dict.fromkeys(self.CATEGORIES,0);self.targets=[];self.checkpoints=[]
        self.allowed=dict(source_application_scopes=0,recording_metadata_scopes=0)
        self._stack=ExitStack();self._installed=set();self.active=False
    def _deny(self,category,target):
        def blocked(*args,**kwargs):
            self.attempts[category]+=1;self.targets.append(dict(category=category,target=target))
            raise SourceBoundaryViolation('SOURCE_ONLY_FORBIDDEN:'+category+':'+target)
        return blocked
    def _block(self,obj,name,category):
        if hasattr(obj,name) and (id(obj),name) not in self._installed:
            self._installed.add((id(obj),name))
            self._stack.enter_context(patch.object(obj,name,self._deny(category,getattr(obj,'__name__',type(obj).__name__)+'.'+name)))
    def _write_category(self,path):
        if not isinstance(path,(str,bytes,os.PathLike)):return None
        p=Path(os.fsdecode(path));name=p.name.upper();parts={str(x).upper() for x in p.parts}
        if 'EXECUTION_CLAIMS' in parts or name in {'LAUNCH_CLAIM.JSON','CONTROLLER_LEASE.LOCK'}:return 'canonical_financial_claims_or_leases'
        if name in {'SOURCE_PREP_GO.JSON','ROOT_GO_TEMPLATE_UNAPPROVED.JSON'}:return None
        if name.startswith('ROOT_GO') or name in {'ADMISSION_GO.JSON','FINANCIAL_GO.JSON'}:return 'financial_GO_writes'
        return None
    def _check_write(self,path):
        category=self._write_category(path)
        if category:self._deny(category,'WRITE:'+Path(os.fsdecode(path)).name)()
    def _check_json(self,value):
        if isinstance(value,dict) and (value.get('schema')==entry.GO_SCHEMA or value.get('action')==entry.ACTION):
            invalid=(value.get('action')=='INVALID_TEMPLATE_NOT_ROOT_AUTHORIZATION'
                and type(value.get('status')) is str and value['status'].startswith('INVALID_')
                and value.get('historical_execution_authorized') is False)
            if not invalid:self._deny('financial_GO_writes','EXECUTABLE_FINANCIAL_GO_CONTENT')()
    def _wrapped_file(self,stream,mode):
        if not any(c in mode for c in 'wax+'):return stream
        guard=self
        class CheckedWriter:
            def __init__(self):self.prefix=b'';self.inspect=None
            def __getattr__(self,name):return getattr(stream,name)
            def __enter__(self):stream.__enter__();return self
            def __exit__(self,*args):return stream.__exit__(*args)
            def write(self,value):
                raw=value.encode() if isinstance(value,str) else bytes(value)
                if self.inspect is None and raw.strip():self.inspect=raw.lstrip()[:1] in (b'{',b'[')
                if self.inspect:
                    self.prefix+=raw
                    if len(self.prefix)>16_000_000:raise SourceBoundaryViolation('SOURCE_JSON_WRITE_SIZE_LIMIT')
                    try:decoded=json.loads(self.prefix)
                    except (ValueError,UnicodeError):pass
                    else:guard._check_json(decoded)
                return stream.write(value)
            def writelines(self,values):
                for value in values:self.write(value)
        return CheckedWriter()
    def __enter__(self):
        if self.active:raise RuntimeError('SOURCE_GUARD_NOT_REENTRANT')
        self.active=True
        try:
            v=integration.V2
            classes=(integration.ExpansionAccount,integration.D.Guard50ExitAccount,v.ContinuationAccount,
                v.P.BoundedContinuationAccount,v.ENGINE.USDTLinearPerpetualAccount,v.OWNED.OwnedFineGridAccount)
            for cls in classes:
                self._block(cls,'__init__','financial_constructors')
                for name in ('update_marks','execute_fill','apply_funding','monitor','from_snapshot','fork_for_preview'):
                    self._block(cls,name,'financial_account_advance')
            native=v.native.runtime()[1]
            # Discover the exact native simulator class from its loaded module.
            for module in tuple(sys.modules.values()):
                if module is not None and hasattr(module,'NativeDailySimulator'):
                    cls=module.NativeDailySimulator
                    self._block(cls,'__init__','native_simulator_construct_or_advance')
                    for name in ('advance_day','attempt','funding_through','from_snapshot'):
                        self._block(cls,name,'native_simulator_construct_or_advance')
            for module,names in ((integration,('construct_case',)),(v.native,('build_case','_construct_case','make_owned_account')),
                    (v.grid,('make_account',)),(entry,('make_case','_default_constructor_callback','validate_case_inputs'))):
                for name in names:self._block(module,name,'financial_constructors')
            self._block(entry.FreshHistoricalExecutionScope,'__post_init__','historical_scope_mints')
            self._block(entry.s.CapturedMinuteProvider,'__call__','actual_provider_calls')
            self._block(entry.s.CapturedMinuteProvider,'_bind_historical_scope','actual_provider_calls')
            for name in ('claim_launch','controller_lease'):self._block(runner,name,'canonical_financial_claims_or_leases')
            for name in ('case','controller','run_pool','_run_pool'):self._block(runner,name,'process_launches')
            for name in ('Popen','run','call','check_call','check_output'):self._block(subprocess,name,'process_launches')
            for name in ('system','fork','forkpty','posix_spawn','posix_spawnp','execv','execve','execvp','execvpe','execl','execlp','execle','execlpe'):
                self._block(os,name,'process_launches')
            import multiprocessing.process
            self._block(multiprocessing.process.BaseProcess,'start','process_launches')
            self._block(fcntl,'flock','canonical_financial_claims_or_leases')
            for obj,names in ((socket,('create_connection','getaddrinfo')),(socket.socket,('connect','connect_ex')),
                    (urllib.request,('urlopen',)),(urllib.request.OpenerDirector,('open',)),
                    (http.client.HTTPConnection,('connect',)),(http.client.HTTPSConnection,('connect',))):
                for name in names:self._block(obj,name,'network_calls')
            # Record the two explicitly permitted source/metadata scope classes.
            for cls,key in ((entry.s.ActualSourceApplicationScope,'source_application_scopes'),(entry.RecordingOnlyMetadataScope,'recording_metadata_scopes')):
                original=cls.__post_init__
                def observed(obj,*args,_original=original,_key=key,**kwargs):
                    result=_original(obj,*args,**kwargs);self.allowed[_key]+=1;return result
                self._stack.enter_context(patch.object(cls,'__post_init__',observed))
            original_open=builtins.open;original_path_open=Path.open;original_os_open=os.open;original_mkdir=os.mkdir
            def opened(file,mode='r',*args,**kwargs):
                if any(c in mode for c in 'wax+'):self._check_write(file)
                return self._wrapped_file(original_open(file,mode,*args,**kwargs),mode)
            def path_open(path,mode='r',*args,**kwargs):
                if any(c in mode for c in 'wax+'):self._check_write(path)
                return self._wrapped_file(original_path_open(path,mode,*args,**kwargs),mode)
            def os_open(path,flags,*args,**kwargs):
                if flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND):self._check_write(path)
                return original_os_open(path,flags,*args,**kwargs)
            def mkdir(path,*args,**kwargs):
                if 'EXECUTION_CLAIMS' in {str(p).upper() for p in Path(os.fsdecode(path)).parts}:self._deny('canonical_financial_claims_or_leases','mkdir:EXECUTION_CLAIMS')()
                return original_mkdir(path,*args,**kwargs)
            self._stack.enter_context(patch.object(builtins,'open',opened));self._stack.enter_context(patch.object(Path,'open',path_open))
            self._stack.enter_context(patch.object(os,'open',os_open));self._stack.enter_context(patch.object(os,'mkdir',mkdir))
            original_dump=json.dump;original_dumps=json.dumps
            def financial(value):self._check_json(value)
            def dump(value,*args,**kwargs):financial(value);return original_dump(value,*args,**kwargs)
            def dumps(value,*args,**kwargs):financial(value);return original_dumps(value,*args,**kwargs)
            self._stack.enter_context(patch.object(json,'dump',dump));self._stack.enter_context(patch.object(json,'dumps',dumps))
            return self
        except BaseException:
            self._stack.close();self.active=False;raise
    def checkpoint(self,label):
        self.checkpoints.append(dict(label=label,forbidden_attempts=dict(self.attempts),allowed_scope_constructions=dict(self.allowed),
            active_recording_scopes=len(entry._METADATA_ACTIVE)))
        if any(self.attempts.values()):raise SourceBoundaryViolation('SOURCE_ONLY_FORBIDDEN_ATTEMPTS_OBSERVED')
    def __exit__(self,kind,value,tb):
        self._stack.close();self.active=False
        if any(self.attempts.values()):raise SourceBoundaryViolation('SOURCE_ONLY_FORBIDDEN_ATTEMPTS_FATAL_EVEN_IF_CAUGHT') from value
        return False
    def receipt(self,status,error=None):
        return dict(schema='OBSERVED_SOURCE_ONLY_NO_FINANCE_GUARD_V1',status=status,error=error,
            forbidden_attempts=dict(self.attempts),allowed_scope_constructions=dict(self.allowed),checkpoints=deepcopy(self.checkpoints),
            attempted_forbidden_targets=deepcopy(self.targets),all_recording_scopes_revoked=not entry._METADATA_ACTIVE,
            source_only_guard_code_identity=launcher_code_identity(),execution_code_identity=entry.code_identity(),
            actual_source_financial_execution_authorized=False)


def guarded_prepare(*,source_root,output,source_go_raw,expected_source_go_sha256,guard_receipt,record_metadata=True):
    # Verify this independent invocation pin before running source application.
    entry._exact(source_go_raw,expected_source_go_sha256,'EXTERNAL_SOURCE_STAGE_GO_REQUIRED')
    go=entry._object(source_go_raw,'EXACT_SOURCE_STAGE_GO_OBJECT_REQUIRED')
    if go.get('source_guard_code_identity')!=launcher_code_identity():raise ValueError('EXACT_REVIEWED_SOURCE_GUARD_INVOCATION_PIN_REQUIRED')
    guard=SourceOnlyGuard();error=None;result=None
    try:
        with guard:
            result=entry.prepare_source_only({2022:source_root},output,source_authorization_raw=source_go_raw,
                expected_source_authorization_sha256=expected_source_go_sha256)
            guard.checkpoint('AFTER_SOURCE_ONLY_PREPARATION')
            if record_metadata:
                recording=entry.record_source_metadata_callbacks(output,source_go_raw,expected_source_go_sha256)
                with (Path(output)/'RECORDING_ONLY_METADATA_RECEIPT.json').open('x') as stream:json.dump(recording,stream,indent=2);stream.write('\n')
            guard.checkpoint('AFTER_RECORDING_CALLBACKS')
    except BaseException as exc:error=repr(exc)
    observed=guard.receipt('PASS_OBSERVED_ZERO_FORBIDDEN_CALLS' if error is None else 'SOURCE_STAGE_FAILED_OR_GUARD_BLOCKED',error)
    with Path(guard_receipt).open('x') as stream:json.dump(observed,stream,indent=2,sort_keys=True);stream.write('\n')
    if error is not None:raise SourceBoundaryViolation(error)
    return result,observed


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    for name in ('source-root','output','source-go','source-go-sha','guard-receipt'):parser.add_argument('--'+name,required=True)
    args=parser.parse_args()
    result,receipt=guarded_prepare(source_root=args.source_root,output=args.output,source_go_raw=Path(args.source_go).read_bytes(),
        expected_source_go_sha256=args.source_go_sha,guard_receipt=args.guard_receipt,record_metadata=True)
    print(json.dumps(dict(status=receipt['status'],guard_receipt=args.guard_receipt)))
