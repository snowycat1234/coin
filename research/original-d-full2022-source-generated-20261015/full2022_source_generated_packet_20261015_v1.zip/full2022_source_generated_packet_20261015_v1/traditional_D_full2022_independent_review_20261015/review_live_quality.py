"""Independent synthetic source-clock and per-asset recovery seam tests."""
import os
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','POLARS_MAX_THREADS','VECLIB_MAXIMUM_THREADS'):os.environ[k]='1'
os.sched_setaffinity(0,{6})
import sys,unittest,json,time,resource
from pathlib import Path
from dataclasses import replace
from decimal import Decimal as Q
from types import SimpleNamespace
from hashlib import sha256
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1];HERE=Path(__file__).resolve().parent;NEW=ROOT/os.environ.get('FULL2022_REVIEW_DIR','traditional_D_full2022_20261015')
sys.path.insert(0,str(NEW))
import full_source as s
import full_d as d
from test_native_runtime import fixture,BASE
B=978307200000000

def cell(symbol,opened,anchor):return s.QualityCell(symbol,opened,opened+s.MINUTE,opened+s.MINUTE,'50000',anchor,anchor+s.MINUTE,anchor+s.MINUTE,anchor+s.MINUTE,anchor+s.MINUTE,'a'*64,'GENERATED_ANCHOR:'+symbol+':'+str(anchor))
def shell(cells):
    account=SimpleNamespace(marks={symbol:[] for symbol in d.S},mark_quality={})
    guard=object.__new__(d.ContinuationQualityGuard);guard.source_quality_cells=tuple(cells);guard.sim=SimpleNamespace(account=account)
    guard.policy_sha256='b'*64;guard.source_sidecar_sha256='c'*64
    return guard,account

def generated_account():
    plain=d.V2.grid.make_account('MID','BASE27')
    return d.ExpansionAccount(plain.config,symbols=d.S,instrument_profiles=plain.instrument_profiles,generated_scope=d.GENERATED,tier_name='MID')

class LiveQuality(unittest.TestCase):
    def test_overlapping_symbols_keep_distinct_original_anchor_ages(self):
        btc=(cell('BTCUSDT',B+2*s.MINUTE,B+s.MINUTE),cell('BTCUSDT',B+3*s.MINUTE,B+s.MINUTE))
        eth=(cell('ETHUSDT',B+3*s.MINUTE,B+2*s.MINUTE),)
        guard,account=shell(btc+eth);event=B+4*s.MINUTE
        found=guard.quality_witness(event)['affected_source_cells'];by={x['symbol']:x for x in found}
        self.assertEqual(by['BTCUSDT']['original_genuine_age_us'],2*s.MINUTE)
        self.assertEqual(by['ETHUSDT']['original_genuine_age_us'],s.MINUTE)
        self.assertEqual(by['BTCUSDT']['original_genuine_observation_us'],B+2*s.MINUTE)
        self.assertEqual(by['ETHUSDT']['original_genuine_observation_us'],B+3*s.MINUTE)
    def test_nominal_end_and_fakefresh_derived_mark_never_recover(self):
        c=cell('BTCUSDT',B+2*s.MINUTE,B+s.MINUTE);guard,account=shell((c,));event=B+5*s.MINUTE
        for close in (c.anchor_completed_us,B+4*s.MINUTE,B+5*s.MINUTE):
            account.marks['BTCUSDT']=[dict(price=Q('50000'),close_us=close,available_us=close)]
            account.mark_quality['BTCUSDT']='UNKNOWN_OR_DERIVED'
            self.assertIsNotNone(guard.quality_witness(event))
        account.mark_quality['BTCUSDT']='DIRECT_GENERATED_OBSERVATION'
        self.assertIsNone(guard.quality_witness(event))
    def test_each_asset_requires_own_installed_genuine_recovery(self):
        guard,account=shell((cell('BTCUSDT',B+2*s.MINUTE,B+s.MINUTE),cell('ETHUSDT',B+2*s.MINUTE,B+s.MINUTE)))
        event=B+4*s.MINUTE;account.marks['BTCUSDT']=[dict(price=Q('50000'),close_us=event,available_us=event)];account.mark_quality['BTCUSDT']='DIRECT_GENERATED_OBSERVATION'
        self.assertEqual([x['symbol'] for x in guard.quality_witness(event)['affected_source_cells']],['ETHUSDT'])
    def test_witness_preserves_timestamp_type_contract(self):
        guard,account=shell((cell('BTCUSDT',B+2*s.MINUTE,B+s.MINUTE),))
        for invalid in (True,-1,1.0,str(B)):
            with self.subTest(value=invalid),self.assertRaises((ValueError,TypeError)):guard.quality_witness(invalid)
    def test_transport_retains_anchor_and_unknown_before_native_immediate_risk(self):
        a=generated_account();at=B+3*s.MINUTE;c=cell('BTCUSDT',B+2*s.MINUTE,B+s.MINUTE)
        a._source_quality_cells=(c,);a._quality_intervals=((c.completed_us,c.completed_us+s.MINUTE,('BTCUSDT',)),)
        before={symbol:dict(price=str(BASE[j]),close_us=c.anchor_completed_us,available_us=c.anchor_available_us) for j,symbol in enumerate(d.S)}
        a.update_marks(c.anchor_completed_us,before)
        seen=[];original=a._risk
        def observed(reason):
            seen.append((dict(a.mark_quality),{k:dict(v[-1]) if v else None for k,v in a.marks.items()}));return original(reason)
        a._risk=observed
        current={symbol:dict(price=str(BASE[j]),close_us=at,available_us=at) for j,symbol in enumerate(d.S)}
        a.update_marks(at,current)
        self.assertEqual(len(seen),1);quality,marks=seen[0]
        self.assertEqual(quality['BTCUSDT'],'UNKNOWN_OR_DERIVED');self.assertEqual(marks['BTCUSDT']['close_us'],c.anchor_completed_us)
        self.assertEqual(marks['BTCUSDT']['available_us'],c.anchor_available_us);self.assertEqual(marks['BTCUSDT']['price'],Q(c.price_text))
        self.assertFalse(a.pending_exits);self.assertFalse(a.transfer_journal)

if __name__=='__main__':
    began=time.monotonic();r=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(LiveQuality))
    record=dict(status='PASS_GENERATED_LIVE_QUALITY_ONLY' if r.wasSuccessful() else 'FAIL',tests_run=r.testsRun,failures=len(r.failures),errors=len(r.errors),actual_source_inputs_used=False,actual_accounts_constructed=0,historical_scopes_created=0,actual_source_callbacks=0,process_probes=0,canonical_claims=0,source_files={name:sha256((NEW/name).read_bytes()).hexdigest() for name in ('full_d.py','full_source.py','source_overlay.py','source_projection.py')},test_script_SHA256=sha256(Path(__file__).read_bytes()).hexdigest(),CPU_affinity=sorted(os.sched_getaffinity(0)),wall_seconds=time.monotonic()-began,max_RSS_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024)
    (HERE/'LIVE_QUALITY_REVIEW.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n');raise SystemExit(not r.wasSuccessful())
