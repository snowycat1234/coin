"""Synthetic in-process parser memory observation; no actual bridge application."""
import os
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','POLARS_MAX_THREADS','VECLIB_MAXIMUM_THREADS'):os.environ[k]='1'
os.sched_setaffinity(0,{6})
import sys,time,json,resource,zipfile,gc,tracemalloc
from pathlib import Path
from io import BytesIO
from hashlib import sha256
ROOT=Path(__file__).resolve().parents[1];HERE=Path(__file__).resolve().parent;NEW=ROOT/os.environ.get('FULL2022_REVIEW_DIR','traditional_D_full2022_20261015')
sys.path.insert(0,str(NEW))
import full_source as s
import raw_source_bridge as bridge
count=44640;start=1669852800000 # synthetic December2022 shape, all values invented
began=time.monotonic();memory=BytesIO()
with zipfile.ZipFile(memory,'w',compression=zipfile.ZIP_DEFLATED) as z:
    with z.open('BTCUSDT-1m-2022-12.csv','w') as stream:
        for k in range(count):
            t=start+k*60000
            stream.write((f'{t},100.00000000,102.00000000,99.00000000,101.00000000,1234.56789000,{t+59999},124691.35689000,120,678.90123400,68569.02463400,0\n').encode())
raw=memory.getvalue();del memory
rss_before=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024
tracemalloc.start();parsed,metadata=bridge.parse_original_zip(raw,symbol='BTCUSDT',period='2022-12',family='klines');current,peak=tracemalloc.get_traced_memory();tracemalloc.stop()
assert len(parsed)==count and metadata['observed_minutes']==count
rss_after=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024
record=dict(status='PASS_GENERATED_FULL_MONTH_PARSER_OBSERVATION_ONLY',fixture='SYNTHETIC_ALL_PRICES_AND_VOLUMES_INVENTED',generated_minutes=count,generated_ZIP_bytes=len(raw),python_traced_retained_bytes=current,python_traced_peak_bytes=peak,max_RSS_before_bytes=rss_before,max_RSS_after_bytes=rss_after,observed_max_RSS_increase_bytes=max(0,rss_after-rss_before),wall_seconds=time.monotonic()-began,CPU_affinity=sorted(os.sched_getaffinity(0)),script_SHA256=sha256(Path(__file__).read_bytes()).hexdigest(),bridge_SHA256=sha256((NEW/'raw_source_bridge.py').read_bytes()).hexdigest(),actual_source_body_reads=0,actual_source_application_calls=0,actual_account_constructors=0,process_probes=0,canonical_claims=0,actual_annual_resource_envelope_certified=False)
(HERE/'GENERATED_BRIDGE_MEMORY_OBSERVATION.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n');print(json.dumps(record,sort_keys=True))
