"""Generated-only recording-scope class separation and revocation."""
import os
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','POLARS_MAX_THREADS','VECLIB_MAXIMUM_THREADS'):os.environ[k]='1'
os.sched_setaffinity(0,{6})
import sys,unittest,json,time
from pathlib import Path
from hashlib import sha256
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1];HERE=Path(__file__).resolve().parent;NEW=ROOT/os.environ.get('FULL2022_REVIEW_DIR','traditional_D_full2022_20261015_v2')
sys.path.insert(0,str(NEW))
import full_entry as entry
import full_d as d
import full_source as s
import source_projection as projection

def fake_prep():return {'cells':{c:{'input_binding_SHA256':'a'*64} for c in entry.tranche_cells()}}

class RecordingScope(unittest.TestCase):
    def test_generated_nine_are_distinct_inputless_and_revoked_after_each_callback(self):
        saved=[]
        def record(*,scope,metadata):
            for older in saved:
                with self.assertRaises(ValueError):older.validate_current()
            self.assertTrue(scope.validate_current());saved.append(scope)
            self.assertIs(type(scope),entry.RecordingOnlyMetadataScope);self.assertNotIsInstance(scope,entry.FreshHistoricalExecutionScope)
            self.assertTrue(metadata['recording_only']);self.assertFalse(metadata['historical_execution_authorized'])
            for key in ('window','source_rows','targets','decisions','provider','account','_bound_window','_bound_targets'):
                self.assertFalse(hasattr(scope,key),key)
            self.assertFalse(set(metadata)&{'window','source_rows','targets','decisions','provider','account'})
            metadata['cell_id']='GENERATED_MUTATION'
            self.assertNotEqual(scope.metadata['cell_id'],'GENERATED_MUTATION')
            return {'cell_id':scope.cell_id,'generated_only':True}
        r=entry._record_metadata_cells(fake_prep(),'b'*64,record,domain='GENERATED_FAKE_METADATA')
        self.assertEqual(r['recording_scopes_created'],9);self.assertEqual(r['recording_scopes_revoked'],9)
        self.assertEqual(len(saved),9);self.assertFalse(entry._METADATA_ACTIVE)
        for scope in saved:
            with self.assertRaises(ValueError):scope.validate_current()
            with self.assertRaises(ValueError):_ = scope.metadata
    def test_generated_scope_revoked_even_callback_raises(self):
        saved=[]
        def fail(*,scope,metadata):saved.append(scope);raise RuntimeError('GENERATED_EXPECTED_CALLBACK_FAILURE')
        with self.assertRaisesRegex(RuntimeError,'EXPECTED_CALLBACK_FAILURE'):entry._record_metadata_cells(fake_prep(),'b'*64,fail,domain='GENERATED_FAKE_METADATA')
        self.assertEqual(len(saved),1);self.assertFalse(entry._METADATA_ACTIVE)
        with self.assertRaises(ValueError):saved[0].validate_current()
    def test_recording_scope_cannot_enter_financial_constructor(self):
        with patch.object(d.V2.ENGINE.USDTLinearPerpetualAccount,'__init__',side_effect=AssertionError('FINANCIAL_CONSTRUCTOR_FORBIDDEN')) as financial:
            def record(*,scope,metadata):
                with self.assertRaises(ValueError):d.ExpansionAccount(None,historical_scope=scope)
                with self.assertRaises(ValueError):d.construct_case({},(),None,None,historical_scope=scope)
                provider=s.CapturedMinuteProvider(2022,(),())
                with self.assertRaises(ValueError):provider._bind_historical_scope(scope)
                with patch.object(projection,'month_arrays',side_effect=AssertionError('DECODE_FORBIDDEN')) as decode:
                    forged=s.CapturedMinuteProvider(2022,(),(),scope)
                    with self.assertRaisesRegex(ValueError,'HISTORICAL_PROVIDER_REQUIRES_SEPARATE_ROOT_GO'):next(forged())
                    decode.assert_not_called()
                return {'generated_only':True}
            entry._record_metadata_cells(fake_prep(),'b'*64,record,domain='GENERATED_FAKE_METADATA');financial.assert_not_called()
    def test_actual_recording_domain_requires_source_stage_authority_before_callbacks(self):
        called=[]
        with self.assertRaises((ValueError,TypeError)):
            entry._record_metadata_cells(fake_prep(),'b'*64,lambda **kw:called.append(kw),domain='ACTUAL_PREPARED_SOURCE_METADATA')
        self.assertFalse(called);self.assertFalse(entry._METADATA_ACTIVE)
    def test_unknown_domain_and_direct_unsealed_class_rejected(self):
        with self.assertRaises(ValueError):entry._record_metadata_cells(fake_prep(),'b'*64,lambda **kw:None,domain='FORGED')
        with self.assertRaises(ValueError):entry.RecordingOnlyMetadataScope('FAKE','a'*64,'b'*64,'GENERATED_FAKE_METADATA',object(),object())

if __name__=='__main__':
    began=time.monotonic();r=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(RecordingScope))
    record=dict(status='PASS_GENERATED_RECORDING_SCOPE_ONLY' if r.wasSuccessful() else 'FAIL',tests_run=r.testsRun,failures=len(r.failures),errors=len(r.errors),actual_source_callbacks=0,actual_source_scopes=0,historical_scopes=0,actual_accounts_constructed=0,actual_provider_iterations=0,process_launches=0,financial_claims=0,source_files={p.name:sha256(p.read_bytes()).hexdigest() for p in (NEW/'full_entry.py',NEW/'full_d.py',NEW/'full_source.py')},script_SHA256=sha256(Path(__file__).read_bytes()).hexdigest(),wall_seconds=time.monotonic()-began,CPU_affinity=sorted(os.sched_getaffinity(0)))
    (HERE/'RECORDING_SCOPE_REVIEW.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n');raise SystemExit(not r.wasSuccessful())
