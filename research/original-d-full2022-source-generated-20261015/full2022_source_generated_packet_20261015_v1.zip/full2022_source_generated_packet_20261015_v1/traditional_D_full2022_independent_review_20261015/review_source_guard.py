"""Independent generated-only tests of the dynamic source-stage guard."""
import os
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','POLARS_MAX_THREADS','VECLIB_MAXIMUM_THREADS'):os.environ[k]='1'
os.sched_setaffinity(0,{6})
import sys,json,unittest,tempfile,time,socket,subprocess
from pathlib import Path
from hashlib import sha256
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1];HERE=Path(__file__).resolve().parent;GUARD=ROOT/'traditional_D_full2022_source_stage_handoff_20261015/source_stage_guard.py'
sys.path.insert(0,str(GUARD.parent))
import source_stage_guard as g

def fake_prep():return {'cells':{c:{'input_binding_SHA256':'a'*64} for c in g.entry.tranche_cells()}}

class SourceGuard(unittest.TestCase):
    def test_safe_generated_metadata_nine_counted_revoked_and_zero_forbidden(self):
        guard=g.SourceOnlyGuard();original=g.integration.V2.grid.make_account
        with guard:
            g.entry._record_metadata_cells(fake_prep(),'b'*64,lambda **kw:dict(kw['metadata']),domain='GENERATED_FAKE_METADATA')
            self.assertEqual(json.loads(json.dumps({'schema':'ROOT_SOURCE_PREP_FULL2022_V1'}))['schema'],'ROOT_SOURCE_PREP_FULL2022_V1')
            guard.checkpoint('AFTER_FAKE_RECORDING_ONLY')
        self.assertIs(g.integration.V2.grid.make_account,original)
        r=guard.receipt('GENERATED_TEST_ONLY');self.assertTrue(all(v==0 for v in r['forbidden_attempts'].values()))
        self.assertEqual(r['allowed_scope_constructions']['recording_metadata_scopes'],9)
        self.assertEqual(r['allowed_scope_constructions']['source_application_scopes'],0)
        self.assertTrue(r['all_recording_scopes_revoked']);self.assertEqual(r['checkpoints'][0]['active_recording_scopes'],0)
    def test_every_forbidden_category_blocks_before_action_and_caught_attempt_is_fatal(self):
        native=g.integration.V2.native.runtime()[1]
        actions={
            'financial_constructors':lambda:g.integration.V2.grid.make_account('MID','BASE27'),
            'financial_account_advance':lambda:g.integration.ExpansionAccount.update_marks(None,0,{}),
            'native_simulator_construct_or_advance':lambda:native.NativeDailySimulator.__init__(None),
            'historical_scope_mints':lambda:g.entry.FreshHistoricalExecutionScope.__post_init__(None),
            'actual_provider_calls':lambda:g.entry.s.CapturedMinuteProvider(2022,(),())(),
            'process_launches':lambda:subprocess.Popen(['FORBIDDEN_NEVER_LAUNCHED']),
            'network_calls':lambda:socket.create_connection(('FORBIDDEN.invalid',443)),
            'canonical_financial_claims_or_leases':lambda:g.runner.claim_launch('/tmp/NEVER_CREATED'),
            'financial_GO_writes':lambda:json.dumps({'schema':g.entry.GO_SCHEMA})}
        for category,action in actions.items():
            guard=g.SourceOnlyGuard()
            with self.subTest(category=category),self.assertRaisesRegex(g.SourceBoundaryViolation,'FATAL_EVEN_IF_CAUGHT'):
                with guard:
                    with self.assertRaises(g.SourceBoundaryViolation):action()
                    self.assertEqual(guard.attempts[category],1)
            self.assertEqual(sum(guard.attempts.values()),1);self.assertFalse(guard.active)
    def test_financial_GO_and_claim_file_writes_are_blocked_and_source_copy_allowed(self):
        with tempfile.TemporaryDirectory(prefix='GENERATED_SOURCE_GUARD_') as td:
            for name in ('ROOT_GO_GENERATED.json','ADMISSION_GO.json','LAUNCH_CLAIM.json'):
                target=Path(td)/name;guard=g.SourceOnlyGuard()
                with self.assertRaises(g.SourceBoundaryViolation):
                    with guard:
                        try:target.write_bytes(b'GENERATED_NEVER_WRITTEN')
                        except g.SourceBoundaryViolation:pass
                self.assertFalse(target.exists())
            guard=g.SourceOnlyGuard()
            with guard:(Path(td)/'SOURCE_PREP_GO.json').write_bytes(b'GENERATED_SOURCE_ONLY_COPY')
            self.assertEqual((Path(td)/'SOURCE_PREP_GO.json').read_bytes(),b'GENERATED_SOURCE_ONLY_COPY')
    def test_executable_financial_content_blocked_even_under_allowed_template_filename(self):
        executable=json.dumps({'schema':g.entry.GO_SCHEMA,'action':g.entry.ACTION})
        with tempfile.TemporaryDirectory(prefix='GENERATED_GUARD_CONTENT_') as td:
            target=Path(td)/'ROOT_GO_TEMPLATE_UNAPPROVED.json';guard=g.SourceOnlyGuard()
            with self.assertRaises(g.SourceBoundaryViolation):
                with guard:
                    try:target.write_text(executable)
                    except g.SourceBoundaryViolation:pass
            self.assertEqual(guard.attempts['financial_GO_writes'],1)
            if target.exists():self.assertEqual(target.read_bytes(),b'')
    def test_explicit_invalid_financial_template_remains_non_authority_and_allowed(self):
        invalid={'schema':g.entry.GO_SCHEMA,'action':'INVALID_TEMPLATE_NOT_ROOT_AUTHORIZATION','status':'INVALID_GENERATED_TEST_ONLY','historical_execution_authorized':False}
        guard=g.SourceOnlyGuard()
        with tempfile.TemporaryDirectory(prefix='GENERATED_GUARD_INVALID_') as td:
            with guard:(Path(td)/'ROOT_GO_TEMPLATE_UNAPPROVED.json').write_text(json.dumps(invalid))
            self.assertFalse(any(guard.attempts.values()));self.assertFalse(json.loads((Path(td)/'ROOT_GO_TEMPLATE_UNAPPROVED.json').read_text())['historical_execution_authorized'])

    def test_missing_or_changed_external_invocation_pin_fails_before_source_callback(self):
        with patch.object(g.entry,'prepare_source_only',side_effect=AssertionError('ACTUAL_SOURCE_CALLBACK_FORBIDDEN')) as call:
            for expected in (None,'a'*64):
                with self.assertRaises(ValueError):g.guarded_prepare(source_root='/NONEXISTENT_FAKE',output='/NONEXISTENT_FAKE',source_go_raw=b'{}',expected_source_go_sha256=expected,guard_receipt='/NONEXISTENT_FAKE')
            raw=b'{"source_guard_code_identity":{}}'
            with self.assertRaisesRegex(ValueError,'INVOCATION_PIN'):g.guarded_prepare(source_root='/NONEXISTENT_FAKE',output='/NONEXISTENT_FAKE',source_go_raw=raw,expected_source_go_sha256=sha256(raw).hexdigest(),guard_receipt='/NONEXISTENT_FAKE')
            call.assert_not_called()
    def test_context_and_patch_restoration_on_exception(self):
        original=g.runner.claim_launch;guard=g.SourceOnlyGuard()
        with self.assertRaisesRegex(RuntimeError,'GENERATED_EXPECTED'):
            with guard:raise RuntimeError('GENERATED_EXPECTED')
        self.assertFalse(guard.active);self.assertIs(g.runner.claim_launch,original)

if __name__=='__main__':
    began=time.monotonic();r=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(SourceGuard))
    record=dict(status='PASS_GENERATED_DYNAMIC_SOURCE_GUARD_ONLY' if r.wasSuccessful() else 'FAIL',tests_run=r.testsRun,failures=len(r.failures),errors=len(r.errors),source_guard_code_identity=g.launcher_code_identity(),script_SHA256=sha256(Path(__file__).read_bytes()).hexdigest(),actual_source_application_calls=0,actual_source_scopes_created=0,actual_source_callbacks=0,actual_accounts_constructed=0,actual_provider_iterations=0,actual_process_launches=0,actual_network_requests=0,actual_financial_claims=0,actual_financial_GO_writes=0,all_forbidden_attempts_are_intentional_negative_generated_tests=True,CPU_affinity=sorted(os.sched_getaffinity(0)),wall_seconds=time.monotonic()-began)
    (HERE/'SOURCE_GUARD_REVIEW.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n');raise SystemExit(not r.wasSuccessful())
