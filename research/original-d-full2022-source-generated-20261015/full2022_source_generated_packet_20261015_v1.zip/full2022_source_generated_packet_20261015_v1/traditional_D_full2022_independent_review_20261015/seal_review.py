"""Seal only already-run generated/static independent evidence."""
import os
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','POLARS_MAX_THREADS','VECLIB_MAXIMUM_THREADS'):os.environ[k]='1'
os.sched_setaffinity(0,{6})
import sys,json
from pathlib import Path
from hashlib import sha256
ROOT=Path(__file__).resolve().parents[1];HERE=Path(__file__).resolve().parent;NEW=ROOT/'traditional_D_full2022_20261015_v2';OLD=ROOT/'traditional_D_full2022_20261015';GUARD=ROOT/'traditional_D_full2022_source_stage_handoff_20261015/source_stage_guard.py'
sys.path.insert(0,str(NEW));import full_entry as e

def pin(p):
 b=Path(p).read_bytes();return {'SHA256':sha256(b).hexdigest(),'bytes':len(b)}
def read(p):return json.loads(Path(p).read_bytes())
expected='abb7d3cc390b9fe4fda01bc24f066fe04a4fd6c38f6c5b57dcf808f5f6af6a9c'
assert pin(NEW/'DELIVERABLE_PINS.json')['SHA256']==expected
for name,p in read(NEW/'DELIVERABLE_PINS.json').items():assert pin(NEW/name)==p,(name,pin(NEW/name),p)
assert pin(OLD/'DELIVERABLE_PINS.json')['SHA256']=='69b85e43c582bc0f2d614483eba498aa92ffbe9d466f6d29649496081389577a'
for name,p in read(OLD/'DELIVERABLE_PINS.json').items():assert pin(OLD/name)==p,name
implementation=read(NEW/'IMPLEMENTATION_RECEIPT.json');identity=e.code_identity()
assert identity==implementation['code_identity']
assert e._json_sha(identity)=='fbe6fb7dd93733931ee58c3fc3ed3061c2c754e18cb72065722901d54a7bfd9d'
source=read(HERE/'SOURCE_SEAMS_REVIEW.json');live=read(HERE/'LIVE_QUALITY_REVIEW.json');scopes=read(HERE/'RECORDING_SCOPE_REVIEW.json');guard=read(HERE/'SOURCE_GUARD_REVIEW.json');memory=read(HERE/'GENERATED_BRIDGE_MEMORY_OBSERVATION.json')
for result in (source,live,scopes,guard):assert result['status'].startswith('PASS_'),result['status']
for name,h in source['code'].items():assert pin(NEW/name)['SHA256']==h,name
for result,key in ((live,'source_files'),(scopes,'source_files')):
 for name,h in result[key].items():assert pin(NEW/name)['SHA256']==h,name
assert guard['source_guard_code_identity']=={str(GUARD.relative_to(ROOT)):pin(GUARD)['SHA256']}
assert memory['bridge_SHA256']==pin(NEW/'raw_source_bridge.py')['SHA256']
assert 'Ran 2 tests' in (HERE/'FROZEN_D_STATIC_REVIEW.log').read_text() and (HERE/'FROZEN_D_STATIC_REVIEW.log').read_text().rstrip().endswith('OK')
profile=read(NEW/'synthetic_probe_attempt001/GENERATED_POOL_PROFILE.json')
assert profile['generated_only'] and profile['annual_resource_envelope_certified'] is False
for row in profile['cases']:
 d=NEW/'synthetic_probe_attempt001'/row['cell_id'];cp=read(d/'TERMINAL_CHECKPOINT.json')
 assert pin(d/'TERMINAL_CHECKPOINT.json')['SHA256']==row['checkpoint_SHA256']
 for name,h in cp['files'].items():assert pin(d/name)['SHA256']==h
 r=read(d/'CASE_RECEIPT.json');proof=read(d/'GENERATED_PROOF.json')
 assert r['generated_only'] and r['generated_minutes']==4320 and r['actual_affinity']==[row['CPU']]
 assert all(a==[row['CPU']] for a in r['all_TID_affinities']) and all(v=='1' for v in r['thread_environment'].values())
 assert proof['passed'] and not proof['tolerance_or_epsilon_used']
raw_review=ROOT/'full2022_restored_source_independent_review_20261015/REVIEW_RECEIPT.json'
assert pin(raw_review)['SHA256']=='5a934063b763bd54f986a8ad8e8bb3222c737180ca03f5cafbccd4b51b521429'
record=dict(schema='INDEPENDENT_FULL2022_QUALIFIED_V2_AND_SOURCE_GUARD_GENERATED_REVIEW_V1',
 status='PASS_GENERATED_ONLY_EXACT_V2_AND_GUARDED_SOURCE_STAGE_CODE',
 admitted_scope='STATIC_AND_GENERATED_ONLY_IMPLEMENTATION_REVIEW_NO_ACTUAL_SOURCE_APPLICATION_OR_HISTORICAL_GO',
 execution_directory=NEW.name,execution_DELIVERABLE_PINS=pin(NEW/'DELIVERABLE_PINS.json'),implementation_receipt=pin(NEW/'IMPLEMENTATION_RECEIPT.json'),
 execution_code_identity=identity,execution_code_identity_SHA256=e._json_sha(identity),source_guard_code_identity=guard['source_guard_code_identity'],
 unchanged_prior_checkpoint=dict(directory=OLD.name,DELIVERABLE_PINS=pin(OLD/'DELIVERABLE_PINS.json'),all_24_pinned_files_byte_exact=True),
 independent_tests=dict(source_and_admission=13,live_per_asset_quality=5,recording_scope_and_revocation=5,frozen_D_AST_and_code_objects=2,dynamic_source_guard=7,total=32),
 actual_raw_source_review_reused=dict(path=str(raw_review.relative_to(ROOT)),**pin(raw_review),source_body_revalidation_repeated_by_this_reviewer=False),
 declared_source_pins=dict(final_delivery_SHA256=e.s.FINAL_PINS,raw_qualification_SHA256=e.s.SOURCE_QUALIFICATION_SHA256,independent_raw_review_SHA256=e.s.SOURCE_INDEPENDENT_REVIEW_SHA256),
 reviewed_findings=[
 'Exact Jan1-Dec31 full2022 nine fresh 10000-wallet descriptors, fixed BASE27/coarse profile/cash1000/margin8500/Dguard50/terminal60; no strategy or financial formula changes.',
 'Pure carry output on all27 synthetic holes matches frozen v4 prices, original source identity and all source/evaluation clocks; actual symbols never enter the v4 generated API.',
 'Exact27 original OPEN metadata shape remains27 cells/11 clocks/8 asset runs/max7/four singleton runs; no raw price body was needed by this review.',
 'QualityCell and observation contracts explicitly label completion availability and installation as OFFLINE_MODEL; actual publication, arrival and installation remain UNKNOWN_NOT_CERTIFIED.',
 'Generated live tests prove original per-asset anchor age and UNKNOWN installed before native immediate risk; nominal interval end or freshly stamped derived marks never restore quality; each symbol needs its own installed genuine recovery.',
 'Source-only authority uses explicit external expected SHA plus exact source qualification, reviewed code identity and new adapter review; historical GO and review remain separate explicit expectations.',
 'Unbound providers and recording-only scope providers fail before decode; provider binding also requires the exact entry-owned provider reference.',
 'Recording metadata scopes are a separate inputless class, rejected by financial constructors and providers, revoked after each callback and on exceptions; actual-domain helper requires validated source-stage authority.',
 'Pure preparation and input fingerprints reject exact-type, calendar, source identity, tier, target, mutable input and source/quality/funding swaps or produce distinct hashes that cannot match admitted input commitments.',
 'Raw bridge parses each stream/month without retaining annual string-row dictionaries; original ZIP/checksum and genuine daily repair provenance remain separately captured.',
 'Dynamic guard denies all nine financial/provider/process/network/claim/GO categories before action; caught attempts are fatal at exit; safe generated9 callbacks have observed zero forbidden calls.',
 'Historical claim target fields come from admitted preparation digests, rather than manifest null placeholders; frozen native40 proof remains primary and raw100 diagnostics remain separate.'
 ],
 synthetic_memory_observation=dict(evidence=pin(HERE/'GENERATED_BRIDGE_MEMORY_OBSERVATION.json'),minutes=44640,max_RSS_bytes=memory['max_RSS_after_bytes'],python_traced_peak_bytes=memory['python_traced_peak_bytes'],same_exact_parser_SHA256=memory['bridge_SHA256'],actual_annual_resource_envelope_certified=False),
 author_synthetic_two_worker_probe=dict(profile=pin(NEW/'synthetic_probe_attempt001/GENERATED_POOL_PROFILE.json'),checkpoint_hashes_verified=True,CPUs=[4,5],minutes_per_worker=4320,overlap_observations=sum(len(r['workers'])==2 for r in profile['observations']),peak_observed_aggregate_RSS_bytes=max(r['aggregate_live_RSS_bytes'] for r in profile['observations']),helper_TIDs_and_one_thread_pool_contract_verified=True,temporary_lease_inherited=True,exact_no_epsilon_proofs=True,actual_annual_resource_envelope_certified=False),
 required_source_stage_route=dict(launcher=str(GUARD.relative_to(ROOT)),call='guarded_prepare',guard_code_identity_must_be_externally_root_bound=True,unguarded_prepare_source_py_is_not_the_admitted_invocation=True,actual_guard_receipt_must_show_zero_forbidden_calls_and_all9_recording_scopes_revoked=True),
 no_actual_activity_by_this_reviewer=dict(source_market_body_reads=0,source_normalizations=0,actual_causal_overlay_applications=0,actual_targets_generated=0,actual_source_positive_callbacks=0,actual_source_scopes=0,historical_scopes=0,actual_accounts_constructed=0,actual_accounts_advanced=0,actual_provider_iterations=0,actual_process_probes=0,financial_claims=0,valid_GO_written=0,external_network_requests=0,publication_actions=0),
 remaining_unrun_and_not_certified=[
 'Actual raw-to-native normalization, genuine daily-close parity and all-source transport/code/quality binding on the qualified2022 bodies.',
 'Actual causal27 application, output quality sidecar, target/covariance artifacts and nine actual recording-only metadata callbacks under a separate root source-stage GO.',
 'Actual-source dynamic guard receipt, output/source provenance and independent post-preparation review.',
 'Actual annual native resource fit; saved27 event/position/funding/risk/execution impacts and sensitivities.',
 'A separate exact historical independent review and root financial GO before any historical scope/account/provider iteration/process/claim.'
 ],
 financial_GO_eligible=False,historical_execution_authorized=False,actual_source_stage_authorized_by_this_receipt=False,publication_authorized=False,
 evidence={p.name:pin(p) for p in HERE.iterdir() if p.is_file() and p.suffix in ('.py','.json','.log') and p.name!='INDEPENDENT_REVIEW_RECEIPT.json'},
 CPU_affinity=[6])
(HERE/'INDEPENDENT_REVIEW_RECEIPT.json').write_text(json.dumps(record,indent=2,sort_keys=True,allow_nan=False)+'\n')
print(json.dumps(dict(status=record['status'],receipt=pin(HERE/'INDEPENDENT_REVIEW_RECEIPT.json'),independent_tests=record['independent_tests'],source_guard_code_identity=record['source_guard_code_identity']),sort_keys=True))
