"""Independent generated-only new source, overlay and closed-authority seams.
No actual 2022 market bodies, source callbacks, scopes, accounts or processes.
"""
import os
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','POLARS_MAX_THREADS','VECLIB_MAXIMUM_THREADS'):os.environ[k]='1'
os.sched_setaffinity(0,{6})
import sys,json,unittest,importlib.util,time,resource
from pathlib import Path
from dataclasses import replace,asdict
from copy import deepcopy
from hashlib import sha256
from io import BytesIO
from types import MappingProxyType
import polars as pl
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1];HERE=Path(__file__).resolve().parent;NEW=ROOT/os.environ.get('FULL2022_REVIEW_DIR','traditional_D_full2022_20261015')
blocked=[]
def audit(event,args):
    if event!='open' or not args or not isinstance(args[0],(str,bytes,os.PathLike)):return
    p=Path(os.fsdecode(args[0])).resolve()
    if p.suffix in ('.py','.pyc','.so'):return
    if ROOT in p.parents and (any(x.startswith(('full2022_unaffected_source_restore','native_2022_source','native_h1_2022_source','coin_partial_restore')) for x in p.parts) and '.venv' not in p.parts or p.name.upper().startswith('ROOT_GO') and NEW not in p.parents):
        blocked.append(str(p));raise AssertionError('FORBIDDEN_ACTUAL_SOURCE_OR_OLD_AUTHORITY_READ:'+str(p))
sys.addaudithook(audit)
sys.path.insert(0,str(NEW))
import numpy as np
import full_source as s
import source_overlay as ov
import source_projection as projection
import full_entry as entry
import raw_source_bridge as bridge
import zipfile
spec=importlib.util.spec_from_file_location('review_exact_frozen_v4_overlay',ROOT/'causal_isolated_mark_overlay_20261015_v4/overlay.py')
v4=importlib.util.module_from_spec(spec);sys.modules[spec.name]=v4;spec.loader.exec_module(v4)

def qualification():
    return dict(schema='FULL2022_COMPLETE_SOURCE_QUALIFICATION_V1',status='PASS_SOURCE_ONLY_NO_HISTORICAL_GO',year=2022,calendar=[s.START,s.END],days=365,minute_count=525600,monthly_original_streams=120,original_ZIP_bytes=158411229,genuine_daily_repairs=16,genuine_daily_added_asset_minutes=23040,daily_projection_rows=564,daily_projection_calendar=[s.ALLOWED_START,s.END-s.DAY],daily_projection_strictly_before_us=s.END,ready_200close_decisions=365,raw_funding_events=5550,remaining_missing_trade_cells=0,remaining_missing_mark_cells=27,unique_mark_gap_open_clocks=11,mark_gap_asset_runs=8,mark_gap_singleton_runs=4,mark_gap_longest_run=7,endpoint_open_us=s.END-s.MINUTE,endpoint_completed_us=s.END,endpoint_origin='GENUINE_DEC31_2359_NATIVE_BAR',selected_2023_daily_cube_rows=0,historical_arrival_certified=False,funding_unit_certified=False,native_exchange_certified=False,source_observation_implies_ownership=False,accounts_constructed=0,historical_runs=0,source_identity='a'*64,provenance_SHA256='b'*64,allowlist_SHA256=s.ACTUAL_ALLOWLIST_SHA256,endpoint_source_SHA256='c'*64)

def fake_anchors():
    missing={(h.symbol,h.minute_open_ms) for h in v4.FIXTURE_HOLES};obs={}
    for h in v4.FIXTURE_HOLES:
        if (h.symbol,h.minute_open_ms-v4.MINUTE) in missing:continue
        for gap in (2,1):
            at=h.minute_open_ms-gap*v4.MINUTE
            key=(h.symbol,at)
            if key in missing:continue
            ident='GENERATED:'+h.symbol+':'+str(at)
            obs[key]=v4.GenuineObservation(ident,h.symbol,at,at+v4.MINUTE-1,at+v4.MINUTE,at+v4.MINUTE,at+v4.MINUTE,'001.23000000000000000000000001','a'*64,ident)
    return tuple(obs.values())

def new_obs(obs):return tuple(ov.GenuineMarkObservation(o.symbol,o.minute_open_ms*1000,o.completed_at_ms*1000,o.available_at_ms*1000,o.installed_at_ms*1000,o.price_text,o.source_sha256,o.source_record_id) for o in obs)
def new_holes():return tuple((h.symbol,h.minute_open_ms*1000) for h in v4.FIXTURE_HOLES)
def fake_preparation_metadata():
    code={'GENERATED_FIXTURE_NOT_RUNTIME_IDENTITY':'1'*64};policy=entry._policy(code)
    info=dict(year=2022,source_qualification=qualification(),source_identity='a'*64,quality_sidecar_sha256='d'*64,decision_raw_SHA256='e'*64,covariance_raw_SHA256='f'*64,calendar=[s.START,s.END],days=365,required_minutes=525600,quality_cell_count=27,quality_arrival_status='UNKNOWN_NOT_CERTIFIED',actual_gap_impact='PENDING_ACTUAL_SAVED_EVIDENCE')
    cells={}
    for c in entry.frozen_manifest()['cells']:
        binding=dict(cell_id=c['cell_id'],year=2022,config=c['config'],tier=c['tier'],calendar=c['calendar'],selected_target_raw_SHA256='2'*64)
        cells[c['cell_id']]=dict(cell_id=c['cell_id'],year=2022,config=c['config'],tier=c['tier'],descriptor=c,input_binding=binding,input_binding_SHA256=s.jsha(binding),selected_target_raw_SHA256='2'*64,quality_sidecar_sha256='d'*64,decision_raw_SHA256='e'*64,covariance_raw_SHA256='f'*64)
    return dict(schema=entry.PREPARATION_SCHEMA,status='PREPARED_SOURCE_TARGET_ONLY_NO_HISTORICAL_ACCOUNT_OR_GO',policy_version=entry.POLICY_VERSION,source_scope=entry.SOURCE_SCOPE,manifest_SHA256=entry.MANIFEST_SHA256,ordered_cells=list(entry.tranche_cells()),cost=entry.COST,modes=list(entry.MODES),settlement_mode=entry.SETTLEMENT_MODE,historical_admission=False,accounts_created=0,accounts_advanced=0,financial_runs=0,provider_iterations=0,historical_scopes_created=0,process_launches=0,canonical_claims_created=0,real_GO_written=0,publication_actions=0,other_years_or_2025_authorized=False,execution_requires_new_exact_external_root_GO=True,all_inputs_seen_development=True,performance_selection_allowed=False,years={'2022':info},cells=cells,code_identity=code,policy=policy,policy_identity=s.jsha(policy),artifacts={'2022/'+n:dict(SHA256='3'*64,bytes=1) for n in ('TARGETS.npz','TARGET_PROOFS.json','DAILY_SOURCE_PROJECTION.json','MINUTE_MARK_PROVENANCE.json','EXACT_EXECUTION_EQUALITY.json','SOURCE_PREP_GO.json')})

class Explodes:
    def __iter__(self):raise AssertionError('UNAUTHORIZED_OBSERVATION_ITERATION')

class SourceSeams(unittest.TestCase):
    def test_all_actual_pins_absent_and_callback_paths_close_before_observations(self):
        for key in ('SOURCE_STAGE_GO_SHA256','HISTORICAL_ROOT_GO_SHA256','HISTORICAL_REVIEW_SHA256'):
            self.assertIsNone(getattr(s,key,None))
        with self.assertRaises(ValueError):s.apply_actual_causal_marks(Explodes(),source_scope=None,as_of_us=s.END)
        with self.assertRaises(ValueError):s.admit_actual_source_stage(b'{}',b'{}',s.sha(b'{}'))
        with self.assertRaises(ValueError):entry.prepare_source_only({2022:'/NONEXISTENT_GENERATED_NO_READ'},'/tmp/UNAUTHORIZED_NEVER_CREATED',source_authorization_raw=b'{}',expected_source_authorization_sha256=s.sha(b'{}'))
        with self.assertRaises(ValueError):s.project('/NONEXISTENT_GENERATED_NO_READ')
        with self.assertRaises(ValueError):entry.validate_root_go(b'{}',b'{}',s.sha(b'{}'),cell_id=entry.tranche_cells()[0])
        with self.assertRaises(ValueError):entry._validate_independent_review(b'{}',{},b'{}',None,b'{}')
    def test_empty_synthetic_provider_is_unexecutable_before_historical_scope(self):
        fake=s.CapturedMinuteProvider(2022,(),())
        with patch.object(projection,'month_arrays',side_effect=AssertionError('DECODE_FORBIDDEN')) as decode:
            with self.assertRaisesRegex(ValueError,'HISTORICAL_PROVIDER_REQUIRES_SEPARATE_ROOT_GO'):next(fake())
            decode.assert_not_called()
        for forged in (None,object(),'GENERATED',qualification()):
            with self.assertRaises(ValueError):fake._bind_historical_scope(forged)
        self.assertIsNone(fake._historical_scope)

    def test_metadata_qualification_is_pure_and_exact_types(self):
        q=qualification();result=s.SourceQualificationBinding.validate(q)
        self.assertEqual(result.source_identity,'a'*64)
        for name,value in tuple(q.items()):
            bad=dict(q)
            if type(value) is bool:bad[name]=int(value)
            elif type(value) is int:bad[name]=float(value)
            else:continue
            with self.subTest(name=name),self.assertRaises(ValueError):s.SourceQualificationBinding.validate(bad)
        for name in ('source_identity','provenance_SHA256','allowlist_SHA256','endpoint_source_SHA256'):
            for val in ('0'*63,'X'*64,None):
                bad=dict(q);bad[name]=val
                with self.assertRaises(ValueError):s.SourceQualificationBinding.validate(bad)
    def test_pure_preparation_metadata_rejects_swapped_identity_calendar_cell_and_types(self):
        base=fake_preparation_metadata();entry.validate_preparation_metadata(s.canonical(base))
        first=entry.tranche_cells()[0]
        changes=[('year_days_float',lambda p:p['years']['2022'].__setitem__('days',365.0)),('year_minutes_float',lambda p:p['years']['2022'].__setitem__('required_minutes',525600.0)),('cell_year_float',lambda p:p['cells'][first].__setitem__('year',2022.0)),('source_identity_mismatch',lambda p:p['years']['2022'].__setitem__('source_identity','4'*64)),('quality_count_bool',lambda p:p['years']['2022'].__setitem__('quality_cell_count',True)),('selected_target_sha_mismatch',lambda p:p['cells'][first].__setitem__('selected_target_raw_SHA256','4'*64)),('cell_tier_mismatch',lambda p:p['cells'][first].__setitem__('tier','HIGH')),('calendar_mismatch',lambda p:p['years']['2022'].__setitem__('calendar',[s.START+s.DAY,s.END]))]
        for name,change in changes:
            p=deepcopy(base);change(p)
            with self.subTest(name=name),self.assertRaises(ValueError):entry.validate_preparation_metadata(s.canonical(p))

    def test_pure_input_fingerprint_rejects_mutability_and_detects_source_target_quality_swaps(self):
        c=dict(entry.cell_descriptor(entry.tranche_cells()[0]))
        decisions=np.arange(s.START,s.END,s.DAY,dtype=np.int64);targets=np.zeros((365,5),dtype=np.float64);cov=np.repeat(np.eye(5)[None,:,:],365,axis=0)
        for a in (decisions,targets,cov):a.setflags(write=False)
        c['selected_target_raw_SHA256']=s.sha(targets.tobytes())
        rows=(MappingProxyType(dict(symbol='GENERATED_FIXTURE_ONLY',close_us=1,available_us=1,close=1.)),)
        w=dict(start=s.START,end=s.END,symbols=s.S,daily=pl.DataFrame([dict(x=1)]),events=(),minute_blocks=s.CapturedMinuteProvider(2022,(),()),derived_mark_cells=27,original_missing_mark_open_ms=(),original_overlay_future_looking=False,original_overlay_execution_admitted=False,causal_mark_adapter=s.immutable(dict(fixture='GENERATED_EMPTY_PROVIDER_NO_ACTUAL_SOURCE')))
        window=MappingProxyType(w);base=entry._input_binding(c,window,rows,decisions,targets,cov)
        for args in ((dict(window),rows,decisions,targets,cov),(window,tuple(dict(r) for r in rows),decisions,targets,cov),(window,rows,decisions,targets.copy(),cov),(window,rows,decisions,targets,cov.copy())):
            with self.assertRaises(ValueError):entry._input_binding(c,*args)
        badtarget=targets.copy();badtarget[0,0]=.001;badtarget.setflags(write=False)
        with self.assertRaises(ValueError):entry._input_binding(c,window,rows,decisions,badtarget,cov)
        for changes in ({'start':s.START+s.MINUTE},{'symbols':tuple(reversed(s.S))},{'minute_blocks':s.CapturedMinuteProvider(2021,(),())}):
            changed=dict(w);changed.update(changes)
            with self.assertRaises(ValueError):entry._input_binding(c,MappingProxyType(changed),rows,decisions,targets,cov)
        for changes in ({'causal_mark_adapter':s.immutable(dict(fixture='SWAPPED_FAKE_QUALITY'))},{'events':(MappingProxyType(dict(fixture='SWAPPED_FAKE_FUNDING')),)}):
            changed=dict(w);changed.update(changes);other=entry._input_binding(c,MappingProxyType(changed),rows,decisions,targets,cov)
            self.assertNotEqual(s.jsha(base),s.jsha(other))
        changedrows=(MappingProxyType(dict(rows[0],close=2.)),)
        self.assertNotEqual(s.jsha(base),s.jsha(entry._input_binding(c,window,changedrows,decisions,targets,cov)))

    def test_exact27_metadata_shape_and_original_open_semantics(self):
        holes=s.ACTUAL27_OPEN_POINTS_US;self.assertEqual(len(holes),27);self.assertEqual(len({at for _,at in holes}),11)
        lens=[]
        for symbol in sorted({x[0] for x in holes}):
            times=sorted(at for sym,at in holes if sym==symbol);n=1
            for a,b in zip(times,times[1:]):
                if b==a+s.MINUTE:n+=1
                else:lens.append(n);n=1
            lens.append(n)
        self.assertEqual(sorted(lens),[1,1,1,1,5,5,6,7])
        self.assertTrue(all(at%s.MINUTE==0 and s.START<=at<s.END for _,at in holes))
    def test_new_pure_carry_exact_frozen_v4_algorithm_equivalence_all27(self):
        old_obs=fake_anchors();holes=new_holes();new=ov.build_generated_overlay(new_obs(old_obs),holes,as_of_us=(v4.FIXTURE_BASE_MS+1100*v4.MINUTE)*1000)
        old=v4.build_generated_overlay(old_obs,v4.FIXTURE_HOLES,as_of_ms=v4.FIXTURE_BASE_MS+1100*v4.MINUTE)
        self.assertEqual(len(new),27)
        for c,r in zip(new,old.records):
            self.assertEqual((c.symbol,c.minute_open_us,c.completed_us,c.evaluation_us,c.price_text,c.anchor_open_us,c.anchor_completed_us,c.anchor_available_us,c.anchor_installed_us,c.source_freshness_clock_us,c.anchor_source_SHA256,c.anchor_record_id),(r.symbol,r.minute_open_ms*1000,r.completed_at_ms*1000,r.evaluation_clock_ms*1000,r.price_text,r.anchor_minute_open_ms*1000,r.anchor_completed_at_ms*1000,r.anchor_available_at_ms*1000,r.anchor_installed_at_ms*1000,r.source_freshness_clock_ms*1000,r.anchor_source_sha256,r.anchor_source_record_id))
            self.assertEqual(c.quality,'UNKNOWN_OR_DERIVED');self.assertFalse(c.certifies_liquidation);self.assertFalse(c.certifies_no_liquidation)
    def test_future_perturbations_never_change_prior_anchor_prices_or_age(self):
        obs=new_obs(fake_anchors());holes=new_holes();asof=(v4.FIXTURE_BASE_MS+1100*v4.MINUTE)*1000
        base=ov.build_generated_overlay(obs,holes,as_of_us=asof)
        future=ov.GenuineMarkObservation('FIXTURE_ETH',asof,asof+s.MINUTE,asof+s.MINUTE,asof+s.MINUTE,'9999999999999999','b'*64,'GENERATED_FUTURE')
        self.assertEqual(base,ov.build_generated_overlay(obs+(future,),holes,as_of_us=asof))
        self.assertEqual(base,ov.build_generated_overlay(obs+(replace(future,price_text='0.00000000000001'),),holes,as_of_us=asof))
    def test_carry_rejects_late_install_wrong_domain_derived_present_or_forged(self):
        obs=new_obs(fake_anchors());holes=new_holes();asof=(v4.FIXTURE_BASE_MS+1100*v4.MINUTE)*1000
        first=min(obs,key=lambda o:o.minute_open_us)
        for changes in ({'quality':'UNKNOWN_OR_DERIVED'},{'domain':'TRADE'},{'selected_field':'volume'},{'price_text':'0'},{'source_SHA256':'f'*63}):
            damaged=tuple(replace(o,**changes) if o==first else o for o in obs)
            with self.subTest(changes=changes),self.assertRaises((ValueError,ArithmeticError)):ov.build_generated_overlay(damaged,holes,as_of_us=asof)
        sym,at=holes[0]
        present=ov.GenuineMarkObservation(sym,at,at+s.MINUTE,at+s.MINUTE,at+s.MINUTE,'123','c'*64,'GENERATED_PRESENT_HOLE')
        with self.assertRaises(ValueError):ov.build_generated_overlay(obs+(present,),holes,as_of_us=asof)
        with self.assertRaises(ValueError):ov.build_generated_overlay(obs,tuple((symbol.replace('FIXTURE_','BTC'),t) for symbol,t in holes),as_of_us=asof)
    def test_month_arrays_generated_clock_quality_finite_and_immutable_contract(self):
        start=978307200000000;count=4;times=start+np.arange(count,dtype=np.int64)*s.MINUTE
        arrays={'times':times,'available_us':times+s.MINUTE}
        for symbol in s.S:
            for k in ('open','close','quote_volume','mark'):arrays[symbol+'_'+k]=np.full(count,1.25,dtype=np.float64)
        def archive(data):
            b=BytesIO();np.savez_compressed(b,**data);return b.getvalue()
        out,missing=projection.month_arrays(archive(arrays),start,count,())
        self.assertEqual(missing,());self.assertTrue(all(not a.flags.writeable for a in out.values()))
        for field,val in (('available_us',times+s.MINUTE-1),('times',times.astype(float)),('BTCUSDT_open',np.array([1.,0,1,1])),('BTCUSDT_mark',np.array([1.,np.nan,1,1]))):
            changed=dict(arrays);changed[field]=val
            with self.subTest(field=field),self.assertRaises(ValueError):projection.month_arrays(archive(changed),start,count,())
    def test_pure_daily_projection_uses_exact_frozen_strategy_and_future_prefix_causality(self):
        times=np.arange(s.ALLOWED_START,s.END,s.DAY,dtype=np.int64)
        x=np.arange(564,dtype=np.float64)
        close=np.column_stack([(j+1)*100*(1+.0002*x+.002*np.sin(x/(7+j))) for j in range(5)]).astype(np.float64)
        def archive(t=times,p=close,syms=s.S):
            b=BytesIO();np.savez_compressed(b,symbol_order=np.asarray(syms),close_available_us=t,close=p);return b.getvalue()
        d,targets,cov,proofs,rows,daily,meta=projection.project_daily_grid(archive())
        self.assertEqual(d.shape,(365,));self.assertEqual(len(rows),564*5);self.assertEqual(daily.height,365*5)
        self.assertEqual(int(d[0]),s.START);self.assertEqual(int(d[-1]),s.END-s.DAY)
        self.assertTrue(all(not a.flags.writeable for a in (d,cov,*targets.values())))
        import frozen_grid as grid
        expected=grid.build_target_grid(close,times,times.copy(),np.arange(s.START,s.END,s.DAY,dtype=np.int64))
        self.assertEqual(d.tobytes(),expected[0].tobytes());self.assertEqual(cov.tobytes(),expected[2].tobytes())
        for k in s.CONFIGS:self.assertEqual(targets[k].tobytes(),expected[1][k].tobytes())
        later=close.copy();later[-1,:]*=10
        altered=projection.project_daily_grid(archive(p=later))
        for k in s.CONFIGS:self.assertEqual(targets[k][:-1].tobytes(),altered[1][k][:-1].tobytes())
        for t,p,syms in ((times[:-1],close[:-1],s.S),(np.append(times,s.END),np.vstack([close,close[-1]]),s.S),(times,close,tuple(reversed(s.S))),(times.astype(float),close,s.S)):
            with self.assertRaises(ValueError):projection.project_daily_grid(archive(t,p,syms))

    def test_raw_zip_bridge_pure_fake_parser_clock_domain_ohlc_and_member_contract(self):
        # Synthetic one-row CSV. It is deliberately incomplete and never
        # presented as a qualified month or passed to actual application.
        opened=s.START//1000
        row=[str(opened),'100','102','99','101','5',str(opened+59999),'505','4','2','202','0']
        def archive(lines,member='BTCUSDT-1m-2022-01.csv'):
            b=BytesIO()
            with zipfile.ZipFile(b,'w',compression=zipfile.ZIP_DEFLATED) as z:z.writestr(member,'\n'.join(','.join(x) for x in lines)+'\n')
            return b.getvalue()
        rows,meta=bridge.parse_original_zip(archive([row]),symbol='BTCUSDT',period='2022-01',family='klines')
        self.assertEqual(tuple(rows),(s.START,));self.assertEqual(rows[s.START],tuple(row));self.assertEqual(meta['observed_minutes'],1)
        for col,value in ((0,str(opened+1)),(6,str(opened+60000)),(1,'0'),(2,'100'),(3,'102'),(5,'-1'),(7,'NaN')):
            bad=row.copy();bad[col]=value
            with self.subTest(col=col,value=value),self.assertRaises(ValueError):bridge.parse_original_zip(archive([bad]),symbol='BTCUSDT',period='2022-01',family='klines')
        with self.assertRaises(ValueError):bridge.parse_original_zip(archive([row],member='../BTCUSDT-1m-2022-01.csv'),symbol='BTCUSDT',period='2022-01',family='klines')
        conflict=row.copy();conflict[4]='100'
        with self.assertRaises(ValueError):bridge.parse_original_zip(archive([row,conflict]),symbol='BTCUSDT',period='2022-01',family='klines')
        for symbol,family in (('FAKE','klines'),('BTCUSDT','TRADE')):
            with self.assertRaises(ValueError):bridge.parse_original_zip(archive([row]),symbol=symbol,period='2022-01',family=family)
        with self.assertRaises(ValueError):bridge.capture_and_normalize('/NONEXISTENT_GENERATED_NO_READ',source_authorization_raw=b'{}',expected_source_authorization_sha256=None)

    def test_portable_relative_names(self):
        self.assertEqual(projection.relative('month/FAKE.npz'),'month/FAKE.npz')
        for name in ('/absolute','../parent','a/../b','a\\b','a//b'):
            with self.assertRaises(ValueError):projection.relative(name)

if __name__=='__main__':
    began=time.monotonic();result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(SourceSeams))
    record=dict(status='PASS_GENERATED_NEW_SOURCE_SEAMS_ONLY' if result.wasSuccessful() else 'FAIL',tests_run=result.testsRun,failures=len(result.failures),errors=len(result.errors),actual_market_body_reads=0,actual_source_callback_calls=0,actual_overlay_records=0,historical_scopes_created=0,actual_accounts_constructed=0,process_probes=0,canonical_claims=0,old_authority_body_attempts=blocked,code={p.name:sha256(p.read_bytes()).hexdigest() for p in NEW.glob('*.py')},script_SHA256=sha256(Path(__file__).read_bytes()).hexdigest(),wall_seconds=time.monotonic()-began,CPU_affinity=sorted(os.sched_getaffinity(0)),max_RSS_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024)
    (HERE/'SOURCE_SEAMS_REVIEW.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n');raise SystemExit(not result.wasSuccessful())
