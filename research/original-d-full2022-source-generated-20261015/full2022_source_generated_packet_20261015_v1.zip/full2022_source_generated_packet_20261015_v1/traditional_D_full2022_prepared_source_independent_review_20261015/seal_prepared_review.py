"""Seal preparation-bound source/generated evidence only; no historical admission."""
import os
for _k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','POLARS_MAX_THREADS','VECLIB_MAXIMUM_THREADS'):os.environ[_k]='1'
os.sched_setaffinity(0,{6})
import hashlib,json,sys
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];HERE=Path(__file__).resolve().parent;EXEC=ROOT/'traditional_D_full2022_20261015_v2';PREP=ROOT/'traditional_D_full2022_20261015_v2_source_preparation_attempt001';PRI=ROOT/'traditional_D_full2022_independent_review_20261015';HAND=ROOT/'traditional_D_full2022_source_stage_handoff_20261015'
sys.path.insert(0,str(EXEC));import full_entry as e
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(Path(p).read_bytes())
def pin(p):
 p=Path(p);assert p.is_file() and not p.is_symlink();b=p.read_bytes();return dict(path=str(p.relative_to(ROOT)),SHA256=sha(b),bytes=len(b))
def save(name,value):
 with (HERE/name).open('x') as f:json.dump(value,f,indent=2,sort_keys=True,allow_nan=False);f.write('\n')
raw=(PREP/'PREPARATION.json').read_bytes();p=e.validate_preparation_metadata(raw);audit=read(HERE/'SAVED_SOURCE_AUDIT.json');datafree=read(HERE/'DATA_FREE_FLAGS_REVIEW.json')
assert audit['status']=='PASS_SAVED_SOURCE_TARGET_QUALITY_BINDINGS' and audit['check_count']==993
assert datafree['status']=='PASS_TWO_DATA_FREE_FLAGS_NO_ACCOUNT_PROVIDER_OR_PROJECTOR' and datafree['tests_run']==2
assert sha((EXEC/'DELIVERABLE_PINS.json').read_bytes())=='abb7d3cc390b9fe4fda01bc24f066fe04a4fd6c38f6c5b57dcf808f5f6af6a9c'
assert e.code_identity()==p['code_identity'] and e._json_sha(p['code_identity'])=='fbe6fb7dd93733931ee58c3fc3ed3061c2c754e18cb72065722901d54a7bfd9d'
for key in ('forbidden_attempts',):assert all(v==0 for v in datafree['reports']['fake_risk_report']['guard'][key].values())
assert datafree['reports']['fake_risk_report']['guard']['allowed_scope_constructions']==dict(source_application_scopes=0,recording_metadata_scopes=0)
assert (EXEC/'GENERATED_TESTS.log').read_text().rstrip().endswith('OK') and 'Ran 41 tests' in (EXEC/'GENERATED_TESTS.log').read_text()
profile=read(EXEC/'synthetic_probe_attempt001/GENERATED_POOL_PROFILE.json')
assert profile['generated_only'] is True and profile['annual_resource_envelope_certified'] is False
synthetic_pins=[pin(EXEC/'synthetic_probe_attempt001/GENERATED_POOL_PROFILE.json')]
for row in profile['cases']:
 folder=EXEC/'synthetic_probe_attempt001'/row['cell_id'];cp=read(folder/'TERMINAL_CHECKPOINT.json')
 assert pin(folder/'TERMINAL_CHECKPOINT.json')['SHA256']==row['checkpoint_SHA256']
 synthetic_pins.append(pin(folder/'TERMINAL_CHECKPOINT.json'))
 for name,digest in cp['files'].items():assert pin(folder/name)['SHA256']==digest;synthetic_pins.append(pin(folder/name))
 receipt=read(folder/'CASE_RECEIPT.json');proof=read(folder/'GENERATED_PROOF.json')
 assert receipt['generated_only'] is True and receipt['generated_minutes']==4320 and receipt['actual_affinity']==[row['CPU']] and all(a==[row['CPU']] for a in receipt['all_TID_affinities']) and all(v=='1' for v in receipt['thread_environment'].values())
 assert proof['passed'] and proof['tolerance_or_epsilon_used'] is False

flag_evidence={
 'generated_native_scheduler_phase_order_passed':['Exact reviewed frozen D AST/code-object identity; author41 test_sameclock_nonzero_funding_batch_then_warning; exact generated two-worker native checkpoints.'],
 'generated_shared_pending_32_corner_passed':['Author41 test_fresh_all_32_shared_wallet_corners_all_tiers_and_forks; test_MID_gap_signal_transport_exact_frozen_D_finance_and_pending.'],
 'generated_preview_isolation_passed':['Author41 test_fresh_all_32_shared_wallet_corners_all_tiers_and_forks; exact frozen preview code-object identity.'],
 'generated_causal_quality_passed':['Independent32 SOURCE_SEAMS_REVIEW and LIVE_QUALITY_REVIEW; all27 actual anchor/source-clock review.'],
 'generated_terminal_taxonomy_passed':['Author41 generated native calendar/result tests; exact frozen classifier/terminal60 code and generated checkpoint proofs.'],
 'generated_unknown_quality_no_new_exit_passed':['Author41 test_known_unknown_quality_and_terminal_rule_remain_D; independent32 LIVE_QUALITY_REVIEW, original source age and installed genuine recovery checks.'],
 'generated_guard50_paid_exit_no_topup_passed':['Author41 test_warning_finance_and_intent_equal_frozen_D_in_every_tier and frozen code-object identity; active synthetic paid fills with no transfer/conditional-settlement proof.'],
 'generated_exact_cell_year_tier_target_quality_gates_passed':['Independent32 SOURCE_SEAMS_REVIEW pure preparation/input fingerprint mutation tests; 993-check actual saved binding audit.'],
 'generated_frozen_manifest_and_ordered_tranche_gates_passed':['Author41 test_exact_nine_no_alias_and_calendar; independent32 SOURCE_SEAMS_REVIEW; actual recording callbacks exactly ordered9.'],
 'generated_pool_resource_and_aggregate_pressure_gates_passed':['Author41 RunnerTests affinity/pressure/duplicate/existing-output tests; exact saved two-worker synthetic profile. Actual annual resource fit is not certified.'],
 'generated_canonical_launch_claim_duplicate_and_existing_output_gates_passed':['Author41 canonical_claims_permanent_across_outputs, existing_output_and_unfinished_output_pause_no_spawn, duplicate_jobs_and_low_memory_pause_before_spawn. No real financial claim exists.'],
 'generated_global_controller_lease_inherited_worker_FD_gates_passed':['Author41 global_nine_cell_controller_lease_rejects_overlap; synthetic profile inherited lease inode/FD and exact saved worker checkpoints.'],
 'generated_helper_thread_affinity_and_compute_pool_contract_passed':['Exact saved synthetic profile/worker receipts checked: all helper TIDs use single assigned CPU and all numerical pools configured1. Actual host quota and full-year fit remain unverified.'],
 'generated_actual_held_exposure_forecast_overshoot_reporting_passed':['New independent DATA_FREE_FLAGS_REVIEW test_fake_saved_minute_exposure_forecast_overshoot_and_roundtrip: unchanged held-risk AST/frozen reporter SHA, obvious fake six-minute2001 fixture, three independently calculated breach minutes, saved-only roundtrip and deliberate zero-overshoot corruption rejection. No account/provider/simulator is constructed.'],
 'generated_native40_raw100_financial_reconstruction_passed':['Author41 test_generated_native40 six tests cover chronological native40 proof and nonzero raw100 fractional residual preservation, corrupt arithmetic failure and no relabelled conditional flat; exact synthetic checkpoints checked.'],
 'independent_actual2022_source_target_equivalence_passed':['993-check independent actual saved-source audit: all365 decisions/covariances/nine target arrays and canonical proofs exactly recomputed from bounded daily projection. Native transport is reviewed deterministic bridge + saved12 month hashes + successful runtime parity gates + independently reviewed raw120+16 originals; no independent saved all-value month comparison is claimed.'],
 'generated_full2022_coldstart_funding_ownership_terminal60_passed':['Author41 initial_source_funding_is_fresh_cash_not_ownership, genuine_final_endpoint_and_no_2023_cube and exact unchanged terminal rule; actual funding first5 +6ms unowned, exact terminal clock metadata and genuine endpoint checks.'],
 'generated_old_private_GO_hash_only_portability_passed':['New independent DATA_FREE_FLAGS_REVIEW test_all_legacy_private_GO_reads_denied_current_metadata_still_validates: broad GO-body read denial with positivecontrol, exact metadata/source authority/code identity validation, hash-metadata-only AST contract. No legacy private GO body is needed or opened.']}
assert set(flag_evidence)==set(e.REVIEW_FLAGS)
evidence_paths=[PREP/'PREPARATION.json',PREP/'RECORDING_ONLY_METADATA_RECEIPT.json',HAND/'ROOT_SOURCE_STAGE_GO_APPROVED_attempt001.json',HAND/'OBSERVED_SOURCE_ONLY_GUARD_RECEIPT_attempt001.json',HAND/'source_stage_guard.py',EXEC/'DELIVERABLE_PINS.json',EXEC/'GENERATED_TESTS.log',EXEC/'IMPLEMENTATION_RECEIPT.json',PRI/'INDEPENDENT_REVIEW_RECEIPT.json',ROOT/'full2022_restored_source_independent_review_20261015/REVIEW_RECEIPT.json']
evidence_paths += [PREP/name for name in p['artifacts']]
supplement=ROOT/'traditional_D_full2022_supplementary_pure_tests_20261015'
for name,digest in {'test_pure_reporting_portability.py':'c628bf8d950843aaf6628c956185dca3d309b46bd373ee2c24b56b2d19b35554','PURE_TEST_RECEIPT.json':'47e8d6ea6fc857861bcdd46b27d7434d87b8e890d3bbd2f2b706a497b64a9c9a','PURE_TESTS.log':'471f5da2a5cbcdf5622c956365ed961cf65ea312b620e16e29ebafecc05c8314'}.items():
 assert pin(supplement/name)['SHA256']==digest
 evidence_paths.append(supplement/name)
evidence_paths += [path for path in HERE.iterdir() if path.is_file() and path.name not in ('INDEPENDENT_REVIEW_RECEIPT.json','PUBLIC_SAFE_EXACT_EVIDENCE_ALLOWLIST.json','WIRE_VALIDATION.json') and path.suffix in ('.json','.py','.log','.md')]
evidence={str(path.relative_to(ROOT)):pin(path) for path in evidence_paths}
review=dict(schema=e.REVIEW_SCHEMA,status='PASS_SOURCE_ONLY_AND_GENERATED_NO_HISTORICAL_GO',**e._authorization_common(raw,p),**dict.fromkeys(e.REVIEW_FLAGS,True),
 actual_2022_accounts_constructed=0,actual_2022_financial_runs=0,historical_market_minutes_advanced=0,publication_actions=0,locked_source_reads=0,
 reviewer_role='INDEPENDENT_POST_SOURCE_STAGE_SAVED_OUTPUT_AND_GENERATED_EVIDENCE_REVIEW',finished_UTC=datetime.now(timezone.utc).isoformat(),
 source_stage_observed_guard=pin(HAND/'OBSERVED_SOURCE_ONLY_GUARD_RECEIPT_attempt001.json'),source_stage_recording_callbacks=pin(PREP/'RECORDING_ONLY_METADATA_RECEIPT.json'),source_stage_external_GO=pin(HAND/'ROOT_SOURCE_STAGE_GO_APPROVED_attempt001.json'),
 source_stage_observed_forbidden_calls_all_zero=True,recording_scopes_created=9,recording_scopes_revoked=9,actual_source_application_scopes_created_by_original_stage=2,
 independent_saved_source_checks=993,independent_new_data_free_tests=2,inherited_author_generated_tests=41,inherited_prior_independent_generated_static_tests=32,
 actual2022_equivalence_scope=dict(exact_saved_decision_bits_all365=True,exact_saved_covariance_bits_all365=True,exact_saved_nine_target_paths_all365=True,exact_target_proofs_all365=True,all277_source_byte_pins_rehashed=True,all64_code_pins_checked=True,all6_source_artifact_pins_checked=True,all27_actual_latest_genuine_raw_anchor_prices_and_original_clocks_checked=True,all8_first_per_asset_genuine_recovery_rows_checked=True,all5_genuine_native_endpoints_checked=True,direct_July_funding_genuine_anchor_comparisons=372,full_original_raw_source_QA_reused=True,independent_all_value_normalized_month_byte_comparison=False,normalized_monthly_containers_persisted=False,full_source_projector_reexecuted=False),
 native_transport_proof_scope=pin(HERE/'NATIVE_TRANSPORT_PROOF_SCOPE.json'),review_flag_evidence=flag_evidence,evidence=evidence,synthetic_checkpoint_evidence=synthetic_pins,
 limitations=[
  'Twelve normalized native monthly containers existed only in source-stage memory. The prepared cell bindings save exact compressed-month hashes/sizes and quality hash. This review did not independently reread every normalized monthly value or rerun the full actual projector. Native transport evidence is the exact reviewed deterministic bridge, saved hashes, successful author native/daily and genuine-anchor bit parity gates, all277 raw-source pins, independently reviewed original120+16 raw QA and generated parser/month contract proofs.',
  'Raw source remains5255973/5256000 original asset-family minutes. The exact27 July MARK absences remain UNKNOWN_OR_DERIVED with source ages1–7 minutes and original genuine anchor clocks. No genuine/source-arrival claim is created by the causal carry.',
  'The five older July daily zero-add confirmation bodies were not freshly rehashed or parsed by the prior raw review; their saved metadata lineage remains inherited. The16 genuine positive repairs/23040 added minutes are separately independently substantiated.',
  'Actual historical publication, arrival and replay installation are UNKNOWN_NOT_CERTIFIED. Offline completion and replay-installation clocks do not certify venue availability or execution.',
  'Raw funding5550 events, including SOL1170 and others1095, preserve unconfirmed raw rate units/intervals. First5 Jan1+6ms lack prior2022 source and are not owned. Source coverage never establishes actual position ownership or a financial charge.',
  'Actual27 FUNDING/NATIVE_IMMEDIATE_RISK/GUARD50_MONITOR/PAID_EXECUTION/TERMINAL/POSITION_INTERVALS effects remain PENDING_ACTUAL_SAVED_EVIDENCE. This review makes no zero-impact, liquidation/no-liquidation or last-two-past-price future-bound claim.',
  'Synthetic two-worker runtime observations do not certify full-year resource fit, host CPU quota or successful actual annual completion. No actual historical financial case was launched.',
  'All inputs are seen DEVELOPMENT data. No holdout, other year,2025 execution, alpha/performance selection, riskmatched excess, annual wallet compounding or publication authority is granted.'
 ],
 decision_boundary='This exact preparation-bound review may support the parent’s next source/financial-preparation gate decision. It does not authorize historical scopes, accounts, provider iteration, processes, canonical financial claims or any financial GO. A separate exact new externally pinned root financial GO and the unchanged admission/resource checks remain mandatory.',
 historical_execution_authorized=False,account_construction_authorized=False,provider_iteration_authorized=False,financial_process_launch_authorized=False,canonical_financial_claims_authorized=False,valid_financial_GO_written=False,actual_annual_resource_fit_certified=False,
 reviewer_new_activity=dict(actual_daily_target_paths_recomputed=9,actual_saved_source_ZIPs_independently_parsed=9,actual_full_source_projector_calls=0,actual_normalized_month_recreations=0,actual_source_scopes=0,actual_accounts_constructed=0,actual_accounts_advanced=0,historical_scopes_created=0,provider_iterations=0,financial_runs=0,financial_case_process_launches=0,canonical_financial_claims=0,financial_GO_writes=0,new_network_requests=0,publication_actions=0),CPU_affinity=[6])
save('INDEPENDENT_REVIEW_RECEIPT.json',review)
receipt_path=HERE/'INDEPENDENT_REVIEW_RECEIPT.json';review_raw=receipt_path.read_bytes();expected=sha(review_raw)
# Exact wire-schema validation is metadata-only. This in-memory object is not a GO.
assert e._validate_independent_review(raw,p,review_raw,expected,e._canonical(dict(independent_review_SHA256=expected)))==review
save('WIRE_VALIDATION.json',dict(schema='INDEPENDENT_REVIEW_PURE_WIRE_VALIDATION_V1',status='PASS_EXACT_PREPARATION_BOUND_18_FLAG_REVIEW_SCHEMA',review=pin(receipt_path),pure_validation_function='full_entry._validate_independent_review',no_root_financial_GO_constructed_or_written=True,historical_scopes_created=0,actual_accounts_constructed=0))
allow_paths=list({path.resolve():path for path in evidence_paths+[receipt_path,HERE/'WIRE_VALIDATION.json']}.values())
save('PUBLIC_SAFE_EXACT_EVIDENCE_ALLOWLIST.json',dict(schema='EXACT_SOURCE_ONLY_REVIEW_EVIDENCE_ALLOWLIST_V1',scope='Prepared full2022 source/target/quality and generated proof; not financial authority',files=[pin(path) for path in sorted(allow_paths)]))
print(json.dumps(dict(status=review['status'],receipt=pin(receipt_path),wire=pin(HERE/'WIRE_VALIDATION.json'),allowlist=pin(HERE/'PUBLIC_SAFE_EXACT_EVIDENCE_ALLOWLIST.json'),no_financial_GO=True)))
