"""Independent fake saved-minute and legacy-GO-denial checks; no financial object."""
import os
for _k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','POLARS_MAX_THREADS','VECLIB_MAXIMUM_THREADS'):os.environ[_k]='1'
os.sched_setaffinity(0,{6})
import ast,builtins,hashlib,json,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import numpy as np
ROOT=Path(__file__).resolve().parents[1];HERE=Path(__file__).resolve().parent;EXEC=ROOT/'traditional_D_full2022_20261015_v2'
for _p in (EXEC,ROOT/'traditional_three_tier_freeze_20261015'):sys.path.insert(0,str(_p))
import full_entry as entry
import run_full as runner
import full_d as integration
import annual_reporting
sys.path.insert(0,str(ROOT/'traditional_D_full2022_source_stage_handoff_20261015'))
from source_stage_guard import SourceOnlyGuard

def sha(b):return hashlib.sha256(b).hexdigest()
def pin(p):
 b=Path(p).read_bytes();return dict(SHA256=sha(b),bytes=len(b))
def read(p):return json.loads(Path(p).read_bytes())
def function_AST(path,name):return ast.dump(next(n for n in ast.parse(Path(path).read_bytes()).body if isinstance(n,ast.FunctionDef) and n.name==name))

class DataFreeFlags(unittest.TestCase):
 def test_fake_saved_minute_exposure_forecast_overshoot_and_roundtrip(self):
  self.assertEqual(function_AST(EXEC/'run_full.py','held_risk_report'),function_AST(ROOT/'traditional_D_full2022_20261015/run_full.py','held_risk_report'))
  self.assertEqual(pin(ROOT/'traditional_three_tier_freeze_20261015/annual_reporting.py')['SHA256'],'3ffee703c1fabd4e18d9673220a850fff5e5663aed697e2dead7627017ff8636')
  self.assertEqual(runner.held_risk_report.__globals__['__name__'],'run_full')
  start=978307200000000;minute=60000000
  weights=np.array([[.6,0,0,0,0],[0,.1,0,0,0],[.1,-.2,0,0,0],[0,0,0,0,0],[-.8,0,0,0,0],[.01,.01,.01,.01,.01]],dtype=np.float64)
  columns=['close_us','nav','free_cash','isolated_balance','gross_weight']+[s+'_signed_weight' for s in integration.S]
  values=np.column_stack([start+np.arange(1,7)*minute,np.full(6,10000.),[10000.,9500.,900.,1000.,9000.,10000.],[0.,500.,9100.,9000.,1000.,0.],np.abs(weights).sum(axis=1),weights])
  decisions=np.array([start],dtype=np.int64);covariance=np.array([np.eye(5)*.25]);targets=np.full((1,5),.03)
  receipts=[dict(allowed=False,reason='FAKE_CAPITAL_CASH_ONLY',fraction='0',evaluations=[dict(allowed=False,reason='FAKE_GROSS_ONLY')])]
  # This guard dynamically denies all account/provider/process/network/claim/GO actions.
  with SourceOnlyGuard() as guard:
   report=runner.held_risk_report(values,columns,decisions,covariance,targets,'MID',receipts)
   forecast=np.sqrt((weights*weights).sum(axis=1)*.25)
   self.assertEqual(report['observation_count'],6)
   self.assertEqual(report['forecast_volatility_breach_minutes'],int(np.sum(forecast-.1>1e-10)))
   self.assertEqual(report['forecast_volatility_breach_minutes'],3)
   self.assertEqual(report['forecast_annual_volatility_max'],float(forecast.max()))
   self.assertEqual(report['forecast_annual_volatility_mean'],float(forecast.mean()))
   self.assertEqual(report['forecast_volatility_breach_max_absolute'],float(np.maximum(0,forecast-.1).max()))
   self.assertEqual(report['actual_net_signed_weight_min'],float(weights.sum(axis=1).min()))
   self.assertEqual(report['actual_net_signed_weight_max'],float(weights.sum(axis=1).max()))
   self.assertEqual(report['actual_net_signed_weight_mean'],float(weights.sum(axis=1).mean()))
   self.assertEqual(report['actual_absolute_weight_max_by_symbol'],dict(zip(integration.S,np.abs(weights).max(axis=0).tolist())))
   self.assertEqual(report['actual_signed_weight_min_by_symbol'],dict(zip(integration.S,weights.min(axis=0).tolist())))
   self.assertEqual(report['actual_signed_weight_max_by_symbol'],dict(zip(integration.S,weights.max(axis=0).tolist())))
   self.assertEqual(report['minutes_observed_free_cash_below1000'],1)
   self.assertEqual(report['minutes_observed_margin_above8500'],2)
   self.assertTrue(report['nominal_tier_equality_is_not_exact_realized_risk_matching'])
   self.assertEqual(report['riskmatched_excess_method'],'NOT_PREREGISTERED_NOT_CLAIMED')
   self.assertEqual(report['exact_capital_binding_count'],'NOT_IDENTIFIABLE_FROM_FROZEN_COMPACT_RECEIPTS')
   self.assertFalse(report['native_exchange_execution_certified']);self.assertFalse(report['funding_publication_certified'])
   with tempfile.TemporaryDirectory(prefix='obvious_fake_saved_report_',dir=HERE) as temp:
    folder=Path(temp);(folder/'2001').mkdir()
    np.savez_compressed(folder/'MINUTE.npz',values=values,columns=np.array(columns))
    np.savez_compressed(folder/'2001/TARGETS.npz',decision_us=decisions,annual_covariance=covariance,FAKE_REPORT_MID=targets)
    raw=runner.body(dict(generated_only=True,artifacts={'2001/TARGETS.npz':pin(folder/'2001/TARGETS.npz')}))
    (folder/'PREPARATION.json').write_bytes(raw);(folder/'GUARD_RECEIPTS.json').write_bytes(runner.body(receipts));(folder/'ACTUAL_HELD_RISK_REPORT.json').write_bytes(runner.body(report))
    result=dict(summary={k:float(values[-1,columns.index(v)]) for k,v in [('NAV','nav'),('free_cash','free_cash'),('isolated_balance','isolated_balance'),('gross_weight','gross_weight')]})
    saved=runner.validate_saved_risk_report(folder,preparation_directory=folder,preparation_raw=raw,cell=dict(year=2001,calendar=[start,start+6*minute],config='FAKE_REPORT_MID',tier='MID'),receipt=dict(completed_minutes=6,account_stop_us=None),result=result)
    self.assertEqual(saved,report)
    damaged=dict(report,forecast_volatility_breach_minutes=0);(folder/'ACTUAL_HELD_RISK_REPORT.json').write_bytes(runner.body(damaged))
    with self.assertRaisesRegex(ValueError,'EXACT_ACTUAL_HELD_RISK_REPORT_RECOMPUTATION_REQUIRED'):
     runner.validate_saved_risk_report(folder,preparation_directory=folder,preparation_raw=raw,cell=dict(year=2001,calendar=[start,start+6*minute],config='FAKE_REPORT_MID',tier='MID'),receipt=dict(completed_minutes=6,account_stop_us=None),result=result)
   guard.checkpoint('AFTER_FAKE_SAVED_REPORT_ONLY')
  self.assertTrue(all(v==0 for v in guard.attempts.values()))
  self.assertEqual(guard.allowed,dict(source_application_scopes=0,recording_metadata_scopes=0))
  REPORTS['fake_risk_report']=dict(generated_only=True,fake_calendar_year=2001,observation_count=6,forecast_breach_minutes=report['forecast_volatility_breach_minutes'],saved_roundtrip_exact=True,deliberate_saved_zero_overshoot_corruption_rejected=True,guard=guard.receipt('PASS_NO_FINANCIAL_OBJECT_OR_PROCESS'))

 def test_all_legacy_private_GO_reads_denied_current_metadata_still_validates(self):
  prep_path=ROOT/'traditional_D_full2022_20261015_v2_source_preparation_attempt001/PREPARATION.json'
  prep_raw=prep_path.read_bytes();prep=json.loads(prep_raw)
  source_go_raw=(ROOT/'traditional_D_full2022_source_stage_handoff_20261015/ROOT_SOURCE_STAGE_GO_APPROVED_attempt001.json').read_bytes()
  denied=[];original_open=builtins.open;path_open=Path.open
  def denied_path(path):
   if not isinstance(path,(str,bytes,os.PathLike)):return False
   name=Path(os.fsdecode(path)).name.upper()
   return name.endswith('.JSON') and ('ROOT_GO' in name or 'ADMISSION_GO' in name or 'FINANCIAL_GO' in name or name=='GO.JSON')
  def guarded_open(path,*args,**kwargs):
   if denied_path(path):denied.append(str(path));raise PermissionError('TEST_DENIED_ALL_PRIVATE_GO_BODIES')
   return original_open(path,*args,**kwargs)
  def guarded_path_open(path,*args,**kwargs):
   if denied_path(path):denied.append(str(path));raise PermissionError('TEST_DENIED_ALL_PRIVATE_GO_BODIES')
   return path_open(path,*args,**kwargs)
  with patch.object(builtins,'open',guarded_open),patch.object(Path,'open',guarded_path_open):
   # Positive control proves Path.read_bytes cannot silently bypass this guard.
   with self.assertRaisesRegex(PermissionError,'TEST_DENIED_ALL_PRIVATE_GO_BODIES'):
    (ROOT/'OBVIOUS_FAKE_PRIVATE_LEGACY/ROOT_GO_APPROVED.json').read_bytes()
   self.assertEqual(len(denied),1)
   self.assertEqual(entry.validate_preparation_metadata(prep_raw),prep)
   self.assertEqual(entry.code_identity(),prep['code_identity'])
   self.assertEqual(entry.s.require_source_stage_authority(source_go_raw,sha(source_go_raw)),json.loads(source_go_raw))
   common=entry._authorization_common(prep_raw,prep)
   self.assertFalse(common['preserved_old_root_GO_is_new_authority']);self.assertFalse(common['old_private_GO_bodies_required'])
   self.assertEqual(common['preserved_evidence_pins'],entry.preserved_evidence_identity())
   self.assertEqual(len(denied),1)
  text=(EXEC/'full_entry.py').read_text();tree=ast.parse(text)
  fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='preserved_evidence_identity')
  self.assertEqual(ast.dump(fn.body[0].value),ast.dump(ast.parse('dict(OLD_EVIDENCE_HASHES)',mode='eval').body))
  self.assertEqual(entry.OLD_EVIDENCE_HASHES,{})
  REPORTS['private_GO_portability']=dict(all_private_GO_body_reads_denied=True,denial_positive_control_count=1,unexpected_private_GO_read_attempts=0,current_source_metadata_authority_validated_from_existing_external_bytes=True,current_preparation_metadata_validates=True,current64_code_files_validate=True,legacy_evidence_contract='HASH_METADATA_ONLY_NEVER_AUTHORITY_OR_PRIVATE_BODY_DEPENDENCY',actual_projector_calls=0,historical_scopes_created=0)

REPORTS={}
if __name__=='__main__':
 result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(DataFreeFlags))
 if result.wasSuccessful():
  out=dict(schema='INDEPENDENT_DATA_FREE_FULL2022_MISSING_FLAGS_REVIEW_V1',status='PASS_TWO_DATA_FREE_FLAGS_NO_ACCOUNT_PROVIDER_OR_PROJECTOR',tests_run=result.testsRun,reports=REPORTS,review_script=pin(__file__),execution_code_identity_SHA256=entry._json_sha(entry.code_identity()),actual_2022_accounts_constructed=0,actual_2022_financial_runs=0,historical_market_minutes_advanced=0,provider_iterations=0,actual_source_projector_calls=0,subprocess_launches=0,financial_GO_written=0,CPU_affinity=sorted(os.sched_getaffinity(0)))
  with (HERE/'DATA_FREE_FLAGS_REVIEW.json').open('x') as f:json.dump(out,f,indent=2,sort_keys=True);f.write('\n')
 raise SystemExit(not result.wasSuccessful())
