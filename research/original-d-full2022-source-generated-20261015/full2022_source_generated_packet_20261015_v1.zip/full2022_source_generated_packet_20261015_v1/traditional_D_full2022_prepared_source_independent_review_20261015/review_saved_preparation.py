"""Read-only saved full2022 source-stage review; never calls a projector/provider/account."""
import os
for _k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','POLARS_MAX_THREADS','VECLIB_MAXIMUM_THREADS'):
    os.environ[_k]='1'
os.sched_setaffinity(0,{6})
import ast,csv,hashlib,io,json,resource,sys,time,zipfile
from collections import Counter
from datetime import datetime,timezone
from pathlib import Path
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
HERE=Path(__file__).resolve().parent
PREP=ROOT/'traditional_D_full2022_20261015_v2_source_preparation_attempt001'
EXEC=ROOT/'traditional_D_full2022_20261015_v2'
HAND=ROOT/'traditional_D_full2022_source_stage_handoff_20261015'
RAW=ROOT/'full2022_unaffected_source_restore_20261015'
PRI=ROOT/'traditional_D_full2022_independent_review_20261015'
FROZEN=ROOT/'traditional_three_tier_freeze_20261015'
for _p in (EXEC,FROZEN):sys.path.insert(0,str(_p))
import full_entry as e
import frozen_grid as g

def sha(b):return hashlib.sha256(b).hexdigest()
def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def jsha(v):return sha(canon(v))
def pin(p):
    p=Path(p);assert p.is_file() and not p.is_symlink(),p
    b=p.read_bytes();return dict(SHA256=sha(b),bytes=len(b))
def read(p):return json.loads(Path(p).read_bytes())
def save(name,v):
    with (HERE/name).open('x') as f:json.dump(v,f,indent=2,sort_keys=True,allow_nan=False);f.write('\n')
def check(label,ok=True):
    assert ok,label
    CHECKS.append(label)
def zip_rows(rec):
    """Separate simple CSV reader for selected July anchors and December endpoints."""
    with zipfile.ZipFile(ROOT/rec['source_path']) as z:
        check('selected original exact single CSV member '+rec['CSV_member'],z.namelist()==[rec['CSV_member']])
        raw=z.read(rec['CSV_member'])
    check('selected original decompressed CSV identity '+rec['CSV_member'],sha(raw)==rec['CSV_SHA256'])
    rows={}
    for row in csv.reader(io.StringIO(raw.decode('utf-8-sig'))):
        if not row[0].isdigit():continue
        at=int(row[0])*1000
        assert len(row)==12 and at not in rows
        assert int(row[6])*1000+1000==at+e.s.MINUTE
        rows[at]=row
    return rows

CHECKS=[]
began=time.monotonic()
preparation_raw=(PREP/'PREPARATION.json').read_bytes();p=read(PREP/'PREPARATION.json')
go_raw=(HAND/'ROOT_SOURCE_STAGE_GO_APPROVED_attempt001.json').read_bytes();go=json.loads(go_raw)
check('exact external source GO SHA',sha(go_raw)=='8408bd74dca44784add9d71ac0458e026fcecf93a59866cdf78d0eaea5d17522')
check('exact preparation source GO binding',p['source_stage_GO_SHA256']==sha(go_raw))
check('pure preparation wire validator',e.validate_preparation_metadata(preparation_raw)==p)
check('exact current v2 code identity',p['code_identity']==e.code_identity())
check('exact reviewed v2 code identity SHA',jsha(p['code_identity'])=='fbe6fb7dd93733931ee58c3fc3ed3061c2c754e18cb72065722901d54a7bfd9d')
check('exact v2 deliverable manifest',pin(EXEC/'DELIVERABLE_PINS.json')['SHA256']=='abb7d3cc390b9fe4fda01bc24f066fe04a4fd6c38f6c5b57dcf808f5f6af6a9c')
for name,v in read(EXEC/'DELIVERABLE_PINS.json').items():check('v2 pinned file '+name,pin(EXEC/name)==v)
for name,v in p['artifacts'].items():check('saved source-stage artifact '+name,pin(PREP/name)==v)
check('saved source GO byte identity',(PREP/'2022/SOURCE_PREP_GO.json').read_bytes()==go_raw)
check('no prep historical/account/provider/process/claims/financial GO activity',all(p[k]==0 for k in ('accounts_created','accounts_advanced','financial_runs','provider_iterations','historical_scopes_created','process_launches','canonical_claims_created','real_GO_written','publication_actions')))
check('all financial/source-only permissions false',all(go[k] is False for k in ('historical_execution_authorized','account_construction_authorized','provider_iteration_authorized','process_launch_authorized','canonical_claims_authorized')))
check('source-only positive scopes bounded',go['target_generation_authorized'] is True and go['actual_overlay_application_authorized'] is True)

guard_path=HAND/'OBSERVED_SOURCE_ONLY_GUARD_RECEIPT_attempt001.json';guard=read(guard_path)
check('observed source guard PASS',guard['status']=='PASS_OBSERVED_ZERO_FORBIDDEN_CALLS' and guard['error'] is None)
check('observed all nine forbidden categories zero',len(guard['forbidden_attempts'])==9 and all(v==0 for v in guard['forbidden_attempts'].values()) and guard['attempted_forbidden_targets']==[])
check('observed exact source2 recording9 scope counts',guard['allowed_scope_constructions']==dict(source_application_scopes=2,recording_metadata_scopes=9))
check('observed all recording scopes revoked',guard['all_recording_scopes_revoked'] is True)
check('guard exact reviewed invocation code identity',guard['source_only_guard_code_identity']==go['source_guard_code_identity']=={str((HAND/'source_stage_guard.py').relative_to(ROOT)):'868c1094cc48c45e45875d52c6e7fe7a56727c0b35971ec5ad86930b4bf91bb8'})
check('guard source code matches preparation',guard['execution_code_identity']==p['code_identity'])
check('guard checkpoints zero forbidden and no active scopes',len(guard['checkpoints'])==2 and all(c['active_recording_scopes']==0 and all(v==0 for v in c['forbidden_attempts'].values()) for c in guard['checkpoints']))

recording_path=PREP/'RECORDING_ONLY_METADATA_RECEIPT.json';recording=read(recording_path)
check('nine actual recording metadata callbacks exact frozen order',[r['cell_id'] for r in recording['records']]==p['ordered_cells'])
check('nine created and revoked metadata scopes',recording['recording_scopes_created']==recording['recording_scopes_revoked']==9)
check('recording zero financial/provider/process/history/claim activity',all(recording[k]==0 for k in ('historical_scopes_created','accounts_constructed','accounts_advanced','provider_iterations','process_launches','canonical_financial_claims','financial_GO_written')))
for row in recording['records']:
    check('recording exact preparation/input binding '+row['cell_id'],row['preparation_SHA256']==sha(preparation_raw) and row['input_binding_SHA256']==p['cells'][row['cell_id']]['input_binding_SHA256'])
    check('recording metadata-only flags '+row['cell_id'],row['domain']=='ACTUAL_PREPARED_SOURCE_METADATA' and row['recording_only'] is True and all(row[k] is False for k in ('historical_execution_authorized','financial_constructor_authorized','provider_iteration_authorized','process_launch_authorized','claims_authorized')))

check('inherited generated review exact SHA',pin(PRI/'INDEPENDENT_REVIEW_RECEIPT.json')['SHA256']=='1d8d94eb352891ad9154412f48291dd734fc996289ed13e37f629c7115c0e09e')
prior=read(PRI/'INDEPENDENT_REVIEW_RECEIPT.json')
for name,v in prior['evidence'].items():check('inherited independently reviewed evidence pin '+name,pin(PRI/name)==v)
raw_review_path=ROOT/'full2022_restored_source_independent_review_20261015/REVIEW_RECEIPT.json'
check('inherited original raw-source QA exact SHA',pin(raw_review_path)['SHA256']=='5a934063b763bd54f986a8ad8e8bb3222c737180ca03f5cafbccd4b51b521429')
raw_review=read(raw_review_path)
check('inherited raw original complete source and exact27 findings',raw_review['monthly_originals_rechecked']==120 and raw_review['genuine_daily_originals_rechecked']==16 and raw_review['genuine_daily_added_asset_minutes']==23040 and raw_review['genuine_source_union_asset_minutes']==5255973 and raw_review['genuine_unknown_MARK_asset_minutes']==27 and raw_review['missing_TRADE_source_union_minutes']==0)
index=read(RAW/'FINAL_RAW_SOURCE_INDEX.json');qa=read(RAW/'FINAL_SOURCE_QUALIFICATION_RECEIPT.json')
check('exact raw source index identity',pin(RAW/'FINAL_RAW_SOURCE_INDEX.json')['SHA256']=='ab57ebc72f05ac0e59df232b477de27f8674b34aca0667168b4c69c40ab065ab')
check('exact qualifier identity',pin(RAW/'FINAL_SOURCE_QUALIFICATION_RECEIPT.json')['SHA256']=='36310f40bddad0c6de5482085ba8fc0c81571060f7dda5da6deb62125fa1c5ec')
check('exact final raw source manifest identity',pin(RAW/'FINAL_DELIVERABLE_PINS.json')['SHA256']=='b10686c8f84d3aa111d48763612b0433c2469ca605e15f4910b80a39cee6d9d5')
info=p['years']['2022']
for name,v in info['source_files'].items():check('prepared original source file pin '+name,pin(ROOT/name)==v)
check('source original pin count277',len(info['source_files'])==277)
expected_files={}
for rec in index['monthly']+index['daily']:
    expected_files[rec['source_path']]=dict(SHA256=rec['ZIP_SHA256'],bytes=rec['ZIP_bytes'])
    if rec.get('CHECKSUM_path'):expected_files[rec['CHECKSUM_path']]=dict(SHA256=rec['CHECKSUM_SHA256'],bytes=rec['CHECKSUM_bytes'])
for name in ('FINAL_RAW_SOURCE_INDEX.json','FINAL_SOURCE_QUALIFICATION_RECEIPT.json','FINAL_DELIVERABLE_PINS.json'):
    expected_files[str((RAW/name).relative_to(ROOT))]=pin(RAW/name)
for key in ('daily_close','raw_rate_interval_events'):
    row=index['projections'][key];expected_files[row['path']]=dict(SHA256=row['SHA256'],bytes=row['bytes'])
check('prepared277 source pins exactly raw120plus16 + metadata + daily/funding projections',expected_files==info['source_files'])
derivation=read(HAND/'SOURCE_BINDING_DERIVATION.json')
check('source identity independently recomputed from exact five metadata bindings',jsha(derivation['source_identity_inputs'])==info['source_identity']==derivation['source_identity'])
check('qualified endpoint source metadata digest',jsha(derivation['endpoint_source_binding'])==info['source_qualification']['endpoint_source_SHA256'])

side=read(PREP/'2022/MINUTE_MARK_PROVENANCE.json');cells=side['cells'];missing={(c['symbol'],c['minute_open_us']) for c in cells}
check('actual exact27 original source missing set',missing==set(e.s.ACTUAL27_OPEN_POINTS_US) and len(cells)==27)
check('actual 11 missing open clocks',len({at for _,at in missing})==11)
check('sidecar exact source identity and completion pin',side['source_identity']==info['source_identity'] and side['source_completion_SHA256']==e.s.FINAL_PINS)
check('quality sidecar bound everywhere',all(c['quality_sidecar_sha256']==pin(PREP/'2022/MINUTE_MARK_PROVENANCE.json')['SHA256'] for c in p['cells'].values()))
check('sidecar UNKNOWN/offline/no certification',side['quality']=='UNKNOWN_OR_DERIVED' and side['arrival_status']==side['actual_publication_arrival_installation']=='UNKNOWN_NOT_CERTIFIED' and side['certifies_liquidation'] is False and side['certifies_no_liquidation'] is False and side['past2_envelope_is_future_bound'] is False)
check('saved event and position impacts still explicitly pending',side['actual_event_impacts']=='PENDING_ACTUAL_SAVED_EVIDENCE' and side['affected_event_and_position_interval_flags']=='PENDING_ACTUAL_SAVED_EVIDENCE_NOT_ZERO_IMPACT')
july={};july_records={}
for symbol in sorted({s for s,_ in missing}):
    rec=next(r for r in index['monthly'] if r['symbol']==symbol and r['period']=='2022-07' and r['family']=='markPriceKlines')
    july[symbol]=zip_rows(rec);july_records[symbol]=rec
    lo=int(datetime(2022,7,1,tzinfo=timezone.utc).timestamp()*1e6);hi=int(datetime(2022,8,1,tzinfo=timezone.utc).timestamp()*1e6)
    check('independent July original absence set '+symbol,{(symbol,at) for at in range(lo,hi,e.s.MINUTE) if at not in july[symbol]}=={k for k in missing if k[0]==symbol})
run_map={};cell_rows=[]
for c in cells:
    symbol,at=c['symbol'],c['minute_open_us'];rows=july[symbol];rec=july_records[symbol]
    prior=max(k for k in rows if k<at);anchor=rows[prior]
    check('actual latest genuine anchor row and exact original decimal price '+symbol+':'+str(at),prior==c['anchor_open_us'] and anchor[4]==c['price_text'] and c['anchor_source_SHA256']==rec['ZIP_SHA256'] and c['anchor_record_id']==rec['CSV_member']+':OPEN_MS:'+str(prior//1000))
    check('actual original source clocks never stamped with missing completion '+symbol+':'+str(at),c['anchor_completed_us']==c['anchor_available_us']==c['anchor_installed_us']==c['source_freshness_clock_us']==prior+e.s.MINUTE and c['completed_us']==c['evaluation_us']==at+e.s.MINUTE)
    check('actual carry is marked derived and never genuine/new-risk/certification '+symbol+':'+str(at),c['quality']=='UNKNOWN_OR_DERIVED' and c['arrival_status']=='UNKNOWN_NOT_CERTIFIED' and all(c[k] is False for k in ('is_genuine','permits_new_increase','permits_topup','certifies_liquidation','certifies_no_liquidation')))
    recovery=at+e.s.MINUTE
    while (symbol,recovery) in missing:recovery+=e.s.MINUTE
    check('actual first per-asset recovery row exists and preserves raw completion '+symbol+':'+str(at),recovery in rows and all((symbol,k) in missing for k in range(at,recovery,e.s.MINUTE)))
    row=dict(symbol=symbol,missing_open_us=at,missing_completed_us=at+e.s.MINUTE,anchor_open_us=prior,anchor_completed_us=prior+e.s.MINUTE,anchor_available_us=c['anchor_available_us'],anchor_installed_us=c['anchor_installed_us'],anchor_age_at_missing_completion_us=at-prior,anchor_source_SHA256=rec['ZIP_SHA256'],anchor_record_id=c['anchor_record_id'],anchor_price_text=anchor[4],genuine_recovery_open_us=recovery,genuine_recovery_completed_us=recovery+e.s.MINUTE,genuine_recovery_price_text=rows[recovery][4],actual_recovery_installation_verified=False)
    cell_rows.append(row);run_map[(symbol,prior)]=dict(symbol=symbol,anchor_open_us=prior,recovery_open_us=recovery,missing_minutes=(recovery-prior)//e.s.MINUTE-1)
check('actual27 eight asset runs max7 four singletons',len(run_map)==8 and max(r['missing_minutes'] for r in run_map.values())==7 and sum(r['missing_minutes']==1 for r in run_map.values())==4)
check('source ages one through seven minutes',min(r['anchor_age_at_missing_completion_us'] for r in cell_rows)==e.s.MINUTE and max(r['anchor_age_at_missing_completion_us'] for r in cell_rows)==7*e.s.MINUTE)
by_clock={}
for c in cells:by_clock.setdefault(c['completed_us'],set()).add(c['symbol'])
intervals=[]
for at,symbols in sorted(by_clock.items()):
    syms=sorted(symbols)
    if intervals and intervals[-1][1]==at and intervals[-1][2]==syms:intervals[-1][1]=at+e.s.MINUTE
    else:intervals.append([at,at+e.s.MINUTE,syms])
check('quality interval clock partitions exact27 asset-minutes',intervals==side['quality_intervals']==info['quality_intervals'] and sum((b-a)//e.s.MINUTE*len(ss) for a,b,ss in intervals)==27)
save('ACTUAL27_ANCHOR_RECOVERY_REVIEW.json',dict(schema='INDEPENDENT_ACTUAL27_RAW_ANCHOR_RECOVERY_SOURCE_ONLY_V1',cells=cell_rows,asset_runs=list(run_map.values()),actual_account_or_installed_recovery_claim=False,publication_arrival_installation='UNKNOWN_NOT_CERTIFIED'))

endpoint={};endpoint_rows=[]
for symbol in e.s.S:
    rec=next(r for r in index['monthly'] if r['symbol']==symbol and r['period']=='2022-12' and r['family']=='klines')
    rows=zip_rows(rec);last=max(rows);row=rows[last]
    check('genuine final December trade native endpoint '+symbol,last==e.s.END-e.s.MINUTE and int(row[6])*1000+1000==e.s.END)
    endpoint[symbol]=float(row[4]);endpoint_rows.append(dict(symbol=symbol,source_SHA256=rec['ZIP_SHA256'],CSV_member=rec['CSV_member'],open_us=last,completed_us=e.s.END,close_text=row[4]))
check('saved endpoint allfive exact float bits',all(np.float64(endpoint[s]).tobytes()==np.float64(side['final_endpoint_close'][s]).tobytes() for s in e.s.S))
check('genuine endpoint excludes 2023 daily row',side['endpoint_open_us']==e.s.END-e.s.MINUTE and side['endpoint_completed_us']==e.s.END and side['selected_2023_daily_cube_rows']==0)
save('GENUINE_ENDPOINT_REVIEW.json',dict(schema='INDEPENDENT_GENUINE_DEC31_2359_ENDPOINT_REVIEW_V1',sources=endpoint_rows,selected_2023_daily_cube_rows=0))

daily_path=ROOT/index['projections']['daily_close']['path']
with np.load(daily_path,allow_pickle=False) as z:
    check('daily projection exact bounded three field namespace',set(z.files)=={'symbol_order','close_available_us','close'})
    check('daily projection exact CORE5 order',tuple(z['symbol_order'])==e.s.S)
    times=z['close_available_us'].copy();close=z['close'].copy()
check('564 daily past-only finite original closes',times.dtype==np.dtype('int64') and close.dtype==np.dtype('float64') and close.shape==(564,5) and np.array_equal(times,np.arange(e.s.ALLOWED_START,e.s.END,e.s.DAY,dtype=np.int64)) and np.isfinite(close).all() and (close>0).all())
decisions=np.arange(e.s.START,e.s.END,e.s.DAY,dtype=np.int64)
check('all365 original fullfive200 windows ready',all(np.searchsorted(times,at)>=199 and times[np.searchsorted(times,at)]==at for at in decisions))
rebuilt_d,rebuilt_targets,rebuilt_cov,rebuilt_proofs=g.build_target_grid(close,times,times.copy(),decisions)
with np.load(PREP/'2022/TARGETS.npz',allow_pickle=False) as z:
    check('saved nine target array exact namespace',set(z.files)==set(e.s.CONFIGS)|{'decision_us','annual_covariance'})
    check('saved all365 decision bit equality',z['decision_us'].dtype==np.dtype('int64') and z['decision_us'].tobytes()==rebuilt_d.tobytes())
    check('saved all365 covariance bit equality',z['annual_covariance'].dtype==np.dtype('float64') and z['annual_covariance'].shape==(365,5,5) and z['annual_covariance'].tobytes()==rebuilt_cov.tobytes())
    for key in e.s.CONFIGS:check('saved original target bits all365x5 '+key,z[key].dtype==np.dtype('float64') and z[key].shape==(365,5) and z[key].tobytes()==rebuilt_targets[key].tobytes())
check('saved canonical target proof equality all365 decisions',read(PREP/'2022/TARGET_PROOFS.json')==rebuilt_proofs)
for i,at in enumerate(decisions):
    k=np.searchsorted(times,at);past=close[k-30:k+1];returns=np.diff(past,axis=0)/past[:-1]
    check('independent raw daily covariance exact bits '+str(at),np.cov(returns,rowvar=False,ddof=1).__mul__(365).tobytes()==rebuilt_cov[i].tobytes())
equality=read(PREP/'2022/EXACT_EXECUTION_EQUALITY.json')
check('exact nine no aliases or performance selection',equality['unique_execution_jobs']==9 and equality['alias_mapping']=={} and equality['no_apriori_H090_alias'] is True and equality['no_performance_selection'] is True)
target_pins={key:sha(rebuilt_targets[key].tobytes()) for key in e.s.CONFIGS}
check('equality sidecar all target decision covariance pins',equality['selected_target_raw_SHA256']==target_pins and equality['decision_raw_SHA256']==sha(rebuilt_d.tobytes()) and equality['covariance_raw_SHA256']==sha(rebuilt_cov.tobytes()))

fund_path=ROOT/index['projections']['raw_rate_interval_events']['path'];fund=read(fund_path)
check('5550 exact unique chronological funding events',len(fund)==5550 and len({(r['symbol'],r['calc_time_ms']) for r in fund})==5550 and fund==sorted(fund,key=lambda r:(r['calc_time_ms'],e.s.S.index(r['symbol']))))
check('original funding counts SOL1170 other1095',dict(Counter(r['symbol'] for r in fund))=={s:1170 if s=='SOLUSDT' else 1095 for s in e.s.S})
events=[dict(symbol=r['symbol'],event_us=r['calc_time_ms']*1000,raw_rate=r['raw_rate'],reported_interval_hours=r['reported_interval_hours'],raw_rate_unit='UNCONFIRMED') for r in fund]
check('initial five funding Jan1+6ms have no owned source positions',[r['event_us'] for r in events[:5]]==[e.s.START+6000]*5 and [r['symbol'] for r in events[:5]]==list(e.s.S))
fundmap=read(RAW/'FINAL_FUNDING_STRICT_PRIOR_SOURCE_AVAILABILITY.json')
check('exact independently reviewed strict-prior funding metadata pin',pin(RAW/'FINAL_FUNDING_STRICT_PRIOR_SOURCE_AVAILABILITY.json')=={k:qa['funding_strict_prior_source_availability'][k] for k in ('SHA256','bytes')})
check('raw funding metadata map all5550 original values',all(all(m[k]==r[k] for k in ('symbol','calc_time_ms','raw_rate','reported_interval_hours')) for m,r in zip(fundmap['events'],fund)) and len(fundmap['events'])==5550)
check('strict-prior funding map 5545 genuine and5unknown',fundmap['actual_strict_prior_genuine_marks']==5545 and fundmap['unknown_prior_marks']==5 and fundmap['historical_arrival_certified'] is False and fundmap['future_mark_used'] is False)
for m in fundmap['events'][5:]:assert m['nominal_available_ms']<m['calc_time_ms'] and m['nominal_available_ms']==m['mark_open_ms']+60000
july_funding_count=0
for m in fundmap['events']:
    if m['symbol'] in july and m['mark_open_ms'] is not None and m['mark_open_ms']*1000 in july[m['symbol']]:
        raw=july[m['symbol']][m['mark_open_ms']*1000]
        assert np.float64(raw[4]).tobytes()==np.float64(m['mark_close']).tobytes()
        july_funding_count+=1
check('direct July genuine funding anchor parity',july_funding_count>300)
check('funding source presence never ownership and unconfirmed unit policy',side['source_funding_coverage_is_not_ownership'] is True and side['funding_ownership']=='CURRENT_NATIVE_ACTUAL_QUANTITY_ONLY_AFTER_PAID_FILLS' and p['policy']['funding_units']=='RAW_AS_FRACTION_CONDITIONAL_UNCERTIFIED')

source_rows=[dict(symbol=s,close_us=int(at),available_us=int(at),close=float(close[i,j])) for i,at in enumerate(times) for j,s in enumerate(e.s.S)]
daily_rows=[{k:v for k,v in r.items() if k!='available_us'} for r in source_rows if e.s.START<=r['close_us']<e.s.END]
month_id=None
for cell_id,c in p['cells'].items():
    b=c['input_binding'];key=c['config']
    check('cell selected original target raw hash '+cell_id,b['selected_target_raw_SHA256']==target_pins[key]==c['selected_target_raw_SHA256'])
    check('cell decision covariance binding '+cell_id,b['decision_raw_SHA256']==sha(rebuilt_d.tobytes()) and b['covariance_raw_SHA256']==sha(rebuilt_cov.tobytes()))
    check('cell source rows daily rows funding and quality binding '+cell_id,b['source_rows_SHA256']==jsha(source_rows) and b['daily_rows_SHA256']==jsha(daily_rows) and b['funding_events_SHA256']==jsha(events) and b['causal_mark_adapter_SHA256']==jsha(side))
    check('cell exact canonical input binding hash '+cell_id,jsha(b)==c['input_binding_SHA256'])
    check('provider identity bound to exact27 source quality '+cell_id,b['provider_month_identity']['quality_SHA256']==jsha(cells))
    if month_id is None:month_id=b['provider_month_identity']
    check('same native month identity all nine cells '+cell_id,b['provider_month_identity']==month_id)
check('all12 native month identity hashes bounded annual metadata',len(month_id['months'])==12 and sum(m[2] for m in month_id['months'])==525600 and all(m[5]==0 and m[6]==m[2] for m in month_id['months']))
for i,m in enumerate(month_id['months'],1):
    start=int(datetime(2022,i,1,tzinfo=timezone.utc).timestamp()*1e6)
    end=e.s.END if i==12 else int(datetime(2022,i+1,1,tzinfo=timezone.utc).timestamp()*1e6)
    assert m[0]==f'normalized_months/2022-{i:02}.npz' and m[1]==start and m[2]==(end-start)//e.s.MINUTE and len(m[3])==64 and m[4]>0
check('normalized monthly containers are not persisted',not any((PREP/m[0]).exists() or (RAW/m[0]).exists() for m in month_id['months']))
save('NATIVE_TRANSPORT_PROOF_SCOPE.json',dict(schema='INDEPENDENT_NATIVE_TRANSPORT_HASH_AND_CODE_PROOF_SCOPE_V1',normalized_months=month_id['months'],quality_SHA256=month_id['quality_SHA256'],independent_saved_all_month_all_value_comparison=False,normalized_monthly_containers_persisted=False,bridge_code_SHA256=p['code_identity']['traditional_D_full2022_20261015_v2/raw_source_bridge.py'],projector_code_SHA256=p['code_identity']['traditional_D_full2022_20261015_v2/source_projection.py'],inherited_raw_QA=pin(raw_review_path),inherited_generated_bridge_review=pin(PRI/'SOURCE_SEAMS_REVIEW.json'),author_runtime_native_daily_and_anchor_parity_gates_completed=True,proof='The exact reviewed deterministic bridge reconstructs original monthly priority plus 16 genuine daily repairs, preserves genuine Float64 native columns and NaN only at exact27 original MARK absences. Saved preparation commits 12 compressed monthly hashes and binds them into all nine cell inputs. The successful exact guarded invocation includes native-to-daily boundary parity and genuine anchor-price-bit gates. This reviewer rehashed all277 source inputs and independently checked all target/covariance/proof bytes, all27 raw anchors/recoveries and allfive genuine endpoints. The memory-only normalized month values were not independently reread or compared all-value; no full projector rerun was performed.'))

check('no historical execution claims directory created by source stage',not (EXEC/'EXECUTION_CLAIMS').exists())
check('no writable source output altered by reviewer',pin(PREP/'PREPARATION.json')['SHA256']==sha(preparation_raw))
save('SAVED_SOURCE_AUDIT.json',dict(schema='INDEPENDENT_SAVED_SOURCE_ONLY_PREPARATION_AUDIT_V1',status='PASS_SAVED_SOURCE_TARGET_QUALITY_BINDINGS',preparation=pin(PREP/'PREPARATION.json'),source_GO=pin(HAND/'ROOT_SOURCE_STAGE_GO_APPROVED_attempt001.json'),guard_receipt=pin(guard_path),recording_receipt=pin(recording_path),checks=CHECKS,check_count=len(CHECKS),direct_July_funding_genuine_anchor_comparisons=july_funding_count,actual_target_recomputation_only=True,actual_full_projector_calls=0,actual_normalized_month_recreations=0,actual_accounts_constructed=0,historical_scopes_created=0,provider_iterations=0,financial_runs=0,financial_GO_written=0,locked_source_reads=0,new_network_requests=0,resources=dict(CPU_affinity=sorted(os.sched_getaffinity(0)),wall_seconds=time.monotonic()-began,max_RSS_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024)))
print(json.dumps(dict(status='PASS_SAVED_SOURCE_TARGET_QUALITY_BINDINGS',checks=len(CHECKS),audit=pin(HERE/'SAVED_SOURCE_AUDIT.json'),preparation=pin(PREP/'PREPARATION.json'),wall_seconds=time.monotonic()-began)))
