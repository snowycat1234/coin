"""Offline fake-fixture cold checks. Never admits actual source or finance.

Exact archived test sources are loaded without executing their __main__ sealers.
Only their historical load-time CPU6 requests are explicitly remapped to the
single assigned CPU. No original source byte is rewritten.
"""
import argparse,os,json,sys,time,resource,unittest,runpy,socket,subprocess
from pathlib import Path
from hashlib import sha256
from unittest.mock import patch
ROOT=Path(__file__).resolve().parent
EXEC=ROOT/'traditional_D_full2022_20261015_v2'
parser=argparse.ArgumentParser();parser.add_argument('--cpu',type=int,required=True);parser.add_argument('--output',required=True)
a=parser.parse_args()
assert a.cpu in os.sched_getaffinity(0),'ASSIGNED_CPU_NOT_ALLOWED'
os.sched_setaffinity(0,{a.cpu})
THREADS=('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','POLARS_MAX_THREADS','VECLIB_MAXIMUM_THREADS')
for k in THREADS:os.environ[k]='1'
os.environ['PYTHONDONTWRITEBYTECODE']='1';sys.dont_write_bytecode=True
os.environ['FULL2022_REVIEW_DIR']=EXEC.name;os.environ['PURE_TEST_CPU']=str(a.cpu)
manifest=json.loads((ROOT/'FILE_MANIFEST.json').read_bytes())
actual={p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file()}
assert actual==set(manifest['files'])|{'FILE_MANIFEST.json'},'EXACT_PACKET_MEMBERS_REQUIRED'
for name,pin in manifest['files'].items():
 p=ROOT/name;raw=p.read_bytes()
 assert not p.is_symlink() and len(raw)==pin['bytes'] and sha256(raw).hexdigest()==pin['SHA256'],name
mapping=json.loads((ROOT/'ORIGINAL_COPY_MAPPING.json').read_bytes())
initial={x['packet_path']:x['SHA256'] for x in mapping['files']}
archived_identity=json.loads((EXEC/'IMPLEMENTATION_RECEIPT.json').read_bytes())['code_identity']
index=json.loads((ROOT/'full2022_unaffected_source_restore_20261015/FINAL_RAW_SOURCE_INDEX.json').read_bytes())
metadata_pins={n:sha256((ROOT/'full2022_unaffected_source_restore_20261015'/n).read_bytes()).hexdigest() for n in ('FINAL_RAW_SOURCE_INDEX.json','FINAL_SOURCE_QUALIFICATION_RECEIPT.json','FINAL_DELIVERABLE_PINS.json')}
# All actual small projection bytes have now been integrity-hashed only. Never
# decode them. Exact monthly/daily source bodies and valid GO bodies are absent.
blocked_actual_reads=[];network_attempts=[];process_attempts=[]
def audit(event,values):
 if event in ('socket.connect','socket.getaddrinfo'):
  network_attempts.append(event);raise AssertionError('COLD_VERIFIER_NETWORK_FORBIDDEN')
 if event=='subprocess.Popen':
  process_attempts.append(event);raise AssertionError('COLD_VERIFIER_PROCESS_LAUNCH_FORBIDDEN')
 if event!='open' or not values or not isinstance(values[0],(str,bytes,os.PathLike)):return
 p=Path(os.fsdecode(values[0])).resolve()
 if ROOT not in p.parents:return
 rel=p.relative_to(ROOT).as_posix();upper=p.name.upper()
 source_body=('source_only_projections' in p.parts or '/raw/' in rel or p.suffix.lower() in ('.parquet','.npy','.bin'))
 valid_go=('ROOT_SOURCE_STAGE_GO_APPROVED' in upper or upper=='SOURCE_PREP_GO.JSON' and 'obvious_fake' not in rel.lower())
 if source_body or valid_go:
  blocked_actual_reads.append(rel);raise AssertionError('ACTUAL_SOURCE_OR_VALID_AUTHORITY_BODY_READ_FORBIDDEN:'+rel)
sys.addaudithook(audit)
for p in (EXEC,ROOT/'traditional_three_tier_freeze_20261015',ROOT/'bounded_native_continuation_guard50_exit_expansion_20261015',ROOT/'traditional_D_full2022_source_stage_handoff_20261015'):sys.path.insert(0,str(p))
began=time.monotonic()
import numpy as np
import polars as pl
import full_source as source
import full_entry as entry
import source_stage_guard as guard
suite=unittest.TestSuite();declared=[];remaps=[]
EXCLUSIONS={
 'test_generated_runner.RunnerTests.test_duplicate_jobs_and_low_memory_pause_before_spawn':'Exact test hardcodes CPU4; assigned CPU7 only. Initial attempt stopped at CPU-affinity precondition before intended assertion; CPU4/5 rerun prohibited.',
 'test_generated_runner.RunnerTests.test_existing_output_and_unfinished_output_pause_no_spawn':'Exact test hardcodes CPU4; assigned CPU7 only. Initial attempt stopped at CPU-affinity precondition before intended assertion; CPU4/5 rerun prohibited.',
 'portable_review_generated_core.GeneratedReview.test_all_tiers_whole_same_input_D_financial_states_ledgers_and_minutes_exact':'Initial attempt failed whole-snapshot equality in LOW/MID/HIGH. Outside archived 32-test review subset. Concrete differences recorded separately; independently unresolved. Exact test and finance source remain unchanged.'}
def add_tests(loaded):
 for test in loaded:
  if isinstance(test,unittest.TestSuite):add_tests(test);continue
  if test.id() in EXCLUSIONS:
   reason=EXCLUSIONS[test.id()]
   def excluded(self,reason=reason):self.skipTest(reason)
   setattr(test,test._testMethodName,excluded.__get__(test,type(test)))
  suite.addTest(test)
for name in ('test_full_gate','test_generated_d','test_generated_native40','test_generated_runner'):
 loaded=unittest.defaultTestLoader.loadTestsFromName(name);declared.append(dict(group=name,declared_tests=loaded.countTestCases()));add_tests(loaded)
original_affinity=os.sched_setaffinity
def remap_affinity(pid,mask):
 assert pid==0 and set(mask)=={6},'UNEXPECTED_ARCHIVED_TEST_AFFINITY'
 remaps.append(dict(original_CPU=6,assigned_CPU=a.cpu));return original_affinity(pid,{a.cpu})
for filename,cls in [('review_source_seams.py','SourceSeams'),('review_source_guard.py','SourceGuard'),('review_live_quality.py','LiveQuality'),('review_recording_scope.py','RecordingScope'),('review_generated_core.py','GeneratedReview')]:
 with patch.object(os,'sched_setaffinity',remap_affinity):
  mod=runpy.run_path(str(ROOT/'traditional_D_full2022_independent_review_20261015'/filename),run_name='portable_'+filename[:-3])
 loaded=unittest.defaultTestLoader.loadTestsFromTestCase(mod[cls]);declared.append(dict(group=filename,declared_tests=loaded.countTestCases()));add_tests(loaded)
loaded=unittest.defaultTestLoader.loadTestsFromName('test_source_stage_guard');declared.append(dict(group='test_source_stage_guard',declared_tests=loaded.countTestCases()));add_tests(loaded)
# Supplementary exact source, two self-contained fake-only tests. Its third test
# requires the deliberately omitted actual PREPARATION; report an explicit skip.
mod=runpy.run_path(str(ROOT/'traditional_D_full2022_supplementary_pure_tests_20261015/test_pure_reporting_portability.py'),run_name='portable_supplementary')
loaded=unittest.defaultTestLoader.loadTestsFromTestCase(mod['PureTests'])
for test in loaded:
 if test._testMethodName=='test_legacy_private_GO_deny_read_current_metadata_and_hash_contract':
  def omitted(self):self.skipTest('Exact actual PREPARATION body deliberately omitted; archived result is hash-only evidence')
  setattr(test,test._testMethodName,omitted.__get__(test,type(test)))
 suite.addTest(test)
declared.append(dict(group='supplementary_pure',declared_tests=loaded.countTestCases()))
# Two exact prior post-preparation tests depend on an omitted prior checkpoint
# source or actual PREPARATION/source-GO. Keep both explicit and unexecuted.
with patch.object(os,'sched_setaffinity',remap_affinity):
 mod=runpy.run_path(str(ROOT/'traditional_D_full2022_prepared_source_independent_review_20261015/review_data_free_flags.py'),run_name='portable_data_free_flags')
for test in unittest.defaultTestLoader.loadTestsFromTestCase(mod['DataFreeFlags']):
 def omitted(self):self.skipTest('Archived post-preparation test requires deliberately omitted original checkpoint or actual preparation/source-GO body')
 setattr(test,test._testMethodName,omitted.__get__(test,type(test)));suite.addTest(test)
declared.append(dict(group='post_preparation_flags',declared_tests=2))
class PacketTests(unittest.TestCase):
 def test_exact_64_file_code_identity_and_separate_guard(self):
  self.assertEqual(entry.code_identity(),archived_identity)
  self.assertEqual(source.jsha(entry.code_identity()),'fbe6fb7dd93733931ee58c3fc3ed3061c2c754e18cb72065722901d54a7bfd9d')
  self.assertEqual(guard.launcher_code_identity(),{'traditional_D_full2022_source_stage_handoff_20261015/source_stage_guard.py':'868c1094cc48c45e45875d52c6e7fe7a56727c0b35971ec5ad86930b4bf91bb8'})
 def test_nine_cells_full_calendar_and_terminal60(self):
  self.assertEqual(len(entry.tranche_cells()),9);self.assertEqual(entry.frozen_manifest()['alias_mapping'],{})
  self.assertEqual((source.END-source.START)//source.MINUTE,525600)
  self.assertEqual(entry._coldstart_policy(2022)['earliest_initial_increase_admission_us'],source.START+source.MINUTE+1)
  p=entry._policy(archived_identity)
  self.assertEqual(p['terminal_signal_us'],source.END-61*source.MINUTE)
  self.assertEqual(p['terminal_eligible_open_range'],[source.END-60*source.MINUTE,source.END-source.MINUTE])
 def test_actual_runtime_metadata_pins_preserved(self):
  self.assertEqual(metadata_pins,{'FINAL_RAW_SOURCE_INDEX.json':'ab57ebc72f05ac0e59df232b477de27f8674b34aca0667168b4c69c40ab065ab','FINAL_SOURCE_QUALIFICATION_RECEIPT.json':source.SOURCE_QUALIFICATION_SHA256,'FINAL_DELIVERABLE_PINS.json':source.FINAL_PINS})
  self.assertEqual(len(index['monthly']),120);self.assertEqual(len(index['daily']),16)
 def test_all136_raw_bodies_and_actual_preparation_targets_GO_absent(self):
  for rec in index['monthly']+index['daily']:self.assertFalse((ROOT/rec['source_path']).exists())
  self.assertFalse((ROOT/'traditional_D_full2022_20261015_v2_source_preparation_attempt001').exists())
  self.assertFalse((ROOT/'traditional_D_full2022_source_stage_handoff_20261015/ROOT_SOURCE_STAGE_GO_APPROVED_attempt001.json').exists())
  self.assertFalse((EXEC/'EXECUTION_CLAIMS').exists())
 def test_invalid_source_template_rejects_before_source_scope(self):
  raw=(EXEC/'SOURCE_PREP_AUTHORIZATION_TEMPLATE_UNAPPROVED.json').read_bytes()
  with self.assertRaises(ValueError):source.require_source_stage_authority(raw,source.sha(raw))
  self.assertEqual(json.loads(raw)['action'],'INVALID_TEMPLATE_NOT_ROOT_AUTHORIZATION')
 def test_old_authority_is_hash_only_no_old_GO_body_dependency(self):
  self.assertEqual(entry.preserved_evidence_identity(),{})
  deps=json.loads((EXEC/'DEPENDENCY_PINS.json').read_bytes())
  self.assertFalse(any('GO' in Path(name).name.upper() and Path(name).suffix=='.json' for name in deps))
  self.assertFalse(any('2025' in name for name in deps))
suite.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(PacketTests));declared.append(dict(group='packet_recovery',declared_tests=6))
result=unittest.TextTestRunner(verbosity=2).run(suite)
# Exact copied code/review bytes remain immutable; no hashes are silently updated.
changed=[]
for name,digest in initial.items():
 if name.endswith('.py') and sha256((ROOT/name).read_bytes()).hexdigest()!=digest:changed.append(name)
assert not changed,'FROZEN_CODE_CHANGED'
report=dict(schema='FULL2022_PUBLIC_PACKET_COLD_FAKE_ONLY_RECEIPT_V1',status='PASS_DOCUMENTED_SUBSET_WITH_EXPLICIT_UNRESOLVED_EXCLUSION' if result.wasSuccessful() else 'FAIL',
 tests_run=result.testsRun,tests_passed=result.testsRun-len(result.skipped)-len({getattr(t,'test_case',t).id() for t,_ in result.failures})-len({getattr(t,'test_case',t).id() for t,_ in result.errors}),distinct_failed_test_cases=len({getattr(t,'test_case',t).id() for t,_ in result.failures}),failure_entries_including_subtests=len(result.failures),skipped=[dict(test=str(t),reason=reason) for t,reason in result.skipped],failures=len(result.failures),errors=len(result.errors),declared_groups=declared,
 original_exact_sources_rewritten=False,copied_frozen_Python_files_changed=changed,explicit_wrapper_test_exclusions=EXCLUSIONS,archived_test_CPU_only_load_time_remaps=remaps,
 actual_small_source_projections_byte_hashed_only=True,actual_small_source_projections_decoded=False,actual_source_body_reads=0,actual_raw_source_downloads=0,source_stage_or_financial_GO_issued=0,actual_source_preparation_executed=False,actual_target_generation_executed=False,actual_source_provider_iterations=0,actual_accounts_constructed=0,actual_financial_runs=0,actual_market_minutes_advanced=0,publication_actions=0,
 blocked_actual_source_or_authority_body_read_attempts=blocked_actual_reads,network_attempts=network_attempts,subprocess_attempts=process_attempts,
 generated_fake_account_and_saved_report_tests=True,generated_temporary_claim_and_lease_tests=True,
 not_run=['Actual source recovery and fresh provider authentication','Actual source-stage GO issuance or raw normalization/preparation','Actual source numerical-equivalence rerun','Actual nine-cell recording-positive callbacks','Actual historical constructors, providers, accounts or financial replay','Two-worker generated resource pool/profile and annual resource certification','Snapshot restart or full cold original financial replay'],
 CPU_affinity=sorted(os.sched_getaffinity(0)),all_current_TID_affinities={p.name:sorted(os.sched_getaffinity(int(p.name))) for p in Path('/proc/self/task').iterdir()},thread_environment={k:os.environ[k] for k in THREADS},numpy_version=np.__version__,polars_version=pl.__version__,Python=sys.version.split()[0],wall_seconds=time.monotonic()-began,CPU_seconds=resource.getrusage(resource.RUSAGE_SELF).ru_utime+resource.getrusage(resource.RUSAGE_SELF).ru_stime,max_RSS_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,script_SHA256=sha256(Path(__file__).read_bytes()).hexdigest())
assert not blocked_actual_reads and not network_attempts and not process_attempts
with Path(a.output).open('x') as f:json.dump(report,f,sort_keys=True,indent=2);f.write('\n')
print(json.dumps({k:report[k] for k in ('status','tests_run','tests_passed','failures','errors','wall_seconds','max_RSS_bytes')}))
sys.exit(not result.wasSuccessful())
