# Original D full-2022 portable scaffold

## Initial scaffold scope

NEW code, metadata and generated-only negative/equivalence tests. No actual
market bodies, actual target generation, source overlay application, historical
scope/account/provider iteration, process probe, canonical claim, valid GO,
financial replay or publication. Source completion does not broaden this scope.
No old module, authority body, source or result is edited.

## Calendar and fixed experiment

Exactly STATIC50, H090, VOL_MANAGED_HOLD times LOW, MID, HIGH, BASE27,
coarse quantity profile, nine separate fresh 10,000 USDT wallets. No aliases,
performance selection, annual compounding, topups, external capital, or quantity
increase beyond the original strategy. Cash floor 1,000 and isolated ceiling
8,500 remain native. Calendar 2022-01-01 through 2023-01-01 exclusive: 365
decisions, 525,600 minutes. Cold-start first possible increase is Jan 1
00:01:00.000001. Earlier source observations/funding imply no owned position.
Terminal signal Dec 31 22:59; eligible opens 23:00 through 23:59. The last
POSSIBLE fill is 23:59:00.000001; actual paid fills must be reported per case.
The genuine final close at Jan 1 2023 is derived only from Dec 31 23:59 native
bar. Never select a 2023 daily-cube row. Daily target input projection contains
564 close rows, June 16 2021 through Dec 31 2022, strictly before Jan 1 2023.

## Staged dependencies and authority

1. This scaffold: typed pure source, quality and admission validators; generated
   fake fixtures; frozen D code-object/economic/phase equivalence. Source pins,
   SOURCE_PREP GO, independent full-source review, historical ROOT_GO and prepared
   input hashes are deliberately absent. All actual pathways fail closed.
2. Separate future SOURCE_ONLY authorization: exact completed source qualifier,
   complete original ZIP/repair provenance, endpoint, funding, and exact 27-hole
   allowlist. Root must admit SOURCE_PREP by an external pinned digest before any
   actual source/target/overlay preparation callback. This stage creates no
   historical scope, account, process or claim. Source authorization does not
   depend on future preparation hashes, avoiding circular GO dependencies.
3. Future source-only preparation and independent source/generated/unknown-risk
   review. Bind every input, target, quality sidecar, code and policy. All 27
   quality cells, 11 clocks, 8 runs, maximum 7, four singleton runs remain UNKNOWN
   or derived, arrival UNKNOWN. Preserve anchor price, identity and availability;
   quality installed before update_marks/immediate risk. No new increase/topup;
   ordinary reductions/reversal CLOSE/terminal/pending legitimate D exits survive.
   Entire same-clock funding batch precedes monitor except frozen protection-only
   native phase. Last-two-past-price envelope is descriptive, no safety bound.
   Actual funding/risk/execution impact remains PENDING until saved evidence.
4. Only after complete source qualification, independent review and a NEW exact
   root historical GO externally pinned may a distinct fresh historical scope be
   minted and the finite controller used. No snapshot restart, HALT restore,
   automatic retry, dedup financial claim or old private GO/review dependency.

## Runner and proof

Reuse the reviewed D paid-Guard50 engine, owned journals, previews/CapitalView,
32 corners, latency/capacity/funding/native phase unchanged. Preserve native40
chronological proof as authoritative and raw100 stored-delta residual separately,
with no tolerance/epsilon/forced balance. Honest full paid flat, conditional
forfeiture flat, residual/unsettled, native economic halt and operational pause
remain separate. Existing scheduler limits: 600 seconds wall/CPU, one assigned
CPU per worker, numerical pools one, all helper TIDs confined, 2GB RSS/4GB AS/
250MB output per case, maximum two workers/3.5GB aggregate with distinct affinity.
Canonical claims are permanent and global controller lease held through workers.
Generated unit tests only now; no bounded process/resource probe without new root
permission. Use existing venv Python -B and light CPU4/5 or 8; do not interfere
with source/download work on CPU0 or reserved review/publication CPUs6/7.

## Stable generated checkpoint boundary

The future actual raw ZIP bridge, causal adapter, native/daily projector and
source-only preparation are implemented. Their application was never invoked.
Final raw metadata hashes are recorded separately without installing authority.
Availability and installation are OFFLINE_MODEL replay clocks; actual publication,
arrival and installation remain UNKNOWN. New adapter code identity and independent
review are mandatory source-stage GO fields. GO/review expected digests come from
the root invocation, outside saved artifacts; no self-referential GO pin is part
of its reviewed code hash. The source-stage and historical authority remain closed.

Future saved impact audit is required for FUNDING, NATIVE_IMMEDIATE_RISK,
GUARD50_MONITOR, PAID_EXECUTION, TERMINAL and POSITION_INTERVALS. All actual
effects remain PENDING; no zero-impact, future-bound or no-liquidation claim.

## Qualified metadata revision 2 and latest authority

The original checkpoint is preserved unchanged. v2 installs the final raw source
pins b10686c8 / qualifier36310f40 / independent source-review5a934063, plus two
independent fixes: strict metadata integer types and timestamp validation.
Source-stage GO must still bind exact current code, new adapter review, source
qualification/provenance and real27 policy. No actual application has occurred.

Root separately approved a bounded synthetic probe, which completed two obvious
1970 fake calendars on CPUs4/5. Source-preparation counters stay zero; synthetic
workers are separately accounted. This does not prove actual-year resource fit.

Root conditionally approved future source-only normalization, flagged carry27,
frozen deterministic targets, native endpoint and owned-neutral funding only
after both exact independent reviews and a fresh external source-stage GO. Nine
recording-only metadata callbacks are allowed at that stage: their scopes are a
different class from historical execution scopes and are immediately revoked on
return or error. The actual-domain helper requires a validated source-stage
scope; a caller string or generated flag cannot substitute. Financial scopes,
accounts, provider iteration, financial claims and historical GO remain closed.
