# Original D full-2022 scaffold

Current scope is generated-only code validation. No actual market body has been
opened by this implementation task. No actual target, normalized source array,
overlay, historical scope/account/provider iteration, actual-source process/resource probe,
canonical financial claim, valid GO, historical result or publication was made.

## Components

- full_source.py: typed metadata/source/quality contracts, separate sealed source
  stage and fresh historical/provider boundaries. Completed raw/source-review pins are installed; source-stage GO remains absent.
- raw_source_bridge.py: implemented future raw ZIP/CSV normalization, using the
  confirmed final raw-index/QA contract, one month/stream dictionary at a time.
  Original sources and genuine daily repairs remain distinguishable.
- source_overlay.py: new declared causal carry adapter. Synthetic API remains
  synthetic-only; actual API requires the separate source-stage scope. No real
  data is ever routed through frozen v4's fixture symbols or generated flags.
- source_projection.py: implemented future native/daily/target/quality binding,
  564 strictly past-only daily rows, original deterministic nine target paths,
  genuine final Dec31 native-bar endpoint, 5550 raw funding events.
- full_d.py: exact D financial/intent/paid-exit methods and native constructor
  transport. A source-clock-only mark seam preserves per-asset genuine anchors,
  installs UNKNOWN before native immediate risk, and waits for installed recovery.
- full_entry.py and run_full.py: separate source-only preparation and historical
  admission, fresh scope, finite scheduler, permanent claims/global nine-cell
  controller lease, exact saved-native40 proof and unchanged resource limits.

All authority hashes are external invocation expectations, never taken from
saved self-assertions or written into the code hash of their own GO/review.
Source completion/qualification/review pins are now installed in v2 and must be
reviewed as part of this final code identity.
The source-stage GO must bind exact current adapter code identity, its separate
independent review, source/provenance/real27 allowlist and policy. It does not bind
nonexistent target hashes. Historical GO then binds the frozen preparation.

## Verification and remaining gates

Only fake fixtures and generated finance are tested here. Actual source-positive
callbacks, actual raw bridge equivalence, real27 application, actual-year native
resource fit and actual saved-event impact audits have NOT run. The driver
is implemented but is not admitted or certified for historical execution.

The final raw metadata is available, but raw restore explicitly remains short of
full native/source admission because 27 MARK cells are UNKNOWN. Source-stage
application, independent source/quality review and separate root GO are required.
Actual publication/arrival/installation remains UNKNOWN. Available/installed
replay clocks are explicitly OFFLINE_MODEL completion/replay assumptions.

Future saved results must distinguish affected funding, native immediate risk,
Guard50 monitors, paid execution, terminal and position intervals. Those effects
remain PENDING. The fixed last-two-past-price envelope is descriptive, with no
future bound, low-impact claim or liquidation/no-liquidation certificate.

## Revision 2

The prior original checkpoint is preserved byte-exact. This revision installs
completed raw/source-review metadata bindings and fixes independently found
integer-type validation and quality-witness timestamp validation. No source-stage
GO or actual application is authorized by these metadata changes.

A separately authorized synthetic-only resource probe completed two concurrent
1970 fake native calendars (4,320 minutes each), CPUs4/5, numerical pools1,
inherited temporary lease and all helper TID affinities confined. Peak observed
aggregate worker RSS was 197,804,032 bytes. This is not an actual-year fit proof;
source preparation itself still launched no process or account.
