"""Hard-gated actual-source projector over an exact captured transport contract.

No module-level market I/O. The final qualifier supplies pinned normalized
monthly containers retaining exact genuine fields and NaN only at original27
MARK absences; the separate stage-authorized adapter carries those cells.
"""
from io import BytesIO
import json
from pathlib import Path,PurePosixPath
from types import MappingProxyType
import numpy as np
import polars as pl
import full_source as s
from source_overlay import GenuineMarkObservation,apply_actual_causal_marks


def relative(name):
    p=PurePosixPath(name)
    if type(name) is not str or p.is_absolute() or '..' in p.parts or str(p)!=name or '\\' in name:
        raise ValueError('PORTABLE_RELATIVE_SOURCE_NAME_REQUIRED')
    return name


def month_arrays(raw,start,count,quality_cells):
    with np.load(BytesIO(raw),allow_pickle=False) as z:
        needed={'times','available_us'}|{symbol+'_'+k for symbol in s.S for k in ('open','close','quote_volume','mark')}
        allowed=needed|{symbol+'_'+k for symbol in s.S for k in ('high','low','volume','mark_open','mark_high','mark_low')}
        if not needed<=set(z.files)<=allowed:raise ValueError('EXACT_NATIVE_MONTH_SOURCE_NAMESPACE_REQUIRED')
        times=z['times'].copy();available=z['available_us'].copy()
        if (times.dtype!=np.dtype('int64') or available.dtype!=np.dtype('int64') or times.shape!=(count,)
                or not np.array_equal(times,np.arange(start,start+count*s.MINUTE,s.MINUTE,dtype=np.int64))
                or not np.array_equal(available,times+s.MINUTE)):raise ValueError('EXACT_NATIVE_OPEN_COMPLETION_CLOCKS_REQUIRED')
        arrays={'times':times};missing=[]
        overlay={(c.symbol,c.minute_open_us):c for c in quality_cells}
        for symbol in s.S:
            for k in ('open','close','quote_volume','mark'):
                value=z[symbol+'_'+k].copy()
                if value.dtype!=np.dtype('float64') or value.shape!=(count,):raise ValueError('EXACT_FLOAT64_NATIVE_SOURCE_ARRAY_REQUIRED')
                if k=='mark':
                    holes=np.flatnonzero(np.isnan(value))
                    for off in holes:
                        key=(symbol,start+int(off)*s.MINUTE)
                        if key not in overlay:raise ValueError('UNLISTED_MARK_ABSENCE_FORBIDDEN')
                        c=overlay[key];value[off]=float(c.price_text);missing.append(key)
                    if any(start<=c.minute_open_us<start+count*s.MINUTE and c.symbol==symbol and c.minute_open_us not in {start+int(i)*s.MINUTE for i in holes} for c in quality_cells):
                        raise ValueError('GENUINE_MARK_SOURCE_MAY_NOT_BE_OVERWRITTEN')
                if not np.isfinite(value).all() or (value<0).any() or k!='quote_volume' and (value<=0).any():raise ValueError('FINITE_GENUINE_NATIVE_TRADE_OR_BOUNDED_MARK_REQUIRED')
                arrays[symbol+'_'+k]=value
    for a in arrays.values():a.setflags(write=False)
    return arrays,tuple(missing)


def project_daily_grid(raw):
    """Pure shared actual/fake routine. Input already projects strictly <2023."""
    with np.load(BytesIO(raw),allow_pickle=False) as z:
        if set(z.files)!={'symbol_order','close_available_us','close'}:raise ValueError('EXACT_PROJECTED_DAILY_FIELDS_ONLY_REQUIRED')
        symbols=tuple(z['symbol_order']);times=z['close_available_us'].copy();close=z['close'].copy()
    if (symbols!=s.S or times.dtype!=np.dtype('int64') or times.shape!=(564,)
            or close.dtype!=np.dtype('float64') or close.shape!=(564,5)
            or not np.array_equal(times,np.arange(s.ALLOWED_START,s.END,s.DAY,dtype=np.int64))
            or not np.isfinite(close).all() or (close<=0).any()):raise ValueError('EXACT564_PAST_ONLY_FIVE_DAILY_CLOSES_REQUIRED')
    import sys
    if str(s.FROZEN) not in sys.path:sys.path.insert(0,str(s.FROZEN))
    import frozen_grid as g
    if Path(g.__file__).resolve()!=s.FROZEN/'frozen_grid.py':raise ValueError('EXACT_FROZEN_STRATEGY_TARGET_FUNCTIONS_REQUIRED')
    decisions=np.arange(s.START,s.END,s.DAY,dtype=np.int64)
    d,targets,covariance,proofs=g.build_target_grid(close,times,times.copy(),decisions)
    if len(d)!=365 or set(targets)!=set(s.CONFIGS):raise ValueError('EXACT365_NINE_ORIGINAL_TARGET_PATHS_REQUIRED')
    for a in (d,covariance,*targets.values()):a.setflags(write=False)
    rows=tuple(MappingProxyType(dict(symbol=symbol,close_us=int(at),available_us=int(at),close=float(close[i,j]))) for i,at in enumerate(times) for j,symbol in enumerate(s.S))
    daily=pl.DataFrame([dict(symbol=symbol,close_us=int(at),close=float(close[i,j])) for i,at in enumerate(times) if s.START<=at<s.END for j,symbol in enumerate(s.S)])
    projection=dict(schema='FULL2022_PAST_ONLY_564_PROJECTED_CLOSES_V1',fields=['symbol_order','close_available_us','close'],
        rows=564,calendar=[s.ALLOWED_START,s.END-s.DAY],strictly_before_us=s.END,selected_2023_daily_cube_rows=0,
        decisions=365,ready_200close_windows=365,endpoint_origin='GENUINE_DEC31_2359_NATIVE_BAR_ONLY')
    return d,targets,covariance,proofs,rows,daily,projection


def quality_intervals(cells):
    # Canonical disjoint clock partitions satisfy the unchanged native quality
    # guard while preserving full per-symbol source clocks in the rich sidecar.
    by_clock={}
    for c in cells:by_clock.setdefault(c.completed_us,set()).add(c.symbol)
    intervals=[]
    for at,symbols in sorted(by_clock.items()):
        syms=tuple(sorted(symbols))
        if intervals and intervals[-1][1]==at and intervals[-1][2]==syms:
            intervals[-1]=(intervals[-1][0],at+s.MINUTE,syms)
        else:intervals.append((at,at+s.MINUTE,syms))
    return tuple(intervals)


def project(root,*,source_scope=None,source_authorization_raw=None,expected_source_authorization_sha256=None):
    s.require_full_source_pins();root=Path(root).resolve()
    # Actual normalization is implemented behind source-stage admission. The
    # raw bridge uses only exact original ZIPs and genuine daily repairs.
    from raw_source_bridge import capture_and_normalize
    transport,captured,source_scope=capture_and_normalize(root,source_authorization_raw=source_authorization_raw,
        expected_source_authorization_sha256=expected_source_authorization_sha256)
    files=transport['source_files'];qraw=captured[transport['qualification_file']]
    q=source_scope.qualification
    if transport.get('source_identity')!=q.source_identity:raise ValueError('EXACT_TRANSPORT_SOURCE_IDENTITY_REQUIRED')
    anchors=tuple(GenuineMarkObservation(**a) for a in json.loads(captured[transport['mark_anchor_file']]))
    cells=apply_actual_causal_marks(anchors,source_scope=source_scope,as_of_us=s.END)
    d,targets,covariance,proofs,rows,daily,projection=project_daily_grid(captured[transport['daily_projection_file']])
    events=json.loads(captured[transport['funding_file']])
    if (type(events) is not list or len(events)!=5550 or len({(e['event_us'],e['symbol']) for e in events})!=5550
            or any(e['symbol'] not in s.S or type(e['event_us']) is not int or not s.START<=e['event_us']<s.END
                or set(e)!={'symbol','event_us','raw_rate','reported_interval_hours','raw_rate_unit'} for e in events)):
        raise ValueError('EXACT5550_ORIGINAL_RAW_FUNDING_EVENTS_REQUIRED')
    if events!=sorted(events,key=lambda e:(e['event_us'],s.S.index(e['symbol']))):raise ValueError('ORIGINAL_FUNDING_CLOCK_AND_SYMBOL_ORDER_REQUIRED')
    for e in events:
        if not np.isfinite(float(e['raw_rate'])) or not np.isfinite(float(e['reported_interval_hours'])) or e['reported_interval_hours']<=0 or e['raw_rate_unit']!='UNCONFIRMED':raise ValueError('PRESERVED_RAW_FUNDING_UNIT_AND_INTERVAL_REQUIRED')
    provider=[];cursor=s.START;seen=[];final=None
    from datetime import datetime,timezone
    for index,rec in enumerate(transport['months'],1):
        month_start=int(datetime(2022,index,1,tzinfo=timezone.utc).timestamp()*1e6)
        month_end=s.END if index==12 else int(datetime(2022,index+1,1,tzinfo=timezone.utc).timestamp()*1e6)
        count=(month_end-month_start)//s.MINUTE
        if rec.get('month')!=f'2022-{index:02}' or rec.get('start_us')!=cursor or rec.get('minutes')!=count:raise ValueError('EXACT_TWELVE_CHRONOLOGICAL_NATIVE_MONTHS_REQUIRED')
        raw=captured[rec['file']];a,missing=month_arrays(raw,cursor,count,cells);seen.extend(missing)
        # Genuine trade daily closes through Dec31 are checked against the input
        # cube projection; the Jan1 endpoint uses the final native bar only.
        for at in range(cursor+s.DAY,month_end+1,s.DAY):
            if at==s.END:continue
            k=(at-s.ALLOWED_START)//s.DAY
            for j,symbol in enumerate(s.S):
                if np.float64(a[symbol+'_close'][(at-cursor)//s.MINUTE-1]).tobytes()!=np.float64(rows[k*5+j]['close']).tobytes():raise ValueError('GENUINE_NATIVE_TO_DAILY_CLOSE_PARITY_REQUIRED')
        provider.append((rec['file'],cursor,count,raw,0,count));final=a;cursor=month_end
    if len(provider)!=12 or cursor!=s.END or tuple(sorted(seen))!=tuple(sorted(s.ACTUAL27_OPEN_POINTS_US)):raise ValueError('EXACT_ANNUAL_CALENDAR_AND27_SOURCE_ABSENCES_REQUIRED')
    # Each carried anchor's numeric bits must equal the original genuine source
    # row and its provenance is pinned by the exact anchor/qualification files.
    for c in cells:
        rec=next(v for v in provider if v[1]<=c.anchor_open_us<v[1]+v[2]*s.MINUTE)
        aa,_=month_arrays(rec[3],rec[1],rec[2],cells);off=(c.anchor_open_us-rec[1])//s.MINUTE
        if np.float64(aa[c.symbol+'_mark'][off]).tobytes()!=np.float64(float(c.price_text)).tobytes():raise ValueError('EXACT_ORIGINAL_GENUINE_ANCHOR_PRICE_BITS_REQUIRED')
    from dataclasses import asdict
    sidecar=dict(schema='FULL2022_CAUSAL27_MARK_QUALITY_SOURCE_CLOCK_V1',calendar=[s.START,s.END],quality_intervals=s.plain(quality_intervals(cells)),
        cells=[asdict(c) for c in cells],derived_mark_cells=27,quality='UNKNOWN_OR_DERIVED',arrival_status='UNKNOWN_NOT_CERTIFIED',
        final_endpoint_close={symbol:float(final[symbol+'_close'][-1]) for symbol in s.S},endpoint_origin='GENUINE_DEC31_2359_NATIVE_BAR',
        endpoint_open_us=s.END-s.MINUTE,endpoint_completed_us=s.END,selected_2023_daily_cube_rows=0,
        source_completion_SHA256=s.FINAL_PINS,source_identity=q.source_identity,
        source_funding_coverage_is_not_ownership=True,earliest_native_coldstart_increase_us=s.START+s.MINUTE+1,
        funding_ownership='CURRENT_NATIVE_ACTUAL_QUANTITY_ONLY_AFTER_PAID_FILLS',
        terminal_signal_us=s.END-61*s.MINUTE,terminal_eligible_open_range=[s.END-60*s.MINUTE,s.END-s.MINUTE],latest_POSSIBLE_terminal_fill_us=s.END-s.MINUTE+1,
        availability_clock_semantics='OFFLINE_MODEL_COMPLETION_BOUNDARY',installation_clock_semantics='OFFLINE_MODEL_REPLAY_INSTALLATION',actual_publication_arrival_installation='UNKNOWN_NOT_CERTIFIED',
        required_saved_impact_audit=['FUNDING','NATIVE_IMMEDIATE_RISK','GUARD50_MONITOR','PAID_EXECUTION','TERMINAL','POSITION_INTERVALS'],
        affected_event_and_position_interval_flags='PENDING_ACTUAL_SAVED_EVIDENCE_NOT_ZERO_IMPACT',
        actual_event_impacts='PENDING_ACTUAL_SAVED_EVIDENCE',past2_envelope_is_future_bound=False,certifies_liquidation=False,certifies_no_liquidation=False)
    window=MappingProxyType(dict(start=s.START,end=s.END,symbols=s.S,daily=daily,events=s.immutable(events),
        minute_blocks=s.CapturedMinuteProvider(2022,tuple(provider),cells),derived_mark_cells=27,
        original_missing_mark_open_ms=tuple(at//1000 for _,at in s.ACTUAL27_OPEN_POINTS_US),
        original_overlay_future_looking=False,original_overlay_execution_admitted=False,causal_mark_adapter=s.immutable(sidecar)))
    return dict(source_files=files,captured=captured,source_identity=q.source_identity,source_qualification=json.loads(source_authorization_raw)['qualified_source_binding'],
        decisions=d,targets=targets,covariance=covariance,proofs=proofs,window=window,source_rows=rows,
        sidecar=sidecar,sidecar_raw=s.canonical(sidecar)+b'\n',projection=projection,quality_cells=cells,
        quality_intervals=quality_intervals(cells),quality=dict(fullfive200_decisions=365,derived_mark_cells=27,actual_source=True,
        quality='UNKNOWN_OR_DERIVED',arrival_status='UNKNOWN_NOT_CERTIFIED',publication_arrival_certified=False,
        funding_units_certified=False,native_venue_certified=False))
