"""New declared source adapter; actual API stays separately stage-authorized.

The pure carry algorithm is tested on fake symbols and prices. No actual arrays
are read, normalized, constructed or written by this module or on import.
"""
from dataclasses import dataclass
from decimal import Decimal
from types import MappingProxyType
import full_source as s

@dataclass(frozen=True,slots=True)
class GenuineMarkObservation:
    symbol:str
    minute_open_us:int
    completed_us:int
    available_us:int
    installed_us:int
    price_text:str
    source_SHA256:str
    record_id:str
    domain:str='MARK'
    selected_field:str='selected_mark_price'
    quality:str='GENUINE_MARK_SOURCE'
    availability_clock_semantics:str='OFFLINE_MODEL_COMPLETION_BOUNDARY'
    installation_clock_semantics:str='OFFLINE_MODEL_REPLAY_INSTALLATION'
    actual_publication_arrival_installation:str='UNKNOWN_NOT_CERTIFIED'


def _carry(observations,holes,*,allowed_symbols,as_of_us):
    observations=tuple(observations);holes=tuple(holes);missing=set(holes)
    if type(as_of_us) is not int or as_of_us<0:raise ValueError('EXACT_INTEGER_SNAPSHOT_CLOCK_REQUIRED')
    if len(holes)!=27 or len(missing)!=27:raise ValueError('EXACT27_APPROVED_MISSING_CELLS_REQUIRED')
    ids=set();source_ids=set();seen=set();by_symbol={}
    for o in observations:
        if type(o) is not GenuineMarkObservation or o.symbol not in allowed_symbols:raise ValueError('EXACT_DECLARED_GENUINE_MARK_OBSERVATION_REQUIRED')
        if (o.domain!='MARK' or o.selected_field!='selected_mark_price' or o.quality!='GENUINE_MARK_SOURCE'
                or any(type(x) is not int or x<0 for x in (o.minute_open_us,o.completed_us,o.available_us,o.installed_us))
                or o.minute_open_us%s.MINUTE or o.completed_us!=o.minute_open_us+s.MINUTE
                or not o.completed_us<=o.available_us<=o.installed_us
                or (o.symbol,o.minute_open_us) in missing):raise ValueError('GENUINE_ANCHOR_DOMAIN_CLOCK_OR_MISSINGNESS_INVALID')
        if (o.availability_clock_semantics!='OFFLINE_MODEL_COMPLETION_BOUNDARY' or o.installation_clock_semantics!='OFFLINE_MODEL_REPLAY_INSTALLATION' or o.actual_publication_arrival_installation!='UNKNOWN_NOT_CERTIFIED'):raise ValueError('EXPLICIT_OFFLINE_MODEL_CLOCKS_REQUIRED')
        s.digest(o.source_SHA256)
        if type(o.price_text) is not str or not 0<len(o.price_text)<=200:raise ValueError('EXACT_PRICE_TEXT_REQUIRED')
        p=Decimal(o.price_text)
        if not p.is_finite() or p<=0:raise ValueError('POSITIVE_GENUINE_PRICE_REQUIRED')
        if type(o.record_id) is not str or not o.record_id:raise ValueError('EXACT_RECORD_ID_REQUIRED')
        key=(o.symbol,o.minute_open_us);source=(o.source_SHA256,o.record_id)
        if key in seen or source in source_ids:raise ValueError('DUPLICATE_GENUINE_SOURCE_OR_CELL')
        seen.add(key);source_ids.add(source);by_symbol.setdefault(o.symbol,[]).append(o)
    result=[]
    for symbol,at in sorted(holes,key=lambda x:(x[1],x[0])):
        if symbol not in allowed_symbols or type(at) is not int or at%s.MINUTE or at+s.MINUTE>as_of_us:
            raise ValueError('EXACT_COMPLETED_APPROVED_HOLE_REQUIRED')
        clock=at+s.MINUTE
        candidates=[o for o in by_symbol.get(symbol,()) if o.minute_open_us<at and o.completed_us<clock and o.available_us<=clock and o.installed_us<=clock]
        if not candidates:raise ValueError('NO_CAUSALLY_INSTALLED_PRIOR_GENUINE_MARK')
        a=max(candidates,key=lambda o:o.completed_us)
        c=s.QualityCell(symbol,at,clock,clock,a.price_text,a.minute_open_us,a.completed_us,
            a.available_us,a.installed_us,a.available_us,a.source_SHA256,a.record_id)
        c.validate();result.append(c)
    result=tuple(result);s.validate_quality_binding(result,expected_missing_cells=holes)
    return result


def build_generated_overlay(observations,holes,*,as_of_us):
    """Synthetic-only equivalence seam. No generated flag admits history."""
    holes=tuple(holes)
    if any(type(symbol) is not str or not symbol.startswith('FIXTURE_') or not 978307200000000<=at<978393600000000 for symbol,at in holes):
        raise ValueError('GENERATED_FIXTURE_SYMBOLS_AND_2001_CALENDAR_ONLY')
    return _carry(observations,holes,allowed_symbols=frozenset(s for s,_ in holes),as_of_us=as_of_us)


def apply_actual_causal_marks(observations,*,source_scope,as_of_us):
    """Future reviewed actual stage only. No output file writes or account call.

    Source approval is checked before inspecting observations. Caller must keep
    original source/absence proofs and separately bind output quality sidecar.
    Original missing OPEN clocks are fixed metadata; completion is OPEN+minute.
    """
    if type(source_scope) is not s.ActualSourceApplicationScope:raise ValueError('EXPLICIT_ACTUAL_SOURCE_STAGE_SCOPE_REQUIRED')
    source_scope.validate_current()
    if source_scope.qualification.allowlist_SHA256!=s.ACTUAL_ALLOWLIST_SHA256:raise ValueError('EXACT27_ACTUAL_SOURCE_ALLOWLIST_REQUIRED')
    return _carry(observations,s.ACTUAL27_OPEN_POINTS_US,allowed_symbols=frozenset(s.S),as_of_us=as_of_us)
