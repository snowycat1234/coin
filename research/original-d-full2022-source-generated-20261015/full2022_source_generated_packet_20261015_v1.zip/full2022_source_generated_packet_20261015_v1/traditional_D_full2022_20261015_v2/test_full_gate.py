"""Fake-only pure validators, source/quality equivalence and closed gates."""
from copy import deepcopy
from dataclasses import asdict,replace
from io import BytesIO
import importlib.util,json
from pathlib import Path
import sys,tempfile,unittest
from unittest.mock import patch
import numpy as np
import full_source as s
import full_entry as e
import source_overlay as new
from source_projection import project_daily_grid,quality_intervals

V4=s.ROOT/'causal_isolated_mark_overlay_20261015_v4'
spec=importlib.util.spec_from_file_location('_full2022_reviewed_generated_overlay_v4',V4/'overlay.py')
old=importlib.util.module_from_spec(spec);sys.modules[spec.name]=old;spec.loader.exec_module(old)


def metadata():
    return dict(schema='FULL2022_COMPLETE_SOURCE_QUALIFICATION_V1',status='PASS_SOURCE_ONLY_NO_HISTORICAL_GO',
        year=2022,calendar=[s.START,s.END],days=365,minute_count=525600,monthly_original_streams=120,
        original_ZIP_bytes=158411229,genuine_daily_repairs=16,genuine_daily_added_asset_minutes=23040,
        daily_projection_rows=564,daily_projection_calendar=[s.ALLOWED_START,s.END-s.DAY],daily_projection_strictly_before_us=s.END,
        ready_200close_decisions=365,raw_funding_events=5550,remaining_missing_trade_cells=0,remaining_missing_mark_cells=27,
        unique_mark_gap_open_clocks=11,mark_gap_asset_runs=8,mark_gap_singleton_runs=4,mark_gap_longest_run=7,
        endpoint_open_us=s.END-s.MINUTE,endpoint_completed_us=s.END,endpoint_origin='GENUINE_DEC31_2359_NATIVE_BAR',
        selected_2023_daily_cube_rows=0,historical_arrival_certified=False,funding_unit_certified=False,native_exchange_certified=False,
        source_observation_implies_ownership=False,accounts_constructed=0,historical_runs=0,
        source_identity='a'*64,provenance_SHA256='b'*64,allowlist_SHA256=s.ACTUAL_ALLOWLIST_SHA256,endpoint_source_SHA256='c'*64)


def observations():
    missing={(h.symbol,h.minute_open_ms) for h in old.FIXTURE_HOLES};by={}
    for h in old.FIXTURE_HOLES:
        if (h.symbol,h.minute_open_ms-old.MINUTE) in missing:continue
        for n in (2,1):
            at=h.minute_open_ms-n*old.MINUTE
            o=old.GenuineObservation('generated-'+h.symbol+'-'+str(at),h.symbol,at,at+old.MINUTE-1,
                at+old.MINUTE,at+old.MINUTE,at+old.MINUTE,'00100.123456789000000000000001','a'*64,'fake-row-'+h.symbol+'-'+str(at))
            by[(h.symbol,at)]=o
    return tuple(by.values())


def generated_overlay():
    obs=observations();converted=tuple(new.GenuineMarkObservation(o.symbol,o.minute_open_ms*1000,o.completed_at_ms*1000,
        o.available_at_ms*1000,o.installed_at_ms*1000,o.price_text,o.source_sha256,o.source_record_id) for o in obs)
    holes=tuple((h.symbol,h.minute_open_ms*1000) for h in old.FIXTURE_HOLES)
    result=new.build_generated_overlay(converted,holes,as_of_us=(old.FIXTURE_BASE_MS+1100*old.MINUTE)*1000)
    return obs,converted,holes,result


class PureGateTests(unittest.TestCase):
    def test_complete_fake_metadata_validates_without_minting_scope(self):
        m=metadata();q=s.SourceQualificationBinding.validate(m)
        self.assertEqual(q.source_identity,'a'*64);self.assertEqual(q.qualification_SHA256,s.jsha(m))
        s.digest(s.FINAL_PINS);s.digest(s.SOURCE_QUALIFICATION_SHA256);s.digest(s.SOURCE_INDEPENDENT_REVIEW_SHA256)
        with self.assertRaises(ValueError):s.require_source_stage_authority(None,None)

    def test_source_qualification_every_fixed_field_fails_closed(self):
        m=metadata()
        for key in m:
            bad=deepcopy(m);bad.pop(key)
            with self.subTest(key=key),self.assertRaises((ValueError,TypeError)):s.SourceQualificationBinding.validate(bad)

    def test_bool_is_not_integer_count_or_clock(self):
        for key in ('year','days','minute_count','raw_funding_events','endpoint_open_us'):
            m=metadata();m[key]=True
            with self.assertRaises(ValueError):s.SourceQualificationBinding.validate(m)

    def test_genuine_final_endpoint_and_no_2023_cube(self):
        for changes in ({'endpoint_origin':'DAILY_CUBE_2023_ROW'},{'selected_2023_daily_cube_rows':1},{'endpoint_open_us':s.END},{'daily_projection_strictly_before_us':s.END+s.DAY}):
            m=metadata();m.update(changes)
            with self.assertRaises(ValueError):s.SourceQualificationBinding.validate(m)

    def test_all_actual_boundaries_fail_before_any_body_or_callback(self):
        callback=lambda **kw:(_ for _ in ()).throw(AssertionError('CALLBACK_FORBIDDEN'))
        with tempfile.TemporaryDirectory() as td:
            Path(td,'PREPARATION.json').write_bytes(b'{}')
            with patch.object(Path,'read_bytes',side_effect=AssertionError('BODY_READ_FORBIDDEN')):
                for action in (lambda:s.project(td),lambda:s.admit_actual_source_stage(b'{}',b'{}','a'*64),
                    lambda:e.prepare_source_only({2022:td},Path(td)/'out'),lambda:s.apply_actual_causal_marks([],source_scope=None,as_of_us=s.END)):
                    with self.assertRaises(ValueError):action()
            with self.assertRaises(ValueError):e.make_case({2022:td},td,b'{}','a'*64,cell_id=e.tranche_cells()[0],review_raw=b'{}',expected_review_sha256='b'*64,constructor_callback=callback)
            self.assertFalse(Path(td,'out').exists())

    def test_root_hash_never_derived_from_saved_GO_or_review_body(self):
        raw=b'{"schema":"FAKE_SELF_MINTED"}'
        with self.assertRaises(ValueError):s._external(raw,s.sha(raw),'f'*64,'EXTERNAL_ROOT_REQUIRED')
        with self.assertRaises(ValueError):e.validate_root_go(b'{}',raw,None,cell_id=e.tranche_cells()[0])
        with self.assertRaises(ValueError):e._validate_independent_review(b'{}',{},raw,None,b'{}')

    def test_exact_nine_no_alias_and_calendar(self):
        m=e.frozen_manifest();self.assertEqual(len(e.tranche_cells()),9);self.assertEqual(m['alias_mapping'],{})
        self.assertEqual((s.END-s.START)//s.MINUTE,525600);self.assertEqual(s.DAYS,365)
        self.assertEqual(e._coldstart_policy(2022)['earliest_initial_increase_admission_us'],s.START+s.MINUTE+1)
        p=e._policy({'FAKE':'a'*64});self.assertEqual(p['terminal_signal_us'],s.END-61*s.MINUTE)
        self.assertEqual(p['terminal_eligible_open_range'],[s.END-60*s.MINUTE,s.END-s.MINUTE])

    def test_generated_flags_cannot_substitute_actual_source_scope(self):
        for forged in (None,object(),'GENERATED',metadata()):
            with self.assertRaises(ValueError):new.apply_actual_causal_marks([],source_scope=forged,as_of_us=s.END)
        with self.assertRaises(ValueError):s.ActualSourceApplicationScope(None,'a'*64,b'{}',b'{}',object())

    def test_fake27_carry_price_provenance_and_source_clock_equal_v4(self):
        obs,converted,holes,result=generated_overlay();reference=old.build_generated_overlay(obs,old.FIXTURE_HOLES,as_of_ms=old.FIXTURE_BASE_MS+1100*old.MINUTE)
        for a,b in zip(result,reference.records,strict=True):
            self.assertEqual((a.symbol,a.minute_open_us,a.price_text,a.anchor_open_us,a.source_freshness_clock_us,a.anchor_record_id),
                (b.symbol,b.minute_open_ms*1000,b.price_text,b.anchor_minute_open_ms*1000,b.source_freshness_clock_ms*1000,b.anchor_source_record_id))
        self.assertEqual(len(result),27);self.assertEqual(len({c.minute_open_us for c in result}),11)
        self.assertTrue(all(c.quality=='UNKNOWN_OR_DERIVED' and not c.is_genuine for c in result))

    def test_gap27_derived_fresh_future_domain_or_overwrite_rejected(self):
        _,obs,holes,cells=generated_overlay();c=cells[0]
        for bad in (replace(c,source_freshness_clock_us=c.completed_us),replace(c,quality='DIRECT_REVIEWED_SOURCE_OBSERVATION'),
                    replace(c,is_genuine=True),replace(c,anchor_installed_us=c.completed_us+1),replace(c,permits_new_increase=True)):
            with self.assertRaises(ValueError):s.validate_quality_binding((bad,)+cells[1:],expected_missing_cells=holes)
        for change in ({'quality':'UNKNOWN_OR_DERIVED'},{'domain':'TRADE'},{'available_us':obs[0].available_us+s.MINUTE,'installed_us':obs[0].available_us-1}):
            with self.assertRaises(ValueError):new.build_generated_overlay((replace(obs[0],**change),)+obs[1:],holes,as_of_us=978393600000000)
        with self.assertRaises(ValueError):new.build_generated_overlay(obs,s.ACTUAL27_OPEN_POINTS_US,as_of_us=s.END)

    def test_clock_partitions_preserve_exact_asset_minutes_without_broadening(self):
        _,_,holes,cells=generated_overlay();intervals=quality_intervals(cells)
        expanded={(symbol,at-s.MINUTE) for a,b,symbols in intervals for at in range(a,b,s.MINUTE) for symbol in symbols}
        self.assertEqual(expanded,set(holes));self.assertTrue(all(a[1]<=b[0] for a,b in zip(intervals,intervals[1:])))

    def test_past_only_original_daily_targets_fake_full_calendar(self):
        times=np.arange(s.ALLOWED_START,s.END,s.DAY,dtype=np.int64);base=np.arange(564,dtype=float)
        close=np.column_stack([100+j*30+base*(.02+j*.001)+np.sin(base/15+j)*.1 for j in range(5)])
        memory=BytesIO();np.savez_compressed(memory,symbol_order=np.asarray(s.S),close_available_us=times,close=close)
        d,targets,cov,proof,rows,daily,proj=project_daily_grid(memory.getvalue())
        self.assertEqual(d.shape,(365,));self.assertEqual(cov.shape,(365,5,5));self.assertEqual(set(targets),set(s.CONFIGS))
        self.assertEqual(proj['selected_2023_daily_cube_rows'],0);self.assertFalse(d.flags.writeable)
        # Mutating only the last permitted close cannot change earlier targets.
        later=close.copy();later[-1]*=2;memory=BytesIO();np.savez_compressed(memory,symbol_order=np.asarray(s.S),close_available_us=times,close=later)
        other=project_daily_grid(memory.getvalue())[1]
        for key in targets:self.assertEqual(targets[key][:-1].tobytes(),other[key][:-1].tobytes())


class FakeRawParserTests(unittest.TestCase):
    def test_genuine_fake_original_csv_strict_clock_and_conflict_checks(self):
        import zipfile
        from raw_source_bridge import parse_original_zip
        def blob(rows,name='BTCUSDT-1m-2022-01.csv'):
            out=BytesIO()
            with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:z.writestr(name,'\n'.join(','.join(r) for r in rows)+'\n')
            return out.getvalue()
        at=s.START//1000
        row=[str(at),'50000','50001','49999','50000','1',str(at+59999),'50000','1','0','0','0']
        rows,proof=parse_original_zip(blob([row]),symbol='BTCUSDT',period='2022-01',family='klines')
        self.assertEqual(len(rows),1);self.assertEqual(proof['observed_minutes'],1)
        for bad in (row[:6]+[str(at+60000)]+row[7:],row[:1]+['nan']+row[2:]):
            with self.assertRaises(ValueError):parse_original_zip(blob([bad]),symbol='BTCUSDT',period='2022-01',family='klines')
        conflict=row.copy();conflict[4]='50000.1'
        with self.assertRaises(ValueError):parse_original_zip(blob([row,conflict]),symbol='BTCUSDT',period='2022-01',family='klines')

    def test_actual_bridge_stops_before_body_capture_without_stage_authority(self):
        from raw_source_bridge import capture_and_normalize
        with patch.object(Path,'read_bytes',side_effect=AssertionError('ACTUAL_BODY_FORBIDDEN')):
            with self.assertRaises(ValueError):capture_and_normalize(s.SOURCE_ROOT,source_authorization_raw=None,expected_source_authorization_sha256=None)

if __name__=='__main__':unittest.main()
