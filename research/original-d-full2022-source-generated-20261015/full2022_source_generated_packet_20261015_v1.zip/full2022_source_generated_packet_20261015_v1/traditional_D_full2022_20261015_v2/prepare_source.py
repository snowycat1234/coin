"""Explicit source-only CLI. A review/template or raw completion is never GO."""
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','POLARS_MAX_THREADS','VECLIB_MAXIMUM_THREADS'):os.environ[key]='1'
import argparse,json
from pathlib import Path
import full_entry as e

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    for name in ('source-root','output','source-go','source-go-sha'):parser.add_argument('--'+name,required=True)
    parser.add_argument('--record-metadata',action='store_true');args=parser.parse_args()
    go=Path(args.source_go).read_bytes()
    prep=e.prepare_source_only({2022:args.source_root},args.output,source_authorization_raw=go,expected_source_authorization_sha256=args.source_go_sha)
    if args.record_metadata:
        receipt=e.record_source_metadata_callbacks(args.output,go,args.source_go_sha)
        with (Path(args.output)/'RECORDING_ONLY_METADATA_RECEIPT.json').open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
    print(json.dumps(dict(status=prep['status'],accounts=0,historical_scopes=0,provider_iterations=0,processes=0,claims=0,financial_GO=0)))
