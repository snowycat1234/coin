"""Supplementary data-free reporter/portability proof; no financial construction."""
import os
for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','POLARS_MAX_THREADS','VECLIB_MAXIMUM_THREADS'):os.environ[key]='1'
os.sched_setaffinity(0,{int(os.environ.get('PURE_TEST_CPU','8'))})
import ast,builtins,inspect,json,sys,tempfile,time,unittest
from pathlib import Path
from hashlib import sha256
from unittest.mock import patch
from contextlib import ExitStack
ROOT=Path(__file__).resolve().parents[1];HERE=Path(__file__).resolve().parent
EXEC=ROOT/'traditional_D_full2022_20261015_v2'
PREP=ROOT/'traditional_D_full2022_20261015_v2_source_preparation_attempt001/PREPARATION.json'
for p in (EXEC,ROOT/'traditional_D_full2022_source_stage_handoff_20261015'):sys.path.insert(0,str(p))
DENIED=[];READS=[]
def check_read(path,mode='r'):
    if not isinstance(path,(str,bytes,os.PathLike)):return
    p=Path(os.fsdecode(path));text=str(p).lower();name=p.name.upper()
    if any(x in mode for x in 'wax+'):return
    legacy=('full2022' not in text and (('GO' in name and p.suffix.lower()=='.json') or name in {'ADMISSION_REVIEW.JSON','ROOT_APPROVAL.JSON'}))
    if legacy:DENIED.append(str(p));raise AssertionError('LEGACY_AUTHORITY_BODY_READ_FORBIDDEN:'+str(p))
    if p.suffix.lower() in ('.zip','.npz') and 'obvious_fake_' not in text:raise AssertionError('NO_ACTUAL_MARKET_BODY_READ:'+str(p))
    READS.append(str(p))
ORIGINAL_OPEN=builtins.open;ORIGINAL_PATH_OPEN=Path.open;ORIGINAL_OS_OPEN=os.open
def op(file,mode='r',*a,**k):check_read(file,mode);return ORIGINAL_OPEN(file,mode,*a,**k)
def pop(path,mode='r',*a,**k):check_read(path,mode);return ORIGINAL_PATH_OPEN(path,mode,*a,**k)
def oop(path,flags,*a,**k):
    check_read(path,'w' if flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND) else 'r')
    return ORIGINAL_OS_OPEN(path,flags,*a,**k)
with ExitStack() as stack:
    stack.enter_context(patch.object(builtins,'open',op));stack.enter_context(patch.object(Path,'open',pop));stack.enter_context(patch.object(os,'open',oop))
    import source_stage_guard as sg
    import full_entry as entry
    import run_full as runner
    import full_d
    import numpy as np
    import annual_reporting

GUARD_OBSERVATIONS=[];FAKE_REPORTS={}
class PureTests(unittest.TestCase):
    def test_frozen_reporting_function_AST_identity(self):
        current=ast.parse(inspect.getsource(runner.held_risk_report)).body[0]
        oldtree=ast.parse((ROOT/'bounded_native_continuation_guard50_exit_expansion_20261015/run_expansion.py').read_text())
        old=next(n for n in oldtree.body if isinstance(n,ast.FunctionDef) and n.name=='held_risk_report')
        # Only new entry-local module provenance checks differ from frozen report.
        current.body=[n for n in current.body if not (isinstance(n,ast.If) and any(isinstance(x,ast.Raise) and isinstance(x.exc,ast.Call) and x.exc.args and isinstance(x.exc.args[0],ast.Constant) and x.exc.args[0].value=='EXACT_LOCAL_FULL2022_D_REQUIRED' for x in ast.walk(n)))]
        class Rename(ast.NodeTransformer):
            def visit_Import(self,n):
                for a in n.names:
                    if a.name=='expansion':a.name='full_d'
                return n
        self.assertEqual(ast.dump(current),ast.dump(Rename().visit(old)))
        pins=json.loads((EXEC/'DEPENDENCY_PINS.json').read_bytes())
        key='traditional_three_tier_freeze_20261015/annual_reporting.py'
        self.assertEqual(sha256(Path(annual_reporting.__file__).read_bytes()).hexdigest(),pins[key]['SHA256'])
    def test_fake_saved_exposure_overshoot_roundtrip_all_tiers(self):
        guard=sg.SourceOnlyGuard()
        with guard:
            columns=['close_us','nav','free_cash','isolated_balance','gross_weight']+[s+'_signed_weight' for s in full_d.S]
            weights=np.array([[.01,0,0,0,0],[.06,-.02,0,0,0],[.11,.03,0,0,0],[-.16,.04,0,0,0],[.3,-.1,.02,0,0],[-.4,.2,0,-.03,.01]])
            values=np.column_stack((np.arange(1,7)*60_000_000,np.arange(10000,10006),np.full(6,900.),np.full(6,8600.),np.abs(weights).sum(axis=1),weights))
            decisions=np.array([0],dtype=np.int64);cov=np.array([np.eye(5)]);targets=np.array([[.2,.2,.2,.2,.2]])
            receipts=[{'allowed':False,'reason':'CASH_LIMIT','fraction':'0.5'}]
            for tier in ('LOW','MID','HIGH'):
                report=runner.held_risk_report(values,columns,decisions,cov,targets,tier,receipts)
                budget=annual_reporting.g.tier_named(tier).annual_vol_target;forecast=np.sqrt((weights**2).sum(axis=1))
                self.assertEqual(report['forecast_volatility_breach_minutes'],int(np.sum(forecast-budget>annual_reporting.BREACH_NUMERICAL_TOLERANCE)))
                self.assertEqual(report['forecast_annual_volatility_max'],float(forecast.max()))
                self.assertEqual(report['actual_net_signed_weight_min'],float(weights.sum(axis=1).min()))
                self.assertEqual(report['actual_signed_weight_min_by_symbol']['BTCUSDT'],-.4)
                self.assertEqual(report['actual_absolute_weight_max_by_symbol']['ETHUSDT'],.2)
                self.assertEqual(report['minutes_observed_free_cash_below1000'],6)
                self.assertEqual(report['minutes_observed_margin_above8500'],6)
                self.assertTrue(report['nominal_tier_equality_is_not_exact_realized_risk_matching'])
                with tempfile.TemporaryDirectory(prefix='obvious_fake_reporting_') as tmp:
                    p=Path(tmp);(p/'1900').mkdir();np.savez_compressed(p/'MINUTE.npz',values=values,columns=np.array(columns))
                    np.savez_compressed(p/'1900/TARGETS.npz',decision_us=decisions,annual_covariance=cov,STATIC50_MID=targets)
                    raw=(p/'1900/TARGETS.npz').read_bytes();prep=runner.body({'artifacts':{'1900/TARGETS.npz':{'SHA256':sha256(raw).hexdigest()}}})
                    (p/'PREPARATION.json').write_bytes(prep);(p/'GUARD_RECEIPTS.json').write_bytes(runner.body(receipts));(p/'ACTUAL_HELD_RISK_REPORT.json').write_bytes(runner.body(report))
                    result={'summary':dict(NAV=10005.,free_cash=900.,isolated_balance=8600.,gross_weight=float(values[-1,4]))}
                    cell=dict(calendar=[0,6*60_000_000],year=1900,config='STATIC50_MID',tier=tier);receipt=dict(completed_minutes=6,account_stop_us=None)
                    self.assertEqual(runner.validate_saved_risk_report(p,preparation_directory=p,preparation_raw=prep,cell=cell,receipt=receipt,result=result),report)
                    changed=dict(report,forecast_volatility_breach_minutes=0);(p/'ACTUAL_HELD_RISK_REPORT.json').write_bytes(runner.body(changed))
                    with self.assertRaisesRegex(ValueError,'EXACT_ACTUAL_HELD_RISK_REPORT_RECOMPUTATION_REQUIRED'):runner.validate_saved_risk_report(p,preparation_directory=p,preparation_raw=prep,cell=cell,receipt=receipt,result=result)
                FAKE_REPORTS[tier]=report
            guard.checkpoint('FAKE_REPORTING_ONLY_NO_ACCOUNT_OR_PROVIDER')
        GUARD_OBSERVATIONS.append(guard.receipt('PASS_OBSERVED_ZERO_FORBIDDEN_CALLS'))
    def test_legacy_private_GO_deny_read_current_metadata_and_hash_contract(self):
        guard=sg.SourceOnlyGuard()
        with ExitStack() as stack:
            stack.enter_context(patch.object(builtins,'open',op));stack.enter_context(patch.object(Path,'open',pop));stack.enter_context(patch.object(os,'open',oop))
            with guard:
                raw=PREP.read_bytes();prep=entry.validate_preparation_metadata(raw)
                entry.s.require_full_source_pins()
                qualified=entry.s.SourceQualificationBinding.validate(prep['years']['2022']['source_qualification'])
                self.assertEqual(qualified.source_identity,prep['years']['2022']['source_identity'])
                self.assertEqual(entry.code_identity(),prep['code_identity'])
                common=entry._authorization_common(raw,prep)
                self.assertFalse(common['old_private_GO_bodies_required']);self.assertFalse(common['preserved_old_root_GO_is_new_authority'])
                self.assertEqual(common['preserved_evidence_pins'],entry.preserved_evidence_identity())
                self.assertEqual(entry.preserved_evidence_identity(),{})
                # Exact contract and dependency metadata carry no old authority body.
                self.assertEqual(ast.dump(ast.parse(inspect.getsource(entry.preserved_evidence_identity))).count('read_bytes'),0)
                pins=json.loads((EXEC/'DEPENDENCY_PINS.json').read_bytes())
                self.assertFalse(any('GO' in Path(name).name.upper() and Path(name).suffix=='.json' for name in pins))
                self.assertFalse(any('2025' in name for name in pins))
                guard.checkpoint('CURRENT_METADATA_VALIDATION_WITH_LEGACY_AUTHORITY_DENY_READ')
        self.assertEqual(DENIED,[])
        GUARD_OBSERVATIONS.append(guard.receipt('PASS_OBSERVED_ZERO_FORBIDDEN_CALLS'))

if __name__=='__main__':
    began=time.monotonic();result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(PureTests))
    record=dict(status='PASS_DATA_FREE_GENERATED_REPORTING_AND_PORTABILITY' if result.wasSuccessful() else 'FAIL',tests_run=result.testsRun,failures=len(result.failures),errors=len(result.errors),
        fixture='SIX_OBVIOUS_FAKE_MINUTES_YEAR1900_NO_ACCOUNT_NO_PROVIDER_NO_SIMULATOR',actual_source_body_reads=0,actual_2022_accounts_constructed=0,generated_accounts_constructed=0,financial_runs=0,historical_scopes_created=0,provider_calls=0,process_launches=0,
        preparation_metadata_SHA256=sha256(PREP.read_bytes()).hexdigest(),execution_code_identity=entry.code_identity(),test_script_SHA256=sha256(Path(__file__).read_bytes()).hexdigest(),legacy_authority_body_read_attempts=DENIED,observed_read_paths=sorted(set(READS)),no_finance_guard_observations=GUARD_OBSERVATIONS,fake_reports=FAKE_REPORTS,CPU_affinity=sorted(os.sched_getaffinity(0)),wall_seconds=time.monotonic()-began)
    with (HERE/os.environ.get('PURE_TEST_RECEIPT','PURE_TEST_RECEIPT.json')).open('x') as f:json.dump(record,f,indent=2,sort_keys=True);f.write('\n')
    raise SystemExit(not result.wasSuccessful())
