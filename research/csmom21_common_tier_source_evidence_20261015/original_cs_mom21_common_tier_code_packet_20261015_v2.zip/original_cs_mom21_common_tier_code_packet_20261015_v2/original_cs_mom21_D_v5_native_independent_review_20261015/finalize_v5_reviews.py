"""Seal independent code/generated/metadata review; persist no executable GO."""
from datetime import datetime,timezone
from pathlib import Path
import json,re,sys
ROOT=Path(__file__).resolve().parent.parent
OUT=Path(__file__).resolve().parent
PACKAGE=ROOT/'original_cs_mom21_D_20261015_v5'
sys.path.insert(0,str(PACKAGE))
import cs_common as c
import cs_entry as e
import cs_finance_gate as g
import cs_verified_wires as v
import cs_supersession as s
import cs_loader as loader
SOURCE='21e13995b6be9482ee4e20d8e63be6d63396229035f69c963901331713342fce'
CODE='86da3b35cca4d241a638825cb46c75e153833b980f4474be660abd9427b1bad2'
PROBE='15ce21c98c5fa39d4793bcbb8e73938a2c0cd5cb334df3f2eb26c5d852fbfb9d'
PREP='8bb8c74a9c439ed1af4d22228c8243cfa12a40791642869f0031c44809b62c63'
PREPARED='10a1cb1cf64e22a0133ce0525dafab93d2254c2ceb75b84987ed58a881cff34a'
COUNTS={
 'FINAL_GENERATED_NATIVE_TESTS.log':16,'FINAL_PROCESS_CODE_TESTS.log':4,
 'FINAL_SAVED_CODECS_TESTS.log':10,'FINAL_TERMINAL_TAXONOMY_TESTS.log':7,
 'FINAL_SAVED_BINDINGS_TESTS.log':7,'FINAL_DRIVER_FAILCLOSED_TESTS.log':5,
 'FINAL_SAVED_CONTRACT_GUARD_TESTS.log':7,'FINAL_VERIFIED_WIRES_TESTS.log':9,
 'FINAL_SUPERSESSION_TESTS.log':5,'FINAL_NEW_BOUNDARIES_TESTS.log':6,
 'FINAL_FINAL_PROBE_TESTS.log':2,'FINAL_FAILED_ATTEMPT_METADATA_TESTS.log':5,
 'FINAL_MANIFEST_TESTS.log':4,'FINAL_AUTHOR_test_cs_native.log':10,
 'FINAL_AUTHOR_test_cs_finance.log':10,'FINAL_AUTHOR_test_cs_verified.log':5}
for name,count in COUNTS.items():
    text=(OUT/name).read_text();assert re.search(r'Ran '+str(count)+r' tests? in ',text),name
    assert text.rstrip().endswith('OK') and '\nFAILED' not in text,name
modes=('positive','capture_failure','loaded_validation_failure','guard_exit_failure')
cli={}
for mode in modes:
    path=OUT/('FINAL_REAL_CLI_'+mode.upper()+'.log');record=c.exact_object(path.read_bytes().strip())
    assert record['mode']==mode and record['status']=='PASS_REAL_FRESH_CLI_GENERATED_EXECUTABLE_GO_UNCHANGED_GUARD'
    assert all(x==0 for x in record['positive_guard_counters'].values())
    assert record['authority_serialization_negative_counter']==1 and record['token_negative_cases']==7
    for key in ('accounts','providers','claims','historical_scopes','actual_source_reads','actual_source_scopes'):assert record[key]==0
    assert 'worker_claim_recording_storage_callback' in record['seams']
    cli[mode]=record
assert e.code_identity()==SOURCE and g.code_identity()==CODE
manifest=c.exact_object((PACKAGE/'FINANCIAL_CODE_MANIFEST.json').read_bytes())
probe_path=PACKAGE/'GENERATED_POOL_PROBE_001/GENERATED_POOL_PROFILE.json'
probe=c.exact_object(c.exact(probe_path,PROBE,33155))
assert probe['maximum_observed_live_workers']==2 and probe['historical_financial_runs']==0
pin=lambda p:dict(SHA256=c.sha(p.read_bytes()),bytes=p.stat().st_size)
old_path=ROOT/'original_cs_mom21_D_v4_native_independent_review_20261015/INDEPENDENT_NATIVE_REVIEW_RECEIPT.json'
old=c.exact_object(c.exact(old_path,'a3128f12296c1e65a0845d54ab1992af37e17e1450edcb362834a4fe8738c588'))
review=dict(old)
review.update(created_UTC=datetime.now(timezone.utc).isoformat(),review_scope='INDEPENDENT_V5_EXACT_CODE_GENERATED_CLI_AND_FAILED_PREFINANCE_SUPERSESSION_ADMISSION_FIRST6',
    financial_code_manifest_SHA256=CODE,generated_resource_probe_SHA256=PROBE,
    predecessor_native_review_SHA256=c.sha(old_path.read_bytes()),
    predecessor_review_scope_caveat='V4_NATIVE_GENERATED_PASS_DID_NOT_EXERCISE_THE_FAILED_EXECUTABLE_GO_INSIDE_REAL_WORKER_GUARD_PATH;V5_ADDS_REAL_CONTROL_PATH_REGRESSION',
    frozen_financial_code_inventory=manifest['files'],code_dependency_count=len(manifest['dependencies']),
    generated_resource_probe_relative_path=str(probe_path.relative_to(ROOT)),
    generated_resource_probe_evidence={str(p.relative_to(probe_path.parent)):pin(p) for p in sorted(probe_path.parent.rglob('*')) if p.is_file() and p.name!='CONTROLLER_LEASE.lock'},
    observed_probe_peak_aggregate_RSS_bytes=max(row['aggregate_live_RSS_bytes'] for row in probe['observations']),
    real_CLI_generated_GO_guard_integration_reviewed=True,real_CLI_generated_integration_scenarios=cli,
    generated_CLI_mocked_seams=cli['positive']['seams'],full_unmocked_annual_history_executed_by_review=False,
    preverified_binding_is_financial_or_source_scope=False,preverified_binding_immutable_one_use_revoked=True,
    full_pinned_code_inventory_rechecked_inside_guard_without_GO_serialization=True,
    exact_FIRST6_preparation_wrapper_year_cell_artifact_sets_reviewed=True,
    saved_prefinance_phase_chain_bound_to_cell_GO_preparation_code_claim_PID_guard_reviewed=True,
    failed_claim_supersession_packet_SHA256=s.PACKET_SHA,stable_cross_version_claim_registry=s.STABLE_REGISTRY_REL,
    permanent_one_use_failed_claim_consumption_reviewed=True,
    manual_supersession_scope=list(s.FAILED_CELLS),old_claim_rewrite_release_delete_authorized=False,
    retry_or_claim_supersession_authorized_by_this_review=False,
    failed_attempt_evidence=dict(independent_audit_SHA256='c472fac023fb646e5ebf2dcc5829e688ffb7ca0e853461c263936161f53be90f',
        root_exit_binding_SHA256='67378985670e6d157b505af4ac438e30f3e56880f3470c5f0bcb094426dbd3ca',
        root_exit_receipt_SHA256='6a9a0bad0520d9b0e67487dc89afe4e09dcd2d0e2b1383b7d109b656aa1a89d4',root_actual_exit_code=1,
        failed_root_GO_SHA256='44fb51cfc989a3499105e05144c855ead4840d775e23812a59250a24ed99d8ef',
        LOW_basis='OBSERVED_SAVED_FAILURE_TRACE_AND_GUARD_BEFORE_CAPTURE_AND_ACCOUNT',
        LOW_financial_GO_writes_attempts=1,LOW_financial_GO_persisted=False,
        MID_basis='PINNED_MANDATORY_PRE_FINANCE_CONTROL_FLOW_AND_PARENT_WORKER_TEARDOWN_INFERENCE',
        MID_observed_guard_counters_available=False,economic_HALT=False,completed_financial_case_results=0),
    runtime_read_classification=pin(PACKAGE/'RUNTIME_READ_CLASSIFICATION.json'),
    private_local_recovery_metadata_bodies_required=True,fresh_GO_alone_sufficient_for_local_recovery=False,
    public_fresh_genesis_reproduction_distinct_from_local_failed_claim_recovery=True,
    reviewer_resources=dict(CPU_affinity=[4],numerical_pools=1,single_process_generated_unit_tests=True,
        fresh_generated_CLI_test_processes=4,actual_financial_processes_launched=0,final_probe_saved_evidence_only=True),
    generated_verification=dict(independent_code_generated_metadata_tests=87,author_tests_independently_rerun=25,total_unit_tests=112,
        tests_by_log=COUNTS,real_fresh_CLI_scenarios=4,failures=0,errors=0,
        generated_native_calendar_namespace='INTERNALLY_SEALED_1971_ONLY',
        fake_storage_calendar='INVENTED_2023_ARRAYS_NO_ACTUAL_SOURCE_SCOPE_PROVIDER_OR_ACCOUNT',
        native40_authoritative=True,raw100_residual_retained_unchanged=True,tolerance_or_epsilon_used=False),
    findings_closed=old['findings_closed']+[
        'EXACT_EXECUTABLE_FINANCIAL_GO_VERIFIED_BEFORE_UNCHANGED_SOURCE_GUARD',
        'IMMUTABLE_EXTERNALLY_BOUND_CLAIM_CELL_CODE_PREPARATION_WIRES_CONSUMED_ONCE_WITHOUT_SERIALIZATION',
        'WRONG_CONFLICTING_REPLAYED_REVOKED_BINDINGS_AND_ALL_SOURCE_FAILURE_PATHS_REVOKE_EPHEMERALS',
        'EXACT_FAILED_LOW_MID_ONLY_APPEND_ONLY_ONE_USE_SUPERSESSION_UNDER_UNCHANGED_V4_GLOBAL_LEASE',
        'REAL_MAIN_CASE_LOADER_EXECUTABLE_GO_GUARD_POSITIVE_AND_THREE_FAILURE_REGRESSIONS',
        'EXACT_FIRST6_WRAPPER_ARTIFACT_SCOPE_AND_SAVED_PREFINANCE_PHASE_CHECKS'],
    actual_preparation_metadata_read=True,actual_failed_claim_and_failure_receipt_metadata_read=True,
    evidence={p.name:pin(p) for p in sorted(OUT.iterdir()) if p.is_file() and p.suffix in ('.py','.md','.log')})
raw=(json.dumps(review,sort_keys=True,indent=2,allow_nan=False)+'\n').encode();native_sha=c.sha(raw)
g.native_review(raw,native_sha)
with (OUT/'INDEPENDENT_NATIVE_REVIEW_RECEIPT.json').open('xb') as stream:stream.write(raw)
# Combine external sealed source/prepared/native domains using JSON metadata only.
prep_path=ROOT/'original_cs_mom21_D_20261015_v4/source_attempts/FIRST6_attempt001/PREPARATION.json'
prep_raw=c.exact(prep_path,PREP,28889);prep=v.exact_preparation_shape(prep_raw)
prepared_path=ROOT/'original_cs_mom21_D_v4_independent_review_20261015/INDEPENDENT_PREPARED_TARGET_REVIEW_RECEIPT.json'
prepared_raw=c.exact(prepared_path,PREPARED)
g.prepared_review(prep_raw,prepared_raw,PREPARED)
combined=dict(schema=g.REVIEW_SCHEMA,status='PASS',created_UTC=datetime.now(timezone.utc).isoformat(),
    review_scope='COMBINED_EXACT_V5_CODE_NATIVE_GENERATED_FAILED_PREFINANCE_SUPERSESSION_AND_SEALED_V4_PREPARED_REVIEW_METADATA_ONLY',
    source_code_manifest_SHA256=SOURCE,financial_code_manifest_SHA256=CODE,scope_manifest_SHA256=e.manifest_sha(),
    source_contract_map_SHA256=e.contract_sha(),preparation_SHA256=PREP,tranche=e.FIRST6,ordered_cells=list(e.tranche_cells(e.FIRST6)),
    source_stage_GO_SHA256=prep['source_stage_GO_SHA256'],source_independent_review_SHA256=prep['source_review_SHA256'],
    prepared_source_target_review_SHA256=PREPARED,native_generated_review_SHA256=native_sha,
    old_D_GO_reused_as_authority=False,native_financial_gate_reviewed=True,financial_execution_authorized=False,
    historical_execution_authorized=False,account_construction_authorized=False,provider_iteration_authorized=False,
    real_CLI_generated_GO_guard_integration_reviewed=True,failed_claim_supersession_packet_SHA256=s.PACKET_SHA,
    stable_cross_version_claim_registry=s.STABLE_REGISTRY_REL,permanent_one_use_failed_claim_consumption_reviewed=True,
    retry_or_claim_supersession_authorized_by_this_review=False,old_claim_rewrite_release_delete_authorized=False,
    fresh_separate_external_root_financial_GO_required=True,source_and_target_arrays_regenerated=False,
    actual_source_or_target_bodies_read_by_combined_reviewer=False,
    actual_prepared_targets_independently_audited_in_separate_receipt=True,
    per_cell_input_binding_SHA256={k:row['input_binding_SHA256'] for k,row in prep['cells'].items()},
    per_year_array_raw_SHA256={k:row['array_raw_SHA256'] for k,row in prep['years'].items()},
    generated_resource_probe_SHA256=PROBE,worker_CPUs=[4,5],maximum_observed_live_workers=2,
    native_venue_liquidation_funding_publication_or_annual_resource_envelope_certified=False,
    actual_CS_gap_impacts='PENDING_SEPARATE_FUTURE_SAVED_EXECUTION_AUDIT_NOT_INHERITED_FROM_D',remaining9_admission_enabled=False,
    metadata_validation=dict(exact_frozen_FIRST6_preparation_metadata=True,separate_prepared_review_validated=True,
        separate_native_review_validated=True,combined_gate_validated_with_in_memory_hypothetical_policy=True,
        hypothetical_GO_body_persisted=False,source_capture_calls=0,actual_provider_calls=0,actual_account_constructions=0,
        actual_account_advances=0,historical_or_financial_scopes_minted=0,actual_claims_or_leases_created=0,real_financial_GO_files_written=0),
    evidence=dict(preparation_metadata=dict(path=str(prep_path.relative_to(ROOT)),**pin(prep_path)),
        prepared_review=dict(path=str(prepared_path.relative_to(ROOT)),**pin(prepared_path)),
        native_review=dict(path=str((OUT/'INDEPENDENT_NATIVE_REVIEW_RECEIPT.json').relative_to(ROOT)),SHA256=native_sha,bytes=len(raw)),
        failed_supersession_packet=dict(path=str((PACKAGE/'FAILED_ATTEMPT_SUPERSESSION_PACKET.json').relative_to(ROOT)),**pin(PACKAGE/'FAILED_ATTEMPT_SUPERSESSION_PACKET.json'))))
combined_raw=(json.dumps(combined,sort_keys=True,indent=2,allow_nan=False)+'\n').encode();combined_sha=c.sha(combined_raw)
hypothetical=c.canonical(g.policy(prep_raw,combined_sha,PREPARED,native_sha,[4,5]))
result=g.validate(prep_raw,hypothetical,c.sha(hypothetical),combined_raw,combined_sha,prepared_raw,PREPARED,raw,native_sha)
assert result['financial_code_manifest_SHA256']==CODE
assert not e._ACTIVE_SOURCE and not e._ACTIVE_FINANCIAL and not e._ACTIVE_RECORDING and not v._LIVE and not loader._LIVE
with (OUT/'INDEPENDENT_FINANCIAL_ADMISSION_REVIEW_RECEIPT.json').open('xb') as stream:stream.write(combined_raw)
validation=dict(status='PASS_EXACT_FINAL_V5_NATIVE_AND_COMBINED_METADATA_ADMISSION_NO_FINANCIAL_AUTHORITY',
    financial_code_manifest_SHA256=CODE,source_code_manifest_SHA256=SOURCE,generated_probe_SHA256=PROBE,
    native_review=dict(path=str((OUT/'INDEPENDENT_NATIVE_REVIEW_RECEIPT.json').relative_to(ROOT)),SHA256=native_sha,bytes=len(raw)),
    combined_review=dict(path=str((OUT/'INDEPENDENT_FINANCIAL_ADMISSION_REVIEW_RECEIPT.json').relative_to(ROOT)),SHA256=combined_sha,bytes=len(combined_raw)),
    prepared_review_SHA256=PREPARED,gate_validate='PASS_IN_MEMORY_HYPOTHETICAL_POLICY_ONLY',
    financial_execution_authorized=False,real_financial_GO_files_written=0,total_unit_tests=112,real_CLI_scenarios=4)
with (OUT/'FINAL_ADMISSION_VALIDATION.json').open('x') as stream:json.dump(validation,stream,sort_keys=True,indent=2);stream.write('\n')
print(json.dumps(validation,sort_keys=True))
