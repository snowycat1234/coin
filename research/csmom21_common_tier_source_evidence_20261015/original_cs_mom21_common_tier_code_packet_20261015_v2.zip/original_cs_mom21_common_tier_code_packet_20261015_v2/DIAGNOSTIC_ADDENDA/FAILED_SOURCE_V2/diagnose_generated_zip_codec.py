"""Fresh-process generated ZIP codec diagnosis. No actual source bodies/scopes."""
from io import BytesIO
from pathlib import Path
import importlib
import json,sys,traceback,zipfile
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'original_cs_mom21_D_20261015_v2'))
import cs_source_bridge as bridge
from cs_source_guard import SourceOnlyGuard
for name in sys.argv[1:]:importlib.import_module(name)
stream=BytesIO()
row=['1640995200000','10','11','9','10','5','1640995259999','50','1','0','0','0']
with zipfile.ZipFile(stream,'w',zipfile.ZIP_DEFLATED) as z:
    z.writestr('BTCUSDT-1m-2022-01.csv',b'\xef\xbb\xbf'+','.join(row).encode('utf-8')+b'\n')
raw=stream.getvalue();assert raw[6:8]==b'\x00\x00'  # ASCII ZIP local-header flag0, no pre-guard ZIP read.
guard=SourceOnlyGuard()
loaded_before=[n for n in ('encodings.cp437','encodings.utf_8_sig') if n in sys.modules]
try:
    with guard:
        parsed,proof=bridge.parse_original_zip(raw,symbol='BTCUSDT',period='2022-01',family='klines')
        guard.checkpoint('GENERATED_ASCII_NAME_FLAG0_ZIP_PARSED')
except BaseException as exc:
    traceback.print_exception(exc)
    print(json.dumps(dict(status='EXPECTED_DIAGNOSTIC_STOP',preloads=sys.argv[1:],loaded_before=loaded_before,attempts=guard.attempts,targets=guard.targets)))
else:
    print(json.dumps(dict(status='PASS_GENERATED_ZIP',preloads=sys.argv[1:],loaded_before=loaded_before,parsed_rows=len(parsed),attempts=guard.attempts)))
