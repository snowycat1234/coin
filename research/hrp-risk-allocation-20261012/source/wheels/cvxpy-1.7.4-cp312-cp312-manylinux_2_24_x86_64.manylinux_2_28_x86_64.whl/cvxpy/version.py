
# THIS FILE IS GENERATED FROM CVXPY SETUP.PY
short_version = '1.7.4'
version = '1.7.4'
full_version = '1.7.4'
git_revision = '4c5ec49'
commit_count = '0'
release = True
if not release:
    version = full_version
