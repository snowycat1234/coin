"""Synthetic public-API boundary tests only. No historical data is loaded."""
from copy import deepcopy
from decimal import Decimal as D
import json
from pathlib import Path
import unittest

from continuation import BoundedContinuationAccount as Account, MINUTE as M
from vendor_quant.perpetual_account import USDTLinearPerpetualAccount as Base, InstrumentProfile, PerpetualConfig

S = ('BTCUSDT','ETHUSDT','SOLUSDT','XRPUSDT','DOGEUSDT')


def marks(a, at, price='100', *, quality=None):
    a.update_marks(at, {s:dict(price=price if not isinstance(price,dict) else price[s], close_us=at, available_us=at) for s in a.symbols},
                   **({'quality':quality} if quality is not None else {}))


def fresh(mode='CONDITIONAL_COLLATERAL_FORFEITURE', *, symbols=('BTCUSDT',), enabled=True, **kw):
    kw.setdefault('instrument_profiles',{s:InstrumentProfile() for s in symbols})
    a=Account(generated_scope='GENERATED_FAKE_ORIGIN_ONLY', settlement_mode=mode,
        policy_variant=kw.pop('policy_variant','TOPUP_THEN_CONTINUE' if enabled else 'NATIVE_STOP_REFERENCE'), symbols=symbols, **kw)
    marks(a,0);marks(a,M)
    return a


def opened(mode='CONDITIONAL_COLLATERAL_FORFEITURE', **kw):
    a=fresh(mode,**kw)
    a.execute_fill(a.symbols[0],'SELL','10',M+1,0,'open',execution_mid_price='100',quote_available_us=M)
    return a


def quote(open_us=3*M, price='150', volume='1e10'):
    return dict(open_us=open_us,open_price=price,quote_close_us=open_us,
                quote_available_us=open_us,quote_volume=volume,source_scope='GENERATED_COMPLETED_PRIOR_MINUTE')


class Tests(unittest.TestCase):
    def test_generated_scope_only(self):
        with self.assertRaisesRegex(ValueError,'GENERATED_ONLY'):
            Account(generated_scope='2024',settlement_mode='UNKNOWN_UNSETTLED')

    def test_explicit_settlement_required(self):
        with self.assertRaises(ValueError):
            Account(generated_scope='GENERATED_FAKE_ORIGIN_ONLY',settlement_mode='NATIVE_CERTIFIED')

    def test_native_finance_inherited(self):
        self.assertIs(Account._leg,Base._leg)
        self.assertIs(Account.apply_funding,Base.apply_funding)

    def test_disabled_baseline_golden_unchanged(self):
        base=Base(symbols=('BTCUSDT',),closing_min_notional_exempt=True)
        candidate=fresh(enabled=False)
        marks(base,0);marks(base,M)
        for a in (base,candidate):
            a.execute_fill('BTCUSDT','SELL','10',M+1,0,'open',execution_mid_price='100',quote_available_us=M)
            marks(a,2*M)
            a.execute_fill('BTCUSDT','BUY','10',2*M+1,M,'close',execution_mid_price='100',quote_available_us=2*M,reduce_only=True)
        self.assertEqual(base.nav(),D('9997.300000'))
        for field in ('free_cash','fees','execution_cost','realized_PnL','funding_cash','trades','positions','unpaid_liability','status'):
            self.assertEqual(getattr(base,field),getattr(candidate,field),field)
        self.assertEqual(candidate.transfer_journal,[])
        self.assertEqual(candidate.settlement_journal,[])

    def test_native_halt_stays_halted_no_retro_topup(self):
        a=opened('UNKNOWN_UNSETTLED');marks(a,2*M,'210')
        cash=a.free_cash;position=deepcopy(a.positions['BTCUSDT'])
        self.assertIn(a.status,{'BANKRUPT_HALT','LIQUIDATION_REQUIRED_HALT'})
        self.assertEqual(a.monitor('halt',2*M)['status'],'CASH_WATCH_UNRESOLVED')
        self.assertEqual(a.free_cash,cash);self.assertEqual(a.positions['BTCUSDT'],position)
        self.assertFalse(a.transfer_journal)

    def test_topup_conserves_NAV_not_PnL_or_quantity(self):
        a=opened();marks(a,2*M,'150')
        before=a.nav();q=a.positions['BTCUSDT'].quantity
        totals=(a.fees,a.execution_cost,a.realized_PnL,a.funding_cash)
        r=a.monitor('healthy',2*M)
        self.assertEqual(len(a.transfer_journal),1)
        self.assertEqual(a.nav(),before);self.assertEqual(a.positions['BTCUSDT'].quantity,q)
        self.assertEqual(totals,(a.fees,a.execution_cost,a.realized_PnL,a.funding_cash))
        self.assertEqual(a.free_cash,D('8499.45044000'))
        self.assertFalse(a.pending_exits)

    def test_transfer_limits_atomic(self):
        a=opened();before=a.snapshot()
        with self.assertRaises(ValueError):a._transfer('BTCUSDT',D('9000'),M+1,'bad')
        self.assertEqual(a.snapshot(),before)

    def test_jump_settles_position_once_no_cash_credit(self):
        a=opened();cash=a.free_cash;marks(a,2*M,'210')
        self.assertEqual(a.positions['BTCUSDT'].quantity,0)
        self.assertFalse(a.economic_report()['paid_flat'])
        self.assertTrue(a.economic_report()['settled_flat_under_declared_model'])
        self.assertEqual(a.free_cash,cash)
        self.assertEqual(len(a.settlement_journal),1)
        self.assertGreater(D(a.settlement_journal[0]['decimal_strings']['conditional_overshoot_absorption']),0)
        self.assertEqual(D(a.economic_report()['decimal_strings']['accounting_bridge_error_USDT']),0)
        marks(a,2*M,'210');self.assertEqual(len(a.settlement_journal),1)
        self.assertNotIn(a.status,{'BANKRUPT_HALT','LIQUIDATION_REQUIRED_HALT'})

    def test_positive_equity_forfeiture_honest(self):
        a=opened();marks(a,2*M,'199')
        self.assertEqual(a.positions['BTCUSDT'].quantity,0)
        row=a.settlement_journal[0]['decimal_strings']
        self.assertGreater(D(row['conditional_positive_residual_forfeited']),0)
        self.assertEqual(D(row['free_cash_credit']),0)

    def test_stale_mark_blocks_topup_and_new_increase(self):
        a=opened();a.clock_us=3*M
        r=a.monitor('stale',3*M)
        self.assertFalse(a.transfer_journal);self.assertEqual(r['status'],'REDUCE_ONLY_MONITOR')
        with self.assertRaisesRegex(ValueError,'FAIL_CLOSED'):
            a.execute_fill('BTCUSDT','SELL','1',3*M+1,M,'inc',execution_mid_price='100',quote_available_us=3*M)

    def test_unknown_derived_marks_fail_closed(self):
        a=opened();marks(a,2*M,'150',quality={'BTCUSDT':'UNKNOWN_OR_DERIVED'})
        a.monitor('unknown',2*M)
        self.assertFalse(a.transfer_journal);self.assertTrue(a.pending_exits)

    def test_insufficient_budget_then_paid_partial_and_full_close(self):
        a=opened();a.apply_funding('BTCUSDT','drain',2*M,'-7.95',2*M)
        marks(a,2*M,'150');a.monitor('lowcash',2*M)
        self.assertEqual(a.free_cash,1000);self.assertTrue(a.pending_exits)
        self.assertLess(sum(D(r['decimal_strings']['amount']) for r in a.transfer_journal),D('500.8'))
        # Pro-rata release does not justify declaring the remainder safe.
        marks(a,3*M,'150')
        partial=a.attempt_reductions('part',3*M+1,{'BTCUSDT':quote(volume='150000')})
        self.assertEqual(abs(a.positions['BTCUSDT'].quantity),9)
        self.assertTrue(a.pending_exits);self.assertGreater(a.fees,0)
        marks(a,4*M,'150')
        a.attempt_reductions('finish',4*M+1,{'BTCUSDT':quote(4*M)})
        self.assertEqual(a.positions['BTCUSDT'].quantity,0);self.assertFalse(a.pending_exits)
        self.assertEqual(a.unpaid_liability,0);self.assertTrue(a.economic_report()['paid_flat'])
        self.assertEqual(D(a.summary()['decimal_strings']['accounting_bridge_error_USDT']),0)

    def test_fill_latency_no_instant_close(self):
        a=opened();a.pending_exits['BTCUSDT']=dict(signal_us=2*M,reason='TEST')
        self.assertEqual(a.attempt_reductions('early',2*M+1,{'BTCUSDT':quote(2*M)})['fills'],[])
        self.assertEqual(abs(a.positions['BTCUSDT'].quantity),10)

    def test_capacity_shared_no_duplicate_spend(self):
        a=opened();a.pending_exits['BTCUSDT']=dict(signal_us=M,reason='TEST');marks(a,2*M)
        a.consume_capacity('BTCUSDT',2*M,D('.6'),fill_id='other')
        a.consume_capacity('BTCUSDT',2*M,D('.6'),fill_id='other')
        q=quote(2*M,'100','100000') # raw bucket 1 base
        a.attempt_reductions('c1',2*M+1,{'BTCUSDT':q})
        self.assertEqual(abs(a.positions['BTCUSDT'].quantity),D('9.6'))
        a.attempt_reductions('c2',2*M+1,{'BTCUSDT':q})
        self.assertEqual(abs(a.positions['BTCUSDT'].quantity),D('9.6'))

    def test_invalid_quote_rejected_no_fill(self):
        a=opened();a.pending_exits['BTCUSDT']=dict(signal_us=M,reason='TEST');marks(a,2*M)
        q=quote(2*M);q['quote_available_us']=2*M+1
        with self.assertRaisesRegex(ValueError,'CAUSAL'):
            a.attempt_reductions('bad',2*M+1,{'BTCUSDT':q})
        self.assertEqual(len(a.trades),1)

    def test_duplicate_monitor_and_conflict(self):
        a=opened();marks(a,2*M,'150');r=a.monitor('m',2*M);snap=a.snapshot()
        self.assertEqual(a.monitor('m',2*M),r);self.assertEqual(a.snapshot(),snap)
        with self.assertRaisesRegex(ValueError,'CONFLICTING'):
            a.monitor('m',M)

    def test_duplicate_reduce_receipt_no_second_payment(self):
        a=opened();a.pending_exits['BTCUSDT']=dict(signal_us=M,reason='TEST');marks(a,2*M)
        q={'BTCUSDT':quote(2*M,'100')};r=a.attempt_reductions('exit',2*M+1,q);snap=a.snapshot()
        self.assertEqual(a.attempt_reductions('exit',2*M+1,q),r);self.assertEqual(a.snapshot(),snap)

    def test_native_fill_duplicate_delegated_before_new_gate(self):
        a=opened();a.pending_exits['BTCUSDT']=dict(signal_us=M,reason='TEST')
        r=a.execute_fill('BTCUSDT','SELL','10',M+1,0,'open',execution_mid_price='100',quote_available_us=M)
        self.assertEqual(r['status'],'FILLED');self.assertEqual(len(a.trades),1)

    def test_five_asset_order_and_budget(self):
        a=fresh(symbols=S)
        for i,s in enumerate(S):
            a.execute_fill(s,'SELL','10',M+1+i,0,'o'+s,execution_mid_price='100',quote_available_us=M)
        marks(a,2*M,'150');a.monitor('five',2*M)
        self.assertEqual([r['symbol'] for r in a.transfer_journal],list(S))
        self.assertGreaterEqual(a.free_cash,1000)
        self.assertLessEqual(sum(p.isolated_balance for p in a.positions.values()),8500)
        self.assertEqual(sum(abs(p.quantity) for p in a.positions.values()),50)

    def test_real_unpaid_liability_never_forgiven(self):
        a=opened();a.apply_funding('BTCUSDT','bankrupt',2*M,'-20',2*M)
        liability=a.unpaid_liability;self.assertGreater(liability,0)
        self.assertEqual(a.status,'BANKRUPT_HALT');self.assertEqual(a.settlement_journal,[])
        a._risk('again');self.assertEqual(a.unpaid_liability,liability)
        self.assertEqual(a.status,'BANKRUPT_HALT')

    def test_full_actual_lot_close_without_increase(self):
        a=opened();p=a.positions['BTCUSDT'];p.quantity=D('-9.9995')
        # Synthetic prior actual lot, later assumed profile coarsens to .001.
        a.instrument_profiles={'BTCUSDT':InstrumentProfile(quantity_step=D('.001'))}
        marks(a,2*M)
        a.execute_fill('BTCUSDT','BUY','9.9995',2*M+1,M,'exact',execution_mid_price='100',quote_available_us=2*M,
            available_quantity='9.9995',reduce_only=True)
        self.assertEqual(p.quantity,0)

    def test_fresh_signal_required_after_liquidation(self):
        a=opened();marks(a,2*M,'210')
        with self.assertRaisesRegex(ValueError,'FRESH_NORMAL'):
            a.execute_fill('BTCUSDT','BUY','1',3*M+1,2*M,'old',execution_mid_price='210',quote_available_us=3*M)

    def test_unadmitted_headroom_cannot_switch_policy(self):
        a=opened();before=a.snapshot()
        with self.assertRaisesRegex(ValueError,'NOT_ADMITTED'):
            a.monitor('hr',a.clock_us,headroom_features={})
        self.assertEqual(a.snapshot(),before)

    def test_snapshot_is_evidence_only_no_resume(self):
        a=opened();self.assertIs(a.snapshot()['snapshot_recovery_certified'],False)
        with self.assertRaisesRegex(NotImplementedError,'NOT_CERTIFIED'):
            Account.from_snapshot(a.snapshot())

    def test_replay_from_genesis_deterministic(self):
        def run():
            a=opened();marks(a,2*M,'150');a.monitor('m',2*M);marks(a,3*M,'300')
            return a.snapshot(),a.economic_report()
        self.assertEqual(run(),run())

    def test_unknown_breach_must_not_claim_settled(self):
        a=opened();marks(a,2*M,'210',quality={'BTCUSDT':'UNKNOWN_OR_DERIVED'})
        self.assertFalse(a.settlement_journal)
        self.assertEqual(a.status,'BANKRUPT_HALT')
        self.assertNotEqual(a.positions['BTCUSDT'].quantity,0)

    def test_capital_ceiling_binding_before_cash_floor(self):
        a=fresh(symbols=S)
        for i,s in enumerate(S):
            a.execute_fill(s,'SELL','10',M+1+i,0,'o'+s,execution_mid_price='100',quote_available_us=M)
        # Extra equity buffer requires more than total isolated cap allows.
        marks(a,2*M,'171');a.monitor('ceiling',2*M)
        self.assertEqual(sum(p.isolated_balance for p in a.positions.values()),8500)
        self.assertGreater(a.free_cash,1000)
        self.assertTrue(a.pending_exits)

    def test_terminal_must_actually_pay_close(self):
        a=opened();marks(a,2*M)
        a.request_terminal_exit('terminal',2*M)
        self.assertFalse(a.economic_report()['paid_flat'])
        marks(a,3*M)
        a.attempt_reductions('terminalclose',3*M+1,{'BTCUSDT':quote(3*M,'100')})
        self.assertTrue(a.economic_report()['paid_flat'])
        self.assertGreater(a.fees,D('1'))

    def test_expired_order_cannot_fill_until_new_latency(self):
        a=opened();marks(a,10*M)
        a.pending_exits['BTCUSDT']=dict(signal_us=M,reason='TEST')
        a.attempt_reductions('expired',10*M+1,{'BTCUSDT':quote(10*M,'100')})
        self.assertEqual(abs(a.positions['BTCUSDT'].quantity),10)
        self.assertEqual(a.pending_exits['BTCUSDT']['renewals'],1)
        a.attempt_reductions('tooearly',11*M+1,{'BTCUSDT':quote(11*M,'100')})
        self.assertEqual(abs(a.positions['BTCUSDT'].quantity),10)
        marks(a,12*M)
        a.attempt_reductions('renewed',12*M+1,{'BTCUSDT':quote(12*M,'100')})
        self.assertEqual(a.positions['BTCUSDT'].quantity,0)

    def test_invalid_later_symbol_quote_cannot_partially_mutate_batch(self):
        a=fresh(symbols=('BTCUSDT','ETHUSDT'))
        for i,s in enumerate(a.symbols):
            a.execute_fill(s,'SELL','10',M+1+i,0,'o'+s,execution_mid_price='100',quote_available_us=M)
        marks(a,2*M)
        a.request_terminal_exit('terminal',2*M)
        marks(a,3*M)
        quotes={s:quote(3*M,'100') for s in a.symbols}
        quotes['ETHUSDT']['open_price']='nan'
        before=a.snapshot()
        with self.assertRaises(ValueError):
            a.attempt_reductions('invalidbatch',3*M+1,quotes)
        self.assertEqual(a.snapshot(),before)

    def test_policy_modes_are_readonly_and_features_cannot_switch_variant(self):
        a=opened()
        with self.assertRaises(AttributeError): a.settlement_mode='UNKNOWN_UNSETTLED'
        with self.assertRaises(AttributeError): a.policy_variant='CONTINUE_ONLY'
        with self.assertRaisesRegex(ValueError,'NOT_ADMITTED'):
            a.monitor('switch',a.clock_us,headroom_features={})

    def test_continue_only_settles_without_topup(self):
        a=opened(policy_variant='CONTINUE_ONLY');marks(a,2*M,'150');a.monitor('no-topup',2*M)
        self.assertFalse(a.transfer_journal)
        marks(a,3*M,'210')
        self.assertEqual(len(a.settlement_journal),1)
        self.assertNotIn(a.status,{'BANKRUPT_HALT','LIQUIDATION_REQUIRED_HALT'})
        self.assertEqual(D(a.settlement_journal[0]['decimal_strings']['value_ledger_error']),0)

    def test_below_cash_floor_keeps_monitor_clock_alive(self):
        a=fresh();a.free_cash=D('999')
        self.assertEqual(a.mode(),'CASH_ONLY_MONITOR')
        marks(a,2*M)
        self.assertEqual(a.clock_us,2*M)
        self.assertNotIn(a.status,{'BANKRUPT_HALT','LIQUIDATION_REQUIRED_HALT'})

    def test_transfer_primitive_clock_and_idempotency(self):
        a=opened();marks(a,2*M,'150')
        before=a.snapshot()
        with self.assertRaisesRegex(ValueError,'CURRENT_NATIVE_CLOCK'):
            a._transfer('BTCUSDT','1',3*M-1,'future')
        self.assertEqual(a.snapshot(),before)
        r=a._transfer('BTCUSDT','1',2*M,'once');after=a.snapshot()
        self.assertEqual(a._transfer('BTCUSDT','1',2*M,'once'),r)
        self.assertEqual(a.snapshot(),after)
        with self.assertRaisesRegex(ValueError,'CONFLICTING_TRANSFER'):
            a._transfer('BTCUSDT','2',2*M,'once')

    def test_pre_crossing_transfer_survives_later_gap_without_rewind(self):
        a=opened();marks(a,2*M,'150');a.monitor('beforejump',2*M)
        marks(a,3*M,'210')
        self.assertEqual(abs(a.positions['BTCUSDT'].quantity),10)
        self.assertFalse(a.settlement_journal)
        self.assertEqual(len(a.transfer_journal),1)

    def test_reference_mode_retains_exact_native_stop(self):
        a=opened(policy_variant='NATIVE_STOP_REFERENCE');marks(a,2*M,'210')
        self.assertEqual(a.status,'BANKRUPT_HALT')
        self.assertFalse(a.transfer_journal);self.assertFalse(a.settlement_journal)

    def test_proportional_partial_close_does_not_improve_isolated_equity_value(self):
        a=opened();marks(a,2*M,'150');a.monitor('topup',2*M)
        p=a.positions['BTCUSDT'];before_e=p.isolated_balance+p.quantity*(D(150)-p.entry_price)
        before_value=abs(p.quantity)*D(150)
        marks(a,3*M,'150')
        a.execute_fill('BTCUSDT','BUY','1',3*M+1,2*M,'partial',execution_mid_price='150',
            quote_available_us=3*M,available_quantity='1',reduce_only=True)
        after_e=p.isolated_balance+p.quantity*(D(150)-p.entry_price)
        self.assertEqual(before_e*abs(p.quantity)*D(150),after_e*before_value)

    def test_stress43_native_golden_unchanged(self):
        cfg=PerpetualConfig(half_spread_bps='8',slippage_bps='8')
        a=fresh(enabled=False,config=cfg)
        a.execute_fill('BTCUSDT','SELL','10',M+1,0,'open',execution_mid_price='100',quote_available_us=M)
        marks(a,2*M)
        a.execute_fill('BTCUSDT','BUY','10',2*M+1,M,'close',execution_mid_price='100',quote_available_us=2*M,reduce_only=True)
        self.assertEqual(a.nav(),D('9995.7'))

    def test_policy_events_preserve_global_chronological_clock(self):
        a=opened()
        with self.assertRaisesRegex(ValueError,'CURRENT_NATIVE_CLOCK'):
            a.request_terminal_exit('future',5*M)
        a.attempt_reductions('noquote',5*M+1,{})
        self.assertEqual(a.clock_us,5*M+1)
        with self.assertRaisesRegex(ValueError,'chronological'):
            marks(a,2*M)

    def test_policy_fill_id_collision_rejects_before_any_batch_fill(self):
        a=fresh(symbols=('BTCUSDT','ETHUSDT'))
        for i,s in enumerate(a.symbols):
            a.execute_fill(s,'SELL','10',M+1+i,0,'batch:'+s if s=='ETHUSDT' else 'openBTC',
                execution_mid_price='100',quote_available_us=M)
        marks(a,2*M);a.request_terminal_exit('terminal',2*M);marks(a,3*M)
        before=a.snapshot()
        with self.assertRaisesRegex(ValueError,'WHOLE_BATCH'):
            a.attempt_reductions('batch',3*M+1,{s:quote(3*M,'100') for s in a.symbols})
        self.assertEqual(a.snapshot(),before)

    def test_manual_preview_fork_keeps_all_new_state_independent(self):
        a=opened();marks(a,2*M,'150');a.monitor('topup',2*M)
        a.consume_capacity('BTCUSDT',3*M,'1',fill_id='capacity')
        a.request_terminal_exit('terminal',2*M)
        before=a.snapshot();clone=a.fork_for_preview()
        self.assertEqual(clone.snapshot(),before)
        marks(clone,3*M,'300')
        self.assertTrue(clone.settlement_journal)
        self.assertEqual(a.snapshot(),before)
        self.assertFalse(a.settlement_journal)
        self.assertIsNot(clone.transfer_journal,a.transfer_journal)
        self.assertIsNot(clone.pending_exits,a.pending_exits)
        self.assertIsNot(clone.capacity_used,a.capacity_used)
        self.assertIsNot(clone.operation_ids,a.operation_ids)
        self.assertIsNot(clone.blocked_signals,a.blocked_signals)

    def test_default_reuses_exact_frozen_five_asset_quantity_profile(self):
        a=Account(generated_scope='GENERATED_FAKE_ORIGIN_ONLY',settlement_mode='CONDITIONAL_COLLATERAL_FORFEITURE',symbols=S)
        expected={s:D(q) for s,q in zip(S,('.001','.01','1','100','1000'))}
        self.assertEqual({s:a.instrument_profiles[s].quantity_step for s in S},expected)
        prices=dict(zip(S,map(D,('50000','2000','20','.5','.05'))))
        marks(a,0,prices);marks(a,M,prices)
        for i,s in enumerate(S):
            a.execute_fill(s,'SELL',str(expected[s]),M+1+i,0,'default'+s,
                execution_mid_price=str(prices[s]),quote_available_us=M)
        before={s:p.quantity for s,p in a.positions.items()}
        marks(a,2*M,{s:str(v*D('1.5')) for s,v in prices.items()})
        a.monitor('coarse',2*M)
        self.assertEqual({s:p.quantity for s,p in a.positions.items()},before)
        self.assertEqual(len(a.transfer_journal),5)
        self.assertEqual(a.contract_metadata()['quantity_profile_binding'],'FROZEN_COARSE_RESEARCH_PROFILE')

    def test_explicit_none_capacity_preserves_native_close_contract(self):
        a=opened();marks(a,2*M)
        r=a.execute_fill('BTCUSDT','BUY','10',2*M+1,M,'none-close',execution_mid_price='100',
            quote_available_us=2*M,available_quantity=None,reduce_only=True)
        self.assertEqual(r['status'],'FILLED');self.assertEqual(a.positions['BTCUSDT'].quantity,0)

    def test_positive_NAV_with_unpaid_debt_still_blocks_settlement(self):
        a=fresh(symbols=('BTCUSDT','ETHUSDT'))
        for i,s in enumerate(a.symbols):
            a.execute_fill(s,'SELL','10',M+1+i,0,'open'+s,execution_mid_price='100',quote_available_us=M)
        a.apply_funding('BTCUSDT','deficit',2*M,'-9.5',2*M)
        self.assertGreater(a.unpaid_liability,0);self.assertGreater(a.nav(),0)
        self.assertEqual(a.status,'BANKRUPT_HALT')
        self.assertEqual(a.mode(),'DEBT_SETTLEMENT_BLOCKED')
        self.assertFalse(a.settlement_journal)
        self.assertEqual(a.monitor('debt',2*M)['status'],'DEBT_SETTLEMENT_BLOCKED')

    def test_charged_new_increase_capital_guard(self):
        a=fresh(symbols=S)
        a.free_cash=D('1100') # synthetic opening cash boundary, no performance claim
        before=a.snapshot()
        with self.assertRaisesRegex(ValueError,'POST_FILL_CAPITAL'):
            a.execute_fill('BTCUSDT','BUY','2',M+1,0,'guard',execution_mid_price='100',quote_available_us=M)
        self.assertEqual(a.snapshot(),before)


if __name__=='__main__': unittest.main(verbosity=2)
