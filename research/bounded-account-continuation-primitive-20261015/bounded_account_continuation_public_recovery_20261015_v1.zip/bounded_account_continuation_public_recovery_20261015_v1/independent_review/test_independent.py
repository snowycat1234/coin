"""Independent synthetic adversarial review. No historical sources or runs."""
from copy import deepcopy
from decimal import Decimal as D
import unittest

from continuation import BoundedContinuationAccount as Account, MINUTE as M
from vendor_quant.perpetual_account import USDTLinearPerpetualAccount as Base, HALTS


def mark(a, t, prices='100', quality=None):
    rows = {s: dict(price=prices[s] if isinstance(prices, dict) else prices,
                   close_us=t, available_us=t) for s in a.symbols}
    return a.update_marks(t, rows, **({} if quality is None else {'quality': quality}))


def new(symbols=('BTCUSDT',), variant='TOPUP_THEN_CONTINUE', mode='CONDITIONAL_COLLATERAL_FORFEITURE'):
    a = Account(symbols=symbols, generated_scope='GENERATED_FAKE_ORIGIN_ONLY',
                settlement_mode=mode, policy_variant=variant)
    mark(a, 0); mark(a, M)
    return a


def open_short(a, symbol='BTCUSDT', fill_id='open', t=M+1):
    return a.execute_fill(symbol, 'SELL', '10', t, 0, fill_id,
                          execution_mid_price='100', quote_available_us=M)


def quote(t, price='100', volume='1e10'):
    return dict(open_us=t, open_price=price, quote_close_us=t,
                quote_available_us=t, quote_volume=volume,
                source_scope='GENERATED_COMPLETED_PRIOR_MINUTE')


class Independent(unittest.TestCase):
    def test_exact_guard50_boundary_and_prefund_target(self):
        a = new(); open_short(a)
        p = a.positions['BTCUSDT']; initial_balance = p.isolated_balance
        exact_boundary = p.entry_price + p.isolated_balance / (2 * abs(p.quantity))
        mark(a, 2*M, str(exact_boundary-D('.00000001')))
        a.monitor('below', 2*M)
        self.assertEqual(a.transfer_journal, [])
        mark(a, 3*M, str(exact_boundary))
        cash, nav, q = a.free_cash, a.nav(), p.quantity
        pnl = (a.fees, a.realized_PnL, a.execution_cost, a.funding_cash)
        a.monitor('boundary', 3*M)
        self.assertEqual(cash-a.free_cash, initial_balance/2)
        self.assertEqual(p.isolated_balance+p.quantity*(exact_boundary-p.entry_price), initial_balance)
        self.assertEqual(a.nav(), nav); self.assertEqual(p.quantity, q)
        self.assertEqual((a.fees, a.realized_PnL, a.execution_cost, a.funding_cash), pnl)
        snapshot = a.snapshot(); a.monitor('different-id-same-observation', 3*M)
        self.assertEqual(len(a.transfer_journal), 1)

    def test_allocator_ranks_risk_before_configured_symbol_order(self):
        a = new(('BTCUSDT', 'ETHUSDT')); open_short(a)
        open_short(a, 'ETHUSDT', 'openETH', M+2)
        mark(a, 2*M, {'BTCUSDT':'150', 'ETHUSDT':'170'})
        a.monitor('rank', 2*M)
        self.assertEqual([r['symbol'] for r in a.transfer_journal], ['ETHUSDT', 'BTCUSDT'])

    def test_one_position_settles_other_asset_and_cash_continue(self):
        a = new(('BTCUSDT', 'ETHUSDT'), variant='CONTINUE_ONLY')
        open_short(a); open_short(a, 'ETHUSDT', 'openETH', M+2)
        cash = a.free_cash
        eth = deepcopy(a.positions['ETHUSDT'])
        mark(a, 2*M, {'BTCUSDT':'210', 'ETHUSDT':'100'})
        self.assertEqual(a.positions['BTCUSDT'].quantity, 0)
        self.assertEqual(a.positions['ETHUSDT'], eth)
        self.assertEqual(a.free_cash, cash); self.assertNotIn(a.status, HALTS)
        with self.assertRaisesRegex(ValueError, 'FRESH_NORMAL'):
            a.execute_fill('BTCUSDT', 'BUY', '1', 3*M+1, 2*M, 'old-signal',
                           execution_mid_price='210', quote_available_us=3*M)
        mark(a, 3*M, {'BTCUSDT':'210', 'ETHUSDT':'100'})
        other = a.execute_fill('ETHUSDT', 'SELL', '1', 3*M+1, 2*M, 'other-asset',
                               execution_mid_price='100', quote_available_us=3*M)
        self.assertEqual(other['status'], 'FILLED')
        mark(a, 4*M, {'BTCUSDT':'210', 'ETHUSDT':'100'})
        fresh = a.execute_fill('BTCUSDT', 'BUY', '1', 4*M+1, 3*M, 'fresh-reentry',
                               execution_mid_price='210', quote_available_us=4*M)
        self.assertEqual(fresh['status'], 'FILLED')

    def test_marked_equity_settlement_value_ledger_is_exact(self):
        for price, positive_support in [('210', True), ('199', False)]:
            with self.subTest(price=price):
                a = new(variant='CONTINUE_ONLY'); open_short(a)
                cash = a.free_cash; mark(a, 2*M, price)
                e = a.settlement_journal[0]['decimal_strings']
                before, support, forfeiture, after = (D(e[k]) for k in
                    ('marked_equity_before','conditional_insurance_value_received',
                     'conditional_forfeiture_value_paid','marked_equity_after'))
                self.assertEqual(before+support-forfeiture, after)
                self.assertEqual(after, 0); self.assertEqual(D(e['value_ledger_error']), 0)
                self.assertEqual(D(e['NAV_after'])-D(e['NAV_before']), support-forfeiture)
                self.assertEqual(a.free_cash, cash)
                self.assertEqual(support > 0, positive_support)
                report = a.economic_report()
                self.assertFalse(report['paid_flat'])
                self.assertTrue(report['settled_flat_under_declared_model'])
                self.assertEqual(D(report['market_and_paid_cost_net_PnL_excluding_conditional_settlement_value'])
                    +D(report['conditional_NAV_adjustment_USDT']), a.nav()-a.config.initial_cash)

    def test_partial_paid_close_then_only_actual_remaining_collateral_forfeited(self):
        a = new(); open_short(a); mark(a, 2*M, '150'); a.monitor('topup', 2*M)
        a.request_terminal_exit('terminal', 2*M); mark(a, 3*M, '150')
        before = a.positions['BTCUSDT'].isolated_balance
        a.attempt_reductions('partial', 3*M+1, {'BTCUSDT':quote(3*M, '150', '150000')})
        self.assertEqual(a.positions['BTCUSDT'].quantity, -9)
        remaining_margin = a.positions['BTCUSDT'].isolated_balance
        self.assertEqual(remaining_margin, before*D('.9'))
        self.assertIn('BTCUSDT', a.pending_exits)
        fees = a.fees; mark(a, 4*M, '300')
        self.assertEqual(D(a.liquidations[0]['isolated_margin_lost']), remaining_margin)
        self.assertEqual(a.fees, fees)
        self.assertNotIn('BTCUSDT', a.pending_exits)
        self.assertEqual(len(a.settlement_journal), 1)

    def test_unknown_quality_native_halt_cannot_be_relabelled_or_rescued(self):
        a = new(); open_short(a)
        mark(a, 2*M, '210', {'BTCUSDT':'UNKNOWN_OR_DERIVED'})
        before = a.snapshot()
        self.assertIn(a.status, HALTS); self.assertEqual(a.settlement_journal, [])
        with self.assertRaises(RuntimeError): mark(a, 2*M, '210')
        self.assertEqual(a.snapshot(), before)
        self.assertEqual(a.monitor('halt-watch', 2*M)['status'], 'CASH_WATCH_UNRESOLVED')
        self.assertEqual(a.transfer_journal, [])

    def test_funding_replay_after_genuine_unpaid_halt_has_no_second_charge(self):
        a = new(('BTCUSDT','ETHUSDT')); open_short(a)
        open_short(a, 'ETHUSDT', 'openETH', M+2)
        receipt = a.apply_funding('BTCUSDT', 'debt', 2*M, '-20', 2*M)
        before = a.snapshot(); liability = a.unpaid_liability
        self.assertGreater(liability, 0); self.assertEqual(a.status, 'BANKRUPT_HALT')
        self.assertEqual(a.apply_funding('BTCUSDT', 'debt', 2*M, '-20', 2*M), receipt)
        self.assertEqual(a.snapshot(), before)
        a._risk('RECHECK'); self.assertEqual(a.unpaid_liability, liability)
        self.assertEqual(a.settlement_journal, [])

    def test_policy_event_clocks_and_replays(self):
        a = new(); open_short(a)
        with self.assertRaises(ValueError): a.request_terminal_exit('future', 5*M)
        mark(a, 2*M); a.request_terminal_exit('terminal', 2*M)
        r = a.attempt_reductions('empty', 5*M+1, {})
        self.assertEqual(a.clock_us, 5*M+1)
        before = a.snapshot()
        with self.assertRaises(ValueError): mark(a, 3*M)
        self.assertEqual(a.snapshot(), before)
        self.assertEqual(a.attempt_reductions('empty', 5*M+1, {}), r)
        self.assertEqual(a.snapshot(), before)

    def test_later_leg_fill_identity_conflict_is_preflighted(self):
        a = new(('BTCUSDT','ETHUSDT')); open_short(a)
        open_short(a, 'ETHUSDT', 'batch:ETHUSDT', M+2)
        mark(a, 2*M); a.request_terminal_exit('terminal', 2*M); mark(a, 3*M)
        before = a.snapshot()
        with self.assertRaises(ValueError):
            a.attempt_reductions('batch', 3*M+1, {s:quote(3*M) for s in a.symbols})
        self.assertEqual(a.snapshot(), before)

    def test_reference_inheritance_finance_and_fixed_policy_scope(self):
        self.assertIs(Account._leg, Base._leg)
        self.assertIs(Account.apply_funding, Base.apply_funding)
        a = new(); open_short(a); mark(a, 2*M, '150')
        before = a.snapshot()
        with self.assertRaisesRegex(ValueError, 'NOT_ADMITTED'):
            a.monitor('optional', 2*M, headroom_features={})
        self.assertEqual(a.snapshot(), before)

    def test_native_optional_available_quantity_none_is_preserved(self):
        a = new(); open_short(a); mark(a, 2*M)
        r = a.execute_fill('BTCUSDT', 'BUY', '10', 2*M+1, M, 'full-close',
                           execution_mid_price='100', quote_available_us=2*M,
                           available_quantity=None, reduce_only=True)
        self.assertEqual(r['status'], 'FILLED')
        self.assertEqual(a.positions['BTCUSDT'].quantity, 0)

    def test_rejected_capital_preview_never_calls_real_settlement_callback(self):
        a = new(); open_short(a)
        rate = -(a.free_cash-D(1000))/D(1000)
        a.apply_funding('BTCUSDT', 'cash-boundary', 2*M, str(rate), 2*M)
        mark(a, 2*M, '150'); mark(a, 3*M, '150')
        external = []
        a.liquidation_callback = lambda symbol, at: external.append((symbol, at))
        before = a.snapshot()
        with self.assertRaisesRegex(ValueError, 'POST_FILL_CAPITAL'):
            a.execute_fill('BTCUSDT', 'BUY', '1', 3*M+1, 2*M, 'rejected-preview',
                           execution_mid_price='1800', quote_available_us=3*M)
        self.assertEqual(external, [])
        self.assertEqual(a.snapshot(), before)


if __name__ == '__main__':
    unittest.main(verbosity=2)
