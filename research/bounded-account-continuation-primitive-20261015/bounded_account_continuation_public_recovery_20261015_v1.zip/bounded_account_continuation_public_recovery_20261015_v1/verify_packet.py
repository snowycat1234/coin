"""Read-only public-copy verification; no account construction or history."""
from hashlib import sha256
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
PRIVATE_PREFIXES=[b'/'+b'workspace/',b'/'+b'home/agent/',b'/'+b'opt/codex/',b'/'+b'tmp/',b'/'+b'mnt/']


def digest(raw):return sha256(raw).hexdigest()


def verify():
    manifest=json.loads((HERE/'FILES.json').read_text())
    if manifest['packet_id']!='BOUNDED_CONTINUATION_PUBLIC_COPY_V1':
        raise ValueError('public manifest identity mismatch')
    rows=manifest['files'];expected={r['path'] for r in rows}
    actual={str(p.relative_to(HERE)) for p in HERE.rglob('*') if p.is_file()}
    if actual!=expected|{'FILES.json'}:
        raise ValueError('missing or unexpected packet files')
    for row in rows:
        p=HERE/row['path']
        if p.is_symlink() or not p.is_file():raise ValueError('ordinary packet file required')
        raw=p.read_bytes()
        if len(raw)!=row['bytes'] or digest(raw)!=row['sha256']:
            raise ValueError('public packet mismatch:'+row['path'])
        if any(prefix in raw for prefix in PRIVATE_PREFIXES):
            raise ValueError('private absolute prefix in public packet:'+row['path'])
        if '__pycache__' in p.parts or p.suffix=='.pyc':raise ValueError('bytecode forbidden')
    handoff=json.loads((HERE/'HANDOFF.json').read_text())
    if handoff.get('manifest_name')!='FILES.json' or 'FILES.json' in handoff.get('sha256',{}):
        raise ValueError('public hand-off has ambiguous original manifest seal')
    original=json.loads((HERE/'original_receipts/FILES.json').read_text())
    original_by_path={r['path']:r for r in original}
    transforms=json.loads((HERE/'TRANSFORMATION_MAP.json').read_text())
    if digest((HERE/'original_receipts/FILES.json').read_bytes())!=transforms['original_packet_files_manifest_sha256']:
        raise ValueError('original manifest receipt mismatch')
    changed={r['path']:r for r in transforms['files']}
    if set(changed)!=set(manifest['transformed_evidence_files']):
        raise ValueError('transformed evidence scope mismatch')
    for path,row in original_by_path.items():
        destination='original_receipts/verify_packet.py' if path=='verify_packet.py' else path
        raw=(HERE/destination).read_bytes()
        if path not in changed:
            if digest(raw)!=row['sha256'] or len(raw)!=row['bytes']:
                raise ValueError('unexpected change outside evidence transformation:'+path)
            continue
        t=changed[path]
        if t['original_sha256']!=row['sha256'] or t['original_bytes']!=row['bytes']:
            raise ValueError('original transformation commitment mismatch')
        if digest(raw)!=t['sanitized_sha256'] or len(raw)!=t['sanitized_bytes']:
            raise ValueError('sanitized evidence mismatch')
        if raw.count(b'\n')!=t['newline_count'] or len(raw.splitlines())!=t['line_count']:
            raise ValueError('evidence line count changed')
        if t['sanitized_bytes']!=t['original_bytes']+sum(s['replacement_bytes']-s['original_prefix_bytes'] for s in t['spans']):
            raise ValueError('evidence replacement length arithmetic mismatch')
        for span in t['spans']:
            replacement=span['replacement_text'].encode();at=span['sanitized_byte_offset']
            if raw[at:at+len(replacement)]!=replacement or len(replacement)!=span['replacement_bytes']:
                raise ValueError('evidence replacement byte offset mismatch')
        lines=raw.splitlines(keepends=True)
        for line in t['changed_lines']:
            if digest(lines[line['line_number']-1])!=line['sanitized_line_sha256']:
                raise ValueError('transformed line digest mismatch')
    review=json.loads((HERE/'independent_review/REVIEW.json').read_text())
    for name in ('continuation.py','POLICY.json','test_continuation.py','PRIMITIVE_PINS.json','SOURCE_PROVENANCE.json'):
        if digest((HERE/name).read_bytes())!=review['candidate_sha256'][name]:
            raise ValueError('reviewed execution/policy identity mismatch:'+name)
    if digest((HERE/'independent_review/REVIEW.json').read_bytes())!=transforms['original_review_sha256']:
        raise ValueError('original review changed')
    if digest((HERE/'independent_review/FINAL_BINDING_ADDENDUM.json').read_bytes())!=transforms['original_final_binding_addendum_sha256']:
        raise ValueError('original final binding changed')
    from continuation import verify_primitives
    verify_primitives()
    return dict(packet_files_verified=len(rows),primitive_pin_count=5,reviewed_execution_bytes_unchanged=True,
        sanitized_evidence_files=len(changed),sanitized_prefix_replacements=sum(r['replacement_count'] for r in changed.values()),
        original_review_preserved=True,privacy_scan='PASS_NO_PRIVATE_ABSOLUTE_PREFIXES_OR_BYTECODE',
        historical_replays=0,historical_admission=False,snapshot_recovery_certified=False,
        transformation_proof_scope='PUBLIC_COMMITMENTS_AND_SANITIZED_BYTES; EXACT_PRIVATE_PREIMAGE_CHECK_IS_SEPARATE_INDEPENDENT_PACKAGING_REVIEW')

if __name__=='__main__':print(json.dumps(verify(),indent=2,sort_keys=True))
