"""Read-only verification of generated-only packet files and copied primitives."""
from hashlib import sha256
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent

def verify():
    rows=json.loads((HERE/'FILES.json').read_text())
    for row in rows:
        p=HERE/row['path']
        if p.is_symlink() or not p.is_file():raise ValueError('ordinary packet file required')
        b=p.read_bytes()
        if len(b)!=row['bytes'] or sha256(b).hexdigest()!=row['sha256']:
            raise ValueError('packet mismatch:'+row['path'])
    from continuation import verify_primitives
    verify_primitives()
    return {'packet_files_verified':len(rows),'primitive_bytes_verified':True,'historical_replays':0,
            'historical_admission':False,'snapshot_recovery_certified':False}

if __name__=='__main__':print(json.dumps(verify(),indent=2,sort_keys=True))
