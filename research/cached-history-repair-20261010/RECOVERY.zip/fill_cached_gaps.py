"""Retrieve only21 identified source-day gaps; no imputation or model change."""
from pathlib import Path
import requests,json,hashlib,zipfile
R=Path(__file__).parent/'gap-repair';R.mkdir(exist_ok=True);BASE='https://data.binance.vision/';s=requests.Session();jobs=[]
for sym in ['SOLUSDT','XRPUSDT']:
 for day in ['2022-02-26','2022-02-27','2022-02-28','2022-04-01','2022-04-02']:jobs.append((sym,'klines',day))
for sym in ['BTCUSDT','ETHUSDT','SOLUSDT','XRPUSDT','DOGEUSDT']:
 for day in (['2022-07-31'] if sym=='BTCUSDT' else [])+['2022-10-02','2023-02-24']:jobs.append((sym,'markPriceKlines',day))
(R/'PLAN.json').write_text(json.dumps({'jobs':jobs,'reason':'only actual cached incomplete trade days and funding mark days; no random expanded archive download','maximum_download_bytes':20*2**20},indent=2))
rows=[];total=0
for sym,family,day in jobs:
 name=f'{sym}-1m-{day}.zip';key=f'data/futures/um/daily/{family}/{sym}/1m/{name}';url=BASE+key;dest=R/f'{sym}_{family}_{day}.zip';proof=dest.with_suffix('.json')
 if dest.exists():
  x=json.loads(proof.read_text());assert hashlib.sha256(dest.read_bytes()).hexdigest()==x['SHA256'];rows.append(x);continue
 c=s.get(url+'.CHECKSUM',timeout=30)
 if c.status_code==404:rows.append({'key':key,'status':'SOURCE_OBJECT_UNAVAILABLE_404'});continue
 c.raise_for_status();assert c.url.startswith(BASE) and len(c.content)<1000;h,fn=c.text.split();assert fn==name
 q=s.get(url,timeout=30);q.raise_for_status();assert q.url.startswith(BASE);body=q.content;total+=len(body);assert total<=20*2**20 and len(body)<2*2**20;assert hashlib.sha256(body).hexdigest()==h
 dest.write_bytes(body)
 with zipfile.ZipFile(dest) as z:assert z.testzip() is None and len(z.namelist())==1
 x={'key':key,'url':url,'symbol':sym,'family':family,'day':day,'SHA256':h,'bytes':len(body),'checksum_text':c.text,'status':'CHECKSUM_CRC_VERIFIED'};proof.write_text(json.dumps(x,indent=2)+'\n');rows.append(x);print('VERIFIED',len(rows),key,flush=True)
 (R/'PROGRESS.json').write_text(json.dumps({'checked':len(rows),'expected':len(jobs),'bytes':total},indent=2))
(R/'RESULT.json').write_text(json.dumps({'records':rows,'complete':len(rows)==len(jobs),'no_training':True},indent=2)+'\n');print('COMPLETE',len(rows),flush=True)
