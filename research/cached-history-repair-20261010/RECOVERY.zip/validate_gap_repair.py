"""Fill only verified missing cached observations in a separate recovery dataset."""
from pathlib import Path
import json,hashlib
import pandas as pd,numpy as np
from modules.collector_research.pipeline.normalize import numeric_csv,validate_price,canonical,aggregate_price,mark_funding,funding_windows
R=Path(__file__).resolve().parent;G=R/'gap-repair';S=R.parent;oldroot=S/'feature-input/verified/source_tables_not_model_inputs';O=G/'repaired';O.mkdir(exist_ok=True);(O/'daily_features').mkdir(exist_ok=True);(O/'economics').mkdir(exist_ok=True)
receipts=json.loads((G/'RESULT.json').read_text())['records'];assert len(receipts)==21 and all(x['status']=='CHECKSUM_CRC_VERIFIED' for x in receipts)
frames={p.stem:pd.read_parquet(p) for p in (oldroot/'daily_features').glob('*.parquet')};events={s:pd.read_parquet(oldroot/'economics'/f'{s}_funding_events.parquet') for s in ['BTCUSDT','ETHUSDT','SOLUSDT','XRPUSDT','DOGEUSDT']};days={s:pd.read_parquet(oldroot/'economics'/f'{s}_daily.parquet') for s in events};fixes=[]
for r in receipts:
 s,family,day=r['symbol'],r['family'],r['day'];p=G/f'{s}_{family}_{day}.zip';assert hashlib.sha256(p.read_bytes()).hexdigest()==r['SHA256'];lo=pd.Timestamp(day,tz='UTC').value//1000000
 d,dup=validate_price(numeric_csv(p),family,lo,lo+86400000);np.testing.assert_array_equal(d.timestamp_ms,np.arange(lo,lo+86400000,60000));q=canonical(d,family,s);ag=aggregate_price(q,family);assert ag.complete.all() and len(ag)==1
 if family=='klines':
  row=ag.iloc[0];ix=frames[s].index[frames[s].dt.eq(pd.Timestamp(day,tz='UTC'))];ex=days[s].index[days[s].dt.eq(pd.Timestamp(day,tz='UTC'))];assert len(ix)==len(ex)==1 and not frames[s].loc[ix[0],'complete_kline'] and not days[s].loc[ex[0],'complete_kline']
  for c in ['open','high','low','close','volume','quote_volume']:frames[s].loc[ix,c]=row[c]
  frames[s].loc[ix,'complete_kline']=True
  for c in ['open','high','low','close','volume','quote_volume','trades','rows','first_ms','last_ms','exec_price','unique_minutes']:days[s].loc[ex,c]=row[c]
  days[s].loc[ex,'complete_kline']=True;fixes.append({'symbol':s,'family':family,'day':day,'observed_minutes':len(d),'filled_feature_rows':1})
 else:
  ef=events[s];new=mark_funding(ef,q[['available_us','close']]);valid=np.isfinite(new.past_mark_price);oldvalid=np.isfinite(ef.past_mark_price);both=valid&oldvalid
  np.testing.assert_allclose(ef.loc[both,'past_mark_price'],new.loc[both,'past_mark_price'],atol=1e-10,rtol=1e-12);np.testing.assert_array_equal(ef.loc[both,'past_mark_available_us'],new.loc[both,'past_mark_available_us']);fill=valid&~oldvalid
  ef.loc[fill,['past_mark_price','past_mark_available_us']]=new.loc[fill,['past_mark_price','past_mark_available_us']];fixes.append({'symbol':s,'family':family,'day':day,'observed_minutes':len(d),'filled_event_marks':int(fill.sum()),'overlap_equal':int(both.sum())})
for s,df in frames.items():df.to_parquet(O/'daily_features'/f'{s}.parquet',index=False)
coverage=[]
for s,ef in events.items():
 dd=days[s];fw=funding_windows(ef,pd.DatetimeIndex(dd.dt));old=dd.funding_interval_complete.fillna(False).to_numpy();new=fw.funding_interval_complete.to_numpy();np.testing.assert_allclose(dd.loc[old,'mark_funding_per_unit'],fw.loc[old,'mark_funding_per_unit'],atol=1e-10,rtol=1e-12)
 for c in ['mark_funding_per_unit','funding_rate_sum_interval','funding_interval_complete']:dd[c]=fw[c].to_numpy()
 dd.to_parquet(O/'economics'/f'{s}_daily.parquet',index=False);ef.to_parquet(O/'economics'/f'{s}_funding_events.parquet',index=False);coverage.append({'symbol':s,'additional_complete_funding_intervals':int((new&~old).sum())})
report={'status':'VERIFIED_OBSERVATIONS_RECOVERED_ORIGINAL_FROZEN_DATA_UNCHANGED','fixes':fixes,'coverage':coverage,'new_model_fits':0,'source_cache':str(oldroot),'feature_implication':'Original formulas now see newly observed real days; downstream rolling features/targets must be reconstructed, not spliced onto old contexts. Old fitted models/results remain bound to old data.'}
(G/'VALIDATION.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
