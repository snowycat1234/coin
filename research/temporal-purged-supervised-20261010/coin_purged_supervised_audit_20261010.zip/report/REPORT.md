# Purged chronological supervised timing control

## Result

There is a SHORT-specific association in later old history, but this experiment does **not** establish actionable calibrated or payoff-aware predictive skill. More training clearly overfits: epoch100 fits the prefix much better and performs much worse on2023. The selected epoch20 also identifies SHORT winners in early2024, so the association is not confined to2023. However, its four-class proper scores and average fixed-policy opportunity regret fail to beat the frozen prefix prior/constant VOL action in both later blocks.

These are previously seen project dates used as internal chronological development validation. They are not pristine OOS. This experiment did not read2025 inputs, retune on2025, replay a trading wallet, or establish trading profits. Nothing here promotes a strategy.

## Frozen design and boundaries

- TRAIN:744 labels, decisions2020-10-15 through2022-12-10, strictly mature before2023-01-01.
- Selection:344 labels, decisions2023-01-01 through2023-12-10, strictly mature before2024-01-01.
- Audit:100 labels, decisions2024-01-01 through2024-04-09, strictly mature before2024-05-01.
-42 targets crossing the two boundaries were purged. The original per-episode terminal exclusions were preserved.

The unchanged13,699-parameter model uses causal64-day windows plus expert state. The normalizer was fitted exclusively from sliced TRAIN windows:850 unique valid historical calendar rows, scaler identity `e68ed7582a538e67c1f5cdc6775a2100ae4fdecddb5fc91816c0b7d340d64d73`. It never used the full-history normalizer. Prefix class counts in CASH/VOL/CS/SHORT order are[16,312,234,182], giving prior[.02151,.41935,.31452,.24462]. Counts, class-balanced CE weights, prior and constant mean-utility action were all prefix-only.

One fresh seeded trajectory ran100 epochs/1,200 updates, saving every minibatch's model, Adam, RNG and permutation. Only the fixed20/100 snapshots were candidates. The predeclared rule selected epoch20 by corrected2023 multiclass logloss, with an exact-tie preference for20. Both the prefit plan and selected checkpoint were publicly frozen before their respective evaluation stages. The2024 audit scored only epoch20, once; the100-epoch2024 audit was not run.

## Primary corrected probabilities

| Block/model | Logloss | Brier | Accuracy | SHORT precision | SHORT recall | SHORT prevalence | Mean opportunity regret |
|---|---:|---:|---:|---:|---:|---:|---:|
| TRAIN20 |1.02681|.60537|49.33%|53.24%|40.66%|24.46%|.014419|
| TRAIN100 |.28673|.14933|89.65%|87.78%|86.81%|24.46%|.000945|
|2023 selected20 |1.32405|.67116|57.56%|48.62%|85.44%|29.94%|.017649|
|2023 candidate100 |2.54620|1.06432|34.88%|34.56%|91.26%|29.94%|.031684|
|2023 frozen prior/VOL |1.30705|.69516|47.09%|undefined|0%|29.94%|.015272|
|2024 selected20 |1.54579|.71844|55.00%|53.13%|62.96%|27.00%|.010992|
|2024 frozen prior/VOL |1.39691|.70508|52.00%|undefined|0%|27.00%|.008594|

2023 epoch20 has88 correct SHORT picks out of181, against103 SHORT truths. Epoch100 raises picks to272 and correct picks to94, with sharply worse proper scores and regret. The train100 versus2023 gap supports overfitting; raising epochs alone is not a remedy for earlier low-SHORT results. This control does not uniquely identify the cause of those earlier results because their training prefix, normalizer and class mix differed.

2024 epoch20 has17 correct picks out of32, against27 SHORT truths. Its class truth counts are[12,52,9,27]; predictions are[0,68,0,32]. The classifier never chooses CASH or CS in either later block. Raw balanced probabilities remain a diagnostic only: in2024 raw logloss is1.44696, Brier.77355, accuracy28%, SHORT precision31.08% and recall85.19%. This mixed tradeoff does not validate the inverse-class-weight correction as calibrated, and it did not change the frozen selection rule.

## Why precision uplift does not yield payoff improvement

All margins below are hindsight cost-aware21-day fixed-policy utility units, not return percentages or tradable profits. Overlapping daily totals cannot be compounded or summed as portfolio profit. The read-only postfit decomposition uses existing frozen predictions, changes no thresholds and introduces no fit.

| Selected20 block | Correct SHORT picks | Mean SHORT−VOL margin when correct | Incorrect SHORT picks | Mean SHORT−VOL margin when incorrect |
|---|---:|---:|---:|---:|
|2023|88|+.04354|93|−.05000|
|2024|17|+.02735|15|−.04698|

In2024 correct SHORT picks contribute+.004649 utility per all100 rows, but incorrect SHORT picks contribute−.007047. Their net−.002398 exactly reconstructs the+.002398 excess opportunity regret over constant VOL. Every incorrect SHORT pick in this block has a negative SHORT−VOL margin. The mean adverse margin is about1.72 times the mean correct-pick benefit, so53.13% winner precision is insufficient for this payoff mix.

In2023 the analogous contributions are+.011139 and−.013516, producing net−.002377 and the same exact regret identity. False positives also have a heavier adverse tail: the10th percentile SHORT−VOL margin is−.18947. Winner classification treats these unequal mistake sizes equally; the existing label/objective does not directly optimize their monetary magnitude.

NonSHORT truth confusion, with columns CASH/VOL/CS/SHORT:

-2023 CASH:[0,18,0,9]; VOL:[0,110,0,52]; CS:[0,20,0,32]. NonSHORT accuracy45.64%, versus constant VOL67.22%.
-2024 CASH:[0,12,0,0]; VOL:[0,38,0,14]; CS:[0,8,0,1]. NonSHORT accuracy52.05%, versus constant VOL71.23%.

Rare-CASH probability errors also damage proper scores: mean CASH logloss is4.5576 in2023 and5.0796 in2024, with no correct CASH argmax. The prefix has only16 CASH labels, while the later blocks have27/344 and12/100. This is evidence for a four-way calibration/class-mix and false-positive-cost bottleneck, beyond the presence or absence of a SHORT association.

## Uncertainty and disjoint views

Daily21-day targets overlap. Their344/100 row counts overstate independent information. The fixed calendar phase0 grid has only17 horizons in2023 and5 in2024:

-2023: SHORT precision5/9=55.56%, recall5/5; logloss1.51170 versus prior1.41087. Paired phase0 bootstrap95 intervals for model−prior logloss[−.12016,+.35152] and regret[−.02005,+.01385] include zero.
-2024: SHORT precision1/2=50%, recall1/1; logloss1.92886 versus prior1.57092. Approximate Wilson95 precision interval[9.45%,90.55%] and recall[20.65%,100%] are very wide. Paired logloss difference interval[−.11945,+.94600] and regret[−.01670,+.01392] include zero.

All21 fixed phases are reported without pooling or selecting a favorable phase. In2023 selected20 precision minus prevalence ranges+.07563 to+.31250, but logloss differences range−.22055 to+.12794. In2024 precision minus prevalence ranges−.20 to+.75 and logloss differences−.12425 to+.48894. The small disjoint view is not stable enough to claim reliable generalization. Wilson and IID-on-disjoint-horizons bootstrap intervals remain descriptive: residual serial dependence and selection bias are not removed.

## Best next hypothesis

Keep the selector route open. The narrow hypothesis worth testing next is that costly SHORT false positives and incompletely learned/calibrated CASH/CS probabilities prevent a useful allocation, despite a SHORT-specific signal. Before another fit, use the frozen prediction decomposition to inspect error severity, per-class probability behavior and the inverse-class-weight correction. Any eventual payoff-sensitive or calibration experiment should have a new bounded predeclared plan, calibration/thresholds confined to matured inner-prefix labels, and purged chronological validation. Do not repeat a blind epoch increase, a broad model grid, or an already-negative direct-contrast model, and do not use2025 as a selection target.

## Verification and recovery

- Four focused tests passed: strict maturity/purging at both boundaries, prefix-only normalization against a validation extreme, SHORT metrics/prior correction, and synthetic dropout+Adam+RNG bit-exact recovery. Final package Ruff passed. The read-only payoff diagnostic checks its exact regret reconstruction.
- Actual checkpoint model/optimizer/RNG validators passed at240 and1,200 updates. Per-minibatch checkpoints and all old artifacts remain intact.
- Training took98.48s within a102.46s bounded invocation, peak RSS749,568,000B. Selection and audit took5.51s and4.01s, peak RSS634,769,408B and620,412,928B. Each command used one CPU/thread, no GPU/swap; maximum observed host used memory was2.86GB.
- All four IO receipts show no2025-path opens/attempts. No new downloads, external messages, credentials, payments or trading actions occurred.
- Repository-wide tests, trading wallet replay and the unselected100-epoch2024 audit are explicitly NOT_RUN. No financial kernels changed.
- `PLAN.json`, `SELECTION.json`, complete score files, prediction/checkpoint recovery archive, IO/resource receipts and `PAYOFF_ERROR_DIAGNOSIS.json` bind the source, input and model identities. The pre-audit recovery ZIP is preserved unchanged; the audit extension supplies final predictions and reports separately.
