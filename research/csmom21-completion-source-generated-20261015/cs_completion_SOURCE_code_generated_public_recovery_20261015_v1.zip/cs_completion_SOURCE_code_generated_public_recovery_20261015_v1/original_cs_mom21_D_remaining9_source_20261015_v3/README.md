# REMAINING9 original-CS source/target checkpoint

Code and generated-only status. No actual source capture, target artifact,
covariance artifact, financial run, account, provider iteration, claim, process,
real GO or publication has been created here. A fresh independent source review
and a fresh external root REMAINING9 source GO are still required.

The finite source tranche is partial 2021 April 2–December 31 (274 days), full
2024 (366 days), and full 2025 (365 days), each LOW/MID/HIGH. The original fixed
15-cell manifest and five-year qualified source contract map are byte-identical.
FIRST6, other candidates/cells/years, holdouts and financial permissions fail
source authority validation. Qualified old source identities describe lineage;
no old scope, LoadedInputs, GO body, financial pin or old authority is reused.

## Minimal separate binding

REMAINING9_SOURCE_BINDING.json lists the exact V4 source graph copied unchanged.
cs_entry.py and prepare_cs_source.py add a separate source-only binding. V3 adds only the declared 2021 qualification endpoint projection in cs_source.py.
The CLI requires CPU2, pool1 and an exclusive new local source_attempts directory.
The two exact codec imports, encodings.cp437 and encodings.utf_8_sig, occur before
the unchanged SourceOnlyGuard. There is no broad import allowance.

The original public_targets AST and default short_absolute_confirmation=False,
weekly 2024-01-01 anchor, exact 21-return ranks and original risk sizing stay
unchanged. Current scale_to_tier remains exact and can re-expand the original
sized CS output. The 200-close admission is separate from original signal math.
Arrays are bytes-backed immutable, preserving exact dtype, endian, shape and
raw bytes. Original daily prefix and Dec31 endpoint separation are retained.
2021 raw funding has strict-prior witnesses and UNCONFIRMED units, projected
without rate rescaling. 2024/2025 keep their exact four-field event schemas.
The 2024 ten derived mark cells and uncertified arrival/source-age lineage stay
separate from the 2025 empty quality intervals. No old D impact conclusion is
inherited.

## Stable source artifact/API contract

The V4 source preparation artifact layout is unchanged. PREPARED_CSMOM21_SOURCE_TARGET_ONLY_V2 and
EXACT_NEW_CS_CELL_SOURCE_TARGET_BINDING_V2 are unchanged. Each year saves
TARGETS.npz, SOURCE_INPUTS.npz, RAW_EVENTS.json, MINUTE_MARK_PROVENANCE.json and
TARGET_PROOFS.json, with direct new source-GO/review pins and per-cell bindings.
A future financial adapter must be separate and bind these saved targets and
this exact CODE_MANIFEST digest. It is deliberately excluded from source code
identity and must not modify this checkpoint or regenerate its targets.

## Generated verification

From this directory:

taskset -c 2 env OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 POLARS_MAX_THREADS=1 VECLIB_MAXIMUM_THREADS=1 BLIS_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 ../coin_partial_restore_20261014/.venv/bin/python -B run_source_generated.py

Run test_cold_generated_zip.py separately in fresh processes, once normally and
once with --expect-cold-stop. Both are generated in-memory ZIP controls; neither
opens a stored archive. The negative control deliberately records one blocked
cold cp437 filename-loader attempt. The positive imports the exact two codecs
before the unchanged guard and records zero forbidden attempts.

SOURCE_STAGE_GO_TEMPLATE_INVALID.json and SOURCE_STAGE_COMMAND_INVALID.txt are
non-executable placeholders, not authorization. No actual invocation is allowed
until the parent/root provides a fresh exact approved GO and independent review.

## V2 strict metadata correction

V1 is preserved unchanged. Independent review found that its preparation validator
accepted extra top-level/year/cell-wrapper fields and an extra future-year artifact.
V2 requires exact keysets at every such boundary, including exactly 17 source
artifacts, three years and nine cells. STRICT_PREPARATION_SCHEMA_DELTA.json records
the prior accepted mutations. Source/math/codecs/provider/guard are unchanged.

## V3 pinned 2021 endpoint witness

The genuine 2021 sidecar has no final_endpoint_close field. V2 failed closed on
that assumption. V3 reads the already-allowlisted exact qualification metadata
and matches its five terminal_flat_quote trade/mark prices and source clocks
to the captured final genuine rows. The source-end-plus-one clock remains a
witness only and changes no native execution endpoint. No source bytes, math,
codec, provider, quality policy or financial mechanism change. V1, V2 and the
failed attempt remain unchanged. Fresh review and root source GO are required.
