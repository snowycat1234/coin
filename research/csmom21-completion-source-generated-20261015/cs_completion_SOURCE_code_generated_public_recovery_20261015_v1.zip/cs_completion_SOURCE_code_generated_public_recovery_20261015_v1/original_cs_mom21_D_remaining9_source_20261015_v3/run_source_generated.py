"""CPU2/pool1 generated-only suite with observed external-action counters."""
import os
THREAD_ENV=('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS',
            'POLARS_MAX_THREADS','VECLIB_MAXIMUM_THREADS','BLIS_NUM_THREADS')
for key in THREAD_ENV:os.environ[key]='1'
os.environ['PYTHONDONTWRITEBYTECODE']='1'
import builtins
from contextlib import ExitStack
import io
import json
from pathlib import Path
import resource
import socket
import subprocess
import time
import unittest
from unittest.mock import patch
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
observed=dict(actual_source_body_read_attempts=0,old_private_GO_body_read_attempts=0,
    external_process_launch_attempts=0,network_attempts=0,nonallowlisted_workspace_read_attempts=0)


def main():
    os.sched_setaffinity(0,{2});began=time.monotonic()
    manifest=json.loads((HERE/'CODE_MANIFEST.json').read_bytes())
    read_paths={HERE/name for name in manifest['files']} | {ROOT/name for name in manifest['dependencies']}
    read_paths|={HERE/'CODE_MANIFEST.json',HERE/'run_source_generated.py',HERE/'test_remaining9.py'}
    def check(file):
        if isinstance(file,int) or not isinstance(file,(str,bytes,os.PathLike)):return
        path=Path(os.path.abspath(os.fsdecode(file)))
        if path.suffix.lower() in ('.npz','.npy','.csv','.tsv','.parquet','.arrow','.ipc','.zip'):
            observed['actual_source_body_read_attempts']+=1;raise AssertionError('NO_STORED_MARKET_OR_ARRAY_BODY_READ:'+str(path))
        if ('annual_go' in path.parts or path.name.startswith('ROOT_GO_APPROVED') or path.name.startswith('ROOT_SOURCE_')
                or path.name.startswith('ROOT_FINANCIAL_') or path.name in ('ROOT_GO.json','ROOT_GO_FINANCIAL.json')):
            observed['old_private_GO_body_read_attempts']+=1;raise AssertionError('NO_ACTUAL_AUTHORITY_BODY_READ:'+str(path))
        if ROOT in path.parents and path not in read_paths:
            observed['nonallowlisted_workspace_read_attempts']+=1;raise AssertionError('GENERATED_CODE_METADATA_ALLOWLIST_ONLY:'+str(path))
    def wrapped(original):
        def opened(file,mode='r',*args,**kwargs):
            if 'r' in mode or '+' in mode:check(file)
            return original(file,mode,*args,**kwargs)
        return opened
    original_os_open=os.open
    def os_open(path,flags,*args,**kwargs):
        if not flags&os.O_WRONLY:check(path)
        return original_os_open(path,flags,*args,**kwargs)
    with ExitStack() as stack:
        for obj,name,fn in ((builtins,'open',wrapped(builtins.open)),(io,'open',wrapped(io.open)),(os,'open',os_open)):
            stack.enter_context(patch.object(obj,name,fn))
        def denied(category,target):
            def fail(*args,**kwargs):
                observed[category]+=1;raise AssertionError('GENERATED_EXTERNAL_ACTION_DENIED:'+target)
            return fail
        for obj,names,category in ((subprocess,('Popen','run','call','check_call','check_output'),'external_process_launch_attempts'),
            (os,('system','fork','forkpty','posix_spawn','posix_spawnp','execv','execve','execvp','execvpe'),'external_process_launch_attempts'),
            (socket.socket,('connect','connect_ex','sendto','send','sendall'),'network_attempts')):
            for name in names:
                if hasattr(obj,name):stack.enter_context(patch.object(obj,name,denied(category,name)))
        suite=unittest.defaultTestLoader.loadTestsFromNames(['test_remaining9'])
        result=unittest.TextTestRunner(verbosity=2).run(suite)
    import cs_entry as entry
    from test_remaining9 import GUARD_RECEIPTS,NEGATIVE_GUARD_RECEIPTS
    receipt=dict(schema='REMAINING9_CS_SOURCE_GENERATED_ONLY_RECEIPT_V1',
        status='PASS' if result.wasSuccessful() and not any(observed.values()) else 'FAIL',
        positive_guard_receipts=GUARD_RECEIPTS,expected_negative_guard_receipts=NEGATIVE_GUARD_RECEIPTS,
        tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),observed=observed,
        CPU_affinity=sorted(os.sched_getaffinity(0)),
        all_TID_affinities=[sorted(os.sched_getaffinity(int(t))) for t in os.listdir('/proc/self/task')],
        numerical_environment={key:os.environ[key] for key in THREAD_ENV},
        elapsed_wall_seconds=time.monotonic()-began,peak_RSS_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,
        worker_processes_launched=0,maximum_generated_processes=1,actual_source_body_reads=0,
        actual_source_scopes_minted=0,historical_scopes_minted=0,actual_targets_generated=0,actual_financial_runs=0,
        actual_accounts_created=0,actual_account_advances=0,actual_claims_written=0,source_admission_GO_written=0,
        financial_GO_written=0,provider_or_history_calls=0,publication_actions=0,holdout_reads=0,
        source_scopes_revoked=not entry._ACTIVE_SOURCE,recording_scopes_revoked=not entry._ACTIVE_RECORDING,
        source_code_manifest_SHA256=entry.code_identity(),scope_manifest_SHA256=entry.manifest_sha(),
        source_contract_map_SHA256=entry.contract_sha(),source_authority_domain=entry.SOURCE_DOMAIN,
        arrays='INVENTED_IN_MEMORY_ONLY_NO_ACTUAL_ARTIFACTS')
    (HERE/'SOURCE_GENERATED_TEST_RECEIPT.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
    return 0 if receipt['status']=='PASS' else 1
if __name__=='__main__':raise SystemExit(main())
