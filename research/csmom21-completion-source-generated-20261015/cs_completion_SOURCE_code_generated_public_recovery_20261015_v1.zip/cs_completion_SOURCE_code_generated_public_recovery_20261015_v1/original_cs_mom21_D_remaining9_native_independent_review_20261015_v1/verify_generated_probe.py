"""Audit only saved generated resource evidence, never launch any worker."""
from hashlib import sha256
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
AUTHOR = ROOT / 'original_cs_mom21_D_remaining9_financial_20261015_v1'
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(AUTHOR))
import cs_common as c
import cs_finance_gate as gate
import cs_process_runtime as runtime


def pin(path):
    raw = path.read_bytes()
    return dict(path=str(path.relative_to(ROOT)), SHA256=sha256(raw).hexdigest(), bytes=len(raw))


def main():
    folder = Path(sys.argv[1]).resolve(); expected = sys.argv[2]
    assert folder.is_relative_to(AUTHOR)
    profile_path = folder / 'GENERATED_POOL_PROFILE.json'
    raw = c.exact(profile_path, expected); profile = c.exact_object(raw)
    assert profile['status'] == 'ALL_ADMITTED_ORDERED_CELLS_TERMINAL'
    assert profile['generated_only'] is True
    assert profile['source_code_manifest_SHA256'] == gate.SOURCE_CODE_SHA256
    assert profile['maximum_observed_live_workers'] == 2
    assert profile['coordinator_CPU_affinity'] == [4, 5]
    assert profile['compute_thread_pools_maximum'] == 1
    assert profile['no_automatic_retry'] is True
    assert profile['no_financial_snapshot_resume'] is True
    assert profile['limits'] == runtime.LIMITS
    assert profile['actual_claims_created'] == profile['actual_targets_generated'] == 0
    assert profile['historical_account_objects_constructed'] == profile['historical_financial_runs'] == 0
    assert profile['actual_source_bodies_read'] == 0
    assert profile['annual_resource_envelope_certified'] is False
    cases = profile['cases']; assert len(cases) == 2
    assert {row['cell_id'] for row in cases} == {'GENERATED_CS_ACTIVE_A', 'GENERATED_CS_ACTIVE_B'}
    assert {row['CPU'] for row in cases} == {4, 5}
    for observation in profile['observations']:
        assert len(observation['workers']) <= 2
        assert observation['aggregate_live_RSS_bytes'] <= runtime.LIMITS['aggregate_live_worker_RSS_stop_bytes']
        for worker in observation['workers']:
            assert worker['RSS_bytes'] <= runtime.LIMITS['per_case_RSS_stop_bytes']
            if worker['CPU_affinity'] in ([4], [5]):
                assert all(task['CPU_affinity'] == worker['CPU_affinity'] for task in worker['tasks'])
    import cs_generated as generated
    native = generated.native_reference()
    from saved_native_reconciliation import reconcile_saved_native
    checked = []; common_inode = set()
    for row in cases:
        case = folder / row['cell_id']
        checkpoint_raw = (case / 'TERMINAL_CHECKPOINT.json').read_bytes()
        assert c.sha(checkpoint_raw) == row['checkpoint_SHA256']
        checkpoint = c.exact_object(checkpoint_raw)
        expected_names = {'GENERATED_AUDIT.json', 'GENERATED_RESULT.json', 'GENERATED_PROOF.json',
                          'GENERATED_SOURCE_GUARD.json', 'CASE_RECEIPT.json'}
        assert set(checkpoint['files']) == expected_names
        bodies = {name: c.exact(case / name, digest) for name, digest in checkpoint['files'].items()}
        audit = c.exact_object(bodies['GENERATED_AUDIT.json'])
        result = c.exact_object(bodies['GENERATED_RESULT.json'])
        proof = reconcile_saved_native(audit, result, expected_continuation_version=native.VERSION)
        assert runtime.body(proof) == bodies['GENERATED_PROOF.json']
        receipt = c.exact_object(bodies['CASE_RECEIPT.json'])
        assert receipt['status'] == row['status'] == 'PASS_ACTIVE_GENERATED_CS_NATIVE'
        assert receipt['generated_only'] is True
        assert receipt['source_code_manifest_SHA256'] == gate.SOURCE_CODE_SHA256
        assert receipt['financial_code_manifest_SHA256'] == gate.code_identity()
        assert receipt['historical_account_objects_constructed'] == receipt['historical_financial_runs'] == 0
        assert receipt['actual_source_bodies_read'] == 0
        assert receipt['generated_minutes'] == 2880
        assert receipt['paid_trade_rows'] == len(audit['trades']) > 0
        assert receipt['limits'] == runtime.LIMITS
        assert receipt['actual_affinity'] == [row['CPU']]
        assert all(cpu == [row['CPU']] for cpu in receipt['all_TID_affinities'])
        assert receipt['thread_environment'] == {key: '1' for key in runtime.THREAD_ENV}
        assert receipt['lease_FD_inherited'] is True
        common_inode.add(receipt['lease_inode'])
        assert receipt['max_RSS_bytes'] <= runtime.LIMITS['per_case_RSS_stop_bytes']
        assert receipt['CPU_seconds'] <= runtime.LIMITS['per_case_CPU_seconds']
        assert receipt['wall_seconds'] <= runtime.LIMITS['per_case_wall_seconds']
        source_guard = c.exact_object(bodies['GENERATED_SOURCE_GUARD.json'])
        assert source_guard['guard_active'] is False
        assert all(type(n) is int and n == 0 for n in source_guard['forbidden_attempts'].values())
        bootstrap = c.exact_object((case / 'BOOTSTRAP_READY.json').read_bytes())
        assert bootstrap['PID'] == receipt['PID'] == row['PID']
        assert bootstrap['requested_CPU'] == row['CPU']
        assert bootstrap['actual_affinity'] == [row['CPU']]
        assert bootstrap['thread_environment'] == receipt['thread_environment']
        assert bootstrap['limits'] == {name: [value, value] for name, value in (
            ('AS', runtime.LIMITS['per_case_AS_bytes']), ('CPU', runtime.LIMITS['per_case_CPU_seconds']),
            ('RSS', runtime.LIMITS['per_case_RSS_stop_bytes']))}
        owner = c.exact_object((case / 'PROCESS_OWNERSHIP.json').read_bytes())
        assert owner['cell_id'] == row['cell_id'] and owner['PID'] == row['PID'] and owner['CPU'] == row['CPU']
        checked.append(dict(cell_id=row['cell_id'], PID=row['PID'], CPU=row['CPU'],
            paid_trade_rows=receipt['paid_trade_rows'], generated_minutes=receipt['generated_minutes'],
            exact_native40_reconstruction=True, receipt=pin(case / 'CASE_RECEIPT.json'),
            checkpoint=pin(case / 'TERMINAL_CHECKPOINT.json')))
    assert len(common_inode) == 1
    review = dict(schema='INDEPENDENT_REMAINING9_GENERATED_RESOURCE_PROBE_REVIEW_V1', status='PASS',
        profile=pin(profile_path), financial_code_manifest_SHA256=gate.code_identity(),
        source_code_manifest_SHA256=gate.SOURCE_CODE_SHA256, maximum_observed_live_workers=2,
        worker_CPUs=[4, 5], compute_pool_threads_maximum=1,
        inherited_common_controller_lease_inode=next(iter(common_inode)), checked_generated_cases=checked,
        annual_resource_envelope_certified=False, actual_source_or_target_bodies_read=False,
        actual_historical_scopes_created=0, actual_financial_runs=0, actual_claims_or_GO_writes=0,
        probe_worker_processes_launched_by_reviewer=0, financial_execution_authorized=False)
    (OUT / 'INDEPENDENT_GENERATED_PROBE_REVIEW.json').write_text(json.dumps(review, indent=2, sort_keys=True) + '\n')
    print(json.dumps(dict(status='PASS', generated_resource_probe_SHA256=expected,
        maximum_observed_live_workers=2, checked_generated_cases=len(checked))))


if __name__ == '__main__':
    main()
