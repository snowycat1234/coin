"""Independent generated arithmetic and exact static transport seams only."""
import ast
from copy import deepcopy
from decimal import Decimal, localcontext
from hashlib import sha256
from io import BytesIO
from pathlib import Path
import unittest
from unittest.mock import patch
import zipfile

import numpy as np
import polars as pl
import cs_common as c
import cs_generated as generated
import cs_saved as saved
from test_cs_native import marks

EVIDENCE = {}


def digest(raw):
    return sha256(raw).hexdigest()


def named_function(path, name):
    return next(n for n in ast.parse(path.read_bytes()).body
                if isinstance(n, ast.FunctionDef) and n.name == name)


class IndependentRemaining9(unittest.TestCase):
    def test_exact_reviewed_C_F_parser_function_and_payload_guards(self):
        reference = c.ROOT / 'cs_saved_minute_reporting_repair_20261015_v1/cs_saved_reporting.py'
        self.assertEqual(digest(reference.read_bytes()),
            'b3073f4f4933ebdfccb48b8e130e2a6b2ec14565a7822d0190c75eb719ed2cd5')
        expected = ast.dump(named_function(reference, 'saved_minute'), include_attributes=False)
        actual = ast.dump(named_function(c.HERE / 'cs_saved.py', 'saved_minute'), include_attributes=False)
        self.assertEqual(actual, expected)
        rng = np.random.default_rng(7121)
        count = 0
        for rows, columns in ((0, 1), (1, 3), (4, 5), (17, 37), (29, 128)):
            values = rng.normal(size=(rows, columns)); names = ['c' + str(i) for i in range(columns)]
            for order in ('C', 'F'):
                stream = BytesIO()
                np.savez_compressed(stream, values=np.array(values, order=order), columns=np.asarray(names))
                raw = stream.getvalue(); before = digest(raw)
                result, result_names = saved.saved_minute(raw, rows)
                self.assertEqual(result.tobytes(order='C'), values.tobytes(order='C'))
                self.assertEqual(result_names, names); self.assertEqual(digest(raw), before); count += 1
        frame = pl.DataFrame(dict(a=[1., 2.5, -3., 4.], b=[5., -6., 7., 8.]))
        writer = named_function(c.HERE / 'run_cs.py', 'case')
        source = (c.HERE / 'run_cs.py').read_text()
        assignment = next(n for n in ast.walk(writer) if isinstance(n, ast.Assign)
            and ast.get_source_segment(source, n) == 'values, columns = minute.to_numpy(), minute.columns')
        expected_assignment = ast.parse('values, columns = minute.to_numpy(), minute.columns').body[0]
        self.assertEqual(ast.dump(assignment, include_attributes=False), ast.dump(expected_assignment, include_attributes=False))
        values, names = frame.to_numpy(), frame.columns
        self.assertTrue(values.flags.f_contiguous)
        stream = BytesIO(); np.savez_compressed(stream, values=values, columns=np.asarray(names))
        result, result_names = saved.saved_minute(stream.getvalue(), 4)
        self.assertEqual(result.tobytes(order='C'), values.tobytes(order='C')); self.assertEqual(result_names, names)
        for matrix in (np.asfortranarray(np.zeros((2, 2), dtype='f4')),
                       np.asfortranarray(np.zeros((2, 2), dtype=[('x', 'f8')])),
                       np.asfortranarray(np.array([['a', 'b'], ['c', 'd']], dtype=object))):
            stream = BytesIO(); np.savez_compressed(stream, values=matrix, columns=np.asarray(['a', 'b']))
            with patch.object(np, 'load', side_effect=AssertionError('NO_ALLOCATION')) as load:
                with self.assertRaises(ValueError): saved.saved_minute(stream.getvalue(), 2)
            load.assert_not_called()
        EVIDENCE['parser'] = dict(function_AST_SHA256=digest(actual.encode()),
            reviewed_file_SHA256=digest(reference.read_bytes()), seeded_C_F_value_bit_cases=count,
            genuine_default_polars_Fortran_writer_passed=True, hostile_preallocation_rejections=3)

    def test_native40_raw100_retention_and_resealed_corruptions_all_tiers(self):
        native = generated.native_reference()
        from saved_native_reconciliation import reconcile_saved_native
        sequence = [('BUY', '.003', '10001'), ('BUY', '.002', '10003'), ('BUY', '.002', '10007'),
                    ('SELL', '.001', '10009'), ('BUY', '.015', '10011')]
        findings = {}
        for tier in ('LOW', 'MID', 'HIGH'):
            plain = native.V2.grid.make_account(tier, 'BASE27')
            account = native.ExpansionAccount(plain.config, symbols=native.S,
                instrument_profiles=plain.instrument_profiles, generated_scope=native.GENERATED, tier_name=tier)
            for index, (side, quantity, mid) in enumerate(sequence):
                signal = index * 3 * native.MINUTE; event = signal + native.MINUTE + 1
                marks(account, event - 1)
                account.execute_fill('BTCUSDT', side, quantity, event, signal, 'INDEPENDENT_GENERATED_' + str(index),
                    execution_mid_price=mid, quote_available_us=event - 1, available_quantity=quantity)
            audit = native.V2.OWNED.export_tree(account.snapshot())
            proof = reconcile_saved_native(audit, expected_continuation_version=native.VERSION)
            self.assertTrue(proof['passed']); self.assertFalse(proof['tolerance_or_epsilon_used'])
            residuals = proof['raw_precision100_stored_delta_terminal_residuals']
            self.assertTrue(proof['rounded_subtraction_rows'] or Decimal(residuals['free_cash'])
                or any(Decimal(x) for x in residuals['isolated'].values()))
            def tiny(value):
                with localcontext() as ctx:
                    ctx.prec = 100
                    return str(Decimal(value) + Decimal('1e-40'))
            mutations = {
                'cash_plus_one': lambda a: a.__setitem__('free_cash', str(Decimal(a['free_cash']) + 1)),
                'cash_plus_1e40': lambda a: a.__setitem__('free_cash', tiny(a['free_cash'])),
                'debt_plus_1e40': lambda a: a.__setitem__('unpaid_liability', tiny(a['unpaid_liability'])),
                'margin_plus_1e40': lambda a: a['positions']['BTCUSDT'].__setitem__('isolated_balance', tiny(a['positions']['BTCUSDT']['isolated_balance'])),
                'basis_wrong': lambda a: a['positions']['BTCUSDT'].__setitem__('entry_price', '1'),
                'ledger_cash_delta_wrong': lambda a: a['financial_ledger'][0].__setitem__('free_cash_delta', '0'),
                'ledger_event_kind_wrong': lambda a: a['financial_ledger'][0].__setitem__('kind', 'NATIVE_MARK_RISK'),
                'fee_wrong': lambda a: a['trades'][0]['decimal_strings'].__setitem__('fee_amount', '0'),
                'weighted_basis_wrong': lambda a: a['trades'][1]['decimal_strings'].__setitem__('entry_price_after', '1'),
                'fee_config_wrong': lambda a: a['config'].__setitem__('fee_rate', '0.001'),
                'realized_total_wrong': lambda a: a['totals'].__setitem__('realized_PnL', '1'),
                'transfer_added': lambda a: a['transfer_journal'].append({'amount': '1'}),
                'topup_enabled': lambda a: a['contract'].__setitem__('topup_enabled', True),
            }
            rejected = {}
            for name, mutate in mutations.items():
                bad = deepcopy(audit); mutate(bad)
                with self.assertRaises(ValueError) as caught:
                    reconcile_saved_native(bad, expected_continuation_version=native.VERSION)
                rejected[name] = str(caught.exception)
            findings[tier] = dict(generated_only=True, every_native40_event_exact=True,
                raw100_diagnostic_retained=True, raw100_residuals=residuals,
                corruption_negatives_rejected=rejected, transfer_rows=len(account.transfer_journal))
        EVIDENCE['native40'] = findings


if __name__ == '__main__':
    unittest.main()
