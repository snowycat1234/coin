"""Final read-only metadata envelope audit and non-authorizing packet seal."""
from hashlib import sha256
import json
from pathlib import Path
import shlex
import sys

ROOT = Path(__file__).resolve().parents[1]
OUT = Path(__file__).resolve().parent
AUTHOR = ROOT / 'original_cs_mom21_D_remaining9_financial_20261015_v1'
sys.path.insert(0, str(AUTHOR))
import cs_common as c
import cs_entry as entry
import cs_finance_gate as gate


def pin(path):
    raw = path.read_bytes()
    return dict(path=str(path.relative_to(ROOT)), SHA256=sha256(raw).hexdigest(), bytes=len(raw))


def main():
    expected = {
        'ROOT_REMAINING9_GO_INVALID_TEMPLATE.json':'a19e093f08c05fb57cc69ac2d82acd9ccadf834f6642ab0aa1cf8e1353fb7f89',
        'LAUNCH_REMAINING9_FINANCIAL_COMMAND.txt':'810c650e5211db8f17eb7ee45ac4cb993aba68253a11c5875f5d7f14f94174be',
        'FINANCIAL_REVIEW_HANDOFF.json':'0c0a0eec726b5fc8a1205385739adb07cb9cdf0d73b05d0908889c3e1ecac923',
    }
    author_pins = {name:pin(AUTHOR/name) for name in expected}
    assert all(author_pins[name]['SHA256'] == digest for name,digest in expected.items())
    prep_path=ROOT/'original_cs_mom21_D_remaining9_source_20261015_v3/source_attempts/REMAINING9_attempt002/PREPARATION.json'
    prep_raw=c.exact(prep_path,'ffe53374fbdc4ab79f4e0445849925a597f706ad1de4406137deb98b1eb7d871')
    prep=entry.validate_preparation_metadata(prep_raw)
    review=c.exact(OUT/'INDEPENDENT_FINANCIAL_ADMISSION_REVIEW_RECEIPT.json','18468d56a0bac8c12c15fb839909df48f96f818cf2feb7dbe1284771fc4cfc47')
    native=c.exact(OUT/'INDEPENDENT_NATIVE_REVIEW_RECEIPT.json','3a588a7b94a8430ad04139c7e9a3c03143f777873e77af4204cf558046a50850')
    prepared=c.exact(ROOT/'original_cs_mom21_D_remaining9_saved_source_target_independent_review_20261015_v1/INDEPENDENT_PREPARED_SOURCE_TARGET_REVIEW.json','453066c4929e73545085319c2760dc5b0fb8306fc8e326563fb7b349dee0c140')
    template=(AUTHOR/'ROOT_REMAINING9_GO_INVALID_TEMPLATE.json').read_bytes()
    try:
        gate.validate(prep_raw,template,c.sha(template),review,c.sha(review),prepared,c.sha(prepared),native,c.sha(native))
    except ValueError as error:
        assert str(error)=='EXACT_NEW_CS_FINANCIAL_ROOT_AUTHORITY_REQUIRED',repr(error)
    else:
        raise AssertionError('INVALID_TEMPLATE_MUST_NOT_AUTHORIZE_EXECUTION')
    hand=c.exact_object((AUTHOR/'FINANCIAL_REVIEW_HANDOFF.json').read_bytes())
    command=(AUTHOR/'LAUNCH_REMAINING9_FINANCIAL_COMMAND.txt').read_text().strip()
    assert hand['command']==command and hand['command_pin']['SHA256']==c.sha((command+'\n').encode())
    assert hand['invalid_template_SHA256']==c.sha(template)
    fixed=dict(source_code_manifest_SHA256=gate.SOURCE_CODE_SHA256,
        financial_code_manifest_SHA256=gate.code_identity(),native_review_SHA256=c.sha(native),
        combined_review_SHA256=c.sha(review),prepared_review_SHA256=c.sha(prepared),
        preparation_SHA256=c.sha(prep_raw),final_fake_probe_SHA256='0d3d288bd1c2f546fc3f2b37736b360bc49fac96ab91f1ceca7a1ee348388ef5',
        first6_excluded=True,fresh_genesis_only=True,actual_launch_performed=False,
        actual_claims_written=0,real_GO_written=False,source_and_targets_rebuilt=False,
        financial_formulas_changed=False,partial2021_annualized=False,annual_wallets_compounded=False,
        prior_CS_failed_claim_recovery_dependencies_required=False,worker_CPUs=[4,5],maximum_workers=2,
        stable_claim_registry='original_cs_mom21_D_20261015_v4/EXECUTION_CLAIMS')
    assert all(c.canonical(hand.get(key))==c.canonical(value) for key,value in fixed.items())
    assert hand['ordered_financial_cells']==list(entry.tranche_cells(entry.REMAINING9))
    words=shlex.split(command);assert words[6:9]==['taskset','-c','4,5']
    assert words[9]==str(ROOT/'coin_partial_restore_20261014/.venv/bin/python')
    assert words[10:12]==['-B',str(AUTHOR/'run_cs.py')]
    options=words[12:];assert len(options)%2==0
    args=dict(zip(options[::2],options[1::2]));assert len(args)==len(options)//2
    assert set(args)=={'--preparation','--preparation-sha','--go','--go-sha','--review','--review-sha',
        '--prepared-review','--prepared-review-sha','--native-review','--native-review-sha',
        '--source-go','--source-go-sha','--source-review','--source-review-sha','--output'}
    assert args['--preparation']==str(prep_path.parent) and args['--preparation-sha']==c.sha(prep_raw)
    assert args['--go']==str(AUTHOR/'ROOT_REMAINING9_FINANCIAL_APPROVED_20261015.json')
    assert args['--go-sha']=='REPLACE_WITH_FRESH_ROOT_APPROVED_GO_SHA256'
    assert args['--review']==str(OUT/'INDEPENDENT_FINANCIAL_ADMISSION_REVIEW_RECEIPT.json') and args['--review-sha']==c.sha(review)
    assert args['--native-review']==str(OUT/'INDEPENDENT_NATIVE_REVIEW_RECEIPT.json') and args['--native-review-sha']==c.sha(native)
    assert args['--prepared-review']==str(ROOT/'original_cs_mom21_D_remaining9_saved_source_target_independent_review_20261015_v1/INDEPENDENT_PREPARED_SOURCE_TARGET_REVIEW.json')
    assert args['--prepared-review-sha']==c.sha(prepared)
    assert args['--source-go']==str(prep_path.parent/'SOURCE_STAGE_AUTHORIZATION.json') and args['--source-go-sha']==prep['source_stage_GO_SHA256']
    assert args['--source-review']==str(prep_path.parent/'SOURCE_INDEPENDENT_REVIEW.json') and args['--source-review-sha']==prep['source_review_SHA256']
    assert args['--output']==str(AUTHOR/'financial_attempts/REMAINING9_attempt001')
    reads=c.exact_object((AUTHOR/'RUNTIME_READ_CLASSIFICATION.json').read_bytes())
    assert reads['prepared_artifact_pins']==prep['artifacts']
    assert reads['financial_code_manifest_SHA256']==gate.code_identity()
    assert reads['source_code_manifest_SHA256']==gate.SOURCE_CODE_SHA256
    assert reads['prior_CS_failed_claim_or_attempt_bodies_required'] is False
    assert reads['claim_runtime']['stable_registry']==hand['stable_claim_registry']
    assert reads['ordered_cells']==list(entry.tranche_cells(entry.REMAINING9))
    for year,contract in entry.contracts()['years'].items():
        if year in ('2021','2024','2025'):
            assert reads['canonical_source_runtime_reads_by_year'][year]==contract['read_files']
    inventory_path=AUTHOR/'GENERATED_POOL_FINAL_EXERCISED_CODE/PROBE_CODE_INVENTORY.json'
    inventory=c.exact_object(c.exact(inventory_path,'559e7f4142818c6bd739fcf7b7f1d5342b1d7d0c7c670a2515aa7771e3cb7e7c'))
    assert inventory['status']=='COMPLETED_FINAL_SYNTHETIC_PROBE_EXIT0'
    assert inventory['financial_code_manifest_SHA256']==gate.code_identity()
    assert inventory['generated_resource_probe_SHA256']==hand['final_fake_probe_SHA256']
    for name,value in inventory['exercised_component_pins'].items():
        assert pin(AUTHOR/name)['SHA256']==value['SHA256']
        snapshot=c.exact_object((inventory_path.parent/'FINANCIAL_CODE_MANIFEST.json').read_bytes())
        assert snapshot['files'][name]==value
    for name in ('CODE_MANIFEST.json','FINANCIAL_CODE_MANIFEST.json'):
        assert (inventory_path.parent/name).read_bytes()==(AUTHOR/name).read_bytes()
    for name in ('RUNTIME_READ_CLASSIFICATION.json','PREPARED_METADATA_BINDING_CHECK.json','FINAL_GENERATED_GATE_SUMMARY.json'):
        author_pins[name]=pin(AUTHOR/name)
    author_pins['GENERATED_POOL_FINAL_EXERCISED_CODE/PROBE_CODE_INVENTORY.json']=pin(inventory_path)
    result=dict(schema='INDEPENDENT_REMAINING9_FINAL_ENVELOPE_REVIEW_V1',status='PASS',
        financial_code_manifest_SHA256=gate.code_identity(),source_code_manifest_SHA256=gate.SOURCE_CODE_SHA256,
        native_review_SHA256=c.sha(native),financial_admission_review_SHA256=c.sha(review),
        final_author_metadata_pins=author_pins,all_external_review_hash_bindings_accepted=True,
        invalid_template_rejected_at_exact_root_authority_gate=True,
        command_requires_fresh_root_GO_SHA256=True,exact_final_probe_manifest_snapshot_and_current_component_pins_verified=True,
        stable_registry_and_shared_global_lease_preserved=True,
        actual_source_or_target_bodies_read=False,actual_scopes_providers_accounts_claims_and_GO_writes=0,
        financial_execution_authorized=False,publication_actions=0,
        nonfinal_harness_events_retained=['Initial system interpreter lacked Polars; existing project venv used.',
            'Draft CLI sweep failed closed across an author manifest refresh; final12 scenarios all passed unchanged49d6.',
            'Pre-envelope review draft field label clarified to explicitly say1e-40; prior drafts retained.'])
    final_path=OUT/'INDEPENDENT_FINAL_ENVELOPE_REVIEW.json'
    final_path.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    names=[p for p in OUT.iterdir() if p.is_file() and p.name!='FINAL_ENVELOPE_REVIEW.log' and (p.name.startswith('FINAL_') or p.name.startswith('INDEPENDENT_')
        or p.name.startswith('STATIC_') or p.name=='FINANCIAL_GENERATED_TEST_RECEIPT.json' or p.suffix=='.py')]
    packet=dict(schema='INDEPENDENT_REMAINING9_NATIVE_FINANCIAL_ADMISSION_REVIEW_PACKET_PINS_V1',
        status='PASS_REVIEW_ONLY_FRESH_ROOT_GO_STILL_REQUIRED',financial_execution_authorized=False,
        financial_code_manifest_SHA256=gate.code_identity(),
        files={p.name:pin(p) for p in sorted(names)},final_author_metadata_pins=author_pins)
    packet_path=OUT/'AUDIT_DELIVERABLE_PINS.json'
    packet_path.write_text(json.dumps(packet,indent=2,sort_keys=True)+'\n')
    print(json.dumps(dict(status='PASS_REVIEW_COMPLETE_NO_EXECUTION_AUTHORITY',
        final_envelope_review=pin(final_path),packet=pin(packet_path)),sort_keys=True))


if __name__=='__main__':
    main()
