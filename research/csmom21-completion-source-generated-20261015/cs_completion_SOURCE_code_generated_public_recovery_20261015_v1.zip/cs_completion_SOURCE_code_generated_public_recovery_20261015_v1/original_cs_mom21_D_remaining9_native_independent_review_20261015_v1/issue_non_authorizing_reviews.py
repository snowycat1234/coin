"""Issue code/probe review evidence only. This never creates a financial GO."""
from hashlib import sha256
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
OUT = Path(__file__).resolve().parent
AUTHOR = ROOT / 'original_cs_mom21_D_remaining9_financial_20261015_v1'
sys.path.insert(0, str(AUTHOR))
import cs_common as c
import cs_entry as entry
import cs_finance_gate as gate


def pin(path):
    raw = path.read_bytes()
    return dict(path=str(path.relative_to(ROOT)), SHA256=sha256(raw).hexdigest(), bytes=len(raw))


def write(name, value):
    path = OUT / name
    assert not path.exists(), 'REVIEW_RECEIPTS_ARE_IMMUTABLE'
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')
    return pin(path)


def main():
    financial = gate.code_identity()
    assert financial == '49d6a90d917e29011a8303986c79d96df943a1dd6624eda29ae7aa54dec57162'
    preparation_path = ROOT / 'original_cs_mom21_D_remaining9_source_20261015_v3/source_attempts/REMAINING9_attempt002/PREPARATION.json'
    preparation_raw = c.exact(preparation_path, 'ffe53374fbdc4ab79f4e0445849925a597f706ad1de4406137deb98b1eb7d871')
    prep = entry.validate_preparation_metadata(preparation_raw)
    static = c.exact_object((OUT / 'STATIC_METADATA_TRANSPORT_REVIEW.json').read_bytes())
    probe = c.exact_object((OUT / 'INDEPENDENT_GENERATED_PROBE_REVIEW.json').read_bytes())
    suite = c.exact_object((OUT / 'FINANCIAL_GENERATED_TEST_RECEIPT.json').read_bytes())
    assert static['status'] == probe['status'] == suite['status'] == 'PASS'
    assert static['financial_code_manifest_SHA256'] == probe['financial_code_manifest_SHA256'] == suite['financial_code_manifest_SHA256'] == financial
    assert suite['tests'] == 30 and suite['errors'] == suite['failures'] == 0
    assert not any(suite['observed'].values())
    assert suite['CPU_affinity'] == [3] and all(row == [3] for row in suite['all_TID_affinities'])
    assert suite['loaded_input_seals_remaining'] == suite['actual_financial_scope_seals_remaining'] == suite['internally_generated_native_input_seals_remaining'] == 0
    cli = []
    for year in (2021, 2024, 2025):
        for mode in ('positive', 'capture_failure', 'loaded_validation_failure', 'guard_exit_failure'):
            path = OUT / ('FINAL_INDEPENDENT_CLI_' + str(year) + '_' + mode + '.json')
            value = c.exact_object(path.read_bytes())
            assert value['status'] == 'PASS_REAL_FRESH_CLI_GENERATED_EXECUTABLE_GO_UNCHANGED_GUARD'
            assert value['financial_code_manifest_SHA256'] == financial
            assert value['source_code_manifest_SHA256'] == gate.SOURCE_CODE_SHA256
            assert value['year'] == year and value['mode'] == mode
            assert not any(value['positive_guard_counters'].values())
            assert value['authority_serialization_negative_counter'] == 1
            assert value['token_negative_cases'] == 7 and value['literal_funding_offset_us'] == 15000
            assert value['actual_source_reads'] == value['actual_source_scopes'] == value['historical_scopes'] == value['providers'] == value['accounts'] == value['claims'] == 0
            cli.append(pin(path))
    common = dict(status='PASS', source_code_manifest_SHA256=gate.SOURCE_CODE_SHA256,
        financial_code_manifest_SHA256=financial, scope_manifest_SHA256=entry.manifest_sha(),
        source_contract_map_SHA256=entry.contract_sha(), tranche=entry.REMAINING9,
        ordered_cells=list(entry.tranche_cells(entry.REMAINING9)),
        native_financial_gate_reviewed=True, financial_execution_authorized=False,
        actual_source_or_target_bodies_read=False, old_D_GO_reused_as_authority=False,
        source_capture_or_actual_array_reparse_calls=0, actual_target_or_covariance_rebuild_calls=0,
        actual_historical_scopes_created=0, actual_provider_iterations=0,
        actual_accounts_created_or_advanced=0, actual_claims_created=0, actual_financial_GO_writes=0,
        reviewer_actual_process_launches=0, publication_actions=0,
        source_preparation_reused_exact=True, FIRST6_and_recovery_excluded=True,
        ordinary_fresh_genesis_claims_only_reviewed=True,
        stable_cross_version_claim_registry='original_cs_mom21_D_20261015_v4/EXECUTION_CLAIMS',
        original_financial_D_rules_code_objects_unchanged=True,
        native40_every_event_authoritative=True, raw100_residual_diagnostic_preserved=True,
        genuine_resealed_corruption_negatives=39, tiny_1e_minus40_corruption_negatives=9,
        generated_native_and_metadata_tests=30, real_CLI_fake_storage_year_mode_cases=12,
        no_optional_predictor_tuning_or_framework=True,
        quality2024=dict(derived_UNKNOWN_cells=10, generic_interval_guard_installed_before_native_risk=True,
            exact_original_D_all_tier_generated_equivalence=True,
            original_genuine_observation_us=1723456920000000,
            contract_genuine_recovery_available_us=1723457100000000,
            standalone_saved_recovery_price_row_witness_present=False,
            scope='Qualified contract and successful guarded-source lineage; no fresh raw-row audit or invented recovery witness'),
        endpoint2021=dict(qualified_terminal_trade_and_mark_bits_retained=True,
            final_open_us=1640995140000000, final_available_us=1640995200000000,
            end_plus_one_is_witness_only=True, native_execution_clock_extended=False,
            calendar_days=274, annualized=False),
        quality2025_empty_and_canonical_NPZ_reuse_unchanged=True,
        literal_funding_event_clocks_preserved=True,
        qualified_maximum_funding_offset_us={'2021':47000, '2024':15000, '2025':16000},
        numerical_pools=1, reviewer_CPU_affinity=[3], annual_wallets_compounded=False,
        bounded_drain_code_SHA256='226b1efc7ebe0b4b607b34237240a75a9a6823a74a39345158e18b4abdeced3a',
        reporting_and_drain_independent_review_SHA256='06605d2e59923d5d36349ee3ab81b2f4108d50af780844e995a660fbf71c80be',
        evidence=dict(static=pin(OUT/'STATIC_METADATA_TRANSPORT_REVIEW.json'),
            generated_suite=pin(OUT/'FINANCIAL_GENERATED_TEST_RECEIPT.json'),
            independent_corruption_and_parser=pin(OUT/'FINAL_INDEPENDENT_GENERATED_CORRUPTION_AND_PARSER.json'),
            generated_probe_review=pin(OUT/'INDEPENDENT_GENERATED_PROBE_REVIEW.json'),
            real_CLI_cases=cli),
        limitations=['Generated resource evidence certifies this tiny probe, not the annual resource envelope.',
            'This review grants no launch, source capture, provider iteration, account execution, claim, retry, or GO authority.',
            'Each actual saved terminal and quality impact still requires its own exact evidence audit.'])
    native = dict(common, schema=gate.NATIVE_REVIEW_SCHEMA,
        generated_two_worker_probe_passed=True, worker_CPUs=[4,5], maximum_observed_live_workers=2,
        generated_resource_probe_SHA256=probe['profile']['SHA256'], generated_resource_probe=probe['profile'],
        annual_resource_envelope_certified=False)
    native_pin = write('INDEPENDENT_NATIVE_REVIEW_RECEIPT.json', native)
    gate.native_review((OUT/'INDEPENDENT_NATIVE_REVIEW_RECEIPT.json').read_bytes(), native_pin['SHA256'])
    combined = dict(common, schema=gate.REVIEW_SCHEMA, preparation_SHA256=c.sha(preparation_raw),
        source_stage_GO_SHA256=prep['source_stage_GO_SHA256'],
        prepared_source_target_review_SHA256='453066c4929e73545085319c2760dc5b0fb8306fc8e326563fb7b349dee0c140',
        native_generated_review_SHA256=native_pin['SHA256'],
        real_CLI_generated_GO_guard_integration_reviewed=True,
        remaining9_all_source_calendar_and_quality_shapes_reviewed=True)
    combined_pin = write('INDEPENDENT_FINANCIAL_ADMISSION_REVIEW_RECEIPT.json', combined)
    print(json.dumps(dict(status='NON_AUTHORIZING_REVIEW_RECEIPTS_CREATED_ENVELOPE_AUDIT_PENDING',
        native_review=native_pin, financial_admission_review=combined_pin), sort_keys=True))


if __name__ == '__main__':
    main()
