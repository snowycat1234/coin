"""Review only code and already-qualified metadata; never read market arrays."""
import ast
from hashlib import sha256
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
AUTHOR = ROOT / 'original_cs_mom21_D_remaining9_financial_20261015_v1'
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(AUTHOR))
import cs_common as c
import cs_entry as entry
import cs_finance_gate as gate


def checked(relative, expected):
    path = ROOT / relative
    raw = path.read_bytes()
    assert sha256(raw).hexdigest() == expected, relative
    return dict(path=relative, SHA256=expected, bytes=len(raw))


def function(path, name):
    tree = ast.parse(path.read_bytes())
    return next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == name)


def main():
    pins = {}
    for name, expected in (
        ('original_cs_mom21_D_remaining9_source_20261015_v3/CODE_MANIFEST.json', 'c3d09d50ef306b151fad5de6b9ea917f52d92369db5f2177314ac8da40e0e2f3'),
        ('original_cs_mom21_D_remaining9_source_20261015_v3/SOURCE_DELIVERABLE_PINS.json', 'c067bb6e932079dd2362b6c125d7f61131efd67726eafe671a77c6a23de20732'),
        ('original_cs_mom21_D_remaining9_source_20261015_v3/source_attempts/REMAINING9_attempt002/PREPARATION.json', 'ffe53374fbdc4ab79f4e0445849925a597f706ad1de4406137deb98b1eb7d871'),
        ('original_cs_mom21_D_remaining9_saved_source_target_independent_review_20261015_v1/INDEPENDENT_PREPARED_SOURCE_TARGET_REVIEW.json', '453066c4929e73545085319c2760dc5b0fb8306fc8e326563fb7b349dee0c140'),
        ('original_cs_mom21_D_remaining9_saved_source_target_independent_review_20261015_v1/AUDIT_DELIVERABLE_PINS.json', 'af392b78f923488e0a86f2a2d5cae9f027a9526653495fab922872a9dd1cd31b'),
        ('cs_saved_minute_reporting_repair_20261015_v1/cs_saved_reporting.py', 'b3073f4f4933ebdfccb48b8e130e2a6b2ec14565a7822d0190c75eb719ed2cd5'),
        ('cs_saved_minute_reporting_repair_20261015_v2/bounded_drain.py', '226b1efc7ebe0b4b607b34237240a75a9a6823a74a39345158e18b4abdeced3a'),
        ('cs_saved_minute_reporting_repair_independent_review_20261015/INDEPENDENT_REPORTING_AND_DRAIN_REPAIR_REVIEW.json', '06605d2e59923d5d36349ee3ab81b2f4108d50af780844e995a660fbf71c80be'),
    ):
        pins[name] = checked(name, expected)
    financial = gate.code_identity()
    assert financial == '49d6a90d917e29011a8303986c79d96df943a1dd6624eda29ae7aa54dec57162'
    source = entry.code_identity()
    assert source == gate.SOURCE_CODE_SHA256
    assert (AUTHOR / 'bounded_drain.py').read_bytes() == (ROOT / 'cs_saved_minute_reporting_repair_20261015_v2/bounded_drain.py').read_bytes()
    original_parser = function(ROOT / 'cs_saved_minute_reporting_repair_20261015_v1/cs_saved_reporting.py', 'saved_minute')
    transported_parser = function(AUTHOR / 'cs_saved.py', 'saved_minute')
    assert ast.dump(original_parser, include_attributes=False) == ast.dump(transported_parser, include_attributes=False)
    provenance = c.exact_object((AUTHOR / 'NATIVE_PROCESS_PROVENANCE.json').read_bytes())
    runtime_functions = {}
    for name, record in provenance['selected_functions'].items():
        original = function(ROOT / provenance['source'], name)
        transported = function(AUTHOR / 'cs_process_runtime.py', name)
        old_ast = ast.dump(original, include_attributes=False)
        assert sha256(old_ast.encode()).hexdigest() == record['original_AST_SHA256'], name
        for old, new in provenance['substitutions'].items():
            old_ast = old_ast.replace(old, new)
        new_ast = ast.dump(transported, include_attributes=False)
        assert old_ast == new_ast, name
        runtime_functions[name] = dict(exact_after_declared_launcher_and_scope_filename_substitutions=True,
            transported_AST_SHA256=sha256(new_ast.encode()).hexdigest())
    prep_path = ROOT / 'original_cs_mom21_D_remaining9_source_20261015_v3/source_attempts/REMAINING9_attempt002/PREPARATION.json'
    prep_raw = prep_path.read_bytes(); prep = entry.validate_preparation_metadata(prep_raw)
    review_path = ROOT / 'original_cs_mom21_D_remaining9_saved_source_target_independent_review_20261015_v1/INDEPENDENT_PREPARED_SOURCE_TARGET_REVIEW.json'
    review_raw = review_path.read_bytes()
    gate.prepared_review(prep_raw, review_raw, '453066c4929e73545085319c2760dc5b0fb8306fc8e326563fb7b349dee0c140')
    review = c.exact_object(review_raw)
    years = {}
    for year in (2021, 2024, 2025):
        info = review['per_year_findings'][str(year)]
        years[str(year)] = dict(calendar_days=info['calendar_days'],
            maximum_observed_8h_offset_us=info['maximum_observed_8h_offset_us'],
            literal_funding_clock_preserved=info['literal_funding_clock_preserved'],
            saved_qualified_array_hashes_reused_without_array_reads=True)
    result = dict(schema='INDEPENDENT_REMAINING9_STATIC_METADATA_TRANSPORT_REVIEW_V1', status='PASS',
        source_code_manifest_SHA256=source, financial_code_manifest_SHA256=financial,
        scope_manifest_SHA256=entry.manifest_sha(), source_contract_map_SHA256=entry.contract_sha(),
        tranche=entry.REMAINING9, ordered_cells=list(entry.tranche_cells(entry.REMAINING9)),
        pins=pins, runtime_function_equivalence=runtime_functions, prepared_review_gate_compatibility=True,
        per_year_qualified_metadata_reuse=years,
        quality2024=dict(derived_UNKNOWN_cells=10, original_genuine_observation_us=1723456920000000,
            contract_genuine_recovery_available_us=1723457100000000,
            standalone_saved_recovery_price_row_witness_present=False,
            recovery_scope='Qualified contract and previously successful guarded source path; no fresh raw-row audit claimed'),
        partial2021_annualized=False, annual_wallets_compounded=False,
        actual_source_or_target_bodies_read=False, actual_source_capture_calls=0,
        actual_target_rebuild_calls=0, actual_historical_scopes_created=0,
        actual_provider_iterations=0, actual_accounts_created_or_advanced=0,
        actual_claims_or_GO_writes=0, publication_actions=0)
    (OUT / 'STATIC_METADATA_TRANSPORT_REVIEW.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps(dict(status=result['status'], financial_code_manifest_SHA256=financial,
        runtime_functions_verified=len(runtime_functions), exact_cells=len(prep['cells']))))


if __name__ == '__main__':
    main()
