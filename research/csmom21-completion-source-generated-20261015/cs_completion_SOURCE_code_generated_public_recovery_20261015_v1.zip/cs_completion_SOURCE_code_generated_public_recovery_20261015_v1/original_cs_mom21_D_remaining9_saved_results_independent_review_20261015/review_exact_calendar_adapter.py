"""Independent generated/read-only exact-calendar reporting checks. No account replay."""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','POLARS_MAX_THREADS','VECLIB_MAXIMUM_THREADS'):os.environ[k]='1'
os.sched_setaffinity(0,{0})
import ast,inspect,importlib.util,json,io,zipfile
from pathlib import Path
from hashlib import sha256
from unittest.mock import patch
import numpy as np
import polars as pl
import review_saved_cs as r
ROOT=r.ROOT;OUT=r.OUT;REPAIR=ROOT/'cs_saved_calendar_exact_20261015_v1/cs_saved_calendar.py'
EXPECTED='0a0fc82a6740e785f333a05705de8f4156adfcacfd6aa094c950aa6ff02d57f7'
assert r.digest(REPAIR)==EXPECTED
spec=importlib.util.spec_from_file_location('independent_cs_saved_calendar',REPAIR);fixed=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixed)
def astfn(fn):return ast.parse(inspect.getsource(fn)).body[0]
def dump(a):return ast.dump(a,include_attributes=False)
def archive(values,columns):
 b=io.BytesIO();np.savez_compressed(b,values=values,columns=np.asarray(columns));return b.getvalue()
tests=[]
FROZEN_WRITER_SOURCE=inspect.getsource(r.runner.case)
with r.ReviewBoundary() as boundary:
 original_funcs={n:v for n,v in vars(r.saved).items() if inspect.isfunction(v) and v.__module__==r.saved.__name__}
 for n,fn in original_funcs.items():
  old=astfn(fn);new=astfn(getattr(fixed,n))
  if n=='saved_minute':
   assert old.body[1:] and dump(ast.Module(body=old.body[1:],type_ignores=[]))==dump(ast.Module(body=new.body[1:],type_ignores=[]))
   assert len(new.args.kwonlyargs)==1 and new.args.kwonlyargs[0].arg=='cell_id' and new.args.kw_defaults==[None]
  elif n=='validate_saved_terminal':
   calls=[a for a in ast.walk(new) if isinstance(a,ast.Call) and isinstance(a.func,ast.Name) and a.func.id=='saved_minute']
   assert len(calls)==1 and len(calls[0].keywords)==1 and calls[0].keywords[0].arg=='cell_id' and dump(calls[0].keywords[0].value)==dump(ast.Name(id='cell_id',ctx=ast.Load()))
   calls[0].keywords=[];assert dump(old)==dump(new)
  else:assert dump(old)==dump(new),n
 tests.append(dict(name='AST_ALL_FROZEN_FUNCTIONS_AND_CHECKS_IDENTICAL_EXCEPT_DECLARED_ROW_BOUND_AND_CALL_KEYWORD',passed=True,functions=len(original_funcs)))
 writer_source=FROZEN_WRITER_SOURCE;writer_ast=ast.parse(writer_source);writers=[x for x in ast.walk(writer_ast) if isinstance(x,ast.Call) and isinstance(x.func,ast.Attribute) and x.func.attr=='savez_compressed']
 assert len(writers)==1;statement=ast.Expr(value=writers[0]);statement=ast.fix_missing_locations(statement);writer_code=compile(ast.Module(body=[statement],type_ignores=[]),str(OUT/'ACTUAL_FROZEN_WRITER_AST'),'exec')
 seam=dict(frozen_writer_file=r.pin(r.runner.__file__),function_source_SHA256=sha256(writer_source.encode()).hexdigest(),statement_AST=ast.dump(statement,include_attributes=False),statement_AST_SHA256=sha256(ast.dump(statement,include_attributes=False).encode()).hexdigest())
 for year,days in ((2021,274),(2023,365),(2024,366)):
  rows=days*1440;cell=f'{year}_CSMOM21_COMMON_TIER_LOW_D';assert fixed.admitted_calendar_minutes(cell)==rows
  values=pl.DataFrame({'x':np.arange(rows,dtype=np.float64),'y':np.full(rows,0.25),'z':np.full(rows,-7.)}).to_numpy()
  assert values.flags.f_contiguous;columns=['x','y','z'];directory=OUT/f'GENERATED_REAL_POLARS_WRITER_{year}';directory.mkdir()
  exec(writer_code,dict(np=np,directory=directory,values=values,columns=columns))
  raw=(directory/'MINUTE.npz').read_bytes();before=sha256(raw).hexdigest();read,names=fixed.saved_minute(raw,rows,cell_id=cell)
  assert names==columns and read.tobytes()==values.tobytes()
  original_failed=None
  try:r.saved.saved_minute(raw,rows)
  except ValueError as e:original_failed=str(e);assert year==2024 and original_failed=='BOUNDED_SAVED_NATIVE_MINUTES_REQUIRED'
  else:assert year!=2024
  assert before==r.digest(directory/'MINUTE.npz')
  for order in ('C','F'):
   control=np.array(values,order=order);b=archive(control,columns);v,c=fixed.saved_minute(b,rows,cell_id=cell);assert c==columns and v.tobytes()==values.tobytes()
  tests.append(dict(name='REAL_DEFAULT_POLARS_TO_NUMPY_EXACT_FROZEN_FINAL_WRITER_AND_C_F_CONTROLS',year=year,days=days,rows=rows,default_polars_fortran=True,writer=seam,generated_archive=r.pin(directory/'MINUTE.npz'),original_frozen_error=original_failed,unchanged_bytes=True,passed=True))
  del values,read
 for cell in r.load(r.EXEC/'ROOT_REMAINING9_FINANCIAL_APPROVED_20261015.json')['ordered_cells']:
  bound=fixed.admitted_calendar_minutes(cell)
  for rows in (-1,bound+1,True,1.,'1'):
   with patch.object(np,'load',side_effect=AssertionError('NUMPY_ALLOCATION_MUST_NOT_OCCUR')):
    try:fixed.saved_minute(b'',rows,cell_id=cell)
    except ValueError as e:assert str(e)=='BOUNDED_SAVED_NATIVE_MINUTES_REQUIRED'
    else:raise AssertionError((cell,rows))
 tests.append(dict(name='ALL_NINE_EXACT_CELL_PREALLOCATION_ROW_BOUNDS',passed=True,negative_cases=45))
 for invalid in (None,True,2024,'2020_CSMOM21_COMMON_TIER_LOW_D','2024_CSMOM21_COMMON_TIER_BAD_D'):
  with patch.object(np,'load',side_effect=AssertionError('NUMPY_ALLOCATION_MUST_NOT_OCCUR')):
   try:fixed.saved_minute(b'',1,cell_id=invalid)
   except ValueError:pass
   else:raise AssertionError(invalid)
 tests.append(dict(name='INVALID_EXTERNAL_CELL_IDENTITIES_REJECTED',passed=True,cases=5))
 base=np.arange(6,dtype=np.float64).reshape(3,2);raw=archive(base,['x','y'])
 for label,b,rows in [('TRUNCATED_ZIP',raw[:-20],3),('ROW_HEADER_MISMATCH',raw,2),('DUPLICATE_COLUMNS',archive(base,['x','x']),3),('NONFINITE',archive(np.array([[float('nan'),2.]]),['x','y']),1),('OBJECT',archive(np.array([[object(),2]],dtype=object),['x','y']),1)]:
  try:fixed.saved_minute(b,rows,cell_id='2024_CSMOM21_COMMON_TIER_LOW_D')
  except (ValueError,zipfile.BadZipFile):pass
  else:raise AssertionError(label)
 tests.append(dict(name='UNCHANGED_HOSTILE_ARCHIVE_HEADER_COLUMN_AND_FINITE_CHECKS',passed=True,cases=5))
receipt=dict(schema='INDEPENDENT_EXACT_CELL_CALENDAR_REPORTING_ADAPTER_GENERATED_REVIEW_V1',status='PASS_GENERATED_EXACT_CALENDAR_REPORTING_ADAPTER',adapter=r.pin(REPAIR),frozen_module=r.pin(r.saved.__file__),frozen_config=r.pin(r.config.__file__),frozen_financial_manifest=r.pin(r.EXEC/'FINANCIAL_CODE_MANIFEST.json'),tests=tests,default_real_Polars_actual_frozen_writer=True,source_market_arrays_reparsed=False,accounts_or_providers_or_claims_created=0,financial_replay_or_launch_permission=False,boundary=boundary.receipt(),reviewer_script=r.pin(__file__),CPU_affinity=sorted(os.sched_getaffinity(0)),numerical_pools=1)
print(json.dumps(r.save('INDEPENDENT_EXACT_CALENDAR_ADAPTER_GENERATED_REVIEW.json',receipt)),flush=True)
