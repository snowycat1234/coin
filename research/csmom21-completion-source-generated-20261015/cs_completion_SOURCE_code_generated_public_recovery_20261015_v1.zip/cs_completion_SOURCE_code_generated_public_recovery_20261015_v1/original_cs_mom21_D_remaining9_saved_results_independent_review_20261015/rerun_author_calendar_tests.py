import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','POLARS_MAX_THREADS','VECLIB_MAXIMUM_THREADS'):os.environ[k]='1'
os.sched_setaffinity(0,{0})
import importlib.util,tempfile,unittest,json
from pathlib import Path
import review_saved_cs as r
P=r.ROOT/'cs_saved_calendar_exact_20261015_v1/test_full_writer_calendar.py'
assert r.digest(r.ROOT/'cs_saved_calendar_exact_20261015_v1/cs_saved_calendar.py')=='0a0fc82a6740e785f333a05705de8f4156adfcacfd6aa094c950aa6ff02d57f7'
tmp=r.OUT/'AUTHOR_GENERATED_TEMP';tmp.mkdir();tempfile.tempdir=str(tmp)
spec=importlib.util.spec_from_file_location('independent_author_calendar_tests',P);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
with r.ReviewBoundary() as boundary:
 result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(m))
 assert result.wasSuccessful()
 data=dict(schema='INDEPENDENT_AUTHOR_EXACT_CALENDAR_REGRESSION_RERUN_V1',status='PASS',test_methods=result.testsRun,author_test_file=r.pin(P),adapter=r.pin(r.ROOT/'cs_saved_calendar_exact_20261015_v1/cs_saved_calendar.py'),temporary_directory_only_in_review=True,CPU_affinity=sorted(os.sched_getaffinity(0)),numerical_pools=1,boundary=boundary.receipt(),no_account_or_source_or_financial_replay=True,reviewer_script=r.pin(__file__))
print(json.dumps(r.save('INDEPENDENT_AUTHOR_CALENDAR_REGRESSION_RERUN.json',data)))
