"""Independent finite exact-four admission review. All runtime inputs invented.

Actual preparation and earlier reviews are read as metadata only. This script
does not create a real GO, open a canonical lease, claim a real cell, capture
source, construct a historical scope, or run an actual account/provider.
"""
import ast
from copy import deepcopy
import fcntl
from io import BytesIO
import json
import os
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch
import zipfile

ROOT=Path(__file__).resolve().parent.parent
PACKAGE=ROOT/'original_cs_mom21_D_remaining4_financial_20261015_v1'
OLD=ROOT/'original_cs_mom21_D_remaining9_financial_20261015_v1'
sys.path.insert(0,str(PACKAGE))
import numpy as np
import polars as pl
import cs_common as c
import cs_entry as entry
import cs_finance_gate as gate
import cs_claims as claims
import cs_config as config
import cs_saved as saved
import cs_verified_wires as verified
import cs_loader as loader
import cs_process_runtime as runtime
import run_cs
from test_four_control import bundle
from test_four_controller import combined

REVIEW=Path(__file__).resolve().parent
PREP=ROOT/'original_cs_mom21_D_remaining9_source_20261015_v3/source_attempts/REMAINING9_attempt002'
NATIVE=ROOT/'original_cs_mom21_D_remaining9_native_independent_review_20261015_v1/INDEPENDENT_NATIVE_REVIEW_RECEIPT.json'
PREPARED=ROOT/'original_cs_mom21_D_remaining9_saved_source_target_independent_review_20261015_v1/INDEPENDENT_PREPARED_SOURCE_TARGET_REVIEW.json'
SAVEDREV=ROOT/'original_cs_mom21_D_remaining9_saved_results_independent_review_20261015'
COUNTS={}

def snapshot(path):
    return {str(p.relative_to(path)):dict(SHA256=c.sha(p.read_bytes()),bytes=p.stat().st_size)
            for p in sorted(path.rglob('*')) if p.is_file()}

def reject(call, label):
    try:call()
    except (ValueError, RuntimeError, TypeError, zipfile.BadZipFile, EOFError, KeyError):
        COUNTS[label]=COUNTS.get(label,0)+1
    else:raise AssertionError('NEGATIVE_ACCEPTED:'+label)

def blob(values,columns):
    stream=BytesIO();np.savez_compressed(stream,values=values,columns=np.asarray(columns));return stream.getvalue()

class IndependentTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.prep,cls.artifacts=combined();cls.raw,cls.hashes=bundle(cls.prep)

    def validate(self,raw=None,hashes=None,prep=None):
        raw=self.raw if raw is None else raw
        hashes={k:c.sha(v) for k,v in raw.items()} if hashes is None else hashes
        return gate.validate(self.prep if prep is None else prep,raw['go'],hashes['go'],raw['review'],hashes['review'],
            raw['prepared-review'],hashes['prepared-review'],raw['native-review'],hashes['native-review'])

    def test_01_exact_identity_and_actual_supporting_metadata(self):
        self.assertEqual(gate.code_identity(),'33af99414b211828b960689bb5e210a7b3fea83ca7b9a4cdf5b0d4c7e0bfb339')
        self.assertEqual(c.sha((PACKAGE/'FINAL_AUTHOR_HANDOFF.json').read_bytes()),'12359ee5881850f9af19ff7b4e68a6a5b157a6c4a31df2a7472ab4ee84f4e5f4')
        self.assertEqual(entry.code_identity(),gate.SOURCE_CODE_SHA256)
        old_manifest=c.exact_object((OLD/'FINANCIAL_CODE_MANIFEST.json').read_bytes())
        new_manifest=c.exact_object((PACKAGE/'FINANCIAL_CODE_MANIFEST.json').read_bytes())
        changed=[name for name in old_manifest['files'] if (OLD/name).read_bytes()!=(PACKAGE/name).read_bytes()]
        self.assertEqual(set(changed),{'cs_admission.py','cs_claims.py','cs_finance_gate.py','cs_saved.py','cs_verified_wires.py','run_cs.py'})
        for name in ('cs_native.py','cs_loader.py','cs_process_runtime.py','bounded_drain.py','CODE_MANIFEST.json'):
            self.assertEqual((OLD/name).read_bytes(),(PACKAGE/name).read_bytes())
        for name,pin in c.exact_object((PACKAGE/'CODE_MANIFEST.json').read_bytes())['files'].items():
            self.assertEqual((OLD/name).read_bytes(),(PACKAGE/name).read_bytes())
        for name,pin in old_manifest['dependencies'].items():self.assertEqual(new_manifest['dependencies'][name],pin)
        prep=c.exact(PREP/'PREPARATION.json','ffe53374fbdc4ab79f4e0445849925a597f706ad1de4406137deb98b1eb7d871')
        pr=c.exact(PREPARED,'453066c4929e73545085319c2760dc5b0fb8306fc8e326563fb7b349dee0c140')
        nr=c.exact(NATIVE,'3a588a7b94a8430ad04139c7e9a3c03143f777873e77af4204cf558046a50850')
        gate.prepared_review(prep,pr,c.sha(pr));gate.native_review(nr,c.sha(nr))
        p=entry.validate_preparation_metadata(prep)
        sg=c.exact(PREP/'SOURCE_STAGE_AUTHORIZATION.json',p['source_stage_GO_SHA256'])
        sr=c.exact(PREP/'SOURCE_INDEPENDENT_REVIEW.json',p['source_review_SHA256'])
        entry.validate_source_authority_metadata(sg,c.sha(sg),sr,c.sha(sr))
        self.assertEqual(c.sha(c.exact(SAVEDREV/'INDEPENDENT_EXACT_CALENDAR_REPAIR_FINAL_REVIEW.json',gate.EXACT_CALENDAR_REVIEW_SHA256)),gate.EXACT_CALENDAR_REVIEW_SHA256)
        c.exact(SAVEDREV/'PARTIAL_REMAINING9_SAVED_REVIEW_RECEIPT.json',gate.PRIOR_SAVED_FIVE_REVIEW_SHA256)
        c.exact(ROOT/'cs_saved_calendar_exact_20261015_v1/cs_saved_calendar.py',gate.EXACT_CALENDAR_ADAPTER_SHA256)
        old_go=c.exact(OLD/'ROOT_REMAINING9_FINANCIAL_APPROVED_20261015.json',gate.OLD_REMAINING9_GO_SHA256)
        exitraw=c.exact(OLD/'financial_attempts/REMAINING9_attempt001/ROOT_OBSERVED_EXIT_CONFIRMED.json',gate.ROOT_OBSERVED_EXIT_SHA256)
        self.assertEqual(c.exact_object(exitraw)['observed_exit_code'],1)
        self.assertEqual(len(gate.ordered_cells()),4)
        excluded=gate.SEALED_FIVE+entry.tranche_cells(entry.FIRST6)
        self.assertEqual(len(excluded),11)
        registry=claims.registry_root()/claims.SCOPE_SHA
        for cell in excluded:self.assertTrue((registry/(cell+'.json')).is_file())
        for cell in gate.ordered_cells():self.assertFalse((registry/(cell+'.json')).exists())
        self.assertEqual(set(p['cells']),set(entry.tranche_cells(entry.REMAINING9)))
        COUNTS['actual_metadata_identity_checks']=1

    def test_02_independent_resealed_scope_and_authority_negatives(self):
        self.validate()
        good=c.exact_object(self.raw['go'])
        mutations={
          'all9_queue':lambda x:x.__setitem__('ordered_cells',list(entry.tranche_cells(entry.REMAINING9))),
          'all15_queue':lambda x:x.__setitem__('ordered_cells',[z['cell_id'] for z in config.cells()]),
          'reordered':lambda x:x.__setitem__('ordered_cells',list(gate.ordered_cells())[::-1]),
          'duplicate_queue':lambda x:x.__setitem__('ordered_cells',list(gate.ordered_cells())+[gate.ordered_cells()[0]]),
          'first6_bindings':lambda x:x['per_cell_input_binding_SHA256'].__setitem__(entry.tranche_cells(entry.FIRST6)[0],'0'*64),
          'sealed5_bindings':lambda x:x['per_cell_input_binding_SHA256'].__setitem__(gate.SEALED_FIVE[0],'0'*64),
          'scope_broadening':lambda x:x.__setitem__('other_cells_or_holdouts_authorized',True),
          'failed_recovery':lambda x:x.__setitem__('prior_failed_claim_recovery_required',True),
          'supersession':lambda x:x.__setitem__('failed_claim_supersession_authorized',True),
          'retry':lambda x:x.__setitem__('automatic_retry_authorized',True),
          'resume':lambda x:x.__setitem__('halted_snapshot_resume_authorized',True),
          'old_GO_reused':lambda x:x.__setitem__('prior_remaining9_GO_reused_as_new_authority',True),
          'old_code':lambda x:x.__setitem__('financial_code_manifest_SHA256',gate.INHERITED_FINANCIAL_CODE_SHA256),
          'calendar_2024':lambda x:x['calendar_days_by_year'].__setitem__('2024',365),
          'calendar_2021_annualized':lambda x:x.__setitem__('partial2021_annualized',True),
          'native_review_wrong':lambda x:x.__setitem__('native_generated_review_SHA256','0'*64),
          'new_field':lambda x:x.__setitem__('unreviewed_extra_authority',True),
        }
        for label,change in mutations.items():
            bad=deepcopy(good);change(bad);reject(lambda:self.validate(dict(self.raw,go=c.canonical(bad))),label)
        for cell in gate.SEALED_FIVE+entry.tranche_cells(entry.FIRST6):
            bad=deepcopy(good);bad['ordered_cells']=[cell]+list(gate.ordered_cells())
            reject(lambda:self.validate(dict(self.raw,go=c.canonical(bad))),'excluded_cell_GO')
        for key in ('go','review','prepared-review','native-review'):
            hashes=dict(self.hashes);hashes[key]='0'*64
            reject(lambda:self.validate(hashes=hashes),'external_digest')
        for key in ('review','prepared-review','native-review'):
            v=c.exact_object(self.raw[key]);v['financial_code_manifest_SHA256']=gate.code_identity()
            if key!='native-review':v['schema']='OTHER_DOMAIN'
            reject(lambda:self.validate(dict(self.raw,**{key:c.canonical(v)})),'wrong_review_domain_or_stale_native')
        for cpus in ([3,4],[4,4],[5,4],[4],[4,5,6],[True,5],(4,5)):
            reject(lambda:gate.policy(self.prep,'0'*64,'1'*64,'2'*64,cpus),'wrong_worker_CPU')

    def test_03_all_completed_cells_precede_claim_capture_and_terminal_reads(self):
        args=SimpleNamespace(cpu=3,cell_id=None,case_output='/DO_NOT_TOUCH')
        for cell in gate.SEALED_FIVE+entry.tranche_cells(entry.FIRST6):
            args.cell_id=cell
            with patch.object(runtime,'apply_limits'),patch.object(run_cs,'wires',return_value=(self.prep,c.exact_object(self.prep),self.raw)),patch.object(run_cs,'worker_claim',side_effect=AssertionError('CLAIM_REACHED')),patch.object(run_cs,'load_saved_year',side_effect=AssertionError('CAPTURE_REACHED')):
                reject(lambda:run_cs.case(args),'completed_worker_CLI')
            reject(lambda:claims.claim_path(cell),'completed_claim')
            reject(lambda:saved.validate_saved_terminal('/DO_NOT_TOUCH',args=None,cell_id=cell),'completed_saved_validator')
            claim=c.canonical(dict(cell_id=cell,root_GO_SHA256=self.hashes['go'],preparation_SHA256=c.sha(self.prep),code_identity=gate.code_identity()))
            def check():
                with verified.verify(preparation_raw=self.prep,cell_id=cell,raw=self.raw,hashes=self.hashes,claim_raw=claim):
                    raise AssertionError('TOKEN_ISSUED')
            reject(check,'completed_token')
            self.assertFalse(verified._LIVE)

    def test_04_token_tamper_cleanup_and_conflict(self):
        cell=gate.ordered_cells()[0]
        claim=c.canonical(dict(cell_id=cell,root_GO_SHA256=self.hashes['go'],preparation_SHA256=c.sha(self.prep),code_identity=gate.code_identity()))
        for mode in ('different_wire','different_prep','wrong_year','wrong_type'):
            with verified.verify(preparation_raw=self.prep,cell_id=cell,raw=self.raw,hashes=self.hashes,claim_raw=claim) as token:
                supplied=dict(self.raw);prep=self.prep;year=2024
                if mode=='different_wire':supplied['source-go']+=b' '
                if mode=='different_prep':prep+=b' '
                if mode=='wrong_year':year=2025
                if mode=='wrong_type':year=True
                reject(lambda:token.consume(preparation_raw=prep,year=year,supplied=supplied),'token_'+mode)
                self.assertFalse(verified._LIVE)
            self.assertFalse(verified._LIVE)
        with verified.verify(preparation_raw=self.prep,cell_id=cell,raw=self.raw,hashes=self.hashes,claim_raw=claim) as token:
            def duplicate():
                with verified.verify(preparation_raw=self.prep,cell_id=cell,raw=self.raw,hashes=self.hashes,claim_raw=claim):pass
            reject(duplicate,'duplicate_live_token')
            self.assertEqual(token.consume(preparation_raw=self.prep,year=2024,supplied=self.raw),self.hashes['go'])
            reject(lambda:token.consume(preparation_raw=self.prep,year=2024,supplied=self.raw),'token_second_consume')
        self.assertFalse(verified._LIVE)
        self.assertFalse(loader._LIVE)

    def test_05_exact_calendar_reader_matches_reviewed_adapter(self):
        adapter=ast.parse((ROOT/'cs_saved_calendar_exact_20261015_v1/cs_saved_calendar.py').read_text())
        current=ast.parse((PACKAGE/'cs_saved.py').read_text())
        af={n.name:n for n in adapter.body if isinstance(n,ast.FunctionDef)}
        cf={n.name:n for n in current.body if isinstance(n,ast.FunctionDef)}
        self.assertEqual(set(af),set(cf))
        for name in cf:
            if name=='validate_saved_terminal':continue
            self.assertEqual(ast.dump(af[name]),ast.dump(cf[name]),name)
        a=af['validate_saved_terminal'];b=cf['validate_saved_terminal']
        # Only new admitted scope and new truthful case schema differ here.
        a.body[0]=deepcopy(b.body[0])
        for n in ast.walk(a):
            if isinstance(n,ast.Constant) and n.value=='FINITE_CSMOM21_REMAINING9_ORIGINAL_D_CASE_V1':n.value='FINITE_CSMOM21_FOUR_UNSTARTED_ORIGINAL_D_CASE_V1'
        self.assertEqual(ast.dump(a),ast.dump(b))
        tiny=blob(np.zeros((2,1)),['x'])
        for year,days in ((2021,274),(2024,366),(2025,365)):
            cell=f'{year}_CSMOM21_COMMON_TIER_HIGH_D'
            self.assertEqual(saved.admitted_calendar_minutes(cell),days*1440)
            for rows in (-1,True,False,2.0,np.int64(2),days*1440+1):
                reject(lambda:saved.saved_minute(tiny,rows,cell_id=cell),'row_type_or_calendar_cap')
        for cell in ('2026_CSMOM21_COMMON_TIER_LOW_D','2024_CSMOM21_COMMON_TIER_BAD_D',None):
            reject(lambda:saved.saved_minute(tiny,2,cell_id=cell),'unknown_calendar_cell')

    def test_06_real_default_writer_full_calendars_and_hostile_npz(self):
        tree=ast.parse((PACKAGE/'run_cs.py').read_text())
        case=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='case')
        assign=next(x for x in ast.walk(case) if isinstance(x,ast.Assign) and ast.unparse(x).startswith('values, columns = (minute.to_numpy()'))
        write=next(x for x in ast.walk(case) if isinstance(x,ast.Expr) and ast.unparse(x).startswith('np.savez_compressed('))
        program=compile(ast.fix_missing_locations(ast.Module(body=[assign,write],type_ignores=[])),'<EXACT4_REAL_WRITER>','exec')
        names=['close_us','nav','free_cash','isolated_balance','gross_weight']+[f'invented_{i}' for i in range(32)]
        for year,days in ((2021,274),(2025,365),(2024,366)):
            cell=f'{year}_CSMOM21_COMMON_TIER_HIGH_D';rows=days*1440;index=np.arange(rows,dtype=np.int64)
            data={name:(index%37).astype(np.float64)/3 for name in names}
            data['close_us']=config.cell_named(cell)['start_us']+(index+1)*60_000_000
            for i,name in enumerate(names[1:]):data[name][i::37]=-0.0
            minute=pl.DataFrame(data);del data,index
            with tempfile.TemporaryDirectory(prefix='INDEPENDENT_EXACT4_FULL_WRITER_') as td:
                env=dict(np=np,minute=minute,directory=Path(td));exec(program,env)
                raw=(Path(td)/'MINUTE.npz').read_bytes();values=env['values']
                self.assertTrue(values.flags.f_contiguous)
                decoded,columns=saved.saved_minute(raw,rows,cell_id=cell)
                self.assertEqual(columns,names)
                self.assertTrue(np.array_equal(values.view(np.uint64),decoded.view(np.uint64)))
                self.assertTrue(np.signbit(decoded[:,1:]).any())
                for order in ('C','F'):
                    sub=np.array(values[:,:3],order=order);short=blob(sub,names[:3])
                    actual,_=saved.saved_minute(short,rows,cell_id=cell)
                    self.assertTrue(np.array_equal(actual.view(np.uint64),sub.view(np.uint64)))
                reject(lambda:saved.saved_minute(raw,rows-1,cell_id=cell),'writer_row_mismatch')
                if year==2024:
                    for wrong in (2021,2025):reject(lambda:saved.saved_minute(raw,rows,cell_id=f'{wrong}_CSMOM21_COMMON_TIER_HIGH_D'),'cross_calendar')
            del env,minute,values,raw,decoded
        for values,columns in ((np.zeros((2,1),dtype='float32'),['x']),(np.array([[np.nan],[0.]]),['x']),(np.array([[np.inf],[0.]]),['x']),(np.zeros((2,2)),['x','x']),(np.zeros((2,2)),['x']),(np.zeros((2,1)),[1]),(np.zeros((2,129)),[str(x) for x in range(129)])):
            raw=blob(values,columns);reject(lambda:saved.saved_minute(raw,2,cell_id=gate.ordered_cells()[0]),'hostile_npz')
        good=blob(np.zeros((2,1)),['x'])
        for raw in (good[:-8],):reject(lambda:saved.saved_minute(raw,2,cell_id=gate.ordered_cells()[0]),'truncated_npz')
        # Forged enormous, object and wrong-dtype headers fail before np.load.
        for shape,dtype,fortran in (((10**12,2),'<f8',False),((2,2),'<f4',False),((2,2),'|O',False),((2,2),'<f8',True)):
            header=BytesIO();np.lib.format.write_array_header_1_0(header,dict(shape=shape,descr=dtype,fortran_order=fortran))
            columns=BytesIO();np.save(columns,np.asarray(['a','b']),allow_pickle=False)
            stream=BytesIO()
            with zipfile.ZipFile(stream,'w') as archive:
                archive.writestr('values.npy',header.getvalue());archive.writestr('columns.npy',columns.getvalue())
            with patch.object(np,'load',side_effect=AssertionError('FORBIDDEN_ALLOCATION')) as load:
                reject(lambda:saved.saved_minute(stream.getvalue(),2,cell_id=gate.ordered_cells()[0]),'header_before_allocation')
                load.assert_not_called()
        saved.saved_minute(blob(np.zeros((0,1)),['x']),0,cell_id=gate.ordered_cells()[0])
        COUNTS['real_writer_calendars']=3;COUNTS['real_writer_columns']=37

    def test_07_inherited_global_lease_and_ordinary_claim_safety(self):
        go=c.exact_object(self.raw['go']);cell=gate.ordered_cells()[0]
        with tempfile.TemporaryDirectory(prefix='INDEPENDENT_FAKE_EXACT4_GLOBAL_REGISTRY_') as td,patch.object(claims,'registry_root',return_value=Path(td)):
            reject(lambda:claims.reserve(cell_id=cell,metadata={},go=go),'claim_without_lease')
            duplicate=None
            try:
                with runtime.controller_lease(Path(td)) as fd:
                    duplicate=os.dup(fd)
                    for key in ('automatic_retry_authorized','failed_claim_supersession_authorized','prior_failed_claim_recovery_required'):
                        bad=deepcopy(go);bad[key]=True
                        reject(lambda:claims.reserve(cell_id=cell,metadata={},go=bad),'claim_recovery_or_retry')
                        self.assertFalse(claims.claim_path(cell).exists())
                    wrong=deepcopy(go);wrong['ordered_cells']=list(entry.tranche_cells(entry.REMAINING9))
                    reject(lambda:claims.reserve(cell_id=cell,metadata={},go=wrong),'claim_all9_queue')
                    path=claims.reserve(cell_id=cell,metadata={'root_GO_SHA256':'a'*64},go=go);first=path.read_bytes()
                    reject(lambda:claims.reserve(cell_id=cell,metadata={'root_GO_SHA256':'b'*64},go=go),'claim_duplicate')
                    self.assertEqual(path.read_bytes(),first)
                self.assertIsNone(runtime._CONTROLLER_LEASE_FD)
                other=os.open(Path(td)/claims.SCOPE_SHA/'CONTROLLER_LEASE.lock',os.O_RDWR)
                try:
                    with self.assertRaises(BlockingIOError):fcntl.flock(other,fcntl.LOCK_EX|fcntl.LOCK_NB)
                    COUNTS['duplicated_inherited_FD_retains_global_exclusion']=1
                    os.close(duplicate);duplicate=None
                    fcntl.flock(other,fcntl.LOCK_EX|fcntl.LOCK_NB)
                finally:os.close(other)
            finally:
                if duplicate is not None:os.close(duplicate)
            self.assertIsNone(runtime._CONTROLLER_LEASE_FD)

if __name__=='__main__':
    assert os.sched_getaffinity(0)=={3}
    before=snapshot(claims.registry_root())
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(IndependentTests))
    assert snapshot(claims.registry_root())==before,'CANONICAL_CLAIMS_CHANGED'
    evidence=dict(status='PASS' if result.wasSuccessful() else 'FAIL',test_count=result.testsRun,counters=COUNTS,
       canonical_claims_unchanged=True,actual_claims_or_leases=0,actual_source_body_reads=0,
       actual_source_scopes=0,historical_scopes=0,actual_providers=0,actual_accounts=0,actual_GO_writes=0,
       actual_worker_launches=0,network_requests=0,publication_actions=0,CPU_affinity=sorted(os.sched_getaffinity(0)),
       numerical_pools=1,financial_code_manifest_SHA256=gate.code_identity())
    (REVIEW/'INDEPENDENT_TARGETED_EVIDENCE.json').write_text(json.dumps(evidence,sort_keys=True,indent=2)+'\n')
    print(json.dumps(evidence,sort_keys=True));sys.exit(not result.wasSuccessful())
