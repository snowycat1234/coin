"""Verify trusted archive, extract, recover exact code, run finite invented tests."""
from pathlib import Path,PurePosixPath
import argparse,subprocess,os,sys,tempfile,json,hashlib,zipfile,datetime
ENV=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',POLARS_MAX_THREADS='1',VECLIB_MAXIMUM_THREADS='1',BLIS_NUM_THREADS='1')
def pin(p):
 b=p.read_bytes();return dict(SHA256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--packet-zip',required=True,type=Path);ap.add_argument('--trusted-packet-sha',required=True);ap.add_argument('--parent-zip',required=True,type=Path);ap.add_argument('--evidence',required=True,type=Path);a=ap.parse_args()
 if sorted(os.sched_getaffinity(0))!=[3]:raise ValueError('RUN_ON_PHYSICAL_CPU3_ONLY')
 if len(a.trusted_packet_sha)!=64 or pin(a.packet_zip)['SHA256']!=a.trusted_packet_sha:raise ValueError('TRUSTED_EXTERNAL_OUTER_ZIP_SHA256_REQUIRED')
 a.evidence.mkdir(parents=True,exist_ok=False)
 groups=[('remaining9_source_author',['source_unit']),('remaining9_source_independent',['source_independent']),('remaining9_native_author',['native_unit']),('remaining9_native_independent',['native_independent']),('native40_corruption_and_debt',['native40']),('exact_calendar_full_writer',['calendar']),('exact_four_author_native_controller',['four_unit']),('exact_four_independent_invented_only',['four_independent']),('source_fresh_zip_positive',['source_zip']),('source_fresh_zip_expected_cold_stop',['source_zip','--expect-cold-stop']),('exact_source_and_native_review_metadata',['metadata'])]
 for year in (2021,2024,2025):
  for mode in ('positive','capture_failure','loaded_validation_failure','guard_exit_failure'):groups.append((f'remaining9_CLI_{year}_{mode}',['nine_cli',mode,str(year)]))
 for cell in ('2024_CSMOM21_COMMON_TIER_HIGH_D','2025_CSMOM21_COMMON_TIER_LOW_D','2025_CSMOM21_COMMON_TIER_MID_D','2025_CSMOM21_COMMON_TIER_HIGH_D'):
  for mode in ('positive','capture_failure','loaded_validation_failure','guard_exit_failure'):groups.append((f'exact_four_CLI_{cell}_{mode}',['four_cli',mode,cell]))
 results=[]
 with tempfile.TemporaryDirectory(prefix='cs_completion_source_cold_') as td:
  base=Path(td);extract=base/'extracted';recover=base/'recovered';temp=base/'invented';temp.mkdir()
  with zipfile.ZipFile(a.packet_zip) as z:
   names=z.namelist()
   if len(names)!=len(set(names)):raise ValueError('DUPLICATE_ARCHIVE_MEMBERS')
   roots=set()
   for info in z.infolist():
    p=PurePosixPath(info.filename)
    if p.is_absolute() or '..' in p.parts or '\\' in info.filename or (info.external_attr>>16)&0o170000==0o120000:raise ValueError('SAFE_REGULAR_ARCHIVE_REQUIRED')
    roots.add(p.parts[0])
   if len(roots)!=1:raise ValueError('ONE_PACKET_ROOT_REQUIRED')
   z.extractall(extract)
  packet=extract/roots.pop();manifest=json.loads((packet/'PACKET_MANIFEST.json').read_bytes())['files']
  actual={str(p.relative_to(packet)) for p in packet.rglob('*') if p.is_file()}
  if actual!=set(manifest)|{'PACKET_MANIFEST.json'}:raise ValueError('EXACT_PACKET_MEMBER_SET_REQUIRED')
  for n,r in manifest.items():
   if pin(packet/n)!=r:raise ValueError('PACKET_MEMBER_PIN_CHANGED:'+n)
  env=dict(ENV,TMPDIR=str(temp))
  p=subprocess.run([sys.executable,'-B',str(packet/'tools/recover_code_closure.py'),'--parent-zip',str(a.parent_zip.resolve()),'--output',str(recover)],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=90);(a.evidence/'RECOVERY.log').write_bytes(p.stdout)
  if p.returncode:raise RuntimeError('EXACT_CODE_RECOVERY_FAILED')
  recovery=json.loads(p.stdout);before={str(p.relative_to(recover)):pin(p) for p in recover.rglob('*') if p.is_file()}
  for name,args in groups:
   p=subprocess.run([sys.executable,'-B',str(packet/'tools/cold_generated_inner.py'),str(recover),*args],cwd=recover,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=300)
   raw_capture_pin=dict(SHA256=hashlib.sha256(p.stdout).hexdigest(),bytes=len(p.stdout));public_output=p.stdout.replace(str(base).encode(),b'<EXTRACTED_COLD_WORKSPACE>')
   log=a.evidence/(name+'.log');log.write_bytes(public_output);lines=[s for s in p.stdout.decode(errors='replace').splitlines() if s.startswith('COLD_RECEIPT_JSON=')];receipt=json.loads(lines[-1].split('=',1)[1]) if lines else None
   results.append(dict(group=name,arguments=args,exit_code=p.returncode,receipt=receipt,log=pin(log),original_capture_pin=raw_capture_pin,public_log_transform='TEMPORARY_COLD_WORKSPACE_PREFIX_REPLACEMENT_ONLY' if public_output!=p.stdout else 'EXACT_CAPTURE_BYTES'));print(name,p.returncode,receipt.get('tests') if receipt else 'NO_RECEIPT',flush=True)
   if p.returncode:break
  after={n:pin(recover/n) for n in before}
 report=dict(schema='CS_COMPLETION_SOURCE_EXTRACTED_COLD_GENERATED_CHECKS_V1',created_UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),tested_outer_archive=pin(a.packet_zip),status='PASS' if len(results)==len(groups) and all(r['exit_code']==0 for r in results) and before==after else 'FAIL',recovery=recovery,recovered_exact_files_unchanged=before==after,groups=results,tests=sum(r['receipt']['tests'] for r in results if r['receipt']),CPU_affinity=sorted(os.sched_getaffinity(0)),numerical_pools=1,generated_interpreter_processes=len(results)+1,actual_source_or_target_replay=False,actual_financial_runs=0,actual_claims_or_valid_authority_bodies_created=0,resource_probe_rerun=False,publication_actions=0,limitations=['The source deliverable-pin audit is excluded because exact path-containing historical evidence bodies are omitted; the code manifest itself is fully recovered and checked.','The exact-four metadata/registry test is excluded because historical valid GO/claim bodies are absent. Six independent invented-only methods execute unchanged.','The unchanged source cold-ZIP script historical CPU2 request is explicitly mapped to physical CPU3; no CPU2 work occurs.','Generated CLI scenarios use invented storage and recording capture/context with a post-guard native sentinel. No actual source scope, account/provider or finance is reached.','Historical audit metadata dependencies are supplied exactly but are not new root authority. Full cold historical execution remains unavailable.','Annual resource fit and host quota are not certified; the inherited tiny CPU4/5 probe is evidence only and is never rerun.','Finite observers are not a universal Python sandbox.'])
 (a.evidence/'COLD_GENERATED_CHECKS.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n');print(json.dumps(dict(status=report['status'],groups=len(results),tests=report['tests'])));return 0 if report['status']=='PASS' else 1
if __name__=='__main__':raise SystemExit(main())
