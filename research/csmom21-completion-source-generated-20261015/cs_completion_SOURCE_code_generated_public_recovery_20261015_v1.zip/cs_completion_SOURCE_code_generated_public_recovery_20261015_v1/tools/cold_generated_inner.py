"""Finite extracted-copy generated observer; not a universal Python sandbox."""
from pathlib import Path
import os,sys,json,runpy,unittest,resource,time
from contextlib import ExitStack
from unittest.mock import patch
ROOT=Path(sys.argv[1]).resolve();MODE=sys.argv[2];ARGS=sys.argv[3:];PACKET=Path(__file__).resolve().parent.parent
SRC=ROOT/'original_cs_mom21_D_remaining9_source_20261015_v3';FIN=ROOT/'original_cs_mom21_D_remaining9_financial_20261015_v1';FOUR=ROOT/'original_cs_mom21_D_remaining4_financial_20261015_v1';CAL=ROOT/'cs_saved_calendar_exact_20261015_v1';SREV=ROOT/'original_cs_mom21_D_remaining9_source_independent_review_20261015_v3';NREV=ROOT/'original_cs_mom21_D_remaining9_native_independent_review_20261015_v1';FREV=ROOT/'original_cs_mom21_D_remaining4_independent_review_20261015_v1'
paths=[SRC] if MODE.startswith('source') else [FOUR] if MODE.startswith('four') else [FIN]
if MODE=='calendar':paths=[CAL,FIN]
if MODE=='native40':paths=[ROOT/'traditional_D_full2025_20261015',ROOT/'traditional_three_tier_freeze_20261015']
for p in reversed(paths):sys.path.insert(0,str(p))
observed=dict(external_process_events=0,network_events=0,outside_allowed_file_events=0,stored_array_outside_invented_storage_events=0,actual_authority_body_events=0,unassigned_CPU_events=0,actual_source_scope_events=0,actual_historical_scope_events=0,actual_capture_or_target_events=0,actual_provider_events=0)
TMP=Path(os.environ['TMPDIR']).resolve();allowed=[ROOT,PACKET,TMP,Path(sys.prefix),Path(sys.base_prefix),Path('/usr'),Path('/lib'),Path('/lib64'),Path('/etc'),Path('/proc'),Path('/dev')]
def audit(event,args):
 if event in ('subprocess.Popen','os.system','os.fork','os.forkpty','os.posix_spawn','os.exec'):
  observed['external_process_events']+=1;raise AssertionError('ENUMERATED_GENERATED_CHILD_PROCESS_DENIED')
 if event in ('socket.connect','socket.connect_ex','socket.sendto','socket.getaddrinfo'):
  observed['network_events']+=1;raise AssertionError('ENUMERATED_GENERATED_NETWORK_DENIED')
 if event=='open' and args and isinstance(args[0],(str,bytes,os.PathLike)):
  p=Path(os.path.abspath(os.fsdecode(args[0])))
  if not any(p==r or r in p.parents for r in allowed):
   observed['outside_allowed_file_events']+=1;raise AssertionError('OUTSIDE_EXTRACTED_CODE_AND_INVENTED_STORAGE_DENIED')
  if ROOT in p.parents:
   if p.suffix.lower() in ('.npy','.npz','.csv','.tsv','.parquet','.arrow','.ipc','.zip'):
    observed['stored_array_outside_invented_storage_events']+=1;raise AssertionError('NO_STORED_ACTUAL_ARRAY_OR_MARKET_BODY')
   if p.name.startswith(('ROOT_SOURCE_','ROOT_REMAINING9_FINANCIAL_APPROVED','ROOT_EXACT4_APPROVED')) or p.name in ('SOURCE_STAGE_AUTHORIZATION.json','SOURCE_INDEPENDENT_REVIEW.json'):
    observed['actual_authority_body_events']+=1;raise AssertionError('NO_HISTORICAL_VALID_GO_OR_SOURCE_WIRE_BODY')
sys.addaudithook(audit)
original_affinity=os.sched_setaffinity
def assigned(pid,cpus):
 if set(cpus)!={3}:
  observed['unassigned_CPU_events']+=1;raise AssertionError('PHYSICAL_CPU3_ONLY')
 return original_affinity(pid,{3})
os.sched_setaffinity=assigned
started=time.monotonic();tests=0;passed=False;errors=0;failures=0;excluded=[];special={}
def suite(names):
 global tests,passed,errors,failures
 r=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromNames(names));tests=r.testsRun;passed=r.wasSuccessful();errors=len(r.errors);failures=len(r.failures)
if MODE=='source_unit':suite(['test_remaining9'])
elif MODE=='source_independent':
 sys.path.insert(0,str(SREV));import reviewer_additional as rev
 excluded=['reviewer_additional.IndependentAdmissionTests.test_frozen_graph_and_all_deliverable_pins']
 names=[]
 for cls in (rev.IndependentAdmissionTests,rev.IndependentCLIAndLifecycleTests,rev.IndependentGuardAndScopeTests,rev.Independent2021EndpointTests):
  names += ['reviewer_additional.'+cls.__name__+'.'+n for n in unittest.defaultTestLoader.getTestCaseNames(cls) if 'reviewer_additional.'+cls.__name__+'.'+n not in excluded]
 with ExitStack() as s:rev.pure_boundary(s);suite(names)
 special=dict(independent_observed=dict(rev.OBS),source_and_recording_scopes_revoked=not rev.e._ACTIVE_SOURCE and not rev.e._ACTIVE_RECORDING)
elif MODE=='source_zip':
 # Exact script bytes are unchanged. Only its historical CPU2 affinity request is
 # mapped to physical CPU3 by this explicit packaging compatibility wrapper.
 def cpu2_to3(pid,cpus):
  if set(cpus)!={2}:raise AssertionError('ONLY_DOCUMENTED_SOURCE_CPU2_REQUEST')
  return original_affinity(pid,{3})
 os.sched_setaffinity=cpu2_to3;sys.argv=[str(SRC/'test_cold_generated_zip.py'),*ARGS]
 runpy.run_path(sys.argv[0],run_name='__main__');tests=1;passed=True;special['source_CPU2_request_mapped_to_physical_CPU3']=True
elif MODE=='native_unit':
 import cs_entry as entry,cs_source as source,cs_source_bridge as bridge,cs_admission as admission,cs_generated as generated
 generated.native_reference()
 def denied(key):
  def fail(*a,**kw):observed[key]+=1;raise AssertionError('ACTUAL_BOUNDARY_FORBIDDEN:'+key)
  return fail
 with ExitStack() as s:
  for obj,name,key in [(entry.SourcePreparationScope,'__post_init__','actual_source_scope_events'),(admission.FreshHistoricalExecutionScope,'__post_init__','actual_historical_scope_events'),(source,'capture_year','actual_capture_or_target_events'),(source,'project_targets','actual_capture_or_target_events'),(bridge,'capture_2022','actual_capture_or_target_events'),(admission.CapturedMinuteProvider,'__call__','actual_provider_events')]:s.enter_context(patch.object(obj,name,denied(key)))
  suite(['test_cs_native','test_cs_finance','test_remaining_finance'])
 special['generated_native_input_seals_revoked']=not generated._LIVE_NATIVE_INPUTS
elif MODE=='native_independent':sys.path.insert(0,str(NREV));suite(['test_independent_remaining9'])
elif MODE=='native40':suite(['test_generated_native40.SavedNativeTests'])
elif MODE=='calendar':suite(['test_full_writer_calendar'])
elif MODE=='four_unit':suite(['test_four_control','test_four_controller','test_cs_native'])
elif MODE=='four_independent':
 sys.path.insert(0,str(FREV));import review_exact_four as rev
 excluded=['review_exact_four.IndependentTests.test_01_exact_identity_and_actual_supporting_metadata']
 suite(['review_exact_four.IndependentTests.'+n for n in unittest.defaultTestLoader.getTestCaseNames(rev.IndependentTests) if 'review_exact_four.IndependentTests.'+n not in excluded]);special['independent_negative_counts']=rev.COUNTS
elif MODE=='nine_cli':
 sys.argv=[str(FIN/'test_worker_integration.py'),*ARGS];runpy.run_path(sys.argv[0],run_name='__main__');tests=1;passed=True
elif MODE=='four_cli':
 import test_four_control as t;t.cli(*ARGS);tests=1;passed=True
elif MODE=='metadata':
 import cs_common as c,cs_entry as entry,cs_finance_gate as gate
 raw=(PACKET/'SOURCE_EVIDENCE/PREPARATION_METADATA_EXACT.json').read_bytes();assert c.sha(raw)=='ffe53374fbdc4ab79f4e0445849925a597f706ad1de4406137deb98b1eb7d871';entry.validate_preparation_metadata(raw);tests+=1
 nr=(NREV/'INDEPENDENT_NATIVE_REVIEW_RECEIPT.json').read_bytes();gate.native_review(nr,'3a588a7b94a8430ad04139c7e9a3c03143f777873e77af4204cf558046a50850');tests+=1
 fr=(NREV/'INDEPENDENT_FINANCIAL_ADMISSION_REVIEW_RECEIPT.json').read_bytes();assert c.sha(fr)=='18468d56a0bac8c12c15fb839909df48f96f818cf2feb7dbe1284771fc4cfc47';assert c.exact_object(fr)['financial_execution_authorized'] is False;tests+=1
 passed=True
else:raise ValueError('ENUMERATED_GROUP_REQUIRED')
receipt=dict(schema='CS_COMPLETION_SOURCE_EXTRACTED_GENERATED_GROUP_V1',runtime_versions=dict(Python=sys.version.split()[0],NumPy=getattr(sys.modules.get('numpy'),'__version__',None),Polars=getattr(sys.modules.get('polars'),'__version__',None)),mode=MODE,arguments=ARGS,tests=tests,errors=errors,failures=failures,passed=passed,observed=observed,special=special,excluded_original_tests=excluded,CPU_affinity=sorted(os.sched_getaffinity(0)),all_TID_affinities=[sorted(os.sched_getaffinity(int(t))) for t in os.listdir('/proc/self/task')],numerical_pools=1,wall_seconds=time.monotonic()-started,peak_RSS_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,actual_source_or_target_replay=False,actual_financial_runs=0,actual_claims_or_valid_GO_created=0,resource_probe_rerun=False,universal_sandbox_claim=False)
print('COLD_RECEIPT_JSON='+json.dumps(receipt,sort_keys=True));raise SystemExit(0 if passed and not any(observed.values()) and receipt['CPU_affinity']==[3] else 1)
