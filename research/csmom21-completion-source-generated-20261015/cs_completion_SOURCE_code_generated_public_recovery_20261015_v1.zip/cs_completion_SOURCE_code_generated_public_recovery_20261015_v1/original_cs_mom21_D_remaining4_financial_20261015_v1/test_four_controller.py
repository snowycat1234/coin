"""Real exact-four controller CLI using invented storage and recording fake pool."""
from contextlib import ExitStack
import json
from pathlib import Path
import shutil
import sys
import tempfile
import unittest
import uuid
from unittest.mock import patch
import cs_common as c
import cs_claims as claims
import cs_entry as entry
import cs_finance_gate as gate
import cs_process_runtime as runtime
import run_cs
from test_four_control import bundle
from test_worker_integration import fixture


def combined():
    prep=None;artifacts={}
    for year in (2021,2024,2025):
        raw,files,_,_=fixture(year);p=c.exact_object(raw)
        if prep is None:prep=p
        prep['years'][str(year)]=p['years'][str(year)]
        for key,value in p['cells'].items():
            if int(key[:4])==year:prep['cells'][key]=value
        for key,value in files.items():artifacts[key]=value;prep['artifacts'][key]=dict(SHA256=c.sha(value),bytes=len(value))
    raw=c.canonical(prep);entry.validate_preparation_metadata(raw);return raw,artifacts


class ControllerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.prep,cls.artifacts=combined()
    def invoke(self,mode):
        raw,hashes=bundle(self.prep);observed=[];oldparent=run_cs.HERE/'financial_attempts';oldparent.mkdir(exist_ok=True)
        output=oldparent/('GENERATED_EXACT4_CONTROLLER_'+uuid.uuid4().hex)
        with tempfile.TemporaryDirectory(prefix='INVENTED_EXACT4_CONTROLLER_STORAGE_') as td:
            base=Path(td);preproot=base/'preparation';preproot.mkdir();(preproot/'PREPARATION.json').write_bytes(self.prep)
            for key,value in self.artifacts.items():
                p=preproot/key;p.parent.mkdir(exist_ok=True);p.write_bytes(value)
            if mode=='wrong_GO':
                go=c.exact_object(raw['go']);go['ordered_cells']+=list(gate.SEALED_FIVE);raw['go']=c.canonical(go);hashes['go']=c.sha(raw['go'])
            argv=['run_cs.py','--output',str(output),'--preparation',str(preproot),'--preparation-sha',c.sha(self.prep)]
            for key,value in raw.items():
                p=base/(key+'.json');p.write_bytes(value);argv+=['--'+key,str(p),'--'+key+'-sha',hashes[key]]
            def pool(jobs,out,**kwargs):
                self.assertEqual(tuple(x[0] for x in jobs),gate.ordered_cells());self.assertEqual(kwargs['cpus'],[4,5]);self.assertEqual(kwargs['requested_workers'],2)
                for i,(cell,build) in enumerate(jobs):
                    directory=out/cell;directory.mkdir();cpu=[4,5][i%2]
                    argv=build(directory,cpu)
                    self.assertEqual(argv[:3],[sys.executable,'-B',str(run_cs.HERE/'run_cs.py')]);self.assertEqual(argv[argv.index('--cell-id')+1],cell)
                    self.assertEqual(argv[argv.index('--go-sha')+1],hashes['go'])
                    kwargs['before_launch'](cell,directory,cpu);observed.append(cell)
                    self.assertTrue(claims.claim_path(cell).is_file())
                    if mode=='pool_failure':raise ValueError('INVENTED_POOL_FAILURE')
                return dict(status='INVENTED_RECORDING_POOL_NO_SPAWN',ordered_cells=list(observed))
            try:
                with ExitStack() as stack:
                    stack.enter_context(patch.object(sys,'argv',argv));stack.enter_context(patch.object(claims,'registry_root',return_value=base/'claims'))
                    stack.enter_context(patch.object(runtime,'host_observation',return_value={'INVENTED_NO_PROCESS_PROBE':True}))
                    stack.enter_context(patch.object(runtime,'choose_worker_count',return_value=2));stack.enter_context(patch.object(run_cs.bounded_drain,'run_pool',side_effect=pool))
                    if mode=='positive':
                        run_cs.main();self.assertEqual(tuple(observed),gate.ordered_cells());self.assertTrue((output/('CONTROLLER_RECEIPT_'+hashes['go']+'.json')).is_file())
                    else:
                        with self.assertRaises(ValueError):run_cs.main()
                        if mode=='wrong_GO':self.assertFalse(output.exists());self.assertFalse((base/'claims').exists());self.assertEqual(observed,[])
                        else:
                            self.assertEqual(observed,[gate.ordered_cells()[0]]);self.assertTrue((output/('CONTROLLER_PAUSE_'+hashes['go']+'.json')).is_file())
                    self.assertIsNone(runtime._CONTROLLER_LEASE_FD)
            finally:
                if output.exists():shutil.rmtree(output)
        self.assertFalse(output.exists())
    def test_controller_exact_four_positive(self):self.invoke('positive')
    def test_controller_resealed_wrong_GO_precedes_claim_lease_output(self):self.invoke('wrong_GO')
    def test_controller_pool_failure_preserves_pause_and_releases_lease(self):self.invoke('pool_failure')

if __name__=='__main__':unittest.main(verbosity=2)
