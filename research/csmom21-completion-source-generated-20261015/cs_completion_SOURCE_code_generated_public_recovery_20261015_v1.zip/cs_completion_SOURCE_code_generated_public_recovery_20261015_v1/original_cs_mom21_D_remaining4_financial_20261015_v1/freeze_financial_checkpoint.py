"""Code/metadata-only remaining9 seal. No market/authority/claim actions."""
from hashlib import sha256
import json
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent

def pin(path):
    b=path.read_bytes();return dict(SHA256=sha256(b).hexdigest(),bytes=len(b))

def seal():
    base=json.loads((ROOT/'original_cs_mom21_D_20261015_v4/FINANCIAL_CODE_MANIFEST.json').read_bytes())
    names=set(base['files'])|{'cs_verified_wires.py','cs_claims.py','test_worker_integration.py','test_remaining_finance.py','freeze_financial_checkpoint.py','REMAINING9_NATIVE_PROVENANCE.json','bounded_drain.py','REPORTING_AND_DRAIN_PROVENANCE.json'}
    deps=base['dependencies']
    for n,v in deps.items():
        if pin(ROOT/n)!=v:raise ValueError('FROZEN_DEPENDENCY_CHANGED:'+n)
    value=dict(base,schema='ADDITIVE_CSMOM21_REMAINING9_NATIVE_FINANCIAL_CODE_V1',files={n:pin(HERE/n) for n in sorted(names)},dependencies=deps,
        source_code_manifest_SHA256='c3d09d50ef306b151fad5de6b9ea917f52d92369db5f2177314ac8da40e0e2f3',
        status='SEPARATE_REMAINING9_CODE_GENERATED_ONLY_NO_ACTUAL_ADMISSION',
        private_CS_failed_claim_recovery_dependencies_required=False)
    (HERE/'FINANCIAL_CODE_MANIFEST.json').write_text(json.dumps(value,sort_keys=True,indent=2)+'\n');print(pin(HERE/'FINANCIAL_CODE_MANIFEST.json'))
if __name__=='__main__':seal()
