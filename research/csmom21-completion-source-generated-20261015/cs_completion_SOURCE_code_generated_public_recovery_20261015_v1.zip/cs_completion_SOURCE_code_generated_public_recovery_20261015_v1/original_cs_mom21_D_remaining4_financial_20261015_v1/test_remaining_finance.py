"""Generated remaining9 lifecycle, calendar, quality and stable-lease checks."""
from copy import deepcopy
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import cs_common as c
import cs_config as config
import cs_entry as entry
import cs_claims as claims
import cs_process_runtime as runtime

class ClaimAndScopeTests(unittest.TestCase):
    def test_all9_calendar_and_canonical_namespace(self):
        cells=entry.tranche_cells(entry.REMAINING9)
        self.assertEqual(len(cells),9)
        for year,days in ((2021,274),(2024,366),(2025,365)):
            self.assertEqual(config.period_named(year)['days'],days)
            self.assertEqual(len([x for x in cells if config.cell_named(x)['year']==year]),3)
        self.assertEqual(claims.registry_root(),c.ROOT/'original_cs_mom21_D_20261015_v4/EXECUTION_CLAIMS')
        for cell in cells:self.assertEqual(claims.claim_path(cell),claims.registry_root()/claims.SCOPE_SHA/(cell+'.json'))
        for cell in entry.tranche_cells(entry.FIRST6):
            with self.assertRaises(ValueError):claims.claim_path(cell)

    def test_generated_permanent_claim_and_cross_tranche_lock(self):
        import fcntl,os
        cell=entry.tranche_cells(entry.REMAINING9)[0]
        go=dict(tranche=entry.REMAINING9,stable_cross_version_claim_registry=claims.STABLE_REGISTRY_REL,
                failed_claim_supersession_authorized=False,prior_failed_claim_recovery_required=False,automatic_retry_authorized=False)
        with tempfile.TemporaryDirectory() as td,patch.object(claims,'registry_root',return_value=Path(td)):
            with runtime.controller_lease(Path(td)):
                # Same canonical lock blocks another controller even for a different tranche.
                fd=os.open(Path(td)/claims.SCOPE_SHA/'CONTROLLER_LEASE.lock',os.O_RDWR)
                try:
                    with self.assertRaises(BlockingIOError):fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
                finally:os.close(fd)
                path=claims.reserve(cell_id=cell,metadata={'root_GO_SHA256':'a'*64},go=go)
                before=path.read_bytes()
                with self.assertRaisesRegex(RuntimeError,'NO_DUPLICATE'):claims.reserve(cell_id=cell,metadata={'root_GO_SHA256':'b'*64},go=go)
                self.assertEqual(path.read_bytes(),before)
            with self.assertRaisesRegex(ValueError,'LEASE_REQUIRED'):claims.reserve(cell_id=cell,metadata={},go=go)

    def test_wrong_tranche_or_recovery_go_denied_before_claim(self):
        cell=entry.tranche_cells(entry.REMAINING9)[0]
        good=dict(tranche=entry.REMAINING9,stable_cross_version_claim_registry=claims.STABLE_REGISTRY_REL,
                  failed_claim_supersession_authorized=False,prior_failed_claim_recovery_required=False,automatic_retry_authorized=False)
        for key in good:
            bad=good.copy();bad.pop(key)
            with patch.object(runtime,'claim_launch',side_effect=AssertionError('NO_CLAIM')),self.assertRaises(ValueError):claims.reserve(cell_id=cell,metadata={},go=bad)

class RemainingQualityTests(unittest.TestCase):
    def test_ten_derived_cells_unknown_before_risk_and_installed_recovery_all_tiers(self):
        import cs_generated as g
        from types import MethodType
        from test_cs_native import marks
        native=g.native_reference()
        for tier in config.TIERS:
            with g.generated_fixture(days=1) as fixture:
                targets=g.project_generated(fixture)
                start=int(fixture.decisions[0]);first=start+2*native.MINUTE;end=first+2*native.MINUTE
                sim,guard=g.construct_generated_case(targets,tier,quality_intervals=((first,end,native.S),))
                account=sim.account;marks(account,first-native.MINUTE)
                account.execute_fill('BTCUSDT','SELL','.02',first-native.MINUTE+1,start,'GENERATED_2024_SHAPE',
                    execution_mid_price='50000',quote_available_us=first-native.MINUTE,available_quantity='.02')
                seen=[];risk=account._risk
                def observed(_account,phase):
                    seen.append(tuple(_account.mark_quality[s] for s in native.S));return risk(phase)
                account._risk=MethodType(observed,account)
                quality=guard.causal_mark_quality_guard
                for at in (first,first+native.MINUTE):
                    marks(account,at,75000)
                    self.assertEqual([account.mark_quality[s] for s in native.S],['UNKNOWN_OR_DERIVED']*5)
                    self.assertFalse(account.can_increase(at));self.assertIsNotNone(quality.quality_witness(at))
                    account.monitor('MONITOR:'+str(at),at);self.assertFalse(account.pending_exits)
                del account._risk
                self.assertTrue(seen);self.assertTrue(all(x==('UNKNOWN_OR_DERIVED',)*5 for x in seen))
                self.assertIsNotNone(quality.quality_witness(end+native.MINUTE))
                marks(account,end,75000)
                self.assertIsNone(quality.quality_witness(end));account.monitor('MONITOR:'+str(end),end)
                self.assertEqual(account.pending_exits['BTCUSDT']['reason'],'GUARD50_PAID_EXIT_NO_TOPUP')
                self.assertFalse(account.transfer_journal)
                self.assertEqual(len(quality.identity['intervals']),1)
                self.assertEqual(quality.identity['intervals'][0]['original_genuine_observation_us'],first-native.MINUTE)

    def test_original_D_generic_interval_native_finance_exact_all_tiers(self):
        import importlib.util,sys
        import cs_generated as g
        from test_cs_native import finance
        native=g.native_reference()
        path=c.ROOT/'bounded_native_continuation_guard50_exit_expansion_20261015/expansion.py'
        manifest=c.exact_object((c.HERE/'FINANCIAL_CODE_MANIFEST.json').read_bytes())
        record=manifest['dependencies'][str(path.relative_to(c.ROOT))]
        c.exact(path,record['SHA256'],record['bytes'])
        name='_remaining9_exact_original_D_generic_quality_reference'
        spec=importlib.util.spec_from_file_location(name,path);reference=importlib.util.module_from_spec(spec)
        sys.modules[name]=reference;spec.loader.exec_module(reference)
        with g.generated_fixture(days=1) as fixture:
            targets=g.project_generated(fixture);window,rows,decisions=g._synthetic_window(fixture)
            first=int(decisions[0])+native.MINUTE;intervals=((first,first+2*native.MINUTE,native.S),)
            for tier in config.TIERS:
                new,ng=g.construct_generated_case(targets,tier,quality_intervals=intervals)
                old,og=reference.construct_case(window,rows,decisions,targets.common_tier[tier],
                    generated_scope=native.GENERATED,tier_name=tier,quality_intervals=intervals)
                for sim in (new,old):
                    while sim.cursor<sim.end and sim.stop is None:sim.advance_day()
                self.assertEqual(finance(new.account),finance(old.account))
                self.assertEqual(new.pending,old.pending)
                self.assertEqual(new.result()['minute'].to_numpy().tobytes(),old.result()['minute'].to_numpy().tobytes())
                self.assertEqual(ng.causal_mark_quality_guard.identity,og.causal_mark_quality_guard.identity)
                self.assertGreater(len(new.account.trades),0)
                result=native.case_result(new,ng);result.pop('minute');result['targets']=result['targets'].to_dicts()
                result=native.V2.OWNED.export_tree(result);audit=native.V2.OWNED.export_tree(new.account.snapshot())
                from saved_native_reconciliation import reconcile_saved_native
                proof=reconcile_saved_native(audit,result,expected_continuation_version=native.VERSION)
                self.assertTrue(proof['passed']);self.assertFalse(proof['tolerance_or_epsilon_used'])

    def test_saved_quality_identity_uses_exact_2024_generic_interval_and_no_cells(self):
        import cs_saved
        sidecar=dict(year=2024,cells=[],qualified_source_identity='a'*64,arrival_status='UNKNOWN_NOT_CERTIFIED',
            original_source_age_and_arrival_flags_preserved=True,actual_CS_event_impacts='PENDING_CS_SAVED_EXECUTION',
            actual_CS_position_interval_impacts='PENDING_CS_SAVED_EXECUTION_NOT_INHERITED_FROM_D',
            quality_intervals=[[1723456980000000,1723457100000000,list(config.cell_named(entry.tranche_cells(entry.REMAINING9)[0]).get('symbols',()))]])
        import cs_signal
        sidecar['quality_intervals'][0][2]=list(cs_signal.SYMBOLS)
        info=dict(quality_cells_SHA256=c.jsha([]),source_identity='a'*64,source_quality_sidecar_SHA256='b'*64)
        identity=cs_saved.quality_identity(sidecar,info,'FAKE_GENERATED_VERSION')
        self.assertEqual(identity['intervals'][0]['original_genuine_observation_us'],1723456920000000)
        self.assertNotIn('source_clock_cells',identity)

class ReportingAndResourceTests(unittest.TestCase):
    def test_C_and_Fortran_minute_arrays_preserve_cell_bits_and_columns(self):
        import numpy as np
        from io import BytesIO
        import cs_saved
        import polars as pl
        matrix=np.arange(60,dtype=np.float64).reshape(20,3)/7
        polars=pl.DataFrame(dict(a=matrix[:,0],b=matrix[:,1],c=matrix[:,2])).to_numpy()
        self.assertTrue(polars.flags.f_contiguous)
        for values in (np.ascontiguousarray(matrix),np.asfortranarray(matrix),polars):
            out=BytesIO();np.savez_compressed(out,values=values,columns=np.array(['a','b','c']))
            decoded,names=cs_saved.saved_minute(out.getvalue(),20)
            self.assertEqual(decoded.tobytes(),matrix.tobytes());self.assertEqual(names,['a','b','c'])

    def test_launcher_affinity_must_contain_both_fixed_worker_CPUs(self):
        host=dict(allowed_CPUs=[8],available_memory_bytes=10**10,free_memory_bytes=10**10,
                  total_memory_bytes=10**10,host_load1=0)
        with self.assertRaises(ValueError):runtime.choose_worker_count(2,[4,5],host)


if __name__=='__main__':unittest.main()
