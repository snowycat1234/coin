"""Invented arrays and strict metadata only. No market body or stage scope."""
from copy import deepcopy
from io import BytesIO
import importlib.util
import json
import os
from pathlib import Path
import sys
import types
import unittest
from unittest.mock import Mock, patch
import zipfile

import numpy as np
import cs_common as c
import cs_config as config
import cs_codec as codec
import cs_entry as e
import cs_signal as signal
import cs_quality as quality
import cs_source as source
from cs_source_guard import SourceOnlyGuard, SourceBoundaryViolation

YEARS = (2021, 2024, 2025)
GUARD_RECEIPTS = []
NEGATIVE_GUARD_RECEIPTS = []


def pack(**arrays):
    out = BytesIO(); np.savez_compressed(out, **arrays); return out.getvalue()


def prices(clocks):
    x = (clocks - config.utc('2020-01-01')) / config.DAY
    return np.column_stack([100 + j * 20 + x * (.02 + j * .003)
        + np.sin(x / (7 + j) + j) * .4 for j in range(5)])


def fake_daily(year):
    rows, first, last = codec.STORED_DAILY[year]
    clocks = np.arange(first, last + config.DAY, config.DAY, dtype=np.int64)
    arrays = dict(close_available_us=clocks, close=prices(clocks))
    if year == 2021:
        arrays['symbol_order'] = np.array(signal.SYMBOLS)
        arrays['unselected_later_DEV'] = np.array([float('nan')])
    daily = None
    if year == 2025:
        d = np.arange(config.period_named(year)['start'], config.period_named(year)['end'], config.DAY, dtype=np.int64)
        p = prices(d)
        daily = c.canonical([dict(symbol=s, close_us=int(at), close=float(p[i,j]))
            for i, at in enumerate(d) for j,s in enumerate(signal.SYMBOLS)])
    return arrays, daily


def fake_events(year):
    start = config.utc('2021-01-01') if year == 2021 else config.period_named(year)['start']
    days = 365 if year == 2021 else config.period_named(year)['days']
    rows = [dict(symbol=s, event_us=start+i*8*60*codec.MINUTE,
        raw_rate=float((1 if i%2 else -1)*(j+1)*.000013), reported_interval_hours=8.)
        for i in range(days*3) for j,s in enumerate(sorted(signal.SYMBOLS))]
    if year == 2021:
        for row in rows:
            row['raw_rate_unit']='UNCONFIRMED'
            row['strict_prior_mark']=dict(mark_available_us=row['event_us']-1, strict_prior_age_us=1)
    return rows


def fake_month(year, rec, close_clocks, close):
    times=np.arange(rec['start'],rec['start']+rec['count']*codec.MINUTE,codec.MINUTE,dtype=np.int64)
    arrays=dict(times=times)
    if year == 2021: arrays['available_us']=times+codec.MINUTE
    for j,s in enumerate(signal.SYMBOLS):
        for field in codec.FIELDS:
            arrays[s+'_'+field]=np.full(rec['count'],100.+j,dtype=np.float64)
        for at in range(rec['start']+config.DAY,rec['start']+rec['count']*codec.MINUTE+1,config.DAY):
            k=int(np.searchsorted(close_clocks,at))
            if k<len(close_clocks) and close_clocks[k]==at:
                arrays[s+'_close'][(at-rec['start'])//codec.MINUTE-1]=close[k,j]
    return arrays


def fake_source(year):
    contract=deepcopy(e.contracts()['years'][str(year)])
    warm,daily=fake_daily(year); warm_raw=pack(**warm)
    clocks,close,decisions=codec.daily_inputs(year,warm_raw,daily)
    months=[]; final=None; mark_hashes={}
    for rec in contract['months']:
        a=fake_month(year,rec,clocks,close); raw=pack(**a)
        rec['hash']=c.sha(raw); rec['size']=len(raw)
        months.append((rec['path'],raw)); final=a
        if year==2024 and rec['start']<=1723456920000000<rec['start']+rec['count']*codec.MINUTE:
            projected,_=codec.month_arrays(year,raw,rec['start'],rec['count'])
            mark_hashes={s:c.sha(projected[s+'_mark'].tobytes()) for s in signal.SYMBOLS}
    endpoint={s:float(final[s+'_close'][-1]) for s in signal.SYMBOLS}
    sidecar=dict(final_endpoint_close=endpoint,arrival_status='UNKNOWN_NOT_CERTIFIED',
        certifies_liquidation=False,certifies_no_liquidation=False)
    qualification_raw=None
    if year==2021:
        sidecar.pop('final_endpoint_close')
        sidecar.update(schema='GENUINE_2021_PARTIAL_NATIVE_MARK_PROVENANCE_V1',
            source_end_plus_one_witness_is_not_execution_authority=True)
        quotes=[]
        period=config.period_named(year)
        for kind,at in (('fresh_start',period['start']),('terminal_flat_quote',period['end'])):
            for symbol in signal.SYMBOLS:
                quotes.append(dict(symbol=symbol,kind=kind,open_us=at-codec.MINUTE,available_us=at,
                    execution_clock_if_later_admitted_us=at+1,available_before_proposed_execution=True,
                    actual_trade_close=float(final[symbol+'_close'][-1]),actual_mark_close=float(final[symbol+'_mark'][-1])))
        qualification_raw=c.canonical(dict(schema='CORE5_2021_APR_DEC_SOURCE_QUALIFICATION_V1',
            symbol_order=list(signal.SYMBOLS),actual_endpoint_quotes=quotes))
        contract['qualification'].update(SHA256=c.sha(qualification_raw),bytes=len(qualification_raw))
        sidecar['qualification_SHA256']=c.sha(qualification_raw)
    if year==2024: sidecar['causal_estimate_mark_array_SHA256']=mark_hashes
    inputs=(year,warm_raw,daily,c.canonical(fake_events(year)),c.canonical(sidecar),tuple(months),contract,qualification_raw)
    return inputs


def fake_review():
    return c.canonical(dict(schema=e.SOURCE_REVIEW_SCHEMA,status='PASS',code_manifest_SHA256=e.code_identity(),
        scope_manifest_SHA256=e.manifest_sha(),source_contract_map_SHA256=e.contract_sha(),
        tranche=e.REMAINING9,ordered_cells=list(e.tranche_cells(e.REMAINING9)),years=list(YEARS),
        old_D_GO_reused_as_authority=False))


def fake_authority():
    review=fake_review();go=c.canonical(e.source_policy(e.REMAINING9,c.sha(review)))
    return go,c.sha(go),review,c.sha(review)


def fake_preparation():
    go,go_sha,review,review_sha=fake_authority()
    prep=dict(schema='PREPARED_CSMOM21_SOURCE_TARGET_ONLY_V2',candidate=config.STRATEGY,
        tranche=e.REMAINING9,ordered_cells=list(e.tranche_cells(e.REMAINING9)),years={},cells={},artifacts={},
        code_manifest_SHA256=e.code_identity(),scope_manifest_SHA256=e.manifest_sha(),
        source_contract_map_SHA256=e.contract_sha(),source_stage_GO_SHA256=go_sha,source_review_SHA256=review_sha,
        historical_admission=False,financial_runs=0,accounts_created=0,accounts_advanced=0,
        provider_iterations=0,process_launches=0,canonical_claims_created=0,real_financial_GO_written=0,publication_actions=0)
    for name,raw in (('SOURCE_STAGE_AUTHORIZATION.json',go),('SOURCE_INDEPENDENT_REVIEW.json',review)):
        prep['artifacts'][name]=dict(SHA256=c.sha(raw),bytes=len(raw))
    for year in YEARS:
        contract=e.contracts()['years'][str(year)];period=config.period_named(year)
        fake=lambda key:c.sha(('GENERATED_METADATA_ONLY_'+str(year)+key).encode())
        hashes={key:fake(key) for key in ('decision_us','annual_covariance','weekly_raw_CS','original_sized_CS',
            *(config.STRATEGY+'_'+tier for tier in config.TIERS))}
        info=dict(source_identity=contract['source_identity'],source_contract_SHA256=c.jsha(contract),
            days=period['days'],calendar=[period['start'],period['end']],provider_months_source='EXISTING_PINNED_CANONICAL_MONTHS',
            source_quality_sidecar_SHA256=fake('sidecar'),quality_cells_SHA256=c.jsha([]),source_rows_SHA256=fake('rows'),
            funding_events_SHA256=fake('events'),array_raw_SHA256=hashes,all_CS_position_and_event_impacts_pending=True)
        prep['years'][str(year)]=info
        for name in ('TARGETS.npz','SOURCE_INPUTS.npz','RAW_EVENTS.json','MINUTE_MARK_PROVENANCE.json','TARGET_PROOFS.json'):
            prep['artifacts'][str(year)+'/'+name]=dict(SHA256=info['source_quality_sidecar_SHA256'] if name=='MINUTE_MARK_PROVENANCE.json' else fake(name),bytes=1)
        for cell_id in e.tranche_cells(e.REMAINING9):
            cell=config.cell_named(cell_id)
            if cell['year']!=year:continue
            target=hashes[config.STRATEGY+'_'+cell['tier']]
            binding=dict(schema='EXACT_NEW_CS_CELL_SOURCE_TARGET_BINDING_V2',cell_id=cell_id,strategy=config.STRATEGY,
                year=year,tier=cell['tier'],calendar=info['calendar'],source_identity=contract['source_identity'],source_contract_SHA256=c.jsha(contract),
                source_rows_SHA256=info['source_rows_SHA256'],funding_events_SHA256=info['funding_events_SHA256'],
                source_quality_sidecar_SHA256=info['source_quality_sidecar_SHA256'],quality_cells_SHA256=c.jsha([]),
                provider_months=[[r['path'],r['start'],r['count'],r['hash'],r['size'],r['lo'],r['hi']] for r in contract['months']],
                decision_raw_SHA256=hashes['decision_us'],covariance_raw_SHA256=hashes['annual_covariance'],weekly_raw_CS_SHA256=hashes['weekly_raw_CS'],
                original_sized_CS_SHA256=hashes['original_sized_CS'],selected_target_raw_SHA256=target,cost='BASE27',policy_variant='GUARD50_EXIT_ONLY',
                quantity_profile_SHA256='94b2238b25ed345a24a1fa148c6f35523b8efe9bf47496958028844432cb8ebf')
            prep['cells'][cell_id]=dict(descriptor=cell,input_binding=binding,input_binding_SHA256=c.jsha(binding))
    return prep


def source_read_paths():
    code=c.exact_object((c.HERE/'CODE_MANIFEST.json').read_bytes())
    return [c.HERE/name for name in code['files']]+[c.ROOT/name for name in code['dependencies']]+[c.HERE/'CODE_MANIFEST.json']


class RemainingAuthorityTests(unittest.TestCase):
    def test_exact_nine_metadata_and_no_live_scope(self):
        value=e.validate_source_authority_metadata(*fake_authority())
        self.assertEqual(tuple(value['policy']['years']),YEARS)
        self.assertEqual(len(value['policy']['ordered_cells']),9)
        self.assertEqual(value['policy']['source_limits']['assigned_CPU'],2)
        self.assertFalse(e._ACTIVE_SOURCE)
        self.assertFalse(hasattr(e,'financial_policy'))
        self.assertEqual(e.manifest_sha(),'9a5ef547d61272d5eb0bfb1b61fef8005a752d82f4e0007d18cbe65f06445a8a')
        self.assertEqual(e.contract_sha(),'9ead9f2aa1e2581f9bd200def5a3c5dbd21205dcacfc0048d7b820c15ec1f951')

    def test_missing_or_resealed_GO_field_mutations_and_first6_holdouts_denied(self):
        go,_,review,review_sha=fake_authority();original=c.exact_object(go)
        for key in original:
            bad=deepcopy(original);del bad[key];raw=c.canonical(bad)
            with self.subTest(missing=key),self.assertRaises(ValueError):e.validate_source_authority_metadata(raw,c.sha(raw),review,review_sha)
        for key,value in (('candidate','STATIC50'),('tranche',e.FIRST6),('years',[2021,2024,2026]),
            ('financial_execution_authorized',True),('provider_iteration_authorized',True),('process_launch_authorized',True),
            ('canonical_claims_authorized',True),('financial_GO_authorized',True),('source_only_2022_memory_normalization_authorized',True),
            ('source_identities',{}),('source_authority_domain','FIRST6'),('old_D_GO_reused_as_authority',True)):
            bad=deepcopy(original);bad[key]=value;raw=c.canonical(bad)
            with self.subTest(changed=key),self.assertRaises(ValueError):e.validate_source_authority_metadata(raw,c.sha(raw),review,review_sha)
        with self.assertRaises(ValueError):e.source_policy(e.FIRST6,review_sha)
        with self.assertRaises(ValueError):e.validate_source_authority_metadata(go,'a'*64,review,review_sha)

    def test_review_wrong_code_scope_contract_cells_source_years_rejected(self):
        go,_,review,_=fake_authority()
        for key,value in (('schema','OLD_D_REVIEW'),('status','FAIL'),('code_manifest_SHA256','a'*64),
            ('scope_manifest_SHA256','a'*64),('source_contract_map_SHA256','a'*64),('ordered_cells',[]),
            ('years',[2021,2025]),('tranche',e.FIRST6),('old_D_GO_reused_as_authority',True)):
            r=c.exact_object(review);r[key]=value;raw=c.canonical(r)
            g=c.exact_object(go);g['independent_review_SHA256']=c.sha(raw);graw=c.canonical(g)
            with self.subTest(key=key),self.assertRaises(ValueError):e.validate_source_authority_metadata(graw,c.sha(graw),raw,c.sha(raw))

    def test_all_nine_metadata_bindings_record_and_revoke(self):
        prep=fake_preparation();e.validate_preparation_metadata(c.canonical(prep));seen=[]
        result=e.record_metadata_bindings(prep,lambda scope:(scope.validate_current(),seen.append(scope)))
        self.assertEqual(result['ordered_cells'],list(e.tranche_cells(e.REMAINING9)))
        self.assertTrue(result['metadata_scopes_revoked']);self.assertFalse(e._ACTIVE_SOURCE)
        for scope in seen:
            with self.assertRaisesRegex(ValueError,'REVOKED'):scope.validate_current()
        for cell_id in e.tranche_cells(e.REMAINING9):
            for key,value in (('tier','OTHER'),('year',2022),('calendar',[0,1]),('source_identity','a'*64),('provider_months',[]),
                ('source_quality_sidecar_SHA256','a'*64),('selected_target_raw_SHA256','a'*64),('cost','STRESS43')):
                bad=deepcopy(prep);binding=bad['cells'][cell_id]['input_binding'];binding[key]=value
                bad['cells'][cell_id]['input_binding_SHA256']=c.jsha(binding)
                with self.subTest(cell=cell_id,key=key),self.assertRaises(ValueError):e.validate_preparation_metadata(c.canonical(bad))
        bad=deepcopy(prep);bad['tranche']=e.FIRST6
        with self.assertRaises(ValueError):e.validate_preparation_metadata(c.canonical(bad))

    def test_exact_preparation_top_year_cell_and_artifact_namespace_rejects_unknown_or_missing(self):
        prep=fake_preparation();cell_id=e.tranche_cells(e.REMAINING9)[0]
        mutations=[]
        bad=deepcopy(prep);bad['UNEXPECTED']=True;mutations.append(bad)
        for key in ('historical_execution_authorized','financial_execution_authorized','provider_iteration_authorized'):
            bad=deepcopy(prep);bad[key]=True;mutations.append(bad)
        for year in YEARS:
            bad=deepcopy(prep);bad['years'][str(year)]['UNEXPECTED']=True;mutations.append(bad)
        for cell_id in e.tranche_cells(e.REMAINING9):
            bad=deepcopy(prep);bad['cells'][cell_id]['UNEXPECTED']=True;mutations.append(bad)
        for name in ('2026/TARGETS.npz','2022/TARGETS.npz','2023/TARGETS.npz','2021/UNEXPECTED.json','FINANCIAL_GO.json'):
            bad=deepcopy(prep);bad['artifacts'][name]={'SHA256':'a'*64,'bytes':1};mutations.append(bad)
        for key in prep:
            bad=deepcopy(prep);del bad[key];mutations.append(bad)
        for year in YEARS:
            for key in prep['years'][str(year)]:
                bad=deepcopy(prep);del bad['years'][str(year)][key];mutations.append(bad)
        for cell_id in e.tranche_cells(e.REMAINING9):
            for key in prep['cells'][cell_id]:
                bad=deepcopy(prep);del bad['cells'][cell_id][key];mutations.append(bad)
        for name in prep['artifacts']:
            bad=deepcopy(prep);del bad['artifacts'][name];mutations.append(bad)
        for index,bad in enumerate(mutations):
            with self.subTest(mutation=index),self.assertRaises(ValueError):
                e.validate_preparation_metadata(c.canonical(bad))
        self.assertEqual(len(prep['artifacts']),17)
        self.assertFalse(e._ACTIVE_SOURCE);self.assertFalse(e._ACTIVE_RECORDING)

    def test_no_crossnamespace_source_LoadedInputs_or_unsealed_scope(self):
        class OldSourcePreparationScope: pass
        class LoadedInputs: pass
        for year in (2021,2022,2023,2024,2025,2026):
            for scope in (None,object(),OldSourcePreparationScope(),LoadedInputs(),{'root_GO':'a'*64}):
                with self.assertRaisesRegex(ValueError,'EXACT_NEW_CS_SOURCE_SCOPE_REQUIRED'):source.capture_year(year,scope)
        with self.assertRaisesRegex(ValueError,'SEAL'):
            e.SourcePreparationScope(e.REMAINING9,'a'*64,'b'*64,b'',b'','c'*64,object(),object())
        fake=types.SimpleNamespace(__file__=str(c.ROOT/'original_cs_mom21_D_20261015_v4/cs_source.py'))
        with patch.dict(sys.modules,cs_source=fake):
            with self.assertRaisesRegex(ValueError,'NAMESPACE'):e.code_identity()

    def test_missing_authority_stops_before_reader_or_output(self):
        reader=Mock(side_effect=AssertionError('NO_ACTUAL_READER'))
        with patch.object(source,'capture_year',reader),self.assertRaises(ValueError):
            source.prepare_source_only('/never/write',source_go_raw=b'{}',expected_source_go_sha256='a'*64,review_raw=b'{}',expected_review_sha256='b'*64)
        reader.assert_not_called();self.assertFalse(e._ACTIVE_SOURCE)


class RemainingCodecTests(unittest.TestCase):
    def test_period_shape_warmup_original_defaults_and_prefix_causality(self):
        for year in YEARS:
            arrays,daily=fake_daily(year);t,p,d=codec.daily_inputs(year,pack(**arrays),daily);period=config.period_named(year)
            self.assertEqual((len(d),p.shape),(period['days'],(period['days']+199,5)))
            self.assertEqual(int(t[0]),period['warmup_start']);self.assertEqual(int(t[-1]),period['end']-config.DAY)
            projected=signal.project_arrays(p,t,t,d);raw,original,targets,cov,diag,proofs=projected
            expected,expected_diag=signal.originals().public_targets(p,t,d,signal.SYMBOLS,signal.SYMBOLS)
            self.assertEqual(expected.tobytes(),original.tobytes());self.assertEqual(diag,expected_diag)
            self.assertEqual(signal.originals().public_targets.__kwdefaults__,{'short_absolute_confirmation':False})
            self.assertEqual(diag['momentum_days'],21);self.assertEqual(diag['weekly_anchor_us'],signal.ANCHOR)
            self.assertEqual(proofs[0]['oldest_admitted_close_available_us'],period['warmup_start'])
            self.assertTrue(any(proof['tiers']['HIGH']['factor']>1 for proof in proofs))
            cut=37;k=int(np.searchsorted(t,d[cut]))
            prefix=signal.project_arrays(p[:k+1],t[:k+1],t[:k+1],d[:cut+1])
            for index in (0,1,3):self.assertEqual(projected[index][:cut+1].tobytes(),prefix[index].tobytes())
            for tier in config.TIERS:
                self.assertEqual(targets[tier][:cut+1].tobytes(),prefix[2][tier].tobytes())
                target,proof=signal.common_grid().scale_to_tier(original[-1],cov[-1],tier)
                self.assertEqual(target.tobytes(),targets[tier][-1].tobytes())
            src=dict(close=p,clocks=t,decisions=d);frozen,_=source.project_targets(src)
            for a in (*frozen.values(),t,p,d):
                self.assertFalse(a.flags.writeable)
                with self.assertRaises(ValueError):a.setflags(write=True)
                self.assertEqual(a.tobytes(),np.frombuffer(a.tobytes(),dtype=a.dtype).reshape(a.shape).tobytes())

    def test_daily_poisoned_excluded_rows_endpoint_and_2025_join(self):
        for year in YEARS:
            arrays,daily=fake_daily(year);changed={key:value.copy() for key,value in arrays.items()}
            if year==2021:
                outside=(changed['close_available_us']<config.period_named(year)['warmup_start']) | (changed['close_available_us']>=config.period_named(year)['end'])
                changed['close'][outside]=np.nan
            elif year==2024:changed['close'][-1]=np.nan
            else:
                bad=c.object_json(daily);bad[0]['close']*=2
                with self.assertRaisesRegex(ValueError,'PARITY'):codec.daily_inputs(year,pack(**arrays),c.canonical(bad))
                continue
            left=codec.daily_inputs(year,pack(**arrays),daily);right=codec.daily_inputs(year,pack(**changed),daily)
            for a,b in zip(left,right):self.assertEqual(a.tobytes(),b.tobytes())

    def test_dtype_endian_clock_object_and_archive_shape_rejected(self):
        for year in YEARS:
            arrays,daily=fake_daily(year)
            for key,dtype in (('close','float32'),('close','>f8'),('close_available_us','uint64'),('close_available_us','>i8')):
                bad={k:v.copy() for k,v in arrays.items()};bad[key]=bad[key].astype(dtype)
                with self.subTest(year=year,dtype=dtype),self.assertRaises(ValueError):codec.daily_inputs(year,pack(**bad),daily)
            bad={k:v.copy() for k,v in arrays.items()};bad['close_available_us'][2]+=1
            with self.assertRaises(ValueError):codec.daily_inputs(year,pack(**bad),daily)
        with self.assertRaises(ValueError):codec.npz(pack(x=np.ones(4,dtype=object)),{'x':((4,),'float64')})
        payload=BytesIO();np.save(payload,np.ones(4),allow_pickle=False)
        for bodies in ((payload.getvalue(),payload.getvalue()),(payload.getvalue()[:-1],)):
            out=BytesIO()
            with zipfile.ZipFile(out,'w') as z:
                for body in bodies:z.writestr('x.npy',body)
            with self.assertRaises(ValueError):codec.npz(out.getvalue(),{'x':((4,),'float64')})

    def test_full_fake_source_assembly_quality_endpoint_raw_units_all_three_years(self):
        signal.originals();signal.common_grid();quality.original_quality();codec.mark2024()
        for year in YEARS:
            inputs=fake_source(year)
            guard=SourceOnlyGuard(read_paths=source_read_paths())
            with guard:
                result=source.assemble_inputs(*inputs)
                self.assertEqual(result['period']['days'],config.period_named(year)['days'])
                self.assertEqual(len(result['events']),e.contracts()['years'][str(year)]['events']['selected_events'])
                self.assertEqual(result['sidecar']['derived_mark_cells'],10 if year==2024 else 0)
                self.assertEqual(c.canonical(result['sidecar']['quality_intervals']),c.canonical(e.contracts()['years'][str(year)]['quality_intervals']))
                self.assertFalse(result['sidecar']['certifies_liquidation']);self.assertFalse(result['sidecar']['certifies_no_liquidation'])
                self.assertEqual(result['sidecar']['actual_CS_event_impacts'],'PENDING_CS_SAVED_EXECUTION')
                projected,_=source.project_targets(result)
                self.assertEqual(projected['decision_us'].shape,(config.period_named(year)['days'],))
                guard.checkpoint('GENERATED_REMAINING9_SOURCE_SHAPE_'+str(year))
            self.assertFalse(any(guard.attempts.values()))
            GUARD_RECEIPTS.append(guard.receipt('GENERATED_YEAR_'+str(year)+'_PASS'))
            if year==2021:
                self.assertNotIn('final_endpoint_close',c.exact_object(inputs[4]))
                witness=result['sidecar']['qualified_terminal_source_witness']
                self.assertTrue(witness['source_end_plus_one_witness_is_not_execution_authority'])
                self.assertFalse(witness['changes_native_execution_clock']);self.assertFalse(witness['historical_execution_authorized'])
            else:self.assertEqual(result['sidecar']['final_endpoint_close'],c.exact_object(inputs[4])['final_endpoint_close'])
            if year==2025:
                bad=list(inputs);sidecar=c.exact_object(bad[4]);sidecar['final_endpoint_close']['BTCUSDT']+=1;bad[4]=c.canonical(sidecar)
                with self.assertRaisesRegex(ValueError,'FINAL_NATIVE_CLOSE_WITNESS'):source.assemble_inputs(*bad)
            if year==2024:
                bad=list(inputs);sidecar=c.exact_object(bad[4]);sidecar['causal_estimate_mark_array_SHA256']['BTCUSDT']='a'*64;bad[4]=c.canonical(sidecar)
                with self.assertRaisesRegex(ValueError,'MARK_ARRAY_BITS'):source.assemble_inputs(*bad)

    def test_2021_exact_qualification_endpoint_shape_bits_clocks_and_lineage(self):
        inputs=fake_source(2021);contract=inputs[6];sidecar=c.exact_object(inputs[4])
        qualification=c.exact_object(inputs[7]);rec=contract['months'][-1]
        final,_=codec.month_arrays(2021,inputs[5][-1][1],rec['start'],rec['count'])
        result=source.qualified_terminal_witness_2021(inputs[7],sidecar,contract,final)
        self.assertNotIn('final_endpoint_close',sidecar)
        self.assertEqual(len(result['terminal_quotes']),5)
        self.assertEqual(result['terminal_quotes'][0]['available_us'],1640995200000000)
        self.assertEqual(result['terminal_quotes'][0]['execution_clock_if_later_admitted_us'],1640995200000001)
        mutations=[]
        for key,value in (('actual_trade_close',321.),('actual_mark_close',654.),('open_us',1640995140000001),
            ('available_us',1640995199999999),('execution_clock_if_later_admitted_us',1640995200000000),
            ('available_before_proposed_execution',False),('symbol','OTHER'),('kind','fresh_start'),('UNEXPECTED',True)):
            bad=deepcopy(qualification);bad['actual_endpoint_quotes'][5][key]=value;mutations.append(bad)
        bad=deepcopy(qualification);bad['actual_endpoint_quotes'].pop();mutations.append(bad)
        for index,bad in enumerate(mutations):
            raw=c.canonical(bad);co=deepcopy(contract);co['qualification'].update(SHA256=c.sha(raw),bytes=len(raw))
            sc=deepcopy(sidecar);sc['qualification_SHA256']=c.sha(raw)
            with self.subTest(index=index),self.assertRaises(ValueError):
                source.qualified_terminal_witness_2021(raw,sc,co,final)
        for raw in (None,b'{}'):
            with self.assertRaises(ValueError):source.qualified_terminal_witness_2021(raw,sidecar,contract,final)
        for key,value in (('qualification_SHA256','a'*64),('source_end_plus_one_witness_is_not_execution_authority',False)):
            bad=deepcopy(sidecar);bad[key]=value
            with self.assertRaises(ValueError):source.qualified_terminal_witness_2021(inputs[7],bad,contract,final)

    def test_2024_exact_ten_causal_cells_and_2025_genuine_empty(self):
        start=1723456800000000;count=8
        for year in (2024,2025):
            rec=dict(start=start,count=count);clocks=np.array([],dtype=np.int64);close=np.empty((0,5))
            arrays=fake_month(year,rec,clocks,close)
            for s in signal.SYMBOLS:arrays[s+'_mark']=np.arange(count,dtype=np.float64)+100
            before={key:value.tobytes() for key,value in arrays.items()}
            projected,missing=codec.month_arrays(year,pack(**arrays),start,count)
            self.assertFalse(missing)
            for s in signal.SYMBOLS:
                expected=arrays[s+'_mark'].copy()
                if year==2024:expected[2:4]=expected[1]
                self.assertEqual(projected[s+'_mark'].tobytes(),expected.tobytes())
            self.assertEqual(before,{key:value.tobytes() for key,value in arrays.items()})


class RemainingFundingTests(unittest.TestCase):
    def test_distinct_funding_schemas_raw_rates_order_and_strict_prior_2021(self):
        for year in YEARS:
            rows=fake_events(year);contract=e.contracts()['years'][str(year)]
            result=source.funding_events(year,c.canonical(rows),contract)
            selected=[row for row in rows if config.period_named(year)['start']<=row['event_us']<config.period_named(year)['end']]
            if year==2021:selected=[{k:row[k] for k in ('symbol','event_us','raw_rate','reported_interval_hours','raw_rate_unit')} for row in selected]
            self.assertEqual(c.canonical(result),c.canonical(selected))
            self.assertEqual([row['raw_rate'].hex() for row in result],[row['raw_rate'].hex() for row in selected])
            self.assertEqual(len(result),4110 if year==2021 else 5490 if year==2024 else 5475)
            with self.assertRaises(TypeError):result[0]['raw_rate']=0
            for key,value in (('reported_interval_hours',2.),('reported_interval_hours',True),('raw_rate',True),('symbol','OTHER')):
                bad=deepcopy(rows);idx=1365 if year==2021 else 0;bad[idx][key]=value
                with self.subTest(year=year,key=key),self.assertRaises(ValueError):source.funding_events(year,c.canonical(bad),contract)
            bad=deepcopy(rows);idx=1365 if year==2021 else 0
            if year==2021:bad[idx]['raw_rate_unit']='CERTIFIED'
            else:bad[idx]['raw_rate_unit']='UNCONFIRMED'
            with self.assertRaises(ValueError):source.funding_events(year,c.canonical(bad),contract)
        rows=fake_events(2021);rows[1365]['strict_prior_mark']['mark_available_us']=rows[1365]['event_us']
        with self.assertRaisesRegex(ValueError,'STRICT_PRIOR'):source.funding_events(2021,c.canonical(rows),e.contracts()['years']['2021'])


class RemainingGuardTests(unittest.TestCase):
    def test_clean_fake_projection_has_all_forbidden_counters_zero(self):
        signal.originals();signal.common_grid();quality.original_quality()
        a,daily=fake_daily(2025);t,p,d=codec.daily_inputs(2025,pack(**a),daily)
        guard=SourceOnlyGuard(read_paths=source_read_paths())
        with guard:
            signal.project_arrays(p,t,t,d[:2]);e.validate_source_authority_metadata(*fake_authority());guard.checkpoint('CLEAN_GENERATED_SOURCE_ONLY')
        self.assertFalse(any(guard.attempts.values()));self.assertFalse(e._ACTIVE_SOURCE)
        self.assertEqual(guard.receipt('GENERATED_PASS')['forbidden_attempts'],dict.fromkeys(guard.CATEGORIES,0))
        GUARD_RECEIPTS.append(guard.receipt('GENERATED_CLEAN_PROJECTION_PASS'))

    def test_preloaded_actual_class_boundary_stops_before_constructor_or_provider(self):
        for name in ('FakeAccount','NativeSimulator','MinuteProvider','HistoricalExecutionScope'):
            module=types.ModuleType('_generated_preloaded_boundary');module.__source_guard_fixture__=True
            touched=[]
            cls=type(name,(),{'__init__':lambda self:touched.append(True)})
            setattr(module,name,cls);sys.modules[module.__name__]=module;guard=SourceOnlyGuard()
            try:
                with self.assertRaisesRegex(SourceBoundaryViolation,'PRELOADED_FINANCIAL_GRAPH'):
                    with guard:cls()
                self.assertEqual(touched,[]);self.assertEqual(guard.attempts['financial_imports'],1)
                NEGATIVE_GUARD_RECEIPTS.append(guard.receipt('EXPECTED_PRELOADED_'+name+'_DENIAL'))
            finally:sys.modules.pop(module.__name__,None)

    def test_process_claim_realGO_network_and_loader_attempts_are_fatal_and_observed(self):
        import fcntl,socket,subprocess
        cases=(('process_launches',lambda:subprocess.run(['not-a-process'])),
            ('canonical_financial_claims_or_leases',lambda:fcntl.flock(-1,fcntl.LOCK_EX)),
            ('financial_GO_writes',lambda:json.dumps({'schema':'FINANCIAL_GO','historical_execution_authorized':True})),
            ('network_calls',lambda:socket.create_connection(('invalid.test',443))),
            ('financial_imports',lambda:importlib.util.spec_from_file_location('alias','/tmp/no.py')),
            ('financial_imports',lambda:__import__('cs_native')))
        for category,action in cases:
            guard=SourceOnlyGuard()
            with self.subTest(category=category),self.assertRaises(SourceBoundaryViolation):
                with guard:
                    try:action()
                    except SourceBoundaryViolation:pass
            self.assertEqual(guard.attempts[category],1)
            self.assertEqual(sum(guard.attempts.values()),1)
            NEGATIVE_GUARD_RECEIPTS.append(guard.receipt('EXPECTED_'+category+'_DENIAL'))

    def test_cpu2_only_cli_argument_before_authority(self):
        import prepare_cs_source as cli
        args=['prepare_cs_source.py','--output','/never','--source-go','/never','--source-go-sha','a'*64,
              '--source-review','/never','--source-review-sha','b'*64,'--cpu','7']
        with patch.object(sys,'argv',args),self.assertRaisesRegex(ValueError,'ASSIGNED_SOURCE_CPU'):cli.main()


if __name__=='__main__':unittest.main()
