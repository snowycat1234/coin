"""Ordinary remaining9 claims under the same permanent CS15 global lease.

This fresh-genesis tranche has no failed-claim recovery packet or supersession.
No claims or leases are acquired by import or metadata validation.
"""
import os
import cs_common as c
import cs_config as config
import cs_entry as entry
import cs_finance_gate as gate
import cs_process_runtime as r

SCOPE_SHA='9a5ef547d61272d5eb0bfb1b61fef8005a752d82f4e0007d18cbe65f06445a8a'
STABLE_REGISTRY_REL='original_cs_mom21_D_20261015_v4/EXECUTION_CLAIMS'


def registry_root():return c.ROOT/STABLE_REGISTRY_REL


def require_exact_namespace():
    if entry.manifest_sha()!=SCOPE_SHA:
        raise ValueError('EXACT_SHARED_ALL15_CLAIM_NAMESPACE_REQUIRED')
    root=registry_root()
    if root.is_symlink() or any(p.is_symlink() for p in root.parents):
        raise ValueError('ORDINARY_STABLE_ALL15_REGISTRY_REQUIRED')
    return root


def claim_path(cell_id):
    if cell_id not in gate.ordered_cells():
        raise ValueError('ONLY_EXACT_REMAINING9_FRESH_CLAIMS_ADMITTED')
    return require_exact_namespace()/SCOPE_SHA/(cell_id+'.json')


def reserve(*,cell_id,metadata,go):
    claim_path(cell_id)
    if (go.get('tranche')!=gate.FOUR_UNSTARTED or go.get('ordered_cells')!=list(gate.ordered_cells()) or go.get('stable_cross_version_claim_registry')!=STABLE_REGISTRY_REL
            or go.get('failed_claim_supersession_authorized') is not False
            or go.get('prior_failed_claim_recovery_required') is not False
            or go.get('automatic_retry_authorized') is not False):
        raise ValueError('EXACT_FRESH_REMAINING9_GO_NO_SUPERSESSION_REQUIRED')
    fd=r._CONTROLLER_LEASE_FD
    if type(fd) is not int:raise ValueError('STABLE_ALL15_CONTROLLER_LEASE_REQUIRED')
    canonical=(registry_root()/SCOPE_SHA/'CONTROLLER_LEASE.lock').stat();held=os.fstat(fd)
    if (canonical.st_dev,canonical.st_ino)!=(held.st_dev,held.st_ino):
        raise ValueError('EXACT_SHARED_ALL15_CONTROLLER_LEASE_INODE_REQUIRED')
    return r.claim_launch(registry_root(),cell_id=cell_id,manifest_sha256=SCOPE_SHA,metadata=metadata)
