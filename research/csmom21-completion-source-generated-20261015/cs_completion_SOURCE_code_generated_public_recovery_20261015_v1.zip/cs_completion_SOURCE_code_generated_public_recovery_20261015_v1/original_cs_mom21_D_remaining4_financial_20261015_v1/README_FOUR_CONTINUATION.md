# Exact four never-started CS continuation

This is a declared separate execution package for only, in this order:

1. 2024_CSMOM21_COMMON_TIER_HIGH_D
2. 2025_CSMOM21_COMMON_TIER_LOW_D
3. 2025_CSMOM21_COMMON_TIER_MID_D
4. 2025_CSMOM21_COMMON_TIER_HIGH_D

The previous remaining9 controller ended EXIT1 after its saved reader rejected
527040-row leap-year evidence. Five completed native cases are already sealed.
Their old files, claims, failures, and wasted computation remain evidence. This
package cannot claim, admit, queue, or validate those five or any first6 cell.
It does not replay, restore, resume, or supersede a claim.

The source graph remains c3d09d50ef306b151fad5de6b9ea917f52d92369db5f2177314ac8da40e0e2f3.
The original financial package49d6a90d917e29011a8303986c79d96df943a1dd6624eda29ae7aa54dec57162 is unchanged.
The native implementation VERSION remains the inherited remaining9 implementation
identifier. New execution identity is explicit in the financial manifest, new
SOURCE_SCOPE, exact-four root policy, new case receipt schema and new review.
No fake historical scope or generated history is manufactured.

Only six runtime files have declared changes from the old package:
cs_finance_gate.py, cs_admission.py, cs_claims.py, cs_verified_wires.py,
run_cs.py, cs_saved.py. Native finance, source capture, loaded arrays and their
validation, process runtime, limits, charged preview, funding, latency,
capacity, paid-exit rules, and bounded_drain226b are byte-identical.

The saved NPZ reader uses the externally bound admitted cell's exact calendar
minutes. It allows a genuine partial halt's completed rows up to that exact
period length. All existing completion, halt, clock, account, native40, raw100,
archive, dtype, shape, finite numeric and payload checks remain strict.
Independent adapter approval is d8ff2a5bdb2f6d4ea49ee62237a64c06ddbf49175735f67385167d40d619f626.
Independent saved-five evidence is22ab5f582fc13d555f3eafbbffb0009ba094dcc4a8d696bdc51cbb13888a4066.

No new actual root GO was created. New independent exact-four financial review
and a fresh root-issued exact-four GO are mandatory before launch. Old source
GO, prepared review and native9 review are immutable supporting evidence. The
old financial9 GO is a digest-only history binding, never new authority.

Author regressions use CPU3 and one numerical thread. Real CLI worker tests
use invented storage/capture and stop at a post-guard constructor sentinel;
real controller CLI tests use invented claims/lease storage and a recording
pool that never launches a worker. Actual source reads, actual source scopes,
historical scopes, providers, accounts, canonical claims, real GO writes,
network, actual worker launches and publication actions are all zero.
