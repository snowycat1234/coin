"""Freeze a declared separate exact-four code envelope, never a GO."""
from hashlib import sha256
import json
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
FROZEN=ROOT/'original_cs_mom21_D_remaining9_financial_20261015_v1'

def pin(path):
    raw=path.read_bytes();return dict(SHA256=sha256(raw).hexdigest(),bytes=len(raw))

def seal():
    base=json.loads((FROZEN/'FINANCIAL_CODE_MANIFEST.json').read_text())
    assert pin(FROZEN/'FINANCIAL_CODE_MANIFEST.json')['SHA256']=='49d6a90d917e29011a8303986c79d96df943a1dd6624eda29ae7aa54dec57162'
    names=set(base['files'])|{'freeze_remaining4_checkpoint.py','test_four_control.py','test_four_controller.py','test_remaining9.py','DECLARED_FOUR_CONTINUATION_PROVENANCE.json'}
    deps=dict(base['dependencies']);deps[str((FROZEN/'FINANCIAL_CODE_MANIFEST.json').relative_to(ROOT))]=pin(FROZEN/'FINANCIAL_CODE_MANIFEST.json')
    for name in ('cs_saved_calendar_exact_20261015_v1/cs_saved_calendar.py',
                 'original_cs_mom21_D_remaining9_saved_results_independent_review_20261015/INDEPENDENT_EXACT_CALENDAR_REPAIR_FINAL_REVIEW.json',
                 'original_cs_mom21_D_remaining9_saved_results_independent_review_20261015/PARTIAL_REMAINING9_SAVED_REVIEW_RECEIPT.json',
                 'original_cs_mom21_D_remaining9_saved_results_independent_review_20261015/2024_CSMOM21_COMMON_TIER_LOW_D_EXACT_CALENDAR_SAVED_VALIDATION_BINDING.json',
                 'original_cs_mom21_D_remaining9_saved_results_independent_review_20261015/2024_CSMOM21_COMMON_TIER_MID_D_EXACT_CALENDAR_SAVED_VALIDATION_BINDING.json'):
        deps[name]=pin(ROOT/name)
    # The source graph and financial primitives were not reauthored.
    for name,value in deps.items():
        if pin(ROOT/name)!=value:raise ValueError('FROZEN_DEPENDENCY_CHANGED:'+name)
    for name in ('cs_native.py','cs_process_runtime.py','bounded_drain.py','cs_loader.py'):
        if pin(HERE/name)!=pin(FROZEN/name):raise ValueError('UNCHANGED_NATIVE_RUNTIME_LOADER_REQUIRED:'+name)
    value=dict(base,schema='DECLARED_CSMOM21_EXACT_FOUR_UNSTARTED_FINANCIAL_CODE_V1',
        files={name:pin(HERE/name) for name in sorted(names)},dependencies=deps,
        status='GENERATED_ONLY_NEW_EXACT4_SCOPE_INDEPENDENT_REVIEW_AND_FRESH_ROOT_GO_REQUIRED',
        inherited_financial_code_SHA256=pin(FROZEN/'FINANCIAL_CODE_MANIFEST.json')['SHA256'])
    (HERE/'FINANCIAL_CODE_MANIFEST.json').write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')
    print(pin(HERE/'FINANCIAL_CODE_MANIFEST.json'))
if __name__=='__main__':seal()
