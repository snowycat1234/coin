"""Invented full-length default-Polars writer regression, no financial execution."""
import ast
from io import BytesIO
import json
from pathlib import Path
import sys
import tempfile
import unittest
import zipfile
import numpy as np
import polars as pl

HERE=Path(__file__).resolve().parent
FROZEN=HERE.parent/'original_cs_mom21_D_remaining9_financial_20261015_v1'
sys.path.insert(0,str(FROZEN));sys.path.insert(0,str(HERE))
import cs_saved_calendar as saved
import cs_saved as frozen
import cs_config as config


def blob(values, columns):
    target=BytesIO();np.savez_compressed(target,values=values,columns=np.asarray(columns));return target.getvalue()


def reject(raw, rows, year=2024):
    with np.testing.assert_raises((ValueError,zipfile.BadZipFile,EOFError)):
        saved.saved_minute(raw,rows,cell_id=f'{year}_CSMOM21_COMMON_TIER_LOW_D')


def rewrite(raw, change):
    with zipfile.ZipFile(BytesIO(raw)) as z: parts={i.filename:z.read(i) for i in z.infolist()}
    parts=change(parts)
    target=BytesIO()
    with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED) as z:
        for name,data in parts.items():z.writestr(name,data)
    return target.getvalue()


class FullWriterTests(unittest.TestCase):
    def test_full_actual_default_writer_274_365_366(self):
        # Execute the exact two writer statements parsed from frozen run_cs.case.
        source=ast.parse((FROZEN/'run_cs.py').read_text())
        case=next(x for x in source.body if isinstance(x,ast.FunctionDef) and x.name=='case')
        assign=next(x for x in ast.walk(case) if isinstance(x,ast.Assign) and ast.unparse(x).startswith('values, columns = (minute.to_numpy()'))
        write=next(x for x in ast.walk(case) if isinstance(x,ast.Expr) and ast.unparse(x).startswith('np.savez_compressed('))
        program=compile(ast.fix_missing_locations(ast.Module(body=[assign,write],type_ignores=[])),'<EXACT_FROZEN_CS_WRITER_AST>','exec')
        self.assertEqual(ast.unparse(assign),'values, columns = (minute.to_numpy(), minute.columns)')
        names=['close_us','nav','free_cash','isolated_balance','gross_weight']+[f'generated_col_{n}' for n in range(32)]
        for year,days in ((2021,274),(2025,365),(2024,366)):
            cell=f'{year}_CSMOM21_COMMON_TIER_LOW_D';rows=days*1440
            index=np.arange(rows,dtype=np.int64)
            data={name:(index%97).astype(np.float64)/7 for name in names}
            data['close_us']=config.cell_named(cell)['start_us']+(index+1)*60_000_000
            for i,name in enumerate(names[1:]): data[name][i::37]=-0.0
            minute=pl.DataFrame(data);del data,index
            with tempfile.TemporaryDirectory(prefix='GENERATED_FULL_CALENDAR_WRITER_') as td:
                env={'minute':minute,'np':np,'directory':Path(td)};exec(program,env)
                values=env['values'];self.assertTrue(values.flags.f_contiguous)
                raw=(Path(td)/'MINUTE.npz').read_bytes()
                decoded,columns=saved.saved_minute(raw,rows,cell_id=cell)
                self.assertEqual(columns,names);self.assertTrue(np.array_equal(decoded.view(np.uint64),values.view(np.uint64)))
                self.assertTrue(np.signbit(decoded[:,1:]).any())
                if year==2024:
                    with self.assertRaisesRegex(ValueError,'BOUNDED_SAVED_NATIVE_MINUTES_REQUIRED'):frozen.saved_minute(raw,rows)
                for layout in (np.ascontiguousarray(values),np.asfortranarray(values)):
                    small=blob(layout[:, :3],names[:3]);d,n=saved.saved_minute(small,rows,cell_id=cell)
                    self.assertTrue(np.array_equal(d.view(np.uint64),values[:,:3].view(np.uint64)));self.assertEqual(n,names[:3])
                reject(raw,rows-1,year)
                reject(raw,rows+1,year)
                if year==2024:
                    reject(raw,rows,2021);reject(raw,rows,2025)
                if year==2025:reject(raw,rows,2021)
            del minute,env,values,raw,decoded

    def test_bound_and_row_types(self):
        raw=blob(np.zeros((2,1)),['x'])
        for rows in (True,False,2.0,np.int64(2),-1,527041):reject(raw,rows)
        for cell in ('2026_CSMOM21_COMMON_TIER_LOW_D','2024_CSMOM21_COMMON_TIER_NO_D',None):
            with self.assertRaises(ValueError):saved.saved_minute(raw,2,cell_id=cell)
        for year,days in ((2021,274),(2022,365),(2023,365),(2024,366),(2025,365)):
            cell=f'{year}_CSMOM21_COMMON_TIER_LOW_D'
            self.assertEqual(saved.admitted_calendar_minutes(cell),days*1440)
            saved.saved_minute(raw,2,cell_id=cell)
        saved.saved_minute(blob(np.zeros((0,1)),['x']),0,cell_id='2024_CSMOM21_COMMON_TIER_LOW_D')

    def test_archive_header_payload_numeric_unchanged(self):
        good=blob(np.zeros((2,2)),['a','b'])
        for raw in (good[:-8],rewrite(good,lambda p:{**p,'unexpected.npy':b'x'}),rewrite(good,lambda p:{k:v[:-1] if k=='values.npy' else v for k,v in p.items()}),rewrite(good,lambda p:{k:v+b'x' if k=='values.npy' else v for k,v in p.items()})):
            reject(raw,2)
        for matrix,names in ((np.zeros((2,2),dtype='float32'),['a','b']), (np.array([[np.nan,0.],[0.,0.]]),['a','b']), (np.array([[np.inf,0.],[0.,0.]]),['a','b']), (np.zeros((2,2)),['a','a']), (np.zeros((2,2)),['a']), (np.zeros((2,2)),np.array([1,2])), (np.zeros((2,0)),[]), (np.zeros((2,129)),[str(i) for i in range(129)])):
            reject(blob(matrix,names),2)

    def test_only_declared_adapter_delta(self):
        old=ast.parse((FROZEN/'cs_saved.py').read_text());new=ast.parse((HERE/'cs_saved_calendar.py').read_text())
        old_functions={x.name:x for x in old.body if isinstance(x,ast.FunctionDef)}
        new_functions={x.name:x for x in new.body if isinstance(x,ast.FunctionDef)}
        self.assertEqual(set(new_functions)-set(old_functions),{'admitted_calendar_minutes'})
        for name,node in old_functions.items():
            if name in ('saved_minute','validate_saved_terminal'):continue
            self.assertEqual(ast.dump(node),ast.dump(new_functions[name]),name)
        old_minute=old_functions['saved_minute'];new_minute=new_functions['saved_minute']
        self.assertEqual(ast.dump(ast.Module(body=old_minute.body[1:],type_ignores=[])),ast.dump(ast.Module(body=new_minute.body[1:],type_ignores=[])))
        old_validator=old_functions['validate_saved_terminal'];new_validator=new_functions['validate_saved_terminal']
        calls=[x for x in ast.walk(new_validator) if isinstance(x,ast.Call) and isinstance(x.func,ast.Name) and x.func.id=='saved_minute']
        self.assertEqual(len(calls),1);self.assertEqual(ast.unparse(calls[0].keywords[0]),'cell_id=cell_id');calls[0].keywords=[]
        self.assertEqual(ast.dump(old_validator),ast.dump(new_validator))

if __name__=='__main__':unittest.main(verbosity=2)
