from pathlib import Path
import sys
HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent/'original_cs_mom21_D_remaining9_source_20261015_v3'
sys.path.insert(0,str(SOURCE))
raw=(SOURCE/'run_source_generated.py').read_text()
raw=raw.replace("HERE=Path(__file__).resolve().parent", "HERE=Path("+repr(str(SOURCE))+")")
raw=raw.replace('os.sched_setaffinity(0,{2})','os.sched_setaffinity(0,{3})')
raw=raw.replace("(HERE/'SOURCE_GENERATED_TEST_RECEIPT.json').write_text", "(Path("+repr(str(HERE/'INDEPENDENT_AUTHOR_RERUN_RECEIPT.json'))+")).write_text")
exec(compile(raw,str(SOURCE/'run_source_generated.py'),'exec'))
