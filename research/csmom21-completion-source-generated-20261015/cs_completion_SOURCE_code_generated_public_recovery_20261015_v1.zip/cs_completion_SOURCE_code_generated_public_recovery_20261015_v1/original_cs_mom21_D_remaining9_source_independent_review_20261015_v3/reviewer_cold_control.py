from pathlib import Path
import sys
SOURCE=Path(__file__).resolve().parent.parent/'original_cs_mom21_D_remaining9_source_20261015_v3'
sys.path.insert(0,str(SOURCE))
raw=(SOURCE/'test_cold_generated_zip.py').read_text().replace('os.sched_setaffinity(0,{2})','os.sched_setaffinity(0,{3})')
exec(compile(raw,str(SOURCE/'test_cold_generated_zip.py'),'exec'))
