"""Pin independently observed CODE + GENERATED evidence; never emit an actual GO."""
from pathlib import Path
import hashlib,json,os,sys
HERE=Path(__file__).resolve().parent
SOURCE=HERE.parent/'original_cs_mom21_D_remaining9_source_20261015_v3'
sys.path.insert(0,str(SOURCE))
import cs_common as c,cs_entry as e,cs_config as cfg

def pin(p):
    raw=p.read_bytes();return {'SHA256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}

a=json.loads((HERE/'INDEPENDENT_ADDITIONAL_RECEIPT.json').read_bytes())
b=json.loads((HERE/'INDEPENDENT_AUTHOR_RERUN_RECEIPT.json').read_bytes())
pos=json.loads((HERE/'INDEPENDENT_COLD_POSITIVE.json').read_bytes());neg=json.loads((HERE/'INDEPENDENT_COLD_NEGATIVE.json').read_bytes())
assert a['status']==b['status']==pos['status']==neg['status']=='PASS'
assert a['tests']==10 and b['tests']==18 and len(a['mutation_cases'])==668
assert not a['unexpected_acceptances'] and not any(a['observed'].values()) and not any(b['observed'].values())
assert a['CPU_affinity']==b['CPU_affinity']==[3]
assert all(x==[3]for x in a['all_TID_affinities']+b['all_TID_affinities'])
assert len(a['expected_negative_guard_receipts'])==12
assert all(sum(r['forbidden_attempts'].values())==1 for r in a['expected_negative_guard_receipts'])
assert len(b['positive_guard_receipts'])==4
assert all(not any(r['forbidden_attempts'].values())for r in b['positive_guard_receipts'])
assert not any(a['CLI_receipts'][0]['guard_receipt']['forbidden_attempts'].values())
assert a['source_scopes_revoked']and a['recording_scopes_revoked']
assert not (SOURCE/'source_attempts').exists()
for folder in ('original_cs_mom21_D_remaining9_source_20261015_v1','original_cs_mom21_D_remaining9_source_20261015_v2',SOURCE.name):
    root=HERE.parent/folder;delivery=json.loads((root/'SOURCE_DELIVERABLE_PINS.json').read_bytes())
    for name,p in delivery['files'].items():c.exact(root/name,p['SHA256'],p['bytes'])
contracts=e.contracts();manifest=json.loads((SOURCE/'CODE_MANIFEST.json').read_bytes());inherited=json.loads((SOURCE/'INHERITED_DEPENDENCY_PINS.json').read_bytes())
metadata_pins={name:pin(SOURCE/name)for name in ('CODE_MANIFEST.json','SOURCE_DELIVERABLE_PINS.json','FROZEN_FIFTEEN_CELL_MANIFEST.json','SOURCE_CONTRACT_MAP.json','REMAINING9_SOURCE_BINDING.json','STRICT_PREPARATION_SCHEMA_DELTA.json','ENDPOINT_2021_QUALIFICATION_DELTA.json','INHERITED_DEPENDENCY_PINS.json','ORIGINAL_SIGNAL_PROVENANCE.json','CS2022_SOURCE_BRIDGE_PROVENANCE.json','SOURCE_REVIEW_TEMPLATE_INVALID.json','SOURCE_STAGE_GO_TEMPLATE_INVALID.json','SOURCE_STAGE_COMMAND_INVALID.txt')}
evidence_names=('reviewer_rerun_author.py','reviewer_additional.py','reviewer_cold_control.py','build_independent_receipt.py','INDEPENDENT_rerun_author.log','INDEPENDENT_additional.log','INDEPENDENT_AUTHOR_RERUN_RECEIPT.json','INDEPENDENT_ADDITIONAL_RECEIPT.json','INDEPENDENT_COLD_POSITIVE.json','INDEPENDENT_COLD_NEGATIVE.json','INDEPENDENT_COLD_POSITIVE.stderr','INDEPENDENT_COLD_NEGATIVE.stderr','verify_endpoint_metadata_and_failure.py','ENDPOINT_METADATA_AND_FAILURE_DIAGNOSIS.json')
review=dict(schema=e.SOURCE_REVIEW_SCHEMA,status='PASS',code_manifest_SHA256=e.code_identity(),scope_manifest_SHA256=e.manifest_sha(),source_contract_map_SHA256=e.contract_sha(),tranche=e.REMAINING9,ordered_cells=list(e.tranche_cells(e.REMAINING9)),years=[2021,2024,2025],old_D_GO_reused_as_authority=False,
    independent_review_scope='EXACT_REMAINING9_SOURCE_GATE_CODE_AND_GENERATED_ONLY',reviewed_source_checkpoint=SOURCE.name,
    source_authority_domain=e.SOURCE_DOMAIN,source_deliverable_pins_SHA256=metadata_pins['SOURCE_DELIVERABLE_PINS.json']['SHA256'],
    review_CPU=3,physical_CPU_affinity=[3],numerical_pools=1,all_observed_TID_affinities=[3],
    reviewed_metadata_pins=metadata_pins,verified_source_code_files=manifest['files'],verified_code_only_dependency_pins=manifest['dependencies'],
    inherited_policy_and_primitive_pins={k:v for k,v in inherited.items()if k.endswith(('/POLICY.json','/PRIMITIVE_PINS.json','/QUANTITY_PROFILE.json'))},
    inherited_pin_meaning='Qualified metadata lineage only. These old private GO bodies, historical scopes and financial authorities were neither read nor reused. Only the four CODE_MANIFEST code dependencies were runtime-required and byte-verified.',
    qualified_input_metadata={str(year):dict(source_identity=contracts['years'][str(year)]['source_identity'],source_contract_SHA256=c.jsha(contracts['years'][str(year)]),read_file_allowlist_SHA256=c.jsha(contracts['years'][str(year)]['read_files']),source_read_file_count=len(contracts['years'][str(year)]['read_files']),calendar=cfg.period_named(year),actual_input_body_read=False)for year in (2021,2024,2025)},
    checks=dict(exact_all_nine_year_tier_calendar_source_raw_sized_bindings=True,exact_17_artifact_names=True,exact_top_year_cell_wrapper_schemas=True,FIRST6_crossnamespace_old_source_classes_and_other_years_rejected=True,resealed_binding_and_source_identity_mutations_rejected=True,financial_GO_flags_limits_schema_hash_mutations_rejected=True,no_follow_path_symlink_controls=True,bounded_NPZ_headers_rejected_before_np_load=True,original_public_targets_byte_pinned_and_generated_bit_parity=True,original_short_absolute_confirmation_default=False,weekly_anchor_UTC='2024-01-01T00:00:00Z',momentum_return_count=21,shared_close_admission_count=200,calendar_day_counts=[274,366,365],raw_and_original_sized_CS_arrays_separate=True,current_scale_to_tier_may_reexpand=True,immutable_bytes_backed_arrays_and_dtype_endian_shape_controls=True,prefix_causality_and_genuine_Dec31_endpoint_controls=True,funding_2021_strict_prior_UNCONFIRMED_raw_rates_unscaled=True,funding_2024_2025_exact_four_field_schema=True,quality_2024_ten_derived_mark_cells_distinct_from_2025_empty=True,source_age_and_arrival_uncertified_flags_preserved=True,old_D_event_position_impact_conclusions_not_inherited=True,only_cp437_and_utf_8_sig_deliberately_preloaded=True,SourceOnlyGuard_byte_identical_to_V4=True,no_generated_bypass_runtime_flag=True),
    test_summary=dict(author_tests_independently_rerun=18,additional_independent_tests=10,independent_rejected_mutation_cases=668,independent_endpoint_2021_negative_cases=143,old_V1_V2_code_authority_resealed_rejections=2,unexpected_acceptances=0,clean_author_guard_receipts=4,clean_real_CLI_guard_receipts=1,independent_fatal_negative_guard_categories=12,fresh_ZIP_positive='PASS',fresh_ZIP_expected_cold_negative='PASS_ONE_CP437_FILENAME_LOADER_DENIAL',v1_accepted_schema_mutations_retested_rejected=17),
    generated_real_CLI=dict(entry='prepare_cs_source.main -> prepare_source_only -> validate_source_authority_metadata -> admit_source_stage -> generated capture -> real project_targets -> all9 validate_preparation_metadata -> record_metadata_bindings',storage='All authority and output blobs remained in RAM through named VirtualStorage seams; no actual input/output artifact was opened or saved.',capture='Three invented-array captures; metadata uses exact qualified source identities only. No scope.read_source invocation or provider call.',resource_seam='CPU2-only production CLI affinity/rlimit requests were observed without changing the review process physical CPU3 affinity. This generated control proves the source control/guard path; it does not assert a real CPU2 launch.',guard_byte_pin=manifest['files']['cs_source_guard.py'],forbidden_attempts=a['CLI_receipts'][0]['guard_receipt']['forbidden_attempts'],virtual_output_files=a['CLI_receipts'][0]['virtual_files']-2,persistent_output_files_created=0),
    endpoint_2021_narrow_repair=json.loads((HERE/'ENDPOINT_METADATA_AND_FAILURE_DIAGNOSIS.json').read_bytes()),
    endpoint_2021_generated_regression=dict(original_source_sidecar_final_endpoint_close_field_absent=True,qualification_has_fresh_and_terminal_quotes=True,all_five_exact_terminal_trade_and_mark_float64_bits_required=True,end_minus_minute_end_and_end_plus_one_clocks_exact=True,end_plus_one_witness_only_no_execution_permission=True,exact_quote_schema_and_pinned_qualification_lineage_required=True,other_year_endpoint_paths_unchanged=True),
    generated_scope_lifecycle=a['scope_lifecycle'],source_scopes_revoked=True,recording_scopes_revoked=True,
    observed_review_boundary_attempts=a['observed'],observed_author_rerun_boundary_attempts=b['observed'],
    test_evidence_pins={name:pin(HERE/name)for name in evidence_names},
    authorized_qualification_sidecar_metadata_files_read=2,authorized_V2_stop_exit_metadata_files_read=2,
    actual_source_bodies_read=0,actual_saved_targets_or_covariances_read=0,actual_sources_captured=0,actual_targets_generated=0,actual_source_stage_scopes_created=0,generated_ephemeral_source_scopes_created=2,actual_historical_scopes_created=0,actual_accounts_created=0,actual_account_advances=0,actual_provider_iterations=0,actual_financial_runs=0,actual_process_launches=0,actual_network_requests=0,actual_claims_written=0,actual_root_GO_files_written=0,publication_actions=0,
    actual_source_stage_authorized=False,financial_execution_authorized=False,historical_execution_authorized=False,account_construction_authorized=False,provider_iteration_authorized=False,process_launch_authorized=False,canonical_claims_authorized=False,financial_GO_authorized=False,publication_authorized=False,
    next_required_gate='Only the parent/root may create a fresh exact REMAINING9 source-only GO against this review SHA256 and this CODE_MANIFEST. Actual prepared source/targets must later receive a separate saved-artifact audit before any financial admission.',reviewed_at_UTC=__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat())
raw=json.dumps(review,indent=2,sort_keys=True).encode()+b'\n'
receipt=HERE/'INDEPENDENT_SOURCE_REVIEW.json';receipt.write_bytes(raw)
# Metadata self-check only: generated GO bytes remain in memory and mint no scope.
go=c.canonical(e.source_policy(e.REMAINING9,c.sha(raw)))
validated=e.validate_source_authority_metadata(go,c.sha(go),raw,c.sha(raw))
assert len(validated['policy']['ordered_cells'])==9 and not e._ACTIVE_SOURCE
qa=dict(schema='REMAINING9_REVIEW_RECEIPT_METADATA_ADMISSION_SELF_CHECK_V1',status='PASS',independent_review_pin=pin(receipt),source_code_manifest_SHA256=e.code_identity(),generated_GO_bytes_persisted=False,scope_minted=False,actual_authority_created=False,source_scopes_revoked=not e._ACTIVE_SOURCE,recording_scopes_revoked=not e._ACTIVE_RECORDING,financial_execution_authorized=False)
(HERE/'REVIEW_RECEIPT_SELF_CHECK.json').write_text(json.dumps(qa,indent=2,sort_keys=True)+'\n')
output=dict(schema='REMAINING9_INDEPENDENT_SOURCE_REVIEW_DELIVERABLE_PINS_V1',status='PASS_CODE_GENERATED_ONLY',files={p.name:pin(p)for p in sorted(HERE.iterdir())if p.is_file()and p.name!='INDEPENDENT_REVIEW_DELIVERABLE_PINS.json'},actual_source_stage_authorized=False,financial_execution_authorized=False)
(HERE/'INDEPENDENT_REVIEW_DELIVERABLE_PINS.json').write_text(json.dumps(output,indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(status='PASS',review=pin(receipt),review_path=str(receipt),deliverable_pins=pin(HERE/'INDEPENDENT_REVIEW_DELIVERABLE_PINS.json'),rejected_mutations=len(a['mutation_cases']))))
