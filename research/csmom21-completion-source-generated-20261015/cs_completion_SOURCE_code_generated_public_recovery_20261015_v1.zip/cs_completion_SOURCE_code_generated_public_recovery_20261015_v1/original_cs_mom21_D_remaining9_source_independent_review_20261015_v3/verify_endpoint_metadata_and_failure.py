"""Read only the explicitly authorized endpoint/STOP metadata; never raw input arrays."""
from pathlib import Path
import hashlib,json,sys,os
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent;SOURCE=ROOT/'original_cs_mom21_D_remaining9_source_20261015_v3'
sys.path.insert(0,str(SOURCE))
import cs_common as c
contract=json.loads((SOURCE/'SOURCE_CONTRACT_MAP.json').read_bytes())['years']['2021']
qpin=contract['qualification'];sp=contract['quality_sidecar_path'];spin=contract['read_files'][sp]
qraw=c.exact(ROOT/qpin['path'],qpin['SHA256'],qpin['bytes']);sraw=c.exact(ROOT/sp,spin['SHA256'],spin['bytes'])
q=c.exact_object(qraw);s=c.exact_object(sraw)
assert 'final_endpoint_close'not in s and s['qualification_SHA256']==qpin['SHA256']
assert s['source_end_plus_one_witness_is_not_execution_authority']is True
assert q['schema']=='CORE5_2021_APR_DEC_SOURCE_QUALIFICATION_V1'
assert q['symbol_order']==['BTCUSDT','ETHUSDT','SOLUSDT','XRPUSDT','DOGEUSDT']
assert len(q['actual_endpoint_quotes'])==10
rows=[x for x in q['actual_endpoint_quotes']if x['kind']=='terminal_flat_quote']
assert len(rows)==5 and [x['symbol']for x in rows]==q['symbol_order']
fields={'symbol','kind','open_us','available_us','execution_clock_if_later_admitted_us','available_before_proposed_execution','actual_trade_close','actual_mark_close'}
for row in rows:
 assert set(row)==fields
 assert row['open_us']==1640995140000000 and row['available_us']==1640995200000000
 assert row['execution_clock_if_later_admitted_us']==1640995200000001
 assert row['available_before_proposed_execution']is True
attempt=ROOT/'original_cs_mom21_D_remaining9_source_20261015_v2/source_attempts/REMAINING9_attempt001'
stopraw=c.exact(attempt/'STOP_SOURCE_TARGET_PREPARATION.json','e24942d03cca629bfb7425fb2b2fd9b570500771fdfc01f73d83dfa63c3ee5bd',9307)
exitraw=c.exact(attempt/'ROOT_DELEGATED_OBSERVED_EXIT_CONFIRMED.json','8621c4d31ea020d350171592ded5bbafd14486104a6c0c41829cd113e25634ec',635)
stop=c.exact_object(stopraw);ex=c.exact_object(exitraw)
assert ex['actual_observed_exit_code']==1 and ex['stage_status']=='FAILED_SOURCE_ENDPOINT_SCHEMA_CHECK_BEFORE_TARGETS'
assert ex['STOP']==dict(SHA256=c.sha(stopraw),bytes=len(stopraw))
assert stop['error']=='ValueError:EXACT_GENUINE_FINAL_NATIVE_CLOSE_WITNESS_REQUIRED'
assert not any(stop['forbidden_attempts'].values())and stop['source_scopes_revoked']and stop['recording_scopes_revoked']
assert [x['label']for x in stop['checkpoints']]==['ENTER_FRESH_REMAINING9_CS_SOURCE_ONLY_PROCESS']
assert not any((attempt/str(y)/'TARGETS.npz').exists()for y in (2021,2024,2025))
out=dict(schema='INDEPENDENT_REMAINING9_V3_ENDPOINT_METADATA_AND_V2_FAILURE_DIAGNOSIS_V1',status='PASS',
    qualification_pin=qpin,sidecar_pin=dict(path=sp,**spin),sidecar_has_no_final_endpoint_close=True,
    qualification_symbol_order=q['symbol_order'],endpoint_quote_count=10,terminal_quote_count=5,terminal_quote_schema=sorted(fields),
    terminal_source_open_us=1640995140000000,terminal_source_available_us=1640995200000000,witness_only_plus_one_us=1640995200000001,
    source_end_plus_one_witness_is_not_execution_authority=True,terminal_quote_metadata_SHA256=c.jsha(rows),
    failed_V2_STOP=dict(path=str((attempt/'STOP_SOURCE_TARGET_PREPARATION.json').relative_to(ROOT)),SHA256=c.sha(stopraw),bytes=len(stopraw)),
    failed_V2_observed_EXIT1=dict(path=str((attempt/'ROOT_DELEGATED_OBSERVED_EXIT_CONFIRMED.json').relative_to(ROOT)),SHA256=c.sha(exitraw),bytes=len(exitraw)),
    failed_V2_all_guard_counters_zero=True,failed_V2_scopes_revoked=True,failed_V2_targets_absent=True,
    authorized_actual_qualification_sidecar_metadata_files_read=2,authorized_stop_exit_metadata_files_read=2,
    raw_monthly_source_bodies_read=0,actual_target_projection_performed=False,actual_capture_performed=False,actual_root_GO_bodies_read=0,
    financial_execution_authorized=False,CPU_affinity=sorted(os.sched_getaffinity(0)))
(HERE/'ENDPOINT_METADATA_AND_FAILURE_DIAGNOSIS.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print('PASS metadata shape and failure evidence; no raw source capture or target projection')
