"""Independent CODE + GENERATED review; no actual input, target, covariance or GO body."""
import os
THREAD_ENV=('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','POLARS_MAX_THREADS','VECLIB_MAXIMUM_THREADS','BLIS_NUM_THREADS')
for k in THREAD_ENV:os.environ[k]='1'
os.sched_setaffinity(0,{3})
from collections import Counter
from contextlib import ExitStack
from copy import deepcopy
from io import BytesIO,StringIO
from pathlib import Path
import builtins,io,json,resource,socket,stat,struct,subprocess,sys,time,types,unittest,zipfile
from unittest.mock import patch
REVIEW=Path(__file__).resolve().parent
SOURCE=REVIEW.parent/os.environ.get('REVIEW_SOURCE','original_cs_mom21_D_remaining9_source_20261015_v3')
sys.path.insert(0,str(SOURCE))
import prepare_cs_source as cli  # Only cp437 and utf_8_sig are deliberately warmed.
import cs_common as c,cs_config as config,cs_entry as e,cs_source as source,cs_codec as codec,cs_signal as sig,cs_quality as quality
import test_remaining9 as t
from cs_source_guard import SourceOnlyGuard,SourceBoundaryViolation,current_guard
OBS=Counter({k:0 for k in ('nonallowlisted_workspace_reads','stored_market_or_array_reads','process_attempts','network_attempts')}); MUTATIONS=[];CLI_RECEIPTS=[];LIFECYCLE=[];META_ACCEPTS=[];NEGATIVE_GUARDS=[]
CODE=json.loads((SOURCE/'CODE_MANIFEST.json').read_bytes())
ALLOWED={SOURCE/name for name in json.loads((SOURCE/'SOURCE_DELIVERABLE_PINS.json').read_bytes())['files']}|{c.ROOT/name for name in CODE['dependencies']}|{SOURCE/'CODE_MANIFEST.json',SOURCE/'test_remaining9.py',SOURCE/'prepare_cs_source.py',SOURCE/'SOURCE_DELIVERABLE_PINS.json'}
BINDING=json.loads((SOURCE/'REMAINING9_SOURCE_BINDING.json').read_bytes())
ALLOWED|={c.ROOT/BINDING['source_checkpoint']/name for name in BINDING['reused_exact_files']}

def record_rejection(label,fn):
    try:fn()
    except (ValueError,TypeError,KeyError,SourceBoundaryViolation) as exc:
        MUTATIONS.append({'case':label,'result':'REJECT','exception':type(exc).__name__,'reason':str(exc)})
    else:
        META_ACCEPTS.append(label)
        raise AssertionError('UNEXPECTED_ACCEPTANCE:'+label)

def pure_boundary(stack):
    original_open=builtins.open;original_io=io.open;original_os=os.open
    def check(file):
        if isinstance(file,int) or not isinstance(file,(str,bytes,os.PathLike)):return
        p=Path(os.path.abspath(os.fsdecode(file)))
        if c.ROOT in p.parents and p not in ALLOWED:
            OBS['nonallowlisted_workspace_reads']+=1;raise AssertionError('REVIEW_CODE_METADATA_READ_ALLOWLIST_ONLY:'+str(p))
        if p.suffix.lower() in ('.npz','.npy','.csv','.tsv','.parquet','.arrow','.ipc','.zip'):
            OBS['stored_market_or_array_reads']+=1;raise AssertionError('NO_STORED_MARKET_ARRAY_READ:'+str(p))
    def wrap(fn):
        def opened(file,mode='r',*a,**kw):
            if 'r' in mode or '+' in mode:check(file)
            if any(ch in mode for ch in 'wax+') and isinstance(file,(str,bytes,os.PathLike)):
                p=Path(os.path.abspath(os.fsdecode(file)))
                if SOURCE in p.parents:raise AssertionError('FROZEN_SOURCE_WRITE_FORBIDDEN:'+str(p))
            return fn(file,mode,*a,**kw)
        return opened
    for obj,name,fn in ((builtins,'open',wrap(original_open)),(io,'open',wrap(original_io))):stack.enter_context(patch.object(obj,name,fn))
    def os_open(p,flags,*a,**kw):
        if not flags&os.O_WRONLY:check(p)
        return original_os(p,flags,*a,**kw)
    stack.enter_context(patch.object(os,'open',os_open))
    def deny(cat):
        def fail(*a,**kw):OBS[cat]+=1;raise AssertionError('REVIEW_ACTUAL_BOUNDARY_DENIED:'+cat)
        return fail
    for obj,names,cat in ((subprocess,('Popen','run','call','check_call','check_output'),'process_attempts'),
        (os,('system','fork','forkpty','posix_spawn','posix_spawnp','execv','execve','execvp','execvpe'),'process_attempts'),
        (socket.socket,('connect','connect_ex','sendto','send','sendall'),'network_attempts')):
        for n in names:
            if hasattr(obj,n):stack.enter_context(patch.object(obj,n,deny(cat)))

class IndependentAdmissionTests(unittest.TestCase):
    def test_frozen_graph_and_all_deliverable_pins(self):
        pins=json.loads((SOURCE/'SOURCE_DELIVERABLE_PINS.json').read_bytes())
        for name,pin in pins['files'].items():
            raw=c.exact(SOURCE/name,pin['SHA256'],pin['bytes']);self.assertEqual(len(raw),pin['bytes'])
        binding=json.loads((SOURCE/'REMAINING9_SOURCE_BINDING.json').read_bytes())
        old=c.ROOT/binding['source_checkpoint']
        for name,pin in binding['reused_exact_files'].items():
            self.assertEqual(c.sha(c.exact(old/name,pin['SHA256'],pin['bytes'])),pin['SHA256'])
        self.assertFalse(any('native' in n.lower() or 'financial' in n.lower() for n in CODE['files']))
        self.assertEqual(c.sha((SOURCE/'CODE_MANIFEST.json').read_bytes()),e.code_identity())

    def test_GO_exact_missing_flags_limits_namespace_and_wire(self):
        g,gh,r,rh=t.fake_authority();value=c.exact_object(g)
        for key in value:
            bad=deepcopy(value);del bad[key];raw=c.canonical(bad)
            record_rejection('GO_missing_'+key,lambda raw=raw:e.validate_source_authority_metadata(raw,c.sha(raw),r,rh))
        changes={'schema':'ROOT_FINANCIAL_GO','action':'PREPARE_EXACT_FIRST6_2022_2023_ALL_THREE_TIERS_CS_SOURCE_TARGETS_ONLY','status':'APPROVED','candidate':'CSMOM21',
            'tranche':e.FIRST6,'source_authority_domain':'FIRST6_SOURCE_TARGET_ONLY','ordered_cells':list(reversed(value['ordered_cells'])),'years':[2021,2024,2026],
            'code_manifest_SHA256':'a'*64,'scope_manifest_SHA256':'a'*64,'source_contract_map_SHA256':'a'*64,'independent_review_SHA256':'a'*64,
            'source_identities':{**value['source_identities'],'2022':'a'*64},'unexpected':True}
        for key,v in value.items():
            if type(v) is bool:changes[key]=not v
        for key,v in changes.items():
            bad=deepcopy(value);bad[key]=v;raw=c.canonical(bad)
            record_rejection('GO_changed_'+key,lambda raw=raw:e.validate_source_authority_metadata(raw,c.sha(raw),r,rh))
        for key in value['source_limits']:
            bad=deepcopy(value);bad['source_limits'][key]+=1;raw=c.canonical(bad)
            record_rejection('GO_limit_'+key,lambda raw=raw:e.validate_source_authority_metadata(raw,c.sha(raw),r,rh))
        for label,gr,grh,rr,rrh in [('wrong_go_pin',g,'a'*64,r,rh),('wrong_review_pin',g,gh,r,'a'*64),('go_bytearray',bytearray(g),gh,r,rh),('trailing_duplicate',b'{"tranche":1,"tranche":2}',c.sha(b'{"tranche":1,"tranche":2}'),r,rh)]:
            record_rejection(label,lambda gr=gr,grh=grh,rr=rr,rrh=rrh:e.validate_source_authority_metadata(gr,grh,rr,rrh))
        self.assertFalse(e._ACTIVE_SOURCE)

    def test_preparation_exact_wrappers_artifact_names_and_binding_all_nine(self):
        p=t.fake_preparation();e.validate_preparation_metadata(c.canonical(p));first=e.tranche_cells(e.REMAINING9)[0]
        cases=[]
        for key in p:
            b=deepcopy(p);del b[key];cases.append(('prep_missing_'+key,b))
        b=deepcopy(p);b['UNEXPECTED']=True;cases.append(('prep_extra_top',b))
        b=deepcopy(p);b['historical_execution_authorized']=True;cases.append(('prep_extra_financial_flag',b))
        for year in (2021,2024,2025):
            for key in p['years'][str(year)]:
                b=deepcopy(p);del b['years'][str(year)][key];cases.append((f'year{year}_missing_{key}',b))
            b=deepcopy(p);b['years'][str(year)]['UNEXPECTED']=True;cases.append((f'year{year}_extra',b))
        for cellid in e.tranche_cells(e.REMAINING9):
            for key in p['cells'][cellid]:
                b=deepcopy(p);del b['cells'][cellid][key];cases.append((cellid+'_missing_'+key,b))
            b=deepcopy(p);b['cells'][cellid]['UNEXPECTED']=True;cases.append((cellid+'_extra_wrapper',b))
            for key in p['cells'][cellid]['input_binding']:
                b=deepcopy(p);bind=b['cells'][cellid]['input_binding'];del bind[key];b['cells'][cellid]['input_binding_SHA256']=c.jsha(bind)
                cases.append((cellid+'_binding_missing_'+key,b))
            for key,v in [('schema','OLD_BINDING'),('year',2022),('tier','LOW' if 'LOW' not in cellid else 'MID'),('source_identity','a'*64),('source_contract_SHA256','a'*64),('calendar',[0,1]),('provider_months',[]),('weekly_raw_CS_SHA256','a'*64),('original_sized_CS_SHA256','a'*64),('selected_target_raw_SHA256','a'*64),('UNEXPECTED',True)]:
                b=deepcopy(p);bind=b['cells'][cellid]['input_binding'];bind[key]=v;b['cells'][cellid]['input_binding_SHA256']=c.jsha(bind);cases.append((cellid+'_binding_changed_'+key,b))
        for name in p['artifacts']:
            b=deepcopy(p);del b['artifacts'][name];cases.append(('artifact_missing_'+name,b))
        for name in ('2026/TARGETS.npz','2022/TARGETS.npz','2021/EXTRA.json','../escape.json','/tmp/absolute.json','2024/../escape.json'):
            b=deepcopy(p);b['artifacts'][name]={'SHA256':'a'*64,'bytes':1};cases.append(('artifact_extra_'+name,b))
        for k,v in [('SHA256','A'*64),('bytes',True),('bytes',-1),('UNEXPECTED',1)]:
            b=deepcopy(p);b['artifacts']['2021/TARGETS.npz'][k]=v;cases.append(('artifact_pin_'+k+'_'+str(v),b))
        for label,b in cases:
            with self.subTest(case=label):record_rejection(label,lambda b=b:e.validate_preparation_metadata(c.canonical(b)))

    def test_recording_callback_failure_revokes_and_no_cross_namespace(self):
        p=t.fake_preparation();seen=[]
        def fail(scope):seen.append(scope);scope.validate_current();raise RuntimeError('GENERATED_CALLBACK_STOP')
        with self.assertRaisesRegex(RuntimeError,'GENERATED_CALLBACK_STOP'):e.record_metadata_bindings(p,fail)
        self.assertFalse(e._ACTIVE_RECORDING);self.assertFalse(e._ACTIVE_SOURCE)
        for scope in seen:record_rejection('recording_callback_revoke',scope.validate_current)
        class ForeignScope:pass
        class LoadedInputs:pass
        class DerivedScope(e.SourcePreparationScope):pass
        for typ in (ForeignScope,LoadedInputs):
            for year in (2021,2022,2024,2025,2026):record_rejection(typ.__name__+'_'+str(year),lambda typ=typ,year=year:source.capture_year(year,typ()))
        for year in (2022,2023,2026,True,'2021'):
            record_rejection('pure_period_'+str(year),lambda year=year:e.source_policy('other', 'a'*64))
        self.assertFalse(e._ACTIVE_SOURCE)

    def test_npz_bad_headers_are_rejected_before_np_load(self):
        def container(payload,name='x.npy',external_attr=0):
            out=BytesIO();info=zipfile.ZipInfo(name);info.external_attr=external_attr
            with zipfile.ZipFile(out,'w') as z:z.writestr(info,payload)
            return out.getvalue()
        def npy(shape,dtype='float64',fortran=False):
            out=BytesIO();np=__import__('numpy');np.lib.format.write_array_header_1_0(out,dict(descr=np.dtype(dtype).str,fortran_order=fortran,shape=shape));return out.getvalue()
        import numpy as np
        payload=BytesIO();np.save(payload,np.ones(4),allow_pickle=False);normal=payload.getvalue()
        cases=[('huge_shape',container(npy((2**61,)))),('shape_mismatch',container(npy((5,))+b'\0'*40)),('object_dtype',container(npy((4,),'object')+b'\0'*32)),('fortran',container(npy((4,),fortran=True)+b'\0'*32)),('big_endian',container(npy((4,),'>f8')+b'\0'*32)),('truncated',container(normal[:-1])),('parent_member',container(normal,'../x.npy')),('symlink_member',container(normal,external_attr=(stat.S_IFLNK|0o777)<<16))]
        for label,raw in cases:
            with self.subTest(case=label),patch.object(np,'load',side_effect=AssertionError('UNSAFE_PAYLOAD_LOAD_REACHED')) as load:
                record_rejection('npz_'+label,lambda raw=raw:codec.npz(raw,{'x':((4,),'float64')}));load.assert_not_called()

class VirtualStorage:
    """Named storage seam. Everything under the virtual output/go paths stays in RAM."""
    def __init__(self,go,review):
        self.base=c.HERE/'source_attempts';self.output=self.base/'GENERATED_REVIEW_VIRTUAL_NO_FILES'
        self.go=Path('/tmp/GENERATED_REMAINING9_AUTHORITY_UNUSABLE.json');self.review=Path('/tmp/GENERATED_REMAINING9_REVIEW_UNUSABLE.json')
        self.data={self.go:go,self.review:review};self.dirs=set();self.opens=[]
        self.original_io=io.open;self.original_mkdir=os.mkdir
    def inside(self,p):return p==self.base or self.base in p.parents or p in (self.go,self.review)
    def open(self,file,mode='r',*a,**kw):
        if isinstance(file,int) or not isinstance(file,(str,bytes,os.PathLike)):return self.original_io(file,mode,*a,**kw)
        p=Path(os.path.abspath(os.fsdecode(file)))
        if not self.inside(p):return self.original_io(file,mode,*a,**kw)
        self.opens.append((str(p),mode));binary='b'in mode
        if 'x'in mode and p in self.data:raise FileExistsError(p)
        if 'r'in mode:
            if p not in self.data:raise FileNotFoundError(p)
            return BytesIO(self.data[p]) if binary else StringIO(self.data[p].decode())
        store=self
        class RAMBytes(BytesIO):
            def close(self):
                if not self.closed:store.data[p]=self.getvalue()
                super().close()
        class RAMText(StringIO):
            def close(self):
                if not self.closed:store.data[p]=self.getvalue().encode()
                super().close()
        return RAMBytes() if binary else RAMText()
    def mkdir(self,p,*a,**kw):
        p=Path(os.path.abspath(p))
        if not self.inside(p):return self.original_mkdir(p,*a,**kw)
        self.dirs.add(p)

class IndependentCLIAndLifecycleTests(unittest.TestCase):
    def test_real_CLI_fake_capture_storage_unchanged_guard_and_lifecycle(self):
        sig.originals();sig.common_grid();quality.original_quality();codec.mark2024()
        generated={}
        for year in (2021,2024,2025):
            result=source.assemble_inputs(*t.fake_source(year))
            # Capture seam supplies only invented arrays, retaining exact qualified metadata.
            result['contract']=c.immutable(e.contracts()['years'][str(year)])
            generated[year]=result
        g,gh,r,rh=t.fake_authority();storage=VirtualStorage(g,r);seen=[];calls=[];resource_calls=[]
        actual_affinity=sorted(os.sched_getaffinity(0));real_getaff=os.sched_getaffinity
        def capture(year,scope):
            self.assertIs(type(scope),e.SourcePreparationScope);scope.validate_current(year=year)
            self.assertIsNotNone(current_guard());self.assertTrue(current_guard().active)
            q=scope.qualification_for(year);self.assertEqual(q.source_identity,e.contracts()['years'][str(year)]['source_identity'])
            if not seen:seen.append(scope)
            calls.append(year);return generated[year]
        original_exists=Path.exists;original_isdir=Path.is_dir;original_rglob=Path.rglob;original_stat=Path.stat;original_symlink=Path.is_symlink
        def exists(p):return p in storage.data or p in storage.dirs if storage.inside(p) else original_exists(p)
        def isdir(p):return p in storage.dirs if storage.inside(p) else original_isdir(p)
        def rglob(p,pattern):return iter([q for q in storage.data if p in q.parents]+[q for q in storage.dirs if p in q.parents]) if storage.inside(p) else original_rglob(p,pattern)
        def stats(p,*a,**kw):
            if p in storage.data:return types.SimpleNamespace(st_size=len(storage.data[p]),st_mode=stat.S_IFREG|0o600)
            if p in storage.dirs:return types.SimpleNamespace(st_size=0,st_mode=stat.S_IFDIR|0o700)
            return original_stat(p,*a,**kw)
        # The real source CLI is CPU2-only; this named resource seam observes its
        # requests while the independent review process stays physically on CPU3.
        def affinity_set(pid,mask):resource_calls.append(['sched_setaffinity',pid,sorted(mask)])
        def affinity_get(pid):return {2} if pid==0 else real_getaff(pid)
        argv=['prepare_cs_source.py','--output',str(storage.output),'--source-go',str(storage.go),'--source-go-sha',gh,'--source-review',str(storage.review),'--source-review-sha',rh,'--cpu','2']
        with ExitStack() as stack:
            for obj,name,fn in [(io,'open',storage.open),(builtins,'open',storage.open),(os,'mkdir',storage.mkdir),(Path,'exists',exists),(Path,'is_dir',isdir),(Path,'rglob',rglob),(Path,'stat',stats),(Path,'is_symlink',lambda p:False if storage.inside(p) else original_symlink(p)),(source,'capture_year',capture),(os,'sched_setaffinity',affinity_set),(os,'sched_getaffinity',affinity_get),(resource,'setrlimit',lambda *a:resource_calls.append(['setrlimit',*a])),(sys,'argv',argv)]:stack.enter_context(patch.object(obj,name,fn))
            with patch('signal.alarm',lambda *a:resource_calls.append(['alarm',*a])),patch('signal.signal',lambda *a:None):cli.main()
        self.assertEqual(calls,[2021,2024,2025]);self.assertFalse(e._ACTIVE_SOURCE);self.assertFalse(e._ACTIVE_RECORDING)
        self.assertEqual(sorted(os.sched_getaffinity(0)),actual_affinity)
        for scope in seen:record_rejection('CLI_source_scope_revoked',scope.validate_current)
        p=c.exact_object(storage.data[storage.output/'PREPARATION.json']);e.validate_preparation_metadata(c.canonical(p))
        receipt=c.exact_object(storage.data[storage.output/'OBSERVED_SOURCE_TARGET_GUARD_RECEIPT.json'])
        self.assertFalse(any(receipt['forbidden_attempts'].values()));self.assertTrue(receipt['source_scopes_revoked']);self.assertTrue(receipt['recording_scopes_revoked'])
        self.assertEqual(len(p['cells']),9);self.assertEqual(p['ordered_cells'],list(e.tranche_cells(e.REMAINING9)))
        recording=c.exact_object(storage.data[storage.output/'RECORDING_ONLY_METADATA_RECEIPT.json']);self.assertTrue(recording['metadata_scopes_revoked'])
        CLI_RECEIPTS.append(dict(status='PASS_GENERATED_REAL_CLI_CONTROL_PATH',actual_review_CPU_affinity=actual_affinity,CLI_resource_seam=resource_calls,guard_receipt=receipt,recording_receipt=recording,source_capture_seam_calls=calls,virtual_files=len(storage.data),virtual_output_bytes=sum(len(v)for k,v in storage.data.items()if storage.output in k.parents),persistent_source_output_files_created=0,persistent_authority_files_created=0,actual_source_reads=0,actual_financial_runs=0,review_policy='CODE_GENERATED_ONLY',testseams=['VirtualStorage.open/mkdir/stat/rglob/exists','generated_capture_with_exact_qualified_metadata','CPU2_request_observer_preserving_physical_CPU3']))
        LIFECYCLE.append(dict(source_scopes_created=1,scope_kind='EPHEMERAL_GENERATED_UNUSABLE_REVOKED',captured_years=calls,source_scopes_revoked=True,recording_scopes_revoked=True))

class Independent2021EndpointTests(unittest.TestCase):
    def test_exact_pinned_qualification_terminal_schema_bits_clocks_and_capture_route(self):
        import numpy as np
        inputs=t.fake_source(2021);contract=inputs[6];sidecar=c.exact_object(inputs[4]);q=c.exact_object(inputs[7]);rec=contract['months'][-1]
        final,_=codec.month_arrays(2021,inputs[5][-1][1],rec['start'],rec['count'])
        self.assertNotIn('final_endpoint_close',sidecar)
        self.assertEqual(len(q['actual_endpoint_quotes']),10)
        witness=source.qualified_terminal_witness_2021(inputs[7],sidecar,contract,final)
        self.assertEqual(len(witness['terminal_quotes']),5)
        self.assertTrue(witness['source_end_plus_one_witness_is_not_execution_authority'])
        self.assertFalse(witness['changes_native_execution_clock']);self.assertFalse(witness['historical_execution_authorized'])
        period=config.period_named(2021);mutations=[]
        for i in range(5,10):
            for key,value in [('symbol','OTHER'),('kind','fresh_start'),('open_us',period['end']-codec.MINUTE+1),('open_us',True),('available_us',period['end']-1),('available_us',True),('execution_clock_if_later_admitted_us',period['end']),('execution_clock_if_later_admitted_us',period['end']+2),('execution_clock_if_later_admitted_us',True),('available_before_proposed_execution',False),('available_before_proposed_execution',1),('actual_trade_close',-1.),('actual_trade_close',True),('actual_trade_close',float(np.nextafter(q['actual_endpoint_quotes'][i]['actual_trade_close'],np.inf))),('actual_mark_close',float(np.nextafter(q['actual_endpoint_quotes'][i]['actual_mark_close'],np.inf))),('UNEXPECTED',True)]:
                bad=deepcopy(q);bad['actual_endpoint_quotes'][i][key]=value;mutations.append((f'quote{i}_changed_{key}_{value}',bad))
            for key in q['actual_endpoint_quotes'][i]:
                bad=deepcopy(q);del bad['actual_endpoint_quotes'][i][key];mutations.append((f'quote{i}_missing_{key}',bad))
        bad=deepcopy(q);bad['actual_endpoint_quotes'].append(deepcopy(bad['actual_endpoint_quotes'][-1]));mutations.append(('terminal_duplicate',bad))
        bad=deepcopy(q);bad['actual_endpoint_quotes'][5:]=reversed(bad['actual_endpoint_quotes'][5:]);mutations.append(('terminal_reordered',bad))
        for key,value in [('schema','OLD_D'),('symbol_order',list(reversed(sig.SYMBOLS))),('actual_endpoint_quotes',{}),('actual_endpoint_quotes',[1])]:
            bad=deepcopy(q);bad[key]=value;mutations.append(('qualification_changed_'+key,bad))
        for label,bad in mutations:
            raw=c.canonical(bad);co=deepcopy(contract);co['qualification'].update(SHA256=c.sha(raw),bytes=len(raw));sc=deepcopy(sidecar);sc['qualification_SHA256']=c.sha(raw)
            with self.subTest(case=label):record_rejection('endpoint2021_'+label,lambda raw=raw,sc=sc,co=co:source.qualified_terminal_witness_2021(raw,sc,co,final))
        for key,value in [('qualification_SHA256','a'*64),('source_end_plus_one_witness_is_not_execution_authority',False),('source_end_plus_one_witness_is_not_execution_authority',1)]:
            sc=deepcopy(sidecar);sc[key]=value
            record_rejection('endpoint2021_sidecar_'+key+'_'+str(value),lambda sc=sc:source.qualified_terminal_witness_2021(inputs[7],sc,contract,final))
        for raw in (None,b'{}',inputs[7]+b' '):record_rejection('endpoint2021_wrong_qualification_bytes_'+str(type(raw)),lambda raw=raw:source.qualified_terminal_witness_2021(raw,sidecar,contract,final))
        for key in ('times',*[symbol+'_'+field for symbol in sig.SYMBOLS for field in ('close','mark')]):
            altered={k:v.copy() for k,v in final.items()}
            altered[key][-1]+=1 if key=='times' else float(np.spacing(altered[key][-1]))
            record_rejection('endpoint2021_final_bit_or_clock_'+key,lambda altered=altered:source.qualified_terminal_witness_2021(inputs[7],sidecar,contract,altered))
        real_contract=e.contracts()['years']['2021'];path=real_contract['qualification']['path']
        self.assertEqual(real_contract['read_files'][path],{k:real_contract['qualification'][k]for k in ('SHA256','bytes')})
        for old_code in ('e933c8c21fbbb2be1c6eb662ba6a377649d50661fb7eaec4306ac1adc3f7f230','2f12c4bdb21b3de079099d5f6c068154208e78dc12343d11f8605e48a0aea106'):
            gr,_,rr,_=t.fake_authority();g=c.exact_object(gr);r=c.exact_object(rr);r['code_manifest_SHA256']=old_code;rawr=c.canonical(r)
            g['code_manifest_SHA256']=old_code;g['independent_review_SHA256']=c.sha(rawr);rawg=c.canonical(g)
            record_rejection('old_checkpoint_authority_'+old_code,lambda rawg=rawg,rawr=rawr:e.validate_source_authority_metadata(rawg,c.sha(rawg),rawr,c.sha(rawr)))
        # Inspect the actual capture function's code, never call it on real sources.
        import ast
        tree=ast.parse((c.HERE/'cs_source.py').read_bytes());capture=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='capture_year')
        self.assertIn("contract['qualification']['path']",ast.unparse(capture))

class IndependentGuardAndScopeTests(unittest.TestCase):
    def test_no_follow_paths_and_generated_symlink_controls(self):
        import tempfile
        for name in ('','/tmp/a','../a','a/../b','./a','a//b','a\\b','.'):
            record_rejection('portable_path_'+repr(name),lambda name=name:c.relative(name))
        with tempfile.TemporaryDirectory(prefix='generated_cs_review_') as temp:
            root=Path(temp);ordinary=root/'generated_metadata.txt';ordinary.write_bytes(b'GENERATED_CODE_METADATA_ONLY')
            digest=c.sha(b'GENERATED_CODE_METADATA_ONLY')
            self.assertEqual(c.exact(ordinary,digest,28),b'GENERATED_CODE_METADATA_ONLY')
            link=root/'link.txt';link.symlink_to(ordinary)
            record_rejection('source_symlink_file',lambda:c.exact(link,digest,28))
            parent=root/'linked_parent';parent.symlink_to(root,target_is_directory=True)
            record_rejection('source_symlink_parent',lambda:c.exact(parent/'generated_metadata.txt',digest,28))
            record_rejection('source_wrong_bytes',lambda:c.exact(ordinary,digest,29))
            record_rejection('source_wrong_hash',lambda:c.exact(ordinary,'a'*64,28))

    def test_every_guard_counter_is_observed_fatal_and_prevents_stub_side_effect(self):
        import fcntl,importlib.util
        categories=SourceOnlyGuard.CATEGORIES
        for category in categories:
            touched=[];fixture=types.ModuleType('_independent_generated_boundaries');fixture.__source_guard_fixture__=True
            def touch(*a,**kw):touched.append(True)
            for name,methods in [('FakeAccount',{'__init__':touch,'advance_day':touch}),('NativeSimulator',{'__init__':touch,'advance_day':touch}),('HistoricalExecutionScope',{'__init__':touch}),('MinuteProvider',{'__iter__':touch})]:setattr(fixture,name,type(name,(),methods))
            guard=SourceOnlyGuard()
            actions={
                'financial_constructors':lambda:fixture.FakeAccount(),
                'financial_account_advance':lambda:object.__new__(fixture.FakeAccount).advance_day(),
                'native_simulator_construct_or_advance':lambda:fixture.NativeSimulator(),
                'historical_scope_mints':lambda:fixture.HistoricalExecutionScope(),
                'actual_provider_calls':lambda:iter(object.__new__(fixture.MinuteProvider)),
                'process_launches':lambda:os.system('NEVER_EXECUTED'),
                'network_calls':lambda:socket.create_connection(('invalid.test',443)),
                'canonical_financial_claims_or_leases':lambda:fcntl.flock(-1,fcntl.LOCK_EX),
                'financial_GO_writes':lambda:json.dumps({'schema':'FINANCIAL_GO','financial_execution_authorized':True}),
                'financial_imports':lambda:importlib.util.spec_from_file_location('not_loaded','/tmp/generated_not_loaded.py'),
                'outside_source_writes':lambda:open('/tmp/generated_guard_never_written.txt','w'),
                'nonallowlisted_file_reads':lambda:open(str(c.ROOT/'GENERATED_GUARD_NEVER_READ.txt'))}
            try:
                with self.subTest(category=category),self.assertRaises(SourceBoundaryViolation):
                    with guard:
                        # The stub module is installed only after clean-graph admission.
                        # This tests discovery blockers without importing any financial graph.
                        sys.modules[fixture.__name__]=fixture;guard._discover_loaded_boundaries()
                        try:actions[category]()
                        except SourceBoundaryViolation:pass
                self.assertEqual(guard.attempts[category],1);self.assertEqual(sum(guard.attempts.values()),1);self.assertEqual(touched,[])
                self.assertFalse(guard.active);self.assertIsNone(current_guard())
                NEGATIVE_GUARDS.append(guard.receipt('EXPECTED_GENERATED_'+category+'_STOP'))
            finally:sys.modules.pop(fixture.__name__,None)

    def test_generated_scope_invalid_year_pin_and_exception_revoke(self):
        authority=t.fake_authority();seen=[]
        record_rejection('admit_without_guard',lambda:e.admit_source_stage(*authority).__enter__())
        guard=SourceOnlyGuard(read_paths=t.source_read_paths())
        try:
            with guard:
                with e.admit_source_stage(*authority) as scope:
                    seen.append(scope)
                    for year in (2022,2023,2026,True,'2021'):
                        record_rejection('active_scope_wrong_year_'+str(year),lambda year=year:scope.qualification_for(year))
                    for name in ('../outside.csv','/tmp/outside.csv','not_a_qualified_file.json'):
                        record_rejection('active_scope_wrong_path_'+name,lambda name=name:scope.read_source(2021,name,'a'*64,1))
                    first=next(iter(e.contracts()['years']['2021']['read_files']))
                    record_rejection('active_scope_wrong_source_pin',lambda:scope.read_source(2021,first,'a'*64,1))
                    raise RuntimeError('GENERATED_SCOPE_EXCEPTION')
        except RuntimeError as exc:self.assertEqual(str(exc),'GENERATED_SCOPE_EXCEPTION')
        self.assertFalse(e._ACTIVE_SOURCE);self.assertFalse(any(guard.attempts.values()))
        for scope in seen:record_rejection('scope_revoked_after_exception',scope.validate_current)
        LIFECYCLE.append(dict(scope_kind='EPHEMERAL_GENERATED_EXCEPTION_PATH',source_scopes_created=1,source_scopes_revoked=True,actual_source_reads=0))

if __name__=='__main__':
    start=time.monotonic()
    suite=unittest.defaultTestLoader.loadTestsFromNames(['__main__.IndependentAdmissionTests','__main__.IndependentCLIAndLifecycleTests','__main__.IndependentGuardAndScopeTests','__main__.Independent2021EndpointTests'])
    # Code/hash checks have their own exact allowlist and require frozen code metadata.
    with ExitStack() as boundary:
        pure_boundary(boundary)
        result=unittest.TextTestRunner(verbosity=2).run(suite)
    out=dict(schema='INDEPENDENT_REMAINING9_CODE_GENERATED_ADVERSARIAL_TESTS_V1',status='PASS'if result.wasSuccessful()else'FAIL',source_folder=SOURCE.name,code_manifest_SHA256=e.code_identity(),tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),mutation_cases=MUTATIONS,expected_negative_guard_receipts=NEGATIVE_GUARDS,unexpected_acceptances=META_ACCEPTS,observed=dict(OBS),CLI_receipts=CLI_RECEIPTS,scope_lifecycle=LIFECYCLE,CPU_affinity=sorted(os.sched_getaffinity(0)),all_TID_affinities=[sorted(os.sched_getaffinity(int(x)))for x in os.listdir('/proc/self/task')],numerical_environment={k:os.environ[k]for k in THREAD_ENV},elapsed_seconds=time.monotonic()-start,source_scopes_revoked=not e._ACTIVE_SOURCE,recording_scopes_revoked=not e._ACTIVE_RECORDING)
    (REVIEW/'INDEPENDENT_ADDITIONAL_RECEIPT.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
    raise SystemExit(0 if result.wasSuccessful()else 1)
