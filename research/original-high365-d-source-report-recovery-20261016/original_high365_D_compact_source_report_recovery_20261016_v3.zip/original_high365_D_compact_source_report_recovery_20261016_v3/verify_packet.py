"""Stdlib-only compact HIGH365 source/report integrity and cross-binding checker.

This deliberately does not import historical code, reconstruct account events,
decode arrays, or certify historical financial execution.
"""
import csv
import copy
import hashlib
import io
import json
from pathlib import Path

NAME = 'original_high365_D_compact_source_report_recovery_20261016_v3'
SIGNAL = 'original_high365_signal_20261016_v1'
SOURCE = 'original_high365_D_source_20261016_v1'
NATIVE = 'original_high365_D_native_20261016_v1'
SAVED = 'original_high365_D_saved_independent_review_20261016_v1'
MATRIX = 'original_high365_D_saved_matrix_20261016_v1'
FIN = '96dac961eec4d01353feae6d542eb90c87f73c903833089068ce6eaf7432f640'
EXPERT = '0b913cc772d059175cc0c9e1e19af47c27d351bd032c1bae6f1ba885d08a76cd'
JSON_SHA = '2a2bf85958ebd692f8997955e3555de6117ffdb28673fc09e131850620ae0ba2'
CSV_SHA = 'b1ac7fc299d6a3fbc2f95341c282d233dceaa5163ad676b3d0f65f979d724a64'
ROOT_EXIT = '2c02b42c420e0a6e5ec726fcf5803c70a22badb302a64dfdb5a27a538fe69459'
GO = '3e4c709ec2174beca290f0169ea0c7ca322bcd231020c9b8c7e004cc65b40280'
DAYS = {2021:274, 2022:365, 2023:365, 2024:366, 2025:365}
CELLS = tuple(f'{y}_STATIC50_HIGH365_REFERENCE_HOLD_{t}_D_INTRINSIC_LOWER_ONLY_V1' for y in DAYS for t in ('LOW','MID','HIGH'))

def require(condition, message):
    if not condition:
        raise ValueError(message)

def unique(pairs):
    out = {}
    for key, value in pairs:
        require(key not in out, 'DUPLICATE_JSON_KEY:' + key)
        out[key] = value
    return out

def decode(data):
    def invalid(value):
        raise ValueError('NONFINITE_JSON:' + value)
    return json.loads(data, object_pairs_hook=unique, parse_constant=invalid)

def pin_bytes(data):
    return {'SHA256':hashlib.sha256(data).hexdigest(), 'bytes':len(data)}

def pin(path):
    require(path.is_file() and not path.is_symlink(), 'REGULAR_FILE_REQUIRED:' + str(path))
    return pin_bytes(path.read_bytes())

def valid_relative(name):
    return (type(name) is str and name and '\\' not in name and ':' not in name
            and all(p not in ('', '.', '..') for p in name.split('/'))
            and not name.startswith('/'))

def load(root, rel):
    require(valid_relative(rel), 'UNSAFE_RELATIVE_PATH')
    return decode((root / rel).read_bytes())

def check_rows(report):
    require(report.get('schema') == 'HIGH365_REVIEWED_SAVED_COST_MDD_EXPOSURE_MATRIX_V1', 'REPORT_SCHEMA')
    require(type(report.get('rows')) is list and len(report['rows']) == 15, 'EXACT_15_ROWS')
    require([r['cell_id'] for r in report['rows']] == list(CELLS), 'EXACT_ALL15_ORDER')
    require(report.get('native_code_manifest_SHA256') == FIN, 'REPORT_FIN_PIN')
    require(report.get('root_GO_SHA256') == GO, 'REPORT_AUTHORITY_HASH_PIN')
    require(report.get('saved_only') is True and report.get('source_arrays_read') is False
            and report.get('new_financial_execution') is False
            and report.get('annual_wallets_compounded') is False, 'REPORT_SCOPE')
    for r in report['rows']:
        year = r['year']
        require(type(year) is int and year in DAYS, 'YEAR_TYPE')
        require(type(r['calendar_days']) is int and r['calendar_days'] == DAYS[year], 'CALENDAR')
        require(type(r['completed_minutes']) is int and r['completed_minutes'] == DAYS[year]*1440, 'COMPLETED_MINUTES')
        require(r['required_minutes'] == r['completed_minutes'], 'REQUIRED_MINUTES')
        require(r['full_calendar'] is True and r['full_year'] is (year != 2021), 'PARTIAL2021_SCOPE')
        require(r['independent_fresh_cash_USDT'] == '10000', 'FRESH_WALLET')
        require(r['paid_market_flat'] is True and r['terminal_status'] == 'FULL_CALENDAR_ACTUAL_PAID_MARKET_FLAT', 'PAID_FLAT')
        require(r['unpaid_liability_USDT'] == '0', 'NO_UNPAID')
    return report['rows']

def verify_dependency_classification(document, actual_files, expected_dependencies):
    """Resolve exact identities over all actual packet locations, not prefixes."""
    dependencies = document.get('dependencies')
    require(type(dependencies) is dict and set(dependencies) == set(expected_dependencies), 'DEPENDENCY_SET')
    require(document.get('external_dependencies_executed') is False, 'DEPENDENCY_EXECUTION_SCOPE')
    for original, entry in dependencies.items():
        original_pin = entry.get('original_pin')
        require(original_pin == expected_dependencies[original], 'DEPENDENCY_ORIGINAL_PIN:' + original)
        matches = sorted(rel for rel, recorded in actual_files.items() if recorded == original_pin)
        included = bool(matches)
        require(type(entry.get('body_in_packet')) is bool and entry['body_in_packet'] is included, 'DEPENDENCY_BODY_FLAG:' + original)
        expected_class = 'INCLUDED_EXACT_DEPENDENCY_BODY' if included else 'EXTERNAL_RUNTIME_OR_SOURCE_DEPENDENCY_HASH_ONLY'
        require(entry.get('classification') == expected_class, 'DEPENDENCY_CLASSIFICATION:' + original)
        require(entry.get('included_packet_paths') == matches, 'DEPENDENCY_EXACT_LOCATIONS:' + original)
        require(entry.get('hash_restores_bytes') is False, 'DEPENDENCY_HASH_LIMIT:' + original)
    return len(dependencies)

def generated_dependency_checks():
    review_pin = pin_bytes(b'GENERATED_REVIEW_ONLY')
    missing_pin = pin_bytes(b'GENERATED_OMITTED_ONLY')
    actual = {'reviews/example/PREPARED_INDEPENDENT_REVIEW.json':review_pin,
              'alternate_allowed_location/same_review.json':review_pin}
    expected = {'example/PREPARED_INDEPENDENT_REVIEW.json':review_pin, 'external/runtime.py':missing_pin}
    base = {'external_dependencies_executed':False,'dependencies':{
        'example/PREPARED_INDEPENDENT_REVIEW.json':dict(original_pin=review_pin,body_in_packet=True,classification='INCLUDED_EXACT_DEPENDENCY_BODY',included_packet_paths=sorted(actual),hash_restores_bytes=False),
        'external/runtime.py':dict(original_pin=missing_pin,body_in_packet=False,classification='EXTERNAL_RUNTIME_OR_SOURCE_DEPENDENCY_HASH_ONLY',included_packet_paths=[],hash_restores_bytes=False)}}
    verify_dependency_classification(base,actual,expected)
    bad=[]
    for key,value in (('body_in_packet',False),('classification','EXTERNAL_RUNTIME_OR_SOURCE_DEPENDENCY_HASH_ONLY'),('included_packet_paths',[]),('body_in_packet',1)):
        x=copy.deepcopy(base);x['dependencies']['example/PREPARED_INDEPENDENT_REVIEW.json'][key]=value;bad.append(x)
    for key,value in (('body_in_packet',True),('classification','INCLUDED_EXACT_DEPENDENCY_BODY'),('included_packet_paths',['reviews/missing.json'])):
        x=copy.deepcopy(base);x['dependencies']['external/runtime.py'][key]=value;bad.append(x)
    x=copy.deepcopy(base);x['dependencies']['example/PREPARED_INDEPENDENT_REVIEW.json']['original_pin']=missing_pin;bad.append(x)
    for x in bad:
        try:
            verify_dependency_classification(x,actual,expected)
        except ValueError:
            continue
        raise ValueError('GENERATED_CONTRADICTORY_DEPENDENCY_ACCEPTED')
    return {'positive_included_review_and_alternate_location_controls':1,'rejected_contradictory_dependency_controls':len(bad)}

def generated_checks():
    """Generated metadata-only adversarial controls; no historical execution."""
    base = dict(schema='HIGH365_REVIEWED_SAVED_COST_MDD_EXPOSURE_MATRIX_V1',
                native_code_manifest_SHA256=FIN, root_GO_SHA256=GO, saved_only=True,
                source_arrays_read=False, new_financial_execution=False, annual_wallets_compounded=False,
                rows=[dict(cell_id=cell, year=int(cell[:4]), calendar_days=DAYS[int(cell[:4])],
                           completed_minutes=DAYS[int(cell[:4])]*1440,
                           required_minutes=DAYS[int(cell[:4])]*1440,
                           full_calendar=True, full_year=int(cell[:4]) != 2021,
                           independent_fresh_cash_USDT='10000', paid_market_flat=True,
                           terminal_status='FULL_CALENDAR_ACTUAL_PAID_MARKET_FLAT', unpaid_liability_USDT='0') for cell in CELLS])
    check_rows(base)
    bad = []
    x=copy.deepcopy(base);x['rows'].pop();bad.append(x)
    x=copy.deepcopy(base);x['rows'][0]=copy.deepcopy(x['rows'][1]);bad.append(x)
    x=copy.deepcopy(base);x['rows'][0]['year']=True;bad.append(x)
    x=copy.deepcopy(base);x['rows'][0]['full_year']=True;bad.append(x)
    x=copy.deepcopy(base);x['rows'][0]['calendar_days']=365;bad.append(x)
    x=copy.deepcopy(base);x['rows'][0]['completed_minutes']=1;bad.append(x)
    x=copy.deepcopy(base);x['rows'][0]['paid_market_flat']=False;bad.append(x)
    x=copy.deepcopy(base);x['rows'][0]['independent_fresh_cash_USDT']='20000';bad.append(x)
    x=copy.deepcopy(base);x['root_GO_SHA256']='0'*64;bad.append(x)
    x=copy.deepcopy(base);x['native_code_manifest_SHA256']='0'*64;bad.append(x)
    x=copy.deepcopy(base);x['annual_wallets_compounded']=True;bad.append(x)
    x=copy.deepcopy(base);x['new_financial_execution']=True;bad.append(x)
    for x in bad:
        try:
            check_rows(x)
        except (ValueError,KeyError):
            continue
        raise ValueError('GENERATED_BAD_METADATA_ACCEPTED')
    for data in (b'{"x":1,"x":2}',b'{"x":NaN}',b'{"x":Infinity}'):
        try:
            decode(data)
        except ValueError:
            continue
        raise ValueError('GENERATED_INVALID_JSON_ACCEPTED')
    require(all(not valid_relative(p) for p in ('../escape','/absolute','a//b','a/./b','a\\b','C:/x')), 'GENERATED_UNSAFE_PATH_ACCEPTED')
    return {'positive_metadata_controls':1,'rejected_metadata_controls':12,'rejected_JSON_controls':3,'rejected_path_controls':6}

def verify(root):
    root = Path(root).resolve()
    manifest = load(root, 'MANIFEST.json')
    require(manifest.get('schema') == 'HIGH365_COMPACT_SOURCE_REPORT_RECOVERY_V1', 'PACKET_SCHEMA')
    expected = manifest['files']
    require(type(expected) is dict and all(valid_relative(x) for x in expected), 'MANIFEST_PATHS')
    actual = {}
    for path in sorted(root.rglob('*')):
        require(not path.is_symlink(), 'SYMLINK_FORBIDDEN')
        if path.is_file() and path != root/'MANIFEST.json':
            actual[str(path.relative_to(root))] = pin(path)
    require(actual == expected, 'EXACT_INVENTORY_AND_PINS')
    require(sum(v['bytes'] for v in actual.values()) < 5_000_000, 'PACKET_BODY_SIZE_BOUND')
    for rel in actual:
        require(not rel.endswith(('.npz','.npy','.parquet','.pyc','.zip')), 'ARRAY_OR_ARCHIVE_BODY_FORBIDDEN')
        require(Path(rel).name not in ('ADMISSION_GO.json','LAUNCH_CLAIM.json','SOURCE_STAGE_AUTHORIZATION.json','RAW_EVENTS.json','NATIVE_RESULT.json','ACCOUNT_FINANCIAL_AUDIT.json'), 'AUTHORITY_OR_BULKY_BODY_FORBIDDEN')
    provenance = load(root, 'PROVENANCE_FILE_MAP.json')
    require(provenance['all_copies_exact_original_bytes'] is True, 'EXACT_COPY_POLICY')
    by_original = {}
    for rel, entry in provenance['files'].items():
        require(pin(root/rel) == entry['original_pin'], 'ORIGINAL_BYTE_IDENTITY:' + rel)
        require(entry['transformation'] == 'EXACT_EXISTING_BYTES', 'UNEXPECTED_TRANSFORMATION')
        by_original[entry['original_path']] = rel
    expected_dependencies = {}
    for folder, manifest_name in ((SIGNAL,'CODE_MANIFEST.json'),(SOURCE,'CODE_MANIFEST.json'),(NATIVE,'FINANCIAL_CODE_MANIFEST.json')):
        code_manifest = load(root, 'snapshots/'+folder+'/'+manifest_name)
        for original, recorded in code_manifest.get('dependencies',{}).items():
            if original in expected_dependencies:
                require(expected_dependencies[original] == recorded, 'CONTRADICTORY_FROZEN_DEPENDENCY_PIN')
            expected_dependencies[original] = recorded
        for rel, recorded in code_manifest['files'].items():
            p = root/'snapshots'/folder/rel
            require(pin(p) == {'SHA256':recorded['SHA256'], 'bytes':recorded['bytes']}, 'INERT_CODE_MANIFEST:' + folder+'/'+rel)
    dependency_count = verify_dependency_classification(load(root,'DEPENDENCY_CLASSIFICATION.json'),actual,expected_dependencies)
    require(pin(root/'snapshots'/NATIVE/'FINANCIAL_CODE_MANIFEST.json')['SHA256'] == FIN, 'FINAL_FIN_IDENTITY')
    require(pin(root/'snapshots'/SIGNAL/'pinned/expert.py')['SHA256'] == EXPERT, 'ORIGINAL_EXPERT_IDENTITY')
    refs = load(root, 'PUBLIC_SOURCE_REFERENCE.json')
    require(refs['commit'] == '1bbc51212c9cf7b7569c1a252efd0e923c2e70c5' and refs['expert_SHA256'] == EXPERT, 'EXACT_PUBLIC_EXPERT_PIN')
    require(pin(root/'results/COST_MDD_EXPOSURE_MATRIX.json')['SHA256'] == JSON_SHA, 'EXACT_REPORT_JSON')
    require(pin(root/'results/COST_MDD_EXPOSURE_MATRIX.csv')['SHA256'] == CSV_SHA, 'EXACT_REPORT_CSV')
    report = load(root, 'results/COST_MDD_EXPOSURE_MATRIX.json')
    rows = check_rows(report)
    # Exact pins authenticate the original CSV bytes. This additionally checks
    # identities and row coverage without float coercion or recalculation.
    csv_rows = list(csv.DictReader(io.StringIO((root/'results/COST_MDD_EXPOSURE_MATRIX.csv').read_text())))
    require([r['cell_id'] for r in csv_rows] == list(CELLS), 'CSV_ALL15_COVERAGE')
    matrix_review = load(root, 'reviews/'+SAVED+'/FINAL_MATRIX_INDEPENDENT_REVIEW.json')
    require(matrix_review['status'] == 'PASS' and matrix_review['reviewed_rows'] == 15, 'MATRIX_REVIEW_PASS')
    for key, rel in (('JSON','results/COST_MDD_EXPOSURE_MATRIX.json'),('CSV','results/COST_MDD_EXPOSURE_MATRIX.csv')):
        require(pin(root/rel) == {k:matrix_review[key][k] for k in ('SHA256','bytes')}, 'MATRIX_REVIEW_BINDING')
    original_inputs = load(root, 'FINAL_INPUT_PINS.json')
    for original, recorded in original_inputs['required_exact_inputs'].items():
        require(original in by_original and pin(root/by_original[original]) == recorded, 'FINAL_INPUT_PIN:' + original)
    for row in rows:
        cell = row['cell_id']
        review_rel = 'reviews/'+SAVED+'/'+cell+'.review.json'
        review = load(root, review_rel)
        require(pin(root/review_rel)['SHA256'] == row['independent_saved_review_SHA256'], 'CELL_REVIEW_PIN')
        require(review['status'] == 'PASS_SAVED_ONLY' and review['cell_id'] == cell, 'CELL_REVIEW_STATUS')
        require(review['completed_minutes'] == row['completed_minutes'] and review['paid_flat'] is True, 'CELL_REVIEW_CALENDAR')
        if row['year'] in (2022,2024):
            require(review['quality']['derived_mark_cells'] == {2022:27,2024:10}[row['year']], 'CELL_UNKNOWN_CARRY_COUNT')
        checkpoint_rel = 'cases/'+cell+'/TERMINAL_CHECKPOINT.json'
        checkpoint = load(root, checkpoint_rel)
        require(pin(root/checkpoint_rel)['SHA256'] == row['terminal_checkpoint_SHA256'], 'CHECKPOINT_PIN')
        require(checkpoint['cell_id'] == cell, 'CHECKPOINT_CELL')
        for filename in ('CASE_RECEIPT.json','ACTUAL_HELD_RISK_REPORT.json','NATIVE40_RECONSTRUCTION_PROOF.json','PRIMARY_FINANCIAL_RECONCILIATION.json','LEGACY_PRIMARY_FINANCIAL_RECONCILIATION.json','CAUSAL_MARK_QUALITY.json'):
            require(pin(root/'cases'/cell/filename)['SHA256'] == checkpoint['files'][filename], 'CHECKPOINT_INCLUDED_PIN')
        case = load(root, 'cases/'+cell+'/CASE_RECEIPT.json')
        require(case['financial_code_manifest_SHA256'] == FIN and case['root_GO_SHA256'] == GO, 'CASE_FINAL_AUTHORITY_HASH')
        require(case['completed_minutes'] == row['completed_minutes'] and case['status'] == row['terminal_status'], 'CASE_REPORT_STATUS')
    exit_rel = 'receipts/ROOT_OBSERVED_EXIT_CONFIRMED.json'
    require(pin(root/exit_rel)['SHA256'] == ROOT_EXIT, 'ROOT_EXIT_PIN')
    scope = load(root, 'SCOPE_AND_LIMITS.json')
    require(scope['case_count'] == 15 and scope['completed_minutes'] == 7495200, 'SCOPE_COVERAGE')
    for key in ('publication_performed','source_or_financial_execution_authorized','financial_history_self_contained','saved_event_reconstruction_self_contained','OOS_or_live_certification','hashes_restore_omitted_bytes'):
        require(scope[key] is False, 'LIMIT_REQUIRED_FALSE:' + key)
    quality = load(root, 'reviews/'+SAVED+'/SOURCE_QUALITY_SAVED_SUPPLEMENT.json')
    require([q['cell_id'] for q in quality['rows']] == list(CELLS[:6]), 'SUPPLEMENT_EXACT2021_AND2022_COVERAGE')
    for q in quality['rows']:
        if q['year'] in (2022,2024):
            require(q['UNKNOWN_original_age_carries'] == {2022:27,2024:10}[q['year']], 'UNKNOWN_CARRY_PRESERVED')
    aggregate = load(root, 'reviews/'+SAVED+'/FINAL_INDEPENDENT_SAVED_AUDIT.json')
    require(aggregate['actual2024_all3_cases_hold_nonzero_positions_in_all10_UNKNOWN_asset_minutes'] is True, 'FINAL2024_QUALITY_BINDING')
    require(aggregate['root_observed_exit_code'] == 0 and aggregate['completed_cases'] == 15, 'FINAL_AGGREGATE_EXIT_AND_COVERAGE')
    return {'status':'PASS_COMPACT_SOURCE_REPORT_CROSS_BINDINGS_ONLY', 'case_count':15,
            'completed_minutes':7495200, 'inventory_files':len(actual)+1,
            'financial_event_reconstruction_performed':False, 'historical_modules_imported':False,
            'arrays_decoded':False, 'publication_performed':False, 'generated_checks':generated_checks(),
            'dependency_classifications_verified':dependency_count,'generated_dependency_checks':generated_dependency_checks()}

if __name__ == '__main__':
    print(json.dumps(verify(Path(__file__).resolve().parent), sort_keys=True))
