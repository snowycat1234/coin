# Independent review: original HIGH365 generated-only adapter

Verdict: PASS for original-signal reconstruction and generated common-D signal adaptation. No signal-code change is needed in the reviewed adapter. This is a code/generated-array finding, with no historical source admission, financial authorization, historical performance claim, or publication action.

## Reviewed identity

- Candidate: `original_high365_signal_20261016_v1/high365_signal.py`
- Adapter SHA256: `b3439ec67967fba74065bfae9734c3557050d4d34a2eee6e18fc275679d56b63`
- Frozen SOURCE_PINS.json SHA256: `4968b9ae11ec40f695ffa5994bdc262a9b90a1401d7cf1458b8e744691a771e9`
- Original expert provenance: commit `1bbc51212c9cf7b7569c1a252efd0e923c2e70c5`, path `research/high-reference-expert-20261012/expert.py`, Git blob `3acfc60517f51637c37cfeecde1e1dadc49bdc96`, SHA256 `0b913cc772d059175cc0c9e1e19af47c27d351bd032c1bae6f1ba885d08a76cd`.
- The original commit/path/blob relationship was checked against the existing literal-code inventory pin record. No network or fresh remote verification was performed. The exact expert bytes and every other pinned source file were independently matched against their recorded local code origins, SHA256, Git-blob SHA1, and length.

## Findings

1. Exact original functions are AST-isolated and executed without importing their market/financial research runners. The selected original `targets`, `same_match_and_mix`, `scale`, `signed_intents`, `market_neutral`, and `signed_risk_weights` retain their original function ASTs. Reviewed injected constants match the original literals. The original rolling200 `mean` and `signal` statements are preserved; HOLD is original signed_intents column2, including its feature-finiteness membership rule.
2. Weekly ownership is preserved at the fixed 2024-01-01 anchor. Starting an output calendar midweek restores that week's scheduled rank rather than reranking on the first output day. Per-asset missing365 clears held intent; later eligibility recovery cannot restore it before the next scheduled weekly rank. Stable order ties, full-tie cash, and minimum-four admission remain original behavior.
3. Source-clock admission requires the actual calendar to begin no later than the owning rank's 365th completed close. It does not fabricate full-five365 eligibility or shorten the decision calendar. Missing older history remains per-asset ineligibility. Every output day independently requires five finite positive completed200-close histories for original HOLD. The exact boundary of200 finite closes admits;199 rejects.
4. Both component risk and common-D annual covariance retain30 simple returns from31 completed closes, inclusive of the current completed close, ddof1, annualization365. Proof oldest/latest clocks were independently checked on every output day.
5. Original risk matching is common=min(10%, HIGH365 sigma, HOLD sigma), followed by fixed50/50 mixing and the original intrinsic risk_budget.scale. That intrinsic operation can enlarge the matched mixture. This is preserved before applying the new lower-only tiers. Every generated fixture day exercised an intrinsic factor above1. The later fixed tier factors are at most1, preserve signs/cash, and enforce gross/asset/volatility ceilings. HIGH and MID can coincide when the intrinsic envelope already fits; this is intended lower-only behavior.
6. An independently transcribed oracle, which does not call the adapter or original functions for its formulas, produced byte-identical decision clocks, component targets, current eligibility masks, annual covariance, intrinsic targets, and all three tier outputs across274/365/365/366/365 days for the five fixed generated DEV calendars. Identities are retained in GENERATED_CALENDAR_IDENTITIES.json; no target-array bodies are saved.
7. Multiple prefix cutoffs at and between weekly ranks preserved every output byte and proof when future rows were removed or poisoned with NaN. Outputs are bytes-backed read-only arrays that cannot be made writeable; later caller-input mutation cannot change them.
8. Native dtype, complete daily clock, shape, fixed CORE5 order, completed-close availability namespace, and source-span checks are fail-closed. Independent malformed dtype/shape/clock/covariance tests passed. Changing a pinned source byte, changing the pin-map bytes, or replacing a pinned source with a symlink is rejected.

## Verification

- Independently reran all13 author tests: PASS, 5.951s.
- Added and ran10 independent generated-only review tests: PASS, 5.821s.
- Tests ran serially on CPU7. OPENBLAS_NUM_THREADS, OMP_NUM_THREADS, MKL_NUM_THREADS, NUMEXPR_NUM_THREADS, VECLIB_MAXIMUM_THREADS, and BLIS_NUM_THREADS were all1; the independent suite asserts affinity and these environment values.
- No CPU4/5 execution, existing-run modification, actual market input bodies, source preparation, providers, accounts, holdouts, network, Library, or public uploads. Only literal source code, source metadata, and generated arrays were inspected or used. The reviewed adapter and author tests were left unchanged.

## Minimal next engineering step

Implement an additive generated-only HIGH365 common-D binding that consumes these exact immutable target keys. Reuse the already reviewed common-D process/account/execution logic unchanged. Its generated tests should cover all15 fixed year/tier bindings, target-byte identity and ordered clocks, using the full365 owning-rank prefix rather than reusing the half-SMA200-only prefix assumption, and rejection of changed module/source pins or mismatched calendars. Preserve recipe-specific identity and lower-only ordering. Do not create or reuse any historical preparation/financial authority as part of that step.

This is a concrete integration step; another signal rewrite or report-only approval loop is unnecessary. Historical source qualification and any financial run remain separate, currently unperformed work.
