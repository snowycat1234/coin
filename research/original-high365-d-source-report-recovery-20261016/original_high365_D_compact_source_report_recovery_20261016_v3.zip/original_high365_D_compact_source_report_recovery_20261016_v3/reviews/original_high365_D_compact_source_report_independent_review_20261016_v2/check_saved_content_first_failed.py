"""Independent compact-only saved report/provenance audit. Stdlib data reads only.

Historical source, report builders, and saved financial validators are inert.
No array, account, native event ledger, provider, authority, or claim is loaded.
"""
import csv
from decimal import Decimal, localcontext
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import sys
import zipfile


def need(ok, message):
    if not ok:
        raise ValueError(message)


def unique(pairs):
    result = {}
    for key, value in pairs:
        need(key not in result, "DUPLICATE_JSON_KEY:" + key)
        result[key] = value
    return result


def reject_constant(value):
    raise ValueError("NONFINITE_JSON:" + value)


def decode(raw):
    return json.loads(raw, object_pairs_hook=unique, parse_constant=reject_constant)


def pin(raw):
    return {"SHA256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw)}


root = Path(sys.argv[1]).resolve()
output = Path(sys.argv[2]).resolve()
predecessor = Path(sys.argv[3]).resolve()
need(os.sched_getaffinity(0) == {6}, "CPU6_REQUIRED")
files = {}
for path in root.rglob("*"):
    need(not path.is_symlink(), "NO_SYMLINK")
    if path.is_file():
        need(stat.S_ISREG(path.stat().st_mode), "REGULAR_ONLY")
        files[str(path.relative_to(root))] = path.read_bytes()
need(len(files) == 267 and sum(map(len, files.values())) == 3594943, "EXACT_COUNTS")
data = {name: decode(raw) for name, raw in files.items() if name.endswith(".json")}
manifest = data["MANIFEST.json"]["files"]
need(manifest == {n: pin(b) for n, b in files.items() if n != "MANIFEST.json"}, "EXACT_MANIFEST")
bom = data["BILL_OF_MATERIALS.json"]["files"]
need(set(bom) == set(files) - {"MANIFEST.json", "BILL_OF_MATERIALS.json"}, "BOM_COVERAGE")
need(all({k: p[k] for k in ("SHA256", "bytes")} == pin(files[n]) for n, p in bom.items()), "BOM_PINS")
provenance = data["PROVENANCE_FILE_MAP.json"]["files"]
by_original = {p["original_path"]: n for n, p in provenance.items()}
need(len(by_original) == len(provenance), "PROVENANCE_UNIQUE_ORIGINALS")
need(all(p["original_pin"] == pin(files[n]) and p["transformation"] == "EXACT_EXISTING_BYTES" for n, p in provenance.items()), "EXACT_PROVENANCE")
saved = "reviews/original_high365_D_saved_independent_review_20261016_v1/"
trusted = {
    saved + "FINAL_INDEPENDENT_SAVED_AUDIT.json": "d5b6ec882caf7e0a8bc4e26708c10c742394add2424442e3627716ca09691fde",
    saved + "FINAL_MATRIX_INDEPENDENT_REVIEW.json": "ccf075f2b29cc45084b957e1da9602b95077513575303dc53110a1a740f661cb",
    "results/COST_MDD_EXPOSURE_MATRIX.json": "2a2bf85958ebd692f8997955e3555de6117ffdb28673fc09e131850620ae0ba2",
    "results/COST_MDD_EXPOSURE_MATRIX.csv": "b1ac7fc299d6a3fbc2f95341c282d233dceaa5163ad676b3d0f65f979d724a64",
    "results/ORIGINAL37_COMPLETION_DELTA.json": "c9d1963c58b9fbcfd71f105acb6f6da8bc3dce4fd336daf5affef1f6afac9b51",
    "snapshots/original_high365_D_native_20261016_v1/FINANCIAL_CODE_MANIFEST.json": "96dac961eec4d01353feae6d542eb90c87f73c903833089068ce6eaf7432f640",
    "snapshots/original_high365_signal_20261016_v1/pinned/expert.py": "0b913cc772d059175cc0c9e1e19af47c27d351bd032c1bae6f1ba885d08a76cd",
}
need(all(pin(files[n])["SHA256"] == h for n, h in trusted.items()), "EXTERNAL_GROUND_TRUTH")
for original, expected in data["FINAL_INPUT_PINS.json"]["required_exact_inputs"].items():
    need(original in by_original and pin(files[by_original[original]]) == expected, "FINAL_PIN")

report = data["results/COST_MDD_EXPOSURE_MATRIX.json"]
rows = report["rows"]
days = {2021: 274, 2022: 365, 2023: 365, 2024: 366, 2025: 365}
cells = [f"{year}_STATIC50_HIGH365_REFERENCE_HOLD_{tier}_D_INTRINSIC_LOWER_ONLY_V1" for year in days for tier in ("LOW", "MID", "HIGH")]
need([row["cell_id"] for row in rows] == cells, "ALL15_ALL5YEARS")
csv_rows = list(csv.DictReader(io.StringIO(files["results/COST_MDD_EXPOSURE_MATRIX.csv"].decode())))
need(len(csv_rows) == 15 and set(csv_rows[0]) == set(rows[0]), "EXACT_CSV_COLUMNS")
csv_cells = 0
for row, csv_row in zip(rows, csv_rows):
    for key, value in row.items():
        rendered = json.dumps(value, sort_keys=True) if isinstance(value, dict) else "" if value is None else str(value)
        need(csv_row[key] == rendered, "CSV_JSON_EXACT_CELL:" + row["cell_id"] + ":" + key)
        csv_cells += 1
scope_cells = {c["cell_id"]: c for c in data["snapshots/original_high365_D_native_20261016_v1/FROZEN_FIFTEEN_CELL_MANIFEST.json"]["cells"]}
risk_map = {
    "risk_status": "status", "risk_observation_count": "observation_count",
    "risk_omitted_nonpositive_or_later_minutes": "omitted_nonpositive_or_later_minutes",
    "mean_minute_gross_exposure": "gross_exposure_mean", "max_minute_gross_exposure": "gross_exposure_max",
    "mean_minute_net_signed_exposure": "actual_net_signed_weight_mean",
    "max_minute_absolute_asset_exposure": "asset_exposure_absolute_max",
    "forecast_annual_vol_mean": "forecast_annual_volatility_mean", "forecast_annual_vol_max": "forecast_annual_volatility_max",
    "nominal_annual_vol_budget": "nominal_annual_volatility_budget", "forecast_vol_breach_minutes": "forecast_volatility_breach_minutes",
    "realized_daily_return_annual_vol": "realized_daily_simple_return_annual_volatility",
    "raw_target_gross_mean": "raw_target_gross_mean", "raw_target_gross_max": "raw_target_gross_max",
    "positive_raw_target_minus_actual_gross_mean": "positive_raw_target_minus_actual_gross_mean",
    "min_minute_free_cash_USDT": "minimum_observed_free_cash_USDT", "max_minute_isolated_margin_USDT": "maximum_observed_isolated_margin_USDT",
    "minutes_free_cash_below1000": "minutes_observed_free_cash_below1000", "minutes_margin_above8500": "minutes_observed_margin_above8500",
    "actual_absolute_weight_max_by_symbol": "actual_absolute_weight_max_by_symbol",
    "actual_absolute_weight_mean_by_symbol": "asset_exposure_absolute_mean_by_symbol", "guard_selection_counts": "guard_selection_counts",
}
review_map = {
    "terminal_NAV_USDT": "exact_NAV", "independent_fresh_cash_USDT": "fresh_shared_initial_cash",
    "fees_USDT": "fees_USDT", "combined_spread_slippage_cost_USDT": "execution_cost_USDT",
    "signed_funding_cash_USDT": "funding_USDT", "gross_paid_fill_turnover_USDT": "gross_fill_turnover_USDT",
    "all_observation_max_drawdown": "all_observation_max_drawdown", "terminal_status": "terminal_status",
    "unpaid_liability_USDT": "unpaid_liability", "trade_legs": "trade_legs", "paid_market_flat": "paid_flat",
    "completed_minutes": "completed_minutes", "required_minutes": "required_minutes", "full_calendar": "full_calendar",
}
comparisons = 0
summary = []
for row in rows:
    cell = row["cell_id"]
    prefix = "cases/" + cell + "/"
    receipt, risk = data[prefix + "CASE_RECEIPT.json"], data[prefix + "ACTUAL_HELD_RISK_REPORT.json"]
    review, checkpoint = data[saved + cell + ".review.json"], data[prefix + "TERMINAL_CHECKPOINT.json"]
    frozen = scope_cells[cell]
    need(row["calendar_days"] == days[row["year"]] and row["completed_minutes"] == days[row["year"]] * 1440, "CALENDARS")
    need(row["full_year"] is (row["year"] != 2021) and row["paid_market_flat"] is True and row["full_calendar"] is True, "PAID_FLAT_FULL")
    need(row["terminal_status"] == "FULL_CALENDAR_ACTUAL_PAID_MARKET_FLAT" and row["independent_fresh_cash_USDT"] == "10000", "FLAT_AND_FRESH")
    for key in ("year", "tier", "start_UTC", "end_exclusive_UTC", "calendar_days"):
        need(row[key] == frozen[key], "FROZEN_SCOPE:" + key)
    need(frozen["fresh_independent_wallet_per_cell"] is True and frozen["original_execution_unchanged"] is False and frozen["financial_reuse_allowed"] is False, "ADAPTATION_NOT_REPLICATION")
    for key, original_key in risk_map.items():
        need(row[key] == risk[original_key], "RISK_SELECTION:" + key)
        comparisons += 1
    for key, original_key in review_map.items():
        need(row[key] == review[original_key], "REVIEW_SELECTION:" + key)
        comparisons += 1
    for key, original_key in {"CPU_seconds": "CPU_seconds", "wall_seconds": "total_wall_seconds", "max_RSS_bytes": "max_RSS_bytes"}.items():
        need(row[key] == receipt[original_key], "RECEIPT_SELECTION:" + key)
        comparisons += 1
    need(pin(files[saved + cell + ".review.json"])["SHA256"] == row["independent_saved_review_SHA256"], "REVIEW_HASH")
    need(pin(files[prefix + "TERMINAL_CHECKPOINT.json"])["SHA256"] == row["terminal_checkpoint_SHA256"], "CHECKPOINT_HASH")
    for filename in ("CASE_RECEIPT.json", "ACTUAL_HELD_RISK_REPORT.json", "NATIVE40_RECONSTRUCTION_PROOF.json", "PRIMARY_FINANCIAL_RECONCILIATION.json", "LEGACY_PRIMARY_FINANCIAL_RECONCILIATION.json", "CAUSAL_MARK_QUALITY.json"):
        need(pin(files[prefix + filename])["SHA256"] == checkpoint["files"][filename], "INCLUDED_TERMINAL_BINDING")
    need(data[prefix + "NATIVE40_RECONSTRUCTION_PROOF.json"]["exact_native40_NAV"] == row["terminal_NAV_USDT"], "PRIOR_PROOF_NAV")
    need(files[prefix + "NATIVE40_RECONSTRUCTION_PROOF.json"] == files[prefix + "PRIMARY_FINANCIAL_RECONCILIATION.json"], "AUTHORITATIVE_PROOF_COPY")
    with localcontext() as context:
        context.prec = 100
        need(str(Decimal(row["net_PnL_USDT"]) / Decimal("10000")) == row["paid_net_return"], "PAID_RETURN_EXACT_RATIO")
        need(str(Decimal(row["gross_paid_fill_turnover_USDT"]) / Decimal("10000")) == row["turnover_over_initial_cash"], "TURNOVER_EXACT_RATIO")
    quality = review["quality"]
    expected_unknown = {2022: 27, 2024: 10}.get(row["year"], 0)
    need(quality["derived_mark_cells"] == expected_unknown, "UNKNOWN_COUNTS")
    need(sum(sum(i["nonzero_position_minute_cells_by_symbol"].values()) for i in quality.get("actual_saved_interval_impacts", [])) == expected_unknown, "UNKNOWN_ACTUAL_POSITIONS")
    need(row["quality_intervals"] == quality["interval_count"] and row["quality_block_rows"] == quality["quality_block_rows"], "QUALITY_SELECTION")
    if row["year"] == 2022:
        need(quality["interval_count"] == 7, "2022_UNION7")
    if row["year"] in (2022, 2025):
        need(Decimal(row["paid_net_return"]) < 0, "UNFAVORABLE_OUTCOME_RETAINED")
    summary.append({k: row[k] for k in ("cell_id", "calendar_days", "paid_net_return", "forecast_vol_breach_minutes")})
need(sum(r["completed_minutes"] for r in rows) == 7495200, "TOTAL_MINUTES")
supplement = data[saved + "SOURCE_QUALITY_SAVED_SUPPLEMENT.json"]
need([q["cell_id"] for q in supplement["rows"]] == cells[:6], "SUPPLEMENT_ONLY2021_2022")
for q in supplement["rows"]:
    if q["year"] == 2021:
        need(q["period_days"] == 274 and q["period_return_annualized"] is False, "2021_UNANNUALIZED")
    else:
        need(q["UNKNOWN_original_age_carries"] == 27 and q["genuine_recovery_source_witnesses"] == 8 and len(q["actual_saved_position_interval_impacts"]) == 7, "2022_QUALITY_WITNESSES")
aggregate = data[saved + "FINAL_INDEPENDENT_SAVED_AUDIT.json"]
exit_receipt = data["receipts/ROOT_OBSERVED_EXIT_CONFIRMED.json"]
need(aggregate["root_observed_exit_code"] == exit_receipt["observed_exit_code"] == 0 and aggregate["root_session_id"] == exit_receipt["session_id"] == 16932, "ROOT_EXIT0_SESSION16932")
need(aggregate["actual2024_all3_cases_hold_nonzero_positions_in_all10_UNKNOWN_asset_minutes"] is True, "2024_AGGREGATE")
need(aggregate["zero_interval_trades_or_funding_does_not_certify_zero_valuation_impact"] is True, "VALUATION_QUALIFICATION")
need(aggregate["required_and_completed_minutes"] == 7495200 and aggregate["completed_cases"] == 15, "AGGREGATE_CALENDARS")
delta = data["results/ORIGINAL37_COMPLETION_DELTA.json"]
need(delta["new_original_completed_signal_cells"] == 105 and delta["extra_pure_CS_cells_outside_original37"] == 15 and delta["total_completed_annual_common_D_cells"] == 120, "105_PLUS15_EQUALS120")
need(delta["remaining_disposition_dependent_nominal_slots"] == 450 and delta["nominal_slots_are_not_all_runnable_jobs"] is True and delta["existing_posthoc_STATIC50_H090_duplicate_groups_preserved"] is True and delta["exact_original_execution_replication_not_claimed"] is True, "SLOT_AND_DUPLICATE_QUALIFICATIONS")
omitted = data["OMITTED_EVIDENCE_PINS.json"]
binding = data[saved + "CONTROLLER_AND_FINAL_ARTIFACT_BINDING.json"]
omitted_expected = {}
for cell, record in binding["checked_case_artifacts"].items():
    for filename, ref in record["files"].items():
        if "cases/" + cell + "/" + filename not in files:
            omitted_expected[ref["path"]] = {k: ref[k] for k in ("SHA256", "bytes")}
controller = binding["controller_terminal"]
omitted_expected[controller["path"]] = {k: controller[k] for k in ("SHA256", "bytes")}
need(omitted_expected == {n: e["original_pin"] for n, e in omitted["files"].items()}, "EXACT_OMITTED_PINS_211")
need(omitted["hashes_restore_omitted_bytes"] is False and all(e["body_in_packet"] is False and e["omitted_body_rehashed_by_packet_builder"] is False for e in omitted["files"].values()), "OMITTED_NOT_RECOVERED")
for original, dependency in data["DEPENDENCY_CLASSIFICATION.json"]["dependencies"].items():
    included = original in by_original
    need(dependency["body_in_packet"] is included and dependency["hash_restores_bytes"] is False, "DEPENDENCY_CLASSIFICATION")
    if included:
        need(pin(files[by_original[original]]) == dependency["original_pin"], "INCLUDED_DEPENDENCY_PIN")
need(data["DEPENDENCY_CLASSIFICATION.json"]["external_dependencies_executed"] is False, "NO_EXTERNAL_DEPENDENCY_EXECUTION")
for name in files:
    need(Path(name).suffix in (".json", ".csv", ".md", ".py", ".log"), "NO_BULK_OR_BINARY")
    need(Path(name).name not in ("ADMISSION_GO.json", "LAUNCH_CLAIM.json", "SOURCE_STAGE_AUTHORIZATION.json", "WORKER_AUTHORITY_VERIFIED.json", "RAW_EVENTS.json", "SOURCE_ROWS.json", "TARGET_PROOFS.json", "NATIVE_RESULT.json", "ACCOUNT_FINANCIAL_AUDIT.json"), "NO_AUTHORITY_OR_RAW_BODY")
scope = data["SCOPE_AND_LIMITS.json"]
for key in ("publication_performed", "source_or_financial_execution_authorized", "financial_history_self_contained", "saved_event_reconstruction_self_contained", "OOS_or_live_certification", "hashes_restore_omitted_bytes", "annual_wallets_compounded", "partial2021_return_annualized", "nominal_tiers_are_exact_realized_risk_matching", "zero_interval_trades_or_funding_certify_zero_valuation_impact"):
    need(scope[key] is False, "REQUIRED_LIMIT:" + key)
need(len(data["DIAGNOSTIC_HISTORY.json"]["items"]) == 5, "FIVE_DIAGNOSTIC_STAGES")
predecessor_diagnostic = data["PREDECESSOR_PACKET_DIAGNOSTIC.json"]
need(pin(predecessor.read_bytes())["SHA256"] == predecessor_diagnostic["predecessor_SHA256"], "FAILED_V1_RETAINED_EXACT")
with zipfile.ZipFile(predecessor) as handle:
    old_names = handle.namelist()
    old_root = old_names[0].split("/")[0]
    for name in provenance:
        need(handle.read(old_root + "/" + name) == files[name], "V2_CHANGED_ORIGINAL_EVIDENCE:" + name)
result = {
    "status": "PASS_INDEPENDENT_COMPACT_SAVED_CONTENT_AND_PROVENANCE",
    "CPU_affinity": sorted(os.sched_getaffinity(0)), "numerical_pools": 1,
    "strict_JSON_documents": len(data), "all_JSON_CSV_cell_comparisons": csv_cells,
    "selected_included_risk_review_resource_comparisons": comparisons,
    "exact_original_byte_provenance_entries": len(provenance),
    "same_original_evidence_bytes_in_failed_v1_and_v2": len(provenance),
    "exact_omitted_evidence_pin_entries": len(omitted_expected),
    "dependency_entries": len(data["DEPENDENCY_CLASSIFICATION.json"]["dependencies"]),
    "case_count": 15, "completed_minutes": 7495200,
    "all_unfavorable_2022_and_2025_tiers_retained": True,
    "source_quality_2021_2022_supplement_and_2024_percell_aggregate_consistent": True,
    "historical_code_imported": False, "arrays_read": False,
    "new_financial_reconstruction": False, "omitted_bodies_read": False,
    "public_source_network_verification": False, "publication": False,
    "saved_outcome_summary": summary,
}
with output.open("x") as handle:
    json.dump(result, handle, sort_keys=True, indent=2)
    handle.write("\n")
print(json.dumps({k: v for k, v in result.items() if k != "saved_outcome_summary"}, sort_keys=True))
