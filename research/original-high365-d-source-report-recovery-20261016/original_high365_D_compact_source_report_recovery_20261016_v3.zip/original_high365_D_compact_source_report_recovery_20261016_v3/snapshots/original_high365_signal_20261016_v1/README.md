# Next original unrun recipe: HIGH365

Decision: prepare `STATIC50_HIGH365_REFERENCE_HOLD` next. This is the next
distinct, fixed original CORE5 signal whose exact source is present and whose
additional input is already represented in reviewed local source-prefix
metadata. Selection used readiness and dependency novelty, never saved returns.
There is no original grid or mean-reversion recipe in the frozen37 catalogue.
Inventing a Bybit-style grid would be a new experiment rather than completing
an original subversion.

## What is implemented

`high365_signal.py` AST-isolates the exact original functions. The unchanged
expert is current completed close / maximum of365 contiguous completed closes,
weekly top2/bottom2 with the original2024Jan1 anchor, stable ties, at least4
eligible assets and full-tie cash. Missing historical assets are excluded and
cannot re-enter until the next eligible weekly ranking. Daily original30-return
risk sizing is retained.

The original HOLD producer and its exact pandas rolling200 finite-membership
feature are retained. HOLD is downmatched to the HIGH365 expert by the exact
original `same_match_and_mix`; the signed half-sum is then retargeted with the
exact original `risk_budget.scale`. Only after that complete intrinsic recipe
are LOW(.30gross/.05vol), MID(.60/.10), HIGH(.90/.15) downward-only ceilings
applied. Cash and intrinsic caps stay intact. HIGH cannot re-expand an intrinsic
10% recipe.

No research runner is imported. No actual source array, provider, account,
financial process, holdout, network, download, Library or publication is used.
The source PINMAP is independently hard-bound in the adapter and each original
code file is checked by byte length, SHA256 and Git blob SHA1. Input arrays must
have exact native int64/float64 dtype, ordered CORE5, completed-close availability
and complete UTC daily clocks. Outputs are backed by immutable bytes.

The sole calendar adaptation accepts complete274/365/366-day decision windows.
A new fail-closed source-clock admission requires coverage through the earliest
owning weekly rank's365th close; it does not replace the original per-asset365
eligibility with a fabricated full-five mask. Current original HOLD still
requires full-five200-close readiness. Actual older unavailable asset values
must remain unavailable.

The fixed15-cell description is in `high365_config.py` and
`FROZEN_FIFTEEN_CELL_MANIFEST.json`. It grants no source, financial or publication
authority. Intended later execution is an explicitly named common-D adaptation
(shared10000, CORE5 perpetual, isolated1x, BASE27, Guard50 EXIT_ONLY and unchanged
current quantity/capital/partial/terminal60 rules). The original fine/terminal5
legacy engine is preserved as provenance and is not relabelled as current D.

## Exact original pins

- Expert: commit `1bbc51212c9cf7b7569c1a252efd0e923c2e70c5`,
  `research/high-reference-expert-20261012/expert.py`,
  SHA256 `0b913cc772d059175cc0c9e1e19af47c27d351bd032c1bae6f1ba885d08a76cd`
- Risk retarget: commit `2c551f8606ac0b9328c52115c761836099517439`,
  `research/portfolio-risk-budget-20261012/risk_budget.py`,
  SHA256 `69de58ac83536dfbf1ec3715aadfa65da741c970c4cb5b417bb4c1e8062b19a6`
- Complete transitive source-function/feature closure: `SOURCE_PINS.json`.
  Original definitions, masks and source identities for every catalogue entry
  remain in `CURRENT37_ACCOUNT_SOURCE_STATUS.json`.

## Current37 coverage

Six original signal definitions have completed15-cell common-D adaptations each:
STATIC50, H090, VOL_MANAGED_HOLD, STATIC50_OLD_NO_REEXPANSION,
HOLD_CORE5_VOL_MATCHED_NOREEXP and STATIC50_HALF_SMA200. That is90 catalogue
adaptation cells. The separate15 pure original CS cells are outside original37,
so total annual saved common-D coverage remains105.

The remaining465 nominal catalogue slots are not465 runnable jobs:

- 1 next HIGH365 recipe, generated-only adapter prepared:15slots
- 1 matched-HOLD-retarget recipe requiring exact source/target/execution dedup:15
- 2 paired FOLLOW/control recipes requiring genuine high/low adaptation:30
- 2 paired lag24 recipes requiring immutable funding-rank completeness:30
- 10 defining execution-policy variants requiring separate original policy scope:150
- 1 fixed-dollar BTC-replacement policy without a source-authorized tier conversion:15
- 14 Spot/BTC-ETH/TEN records outside this CORE5-perpetual cohort:210

No alias is inferred from mathematical direction, tolerance, matching results or
similar names. The15 existing STATIC50/H090 post-hoc realized duplicate groups
are retained, and these90 cells are not90 independent alpha confirmations.
No new distinct-realized-path total is inferred. The overlay preserves exact
saved cell IDs, source/code identities and independent review/account receipts.

## Source readiness and next minimal stage

Existing independent half-SMA source preparation metadata proves an original
close prefix beginning2020-01-02 for all five periods. Saved prefix lengths are
730/1095/1460/1826/2191rows for2021–25. This covers the clock span of the earliest
owning weekly HIGH365 rank. Actual per-asset365 eligibility has not been read or
inferred for this recipe. The old source-only permission is not reusable.

`HIGH365_NEXT_MINIMAL_ADAPTER_PLAN.json` pins these existing source artifacts and
describes the small next code surface: a separate high365 source/admission
namespace, exact canonical-close/prefix validation, target/mask/covariance dedup
and new native binding. Retain2022's27 causal carried marks/eight genuine
recoveries and literal2h/4h/8h funding,2024's ten causal UNKNOWN cells,2021's real
endpoint witness and2025's genuine empty quality. New HIGH365 position/funding
impacts must be measured from its own saved execution, not inherited.

Required next gates are independent generated-code review, fresh recipe-bound
source-only code review and root GO, actual target/mask/source/dedup review, then
independent native admission and a fresh exact root financial GO. No current
HIGH365 financial cell is runnable or counted complete.

## Generated verification

Run from this folder:

`OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 taskset -c7 python -m unittest -v test_high365_signal`

The author ran13 tests successfully on CPU7 with numerical pools1. These prove
literal-original byte equivalence on all five generated calendars, full signed
intrinsic/tier ordering, weekly ownership, per-asset365 unavailability,
full-tie/min4 cash, prefix causality, unsupported source/type/order rejection,
pin-tamper rejection, immutable output and code-only file reads during builds.
The fixtures are invented and contain no empirical prices or financial results.
This is an author test pass, not independent approval or source/finance admission.

`build_decision_overlay.py` is a standard-library metadata-only assembler. It
validates37definitions,90completed catalogue adaptation cells and465pending
slots without importing project modules or decoding source arrays. Its inputs
are pinned in `DECISION_METADATA_INPUT_PINS.json`.
