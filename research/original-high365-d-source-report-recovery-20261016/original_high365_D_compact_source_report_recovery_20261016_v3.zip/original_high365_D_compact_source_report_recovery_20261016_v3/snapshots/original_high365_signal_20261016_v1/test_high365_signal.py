"""Generated fixtures only: no empirical inputs, providers or financial seams."""
import ast
from datetime import datetime,timezone
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import shutil
import sys
import tempfile
import unittest
import numpy as np
import pandas as pd
import high365_signal as h


def utc(value):
    return int(datetime.fromisoformat(value).replace(tzinfo=timezone.utc).timestamp()*1_000_000)


def fixture(start='2020-01-02',end='2026-01-01'):
    t=np.arange(utc(start),utc(end),h.DAY,dtype=np.int64)
    rng=np.random.default_rng(652365)
    r=rng.normal(.0004,.018,(len(t),5))
    p=100*np.exp(np.cumsum(r,axis=0))
    return t,p


def literal_originals():
    """Independent exact function extraction, without calling adapter loader."""
    ns=dict(np=np,DAY=h.DAY,DAY_US=h.DAY,WEEK=h.WEEK,WEEK_US=h.WEEK,
        ANCHOR=h.ANCHOR,ANCHOR_US=h.ANCHOR,SYMBOLS=h.SYMBOLS,
        EXPERTS=('SMA200_SIGNED','CSMOM21_CORE5','HOLD','CASH'),
        ANNUAL_BUDGET=.10,ASSET_CAP=.30,GROSS_CAP=.60)
    picks=[('public_sma_perpetual.py',('require','symbol_order','signed_risk_weights')),
        ('portfolio.py',('market_neutral',)),
        ('public_cross_section_momentum.py',('public_targets',)),
        ('joint_expert_information.py',('signed_intents',)),
        ('risk_budget.py',('scale',)),('expert.py',('targets','same_match_and_mix'))]
    for filename,names in picks:
        tree=ast.parse((h.HERE/'pinned'/filename).read_bytes())
        body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names]
        exec(compile(ast.Module(body=body,type_ignores=[]),filename,'exec'),ns)
    return ns


class GeneratedOnly(unittest.TestCase):
    def test_exact_source_pins_and_function_ASTs(self):
        pins=h.verify_sources();o=h.originals()
        self.assertEqual(pins['files']['pinned/expert.py']['SHA256'],
            '0b913cc772d059175cc0c9e1e19af47c27d351bd032c1bae6f1ba885d08a76cd')
        for name in ('targets','same_match_and_mix'):
            tree=ast.parse((h.HERE/'pinned/expert.py').read_bytes())
            node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name)
            self.assertEqual(o.AST_SHA256['expert.py::'+name],
                hashlib.sha256(ast.dump(node,include_attributes=False).encode()).hexdigest())

    def test_all_five_calendars_literal_original_byte_equivalence(self):
        t,p=fixture();original=literal_originals()
        for year,start,days in [(2021,'2021-04-02',274),(2022,'2022-01-01',365),
                (2023,'2023-01-01',365),(2024,'2024-01-01',366),(2025,'2025-01-01',365)]:
            with self.subTest(year=year):
                d=np.arange(utc(start),utc(str(year+1)+'-01-01'),h.DAY,dtype=np.int64)
                self.assertEqual(len(d),days)
                arrays,proof=h.build_target_grid(p,t,t,d)
                end=int(np.searchsorted(t,d[-1]))+1;ct=t[:end];cp=p[:end]
                ids=np.searchsorted(ct,d)
                mean=pd.DataFrame(cp).rolling(200,min_periods=200).mean().to_numpy()
                signal=np.sign(cp-mean)
                hold=original['signed_intents'](cp,signal,ct,h.SYMBOLS)[ids,2,:]
                expert,expected_proof=original['targets'](ct,cp,d)
                covariance=np.stack([np.cov(np.diff(cp[k-30:k+1],axis=0)/cp[k-30:k],
                    rowvar=False,ddof=1)*365 for k in ids])
                intrinsic,mixproof=original['same_match_and_mix'](expert,hold,covariance,original['scale'])
                for key,expected in [('HIGH365_ORIGINAL',expert),('HOLD_ORIGINAL',hold),
                        ('annual_covariance',covariance),
                        ('intrinsic_STATIC50_HIGH365_REFERENCE_HOLD',intrinsic)]:
                    self.assertEqual(arrays[key].tobytes(),expected.tobytes(),(year,key))
                for i in range(len(d)):
                    self.assertEqual(proof[i]['HIGH365_original'],expected_proof[i])
                    self.assertEqual(proof[i]['original_match_and_intrinsic_retarget'],mixproof[i])
                for tier,gross,vol,asset in h.TIERS:
                    w=arrays[h.RECIPE+'_'+tier]
                    expected=[]
                    for row,c in zip(intrinsic,covariance):
                        sigma=float(np.sqrt(max(0.,float(row@c@row))))
                        g=float(np.abs(row).sum());m=float(np.abs(row).max())
                        f=min(1.,vol/sigma if sigma>0 else 1.,gross/g if g>0 else 1.,asset/m if m>0 else 1.)
                        expected.append(row.copy() if f==1 else row*f)
                    self.assertEqual(w.tobytes(),np.stack(expected).tobytes())
                    self.assertTrue(np.all(np.abs(w)<=np.abs(intrinsic)+1e-15))
                    self.assertFalse(w.flags.writeable)
                self.assertTrue(all(not r['source_admitted'] and not r['financial_authorized'] for r in proof))

    def test_prefix_causality_and_future_nan_suffix(self):
        t,p=fixture(end='2024-01-01');d=np.arange(utc('2023-01-01'),utc('2023-03-01'),h.DAY,dtype=np.int64)
        full,_=h.build_target_grid(p,t,t,d)
        end=int(np.searchsorted(t,d[-1]))+1
        prefix,_=h.build_target_grid(p[:end],t[:end],t[:end],d)
        future=p.copy();future[end:]=np.nan
        suffix,_=h.build_target_grid(future,t,t,d)
        for k in full:
            self.assertEqual(full[k].tobytes(),prefix[k].tobytes())
            self.assertEqual(full[k].tobytes(),suffix[k].tobytes())

    def test_per_asset_365_mask_preserved_without_calendar_shortening(self):
        t,p=fixture(end='2021-05-01');d=np.arange(utc('2021-04-02'),utc('2021-04-25'),h.DAY,dtype=np.int64)
        # Hypothetical unavailable older SOL history, more than200 days old.
        p[t<utc('2020-04-11'),2]=np.nan
        a,proof=h.build_target_grid(p,t,t,d)
        self.assertEqual(len(proof),len(d))
        before=d<utc('2021-04-10')
        self.assertTrue(np.all(~a['HIGH365_CURRENT_ELIGIBLE'][before,2]))
        self.assertTrue(np.all(a['HIGH365_ORIGINAL'][before,2]==0))
        self.assertTrue(a['HIGH365_CURRENT_ELIGIBLE'][-1,2])
        self.assertTrue(np.isfinite(a['HOLD_ORIGINAL']).all())
        self.assertFalse(any('new_source_authority' in r for r in proof))

    def test_weekly_rank_not_first_output_rerank(self):
        t,p=fixture(end='2023-02-01');o=h.originals()
        full_d=np.arange(utc('2023-01-02'),utc('2023-01-16'),h.DAY,dtype=np.int64)
        sub_d=full_d[2:]
        whole,_=o.targets(t,p,full_d);sub,proof=o.targets(t,p,sub_d)
        self.assertEqual(whole[2:].tobytes(),sub.tobytes())
        self.assertFalse(proof[0]['weekly_rank_event'])

    def test_original_sticky_missing_clears_until_next_rank(self):
        t,p=fixture(end='2023-02-01');o=h.originals()
        d=np.arange(utc('2023-01-02'),utc('2023-01-16'),h.DAY,dtype=np.int64)
        first,_=o.targets(t,p,d[:1]);held=int(np.flatnonzero(first[0])[0])
        # A source in the365 window expires mid-week. Recovery is not reranking.
        missing_at=utc('2023-01-05')-364*h.DAY
        p[t==missing_at,held]=np.nan
        out,proof=o.targets(t,p,d)
        recovered=np.array([r['current_eligible'][held] for r in proof])
        self.assertTrue(recovered[4])  # Jan6, expired unavailable close
        self.assertTrue(np.all(out[:7,held]==0))  # Jan2-8, next rank Jan9

    def test_close_reference_includes_current_and_stable_ties(self):
        t,p=fixture(end='2023-01-10');d=np.array([utc('2023-01-02')],np.int64);k=np.searchsorted(t,d[0])
        p[k-364:k+1]=100.;p[k]=[80.,80.,90.,90.,100.]
        # Add nondegenerate past returns outside the exact reference-score ties.
        p[k-30:k]=100.-np.arange(30)[:,None]*np.array([.02,.03,.04,.05,.06])[None,:]
        out,proof=h.originals().targets(t,p,d)
        scores=np.asarray(proof[0]['reference_score'])
        self.assertEqual(scores[-1],1.)
        self.assertTrue(np.all(out[0,:2]<0));self.assertTrue(np.all(out[0,3:]>0));self.assertEqual(out[0,2],0.)

    def test_full_tie_and_zero_risk_cash(self):
        t,p=fixture(end='2023-01-03');p[:]=100.
        d=np.array([utc('2023-01-02')],np.int64)
        a,_=h.build_target_grid(p,t,t,d)
        for key in ['HIGH365_ORIGINAL','intrinsic_STATIC50_HIGH365_REFERENCE_HOLD']+[h.RECIPE+'_'+v[0] for v in h.TIERS]:
            self.assertTrue(np.all(a[key]==0))

    def test_minimum_four_original_rank_admission(self):
        t,p=fixture(end='2023-01-03');d=np.array([utc('2023-01-02')],np.int64);k=np.searchsorted(t,d[0])
        p[k-300,:2]=np.nan
        a,_=h.build_target_grid(p,t,t,d)
        self.assertTrue(np.all(a['HIGH365_ORIGINAL']==0))
        self.assertTrue(np.all(a['intrinsic_STATIC50_HIGH365_REFERENCE_HOLD']==0))

    def test_singular_covariance_and_intrinsic_cash_lower_only(self):
        c=np.zeros((5,5),np.float64);w=np.array([.1,-.1,.1,-.1,0.],np.float64)
        for tier,*_ in h.TIERS:
            out,proof=h.lower_only(w,c,tier)
            self.assertLessEqual(proof['factor'],1.)
            self.assertTrue(np.all(np.abs(out)<=np.abs(w)))
            z,_=h.lower_only(np.zeros(5),c,tier);self.assertTrue(np.all(z==0))

    def test_strict_clock_dtype_universe_and_source_span_rejections(self):
        t,p=fixture(end='2023-01-03');d=np.array([utc('2023-01-02')],np.int64)
        cases=[(p,t.astype(float),t,d,{}),(p,t,t+1,d,{}),
            (p,t,t,d,{'symbols':h.SYMBOLS[::-1]}),(p.astype('float32'),t,t,d,{})]
        for args in cases:
            with self.assertRaises(ValueError):h.build_target_grid(*args[:4],**args[4])
        first=int(np.searchsorted(t,d[0]))-300
        with self.assertRaisesRegex(ValueError,'UNSHORTENED_365'):
            h.build_target_grid(p[first:],t[first:],t[first:],d)
        bad=p.copy();bad[-2,0]=np.nan
        with self.assertRaisesRegex(ValueError,'200_CLOSE_HOLD'):
            h.build_target_grid(bad,t,t,d)

    def test_source_pin_mutation_rejected_in_isolated_copy(self):
        with tempfile.TemporaryDirectory(prefix='high365_generated_') as temp:
            dst=Path(temp)/'code';shutil.copytree(h.HERE,dst,ignore=shutil.ignore_patterns('__pycache__'))
            spec=importlib.util.spec_from_file_location('_generated_high365_copy',dst/'high365_signal.py')
            module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
            (dst/'pinned/expert.py').write_bytes((dst/'pinned/expert.py').read_bytes()+b'\n')
            with self.assertRaisesRegex(ValueError,'ORIGINAL_CODE_BYTES_CHANGED'):module.verify_sources()

    def test_no_financial_or_market_seam_during_generated_build(self):
        t,p=fixture(end='2023-01-03');d=np.array([utc('2023-01-02')],np.int64)
        observed=[];active=[True]
        def hook(event,args):
            if active[0] and event=='open' and isinstance(args[0],(str,bytes)):
                observed.append(str(args[0]))
            if active[0] and event in ('socket.connect','subprocess.Popen','os.system'):
                raise AssertionError('FORBIDDEN_EXTERNAL_SEAM:'+event)
        sys.addaudithook(hook)
        try:h.build_target_grid(p,t,t,d)
        finally:active[0]=False
        allowed={str((h.HERE/name).absolute()) for name in h.verify_sources()['files']}
        allowed.add(str(h.HERE/'SOURCE_PINS.json'))
        self.assertTrue(observed)
        self.assertLessEqual(set(observed),allowed)


if __name__=='__main__':
    unittest.main(verbosity=2)
