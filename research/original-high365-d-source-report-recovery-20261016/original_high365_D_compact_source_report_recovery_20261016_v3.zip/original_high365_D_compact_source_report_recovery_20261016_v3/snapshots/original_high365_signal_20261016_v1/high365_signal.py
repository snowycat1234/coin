"""Exact original HIGH365 expert/HOLD mixture, then downward-only tier ceilings.

Generated/caller-supplied arrays only. This module has no market-file, provider,
account, financial launcher, network, permission, claim or publication entry.
The original code is AST-isolated; its research runner is never imported.
"""
from __future__ import annotations
import ast
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace
import numpy as np
import pandas as pd

HERE = Path(__file__).absolute().parent
DAY = 86_400_000_000
WEEK = 7*DAY
ANCHOR = 1_704_067_200_000_000
SYMBOLS = ('BTCUSDT','ETHUSDT','SOLUSDT','XRPUSDT','DOGEUSDT')
RECIPE = 'STATIC50_HIGH365_REFERENCE_HOLD'
VERSION = 'ORIGINAL_HIGH365_INTRINSIC_LOWER_ONLY_GENERATED_V1'
SOURCE_PINS_SHA256 = '4968b9ae11ec40f695ffa5994bdc262a9b90a1401d7cf1458b8e744691a771e9'
TIERS = (('LOW',.30,.05,.30),('MID',.60,.10,.30),('HIGH',.90,.15,.30))


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def ordinary(path):
    path=Path(path).absolute()
    if path.is_symlink() or any(p.is_symlink() for p in path.parents) or not path.is_file():
        raise ValueError('ORDINARY_PINNED_CODE_REQUIRED')
    return path.read_bytes()


def verify_sources():
    raw=ordinary(HERE/'SOURCE_PINS.json')
    if sha(raw)!=SOURCE_PINS_SHA256:
        raise ValueError('EXACT_FROZEN_CODE_PINMAP_REQUIRED')
    pins=json.loads(raw)
    for name,pin in pins['files'].items():
        rel=Path(name)
        if rel.is_absolute() or '..' in rel.parts or rel.parts[0]!='pinned':
            raise ValueError('PINNED_CODE_NAMESPACE_REQUIRED')
        body=ordinary(HERE/rel)
        blob=hashlib.sha1(b'blob '+str(len(body)).encode()+b'\0'+body).hexdigest()
        if len(body)!=pin['bytes'] or sha(body)!=pin['SHA256'] or blob!=pin['GitBlobSHA1']:
            raise ValueError('EXACT_ORIGINAL_CODE_BYTES_CHANGED:'+name)
    return pins


def originals():
    """Load exact original function ASTs and the exact HOLD membership feature."""
    verify_sources()
    ns=dict(np=np,pd=pd,DAY=DAY,DAY_US=DAY,WEEK=WEEK,WEEK_US=WEEK,
        ANCHOR=ANCHOR,ANCHOR_US=ANCHOR,SYMBOLS=SYMBOLS,
        EXPERTS=('SMA200_SIGNED','CSMOM21_CORE5','HOLD','CASH'),
        ANNUAL_BUDGET=.10,ASSET_CAP=.30,GROSS_CAP=.60)
    selections=(('public_sma_perpetual.py',('require','symbol_order','signed_risk_weights')),
        ('portfolio.py',('market_neutral',)),
        ('public_cross_section_momentum.py',('public_targets',)),
        ('joint_expert_information.py',('signed_intents',)),
        ('risk_budget.py',('scale',)),
        ('expert.py',('targets','same_match_and_mix')))
    ast_pins={}
    for filename,names in selections:
        path=HERE/'pinned'/filename
        tree=ast.parse(ordinary(path),filename=str(path))
        nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names]
        if tuple(n.name for n in nodes)!=names:
            raise ValueError('EXACT_ORIGINAL_FUNCTION_INVENTORY_REQUIRED')
        for node in nodes:
            ast_pins[filename+'::'+node.name]=sha(ast.dump(node,include_attributes=False).encode())
        exec(compile(ast.Module(body=nodes,type_ignores=[]),str(path),'exec'),ns)
    path=HERE/'pinned/hold_feature_original.py'
    tree=ast.parse(ordinary(path),filename=str(path))
    weights=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='weights')
    nodes=[n for n in weights.body if isinstance(n,ast.Assign) and any(
        isinstance(t,ast.Name) and t.id in ('mean','signal') for t in n.targets)]
    if len(nodes)!=2:
        raise ValueError('EXACT_ORIGINAL_HOLD_FINITE_MEMBERSHIP_FEATURE_REQUIRED')
    feature_code=compile(ast.Module(body=nodes,type_ignores=[]),str(path),'exec')
    ast_pins['hold_feature_original.py::mean_and_signal']=sha(
        ast.dump(ast.Module(body=nodes,type_ignores=[]),include_attributes=False).encode())
    return SimpleNamespace(**{k:ns[k] for k in ('targets','same_match_and_mix','scale',
        'signed_intents','market_neutral','signed_risk_weights')},feature_code=feature_code,
        AST_SHA256=ast_pins)


def supported(value,dtype=None):
    a=np.asarray(value)
    if (a.dtype.fields is not None or a.dtype.subdtype is not None or a.dtype.hasobject
            or (a.dtype.kind,a.dtype.itemsize) not in (('b',1),('i',8),('f',8))):
        raise ValueError('PLAIN_BOOL_INT64_FLOAT64_ONLY')
    if dtype is not None and a.dtype!=np.dtype(dtype):
        raise ValueError('EXACT_NATIVE_ARRAY_DTYPE_REQUIRED')
    return a


def immutable(value):
    a=supported(value)
    return np.frombuffer(a.tobytes(order='C'),dtype=a.dtype).reshape(a.shape)


def array_byte_identity(value):
    a=supported(value)
    desc=dict(dtype=a.dtype.str,shape=list(a.shape),order='C')
    header=json.dumps(desc,sort_keys=True,separators=(',',':')).encode()
    return dict(**desc,raw_bytes_SHA256=sha(a.tobytes(order='C')),
        descriptor_and_bytes_SHA256=sha(header+b'\0'+a.tobytes(order='C')))


def clock(value):
    a=supported(value,'int64')
    if a.ndim!=1 or not len(a) or np.any(a<0) or np.any(a%DAY) or np.any(np.diff(a)!=DAY):
        raise ValueError('COMPLETE_UTC_DAILY_INT64_CLOCK_REQUIRED')
    return a


def covariance_checked(value):
    c=supported(value,'float64')
    if c.shape!=(5,5) or not np.isfinite(c).all() or not np.allclose(c,c.T,rtol=0,atol=1e-14):
        raise ValueError('FINITE_SYMMETRIC_ORDERED_CORE5_COVARIANCE_REQUIRED')
    if np.linalg.eigvalsh(c).min() < -1e-12:
        raise ValueError('NON_PSD_COVARIANCE')
    return c


def lower_only(weight,covariance,tier_name):
    try:
        _,gross_cap,vol_cap,asset_cap=next(t for t in TIERS if t[0]==tier_name)
    except StopIteration:
        raise ValueError('EXACT_FIXED_TIER_REQUIRED') from None
    w=supported(weight,'float64');c=covariance_checked(covariance)
    if (w.shape!=(5,) or not np.isfinite(w).all() or np.abs(w).max()>.30+1e-12
            or np.abs(w).sum()>.60+1e-12):
        raise ValueError('FINITE_ORIGINAL_INTRINSIC_ENVELOPE_REQUIRED')
    gross=float(np.abs(w).sum());largest=float(np.abs(w).max());variance=float(w@c@w)
    if variance < -1e-15 or not np.isfinite(variance):
        raise ValueError('NONNEGATIVE_COVARIANCE_RISK_REQUIRED')
    sigma=float(np.sqrt(max(0.,variance)))
    factor=min(1.,vol_cap/sigma if sigma>0 else 1.,gross_cap/gross if gross>0 else 1.,
        asset_cap/largest if largest>0 else 1.)
    out=w.copy() if factor==1. else w*factor
    post=float(np.sqrt(max(0.,float(out@c@out))))
    if (not 0<=factor<=1. or np.any(np.abs(out)>np.abs(w)+1e-15)
            or np.abs(out).sum()>gross_cap+1e-12 or np.abs(out).max()>asset_cap+1e-12
            or post>vol_cap+1e-12):
        raise ValueError('LOWER_ONLY_POSTCONDITION_FAILED')
    return immutable(out),dict(factor=factor,raw_sigma=sigma,post_sigma=post,reexpanded=False)


def build_target_grid(close,close_us,available_us,decisions,*,symbols=SYMBOLS):
    """Preserve the original expert eligibility, weekly state, HOLD and mixture.

    Any supplied complete daily decision calendar is admitted, including the
    fixed 274/365/366-day DEV periods. The supplied source clock must begin on
    or before the earliest owning weekly rank's 365th close. Older per-asset
    missing history remains missing: no full-five 365 eligibility is fabricated.
    Current original HOLD requires all five finite positive 200-close histories.
    No source authority follows from these caller arrays or generated proofs.
    """
    if tuple(symbols)!=SYMBOLS:
        raise ValueError('EXACT_ORDERED_CORE5_REQUIRED')
    p=supported(close,'float64');t=clock(close_us);a=clock(available_us);d=clock(decisions)
    if p.shape!=(len(t),5) or not np.array_equal(t,a):
        raise ValueError('EXACT_COMPLETED_CLOSE_AVAILABILITY_NAMESPACE_REQUIRED')
    ids=np.searchsorted(t,d)
    if np.any(ids>=len(t)) or not np.array_equal(t[ids],d) or np.any(ids<199):
        raise ValueError('ORIGINAL_200_COMPLETED_CLOSE_ADMISSION_REQUIRED')
    first_rank=ANCHOR+(int(d[0])-ANCHOR)//WEEK*WEEK
    if int(t[0])>first_rank-364*DAY:
        raise ValueError('UNSHORTENED_365_CLOSE_OWNING_RANK_SOURCE_CLOCK_REQUIRED')
    end=int(ids[-1])+1;p=p[:end].copy();t=t[:end].copy()
    ready=np.zeros(p.shape,dtype=bool)
    for k in range(199,len(t)):
        ready[k]=np.all(np.isfinite(p[k-199:k+1]) & (p[k-199:k+1]>0),axis=0)
    if not ready[ids].all():
        raise ValueError('FULL_FIVE_ORIGINAL_200_CLOSE_HOLD_READINESS_REQUIRED')
    o=originals()
    feature_ns=dict(np=np,pd=pd,p=p)
    exec(o.feature_code,feature_ns)
    feature=feature_ns['signal']
    experts=o.signed_intents(p,feature,t,SYMBOLS)
    hold=experts[ids,2,:]
    expert,expert_proofs=o.targets(t,p,d)
    cov=[]
    for k in ids:
        past=p[k-30:k+1]
        returns=np.diff(past,axis=0)/past[:-1]
        cov.append(covariance_checked(np.cov(returns,rowvar=False,ddof=1)*365))
    covariance=np.stack(cov)
    intrinsic,mix_proofs=o.same_match_and_mix(expert,hold,covariance,o.scale)
    arrays=dict(decision_us=d,annual_covariance=covariance,HIGH365_ORIGINAL=expert,
        HOLD_ORIGINAL=hold,intrinsic_STATIC50_HIGH365_REFERENCE_HOLD=intrinsic,
        HIGH365_CURRENT_ELIGIBLE=np.asarray([r['current_eligible'] for r in expert_proofs],bool))
    proofs=[]
    for i,(at,k) in enumerate(zip(d,ids)):
        tiers={}
        for tier,*_ in TIERS:
            key=RECIPE+'_'+tier
            if key not in arrays:
                arrays[key]=np.empty_like(intrinsic)
            arrays[key][i],tiers[tier]=lower_only(intrinsic[i],covariance[i],tier)
        rank=ANCHOR+(int(at)-ANCHOR)//WEEK*WEEK
        proofs.append(dict(decision_us=int(at),HIGH365_original=expert_proofs[i],
            HIGH365_owning_weekly_rank_us=rank,
            HOLD_oldest_completed_close_us=int(t[k-199]),
            risk_oldest_completed_close_us=int(t[k-30]),
            latest_completed_close_us=int(t[k]),
            HIGH365_oldest_current_reference_clock_us=int(t[k-364]),
            original_match_and_intrinsic_retarget=mix_proofs[i],tiers=tiers,
            source_admitted=False,financial_authorized=False,
            same_D_execution_unchanged_required=True))
    return {key:immutable(value) for key,value in arrays.items()},proofs
