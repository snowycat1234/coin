"""Fixed-scope metadata checks only; no source or financial admission."""
import json
from pathlib import Path
import unittest
import high365_config as c
import high365_signal as h


class FixedScope(unittest.TestCase):
    def test_exact_fifteen_cell_description(self):
        self.assertEqual(c.manifest(),json.loads((Path(__file__).parent/'FROZEN_FIFTEEN_CELL_MANIFEST.json').read_bytes()))
        cells=c.cells();self.assertEqual(len(cells),15)
        self.assertEqual(len({r['cell_id'] for r in cells}),15)
        self.assertEqual({(r['year'],r['tier']) for r in cells},
            {(y,t) for y in range(2021,2026) for t in ('LOW','MID','HIGH')})
        for r in cells:
            self.assertEqual(r['recipe'],h.RECIPE)
            self.assertEqual(r['calendar_days'],(r['end_exclusive_us']-r['start_us'])//c.DAY)
            self.assertFalse(r['current_source_admission'])
            self.assertFalse(r['current_financial_admission'])
            self.assertFalse(r['execution_reuse_authorized'])
            self.assertFalse(r['original_execution_replication'])

    def test_exact_calendar_and_tier_agreement(self):
        self.assertEqual(c.SYMBOLS,h.SYMBOLS)
        self.assertEqual(tuple((t,g,v) for t,g,v,*_ in h.TIERS),c.TIERS)
        self.assertEqual(c.period_named(2021)['days'],274)
        self.assertEqual(c.period_named(2024)['days'],366)
        for y in (2022,2023,2025):self.assertEqual(c.period_named(y)['days'],365)

    def test_no_holdout_or_other_cell_scope(self):
        for year in (2020,2026,2027,True,2023.,'2023'):
            with self.assertRaises(ValueError):c.period_named(year)
        for cell in ('2026_'+h.RECIPE+'_LOW_D_INTRINSIC_LOWER_ONLY_V1','2023_STATIC50_LOW_D',''):
            with self.assertRaises(ValueError):c.cell_named(cell)


if __name__=='__main__':unittest.main(verbosity=2)
