"""Read existing catalogue/review metadata only; never load market inputs.

No project, provider, account, NumPy, financial or network module is imported.
All output is additive inside this new decision folder.
"""
from pathlib import Path
import csv
import hashlib
import json

HERE=Path(__file__).absolute().parent
ROOT=HERE.parent


def sha(raw):return hashlib.sha256(raw).hexdigest()


def read(path):
    p=ROOT/path
    if p.is_symlink() or any(q.is_symlink() for q in p.parents):raise ValueError('ORDINARY_METADATA_ONLY')
    raw=p.read_bytes()
    pins[path]=dict(SHA256=sha(raw),bytes=len(raw))
    return json.loads(raw)


def write(name,value):
    (HERE/name).write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')


pins={}
catalog=read('overnight_legacy_variant_queue_plan_20261015/READINESS_37.json')['rows']
core=read('traditional_D_MASTER45_saved_summary_20261015/MASTER45_ROWS.json')
legacy=read('legacy_intrinsic_D_ALL30_saved_results_independent_review_20261015_v1/LEGACY30_COST_RISK_ROWS.json')
legacy_receipt=read('legacy_intrinsic_D_ALL30_saved_results_independent_review_20261015_v1/FINAL_LEGACY30_SAVED_AGGREGATE_RECEIPT.json')
half=read('original_half_sma_D_results_independent_review_20261015_v1/ALL15_SAVED_METRICS.json')['rows']
prefix_source='original_half_sma_D_source_20261015_v2/source_attempts/ACTUAL_ALL15_SOURCE_TARGET_ONLY_attempt002/PREPARATION.json'
prefix=read(prefix_source)
half_binding=read('original_half_sma_D_results_independent_review_20261015_v1/FINAL_COMPLETE_BINDING_v3.json')

completed={}
for r in core:
    assert r['return_taxonomy']=='FULL_CALENDAR_ACTUAL_PAID_MARKET_FLAT'
    assert r['initial_wallet_USDT']=='10000'
    completed.setdefault(r['strategy'],[]).append(dict(cell_id=r['cell_id'],year=r['year'],tier=r['tier'],
        review_path=r['review_source'],review_SHA256=r['review_SHA256'],
        source_identity=r['source_identity'],source_code_identity=r['source_code_identity'],
        source_code_identity_kind=r['source_code_identity_kind'],
        independent_fresh_shared_wallet_USDT='10000',financial_contract='COMMON_NATIVE_D'))
for r in legacy:
    assert r['status']=='FULL_CALENDAR_ACTUAL_PAID_MARKET_FLAT' and r['paid_market_flat']
    case=legacy_receipt['cases'][r['cell_id']]
    assert case['review']['SHA256']==r['review_SHA256']
    completed.setdefault(r['recipe'],[]).append(dict(cell_id=r['cell_id'],year=r['year'],tier=r['tier'],
        review_SHA256=r['review_SHA256'],aggregate_receipt='legacy_intrinsic_D_ALL30_saved_results_independent_review_20261015_v1/FINAL_LEGACY30_SAVED_AGGREGATE_RECEIPT.json',
        exact_review_bytes=case['review']['bytes'],
        independent_fresh_shared_wallet_USDT='10000',financial_contract='COMMON_NATIVE_D_INTRINSIC_LOWER_ONLY',
        source_execution_claim='VERSIONED_SOURCE_BOUND_ADAPTATION_NOT_LITERAL_OLD_EXECUTION'))
for r in half:
    assert r['terminal_status']=='FULL_CALENDAR_ACTUAL_PAID_MARKET_FLAT'
    path='original_half_sma_D_results_independent_review_20261015_v1/'+r['cell_id']+'.review.json'
    review=read(path)
    assert review['fresh_shared_initial_cash']=='10000' and review['paid_flat'] and review['full_calendar']
    completed.setdefault('STATIC50_HALF_SMA200',[]).append(dict(cell_id=r['cell_id'],year=r['year'],tier=r['tier'],
        review_path=path,review_SHA256=pins[path]['SHA256'],source_output=review['source_output'],
        terminal_checkpoint=review['terminal_checkpoint'],independent_fresh_shared_wallet_USDT='10000',
        financial_contract='COMMON_NATIVE_D_INTRINSIC_LOWER_ONLY',
        source_execution_claim='VERSIONED_ORIGINAL_SIGNAL_ADAPTATION_NOT_LITERAL_OLD_EXECUTION'))
assert len(core)==45 and len(legacy)==30 and len(half)==15 and len(completed)==6
for name,rows in completed.items():
    assert len(rows)==15
    assert {(r['year'],r['tier']) for r in rows}=={(y,t) for y in range(2021,2026) for t in ('LOW','MID','HIGH')}

dispositions={
    'BLOCKED_EXECUTION_POLICY_IDENTITY':'SEPARATE_ORIGINAL_EXECUTION_POLICY_COHORT_REQUIRED',
    'BLOCKED_GENUINE_TRADE_HIGH_LOW_ADAPTER':'PENDING_GENUINE_HIGH_LOW_SOURCE_ADAPTER_PAIRED',
    'BLOCKED_FIXED_DOLLAR_POLICY_SCOPE':'NO_SOURCE_AUTHORIZED_TIER_CONVERSION',
    'BLOCKED_PRE_FINANCE_EXACT_DEDUP':'PENDING_EXACT_SOURCE_TARGET_EXECUTION_DEDUP_NO_ALIAS_YET',
    'BLOCKED_EXACT_FUNDING_RANK_AUTHORITY':'PENDING_COMPLETE_FUNDING_RANK_READINESS_PAIRED',
    'BLOCKED_SEPARATE_SPOT_COHORT_AND_BODIES':'OUTSIDE_CORE5_PERPETUAL_D_COHORT',
    'BLOCKED_BTC_ETH_COHORT_AND_BODIES':'OUTSIDE_CORE5_PERPETUAL_D_COHORT',
    'BLOCKED_TEN_MEMBERSHIP_AND_BODIES':'OUTSIDE_CORE5_PERPETUAL_D_COHORT',
}
rows=[]
for old in catalog:
    recipe=old['variant_id'];record=old['original_registry_record'];cases=completed.get(recipe,[])
    if cases:status='ORIGINAL_SIGNAL_COMMON_D_ADAPTATION_COMPLETE'
    elif recipe=='STATIC50_HIGH365_REFERENCE_HOLD':status='NEXT_ORIGINAL_FIXED_RECIPE_GENERATED_ONLY_ADAPTER_READY'
    else:status=dispositions[old['readiness_class']]
    rows.append(dict(variant_id=recipe,registry_order=old['registry_order'],status=status,
        original_definition_fingerprint=record['definition_fingerprint'],
        original_product=record['original_product'],original_cohort=record['comparison_cohort'],
        exact_original_definition=record['canonical_definition'],exact_original_mask=record['input_mask'],
        exact_original_source_pins=record['source_files'],original_execution=record['original_execution'],
        completed_current_D_adaptation_cells=len(cases),completed_cells=cases,
        theoretical_catalogue_slots=15,pending_catalogue_slots=15-len(cases),
        currently_runnable_new_financial_cells=0,declared_or_inferred_financial_alias=False,
        pending_disposition=old['exact_blocker_or_disposition'] if not cases else
            'Retain exact completed account/review lineage. No rerun or unseen/OOS inference.',
        current_D_does_not_complete_distinct_original_execution_policy=True))
assert len(rows)==37 and sum(r['completed_current_D_adaptation_cells'] for r in rows)==90
counts={}
for r in rows:counts[r['status']]=counts.get(r['status'],0)+1
write('CURRENT37_ACCOUNT_SOURCE_STATUS.json',dict(schema='ORIGINAL37_CURRENT_D_SIGNAL_ADAPTATION_OVERLAY_20261016_V1',
    rows=rows,definition_status_counts=counts,catalogue_nominal_slots=555,
    current_D_completed_signal_adaptation_cells=90,pending_disposition_dependent_slots=465,
    extra_original_pure_CS_cells_outside_original37=15,total_completed_annual_common_D_cells=105,
    catalogue_is_not_555_runnable_jobs=True,untouched_OOS=False,
    exact_old_engine_completion_not_claimed=True,
    new_financial_or_source_runs=0,source_or_financial_authority_granted=False,
    posthoc_core_STATIC50_H090_realized_duplicate_groups=15,
    mathematical_direction_or_tolerance_does_not_prove_alias=True,
    no_exhaustive_current_distinct_realized_path_count_claimed=True))
with (HERE/'CURRENT37_ACCOUNT_SOURCE_STATUS.csv').open('w',newline='') as f:
    names=['registry_order','variant_id','status','original_product','original_cohort',
        'completed_current_D_adaptation_cells','pending_catalogue_slots','currently_runnable_new_financial_cells']
    writer=csv.DictWriter(f,fieldnames=names);writer.writeheader()
    writer.writerows({k:r[k] for k in names} for r in rows)

source_plan={}
for year,info in prefix['years'].items():
    meta=info['target_prefix_metadata']
    assert meta['first_source_clock_us']==1577923200000000
    assert meta['prefix_first_row_retained'] and meta['future_close_rows_interpreted']==0
    path=str(Path(prefix_source).parent/year/'SOURCE_PREFIX_INPUTS.npz')
    key=year+'/SOURCE_PREFIX_INPUTS.npz'
    source_plan[year]=dict(existing_saved_source_prefix=dict(path=path,**prefix['artifacts'][key]),
        existing_prefix_metadata=meta,
        current_recipe_source_admission=False,per_asset_365_eligibility_actual_values_not_read_or_inferred=True,
        source_preparation_required='Fresh recipe scope and source-only GO; revalidate exact prefix/canonical close bits, clock coverage and masks before building any target.',
        canonical_execution_source_identity=info['source_identity'],
        preserve_original_event_quality_carries=True)
write('HIGH365_NEXT_MINIMAL_ADAPTER_PLAN.json',dict(schema='ORIGINAL_HIGH365_NEXT_ADDITIVE_ADAPTER_PLAN_V1',
    chosen_recipe='STATIC50_HIGH365_REFERENCE_HOLD',
    selection_basis='Readiness/dependency novelty only, never performance. Original close-only new expert avoids absent high-low/funding-readiness adapters and likely HOLD direction alias.',
    no_original_grid_or_mean_reversion_recipe_in_frozen37=True,
    no_grid_search_or_new_parameter_variant=True,
    pure_adapter='high365_signal.py',generated_tests='test_high365_signal.py',
    intended_execution='Fresh named common-D adaptation only: CORE5/BASE27/shared10000/isolated1x/Guard50_EXIT_ONLY/current quantity, capital, partial and terminal60 unchanged.',
    original_legacy_execution_not_relabelled=True,
    source_plan=source_plan,
    actual_inputs_read=False,actual_targets_created=False,financial_GO_written=False,
    next_code_surface=['New high365 configuration/recipe and exact15-cell manifest',
        'New source-only admission namespace wrapping reviewed canonical capture + existing original causal prefix',
        'Bind high365_signal.build_target_grid after exact365 owning-rank clock and per-asset mask proofs',
        'New prepared-target exact dedup key binding source/target/covariance/mask/account tier/D execution',
        'New version-bound native admission namespace reusing unchanged D seams; never reuse old GO'],
    gates=['Independent pure-code/generated review','Fresh versioned source-only code review and root source-only GO',
        'Exact actual target/mask/covariance/source and dedup review','Independent native financial admission review and fresh exact root GO',
        'Run only approved cells once, reconcile and independently review saved outputs','Separate publication approval'],
    no_finance_no_source_array_reads_no_downloads_no_holdouts=True,
    resource_intent=dict(code_generated_CPU=7,numerical_threads=1,financial_CPU_not_authorized=True,
        never_touch_CPUs=[4,5])))
write('DECISION_METADATA_INPUT_PINS.json',dict(schema='DECISION_SAFE_METADATA_PINS_V1',files=pins,
    market_array_reads=0,financial_or_provider_imports=0))
print(json.dumps(dict(status='PASS_METADATA_ONLY_OVERLAY',definitions=37,completed_catalogue_cells=90,
    extra_CS_cells=15,pending_slots=465,status_counts=counts),sort_keys=True))
