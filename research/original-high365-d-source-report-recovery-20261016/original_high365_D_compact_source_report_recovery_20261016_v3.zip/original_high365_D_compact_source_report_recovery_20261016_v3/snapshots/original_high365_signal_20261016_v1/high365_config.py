"""Fixed original HIGH365 fifteen-cell description; no admission or launch API."""
from datetime import datetime,timezone

VERSION='ORIGINAL_STATIC50_HIGH365_REFERENCE_HOLD_INTRINSIC_LOWER_ONLY_D_V1'
CANDIDATE='ORIGINAL_STATIC50_HIGH365_REFERENCE_HOLD_FIXED_SINGLE_RECIPE'
RECIPE='STATIC50_HIGH365_REFERENCE_HOLD'
SYMBOLS=('BTCUSDT','ETHUSDT','SOLUSDT','XRPUSDT','DOGEUSDT')
DAY=86_400_000_000
PERIODS=((2023,'2023-01-01','2024-01-01',365,'FULL_YEAR'),
    (2024,'2024-01-01','2025-01-01',366,'FULL_YEAR'),
    (2025,'2025-01-01','2026-01-01',365,'FULL_YEAR'),
    (2021,'2021-04-02','2022-01-01',274,'PARTIAL_APR2_DEC31'),
    (2022,'2022-01-01','2023-01-01',365,'FULL_YEAR'))
TIERS=(('LOW',.30,.05),('MID',.60,.10),('HIGH',.90,.15))


def utc(value):
    return int(datetime.fromisoformat(value).replace(tzinfo=timezone.utc).timestamp())*1_000_000


def cells():
    return tuple(dict(cell_id=f'{year}_{RECIPE}_{tier}_D_INTRINSIC_LOWER_ONLY_V1',
        year=year,recipe=RECIPE,tier=tier,adaptation_version=VERSION,
        start_UTC=start,end_exclusive_UTC=end,start_us=utc(start),end_exclusive_us=utc(end),
        calendar_days=days,calendar_label=label,gross_ceiling=gross,annual_volatility_ceiling=vol,
        asset_ceiling=.30,initial_cash_USDT='10000',fresh_independent_wallet_per_cell=True,
        product='USDT_LINEAR_PERPETUAL',symbol_order=list(SYMBOLS),isolated_leverage='1x',
        cost='BASE27',execution_policy='GUARD50_EXIT_ONLY_CURRENT_D_NO_TOPUP',
        original_execution_replication=False,complete_original_intrinsic_signal_preserved=True,
        tier_operation='DOWNWARD_ONLY_AFTER_ORIGINAL_INTRINSIC_RETARGET',
        current_source_admission=False,current_financial_admission=False,
        execution_reuse_authorized=False,classification='SEEN_DEVELOPMENT_NOT_UNTOUCHED_OOS')
        for year,start,end,days,label in PERIODS for tier,gross,vol in TIERS)


def period_named(year):
    if type(year) is not int:
        raise ValueError('EXACT_INTEGER_DEV_YEAR_REQUIRED')
    for y,start,end,days,label in PERIODS:
        if year==y:
            return dict(year=y,start=utc(start),end=utc(end),days=days,label=label)
    raise ValueError('EXACT_FIVE_DEV_PERIODS_REQUIRED_HOLDOUT_CLOSED')


def cell_named(cell_id):
    for cell in cells():
        if cell['cell_id']==cell_id:
            return cell
    raise ValueError('EXACT_FIXED_ORIGINAL_HIGH365_CELL_REQUIRED')


def manifest():
    return dict(schema=VERSION,candidate=CANDIDATE,cell_count=15,cells=list(cells()),
        source_entry_implemented=False,financial_entry_implemented=False,
        original_execution_replication=False,source_authority_granted=False,
        financial_authority_granted=False,publication_authority_granted=False)
