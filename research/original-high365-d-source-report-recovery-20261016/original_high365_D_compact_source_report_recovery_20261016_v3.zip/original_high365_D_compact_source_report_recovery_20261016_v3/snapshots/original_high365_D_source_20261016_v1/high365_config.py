"""Fixed fifteen-cell high365 plan; only the all15 have a fresh source-only gate."""
from datetime import datetime, timezone
from types import MappingProxyType

VERSION = 'ORIGINAL_STATIC50_HIGH365_REFERENCE_HOLD_INTRINSIC_LOWER_ONLY_D_V1'
CANDIDATE = 'ORIGINAL_STATIC50_HIGH365_REFERENCE_HOLD_SINGLE_RECIPE_LOWER_ONLY'
RECIPES = ('STATIC50_HIGH365_REFERENCE_HOLD',)
SYMBOLS = ('BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'XRPUSDT', 'DOGEUSDT')
TIERS = ('LOW', 'MID', 'HIGH')
TIER_BUDGETS = MappingProxyType({'LOW': .05, 'MID': .10, 'HIGH': .15})
TIER_GROSS_CAPS = MappingProxyType({'LOW': .30, 'MID': .60, 'HIGH': .90})
DAY = 86_400_000_000
PERIODS = ((2023,'2023-01-01','2024-01-01',365,'FULL_YEAR'),
    (2024,'2024-01-01','2025-01-01',366,'FULL_YEAR'),
    (2025,'2025-01-01','2026-01-01',365,'FULL_YEAR'),
    (2021,'2021-04-02','2022-01-01',274,'PARTIAL_APR2_DEC31'),
    (2022,'2022-01-01','2023-01-01',365,'FULL_YEAR'))


def utc(value):
    return int(datetime.fromisoformat(value).replace(tzinfo=timezone.utc).timestamp()) * 1_000_000


def cells():
    return tuple(dict(cell_id=f'{year}_{recipe}_{tier}_D_INTRINSIC_LOWER_ONLY_V1',
        recipe=recipe, adaptation_version=VERSION, tier=tier, year=year,
        start_UTC=start,end_exclusive_UTC=end,start_us=utc(start),end_exclusive_us=utc(end),
        calendar_days=days,calendar_label=label,annual_volatility_ceiling=TIER_BUDGETS[tier],
        gross_ceiling=TIER_GROSS_CAPS[tier],asset_ceiling=.30,
        preserves_complete_original_intrinsic_signal=True,downward_only=True,
        original_execution_unchanged=False,execution_policy='GUARD50_EXIT_ONLY_CURRENT_D_NO_TOPUP',
        initial_cash_USDT='10000',fresh_independent_wallet_per_cell=True,
        financial_reuse_allowed=False,classification='SEEN_DEVELOPMENT_NOT_UNTOUCHED_OOS')
        for year,start,end,days,label in PERIODS for recipe in RECIPES for tier in TIERS)


def cell_named(cell_id):
    for cell in cells():
        if cell['cell_id'] == cell_id:
            return cell
    raise ValueError('EXACT_HIGH365_FIFTEEN_CELL_MANIFEST_REQUIRED')


def period_named(year):
    if type(year) is not int:
        raise ValueError('EXACT_INTEGER_DEVELOPMENT_YEAR_REQUIRED')
    for y,start,end,days,label in PERIODS:
        if y == year:
            return dict(year=y,start=utc(start),end=utc(end),days=days,label=label,
                        warmup_start=utc(start)-199*DAY)
    raise ValueError('EXACT_FIVE_DEVELOPMENT_PERIODS_REQUIRED')


def source_year(year):
    if type(year) is not int or year not in (2021,2022,2023,2024,2025):
        raise ValueError('ONLY_FIVE_DEV_PERIODS_2021_2022_2023_2024_2025_HOLDOUT_CLOSED')
    return period_named(year)
