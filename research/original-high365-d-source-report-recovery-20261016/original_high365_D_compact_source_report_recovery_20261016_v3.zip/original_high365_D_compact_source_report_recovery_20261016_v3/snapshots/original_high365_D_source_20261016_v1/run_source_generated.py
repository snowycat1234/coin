"""Instrumented single-process synthetic-only suite; no external actions."""
import os
THREAD_ENV = ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS',
              'NUMEXPR_NUM_THREADS', 'POLARS_MAX_THREADS', 'VECLIB_MAXIMUM_THREADS', 'BLIS_NUM_THREADS')
for key in THREAD_ENV:
    os.environ[key] = '1'
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'

import builtins
from contextlib import ExitStack
import io
import json
from pathlib import Path
import resource
import socket
import subprocess
import sys
import time
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
observed = dict(stored_array_body_open_attempts_reaching_outer_guard=0, old_private_GO_body_read_attempts=0,
                external_process_launch_attempts=0, network_attempts=0)


stdlib_code_zip_checks=[]
STDLIB_CODE_ZIP=Path(sys.base_prefix)/('lib/python'+str(sys.version_info.major)+str(sys.version_info.minor)+'.zip')


def check(file):
    if isinstance(file, int) or not isinstance(file, (str, bytes, os.PathLike)):
        return
    path = Path(os.path.abspath(os.fsdecode(file)))
    if path==STDLIB_CODE_ZIP:
        stdlib_code_zip_checks.append(str(path));return
    generated = path.parent.parent == HERE / 'source_attempts' and path.parent.name.startswith('GENERATED_')
    generated = generated or any(p.parent == HERE / 'source_attempts' and p.name.startswith('GENERATED_') for p in path.parents)
    if not generated and path.suffix.lower() in ('.npz', '.npy', '.csv', '.tsv', '.parquet', '.arrow', '.ipc', '.zip'):
        observed['stored_array_body_open_attempts_reaching_outer_guard'] += 1
        print('OUTER_GENERATED_BODY_READ_BLOCKED',str(path),flush=True)
        raise AssertionError('NO_STORED_ARRAY_OR_MARKET_BODY_READS_IN_GENERATED_SUITE:' + str(path))
    if not generated and 'source_attempts' in path.parts and path.name != 'PREPARATION.json':
        observed['stored_array_body_open_attempts_reaching_outer_guard'] += 1
        raise AssertionError('NO_ACTUAL_SAVED_SOURCE_ARTIFACT_READS:' + str(path))
    if ('annual_go' in path.parts or path.name.startswith('ROOT_GO_APPROVED')
            or path.name in ('ROOT_GO.json', 'ROOT_GO_FINANCIAL.json')):
        observed['old_private_GO_body_read_attempts'] += 1
        raise AssertionError('NO_PRIVATE_OLD_GO_BODY_READS:' + str(path))


def wrapped(original):
    def opened(file, mode='r', *args, **kwargs):
        if 'r' in mode or '+' in mode:
            check(file)
        return original(file, mode, *args, **kwargs)
    return opened


original_os_open = os.open


def os_open(path, flags, *args, **kwargs):
    if not flags & os.O_WRONLY:
        check(path)
    return original_os_open(path, flags, *args, **kwargs)


def main():
    os.sched_setaffinity(0, {7})
    began = time.monotonic()
    with ExitStack() as stack:
        for obj, name, fn in ((builtins, 'open', wrapped(builtins.open)),
                              (io, 'open', wrapped(io.open)), (os, 'open', os_open)):
            stack.enter_context(patch.object(obj, name, fn))
        def denied(category, target):
            def fail(*args, **kwargs):
                observed[category] += 1
                raise AssertionError('GENERATED_ONLY_EXTERNAL_ACTION_FORBIDDEN:' + target)
            return fail
        for obj, names, category in (
            (subprocess, ('Popen', 'run', 'call', 'check_call', 'check_output'), 'external_process_launch_attempts'),
            (os, ('system', 'fork', 'forkpty', 'posix_spawn', 'posix_spawnp', 'execv', 'execve', 'execvp', 'execvpe'),
             'external_process_launch_attempts'),
            (socket.socket, ('connect', 'connect_ex', 'sendto', 'send', 'sendall'), 'network_attempts')):
            for name in names:
                if hasattr(obj, name):
                    stack.enter_context(patch.object(obj, name, denied(category, name)))
        suite = unittest.defaultTestLoader.loadTestsFromNames(['test_all15','test_original_prefix'])
        result = unittest.TextTestRunner(verbosity=2).run(suite)
    import high365_generated
    from high365_common import canonical,sha
    boundaries=dict(schema='HIGH365_GENERATED_GUARD_POSITIVE_NEGATIVE_CLASSIFICATIONS_V1',
        clean_runs_require_zero_forbidden_attempts=True,
        negative_controls_are_expected_counted_blocks_not_clean_runs=True,
        receipts=high365_generated.observed_guard_receipts)
    boundaries_raw=canonical(boundaries)+b'\n'
    (HERE/'SOURCE_GENERATED_BOUNDARY_RECEIPTS.json').write_bytes(boundaries_raw)
    receipt = dict(generated_ephemeral_source_scope_lifecycle=dict(high365_generated.observed_generated_scope_lifecycle),
        boundary_receipts_SHA256=sha(boundaries_raw),
        expected_negative_controls='COUNTED_BLOCKS_SEPARATE_FROM_CLEAN_ZERO_ATTEMPT_RUNS', schema='HIGH365_INTRINSIC_ALL15_SOURCE_GRAPH_GENERATED_ONLY_RECEIPT_V1',
        status='PASS' if result.wasSuccessful() and not any(observed.values()) else 'FAIL',
        tests=result.testsRun, failures=len(result.failures), errors=len(result.errors), observed=observed,
        stdlib_code_zip_import_checks=stdlib_code_zip_checks,
        CPU_affinity=sorted(os.sched_getaffinity(0)),
        all_TID_affinities=[sorted(os.sched_getaffinity(int(t))) for t in os.listdir('/proc/self/task')],
        numerical_environment={key: os.environ[key] for key in THREAD_ENV},
        elapsed_wall_seconds=time.monotonic() - began,
        peak_RSS_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024,
        worker_processes_launched=0, maximum_generated_processes=1,
        actual_source_body_reads=0, actual_targets_generated=0, actual_financial_runs=0,
        actual_claims_written=0, source_admission_GO_written=0, generated_ephemeral_metadata_authority_only=True, financial_GO_written=0,
        provider_or_history_calls=0, publication_actions=0, holdout_reads=0,
        original_intrinsic_and_downward_only_arrays='GENERATED_IN_MEMORY_ONLY_NOT_ACTUAL_TARGET_ARTIFACTS')
    from high365_entry import code_identity,manifest_sha,contract_sha
    receipt.update(source_code_manifest_SHA256=code_identity(),scope_manifest_SHA256=manifest_sha(),
        source_contract_map_SHA256=contract_sha(),actual_source_scopes_minted=0,historical_scopes_minted=0,
        source_authority_domain='ALL15_SAVED_SOURCE_TARGET_ONLY_NO_FINANCIAL_ENTRY',
        source_scopes_revoked=not __import__('high365_entry')._ACTIVE_SOURCE,
        recording_scopes_revoked=not __import__('high365_entry')._ACTIVE_RECORDING,
        loaded_inputs_revoked=not __import__('high365_loader')._LIVE)
    (HERE / 'SOURCE_GENERATED_TEST_RECEIPT.json').write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
    return 0 if receipt['status'] == 'PASS' else 1


if __name__ == '__main__':
    raise SystemExit(main())
