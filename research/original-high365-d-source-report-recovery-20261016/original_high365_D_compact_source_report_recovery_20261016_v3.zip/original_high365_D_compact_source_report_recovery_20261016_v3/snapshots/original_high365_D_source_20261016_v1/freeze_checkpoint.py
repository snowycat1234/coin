"""Freeze only this new CODE/generated checkpoint. No runtime authority mint."""
from pathlib import Path
import hashlib,json
HERE=Path(__file__).absolute().parent
FILES=('DEPENDENCY_PINS.json', 'FROZEN_FIFTEEN_CELL_MANIFEST.json', 'README.md', 'RUNTIME_READ_CLASSIFICATION.json', 'SOURCE_CONTRACT_MAP.json', 'freeze_checkpoint.py', 'high365_codec.py', 'high365_common.py', 'high365_config.py', 'high365_entry.py', 'high365_generated.py', 'high365_loader.py', 'high365_prefix.py', 'high365_signal.py', 'high365_source.py', 'high365_source_guard.py', 'prepare_high365_source.py', 'run_source_generated.py', 'test_all15.py', 'test_cold_generated_zip.py', 'test_original_prefix.py')
def main():
 def pin(p):
  raw=p.read_bytes();return dict(SHA256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))
 record=dict(schema='HIGH365_INTRINSIC_SOURCE_ONLY_CODE_IDENTITY_V1',status='GENERATED_ONLY_NOT_ACTUAL_ADMISSION',
  files={name:pin(HERE/name) for name in FILES},dependencies=json.loads((HERE/'DEPENDENCY_PINS.json').read_bytes())['files'],
  actual_source_authorized=False,financial_entry_implemented=False)
 (HERE/'CODE_MANIFEST.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
if __name__=='__main__':main()
