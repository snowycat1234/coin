"""Generated original-prefix reader, hostile layouts and real Polars writer."""
from io import BytesIO
from copy import deepcopy
from unittest.mock import patch
import unittest
import zipfile
import numpy as np
import pandas as pd
import polars as pl
import high365_prefix as prefix
import high365_common as c
import high365_config as config
import high365_codec as codec
import high365_generated as generated
import high365_signal as signal


def wrapper(member,name='Y2023.npz'):
    b=BytesIO()
    with zipfile.ZipFile(b,'w',compression=zipfile.ZIP_DEFLATED) as z:
        z.writestr(name,member);z.writestr('UNSELECTED_POISON.npy',b'NEVER_OPEN_ME')
    return b.getvalue()


def contract_for(member,year=2023):
    wr=wrapper(member)
    return wr,dict(wrapper=dict(SHA256=c.sha(wr),bytes=len(wr)),member=dict(name='Y2023.npz',SHA256=c.sha(member),bytes=len(member)))


class Prefix(unittest.TestCase):
    def test_365_owning_rank_coverage_rejected_before_close_payload(self):
        a=generated.daily(2023)
        member=generated.pack(symbol_order=np.asarray(config.SYMBOLS),
            close_available_us=a['close_available_us'],close=a['close'])
        wr,contract=contract_for(member);opened=[];original=zipfile.ZipFile.open
        def op(z,name,*args,**kwargs):
            opened.append(name.filename if isinstance(name,zipfile.ZipInfo) else name)
            return original(z,name,*args,**kwargs)
        with patch.object(zipfile.ZipFile,'open',op):
            with self.assertRaisesRegex(ValueError,'HIGH365_OWNING_RANK_SOURCE_CLOCK_COVERAGE'):
                prefix.select_prefix(wr,contract,2023)
        self.assertNotIn('close.npy',opened)

    def fixture(self,year=2023):
        a=generated.daily(year);t=a['close_available_us'];p=a['close'];extra=200
        pt=t[0]-np.arange(extra,0,-1,dtype=np.int64)*config.DAY
        pp=np.tile(np.array([100,120,140,160,180],dtype=np.float64),(extra,1))
        return np.r_[pt,t,t[-1]+config.DAY,t[-1]+2*config.DAY],np.vstack([pp,p,np.full((2,5),np.nan)])

    def test_only_source_fields_and_causal_row_prefix_numerically_decoded(self):
        for year in (2021,2022,2023,2024,2025):
            t,p=self.fixture(year);member=generated.pack(symbol_order=np.asarray(config.SYMBOLS),close_available_us=t,close=p,UNSELECTED_OBJECT=np.array([object()],dtype=object))
            wr,contract=contract_for(member,year);opened=[];decoded=[];original=zipfile.ZipFile.open;frombuffer=np.frombuffer
            def op(z,name,*args,**kw):
                opened.append(name.filename if isinstance(name,zipfile.ZipInfo) else name);return original(z,name,*args,**kw)
            def fb(raw,dtype=float,*args,**kwargs):
                if np.dtype(dtype)==np.dtype('float64'):decoded.append(len(raw))
                return frombuffer(raw,dtype,*args,**kwargs)
            with patch.object(zipfile.ZipFile,'open',op),patch.object(np,'frombuffer',fb):selected,proof=prefix.select_prefix(wr,contract,year)
            self.assertEqual(opened,['Y2023.npz','symbol_order.npy','close_available_us.npy','close.npy'])
            self.assertEqual(proof['future_close_rows_interpreted'],0)
            self.assertEqual(set(decoded),{proof['selected_rows']*5*8})
            self.assertEqual(selected['clocks'][0],t[0]);self.assertEqual(selected['clocks'][-1],config.source_year(year)['end']-config.DAY)
            self.assertTrue(np.isfinite(selected['close']).all())
            canonical=generated.daily(year);prefix.validate_canonical_parity(selected,dict(clocks=canonical['close_available_us'],close=canonical['close']))

    def test_unsupported_layout_dtype_symbols_and_clock_fail_before_numeric_close(self):
        t,p=self.fixture();order=np.asarray(config.SYMBOLS)
        for key,value in (('close',np.asfortranarray(p)),('close',p.astype('>f8')),('close',np.array(p,dtype=object)),
            ('close_available_us',t.astype('u8')),('symbol_order',order[::-1])):
            arrays=dict(symbol_order=order,close_available_us=t,close=p);arrays[key]=value
            wr,contract=contract_for(generated.pack(**arrays))
            with self.assertRaises(ValueError):prefix.select_prefix(wr,contract,2023)
        for bad in (t.copy(),t.copy()):
            bad[3]=bad[2]
            wr,contract=contract_for(generated.pack(symbol_order=order,close_available_us=bad,close=p))
            with self.assertRaises(ValueError):prefix.select_prefix(wr,contract,2023)
        wr,contract=contract_for(generated.pack(symbol_order=order,close_available_us=t,close=p));bad=deepcopy(contract);bad['member']['SHA256']='0'*64
        with self.assertRaises(ValueError):prefix.select_prefix(wr,bad,2023)

    def test_exact_preloaded_polars_class_is_benign_workspace_spoof_still_blocked(self):
        import sys,types
        from high365_source_guard import SourceOnlyGuard,SourceBoundaryViolation
        # The actual installed dependency descriptor is loaded, never invoked.
        from polars.catalog.unity.client import CatalogCredentialProvider
        self.assertTrue(CatalogCredentialProvider.__module__.startswith('polars.'))
        guard=SourceOnlyGuard(read_paths=generated.read_paths())
        with guard:guard.checkpoint('TRUSTED_INSTALLED_POLARS_DESCRIPTOR_ONLY')
        self.assertFalse(any(guard.attempts.values()))
        for name in ('_generated_polars_like','polars.spoofed_workspace'):
            module=types.ModuleType(name);module.__file__=str(c.ROOT/'untrusted_workspace'/'polars'/'provider.py')
            module.CatalogCredentialProvider=type('CatalogCredentialProvider',(),{})
            previous=sys.modules.get(name);sys.modules[name]=module
            try:
                guard=SourceOnlyGuard(read_paths=generated.read_paths())
                with self.assertRaises(SourceBoundaryViolation):
                    with guard:pass
                self.assertEqual(guard.attempts['financial_imports'],1)
            finally:
                if previous is None:sys.modules.pop(name,None)
                else:sys.modules[name]=previous



    def test_real_polars_writer_and_roundtrip_all_calendar_shapes(self):
        for year in (2021,2023,2024):
            a=generated.long_daily(year);t=a['close_available_us'];period=config.source_year(year);d=np.arange(period['start'],period['end'],config.DAY,dtype=np.int64);arrays,_=signal.build_target_grid(a['close'],t,t,d)
            w=arrays[config.RECIPES[0]+'_LOW']
            frame=pl.DataFrame(dict(available_us=np.repeat(d,5),symbol=list(config.SYMBOLS)*len(d),target_weight=w.reshape(-1)))
            self.assertEqual(frame.height,len(d)*5);self.assertEqual(frame.schema['available_us'],pl.Int64)
            raw=frame.write_csv().encode();loaded=pl.read_csv(BytesIO(raw),schema_overrides={'available_us':pl.Int64,'symbol':pl.String,'target_weight':pl.Float64})
            self.assertEqual(loaded.shape,frame.shape);self.assertEqual(loaded['available_us'].to_list(),frame['available_us'].to_list())
            np.testing.assert_allclose(loaded['target_weight'].to_numpy(),w.reshape(-1),rtol=0,atol=0)

if __name__=='__main__':unittest.main(verbosity=2)
