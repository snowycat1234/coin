"""Generated real control path, strict metadata/array/guard negative coverage."""
from copy import deepcopy
from io import BytesIO
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile
import types
import unittest
from unittest.mock import patch
import zipfile
import numpy as np
import high365_common as c
import high365_codec as codec
import high365_config as config
import high365_entry as entry
import high365_generated as generated
import high365_loader as loader
import high365_signal as signal
import high365_source as source
from high365_source_guard import SourceOnlyGuard,SourceBoundaryViolation


class ScopeAndSchemaTests(unittest.TestCase):
    def test_exact_frozen15_all15_order_and_calendar(self):
        self.assertEqual(len(config.cells()),15);self.assertEqual(len(entry.tranche_cells(entry.ALL15)),15)
        self.assertEqual(set(config.RECIPES),{'STATIC50_HIGH365_REFERENCE_HOLD'})
        self.assertEqual(entry.tranche_years(entry.ALL15),(2023,2024,2025,2021,2022))
        self.assertEqual(config.source_year(2021)['days'],274);self.assertEqual(config.source_year(2024)['days'],366)
        self.assertEqual(config.source_year(2023)['days'],365)
        for y in (2026,2027,2019,True,False,'2022',2022.):
            with self.assertRaises(ValueError):config.source_year(y)
            with self.assertRaises(ValueError):codec.daily_inputs(y,b'')
            with self.assertRaises(ValueError):source.capture_year(y,object())
        for tranche in ('FIRST6_2023_TWO_RECIPES_ALL_THREE_TIERS','ALL30','REMAINING9',None):
            with self.assertRaises(ValueError):entry.tranche_cells(tranche)

    def test_metadata_gate_namespaces_exact_scope_and_permissions(self):
        go,gs,review,rs=generated.authority();entry.validate_source_authority_metadata(go,gs,review,rs)
        for key,value in (('schema','ROOT_SOURCE_TARGET_HIGH365_INTRINSIC_LOWER_ONLY_V1'),('years',[2023]),
            ('ordered_cells',list(reversed(entry.tranche_cells(entry.ALL15)))),('candidate','CSMOM21_COMMON_TIER'),
            ('adaptation_version','PLAIN_V3'),('tranche','ALL30'),('first6_cells_source_authorized',True),
            ('old_CS_core_D_or_high365_baseline_authority_reused',True),('extra','x')):
            raw=c.canonical(dict(c.exact_object(go),**{key:value}))
            with self.assertRaises(ValueError):entry.validate_source_authority_metadata(raw,c.sha(raw),review,rs)
        for key in ('historical_execution_authorized','financial_execution_authorized','account_construction_authorized',
                    'provider_iteration_authorized','process_launch_authorized','canonical_claims_authorized','financial_GO_authorized','publication_authorized','downloads_authorized'):
            raw=c.canonical(dict(c.exact_object(go),**{key:True}))
            with self.assertRaises(ValueError):entry.validate_source_authority_metadata(raw,c.sha(raw),review,rs)
        for field in ('schema','code_manifest_SHA256','scope_manifest_SHA256','source_contract_map_SHA256','pure_signal_code_manifest_SHA256','years','ordered_cells'):
            raw=c.canonical(dict(c.exact_object(review),**{field:'MUTATED'}))
            with self.assertRaises(ValueError):entry.validate_source_authority_metadata(go,gs,raw,c.sha(raw))
        for old in ('ROOT_SOURCE_TARGET_CSMOM21_COMMON_TIER_V2','ROOT_FINANCIAL_CSMOM21_COMMON_TIER_V2','ROOT_GO_HIGH365_BASELINE','ROOT_CORE_D'):
            raw=c.canonical(dict(c.exact_object(go),schema=old))
            with self.assertRaises(ValueError):entry.validate_source_authority_metadata(raw,c.sha(raw),review,rs)
        with self.assertRaises(ValueError):entry.validate_source_authority_metadata(go,'0'*64,review,rs)
        with self.assertRaises(ValueError):entry.validate_source_authority_metadata(go,gs,review,'0'*64)
        with self.assertRaises(ValueError):
            with entry.admit_source_stage(go,gs,review,rs):pass
        with self.assertRaises(ValueError):source.capture_year(2022,object())
        with self.assertRaises(ValueError):entry.High365SourcePreparationScope(entry.ALL15,gs,rs,go,review,entry.code_identity(),object(),object())

    def test_generated_scope_lifecycle_wrong_year_and_no_actual_reads(self):
        go,gs,review,rs=generated.authority();guard=SourceOnlyGuard(read_paths=generated.read_paths());captured=None
        with guard:
            with entry.admit_source_stage(go,gs,review,rs) as scope:
                generated.observed_generated_scope_lifecycle['minted']+=1;captured=scope
                for y in entry.tranche_years(entry.ALL15):self.assertTrue(scope.validate_current(year=y))
                for y in (2026,True,'2021'):
                    with self.assertRaises(ValueError):scope.validate_current(year=y)
                for path in ('../bad','CS_TARGETS.npz','2026/HOLDOUT.npz'):
                    with self.assertRaises(ValueError):scope.read_source(2022,path,'0'*64)
            generated.observed_generated_scope_lifecycle['revoked']+=1
        with self.assertRaises(ValueError):captured.validate_current()
        self.assertFalse(any(guard.attempts.values()));generated.observed_guard_receipts.append(guard.receipt('PASS_CLEAN_EPHEMERAL_METADATA_ONLY'))
        self.assertFalse(entry._ACTIVE_SOURCE)

    def test_generated_scope_actual_body_read_stopped_before_open(self):
        contract=entry.contracts()['years']['2022'];name,pin=next(iter(contract['read_files'].items()))
        go,gs,review,rs=generated.authority();guard=SourceOnlyGuard(read_paths=generated.read_paths())
        with self.assertRaises(SourceBoundaryViolation):
            with guard:
                with entry.admit_source_stage(go,gs,review,rs) as scope:
                    generated.observed_generated_scope_lifecycle['minted']+=1
                    try:scope.read_source(2022,name,pin['SHA256'],pin['bytes'])
                    finally:generated.observed_generated_scope_lifecycle['revoked']+=1
        self.assertEqual(guard.attempts['nonallowlisted_file_reads'],1)
        generated.observed_generated_scope_lifecycle['actual_body_read_blocks']+=1
        generated.observed_guard_receipts.append(guard.receipt('EXPECTED_NEGATIVE_ACTUAL_BODY_READ_BLOCKED_BEFORE_OPEN'))
        self.assertFalse(entry._ACTIVE_SOURCE)


class CodecAndSignalTests(unittest.TestCase):
    def test_high365_missing_history_mask_identity_and_generated_writer(self):
        a=generated.long_daily(2021);t=a['close_available_us'];p=a['close'].copy()
        period=config.source_year(2021);d=np.arange(period['start'],period['end'],config.DAY,dtype=np.int64)
        first=int(np.searchsorted(t,d[0]));p[first-250,2]=np.nan
        arrays,proofs=signal.build_target_grid(p,t,t,d)
        mask=arrays['HIGH365_CURRENT_ELIGIBLE']
        self.assertEqual(mask.dtype,np.dtype(bool));self.assertFalse(mask[0,2])
        self.assertEqual(arrays['HIGH365_ORIGINAL'][0,2],0.)
        self.assertTrue(np.isfinite(arrays['HOLD_ORIGINAL']).all())
        self.assertEqual(len(proofs),period['days']);self.assertFalse(mask.flags.writeable)
        identities={k:signal.array_byte_identity(v) for k,v in arrays.items()}
        entry.checked_array_identities(identities,2021)
        mutated=deepcopy(identities);mutated['HIGH365_CURRENT_ELIGIBLE']=signal.array_byte_identity(mask.astype('float64'))
        with self.assertRaises(ValueError):entry.checked_array_identities(mutated,2021)
        loaded=codec.npz(source.target_blob(arrays),entry.array_specs(2021))
        for key in arrays:self.assertEqual(arrays[key].tobytes(),loaded[key].tobytes())
        self.assertEqual(loaded['HIGH365_CURRENT_ELIGIBLE'].dtype,np.dtype(bool))

    def test_exact_generated_calendars_and_endpoint_or_holdout_row_reject(self):
        for year in entry.tranche_years(entry.ALL15):
            a=generated.daily(year);t,p,d=codec.daily_inputs(year,generated.pack(**a));period=config.source_year(year)
            self.assertEqual((len(t),len(d)),(period['days']+199,period['days']));self.assertLess(t[-1],period['end'])
            for key,value in (('close',a['close'].astype('f4')),('close',a['close'].astype('>f8')),('close_available_us',a['close_available_us'].astype('u8'))):
                bad=dict(a);bad[key]=value
                with self.assertRaises(ValueError):codec.daily_inputs(year,generated.pack(**bad))
            for kind in ('endpoint','clock','nonfinite','extra'):
                bad={k:v.copy() for k,v in a.items()}
                if kind=='endpoint':bad['close_available_us'][-1]=period['end']
                elif kind=='clock':bad['close_available_us'][2]+=1
                elif kind=='nonfinite':bad['close'][3,0]=np.nan
                else:bad['target']=np.ones((2,5))
                with self.assertRaises(ValueError):codec.daily_inputs(year,generated.pack(**bad))

    def test_unsupported_dtypes_gate_and_endian_shape_signed_zero_exact_identity(self):
        with patch.object(signal,'reviewed_signal',side_effect=AssertionError('GENERIC_IDENTITY_MUST_NOT_RUN')):
            for dtype in (object,'V16',[('x','f8'),('y','f8')],'f4','c16','U4','M8[ns]','u8'):
                with self.assertRaisesRegex(ValueError,'UNSUPPORTED_DTYPE'):signal.array_byte_identity(np.zeros(3,dtype=dtype))
        a=np.array([1.,-0.]);ident=signal.array_byte_identity(a)
        for bad in (a.astype('>f8'),a.reshape(1,2),np.array([1.,0.])):self.assertNotEqual(ident,signal.array_byte_identity(bad))
        with self.assertRaises(ValueError):signal.immutable_array(a).setflags(write=True)

    def test_strict_npz_header_gate_before_any_payload(self):
        for a in (np.zeros(4,dtype='V16'),np.zeros(4,dtype=[('x','f8'),('y','f8')]),np.zeros(4,dtype=object),np.asfortranarray(np.ones((2,2)))):
            with patch.object(np,'load',side_effect=AssertionError('HEADER_FIRST')):
                with self.assertRaises(ValueError):codec.npz(generated.pack(x=a),{'x':((4,),'float64')})
        raw=BytesIO();np.save(raw,np.ones(4),allow_pickle=False)
        for payloads in ((raw.getvalue(),raw.getvalue()),(raw.getvalue()[:-1],)):
            z=BytesIO()
            with zipfile.ZipFile(z,'w') as a:
                for p in payloads:a.writestr('x.npy',p)
            with patch.object(np,'load',side_effect=AssertionError('HEADER_FIRST')):
                with self.assertRaises(ValueError):codec.npz(z.getvalue(),{'x':((4,),'float64')})

    def test_all_year_original_intrinsic_exact_arrays_proofs_and_prefix_invariance(self):
        for year in entry.tranche_years(entry.ALL15):
            a=generated.long_daily(year);t=a['close_available_us'];p=a['close'];period=config.source_year(year)
            d=np.arange(period['start'],period['end'],config.DAY,dtype='int64')
            actual,proofs=signal.build_target_grid(p,t,t,d)
            original,op=signal.reviewed_signal().build_target_grid(p,t,t,d,symbols=config.SYMBOLS)
            for key in actual:self.assertEqual(actual[key].tobytes(),original[key].tobytes())
            self.assertEqual(c.canonical(proofs),c.canonical(op))
            for tier in config.TIERS:
                key=config.RECIPES[0]+'_'+tier;intrinsic=actual['intrinsic_'+config.RECIPES[0]]
                self.assertTrue((np.abs(actual[key])<=np.abs(intrinsic)+1e-15).all())
            for count in (1,38,len(d)//2,len(d)):
                stop=int(np.searchsorted(t,d[count-1]))+1;prefix,pp=signal.build_target_grid(p[:stop],t[:stop],t[:stop],d[:count])
                for key,v in prefix.items():self.assertEqual(v.tobytes(),actual[key][:count].tobytes())
                self.assertEqual(c.canonical(pp),c.canonical(proofs[:count]))

    def test_source_capture_literal_funding_quality_and_year_specific_negatives(self):
        contracts,storage=generated.fake_storage()
        for year in entry.tranche_years(entry.ALL15):
            contract=contracts['years'][str(year)];raw={name:storage[str(c.ROOT/pin['path'])] for name,pin in contract['artifacts'].items()}
            decoded=source.decode_capture(year,raw,contract)
            self.assertEqual(decoded['events'][0]['event_us'],config.source_year(year)['start']+15001)
            self.assertEqual(c.canonical(decoded['sidecar']),c.canonical(c.exact_object(raw['MINUTE_MARK_PROVENANCE.json'])))
            self.assertFalse(decoded['close'].flags.writeable)
            for name in raw:
                bad=dict(raw);bad[name]+=b'X'
                with self.assertRaises(ValueError):source.decode_capture(year,bad,contract)
            for field,value in (('event_us',True),('reported_interval_hours',True),('reported_interval_hours',3),('raw_rate',True),('symbol','BNBUSDT')):
                events=c.object_json(raw['RAW_EVENTS.json']);events[0][field]=value
                with self.assertRaises(ValueError):source.funding_events(year,c.canonical(events),contract)
            events=c.object_json(raw['RAW_EVENTS.json'])
            for bad in (events[::-1],[events[0]]*len(events)):
                with self.assertRaises(ValueError):source.funding_events(year,c.canonical(bad),contract)
            # Self-consistent altered source pins still face semantic/qualified metadata gates.
            for field,value in ((('qualified_terminal_source_witness','terminal_quotes'),[]) if year==2021 else
                (('cells',),[]) if year==2022 else (('genuine_recovery_witnesses',),[{'invented_price':1}]) if year==2024 else (('arrival_status',),'CERTIFIED'),):
                side=c.exact_object(raw['MINUTE_MARK_PROVENANCE.json']);obj=side
                for key in field[:-1]:obj=obj[key]
                obj[field[-1]]=value;body=c.canonical(side);bad=dict(raw,**{'MINUTE_MARK_PROVENANCE.json':body});changed=deepcopy(contract)
                changed['artifacts']['MINUTE_MARK_PROVENANCE.json'].update(SHA256=c.sha(body),bytes=len(body))
                with self.assertRaises(ValueError):source.decode_capture(year,bad,changed)


class RealCliGeneratedTests(unittest.TestCase):
    def test_real_cli_fake_storage_all24_loader_callbacks_scope_revocation_and_strict_negatives(self):
        import prepare_high365_source as cli
        output=c.HERE/'source_attempts'/'GENERATED_REAL_CLI_ONLY'
        if output.exists():raise AssertionError('EXCLUSIVE_GENERATED_OUTPUT_REQUIRED')
        try:
            with generated.installed_fake_storage() as (contracts,storage),tempfile.TemporaryDirectory(dir=c.HERE) as td:
                go,gs,review,rs=generated.authority();td=Path(td)
                gp=td/'GENERATED_AUTHORIZATION.json';rp=td/'GENERATED_REVIEW.json';gp.write_bytes(go);rp.write_bytes(review)
                argv=['prepare_high365_source.py','--output',str(output),'--source-go',str(gp),'--source-go-sha',gs,
                    '--source-review',str(rp),'--source-review-sha',rs,'--cpu','0']
                with patch.object(sys,'argv',argv),patch.object(cli,'assign_source_cpu',side_effect=lambda cpu:self.assertEqual(cpu,0)),patch.object(cli.resource,'setrlimit'),patch.object(cli.signal,'signal'),patch.object(cli.signal,'alarm'):
                    cli.main()
                generated.observed_generated_scope_lifecycle['real_CLI_positive_controls']+=1
                prep_raw=(output/'PREPARATION.json').read_bytes();prep=entry.validate_preparation_metadata(prep_raw)
                self.assertEqual(len(prep['cells']),15)
                generated.observed_generated_scope_lifecycle['minted']+=1
                generated.observed_generated_scope_lifecycle['revoked']+=1
                artifacts={name:(output/name).read_bytes() for name in prep['artifacts']}
                receipt=c.exact_object((output/'OBSERVED_SOURCE_TARGET_GUARD_RECEIPT.json').read_bytes())
                self.assertFalse(any(receipt['forbidden_attempts'].values()));self.assertTrue(receipt['source_scopes_revoked']);self.assertTrue(receipt['recording_scopes_revoked'])
                generated.observed_guard_receipts.append(receipt)
                for year in entry.tranche_years(entry.ALL15):
                    arrays,inputs=loader.decode_saved(prep_raw,artifacts,year)
                    self.assertEqual(len(arrays['decision_us']),config.source_year(year)['days'])
                    for a in (*arrays.values(),*inputs.values()):
                        with self.assertRaises(ValueError):a.setflags(write=True)
                    reads=generated.read_paths()+[output/'PREPARATION.json']+[output/name for name in prep['artifacts']]
                    guard=SourceOnlyGuard(read_paths=reads)
                    with guard:
                        loaded=loader.load_year(output,expected_preparation_sha256=c.sha(prep_raw),year=year,
                            source_go_raw=go,expected_source_go_sha256=gs,source_review_raw=review,expected_source_review_sha256=rs)
                        self.assertTrue(loaded.validate());loader.revoke(loaded)
                        with self.assertRaises(ValueError):loaded.validate()
                    self.assertFalse(any(guard.attempts.values()));generated.observed_guard_receipts.append(guard.receipt('PASS_GENERATED_SAVED_LOADER_NO_FINANCE'))
                scopes=[];result=entry.record_metadata_bindings(prep,lambda scope:(scope.validate_current(),scopes.append(scope)))
                self.assertEqual(len(scopes),15);self.assertTrue(result['metadata_scopes_revoked'])
                for scope in scopes:
                    with self.assertRaises(ValueError):scope.validate_current()
                with self.assertRaises(ValueError):entry.record_metadata_bindings(prep,None)
                with self.assertRaises(RuntimeError):entry.record_metadata_bindings(prep,lambda scope:(_ for _ in ()).throw(RuntimeError('GENERATED_STOP')))
                cell_id=entry.tranche_cells(entry.ALL15)[0]
                for path in (('cells',cell_id,'descriptor','recipe'),('cells',cell_id,'descriptor','year'),('cells',cell_id,'descriptor','tier'),
                    ('cells',cell_id,'input_binding','source_stage_GO_SHA256'),('cells',cell_id,'input_binding','source_review_SHA256'),
                    ('cells',cell_id,'input_binding','source_identity'),('cells',cell_id,'input_binding_SHA256'),
                    ('years','2024','array_identities','annual_covariance','dtype'),('years','2024','array_identities','annual_covariance','shape')):
                    bad=deepcopy(prep);obj=bad
                    for key in path[:-1]:obj=obj[key]
                    obj[path[-1]]='MUTATED'
                    with self.assertRaises(ValueError):entry.validate_preparation_metadata(c.canonical(bad))
                for target in ((),('years','2024'),('cells',cell_id)):
                    bad=deepcopy(prep);obj=bad
                    for key in target:obj=obj[key]
                    obj['financial_execution_authorized']=True
                    with self.assertRaises(ValueError):entry.validate_preparation_metadata(c.canonical(bad))
                for name in ('2024/TARGETS.npz','2022/MINUTE_MARK_PROVENANCE.json','SOURCE_INDEPENDENT_REVIEW.json'):
                    bad=dict(artifacts);bad[name]+=b'X'
                    with self.assertRaises(ValueError):loader.decode_saved(prep_raw,bad,2024)
                arrays,_=loader.decode_saved(prep_raw,artifacts,2024);changed={k:v.copy() for k,v in arrays.items()}
                changed[config.RECIPES[0]+'_LOW'][0,0]=np.nextafter(changed[config.RECIPES[0]+'_LOW'][0,0],1.)
                bad=dict(artifacts);bad['2024/TARGETS.npz']=generated.pack(**changed);changed_prep=deepcopy(prep)
                changed_prep['artifacts']['2024/TARGETS.npz']=dict(SHA256=c.sha(bad['2024/TARGETS.npz']),bytes=len(bad['2024/TARGETS.npz']))
                with self.assertRaisesRegex(ValueError,'RAW_BITS'):loader.decode_saved(c.canonical(changed_prep),bad,2024)
                self.assertFalse(entry._ACTIVE_SOURCE);self.assertFalse(entry._ACTIVE_RECORDING);self.assertFalse(loader._LIVE)
        finally:
            if output.exists():shutil.rmtree(output)

    def test_cli_stop_before_capture_and_invalid_CPU(self):
        import prepare_high365_source as cli
        output=c.HERE/'source_attempts'/'GENERATED_STOP_ONLY'
        if output.exists():raise AssertionError('EXCLUSIVE_GENERATED_OUTPUT_REQUIRED')
        try:
            with tempfile.TemporaryDirectory(dir=c.HERE) as td:
                go,gs,review,rs=generated.authority();td=Path(td);gp=td/'GENERATED_AUTHORIZATION.json';rp=td/'GENERATED_REVIEW.json'
                gp.write_bytes(go);rp.write_bytes(review)
                argv=['prepare_high365_source.py','--output',str(output),'--source-go',str(gp),'--source-go-sha',gs,
                    '--source-review',str(rp),'--source-review-sha',rs,'--cpu','0']
                with patch.object(sys,'argv',argv),patch.object(cli,'assign_source_cpu',side_effect=lambda cpu:self.assertEqual(cpu,0)),patch.object(cli.resource,'setrlimit'),patch.object(cli.signal,'signal'),patch.object(cli.signal,'alarm'),\
                    patch.object(source,'prepare_source_only',side_effect=ValueError('GENERATED_STOP_BEFORE_SOURCE')):
                    with self.assertRaisesRegex(ValueError,'GENERATED_STOP_BEFORE_SOURCE'):cli.main()
                stopped=c.exact_object((output/'STOP_SOURCE_TARGET_PREPARATION.json').read_bytes())
                self.assertTrue(stopped['source_scopes_revoked']);self.assertTrue(stopped['recording_scopes_revoked']);self.assertFalse(any(stopped['forbidden_attempts'].values()))
                with patch.object(sys,'argv',argv[:-1]+['6']):
                    with self.assertRaisesRegex(ValueError,'ASSIGNED_SOURCE_CPU'):cli.main()
        finally:
            if output.exists():shutil.rmtree(output)

    def test_code_dependencies_manifest_and_relative_paths_fail_closed(self):
        record=c.exact_object(c.ordinary(c.HERE/'CODE_MANIFEST.json'));target=next(iter(record['dependencies']));original=c.exact
        def exact(path,*args,**kwargs):
            if str(path)==str(c.ROOT/target):raise ValueError('GENERATED_DEPENDENCY_MUTATION')
            return original(path,*args,**kwargs)
        with patch.object(c,'exact',side_effect=exact):
            with self.assertRaisesRegex(ValueError,'DEPENDENCY_MUTATION'):entry.code_identity()
        with tempfile.TemporaryDirectory(dir=c.HERE) as td:
            td=Path(td);p=td/'x.py';p.write_bytes(b'x');link=td/'link';link.symlink_to(p)
            with self.assertRaises(ValueError):c.exact(link,c.sha(b'x'))
            with self.assertRaises(ValueError):c.exact(p,'0'*64)
            with self.assertRaises(ValueError):c.exact(p,c.sha(b'x'),99)
        for name in ('../escape','/abs','a/../b','a\\b','a//b'):
            with self.assertRaises(ValueError):c.relative(name)


class BoundaryTests(unittest.TestCase):
    def forbidden(self,fn,category):
        guard=SourceOnlyGuard(read_paths=generated.read_paths(),write_roots=(c.HERE/'GENERATED_WRITE_ONLY',))
        with self.assertRaises(SourceBoundaryViolation):
            with guard:fn(guard)
        self.assertGreater(guard.attempts[category],0)
        generated.observed_guard_receipts.append(guard.receipt('EXPECTED_NEGATIVE_CONTROL'))
        return guard

    def test_process_network_claim_and_financial_GO_write_blocks(self):
        import subprocess,socket,fcntl
        for fn,category in ((lambda g:subprocess.run(['false']),'process_launches'),
            (lambda g:os.system('false'),'process_launches'),
            (lambda g:socket.getaddrinfo('example.com',443),'network_calls'),
            (lambda g:fcntl.flock(0,fcntl.LOCK_EX),'canonical_financial_claims_or_leases'),
            (lambda g:(c.HERE/'EXECUTION_CLAIMS'/'x').open('w'),'canonical_financial_claims_or_leases'),
            (lambda g:(c.HERE/'GENERATED_WRITE_ONLY'/'FINANCIAL_GO.json').open('w'),'financial_GO_writes'),
            (lambda g:json.dumps(dict(schema='ROOT_FINANCIAL_AUTHORIZATION',financial_execution_authorized=True)),'financial_GO_writes'),
            (lambda g:(c.HERE/'not_allowlisted').read_bytes(),'nonallowlisted_file_reads')):
            self.forbidden(fn,category)

    def test_financial_import_direct_loader_and_foreign_CS_scope_blocks(self):
        for name in ('high365_native','run_high365','cs_entry','cs_admission','cs_loader','traditional_D_full2022_20261015_v2'):
            self.forbidden(lambda g,name=name:__import__(name),'financial_imports')
        self.forbidden(lambda g:importlib.util.spec_from_file_location('x','/tmp/x.py'),'financial_imports')

    def test_preloaded_captured_finance_provider_and_historical_scope_stop(self):
        for name in ('FakeAccount','FakeSimulator','FakeProvider','FreshHistoricalExecutionScope'):
            fake=types.ModuleType('_generated_boundary');fake.__source_guard_fixture__=True
            setattr(fake,name,type(name,(),{}));sys.modules[fake.__name__]=fake
            try:
                self.forbidden(lambda g:None,'financial_imports')
            finally:sys.modules.pop(fake.__name__,None)

    def test_dynamic_constructor_advance_provider_historical_and_simulator_blockers(self):
        # Register fixture only after clean entry; no actual implementation imported.
        fake=types.ModuleType('_generated_boundary');fake.__source_guard_fixture__=True
        for name,method,category in (('FakeAccount','__init__','financial_constructors'),
            ('FakeAccount','advance_day','financial_account_advance'),
            ('FakeSimulator','__init__','native_simulator_construct_or_advance'),
            ('FakeProvider','__iter__','actual_provider_calls'),
            ('FreshHistoricalExecutionScope','__init__','historical_scope_mints')):
            cls=type(name,(),{method:lambda *a,**k:None});setattr(fake,name,cls)
            def attempt(guard):
                sys.modules[fake.__name__]=fake
                guard._discover_loaded_boundaries()
                getattr(cls,method)(object())
            try:self.forbidden(attempt,category)
            finally:
                sys.modules.pop(fake.__name__,None);delattr(fake,name)

    def test_caught_attempt_remains_fatal_and_scope_mints_stay_zero(self):
        def attempt(guard):
            try:__import__('high365_native')
            except SourceBoundaryViolation:pass
        self.forbidden(attempt,'financial_imports')
        self.assertFalse(entry._ACTIVE_SOURCE);self.assertFalse(entry._ACTIVE_RECORDING);self.assertFalse(loader._LIVE)


class AdditionalGuardWriteTests(unittest.TestCase):
    def test_arbitrary_financial_content_chunked_writer_and_outside_writes_block(self):
        with tempfile.TemporaryDirectory(dir=c.HERE) as td:
            td=Path(td)
            guard=SourceOnlyGuard(read_paths=generated.read_paths(),write_roots=(td,))
            with self.assertRaises(SourceBoundaryViolation):
                with guard:
                    with (td/'innocent.txt').open('wb') as stream:
                        stream.write(b'{"financial_execution_authorized":')
                        stream.write(b'true}')
            self.assertEqual(guard.attempts['financial_GO_writes'],1)
            generated.observed_guard_receipts.append(guard.receipt('EXPECTED_NEGATIVE_CHUNKED_FINANCIAL_CONTENT_WRITE'))
            # No complete executable financial JSON was ever written.
            self.assertEqual((td/'innocent.txt').read_bytes(),b'{"financial_execution_authorized":')
            guard=SourceOnlyGuard(read_paths=generated.read_paths(),write_roots=(td,))
            with self.assertRaises(SourceBoundaryViolation):
                with guard:(c.HERE/'OUTSIDE_GENERATED_ROOT.txt').open('w')
            self.assertEqual(guard.attempts['outside_source_writes'],1)
            generated.observed_guard_receipts.append(guard.receipt('EXPECTED_NEGATIVE_OUTSIDE_OR_RAW_WRITE'))
            guard=SourceOnlyGuard(read_paths=generated.read_paths(),write_roots=(td,))
            with self.assertRaises(SourceBoundaryViolation):
                with guard:os.open(td/'raw',os.O_WRONLY|os.O_CREAT)
            self.assertEqual(guard.attempts['outside_source_writes'],1)
            generated.observed_guard_receipts.append(guard.receipt('EXPECTED_NEGATIVE_OUTSIDE_OR_RAW_WRITE'))



if __name__=='__main__':unittest.main()
