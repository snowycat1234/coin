"""Bounded exact original supplied-prefix selector; no paths, providers or finance.

Only the selected original NPZ member is opened. Only its source clock, ordered
symbols and completed-close prefix are interpreted. Other members/arrays and
future close rows are never decoded into arrays. Source admission is external.
"""
from io import BytesIO
import stat
import zipfile
import numpy as np
import high365_common as c
import high365_config as config
import high365_signal as signal

MAX_ROWS=4096


def header(stream):
    version=np.lib.format.read_magic(stream)
    if version not in ((1,0),(2,0)):raise ValueError('SUPPORTED_ORIGINAL_NPY_HEADER_REQUIRED')
    reader=np.lib.format.read_array_header_1_0 if version==(1,0) else np.lib.format.read_array_header_2_0
    shape,fortran,dtype=reader(stream,max_header_size=4096)
    if fortran or dtype.fields is not None or dtype.subdtype is not None or dtype.hasobject:
        raise ValueError('PLAIN_C_ORDER_ORIGINAL_PREFIX_NPY_REQUIRED')
    return shape,dtype


def archive(raw):
    if type(raw) is not bytes:raise ValueError('EXACT_ORIGINAL_SOURCE_CONTAINER_BYTES_REQUIRED')
    z=zipfile.ZipFile(BytesIO(raw));items=z.infolist();names=[i.filename for i in items]
    if len(names)!=len(set(names)) or any(i.is_dir() or i.flag_bits&1 or stat.S_ISLNK(i.external_attr>>16) or '/' in i.filename or '\\' in i.filename for i in items):
        z.close();raise ValueError('FLAT_UNIQUE_ORDINARY_ORIGINAL_MEMBERS_REQUIRED')
    return z


def select_prefix(wrapper_raw,contract,year):
    period=config.source_year(year)
    if c.sha(wrapper_raw)!=contract['wrapper']['SHA256'] or len(wrapper_raw)!=contract['wrapper']['bytes']:
        raise ValueError('EXACT_ORIGINAL_SMALL_WRAPPER_REQUIRED')
    with archive(wrapper_raw) as wrapper:
        pin=contract['member'];name=pin['name']
        if name not in wrapper.namelist() or wrapper.getinfo(name).file_size!=pin['bytes']:
            raise ValueError('EXACT_ORIGINAL_SELECTED_CUBE_MEMBER_REQUIRED')
        member_raw=wrapper.read(name)
    if c.sha(member_raw)!=pin['SHA256']:raise ValueError('EXACT_ORIGINAL_SELECTED_CUBE_BYTES_REQUIRED')
    with archive(member_raw) as z:
        selected={'symbol_order.npy','close_available_us.npy','close.npy'}
        if not selected<=set(z.namelist()):raise ValueError('ORIGINAL_SOURCE_FIELDS_REQUIRED')
        with z.open('symbol_order.npy') as f:
            shape,dtype=header(f)
            if shape!=(5,) or dtype.kind!='U' or not 0<dtype.itemsize<=128:raise ValueError('EXACT_ORIGINAL_SYMBOL_ORDER_HEADER_REQUIRED')
            raw=f.read(5*dtype.itemsize)
            if len(raw)!=5*dtype.itemsize or f.read(1):raise ValueError('EXACT_ORIGINAL_SYMBOL_PAYLOAD_REQUIRED')
            order=tuple(np.frombuffer(raw,dtype=dtype))
            if order!=config.SYMBOLS:raise ValueError('EXACT_ORIGINAL_ORDERED_CORE5_REQUIRED')
        clocks=[];last=period['end']-config.DAY;boundary_clock=None
        with z.open('close_available_us.npy') as f:
            shape,dtype=header(f)
            if len(shape)!=1 or not 1<=shape[0]<=MAX_ROWS or dtype!=np.dtype('int64'):
                raise ValueError('BOUNDED_ORIGINAL_INT64_CLOCK_HEADER_REQUIRED')
            stored_rows=shape[0]
            if z.getinfo('close_available_us.npy').file_size!=f.tell()+stored_rows*8:raise ValueError('EXACT_ORIGINAL_CLOCK_MEMBER_LENGTH_REQUIRED')
            for _ in range(stored_rows):
                raw=f.read(8)
                if len(raw)!=8:raise ValueError('EXACT_ORIGINAL_CLOCK_PAYLOAD_REQUIRED')
                at=int(np.frombuffer(raw,dtype=np.int64)[0])
                if at>last:
                    boundary_clock=at;break
                clocks.append(at)
        t=np.asarray(clocks,dtype=np.int64)
        if (len(t)<period['days']+199 or t[0]<config.utc('2020-01-01') or t[-1]!=last
                or np.any(t%config.DAY) or np.any(np.diff(t)!=config.DAY)
                or period['start'] not in t):raise ValueError('COMPLETE_UNSHORTENED_ORIGINAL_CAUSAL_PREFIX_COVERAGE_REQUIRED')
        first_rank=1704067200000000+(period['start']-1704067200000000)//(7*config.DAY)*(7*config.DAY)
        if t[0]>first_rank-364*config.DAY:
            raise ValueError('HIGH365_OWNING_RANK_SOURCE_CLOCK_COVERAGE_REQUIRED_BEFORE_CLOSE_PAYLOAD')
        with z.open('close.npy') as f:
            shape,dtype=header(f)
            if shape!=(stored_rows,5) or dtype!=np.dtype('float64'):raise ValueError('EXACT_ORIGINAL_FLOAT64_CLOSE_HEADER_REQUIRED')
            if z.getinfo('close.npy').file_size!=f.tell()+stored_rows*5*8:raise ValueError('EXACT_ORIGINAL_CLOSE_MEMBER_LENGTH_REQUIRED')
            size=len(t)*5*8;raw=f.read(size)
            if len(raw)!=size:raise ValueError('EXACT_CAUSAL_CLOSE_PREFIX_PAYLOAD_REQUIRED')
            p=np.frombuffer(raw,dtype=np.float64).reshape(len(t),5)
            # No read of any remaining close payload. Original early unavailable
            # assets are retained exactly; only selected200-close windows must
            # pass original admission in build_target_grid().
    return dict(clocks=signal.immutable_array(t),close=signal.immutable_array(p)),dict(
        schema='EXACT_ORIGINAL_CAUSAL_SUPPLIED_PREFIX_SELECTION_V1',year=year,
        original_wrapper_SHA256=contract['wrapper']['SHA256'],original_member_SHA256=pin['SHA256'],
        original_member_name=pin['name'],stored_rows=stored_rows,selected_rows=len(t),
        first_source_clock_us=int(t[0]),last_source_clock_us=int(t[-1]),
        first_excluded_clock_us=boundary_clock,prefix_first_row_retained=True,
        source_fields=['symbol_order','close_available_us','close'],
        unselected_numerical_arrays_interpreted=False,future_close_rows_interpreted=0,
        clock_identity=signal.array_byte_identity(t),close_identity=signal.array_byte_identity(p),
        source_admitted=False,financial_authorized=False)


def validate_canonical_parity(prefix,canonical):
    t=prefix['clocks'];p=prefix['close'];ct=canonical['clocks'];cp=canonical['close'];ids=np.searchsorted(t,ct)
    if np.any(ids>=len(t)) or not np.array_equal(t[ids],ct):raise ValueError('EXACT_FULL_PREFIX_CANONICAL_SOURCE_CLOCK_PARITY_REQUIRED')
    if p[ids].tobytes()!=cp.tobytes():raise ValueError('EXACT_FULL_PREFIX_CANONICAL_COMPLETED_CLOSE_BITS_REQUIRED')
    return True
