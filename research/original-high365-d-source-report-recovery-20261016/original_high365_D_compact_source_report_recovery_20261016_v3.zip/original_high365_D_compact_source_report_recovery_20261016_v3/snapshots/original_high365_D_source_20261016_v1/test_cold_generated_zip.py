"""Fresh-process ASCII flag0 DEFLATED NPZ and literal BOM decoder regression."""
import argparse
import sys


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--expect-cold-stop',action='store_true')
    args=parser.parse_args()
    cold='encodings.cp437' not in sys.modules
    if not cold:raise AssertionError('FRESH_PROCESS_COLD_CP437_REQUIRED')
    if not args.expect_cold_stop:
        import prepare_high365_source  # Exact production entry preload, before guard.
    from io import BytesIO
    import json
    import zipfile
    import numpy as np
    import high365_codec as codec
    import high365_generated as generated
    from high365_source_guard import SourceOnlyGuard
    data=BytesIO();array=BytesIO();np.save(array,np.ones(4,dtype='float64'),allow_pickle=False)
    info=zipfile.ZipInfo('x.npy');info.compress_type=zipfile.ZIP_DEFLATED
    with zipfile.ZipFile(data,'w') as archive:archive.writestr(info,array.getvalue())
    guard=SourceOnlyGuard(read_paths=generated.read_paths())
    done=False;error=None
    try:
        with guard:
            a=codec.npz(data.getvalue(),{'x':((4,),'float64')})
            assert a['x'].tobytes()==np.ones(4).tobytes()
            # Literal bytes, so constructing fixture never prewarms utf_8_sig.
            assert b'\xef\xbb\xbf2023,1\n'.decode('utf-8-sig')=='2023,1\n'
            done=True
    except BaseException as exc:error=type(exc).__name__+':'+str(exc)
    if args.expect_cold_stop:
        assert not done and guard.attempts['financial_imports']==1,(done,guard.attempts,error)
        assert all(v==0 for k,v in guard.attempts.items() if k!='financial_imports')
    else:assert done and error is None and not any(guard.attempts.values()),(done,guard.attempts,error)
    print(json.dumps(dict(schema='HIGH365_FRESH_GENERATED_ASCII_FLAG0_DEFLATED_ZIP_AND_BOM_CODEC_V1',
        status='PASS',expected_cold_stop=args.expect_cold_stop,cp437_initially_cold=cold,
        parser_completed=done,ZIP_member_flag_bits=info.flag_bits,ZIP_compression=info.compress_type,
        forbidden_attempts=guard.attempts,error=error,actual_source_reads=0,actual_source_scopes=0,
        financial_runs=0),indent=2))


if __name__=='__main__':main()
