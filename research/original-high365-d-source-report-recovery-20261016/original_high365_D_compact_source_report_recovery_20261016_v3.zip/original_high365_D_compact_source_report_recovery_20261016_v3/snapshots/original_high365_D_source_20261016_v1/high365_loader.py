"""Exact saved new-high365 input reader; no finance import, token or recapture."""
from dataclasses import dataclass,field
from pathlib import Path
from types import MappingProxyType
import numpy as np
import high365_common as c
import high365_codec as codec
import high365_config as config
import high365_entry as entry
import high365_signal as signal
import high365_source as source
_SEAL=object();_LIVE={}


def decode_saved(preparation_raw,artifacts,year):
    config.source_year(year);prep=entry.validate_preparation_metadata(preparation_raw)
    if type(artifacts) is not dict or set(artifacts)!=set(prep['artifacts']):
        raise ValueError('EXACT_SAVED_ARTIFACT_NAMESPACE_REQUIRED')
    for name,raw in artifacts.items():
        pin=prep['artifacts'][name]
        if type(raw) is not bytes or c.sha(raw)!=pin['SHA256'] or len(raw)!=pin['bytes']:
            raise ValueError('EXACT_SAVED_SOURCE_TARGET_ARTIFACT_BYTES_REQUIRED')
    prefix=str(year)+'/';arrays=codec.npz(artifacts[prefix+'TARGETS.npz'],entry.array_specs(year))
    for key,value in arrays.items():
        if not np.isfinite(value).all() or c.canonical(signal.array_byte_identity(value))!=c.canonical(prep['years'][str(year)]['array_identities'][key]):
            raise ValueError('EXACT_FINITE_TARGET_DTYPE_ENDIAN_SHAPE_RAW_BITS_REQUIRED')
    contract=entry.contracts()['years'][str(year)]
    captured=source.decode_capture(year,{name:artifacts[prefix+name] for name in contract['artifacts']},contract)
    if (arrays['decision_us'].tobytes()!=captured['decisions'].tobytes()
            or c.canonical(c.object_json(artifacts[prefix+'SOURCE_ROWS.json']))!=c.canonical(captured['source_rows'])):
        raise ValueError('EXACT_SAVED_CALENDAR_SOURCE_ROW_PARITY_REQUIRED')
    proof=entry.checked_prefix_metadata(prep['years'][str(year)]['target_prefix_metadata'],year)
    selected=codec.npz(artifacts[prefix+'SOURCE_PREFIX_INPUTS.npz'],dict(close_available_us=((proof['selected_rows'],),'int64'),close=((proof['selected_rows'],5),'float64')))
    for key,value in selected.items():
        identity=proof['clock_identity' if key=='close_available_us' else 'close_identity']
        if c.canonical(signal.array_byte_identity(value))!=c.canonical(identity):raise ValueError('EXACT_SAVED_ORIGINAL_PREFIX_RAW_BITS_REQUIRED')
    from high365_prefix import validate_canonical_parity
    validate_canonical_parity(dict(clocks=selected['close_available_us'],close=selected['close']),captured)
    return arrays,dict(close_available_us=captured['clocks'],close=captured['close'])


@dataclass(frozen=True,slots=True)
class LoadedHigh365Inputs:
    year:int
    preparation_raw:bytes=field(repr=False)
    arrays:object=field(repr=False)
    source_arrays:object=field(repr=False)
    captured_artifacts:object=field(repr=False)
    _token:object=field(repr=False)
    _seal:object=field(repr=False)
    def __post_init__(self):
        if self._seal is not _SEAL:raise ValueError('ENTRY_OWNED_SOURCE_ONLY_LOADED_HIGH365_INPUTS_REQUIRED')
    def validate(self):
        if _LIVE.get(self._token) is not self:raise ValueError('LIVE_SOURCE_ONLY_LOADED_HIGH365_INPUTS_REQUIRED')
        arrays,inputs=decode_saved(self.preparation_raw,dict(self.captured_artifacts),self.year)
        for original,checked in ((self.arrays,arrays),(self.source_arrays,inputs)):
            if set(original)!=set(checked):raise ValueError('EXACT_LOADED_ARRAY_NAMESPACE_REQUIRED')
            for key,value in original.items():
                if value.flags.writeable or c.canonical(signal.array_byte_identity(value))!=c.canonical(signal.array_byte_identity(checked[key])):
                    raise ValueError('EXACT_IMMUTABLE_DTYPE_ENDIAN_SHAPE_CBYTES_REQUIRED')
        return True


def load_year(preparation_root,*,expected_preparation_sha256,year,source_go_raw,expected_source_go_sha256,source_review_raw,expected_source_review_sha256):
    config.source_year(year)
    entry.validate_source_authority_metadata(source_go_raw,expected_source_go_sha256,source_review_raw,expected_source_review_sha256)
    from high365_source_guard import current_guard
    guard=current_guard()
    if guard is None or not guard.active:raise ValueError('WHOLE_INVOCATION_HIGH365_SOURCE_ONLY_GUARD_REQUIRED')
    root=Path(preparation_root).absolute()
    if root.is_symlink() or any(p.is_symlink() for p in root.parents):raise ValueError('ORDINARY_NOFOLLOW_PREPARATION_DIRECTORY_REQUIRED')
    raw=c.exact(root/'PREPARATION.json',expected_preparation_sha256);prep=entry.validate_preparation_metadata(raw)
    if prep['source_stage_GO_SHA256']!=expected_source_go_sha256 or prep['source_review_SHA256']!=expected_source_review_sha256:
        raise ValueError('EXACT_EXTERNAL_FRESH_HIGH365_SOURCE_LINEAGE_REQUIRED')
    artifacts={name:c.exact(root/c.relative(name),pin['SHA256'],pin['bytes']) for name,pin in prep['artifacts'].items()}
    if artifacts['SOURCE_STAGE_AUTHORIZATION.json']!=source_go_raw or artifacts['SOURCE_INDEPENDENT_REVIEW.json']!=source_review_raw:
        raise ValueError('EXACT_SOURCE_GO_REVIEW_BODY_BINDING_REQUIRED')
    arrays,inputs=decode_saved(raw,artifacts,year);token=object()
    loaded=LoadedHigh365Inputs(year,raw,MappingProxyType(arrays),MappingProxyType(inputs),MappingProxyType(artifacts),token,_SEAL);_LIVE[token]=loaded
    try:loaded.validate()
    except BaseException:_LIVE.pop(token,None);raise
    return loaded


def revoke(loaded):
    if type(loaded) is not LoadedHigh365Inputs or _LIVE.get(loaded._token) is not loaded:raise ValueError('LIVE_SOURCE_ONLY_LOADED_HIGH365_INPUTS_REQUIRED')
    _LIVE.pop(loaded._token)
