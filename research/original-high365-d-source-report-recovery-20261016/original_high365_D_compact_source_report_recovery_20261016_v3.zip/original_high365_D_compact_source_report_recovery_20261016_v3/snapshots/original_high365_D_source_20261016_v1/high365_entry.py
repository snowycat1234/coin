"""Separate high365 source-only authority. No financial constructor or token exists.

Validators are pure metadata checks. An actual source scope additionally needs a
fresh exact review, a fresh root source GO, and the whole-invocation source guard.
The frozen FIRST6 is excluded; actual all15 capture remains fresh-GO-gated.
"""
from contextlib import contextmanager
from dataclasses import dataclass, field
import high365_common as c
import high365_config as config

ALL15 = 'ALL15_FIVE_DEV_PERIODS_SINGLE_ORIGINAL_HIGH365_ALL_THREE_TIERS'
SOURCE_SCHEMA = 'ROOT_SOURCE_TARGET_HIGH365_INTRINSIC_ALL15_V1'
SOURCE_REVIEW_SCHEMA = 'INDEPENDENT_HIGH365_INTRINSIC_ALL15_SOURCE_GENERATED_REVIEW_V1'
PREPARATION_SCHEMA = 'PREPARED_HIGH365_INTRINSIC_ALL15_SOURCE_TARGET_ONLY_V1'
MANIFEST_NAME = 'FROZEN_FIFTEEN_CELL_MANIFEST.json'
_PURE_CODE_SHA = '2423efc89fb0002c62dc44623c4cf290eb932717f9c782b16e5ed7164ca5811d'
_SOURCE_SEAL, _RECORD_SEAL = object(), object()
_ACTIVE_SOURCE, _ACTIVE_RECORDING = {}, set()


def manifest():
    value = c.exact_object(c.ordinary(c.HERE / MANIFEST_NAME))
    fixed = dict(schema=config.VERSION, candidate=config.CANDIDATE, cell_count=15,
        cells=list(config.cells()),source_checkpoint=ALL15,
        source_enabled_cells=[cell['cell_id'] for cell in config.cells() if True],
        first6_source_entry_enabled=False,financial_entry_implemented=False,
        original_execution_replication=False,financial_reuse_allowed=False)
    if c.canonical(value) != c.canonical(fixed):
        raise ValueError('EXACT_FROZEN_HIGH365_FIFTEEN_CELL_MANIFEST_REQUIRED')
    return value


def manifest_sha():
    manifest()
    return c.sha(c.ordinary(c.HERE / MANIFEST_NAME))


def tranche_cells(tranche):
    if tranche != ALL15:
        raise ValueError('ONLY_ALL15_EXACT_FIVE_PERIOD_HIGH365_SOURCE_CHECKPOINT_ENABLED')
    return tuple(cell['cell_id'] for cell in config.cells() if True)


def tranche_years(tranche):
    tranche_cells(tranche)
    return tuple(dict.fromkeys(cell['year'] for cell in config.cells() if True))


def contracts():
    raw = c.ordinary(c.HERE/'SOURCE_CONTRACT_MAP.json')
    value = c.exact_object(raw)
    if (set(value.get('years',{})) != {'2021','2022','2023','2024','2025'}
            or value.get('schema') != 'ORIGINAL_HIGH365_ALL15_SAVED_SOURCE_CAPTURE_MAP_V1'):
        raise ValueError('EXACT_SEPARATE_ALL15_FIVE_PERIOD_SOURCE_CONTRACT_REQUIRED')
    # CODE_MANIFEST binds this file's exact bytes before admission.
    return value


def contract_sha():
    contracts()
    return c.sha(c.ordinary(c.HERE/'SOURCE_CONTRACT_MAP.json'))


def code_identity():
    raw = c.ordinary(c.HERE/'CODE_MANIFEST.json')
    record = c.exact_object(raw)
    if record.get('schema') != 'HIGH365_INTRINSIC_SOURCE_ONLY_CODE_IDENTITY_V1':
        raise ValueError('EXACT_HIGH365_SOURCE_CODE_MANIFEST_REQUIRED')
    for name,pin in record['files'].items():
        c.exact(c.HERE/c.relative(name),pin['SHA256'],pin['bytes'])
    pins = c.exact_object(c.ordinary(c.HERE/'DEPENDENCY_PINS.json'))['files']
    if c.canonical(record['dependencies']) != c.canonical(pins):
        raise ValueError('EXACT_REVIEWED_HIGH365_SOURCE_DEPENDENCIES_REQUIRED')
    for name,pin in pins.items():
        path=c.ROOT/c.relative(name)
        if path.suffix not in ('.py','.json','.md','.txt'):
            raise ValueError('CODE_METADATA_DEPENDENCY_ONLY')
        c.exact(path,pin['SHA256'],pin['bytes'])
    return c.sha(raw)


def review_policy(tranche):
    return dict(schema=SOURCE_REVIEW_SCHEMA,status='PASS',candidate=config.CANDIDATE,
        adaptation_version=config.VERSION,tranche=tranche,ordered_cells=list(tranche_cells(tranche)),
        years=list(tranche_years(tranche)),code_manifest_SHA256=code_identity(),
        scope_manifest_SHA256=manifest_sha(),source_contract_map_SHA256=contract_sha(),
        pure_signal_code_manifest_SHA256=_PURE_CODE_SHA,I01_unsupported_dtype_gate_reviewed=True,
        source_native_financial_approval=False,old_CS_core_D_or_high365_baseline_authority_reused=False)


def source_policy(tranche,review_sha):
    return dict(schema=SOURCE_SCHEMA,status='APPROVED_SOURCE_TARGET_ONLY',
        action='PREPARE_EXACT_'+tranche+'_HIGH365_SOURCE_TARGETS_ONLY',
        candidate=config.CANDIDATE,adaptation_version=config.VERSION,tranche=tranche,
        ordered_cells=list(tranche_cells(tranche)),years=list(tranche_years(tranche)),
        code_manifest_SHA256=code_identity(),scope_manifest_SHA256=manifest_sha(),
        source_contract_map_SHA256=contract_sha(),independent_review_SHA256=c.digest(review_sha),
        pure_signal_code_manifest_SHA256=_PURE_CODE_SHA,
        source_identities={str(year):contracts()['years'][str(year)]['source_identity'] for year in tranche_years(tranche)},
        canonical_source_capture_authorized=True,target_generation_authorized=True,
        first6_cells_source_authorized=False,old_CS_core_D_or_high365_baseline_authority_reused=False,
        historical_execution_authorized=False,financial_execution_authorized=False,
        account_construction_authorized=False,provider_iteration_authorized=False,
        process_launch_authorized=False,canonical_claims_authorized=False,
        financial_GO_authorized=False,publication_authorized=False,downloads_authorized=False,
        source_limits=dict(CPU=0,CPU_seconds=900,wall_seconds=1800,AS_bytes=3000000000,
            output_bytes=1073741824,process_count=1,numerical_pools=1))


def validate_source_authority_metadata(go_raw,expected_go_sha256,review_raw,expected_review_sha256):
    go=c.checked_external(go_raw,expected_go_sha256)
    review=c.checked_external(review_raw,expected_review_sha256)
    if go.get('tranche') != ALL15:
        raise ValueError('ONLY_ALL15_EXACT_FIVE_PERIOD_HIGH365_SOURCE_CHECKPOINT_ENABLED')
    if c.canonical(review) != c.canonical(review_policy(ALL15)):
        raise ValueError('EXACT_NEW_INDEPENDENT_HIGH365_SOURCE_REVIEW_REQUIRED')
    if c.canonical(go) != c.canonical(source_policy(ALL15,expected_review_sha256)):
        raise ValueError('EXACT_NEW_ROOT_HIGH365_SOURCE_ONLY_AUTHORITY_REQUIRED')
    return c.immutable(dict(policy=go,root_go_SHA256=expected_go_sha256,review_SHA256=expected_review_sha256))


@dataclass(frozen=True,slots=True)
class High365SourcePreparationScope:
    tranche:str
    source_go_sha256:str
    review_sha256:str
    raw_go:bytes=field(repr=False)
    raw_review:bytes=field(repr=False)
    _code:str=field(repr=False)
    _token:object=field(repr=False)
    _seal:object=field(repr=False)

    def __post_init__(self):
        if self._seal is not _SOURCE_SEAL:
            raise ValueError('FRESH_SEPARATE_HIGH365_SOURCE_SCOPE_SEAL_REQUIRED')

    def validate_current(self,*,year=None):
        if _ACTIVE_SOURCE.get(self._token) is not self or self._code != code_identity():
            raise ValueError('LIVE_CURRENT_HIGH365_SOURCE_SCOPE_REQUIRED')
        validate_source_authority_metadata(self.raw_go,self.source_go_sha256,self.raw_review,self.review_sha256)
        if year is not None:
            config.source_year(year)
        from high365_source_guard import current_guard
        guard=current_guard()
        if guard is None or not guard.active:
            raise ValueError('WHOLE_INVOCATION_HIGH365_SOURCE_ONLY_GUARD_REQUIRED')
        guard.checkpoint('SOURCE_SCOPE_CHECK')
        return True

    def read_source(self,year,name,expected_sha256,expected_bytes=None):
        self.validate_current(year=year)
        name=c.relative(name)
        pin=contracts()['years'][str(year)]['read_files'].get(name)
        if (pin is None or pin['SHA256'] != expected_sha256
                or expected_bytes is not None and (type(expected_bytes) is not int or expected_bytes != pin['bytes'])):
            raise ValueError('EXACT_HIGH365_QUALIFIED_SAVED_SOURCE_READ_ALLOWLIST_REQUIRED')
        return c.exact(c.ROOT/name,expected_sha256,pin['bytes'])


@contextmanager
def admit_source_stage(go_raw,expected_go_sha256,review_raw,expected_review_sha256):
    value=validate_source_authority_metadata(go_raw,expected_go_sha256,review_raw,expected_review_sha256)
    from high365_source_guard import current_guard
    guard=current_guard()
    if guard is None or not guard.active:
        raise ValueError('WHOLE_INVOCATION_HIGH365_SOURCE_ONLY_GUARD_REQUIRED')
    token=object()
    scope=High365SourcePreparationScope(value['policy']['tranche'],expected_go_sha256,expected_review_sha256,
        go_raw,review_raw,code_identity(),token,_SOURCE_SEAL)
    _ACTIVE_SOURCE[token]=scope
    try:
        scope.validate_current()
        yield scope
    finally:
        _ACTIVE_SOURCE.pop(token,None)


def array_specs(year):
    days=config.source_year(year)['days']
    return dict(decision_us=((days,),'int64'),annual_covariance=((days,5,5),'float64'),
        **{'intrinsic_'+recipe:((days,5),'float64') for recipe in config.RECIPES},
        **{name:((days,5),'float64') for name in ('HIGH365_ORIGINAL','HOLD_ORIGINAL')},
        HIGH365_CURRENT_ELIGIBLE=((days,5),'bool'),
        **{recipe+'_'+tier:((days,5),'float64') for recipe in config.RECIPES for tier in config.TIERS})


def checked_array_identities(identities,year):
    import numpy as np
    if type(identities) is not dict or set(identities) != set(array_specs(year)):
        raise ValueError('EXACT_INTRINSIC_TARGET_COVARIANCE_ARRAY_NAMESPACE_REQUIRED')
    for key,(shape,dtype) in array_specs(year).items():
        identity=identities[key]
        if (type(identity) is not dict or set(identity) != {'dtype','shape','order','raw_bytes_SHA256','descriptor_and_bytes_SHA256'}
                or identity['dtype'] != np.dtype(dtype).str or identity['shape'] != list(shape) or identity['order']!='C'):
            raise ValueError('EXACT_PLAIN_DTYPE_ENDIAN_SHAPE_CBYTES_ARRAY_IDENTITY_REQUIRED')
        c.digest(identity['raw_bytes_SHA256']);c.digest(identity['descriptor_and_bytes_SHA256'])
    return identities


def checked_prefix_metadata(value,year):
    import numpy as np
    period=config.source_year(year);pc=contracts()['years'][str(year)]['original_target_prefix']
    fields={'schema','year','original_wrapper_SHA256','original_member_SHA256','original_member_name','stored_rows','selected_rows',
        'first_source_clock_us','last_source_clock_us','first_excluded_clock_us','prefix_first_row_retained','source_fields',
        'unselected_numerical_arrays_interpreted','future_close_rows_interpreted','clock_identity','close_identity','source_admitted','financial_authorized'}
    if (type(value) is not dict or set(value)!=fields or value['schema']!='EXACT_ORIGINAL_CAUSAL_SUPPLIED_PREFIX_SELECTION_V1'
        or type(value['year']) is not int or value['year']!=year
        or value['original_wrapper_SHA256']!=pc['wrapper']['SHA256'] or value['original_member_SHA256']!=pc['member']['SHA256']
        or value['original_member_name']!=pc['member']['name'] or type(value['stored_rows']) is not int
        or type(value['selected_rows']) is not int or not period['days']+199<=value['selected_rows']<=value['stored_rows']<=4096
        or type(value['first_source_clock_us']) is not int or value['first_source_clock_us']<config.utc('2020-01-01')
        or value['last_source_clock_us']!=period['end']-config.DAY
        or value['last_source_clock_us']-value['first_source_clock_us']!=(value['selected_rows']-1)*config.DAY
        or value['prefix_first_row_retained'] is not True
        or value['source_fields']!=['symbol_order','close_available_us','close']
        or value['unselected_numerical_arrays_interpreted'] is not False or value['future_close_rows_interpreted']!=0
        or value['source_admitted'] is not False or value['financial_authorized'] is not False):
        raise ValueError('EXACT_ORIGINAL_FULL_CAUSAL_PREFIX_SELECTION_METADATA_REQUIRED')
    first_rank=1704067200000000+(period['start']-1704067200000000)//(7*config.DAY)*(7*config.DAY)
    if value['first_source_clock_us']>first_rank-364*config.DAY:
        raise ValueError('HIGH365_OWNING_RANK_UNSHORTENED_SOURCE_PREFIX_REQUIRED')
    if value['first_excluded_clock_us'] is not None and (type(value['first_excluded_clock_us']) is not int or value['first_excluded_clock_us']<=value['last_source_clock_us']):
        raise ValueError('EXACT_ORIGINAL_CLOCK_PREFIX_BOUNDARY_REQUIRED')
    for key,shape,dtype in (('clock_identity',[value['selected_rows']],'int64'),('close_identity',[value['selected_rows'],5],'float64')):
        identity=value[key]
        if (type(identity) is not dict or set(identity)!={'dtype','shape','order','raw_bytes_SHA256','descriptor_and_bytes_SHA256'}
            or identity['dtype']!=np.dtype(dtype).str or identity['shape']!=shape or identity['order']!='C'):
            raise ValueError('EXACT_ORIGINAL_PREFIX_ARRAY_IDENTITY_REQUIRED')
        c.digest(identity['raw_bytes_SHA256']);c.digest(identity['descriptor_and_bytes_SHA256'])
    return value


def binding_from_info(cell,info,source_go_sha,source_review_sha):
    if cell.get('cell_id') not in tranche_cells(ALL15) or c.canonical(cell)!=c.canonical(config.cell_named(cell['cell_id'])):
        raise ValueError('EXACT_ALL15_HIGH365_CELL_DESCRIPTOR_REQUIRED')
    contract=contracts()['years'][str(cell['year'])]; key=cell['recipe']+'_'+cell['tier']
    identities=checked_array_identities(info['array_identities'],cell['year'])
    return dict(schema='EXACT_HIGH365_INTRINSIC_CELL_SOURCE_TARGET_BINDING_V1',
        cell_id=cell['cell_id'],recipe=cell['recipe'],adaptation_version=config.VERSION,
        year=cell['year'],tier=cell['tier'],calendar=[cell['start_us'],cell['end_exclusive_us']],
        code_manifest_SHA256=code_identity(),scope_manifest_SHA256=manifest_sha(),
        source_contract_map_SHA256=contract_sha(),source_identity=contract['source_identity'],
        source_contract_SHA256=c.jsha(contract),pure_signal_code_manifest_SHA256=_PURE_CODE_SHA,
        source_stage_GO_SHA256=c.digest(source_go_sha),source_review_SHA256=c.digest(source_review_sha),
        source_rows_SHA256=info['source_rows_SHA256'],funding_events_SHA256=info['funding_events_SHA256'],
        source_inputs_SHA256=info['source_inputs_SHA256'],
        source_quality_sidecar_SHA256=info['source_quality_sidecar_SHA256'],quality_cells_SHA256=contract['source_metadata']['quality_cells_SHA256'],
        provider_months=[[rec['path'],rec['start'],rec['count'],rec['hash'],rec['size'],rec['lo'],rec['hi']] for rec in contract['qualified_source_contract']['months']],
        decision_identity=identities['decision_us'],covariance_identity=identities['annual_covariance'],
        original_intrinsic_identity=identities['intrinsic_'+cell['recipe']],selected_target_identity=identities[key],
        target_prefix_metadata=checked_prefix_metadata(info['target_prefix_metadata'],cell['year']),
        preserves_complete_original_intrinsic_signal=True,downward_only=True,
        original_execution_unchanged=False,financial_reuse_allowed=False,
        cost='BASE27',policy_variant='GUARD50_EXIT_ONLY')


def year_metadata(year):
    period=config.source_year(year);contract=contracts()['years'][str(year)]
    original=contract['source_metadata']
    return dict(source_identity=contract['source_identity'],source_contract_SHA256=c.jsha(contract),
        days=period['days'],calendar=[period['start'],period['end']],
        quality_cells_SHA256=original['quality_cells_SHA256'],
        provider_months_source=original['provider_months_source'],
        saved_source_preparation_SHA256=contract['saved_preparation']['SHA256'],
        qualified_source_contract_SHA256=c.jsha(contract['qualified_source_contract']),
        source_rows_SHA256=original['source_rows_SHA256'],funding_events_SHA256=original['funding_events_SHA256'],
        source_quality_sidecar_SHA256=contract['artifacts']['MINUTE_MARK_PROVENANCE.json']['SHA256'],
        source_inputs_SHA256=contract['artifacts']['SOURCE_INPUTS.npz']['SHA256'],
        all_high365_position_and_event_impacts_pending=True,
        original_source_age_and_arrival_flags_preserved=True,
        actual_high365_native_outcomes_inferred=False,
        source_completion_is_not_arrival_certification=True,
        evidence_limits=contract['evidence_limits'])


def validate_preparation_metadata(raw):
    value=c.exact_object(raw);ordered=tranche_cells(value.get('tranche'));years=tranche_years(value['tranche'])
    fixed=dict(schema=PREPARATION_SCHEMA,candidate=config.CANDIDATE,adaptation_version=config.VERSION,
        ordered_cells=list(ordered),code_manifest_SHA256=code_identity(),scope_manifest_SHA256=manifest_sha(),
        source_contract_map_SHA256=contract_sha(),historical_admission=False,financial_runs=0,
        accounts_created=0,accounts_advanced=0,provider_iterations=0,process_launches=0,
        canonical_claims_created=0,real_financial_GO_written=0,publication_actions=0)
    allowed=set(fixed)|{'tranche','years','cells','source_stage_GO_SHA256','source_review_SHA256','artifacts'}
    if set(value)!=allowed or any(c.canonical(value.get(k))!=c.canonical(v) for k,v in fixed.items()):
        raise ValueError('EXACT_PREPARATION_TOP_LEVEL_SCHEMA_NO_EXTRA_AUTHORITY_FIELDS_REQUIRED')
    if set(value.get('years',{}))!={str(y) for y in years} or set(value.get('cells',{}))!=set(ordered):
        raise ValueError('EXACT_ALL15_ONLY_YEAR_CELL_BINDINGS_REQUIRED')
    go=c.digest(value.get('source_stage_GO_SHA256'));review=c.digest(value.get('source_review_SHA256'))
    artifacts=value.get('artifacts');needed={'SOURCE_STAGE_AUTHORIZATION.json','SOURCE_INDEPENDENT_REVIEW.json'}
    for year in years:
        needed|={str(year)+'/'+name for name in ('TARGETS.npz','SOURCE_INPUTS.npz','SOURCE_ROWS.json','RAW_EVENTS.json','MINUTE_MARK_PROVENANCE.json','TARGET_PROOFS.json','SOURCE_PREFIX_INPUTS.npz')}
        if year==2022:needed.add('2022/NORMALIZATION_EQUIVALENCE.json')
    if type(artifacts) is not dict or set(artifacts)!=needed:
        raise ValueError('EXACT_HIGH365_SOURCE_TARGET_ARTIFACT_NAMESPACE_REQUIRED')
    for name,pin in artifacts.items():
        c.relative(name)
        if type(pin) is not dict or set(pin)!={'SHA256','bytes'} or type(pin['bytes']) is not int or pin['bytes']<0:
            raise ValueError('EXACT_ARTIFACT_BYTE_PIN_REQUIRED')
        c.digest(pin['SHA256'])
    if artifacts['SOURCE_STAGE_AUTHORIZATION.json']['SHA256']!=go or artifacts['SOURCE_INDEPENDENT_REVIEW.json']['SHA256']!=review:
        raise ValueError('EXACT_FRESH_SOURCE_GO_REVIEW_ARTIFACT_LINEAGE_REQUIRED')
    for year in years:
        info=value['years'][str(year)];wanted=year_metadata(year)
        if type(info) is not dict or set(info)!=set(wanted)|{'array_identities','target_prefix_metadata'} or any(c.canonical(info.get(k))!=c.canonical(v) for k,v in wanted.items()):
            raise ValueError('EXACT_YEAR_INFORMATION_SCHEMA_AND_QUALIFIED_SOURCE_LINEAGE_REQUIRED')
        checked_array_identities(info['array_identities'],year)
        checked_prefix_metadata(info['target_prefix_metadata'],year)
        contract=contracts()['years'][str(year)]
        for name,pin in contract['artifacts'].items():
            if c.canonical(artifacts[str(year)+'/'+name])!=c.canonical({k:pin[k] for k in ('SHA256','bytes')}):
                raise ValueError('EXACT_QUALIFIED_SOURCE_CAPTURE_ARTIFACT_BITS_REQUIRED')
    for cell_id in ordered:
        cell=value['cells'][cell_id];descriptor=config.cell_named(cell_id)
        if type(cell) is not dict or set(cell)!={'descriptor','input_binding','input_binding_SHA256'}:
            raise ValueError('EXACT_CELL_INFORMATION_SCHEMA_NO_EXTRA_AUTHORITY_FIELDS_REQUIRED')
        binding=binding_from_info(descriptor,value['years'][str(descriptor['year'])],go,review)
        if c.canonical(cell.get('descriptor'))!=c.canonical(descriptor) or c.canonical(cell.get('input_binding'))!=c.canonical(binding) or c.jsha(binding)!=cell.get('input_binding_SHA256'):
            raise ValueError('EXACT_RECIPE_YEAR_TIER_SOURCE_TARGET_REVIEW_GO_BINDING_REQUIRED')
    return value


@dataclass(frozen=True,slots=True)
class High365RecordingScope:
    cell_id:str
    binding_SHA256:str
    _token:object=field(repr=False)
    _seal:object=field(repr=False)

    def __post_init__(self):
        if self._seal is not _RECORD_SEAL:
            raise ValueError('ENTRY_OWNED_HIGH365_RECORDING_SCOPE_ONLY')

    def validate_current(self):
        if self._token not in _ACTIVE_RECORDING:
            raise ValueError('HIGH365_RECORDING_SCOPE_REVOKED')
        return True


def record_metadata_bindings(preparation,callback):
    preparation=validate_preparation_metadata(c.canonical(preparation))
    if not callable(callback):
        raise ValueError('EXPLICIT_SOURCE_ONLY_METADATA_CALLBACK_REQUIRED')
    returned=[]
    for cell_id in tranche_cells(preparation['tranche']):
        token=object();_ACTIVE_RECORDING.add(token)
        scope=High365RecordingScope(cell_id,preparation['cells'][cell_id]['input_binding_SHA256'],token,_RECORD_SEAL)
        try:
            scope.validate_current();callback(scope);returned.append(cell_id)
        finally:
            _ACTIVE_RECORDING.discard(token)
    return dict(ordered_cells=returned,metadata_scopes_revoked=not _ACTIVE_RECORDING,
        actual_source_scopes_created=0,historical_scopes_created=0,actual_provider_iterations=0,accounts_created=0)
