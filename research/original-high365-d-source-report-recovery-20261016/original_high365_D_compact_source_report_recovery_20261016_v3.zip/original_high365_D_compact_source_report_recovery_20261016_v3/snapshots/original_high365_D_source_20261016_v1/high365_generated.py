"""Invented in-memory source storage. No real source input or authority files."""
from contextlib import contextmanager
from copy import deepcopy
from io import BytesIO
from unittest.mock import patch
import numpy as np
import zipfile
import high365_common as c
import high365_config as config
import high365_entry as entry
import high365_signal as signal

observed_guard_receipts=[]
observed_generated_scope_lifecycle=dict(minted=0,revoked=0,actual_body_read_blocks=0,fake_source_storage_reads=0,real_CLI_positive_controls=0)


def pack(**arrays):
    stream=BytesIO();np.savez_compressed(stream,**arrays);return stream.getvalue()


def authority():
    review=c.canonical(entry.review_policy(entry.ALL15));review_sha=c.sha(review)
    go=c.canonical(entry.source_policy(entry.ALL15,review_sha))
    return go,c.sha(go),review,review_sha


def daily(year):
    period=config.source_year(year);clocks=np.arange(period['warmup_start'],period['end'],config.DAY,dtype=np.int64)
    x=np.arange(len(clocks),dtype=np.float64)
    close=np.column_stack([100+j*20+x*(.02+j*.003)+np.sin(x/(7+j)+j)*.4 for j in range(5)])
    return dict(close_available_us=clocks,close=close)


def long_daily(year):
    """Invented unshortened prefix, never an empirical source substitute."""
    a=daily(year);tc=a['close_available_us'];pc=a['close'];extra=200
    older=tc[0]-np.arange(extra,0,-1,dtype=np.int64)*config.DAY
    before=np.column_stack([100+j*20+np.sin(np.arange(extra)/(7+j)+j)*.2 for j in range(5)])
    return dict(close_available_us=np.r_[older,tc],close=np.vstack([before,pc]))


def fake_storage():
    contracts=deepcopy(entry.contracts());storage={}
    for year in entry.tranche_years(entry.ALL15):
        contract=contracts['years'][str(year)];period=config.source_year(year);inputs=daily(year)
        rows=[dict(symbol=symbol,close_us=int(at),available_us=int(at),close=float(inputs['close'][i,j]))
              for i,at in enumerate(inputs['close_available_us']) for j,symbol in enumerate(config.SYMBOLS)]
        # Literal microsecond funding offsets and negative rates remain exact.
        events=[dict(symbol=s,event_us=period['start']+15001,raw_rate=(-1 if j%2 else 1)*.00013,
            reported_interval_hours=(2,4,8,2,8)[j] if year==2022 else 8,
            **({'raw_rate_unit':'UNCONFIRMED'} if year in (2021,2022) else {})) for j,s in enumerate(config.SYMBOLS)]
        if year!=2022:events.sort(key=lambda r:(r['event_us'],r['symbol']))
        original=contract['qualified_source_contract'];original['events']['selected_events']=5
        contract['source_identity']=c.jsha({'INVENTED_SOURCE_YEAR':year});original['source_identity']=contract['source_identity']
        cells=[dict(symbol=config.SYMBOLS[j%5],minute_open_us=period['start']+j*60_000_000,
            anchor_open_us=period['start']-60_000_000,original_source_age_us=(j+1)*60_000_000,
            arrival_status='UNKNOWN_NOT_CERTIFIED',price_text='123.125') for j in range(27)] if year==2022 else []
        sidecar=dict(schema=contract['sidecar_schema'],year=year,
            calendar=[period['start'],period['end']],qualified_source_identity=contract['source_identity'],
            source_completion_is_not_arrival_certification=True,arrival_status='UNKNOWN_NOT_CERTIFIED',
            original_source_age_and_arrival_flags_preserved=True,certifies_liquidation=False,certifies_no_liquidation=False,
            cells=cells,derived_mark_cells={2021:0,2022:27,2023:0,2024:10,2025:0}[year],
            genuine_recovery_witnesses=[dict(symbol=config.SYMBOLS[j%5],minute_open_us=period['start']+(30+j)*60_000_000,is_genuine=True,
                actual_publication_arrival_installation='UNKNOWN_NOT_CERTIFIED') for j in range(8)] if year==2022 else [],
            final_endpoint_close={s:float(120+j) for j,s in enumerate(config.SYMBOLS)})
        if year==2021:
            sidecar['qualified_terminal_source_witness']=dict(source_end_plus_one_witness_is_not_execution_authority=True,
                changes_native_execution_clock=False,historical_execution_authorized=False,terminal_quotes=[dict(symbol=s,
                    kind='terminal_flat_quote',open_us=period['end']-60_000_000,available_us=period['end'],
                    execution_clock_if_later_admitted_us=period['end']+1,available_before_proposed_execution=True,
                    actual_trade_close=123.+j,actual_mark_close=124.+j) for j,s in enumerate(config.SYMBOLS)])
        raw={'SOURCE_INPUTS.npz':pack(**inputs),'RAW_EVENTS.json':c.canonical(events)+b'\n',
             'MINUTE_MARK_PROVENANCE.json':c.canonical(sidecar)+b'\n'}
        if year==2022:raw['NORMALIZATION_EQUIVALENCE.json']=c.canonical(dict(twelve_exact_old_container_hashes=True,
            source_to_serialized_numeric_bits=True,normalized_months_persisted=False,historical_execution_authorized=False))+b'\n'
        contract['source_metadata'].update(source_rows_SHA256=c.jsha(rows),funding_events_SHA256=c.jsha(events),quality_cells_SHA256=c.jsha(cells))
        contract['read_files']={}
        for name,body in raw.items():
            path=f'GENERATED_MEMORY_ONLY/{year}/{name}'
            pin=dict(SHA256=c.sha(body),bytes=len(body));contract['artifacts'][name]=dict(path=path,**pin)
            contract['read_files'][path]=pin;storage[str(c.ROOT/path)]=body
        contract['source_metadata']['source_quality_sidecar_SHA256']=c.sha(raw['MINUTE_MARK_PROVENANCE.json'])
        # Invented original long-prefix transport. Numeric future suffix and an
        # unselected object array are retained only as hostile source fixtures.
        tc=inputs['close_available_us'];pc=inputs['close'];extra=200
        older=tc[0]-np.arange(extra,0,-1,dtype=np.int64)*config.DAY
        before=np.column_stack([100+j*20+np.sin(np.arange(extra)/(7+j)+j)*.2 for j in range(5)])
        ft=np.r_[older,tc,tc[-1]+config.DAY,tc[-1]+2*config.DAY]
        fp=np.vstack([before,pc,np.full((2,5),np.nan)])
        member=pack(symbol_order=np.asarray(config.SYMBOLS),close_available_us=ft,close=fp,UNSELECTED_TARGET_OBJECT=np.array([object()],dtype=object))
        dest=BytesIO()
        with zipfile.ZipFile(dest,'w',compression=zipfile.ZIP_DEFLATED) as z:z.writestr(contract['original_target_prefix']['member']['name'],member)
        wr=dest.getvalue();path=f'GENERATED_MEMORY_ONLY/{year}/ORIGINAL_SMALL_WRAPPER.zip'
        contract['original_target_prefix']['wrapper']=dict(path=path,SHA256=c.sha(wr),bytes=len(wr))
        contract['original_target_prefix']['member'].update(SHA256=c.sha(member),bytes=len(member))
        contract['read_files'][path]=dict(SHA256=c.sha(wr),bytes=len(wr));storage[str(c.ROOT/path)]=wr

    return contracts,storage


@contextmanager
def installed_fake_storage():
    contracts,storage=fake_storage();original=c.exact
    def exact(path,expected_sha,expected_bytes=None):
        name=str(path)
        if name in storage:
            from high365_source_guard import current_guard
            guard=current_guard()
            if guard is None or not guard.active:raise AssertionError('FAKE_SOURCE_READ_REQUIRES_REAL_SOURCE_GUARD')
            guard._check_read(path)
            raw=storage[name]
            if c.sha(raw)!=expected_sha or expected_bytes is not None and len(raw)!=expected_bytes:raise ValueError('EXACT_FAKE_STORAGE_PIN_REQUIRED')
            observed_generated_scope_lifecycle['fake_source_storage_reads']+=1
            return raw
        return original(path,expected_sha,expected_bytes)
    with patch.object(entry,'contracts',return_value=contracts),patch.object(entry,'contract_sha',return_value=c.jsha(contracts)),patch.object(c,'exact',side_effect=exact):
        yield contracts,storage


def read_paths():
    record=c.exact_object((c.HERE/'CODE_MANIFEST.json').read_bytes())
    return [c.HERE/name for name in record['files']]+[c.ROOT/name for name in record['dependencies']]+[c.HERE/'CODE_MANIFEST.json']
