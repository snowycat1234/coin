"""Thin exact saved-source capture; new intrinsic targets, no CS authority.

The three source artifacts per year (plus 2022 normalization witness) are read
only inside the new sealed source scope. No CS targets/covariance, raw monthly
recapture, native provider, account, claim or finance process is used here.
"""
from io import BytesIO
from pathlib import Path
import re
import numpy as np
import high365_common as c
import high365_codec as codec
import high365_config as config
import high365_entry as entry
import high365_signal as signal
import high365_prefix as prefix


def finite_number(value):
    if type(value) not in (int,float):return False
    try:return bool(np.isfinite(float(value)))
    except (OverflowError,ValueError,TypeError):return False


def funding_events(year,raw,contract):
    period=config.source_year(year);values=c.object_json(raw)
    original=contract['qualified_source_contract'];fields={'symbol','event_us','raw_rate','reported_interval_hours'}
    if year in (2021,2022):fields.add('raw_rate_unit')
    if type(values) is not list or len(values)!=original['events']['selected_events']:
        raise ValueError('EXACT_QUALIFIED_FUNDING_ARRAY_COUNT_REQUIRED')
    for row in values:
        if (type(row) is not dict or set(row)!=fields or row['symbol'] not in config.SYMBOLS
                or type(row['event_us']) is not int or not period['start']<=row['event_us']<period['end']
                or not finite_number(row['raw_rate']) or not finite_number(row['reported_interval_hours'])
                or row['reported_interval_hours'] not in ((2,4,8) if year==2022 else (8,))
                or year in (2021,2022) and row['raw_rate_unit']!='UNCONFIRMED'):
            raise ValueError('EXACT_RAW_SIGNED_FUNDING_LITERAL_CLOCK_INTERVAL_AND_UNCERTIFIED_UNIT_REQUIRED')
    order=lambda row:(row['event_us'],config.SYMBOLS.index(row['symbol']) if year==2022 else row['symbol'])
    if len({(r['symbol'],r['event_us']) for r in values})!=len(values) or values!=sorted(values,key=order):
        raise ValueError('EXACT_ORIGINAL_FUNDING_IDENTITY_SAMECLOCK_ORDER_REQUIRED')
    if c.jsha(values)!=contract['source_metadata']['funding_events_SHA256']:
        raise ValueError('EXACT_CAPTURED_FUNDING_EVENTS_BITS_REQUIRED_NO_ROUNDING_OR_RESCALE')
    return c.immutable(values)


def decode_capture(year,raw,contract):
    """Pure invented/actual byte decoder; it cannot mint any source authority."""
    period=config.source_year(year)
    if type(raw) is not dict or set(raw)!=set(contract['artifacts']):
        raise ValueError('EXACT_SOURCE_ONLY_CAPTURE_NAMESPACE_REQUIRED_NO_CS_TARGET_ARRAYS')
    for name,pin in contract['artifacts'].items():
        if type(raw[name]) is not bytes or c.sha(raw[name])!=pin['SHA256'] or len(raw[name])!=pin['bytes']:
            raise ValueError('EXACT_QUALIFIED_SAVED_SOURCE_ARTIFACT_BITS_REQUIRED')
    clocks,close,decisions=codec.daily_inputs(year,raw['SOURCE_INPUTS.npz'])
    rows=tuple(dict(symbol=symbol,close_us=int(at),available_us=int(at),close=float(close[i,j]))
        for i,at in enumerate(clocks) for j,symbol in enumerate(config.SYMBOLS))
    if c.jsha(rows)!=contract['source_metadata']['source_rows_SHA256']:
        raise ValueError('EXACT_QUALIFIED_SOURCE_ROW_BITS_AND_PAST_ONLY_CLOSES_REQUIRED')
    events=funding_events(year,raw['RAW_EVENTS.json'],contract)
    sidecar=c.exact_object(raw['MINUTE_MARK_PROVENANCE.json']);original=contract['qualified_source_contract']
    if (sidecar.get('schema')!=contract['sidecar_schema']
            or type(sidecar.get('year')) is not int or sidecar['year']!=year
            or sidecar.get('calendar')!=[period['start'],period['end']]
            or sidecar.get('qualified_source_identity')!=contract['source_identity']
            or sidecar.get('arrival_status')!='UNKNOWN_NOT_CERTIFIED'
            or sidecar.get('source_completion_is_not_arrival_certification') is not True
            or sidecar.get('original_source_age_and_arrival_flags_preserved') is not True
            or sidecar.get('certifies_liquidation') is not False or sidecar.get('certifies_no_liquidation') is not False
            or c.jsha(sidecar.get('cells'))!=contract['source_metadata']['quality_cells_SHA256']
            or sidecar.get('derived_mark_cells')!=original['quality_summary'].get('derived_mark_cells',original.get('derived_mark_cells',0))):
        raise ValueError('EXACT_QUALIFIED_SOURCE_QUALITY_AGE_AND_UNKNOWN_ARRIVAL_REQUIRED')
    if year==2021:
        witness=sidecar.get('qualified_terminal_source_witness',{})
        terminal=witness.get('terminal_quotes',[])
        if (witness.get('source_end_plus_one_witness_is_not_execution_authority') is not True
                or witness.get('changes_native_execution_clock') is not False
                or witness.get('historical_execution_authorized') is not False
                or len(terminal)!=5 or [r.get('symbol') for r in terminal]!=list(config.SYMBOLS)):
            raise ValueError('EXACT2021_FIVE_QUALIFIED_TERMINAL_QUOTES_WITNESS_ONLY_REQUIRED')
        for row in terminal:
            if (row.get('kind')!='terminal_flat_quote' or row.get('open_us')!=period['end']-codec.MINUTE
                    or row.get('available_us')!=period['end'] or row.get('execution_clock_if_later_admitted_us')!=period['end']+1
                    or row.get('available_before_proposed_execution') is not True
                    or any(not finite_number(row.get(k)) or row[k]<=0 for k in ('actual_trade_close','actual_mark_close'))):
                raise ValueError('EXACT2021_TRUE_TERMINAL_SOURCE_ENDPLUS1_IS_WITNESS_ONLY')
    if year==2022:
        if len(sidecar['cells'])!=27 or len(sidecar.get('genuine_recovery_witnesses',[]))!=8:
            raise ValueError('EXACT2022_27_CAUSAL_PREVIOUS_GENUINE_CARRIES_EIGHT_RECOVERY_WITNESSES_REQUIRED')
        equivalence=c.exact_object(raw['NORMALIZATION_EQUIVALENCE.json'])
        if (equivalence.get('twelve_exact_old_container_hashes') is not True
                or equivalence.get('source_to_serialized_numeric_bits') is not True
                or equivalence.get('normalized_months_persisted') is not False
                or equivalence.get('historical_execution_authorized') is not False):
            raise ValueError('EXACT2022_REUSED_QUALIFIED_NORMALIZATION_WITNESS_REQUIRED')
    if year==2024:
        if (original.get('earliest_genuine_recovery_available_us')!=1723457100000000
                or sidecar['derived_mark_cells']!=10 or sidecar.get('genuine_recovery_witnesses')!=[]):
            raise ValueError('EXACT2024_TEN_UNKNOWN_CELLS_PINNED_RECOVERY_CONTRACT_NO_INVENTED_PRICE_WITNESS')
    if year==2025 and len(original.get('canonical_fifteen_files',[]))!=15:
        raise ValueError('EXACT2025_CANONICAL15_SOURCE_FILES_PAST_WARMUP_ONLY_REQUIRED')
    return dict(year=year,period=period,clocks=clocks,close=close,decisions=decisions,
        source_rows=c.immutable(rows),events=events,sidecar=c.immutable(sidecar),
        sidecar_raw=raw['MINUTE_MARK_PROVENANCE.json'],source_identity=contract['source_identity'],
        contract=c.immutable(contract),captured_artifacts=c.immutable(raw))


def capture_year(year,source_scope):
    config.source_year(year)
    if type(source_scope) is not entry.High365SourcePreparationScope:
        raise ValueError('EXACT_NEW_HIGH365_SOURCE_SCOPE_REQUIRED_NO_CS_ALIAS')
    source_scope.validate_current(year=year);contract=entry.contracts()['years'][str(year)]
    captured={name:source_scope.read_source(year,pin['path'],pin['SHA256'],pin['bytes'])
        for name,pin in contract['artifacts'].items()}
    result=decode_capture(year,captured,contract)
    pc=contract['original_target_prefix'];wr=pc['wrapper']
    source_scope.validate_current(year=year)
    selected,proof=prefix.select_prefix(source_scope.read_source(year,wr['path'],wr['SHA256'],wr['bytes']),pc,year)
    prefix.validate_canonical_parity(selected,result)
    result.update(target_prefix=selected,target_prefix_metadata=proof)
    source_scope.validate_current(year=year)
    return result


def project_targets(source):
    config.source_year(source['year'])
    selected=source['target_prefix']
    prefix.validate_canonical_parity(selected,source)
    arrays,proofs=signal.build_target_grid(selected['close'],selected['clocks'],selected['clocks'],source['decisions'])
    return arrays,dict(original_intrinsic_then_downward_only=True,source_recipe_order=config.RECIPES,
        original_execution_unchanged=False,financial_reuse_allowed=False,proofs=proofs)


def target_blob(arrays):
    stream=BytesIO();np.savez_compressed(stream,**arrays);return stream.getvalue()


def year_info(source,targets):
    info=entry.year_metadata(source['year'])
    info['array_identities']={key:signal.array_byte_identity(value) for key,value in targets.items()}
    info['target_prefix_metadata']=source['target_prefix_metadata']
    return info


def prepare_source_only(output_directory,*,source_go_raw,expected_source_go_sha256,review_raw,expected_review_sha256):
    authority=entry.validate_source_authority_metadata(source_go_raw,expected_source_go_sha256,review_raw,expected_review_sha256)
    from high365_source_guard import current_guard
    guard=current_guard()
    if guard is None or not guard.active:raise ValueError('WHOLE_INVOCATION_HIGH365_SOURCE_ONLY_GUARD_REQUIRED')
    output=Path(output_directory).absolute();base=c.HERE/'source_attempts'
    if (output.parent!=base or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,100}',output.name)
            or output.is_symlink() or any(p.is_symlink() for p in output.parents) or output.exists()):
        raise ValueError('EXCLUSIVE_EXACT_NEW_HIGH365_SOURCE_ATTEMPT_OUTPUT_REQUIRED')
    artifacts={};years={};cells={};tranche=authority['policy']['tranche']
    with entry.admit_source_stage(source_go_raw,expected_source_go_sha256,review_raw,expected_review_sha256) as scope:
        for year in entry.tranche_years(tranche):
            source=capture_year(year,scope);targets,proofs=project_targets(source);prefix=str(year)+'/'
            artifacts.update({prefix+name:raw for name,raw in source['captured_artifacts'].items()})
            artifacts[prefix+'TARGETS.npz']=target_blob(targets)
            artifacts[prefix+'SOURCE_PREFIX_INPUTS.npz']=target_blob(dict(close_available_us=source['target_prefix']['clocks'],close=source['target_prefix']['close']))
            artifacts[prefix+'SOURCE_ROWS.json']=c.canonical(source['source_rows'])+b'\n'
            artifacts[prefix+'TARGET_PROOFS.json']=c.canonical(proofs)+b'\n'
            years[str(year)]=year_info(source,targets)
            for cell_id in entry.tranche_cells(tranche):
                cell=config.cell_named(cell_id)
                if cell['year']!=year:continue
                binding=entry.binding_from_info(cell,years[str(year)],expected_source_go_sha256,expected_review_sha256)
                cells[cell_id]=dict(descriptor=cell,input_binding=binding,input_binding_SHA256=c.jsha(binding))
            guard.checkpoint('PREPARED_'+str(year)+'_NEW_HIGH365_INTRINSIC_TARGETS_NO_ACCOUNT')
    if entry._ACTIVE_SOURCE:raise ValueError('HIGH365_SOURCE_SCOPES_NOT_REVOKED')
    artifacts['SOURCE_STAGE_AUTHORIZATION.json']=source_go_raw;artifacts['SOURCE_INDEPENDENT_REVIEW.json']=review_raw
    preparation=dict(schema=entry.PREPARATION_SCHEMA,candidate=config.CANDIDATE,adaptation_version=config.VERSION,
        tranche=tranche,ordered_cells=list(entry.tranche_cells(tranche)),years=years,cells=cells,
        code_manifest_SHA256=entry.code_identity(),scope_manifest_SHA256=entry.manifest_sha(),source_contract_map_SHA256=entry.contract_sha(),
        source_stage_GO_SHA256=expected_source_go_sha256,source_review_SHA256=expected_review_sha256,
        artifacts={name:dict(SHA256=c.sha(raw),bytes=len(raw)) for name,raw in artifacts.items()},
        historical_admission=False,financial_runs=0,accounts_created=0,accounts_advanced=0,
        provider_iterations=0,process_launches=0,canonical_claims_created=0,real_financial_GO_written=0,publication_actions=0)
    raw=c.canonical(preparation)+b'\n';entry.validate_preparation_metadata(raw)
    output.mkdir(parents=True)
    for name,value in artifacts.items():
        path=output/c.relative(name);path.parent.mkdir(parents=True,exist_ok=True)
        with path.open('xb') as stream:stream.write(value)
    with (output/'PREPARATION.json').open('xb') as stream:stream.write(raw)
    return preparation
