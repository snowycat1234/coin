"""Thin pinned import of the independent original HIGH365/HOLD pure closure."""
from types import ModuleType
import sys
import numpy as np
import high365_common as c
from high365_config import SYMBOLS
PURE_PATH='original_high365_signal_20261016_v1/high365_signal.py'
PURE_SHA='b3439ec67967fba74065bfae9734c3557050d4d34a2eee6e18fc275679d56b63'


def reviewed_signal():
    path=c.ROOT/PURE_PATH;raw=c.exact(path,PURE_SHA)
    module=ModuleType('_original_high365_pure_adapter');module.__file__=str(path)
    previous=sys.modules.get(module.__name__);sys.modules[module.__name__]=module
    try:exec(compile(raw,str(path),'exec'),module.__dict__)
    finally:
        if previous is None:sys.modules.pop(module.__name__,None)
        else:sys.modules[module.__name__]=previous
    return module


def supported_array(value):
    a=np.asarray(value)
    if (a.dtype.fields is not None or a.dtype.subdtype is not None or a.dtype.hasobject
            or (a.dtype.kind,a.dtype.itemsize) not in (('b',1),('i',8),('f',8))):
        raise ValueError('PLAIN_BOOL_INT64_FLOAT64_ONLY_NO_STRUCTURED_VOID_OBJECT_OR_UNSUPPORTED_DTYPE')
    return a


def array_byte_identity(value):
    value=supported_array(value)  # Reject unsupported descriptors before resolving generic code.
    return reviewed_signal().array_byte_identity(value)


def immutable_array(value):
    a=supported_array(value)
    return np.frombuffer(a.tobytes(order='C'),dtype=a.dtype).reshape(a.shape)


def build_target_grid(close,close_us,available_us,decisions):
    arrays=[supported_array(a) for a in (close,close_us,available_us,decisions)]
    if arrays[0].dtype!=np.dtype('float64') or any(a.dtype!=np.dtype('int64') for a in arrays[1:]):
        raise ValueError('EXACT_PLAIN_FLOAT64_PRICES_INT64_CLOCKS_REQUIRED')
    result,proofs=reviewed_signal().build_target_grid(*arrays,symbols=SYMBOLS)
    return result,c.plain(proofs)


def target_key(cell):return cell['recipe']+'_'+cell['tier']
