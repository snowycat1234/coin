"""Shared pure generated/actual source codecs; no filename/provider API."""
from io import BytesIO
import stat
from types import MappingProxyType
import zipfile

import numpy as np

import high365_common as c
from high365_config import source_year as period_named, DAY
from high365_config import SYMBOLS as S

MINUTE = 60_000_000
FIELDS = ('open', 'close', 'quote_volume', 'mark')


def frozen_array(a):
    a = np.asarray(a)
    from high365_signal import supported_array
    a = supported_array(a)
    return np.frombuffer(a.tobytes(order='C'), dtype=a.dtype).reshape(a.shape)


def npz(raw, specs, *, allow_unselected=False):
    """Bound and validate selected NPY headers before allocating a payload."""
    if type(raw) is not bytes or type(allow_unselected) is not bool:
        raise ValueError('EXACT_NUMERIC_CONTAINER_BYTES_REQUIRED')
    try:
        with zipfile.ZipFile(BytesIO(raw)) as archive:
            infos = archive.infolist(); names = [row.filename for row in infos]
            selected = {key + '.npy' for key in specs}
            if (len(names) != len(set(names)) or not selected <= set(names)
                    or not allow_unselected and selected != set(names)):
                raise ValueError('EXACT_ARRAY_MEMBER_NAMESPACE_REQUIRED')
            for info in infos:
                if (info.is_dir() or info.flag_bits & 1 or stat.S_ISLNK(info.external_attr >> 16)
                        or '/' in info.filename or '\\' in info.filename or not info.filename.endswith('.npy')):
                    raise ValueError('ORDINARY_FLAT_NUMERIC_MEMBERS_REQUIRED')
                if info.filename not in selected:
                    continue  # Never decompress unrelated stored DEV members.
                key = info.filename[:-4]; shape, dtype_spec = specs[key]
                if info.file_size > 8 * 1024 * 1024:
                    raise ValueError('BOUNDED_NUMERIC_MEMBER_REQUIRED')
                with archive.open(info) as stream:
                    version = np.lib.format.read_magic(stream)
                    if version not in ((1, 0), (2, 0)):
                        raise ValueError('SUPPORTED_NPY_HEADER_REQUIRED')
                    reader = np.lib.format.read_array_header_1_0 if version == (1, 0) else np.lib.format.read_array_header_2_0
                    actual_shape, fortran, dtype = reader(stream, max_header_size=4096)
                    valid_dtype = (dtype.kind == 'U' and 0 < dtype.itemsize <= 128
                                   if dtype_spec == 'SYMBOLS' else dtype == np.dtype(dtype_spec))
                    if actual_shape != shape or dtype.fields is not None or dtype.subdtype is not None or dtype.hasobject or fortran or not valid_dtype:
                        raise ValueError('EXACT_NUMERIC_HEADER_SCHEMA_REQUIRED')
                    if stream.tell() + int(np.prod(shape)) * dtype.itemsize != info.file_size:
                        raise ValueError('EXACT_NUMERIC_PAYLOAD_LENGTH_REQUIRED')
        with np.load(BytesIO(raw), allow_pickle=False) as arrays:
            return {key: (np.frombuffer(arrays[key].tobytes(order='C'), dtype=arrays[key].dtype).reshape(arrays[key].shape)
                          if specs[key][1] == 'SYMBOLS' else frozen_array(arrays[key])) for key in specs}
    except (zipfile.BadZipFile, EOFError, OSError) as exc:
        raise ValueError('VALID_NUMERIC_ARCHIVE_REQUIRED') from exc


def daily_inputs(year,raw):
    period=period_named(year);count=period['days']+199
    a=npz(raw,{'close_available_us':((count,),'int64'),'close':((count,5),'float64')})
    clocks,close=a['close_available_us'],a['close']
    if (not np.array_equal(clocks,np.arange(period['warmup_start'],period['end'],DAY,dtype=np.int64))
            or not np.isfinite(close).all() or (close<=0).any()):
        raise ValueError('EXACT_COMPLETE_PAST_ONLY_CLOSE_CALENDAR_REQUIRED')
    decisions=np.arange(period['start'],period['end'],DAY,dtype=np.int64)
    return tuple(frozen_array(value) for value in (clocks,close,decisions))
