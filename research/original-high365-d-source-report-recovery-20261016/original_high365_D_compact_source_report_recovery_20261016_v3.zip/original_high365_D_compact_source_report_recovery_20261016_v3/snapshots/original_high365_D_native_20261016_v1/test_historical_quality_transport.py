"""Constructor-quality AST regression: generated inputs/recording metadata only.

No historical scope is minted. The exact production quality-install statements
are executed over a sealed1971 native fixture, or pure recording state for the
real-calendar policy identity shape. No actual source or target arrays are read.
"""
import ast
from copy import deepcopy
from dataclasses import asdict
from pathlib import Path
from types import SimpleNamespace
import unittest
import high365_native_bootstrap
import high365_native_common as c
import high365_native_generated as g
import high365_native_quality as source_quality
import high365_source_entry as entry
import high365_saved as saved
from test_high365_native import finance,marks


def quality_fragment(path,*,install):
    tree=ast.parse(Path(path).read_text());fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='_construct_case')
    body=[];active=False
    for n in fn.body:
        text=ast.unparse(n)
        if text=='account = sim.account':active=True
        if active:
            if text=='quality.install()' and not install:break
            if text.startswith('if getattr(account.liquidation_callback'):break
            body.append(n)
    assert body and any('intervals =' in ast.unparse(n) for n in body)
    return compile(ast.fix_missing_locations(ast.Module(body=body,type_ignores=[])),'<EXACT_PRODUCTION_QUALITY_CONSTRUCTOR_AST>','exec')


def install_recording_quality(native,sim,guard,intervals,*,original_genuine,cells=(),sidecar='a'*64):
    old=guard.causal_mark_quality_guard
    guard.original_attempt=old.original_attempt
    ns=dict(vars(native),sim=sim,guard=guard,quality_intervals=intervals,
        historical_scope=SimpleNamespace(quality_cells=cells),original_genuine=original_genuine,sidecar=sidecar)
    exec(quality_fragment(c.HERE/'high365_native.py',install=True),ns)
    return ns['quality']


def recording_policy(native,path,intervals,*,original_genuine,cells=(),sidecar='a'*64):
    account=SimpleNamespace(marks={symbol:[] for symbol in native.S})
    sim=SimpleNamespace(account=account);guard=SimpleNamespace(sim=sim)
    ns=dict(vars(native),sim=sim,guard=guard,quality_intervals=intervals,
        historical_scope=SimpleNamespace(quality_cells=cells),original_genuine=original_genuine,sidecar=sidecar)
    exec(quality_fragment(path,install=False),ns)
    return ns['quality'],account


class HistoricalQualityTransportTests(unittest.TestCase):
    def test_exact_single_interval_expression_restoration(self):
        def interval(path):
            fn=next(n for n in ast.parse(Path(path).read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='_construct_case')
            return next(n for n in fn.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='intervals' for t in n.targets))
        own=interval(c.HERE/'high365_native.py');cs=interval(c.ROOT/'original_cs_mom21_D_remaining9_financial_20261015_v1/cs_native.py')
        old=interval(c.ROOT/'legacy_intrinsic_D_remaining24_native_20261015_v1/legacy_native.py')
        self.assertEqual(ast.dump(own),ast.dump(cs));self.assertNotEqual(ast.dump(own),ast.dump(old))

    def test_2024_historical_policy_identity_gap_partial_and_full_recovery(self):
        native=g.native_reference();a,b,prior=1723456980000000,1723457100000000,1723456920000000
        intervals=((a,b,native.S),)
        quality,account=recording_policy(native,c.HERE/'high365_native.py',intervals,original_genuine=prior)
        sidecar=dict(year=2024,cells=[],qualified_source_identity='b'*64,arrival_status='UNKNOWN_NOT_CERTIFIED',
            original_source_age_and_arrival_flags_preserved=True,actual_CS_event_impacts='PENDING_CS_SAVED_EXECUTION',
            actual_CS_position_interval_impacts='PENDING_CS_SAVED_EXECUTION_NOT_INHERITED_FROM_D',quality_intervals=c.plain(intervals))
        info=dict(quality_cells_SHA256=c.jsha([]),source_identity='b'*64,source_quality_sidecar_SHA256='a'*64)
        self.assertEqual(quality.identity,saved.quality_identity(sidecar,info,native.V2.quality_module.VERSION))
        old,_=recording_policy(native,c.ROOT/'legacy_intrinsic_D_remaining24_native_20261015_v1/legacy_native.py',intervals,original_genuine=prior)
        self.assertEqual(old.identity['intervals'],[]);self.assertNotEqual(old.identity,quality.identity)
        for symbol in native.S:account.marks[symbol]=[dict(close_us=prior,available_us=prior)]
        self.assertIsNone(quality.quality_witness(a-native.MINUTE))
        self.assertIsNotNone(quality.quality_witness(a));self.assertIsNotNone(quality.quality_witness(b))
        for symbol in native.S[:-1]:account.marks[symbol].append(dict(close_us=b,available_us=b))
        witness=quality.quality_witness(b+native.MINUTE);self.assertIsNotNone(witness)
        self.assertEqual(witness['affected_intervals'][0]['installed_marks'][-1]['symbol'],native.S[-1])
        account.marks[native.S[-1]].append(dict(close_us=b,available_us=b))
        self.assertIsNone(quality.quality_witness(b))

    def test_2022_historical_policy_keeps_intervals_and_all27_typed_cells(self):
        native=g.native_reference();contract=entry.contracts()['years']['2022']['qualified_source_contract']
        points=tuple(tuple(row) for row in contract['exact_mark_absent_open_points_us']);missing=set(points);old=source_quality.original_quality();cells=[]
        for symbol,at in points:
            anchor=at-native.MINUTE
            while (symbol,anchor) in missing:anchor-=native.MINUTE
            cells.append(old.QualityCell(symbol,at,at+native.MINUTE,at+native.MINUTE,'123.125',anchor,
                anchor+native.MINUTE,anchor+native.MINUTE,anchor+native.MINUTE,anchor+native.MINUTE,'c'*64,'GENERATED_ONLY_ANCHOR'))
        cells=tuple(cells);old.validate_quality_binding(cells,expected_missing_cells=points)
        intervals=source_quality.intervals(cells)
        quality,_=recording_policy(native,c.HERE/'high365_native.py',intervals,original_genuine=None,cells=cells)
        rows=[asdict(cell) for cell in cells]
        sidecar=dict(year=2022,cells=rows,qualified_source_identity='b'*64,arrival_status='UNKNOWN_NOT_CERTIFIED',
            original_source_age_and_arrival_flags_preserved=True,actual_CS_event_impacts='PENDING_CS_SAVED_EXECUTION',
            actual_CS_position_interval_impacts='PENDING_CS_SAVED_EXECUTION_NOT_INHERITED_FROM_D',quality_intervals=c.plain(intervals))
        info=dict(quality_cells_SHA256=c.jsha(rows),source_identity='b'*64,source_quality_sidecar_SHA256='a'*64)
        self.assertEqual(quality.identity,saved.quality_identity(sidecar,info,native.V2.quality_module.VERSION))
        self.assertEqual(len(quality.identity['source_clock_cells']),27);self.assertTrue(quality.identity['intervals'])

    def test_recording_historical_install_unknown_before_risk_and_partial_recovery(self):
        native=g.native_reference()
        for tier in ('LOW','MID','HIGH'):
            with g.generated_fixture(days=1) as fixture:
                targets=g.project_generated(fixture);sim,guard=g.construct_generated_case(targets,tier)
                a=int(fixture.decisions[0])+2*native.MINUTE;b=a+2*native.MINUTE;intervals=((a,b,native.S),)
                quality=install_recording_quality(native,sim,guard,intervals,original_genuine=a-native.MINUTE)
                account=sim.account;marks(account,a-native.MINUTE)
                seen=[];original=account._risk
                from types import MethodType
                def risk(self,phase):seen.append(tuple(self.mark_quality[symbol] for symbol in native.S));return original(phase)
                account._risk=MethodType(risk,account);marks(account,a);del account._risk
                self.assertTrue(seen);self.assertTrue(all(row==('UNKNOWN_OR_DERIVED',)*5 for row in seen))
                self.assertFalse(account.can_increase(a));self.assertIsNotNone(quality.quality_witness(b+native.MINUTE))
                price={symbol:dict(price=str((50000,2000,20,.5,.05)[i]),close_us=b,available_us=b) for i,symbol in enumerate(native.S)}
                account.update_marks(b,{symbol:price[symbol] for symbol in native.S[:-1]})
                self.assertIsNotNone(quality.quality_witness(b));account.update_marks(b,{native.S[-1]:price[native.S[-1]]})
                self.assertIsNone(quality.quality_witness(b));self.assertFalse(account.transfer_journal)

    def test_daily_signal_native_finance_parity_both_recipes_all_tiers(self):
        native=g.native_reference()
        for recipe in ('STATIC50_HIGH365_REFERENCE_HOLD',):
            with g.generated_fixture(days=2) as fixture:
                targets=g.project_generated(fixture,recipe=recipe);a=int(fixture.decisions[1])-native.MINUTE;intervals=((a,a+2*native.MINUTE,native.S),)
                for tier in ('LOW','MID','HIGH'):
                    left,lguard=g.construct_generated_case(targets,tier,quality_intervals=intervals)
                    right,rguard=g.construct_generated_case(targets,tier)
                    quality=install_recording_quality(native,right,rguard,intervals,original_genuine=a-native.MINUTE,
                        sidecar=lguard.causal_mark_quality_guard.source_sidecar_sha256)
                    self.assertEqual(quality.identity,lguard.causal_mark_quality_guard.identity)
                    while left.cursor<left.end and left.stop is None:left.advance_day()
                    while right.cursor<right.end and right.stop is None:right.advance_day()
                    self.assertEqual(finance(left.account),finance(right.account));self.assertEqual(lguard.receipts,rguard.receipts)
                    self.assertEqual(left.pending,right.pending);self.assertEqual(left.rows_written,right.rows_written)
                    self.assertEqual(quality.receipts,lguard.causal_mark_quality_guard.receipts)
                    self.assertFalse(left.account.transfer_journal);self.assertFalse(right.account.transfer_journal)
