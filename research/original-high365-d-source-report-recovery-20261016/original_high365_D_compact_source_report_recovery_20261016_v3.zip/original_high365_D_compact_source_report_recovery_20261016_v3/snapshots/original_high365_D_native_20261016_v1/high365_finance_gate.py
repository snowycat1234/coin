"""Separate legacy financial admission. No CS or plain-V3 authority is reused."""
from pathlib import Path
import high365_native_bootstrap
import high365_native_common as c
import high365_source_entry as source_entry
import high365_config as config

SOURCE_CODE_SHA256='a03588282511ae41462f3a1d95aac99a28496a3d4dbd5f3c869ac45bc2fe4799'
PREPARED_SOURCE_AUDIT_SHA256='e1c6983d24ed19298655cf7c0503b444cce9e2bd20e3164af56059222daa279f'
REVIEW_SCHEMA='INDEPENDENT_ORIGINAL_HIGH365_ALL15_FINANCIAL_ADMISSION_V1'
GO_SCHEMA='ROOT_FINANCIAL_ORIGINAL_HIGH365_ALL15_CURRENT_D_V1'
PREPARED_REVIEW_SCHEMA='INDEPENDENT_ORIGINAL_HIGH365_ALL15_INTRINSIC_PREPARED_TARGET_REVIEW_V1'
NATIVE_REVIEW_SCHEMA='INDEPENDENT_ORIGINAL_HIGH365_ALL15_NATIVE_GENERATED_ADMISSION_V1'
CLAIM_NAMESPACE='original_high365_D_native_20261016_v1/EXECUTION_CLAIMS'
SHARED_CPU_LEASE='original_cs_mom21_D_20261015_v4/EXECUTION_CLAIMS/9a5ef547d61272d5eb0bfb1b61fef8005a752d82f4e0007d18cbe65f06445a8a/CONTROLLER_LEASE.lock'


def code_identity():
    here=Path(__file__).resolve().parent
    if c.HERE!=here or Path(source_entry.__file__).resolve()!=high365_native_bootstrap.SOURCE/'high365_entry.py':
        raise ValueError('EXACT_NEW_FINANCE_AND_FROZEN_SOURCE_MODULE_IDENTITIES_REQUIRED')
    if source_entry.code_identity()!=SOURCE_CODE_SHA256:raise ValueError('FROZEN_LEGACY_SOURCE_IDENTITY_CHANGED')
    raw=c.ordinary(here/'FINANCIAL_CODE_MANIFEST.json');m=c.exact_object(raw)
    if (set(m)!={'schema','status','source_code_manifest_SHA256','files','dependencies','runtime_dependency_exclusions'}
            or m['schema']!='ADDITIVE_ORIGINAL_HIGH365_ALL15_NATIVE_FINANCIAL_CODE_V1'
            or m['source_code_manifest_SHA256']!=SOURCE_CODE_SHA256
            or m['runtime_dependency_exclusions']!=['CS_FAILED_CLAIMS','CS_SUPERSESSION_PACKETS','CS_ROOT_GO','PLAIN_V3_ROOT_GO']):
        raise ValueError('EXACT_LEGACY_FINANCIAL_CODE_MANIFEST_REQUIRED')
    if m['dependencies'].get('original_high365_D_prepared_independent_review_20261016_v1/PREPARED_INDEPENDENT_REVIEW.json',{}).get('SHA256')!=PREPARED_SOURCE_AUDIT_SHA256:
        raise ValueError('EXACT_INDEPENDENT_HIGH365_PREPARED_SOURCE_AUDIT_PIN_REQUIRED')
    for name,pin in m['files'].items():c.exact(here/c.relative(name),pin['SHA256'],pin['bytes'])
    for name,pin in m['dependencies'].items():c.exact(c.ROOT/c.relative(name),pin['SHA256'],pin['bytes'])
    return c.sha(raw)


def base(preparation_raw):
    p=source_entry.validate_preparation_metadata(preparation_raw)
    return dict(candidate=config.CANDIDATE,adaptation_version=config.VERSION,pure_signal_code_manifest_SHA256='2423efc89fb0002c62dc44623c4cf290eb932717f9c782b16e5ed7164ca5811d',source_code_manifest_SHA256=SOURCE_CODE_SHA256,financial_code_manifest_SHA256=code_identity(),
        scope_manifest_SHA256=source_entry.manifest_sha(),source_contract_map_SHA256=source_entry.contract_sha(),
        tranche=source_entry.ALL15,ordered_cells=list(source_entry.tranche_cells(source_entry.ALL15)),years=list(source_entry.tranche_years(source_entry.ALL15)),
        preparation_SHA256=c.sha(preparation_raw),source_stage_GO_SHA256=p['source_stage_GO_SHA256'],
        source_independent_review_SHA256=p['source_review_SHA256'],
        per_cell_input_binding_SHA256={k:v['input_binding_SHA256'] for k,v in p['cells'].items()},
        independent_prepared_source_audit_SHA256=PREPARED_SOURCE_AUDIT_SHA256,
        current365_eligibility_mask_identities_by_year={year:info['array_identities']['HIGH365_CURRENT_ELIGIBLE'] for year,info in p['years'].items()},
        full_original_prefix_metadata_by_year={year:info['target_prefix_metadata'] for year,info in p['years'].items()})


def policy(preparation_raw,review_sha,prepared_review_sha,native_review_sha,worker_cpus):
    if type(worker_cpus) is not list or worker_cpus!=[4,5] or any(type(x) is not int for x in worker_cpus):
        raise ValueError('EXACT_MAX2_DISTINCT_CPU4_5_WORKERS_REQUIRED')
    return dict(base(preparation_raw),schema=GO_SCHEMA,status='APPROVED_FRESH_EXACT_ALL15',
        action='RUN_FRESH_ORIGINAL_STATIC50_HIGH365_REFERENCE_HOLD_ALL15_FIVE_DEV_PERIODS_CURRENT_D_ONLY',
        requested_worker_count=2,worker_CPUs=[4,5],resource_limits=dict(per_case_wall_seconds=600,per_case_CPU_seconds=600,
            per_case_RSS_stop_bytes=2000000000,per_case_AS_bytes=4000000000,per_case_output_bytes=250000000,
            aggregate_live_worker_RSS_stop_bytes=3500000000,compute_pool_threads_max=1),
        global_inherited_flock_required=True,permanent_cross_output_cell_claim_required=True,
        cohort_disk_safety=dict(minimum_free_bytes=1610612736,maximum_cohort_output_log_temporary_bytes=2800000000,
            external_disk_writers_guaranteed=False,filesystem_quota_guaranteed=False,
            check_cadence='BEFORE_EACH_LAUNCH_AND_EXISTING_0.1_SECOND_POLL'),
        separate_fresh_genesis_claim_namespace=CLAIM_NAMESPACE,shared_CS_CPU45_lease=SHARED_CPU_LEASE,
        shared_CPU45_lease_nonblocking=True,other_controller_overlap_authorized=False,
        target_financial_independent_review_SHA256=c.digest(review_sha),
        prepared_source_target_review_SHA256=c.digest(prepared_review_sha),native_generated_review_SHA256=c.digest(native_review_sha),
        policy_variant='GUARD50_EXIT_ONLY',cost='BASE27',initial_cash_USDT='10000',free_cash_floor_USDT='1000',
        isolated_margin_ceiling_USDT='8500',quantity_profile_SHA256='94b2238b25ed345a24a1fa148c6f35523b8efe9bf47496958028844432cb8ebf',
        source_recapture='EXACT_REVIEWED_FIVE_YEAR_NATIVE_FRAMES_UNCHANGED_SOURCE_GUARD_BEFORE_FINANCE_IMPORT',
        native_source_capture_authorized=True,native_source_read_allowlist='EXACT_QUALIFIED_SOURCE_CONTRACT_READ_FILES_ONLY',
        source_stage_native_capture_authorized=False,source_and_native_capture_capabilities_separate=True,
        calendar_days_by_year={'2021':274,'2022':365,'2023':365,'2024':366,'2025':365},partial2021_annualized=False,
        annual_wallets_compounded=False,quality2024_pinned_recovery_available_us=1723457100000000,
        generated_resource_probe_binding='EXACT_HASH_IN_EXTERNALLY_BOUND_NATIVE_GENERATED_REVIEW',
        complete_original_intrinsic_signal_preserved=True,downward_only_tier_ceilings=True,reexpansion_authorized=False,
        intrinsic_recipe="HALF_EXACT_ORIGINAL_HIGH365_REFERENCE_PLUS_HALF_EXACT_ORIGINAL_HOLD_THEN_ORIGINAL_INTRINSIC_RISK_RETARGET",
        HIGH365_boolean_mask_preserved_exactly=True,older_per_asset365_unavailability_preserved=True,
        original_causal_feature_prefix_separate_from_canonical199_execution_warmup=True,
        current_D_result_equivalence_or_target_byte_execution_reuse_authorized=False,
        literal_funding_event_clocks_preserved=True,funding_clock_rounding_authorized=False,funding_rate_rescale_authorized=False,
        saved_targets_rebuilt_during_finance=False,covariance_rebuilt_during_finance=False,
        actual_provider_iteration_authorized=True,account_construction_authorized=True,financial_execution_authorized=True,
        fresh_genesis_only=True,automatic_retry_authorized=False,halted_snapshot_resume_authorized=False,
        internal_margin_transfers_authorized=False,topup_authorized=False,new_capital_authorized=False,debt_forgiveness_authorized=False,
        old_CS_D_or_plain_V3_GO_reused_as_authority=False,old_financial_scope_or_LoadedInputs_reused=False,
        original_high365_2023_cells_authorized=True,other_cells_or_holdouts_authorized=False,publication_authorized=False)


def prepared_policy(preparation_raw,audit_details_sha,audit_guard_sha):
    p=source_entry.validate_preparation_metadata(preparation_raw)
    return dict(schema=PREPARED_REVIEW_SCHEMA,status='PASS',**base(preparation_raw),
        preparation_bytes=len(preparation_raw),artifact_pins=p['artifacts'],
        array_identities_by_year={year:info['array_identities'] for year,info in p['years'].items()},
        cell_bindings=p['cells'],audit_details_SHA256=c.digest(audit_details_sha),audit_guard_receipt_SHA256=c.digest(audit_guard_sha),
        exact_saved_target_bits_independently_verified=True,source_lineage_independently_verified=True,
        complete_original_intrinsic_signal_preserved=True,downward_only_tier_ceilings=True,
        target_or_covariance_regeneration_in_finance_authorized=False,native_financial_gate_reviewed=False,
        actual_native_source_capture_reviewed=False,financial_execution_authorized=False)


def prepared_review(preparation_raw,raw,expected_sha):
    r=c.checked_external(raw,expected_sha)
    wanted=prepared_policy(preparation_raw,r.get('audit_details_SHA256'),r.get('audit_guard_receipt_SHA256'))
    if c.canonical(r)!=c.canonical(wanted):
        raise ValueError('EXACT_FUTURE_ALL15_PREPARED_SOURCE_TARGET_ARRAY_BITS_REVIEW_REQUIRED')
    return c.immutable(r)


def native_policy(resource_probe_sha):
    return dict(schema=NATIVE_REVIEW_SCHEMA,status='PASS',source_code_manifest_SHA256=SOURCE_CODE_SHA256,
        financial_code_manifest_SHA256=code_identity(),scope_manifest_SHA256=source_entry.manifest_sha(),
        tranche=source_entry.ALL15,ordered_cells=list(source_entry.tranche_cells(source_entry.ALL15)),years=list(source_entry.tranche_years(source_entry.ALL15)),
        native_financial_gate_reviewed=True,financial_execution_authorized=False,actual_source_or_target_bodies_read=False,
        old_CS_D_or_plain_V3_GO_reused_as_authority=False,generated_two_worker_fake_runtime_model_passed=True,worker_CPUs=[4,5],
        maximum_modeled_live_workers=2,actual_CPU45_resource_probe_run=False,annual_historical_resource_envelope_certified=False,generated_resource_probe_SHA256=c.digest(resource_probe_sha),
        shared_CPU45_lease_exclusion_reviewed=True,real_CLI_generated_GO_guard_integration_reviewed=True,
        separate_legacy_claim_namespace_reviewed=True,all_five_year_native_source_seams_reviewed=True,
        all15_generated_saved_cell_tier_selections_reviewed=True,Boolean_mask_dtype_shape_individual_bits_reviewed=True,
        full_original365_prefix_distinct_from_canonical199_reviewed=True,
        cohort_disk_floor_cap_owned_stop_RESOURCE_classification_reviewed=True,
        generated_physical_CPUs_allowed=[6,7],production_worker_CPUs_unchanged=[4,5],
        all15_source_review_is_not_native_authority=True)


def native_review(raw,expected_sha):
    r=c.checked_external(raw,expected_sha)
    if c.canonical(r)!=c.canonical(native_policy(r.get('generated_resource_probe_SHA256'))):
        raise ValueError('EXACT_SEPARATE_LEGACY_NATIVE_GENERATED_REVIEW_REQUIRED')
    return c.immutable(r)


def review_policy(preparation_raw,prepared_review_sha,native_review_sha):
    return dict(base(preparation_raw),schema=REVIEW_SCHEMA,status='PASS',
        prepared_source_target_review_SHA256=c.digest(prepared_review_sha),native_generated_review_SHA256=c.digest(native_review_sha),
        native_financial_gate_reviewed=True,financial_execution_authorized=False,
        real_CLI_generated_GO_guard_integration_reviewed=True,shared_CPU45_lease_exclusion_reviewed=True,
        separate_legacy_fresh_genesis_claims_reviewed=True,old_CS_D_or_plain_V3_GO_reused_as_authority=False,
        original_high365_2023_cells_authorized=True,other_cells_or_holdouts_authorized=False)


def validate(preparation_raw,go_raw,expected_go_sha,review_raw,expected_review_sha,
             prepared_review_raw,expected_prepared_review_sha,native_review_raw,expected_native_review_sha):
    prepared_review(preparation_raw,prepared_review_raw,expected_prepared_review_sha)
    native_review(native_review_raw,expected_native_review_sha)
    r=c.checked_external(review_raw,expected_review_sha)
    if c.canonical(r)!=c.canonical(review_policy(preparation_raw,expected_prepared_review_sha,expected_native_review_sha)):
        raise ValueError('EXACT_NEW_ORIGINAL_HIGH365_NATIVE_FINANCIAL_REVIEW_REQUIRED')
    go=c.checked_external(go_raw,expected_go_sha)
    if c.canonical(go)!=c.canonical(policy(preparation_raw,expected_review_sha,expected_prepared_review_sha,expected_native_review_sha,go.get('worker_CPUs'))):
        raise ValueError('EXACT_NEW_ORIGINAL_HIGH365_ROOT_FINANCIAL_AUTHORITY_REQUIRED')
    return c.immutable(go)
