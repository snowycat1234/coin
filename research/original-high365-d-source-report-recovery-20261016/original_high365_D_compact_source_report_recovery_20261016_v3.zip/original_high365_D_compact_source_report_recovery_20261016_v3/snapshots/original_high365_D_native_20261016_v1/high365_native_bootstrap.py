"""Bind the exact untouched original HIGH365 source graph."""
from pathlib import Path
import sys
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
SOURCE=ROOT/'original_high365_D_source_20261016_v1'
if str(SOURCE) not in sys.path:sys.path.insert(0,str(SOURCE))
import high365_common,high365_config,high365_codec,high365_entry,high365_signal,high365_source,high365_loader,high365_prefix,high365_source_guard
for name in ('high365_common','high365_config','high365_codec','high365_entry','high365_signal','high365_source','high365_loader','high365_prefix','high365_source_guard'):
    if Path(sys.modules[name].__file__).resolve()!=SOURCE/(name+'.py'):
        raise ValueError('EXACT_FROZEN_ORIGINAL_HIGH365_SOURCE_MODULE_IDENTITY_REQUIRED:'+name)
