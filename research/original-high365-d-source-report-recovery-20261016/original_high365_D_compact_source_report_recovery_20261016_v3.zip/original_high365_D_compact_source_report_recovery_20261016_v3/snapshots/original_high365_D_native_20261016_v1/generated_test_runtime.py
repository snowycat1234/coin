"""Generated-only author/reviewer affinity; never imported by production."""
import os


def selected_cpu():
    value = os.environ.get('HIGH365_GENERATED_TEST_CPU', '7')
    if value not in ('6', '7'):
        raise ValueError('GENERATED_TESTS_ONLY_AUTHOR_CPU7_OR_INDEPENDENT_REVIEW_CPU6')
    return int(value)


def pin_generated():
    cpu = selected_cpu()
    os.sched_setaffinity(0, {cpu})
    if sorted(os.sched_getaffinity(0)) != [cpu]:
        raise ValueError('EXACT_GENERATED_TEST_AFFINITY_REQUIRED')
    return cpu
