"""Thin FIRST6 source capture and complete-intrinsic downward target adapter.

No finance, simulator, historical provider, process, claims or cache. Applying
this to actual source bodies requires the separate fresh source stage authority.
"""
from io import BytesIO
from pathlib import Path
import re
import numpy as np
import high365_native_common as c
import high365_native_codec as codec
import high365_config as config
import high365_native_source_scope as entry
import high365_signal as signal


def finite_number(value):
    if type(value) not in (int,float):
        return False
    try:
        return bool(np.isfinite(float(value)))
    except (OverflowError,ValueError,TypeError):
        return False


def funding_events(year,raw,contract):
    period=config.source_year(year);values=c.object_json(raw)
    fields={'symbol','event_us','raw_rate','reported_interval_hours'}
    if type(values) is not list or len(values)!=contract['events']['selected_events']:
        raise ValueError('EXACT_2023_FUNDING_ARRAY_COUNT_REQUIRED')
    for row in values:
        if (type(row) is not dict or set(row)!=fields or row['symbol'] not in config.SYMBOLS
                or type(row['event_us']) is not int or not period['start']<=row['event_us']<period['end']
                or not finite_number(row['raw_rate'])
                or not finite_number(row['reported_interval_hours']) or row['reported_interval_hours']!=8):
            raise ValueError('EXACT_2023_RAW_UNCERTIFIED_SIGNED_FUNDING_SCHEMA_INTERVAL8_REQUIRED')
    if (len({(r['symbol'],r['event_us']) for r in values})!=len(values)
            or values!=sorted(values,key=lambda r:(r['event_us'],r['symbol']))):
        raise ValueError('EXACT_ORIGINAL_FUNDING_IDENTITY_SAMECLOCK_ORDER_REQUIRED')
    return c.immutable(values)


def assemble_inputs(year,warm_raw,daily_raw,events_raw,sidecar_raw,months,contract):
    """Pure codec/quality checks on caller bytes. Does not mint qualification."""
    period=config.source_year(year)
    clocks,close,decisions=codec.daily_inputs(year,warm_raw,daily_raw)
    sidecar=c.exact_object(sidecar_raw)
    events=funding_events(year,events_raw,contract)
    if contract['quality_intervals'] or contract.get('derived_mark_cells')!=0:
        raise ValueError('EXACT_2023_ZERO_DERIVED_QUALITY_REQUIRED')
    # Existing original200 daily proof is bound by its unchanged source pin.
    if c.canonical(sidecar.get('original200_quality'))!=c.canonical(contract['quality_summary']):
        raise ValueError('EXACT_ORIGINAL200_2023_QUALITY_LINEAGE_REQUIRED')
    daily=c.object_json(daily_raw)
    if type(daily) is not list or len(daily)!=period['days']*5:
        raise ValueError('EXACT_2023_DAILY_CORE5_ROW_COUNT_REQUIRED')
    by={}
    for row in daily:
        if (type(row) is not dict or set(row)!={'symbol','close_us','close'}
                or row['symbol'] not in config.SYMBOLS or type(row['close_us']) is not int
                or not period['start']<=row['close_us']<period['end'] or row['close_us']%config.DAY
                or not finite_number(row['close']) or row['close']<=0):
            raise ValueError('EXACT_2023_DAILY_CORE5_SCHEMA_REQUIRED')
        key=(row['close_us'],row['symbol'])
        if key in by:
            raise ValueError('DUPLICATE_DAILY_SOURCE_CELL')
        by[key]=float(row['close'])
    for at in decisions:
        off=int(np.searchsorted(clocks,at))
        for j,symbol in enumerate(config.SYMBOLS):
            if np.float64(by.get((int(at),symbol),np.nan)).tobytes()!=close[off,j].tobytes():
                raise ValueError('EXACT_2023_WARM_DAILY_CLOSE_BIT_PARITY_REQUIRED')
    if len(months)!=len(contract['months']):
        raise ValueError('EXACT_CANONICAL_MONTH_COUNT_REQUIRED')
    cursor=period['start'];final=None
    for rec,(name,raw) in zip(contract['months'],months,strict=True):
        if (name!=rec['path'] or c.sha(raw)!=rec['hash'] or len(raw)!=rec['size']
                or rec['start']+rec['lo']*codec.MINUTE!=cursor
                or not 0<=rec['lo']<rec['hi']<=rec['count']):
            raise ValueError('EXACT_PINNED_NATIVE_MONTH_IDENTITY_REQUIRED')
        arrays,missing=codec.month_arrays(year,raw,rec['start'],rec['count'])
        if missing:
            raise ValueError('NO_2023_DERIVED_MARK_CELLS_ALLOWED')
        for at in range(rec['start']+config.DAY,rec['start']+rec['count']*codec.MINUTE+1,config.DAY):
            if not period['start']<=at<period['end']:
                continue
            k=int(np.searchsorted(clocks,at));off=(at-rec['start'])//codec.MINUTE-1
            for j,symbol in enumerate(config.SYMBOLS):
                if arrays[symbol+'_close'][off].tobytes()!=close[k,j].tobytes():
                    raise ValueError('EXACT_NATIVE_DAILY_CLOSE_BIT_PARITY_REQUIRED')
        final=arrays;cursor=rec['start']+rec['hi']*codec.MINUTE
    if cursor!=period['end'] or final is None:
        raise ValueError('EXACT_FULL_2023_EXECUTION_AND_CLOSING_CALENDAR_REQUIRED')
    endpoint={symbol:float(final[symbol+'_close'][-1]) for symbol in config.SYMBOLS}
    rows=tuple(dict(symbol=symbol,close_us=int(at),available_us=int(at),close=float(close[i,j]))
               for i,at in enumerate(clocks) for j,symbol in enumerate(config.SYMBOLS))
    quality=dict(schema='LEGACY_INTRINSIC_REUSED_QUALIFIED_2023_SOURCE_QUALITY_V1',year=year,
        calendar=[period['start'],period['end']],qualified_source_identity=contract['source_identity'],
        original_quality_sidecar_SHA256=c.sha(sidecar_raw),original_quality_sidecar=sidecar,
        cells=[],quality_intervals=[],derived_mark_cells=0,final_endpoint_close=endpoint,
        source_completion_is_not_arrival_certification=True,arrival_status='UNKNOWN_NOT_CERTIFIED',
        original_source_age_and_arrival_flags_preserved=True,
        actual_legacy_event_and_position_impacts='PENDING_NEW_LEGACY_SAVED_EXECUTION_NOT_INHERITED_FROM_D',
        certifies_liquidation=False,certifies_no_liquidation=False,
        funding_ownership='CURRENT_NATIVE_ACTUAL_QUANTITY_ONLY_AFTER_PAID_FILLS',
        funding_rate_unit='UNCONFIRMED_PRESERVED_NO_RESCALE')
    return dict(year=year,period=period,clocks=clocks,close=close,decisions=decisions,
        source_rows=c.immutable(rows),events=events,months=tuple(months),quality_cells=(),quality_intervals=(),
        sidecar=c.immutable(quality),sidecar_raw=c.canonical(quality)+b'\n',
        source_identity=contract['source_identity'],contract=c.immutable(contract))

