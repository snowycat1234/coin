"""Seal only code/metadata closure. No market/prepared bodies or runtime claims."""
from hashlib import sha256
import ast,json
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
SOURCE=ROOT/'original_high365_D_source_20261016_v1'
PRIOR=ROOT/'legacy_intrinsic_D_remaining24_native_20261015_v2'
FIRST=ROOT/'legacy_intrinsic_D_native_20261015_v1'
def pin(path):
    raw=path.read_bytes();return dict(SHA256=sha256(raw).hexdigest(),bytes=len(raw))
def functions(path):
    return {n.name:sha256(ast.dump(n,include_attributes=False).encode()).hexdigest() for n in ast.parse(path.read_text()).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
def seal():
    old=json.loads((PRIOR/'FINANCIAL_CODE_MANIFEST.json').read_bytes())
    src=json.loads((SOURCE/'CODE_MANIFEST.json').read_bytes())
    # Prior numerical/account primitives are code dependencies, not authority.
    deps={n:v for n,v in old['dependencies'].items() if not any(x in n for x in ('independent_review','legacy_intrinsic_D_20261015_v1/','legacy_intrinsic_D_remaining24_source_'))}
    deps.update(src['dependencies'])
    for directory,manifest in ((SOURCE,src),(PRIOR,old)):
        deps[directory.name+('/CODE_MANIFEST.json' if directory==SOURCE else '/FINANCIAL_CODE_MANIFEST.json')]=pin(directory/('CODE_MANIFEST.json' if directory==SOURCE else 'FINANCIAL_CODE_MANIFEST.json'))
        for n in manifest['files']:
            deps[directory.name+'/'+n]=pin(directory/n)
    for directory,names in ((FIRST,('legacy_native.py','legacy_saved.py','run_legacy.py','FINANCIAL_CODE_MANIFEST.json')),
        (ROOT/'legacy_intrinsic_D_20261015_v1',('legacy_source.py','legacy_codec.py')),
        (ROOT/'cs_saved_calendar_exact_20261015_v1',('cs_saved_calendar.py',)),
        (ROOT/'original_high365_D_prepared_independent_review_20261016_v1',('PREPARED_INDEPENDENT_REVIEW.json','OBSERVED_AUDIT_GUARD_RECEIPT.json','SOURCE_ONLY_AUDIT_DETAIL.json','AUDIT_FILE_RECEIPTS.json','EXACT_TARGET_EQUALITY_METADATA.json'))):
        for n in names:deps[directory.name+'/'+n]=pin(directory/n)
    for n,want in deps.items():
        if Path(n).suffix not in ('.py','.json','.md','.txt') or '/EXECUTION_CLAIMS/' in n or pin(ROOT/n)!=want:
            raise ValueError('CODE_METADATA_ONLY_EXACT_DEPENDENCY:'+n)
    provenance={}
    for own,origin,names in (
        ('high365_native_codec.py',PRIOR/'legacy_native_codec.py',('npz','daily_inputs','mark2024','month_arrays')),
        ('high365_native_source.py',PRIOR/'legacy_native_source.py',('funding_events','qualified_terminal_witness_2021','assemble_inputs','capture_year')),
        ('high365_native_source2023.py',ROOT/'legacy_intrinsic_D_20261015_v1/legacy_source.py',('finite_number','funding_events','assemble_inputs')),
        ('high365_native_source_bridge.py',PRIOR/'legacy_native_source_bridge.py',('parse_original_zip','verify_normalized_numeric_bits','capture_2022')),
        ('high365_native_quality.py',PRIOR/'legacy_native_quality.py',('original_quality','quality_cells_2022','intervals')),
        ('high365_saved.py',ROOT/'cs_saved_calendar_exact_20261015_v1/cs_saved_calendar.py',('admitted_calendar_minutes','saved_minute')),
        ('high365_process_runtime.py',PRIOR/'legacy_process_runtime.py',('classify_terminal','run_pool','controller_lease','claim_launch'))):
        a,b=functions(HERE/own),functions(origin)
        provenance[own]=dict(origin=str(origin.relative_to(ROOT)),origin_file=pin(origin),functions={n:dict(new_AST_SHA256=a[n],origin_AST_SHA256=b[n],AST_unchanged=a[n]==b[n]) for n in names})
    (HERE/'REUSED_FUNCTION_MAP.json').write_text(json.dumps(provenance,indent=2,sort_keys=True)+'\n')
    names={p.name for p in HERE.glob('*.py')}|{'FROZEN_FIFTEEN_CELL_MANIFEST.json','NATIVE_PROCESS_PROVENANCE.json','REUSED_FUNCTION_MAP.json','README.md'}
    manifest=dict(schema='ADDITIVE_ORIGINAL_HIGH365_ALL15_NATIVE_FINANCIAL_CODE_V1',
        status='CODE_GENERATED_ONLY_REQUIRES_INDEPENDENT_REVIEW_AND_FRESH_FINANCIAL_GO',
        source_code_manifest_SHA256='a03588282511ae41462f3a1d95aac99a28496a3d4dbd5f3c869ac45bc2fe4799',
        files={n:pin(HERE/n) for n in sorted(names)},dependencies=deps,
        runtime_dependency_exclusions=['CS_FAILED_CLAIMS','CS_SUPERSESSION_PACKETS','CS_ROOT_GO','PLAIN_V3_ROOT_GO'])
    (HERE/'FINANCIAL_CODE_MANIFEST.json').write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n')
    print(json.dumps(pin(HERE/'FINANCIAL_CODE_MANIFEST.json')))
if __name__=='__main__':seal()
