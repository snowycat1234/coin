"""Generated five-year seams and unchanged native D comparison checks."""
from copy import deepcopy
import ast
from pathlib import Path
import unittest
from unittest.mock import patch
import high365_native_bootstrap
import high365_native_common as c
import high365_config as config
import high365_source_entry as entry
import high365_native_source_scope as source_scope
import high365_native_source as native_source
import high365_native_quality as quality
import high365_native_codec as codec
class NativeYearQualityTests(unittest.TestCase):
    def test_ten_derived_cells_unknown_before_risk_and_installed_recovery_all_tiers(self):
        import high365_native_generated as g
        from types import MethodType
        from test_high365_native import marks
        native=g.native_reference()
        for tier in config.TIERS:
            with g.generated_fixture(days=1) as fixture:
                targets=g.project_generated(fixture)
                start=int(fixture.decisions[0]);first=start+2*native.MINUTE;end=first+2*native.MINUTE
                sim,guard=g.construct_generated_case(targets,tier,quality_intervals=((first,end,native.S),))
                account=sim.account;marks(account,first-native.MINUTE)
                account.execute_fill('BTCUSDT','SELL','.02',first-native.MINUTE+1,start,'GENERATED_2024_SHAPE',
                    execution_mid_price='50000',quote_available_us=first-native.MINUTE,available_quantity='.02')
                seen=[];risk=account._risk
                def observed(_account,phase):
                    seen.append(tuple(_account.mark_quality[s] for s in native.S));return risk(phase)
                account._risk=MethodType(observed,account)
                quality=guard.causal_mark_quality_guard
                for at in (first,first+native.MINUTE):
                    marks(account,at,75000)
                    self.assertEqual([account.mark_quality[s] for s in native.S],['UNKNOWN_OR_DERIVED']*5)
                    self.assertFalse(account.can_increase(at));self.assertIsNotNone(quality.quality_witness(at))
                    account.monitor('MONITOR:'+str(at),at);self.assertFalse(account.pending_exits)
                del account._risk
                self.assertTrue(seen);self.assertTrue(all(x==('UNKNOWN_OR_DERIVED',)*5 for x in seen))
                self.assertIsNotNone(quality.quality_witness(end+native.MINUTE))
                marks(account,end,75000)
                self.assertIsNone(quality.quality_witness(end));account.monitor('MONITOR:'+str(end),end)
                self.assertEqual(account.pending_exits['BTCUSDT']['reason'],'GUARD50_PAID_EXIT_NO_TOPUP')
                self.assertFalse(account.transfer_journal)
                self.assertEqual(len(quality.identity['intervals']),1)
                self.assertEqual(quality.identity['intervals'][0]['original_genuine_observation_us'],first-native.MINUTE)

    def test_original_D_generic_interval_native_finance_exact_all_tiers(self):
        import importlib.util,sys
        import high365_native_generated as g
        from test_high365_native import finance
        native=g.native_reference()
        path=c.ROOT/'bounded_native_continuation_guard50_exit_expansion_20261015/expansion.py'
        manifest=c.exact_object((c.HERE/'FINANCIAL_CODE_MANIFEST.json').read_bytes())
        record=manifest['dependencies'][str(path.relative_to(c.ROOT))]
        c.exact(path,record['SHA256'],record['bytes'])
        name='_remaining9_exact_original_D_generic_quality_reference'
        spec=importlib.util.spec_from_file_location(name,path);reference=importlib.util.module_from_spec(spec)
        sys.modules[name]=reference;spec.loader.exec_module(reference)
        with g.generated_fixture(days=1) as fixture:
            targets=g.project_generated(fixture);window,rows,decisions=g._synthetic_window(fixture)
            first=int(decisions[0])+native.MINUTE;intervals=((first,first+2*native.MINUTE,native.S),)
            for tier in config.TIERS:
                new,ng=g.construct_generated_case(targets,tier,quality_intervals=intervals)
                old,og=reference.construct_case(window,rows,decisions,targets.common_tier[tier],
                    generated_scope=native.GENERATED,tier_name=tier,quality_intervals=intervals)
                for sim in (new,old):
                    while sim.cursor<sim.end and sim.stop is None:sim.advance_day()
                self.assertEqual(finance(new.account),finance(old.account))
                self.assertEqual(new.pending,old.pending)
                self.assertEqual(new.result()['minute'].to_numpy().tobytes(),old.result()['minute'].to_numpy().tobytes())
                self.assertEqual(ng.causal_mark_quality_guard.identity,og.causal_mark_quality_guard.identity)
                self.assertGreater(len(new.account.trades),0)
                result=native.case_result(new,ng);result.pop('minute');result['targets']=result['targets'].to_dicts()
                result=native.V2.OWNED.export_tree(result);audit=native.V2.OWNED.export_tree(new.account.snapshot())
                from saved_native_reconciliation import reconcile_saved_native
                proof=reconcile_saved_native(audit,result,expected_continuation_version=native.VERSION)
                self.assertTrue(proof['passed']);self.assertFalse(proof['tolerance_or_epsilon_used'])

    def test_saved_quality_identity_uses_exact_2024_generic_interval_and_no_cells(self):
        import high365_saved as cs_saved
        sidecar=dict(year=2024,cells=[],qualified_source_identity='a'*64,arrival_status='UNKNOWN_NOT_CERTIFIED',
            original_source_age_and_arrival_flags_preserved=True,actual_CS_event_impacts='PENDING_CS_SAVED_EXECUTION',
            actual_CS_position_interval_impacts='PENDING_CS_SAVED_EXECUTION_NOT_INHERITED_FROM_D',
            quality_intervals=[[1723456980000000,1723457100000000,list(config.cell_named(entry.tranche_cells(entry.ALL15)[0]).get('symbols',()))]])
        import high365_signal as cs_signal
        sidecar['quality_intervals'][0][2]=list(cs_signal.SYMBOLS)
        info=dict(quality_cells_SHA256=c.jsha([]),source_identity='a'*64,source_quality_sidecar_SHA256='b'*64)
        identity=cs_saved.quality_identity(sidecar,info,'FAKE_GENERATED_VERSION')
        self.assertEqual(identity['intervals'][0]['original_genuine_observation_us'],1723456920000000)
        self.assertNotIn('source_clock_cells',identity)

class SeparateCapabilityTests(unittest.TestCase):
    def test_frozen_source_identity_and_exact_fifteen_single_recipe_cells(self):
        self.assertEqual(entry.code_identity(),'a03588282511ae41462f3a1d95aac99a28496a3d4dbd5f3c869ac45bc2fe4799')
        self.assertEqual(entry.tranche_years(entry.ALL15),(2023,2024,2025,2021,2022))
        self.assertEqual(len(entry.tranche_cells(entry.ALL15)),15)
        self.assertEqual(config.RECIPES,('STATIC50_HIGH365_REFERENCE_HOLD',))
        for year in (2021,2022,2023,2024,2025):
            self.assertEqual(len([cell for cell in entry.tranche_cells(entry.ALL15) if config.cell_named(cell)['year']==year]),3)
        self.assertEqual(config.source_year(2021)['days'],274)
        self.assertEqual(config.source_year(2024)['days'],366)
    def test_native_scope_and_old_source_scope_do_not_alias(self):
        self.assertIsNot(source_scope.SourcePreparationScope,entry.High365SourcePreparationScope)
        self.assertFalse(source_scope._LIVE)
        with patch.object(c,'exact',side_effect=AssertionError('NO_BODY_READ')):
            for value in (None,object(),{},entry.High365SourcePreparationScope):
                with self.assertRaises(ValueError):
                    with source_scope.admit_capture(value,year=2022):pass
                with self.assertRaises(ValueError):native_source.capture_year(2022,value)
            for year in (2020,2026,True,'2022'):
                with self.assertRaises(ValueError):
                    with source_scope.admit_capture(None,year=year):pass
        self.assertFalse(source_scope._LIVE)
    def test_five_year_native_allowlists_are_distinct_from_saved_source_input_scope(self):
        for year,record in entry.contracts()['years'].items():
            saved=set(record['read_files']);native=set(source_scope.contracts()['years'][year]['read_files'])
            self.assertFalse(saved & native)
            self.assertNotEqual(saved,native)
            self.assertFalse(any('TARGETS' in name or 'EXECUTION_CLAIMS' in name or 'ROOT_GO' in name for name in native))
    def test_reviewed_pure_transport_function_bodies_unchanged(self):
        origin=c.ROOT/'original_cs_mom21_D_remaining9_financial_20261015_v1'
        for new,old,names in (
            ('high365_native_codec.py','cs_codec.py',('daily_inputs','month_arrays','mark2024','npz')),
            ('high365_native_quality.py','cs_quality.py',('original_quality','quality_cells_2022','intervals')),
            ('high365_native_source.py','cs_source.py',('funding_events','qualified_terminal_witness_2021','assemble_inputs')),
            ('high365_native_source_bridge.py','cs_source_bridge.py',('parse_original_zip','verify_normalized_numeric_bits','capture_2022'))):
            def functions(path):return {n.name:n for n in ast.parse(path.read_text()).body if isinstance(n,ast.FunctionDef)}
            actual,wanted=functions(c.HERE/new),functions(origin/old)
            for name in names:
                node=actual[name]
                if new=='high365_native_source.py' and name=='assemble_inputs':
                    dispatch=ast.parse('if year == 2023:\n from high365_native_source2023 import assemble_inputs as original2023\n return original2023(year,warm_raw,daily_raw,events_raw,sidecar_raw,months,contract)').body[0]
                    self.assertEqual(ast.dump(node.body[1]),ast.dump(dispatch))
                    node=deepcopy(node);node.body.pop(1)
                self.assertEqual(ast.dump(node),ast.dump(wanted[name]),(new,name))
    def test_2022_literal_fractional_clocks_and_true_intervals_unscaled(self):
        contract=deepcopy(source_scope.contracts()['years']['2022']);start=config.source_year(2022)['start']
        events=[dict(symbol=s,event_us=start+15001,raw_rate=(-1 if j%2 else 1)*.00013,
            reported_interval_hours=(2,4,8,2,8)[j],raw_rate_unit='UNCONFIRMED') for j,s in enumerate(config.SYMBOLS)]
        contract['events']['selected_events']=5
        actual=native_source.funding_events(2022,c.canonical(events),contract,normalized_2022=True)
        self.assertEqual(c.plain(actual),events)
        self.assertTrue(all(row['event_us']%1000==1 for row in actual))
        self.assertEqual([row['reported_interval_hours'] for row in actual],[2,4,8,2,8])
