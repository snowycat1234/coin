"""Invented in-memory five-year source, long-prefix and target storage only."""
from contextlib import contextmanager
from copy import deepcopy
from io import BytesIO
from unittest.mock import patch
import zipfile
import numpy as np
import high365_native_bootstrap
import high365_native_common as c
import high365_common as source_c
import high365_config as config
import high365_source_entry as entry
import high365_source as source
import high365_signal as signal
import high365_prefix as prefix
import high365_generated as generated
import high365_finance_gate as gate

def install_generated_missing365_prefix(year, contract, storage):
    """Only invented older history varies; canonical199 and HOLD stay exact."""
    pc = contract['original_target_prefix']
    key = str(source_c.ROOT / pc['wrapper']['path'])
    with zipfile.ZipFile(BytesIO(storage[key])) as outer:
        blob = outer.read(pc['member']['name'])
    with np.load(BytesIO(blob), allow_pickle=False) as member:
        clocks = member['close_available_us'].copy()
        close = member['close'].copy()
    first = config.source_year(year)['start']
    for symbol_index, age in ((2, 300), (4, 270)):
        matches = np.flatnonzero(clocks == first - age * config.DAY)
        if len(matches) != 1:
            raise AssertionError('INVENTED_OLDER_365_PREFIX_ROW_REQUIRED')
        close[int(matches[0]), symbol_index] = np.nan
    stream = BytesIO()
    np.savez_compressed(stream, symbol_order=np.asarray(config.SYMBOLS),
        close_available_us=clocks, close=close,
        UNSELECTED_TARGET_OBJECT=np.array([object()], dtype=object))
    blob = stream.getvalue(); wrapped = BytesIO()
    with zipfile.ZipFile(wrapped, 'w', compression=zipfile.ZIP_DEFLATED) as outer:
        outer.writestr(pc['member']['name'], blob)
    raw = wrapped.getvalue(); storage[key] = raw
    pc['member'].update(SHA256=c.sha(blob), bytes=len(blob))
    pc['wrapper'].update(SHA256=c.sha(raw), bytes=len(raw))
    contract['read_files'][pc['wrapper']['path']] = dict(SHA256=c.sha(raw), bytes=len(raw))

def source_and_targets(year,contract,raw,storage):
    value=source.decode_capture(year,raw,contract)
    pc=contract['original_target_prefix'];blob=storage[str(source_c.ROOT/pc['wrapper']['path'])]
    selected,proof=prefix.select_prefix(blob,pc,year)
    prefix.validate_canonical_parity(selected,value)
    value.update(target_prefix=selected,target_prefix_metadata=proof)
    arrays,proofs=signal.build_target_grid(selected['close'],selected['clocks'],selected['clocks'],value['decisions'])
    return value,arrays,proofs

def artifact_set(year,raw,value,arrays,proofs):
    pre=str(year)+'/'
    result={pre+name:body for name,body in raw.items()}
    result.update({pre+'SOURCE_ROWS.json':c.canonical(value['source_rows'])+b'\n',
        pre+'TARGETS.npz':source.target_blob(arrays),pre+'TARGET_PROOFS.json':c.canonical(proofs)+b'\n',
        pre+'SOURCE_PREFIX_INPUTS.npz':source.target_blob(dict(close_available_us=value['target_prefix']['clocks'],close=value['target_prefix']['close']))})
    return result

@contextmanager
def installed_fixture():
    with generated.installed_fake_storage() as (contracts,storage), patch.object(entry,'contract_sha',side_effect=lambda:c.jsha(contracts)):
        for year in entry.tranche_years(entry.ALL15):
            install_generated_missing365_prefix(year, contracts['years'][str(year)], storage)
        artifacts={};years={};cells={};captured={}
        sg,gs,sr,rs=generated.authority()
        for year in entry.tranche_years(entry.ALL15):
            contract=contracts['years'][str(year)]
            raw={name:storage[str(source_c.ROOT/pin['path'])] for name,pin in contract['artifacts'].items()}
            value,arrays,proofs=source_and_targets(year,contract,raw,storage)
            artifacts.update(artifact_set(year,raw,value,arrays,proofs));years[str(year)]=source.year_info(value,arrays)
            for cell_id in entry.tranche_cells(entry.ALL15):
                cell=config.cell_named(cell_id)
                if cell['year']!=year:continue
                binding=entry.binding_from_info(cell,years[str(year)],gs,rs)
                cells[cell_id]=dict(descriptor=cell,input_binding=binding,input_binding_SHA256=c.jsha(binding))
            captured[year]=value
        artifacts['SOURCE_STAGE_AUTHORIZATION.json']=sg;artifacts['SOURCE_INDEPENDENT_REVIEW.json']=sr
        prep=dict(schema=entry.PREPARATION_SCHEMA,candidate=config.CANDIDATE,adaptation_version=config.VERSION,tranche=entry.ALL15,
            ordered_cells=list(entry.tranche_cells(entry.ALL15)),years=years,cells=cells,code_manifest_SHA256=entry.code_identity(),
            scope_manifest_SHA256=entry.manifest_sha(),source_contract_map_SHA256=entry.contract_sha(),source_stage_GO_SHA256=gs,source_review_SHA256=rs,
            artifacts={name:dict(SHA256=c.sha(body),bytes=len(body)) for name,body in artifacts.items()},historical_admission=False,financial_runs=0,
            accounts_created=0,accounts_advanced=0,provider_iterations=0,process_launches=0,canonical_claims_created=0,real_financial_GO_written=0,publication_actions=0)
        raw=c.canonical(prep);entry.validate_preparation_metadata(raw)
        yield raw,artifacts,captured

def bundle(preparation_raw):
    pr=c.canonical(gate.prepared_policy(preparation_raw,'1'*64,'2'*64));nr=c.canonical(gate.native_policy('0'*64))
    rr=c.canonical(gate.review_policy(preparation_raw,c.sha(pr),c.sha(nr)))
    go=c.canonical(gate.policy(preparation_raw,c.sha(rr),c.sha(pr),c.sha(nr),[4,5]))
    sg,_,sr,_=generated.authority()
    raw={'go':go,'review':rr,'prepared-review':pr,'native-review':nr,'source-go':sg,'source-review':sr}
    return raw,{name:c.sha(body) for name,body in raw.items()}

def validate(prep,raw):
    return gate.validate(prep,raw['go'],c.sha(raw['go']),raw['review'],c.sha(raw['review']),
        raw['prepared-review'],c.sha(raw['prepared-review']),raw['native-review'],c.sha(raw['native-review']))

@contextmanager
def installed_native_fixture(year):
    """Upgrade one invented year through exact native assembly and original prefix."""
    from generated_native_source_fixture import fake_source,pack
    import high365_native_source as native_source
    with generated.installed_fake_storage() as (contracts,storage):
        parts=list(fake_source(year));value=native_source.assemble_inputs(*parts)
        contract=contracts['years'][str(year)];contract['qualified_source_contract']=parts[6]
        contract['source_identity']=value['source_identity']
        raw={'SOURCE_INPUTS.npz':pack(close_available_us=value['clocks'],close=value['close']),
             'RAW_EVENTS.json':c.canonical(value['events'])+b'\n','MINUTE_MARK_PROVENANCE.json':value['sidecar_raw']}
        if year==2022:
            raw['NORMALIZATION_EQUIVALENCE.json']=c.canonical(dict(twelve_exact_old_container_hashes=True,
                source_to_serialized_numeric_bits=True,normalized_months_persisted=False,historical_execution_authorized=False))+b'\n'
            value['normalization_equivalence']=c.object_json(raw['NORMALIZATION_EQUIVALENCE.json'])
        for name,body in raw.items():
            pin=contract['artifacts'][name];pin.update(SHA256=c.sha(body),bytes=len(body));storage[str(source_c.ROOT/pin['path'])]=body
        contract['source_metadata'].update(source_rows_SHA256=c.jsha(value['source_rows']),funding_events_SHA256=c.jsha(value['events']),
            quality_cells_SHA256=c.jsha(value['sidecar']['cells']),source_quality_sidecar_SHA256=c.sha(value['sidecar_raw']))
        tc,pc=value['clocks'],value['close'];extra=200
        older=tc[0]-np.arange(extra,0,-1,dtype=np.int64)*config.DAY
        before=np.column_stack([100+j*20+np.sin(np.arange(extra)/(7+j)+j)*.2 for j in range(5)])
        ft=np.r_[older,tc,tc[-1]+config.DAY,tc[-1]+2*config.DAY];fp=np.vstack([before,pc,np.full((2,5),np.nan)])
        prefix_contract=contract['original_target_prefix']
        member=pack(symbol_order=np.asarray(config.SYMBOLS),close_available_us=ft,close=fp,UNSELECTED_TARGET_OBJECT=np.array([object()],dtype=object))
        out=BytesIO()
        with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED) as z:z.writestr(prefix_contract['member']['name'],member)
        wrapper=out.getvalue();prefix_contract['member'].update(SHA256=c.sha(member),bytes=len(member))
        prefix_contract['wrapper'].update(SHA256=c.sha(wrapper),bytes=len(wrapper));storage[str(source_c.ROOT/prefix_contract['wrapper']['path'])]=wrapper
        contract['read_files']={pin['path']:dict(SHA256=pin['SHA256'],bytes=pin['bytes']) for pin in contract['artifacts'].values()}
        contract['read_files'][prefix_contract['wrapper']['path']]=dict(SHA256=c.sha(wrapper),bytes=len(wrapper))
        # The fixture context recreates contracts/storage. Temporarily share this
        # invented graph, then invoke the ordinary full five-year builder.
        from contextlib import contextmanager
        @contextmanager
        def use_memory():yield contracts,storage
        with patch.object(entry,'contract_sha',side_effect=lambda:c.jsha(contracts)),patch.object(generated,'installed_fake_storage',use_memory):
            with installed_fixture() as (prep,artifacts,captured):
                captured[year]=value
                yield prep,artifacts,captured,tuple(parts)
