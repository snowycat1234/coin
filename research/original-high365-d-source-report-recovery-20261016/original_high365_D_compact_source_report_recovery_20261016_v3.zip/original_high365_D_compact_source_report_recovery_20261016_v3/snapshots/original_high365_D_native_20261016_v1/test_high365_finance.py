"""Fake metadata, sealed generated accounts, and temporary claim tests only."""
from copy import deepcopy
from decimal import localcontext
from io import BytesIO
from pathlib import Path
import fcntl
import os
import tempfile
import unittest
from unittest.mock import patch
import zipfile
import numpy as np
import high365_native_bootstrap
import high365_native_common as c
import high365_config as config
import high365_source_entry as entry
import high365_finance_gate as gate
import high365_input_loader as loader
import high365_verified_wires as verified
import high365_process_runtime as r
import high365_claims as claims
import high365_saved as saved
from generated_financial_fixture import installed_fixture,bundle,validate

class AdmissionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls._fixture_context=installed_fixture();cls.prep,cls.artifacts,cls.captured=cls._fixture_context.__enter__();cls.raw,cls.hashes=bundle(cls.prep)
    @classmethod
    def tearDownClass(cls):cls._fixture_context.__exit__(None,None,None)
    def tearDown(self):self.assertFalse(verified._LIVE);self.assertFalse(loader._LIVE);self.assertFalse(entry._ACTIVE_SOURCE)
    def test_full_fake_metadata_positive_is_immutable(self):
        value=validate(self.prep,self.raw);self.assertEqual(value['worker_CPUs'],(4,5))
        with self.assertRaises(TypeError):value['cost']='OTHER'
    def test_every_missing_and_extra_wire_field_denied(self):
        for name in ('go','review','prepared-review','native-review'):
            original=c.exact_object(self.raw[name])
            for key in list(original)+['EXTRA_EXECUTABLE_AUTHORITY']:
                changed=deepcopy(self.raw);bad=deepcopy(original)
                if key in bad:bad.pop(key)
                else:bad[key]=True
                changed[name]=c.canonical(bad)
                with self.subTest(name=name,key=key),self.assertRaises(ValueError):validate(self.prep,changed)
    def test_resealed_policy_changes_and_cross_domain_authority_denied(self):
        for key,value in (('worker_CPUs',[4,4]),('cost','STRESS43'),('reexpansion_authorized',True),
            ('funding_clock_rounding_authorized',True),('fresh_genesis_only',False),('other24_cells_authorized',True),
            ('separate_fresh_genesis_claim_namespace','CS_OLD'),('shared_CPU45_lease_nonblocking',False),('initial_cash_USDT','9999')):
            raw=deepcopy(self.raw);go=c.exact_object(raw['go']);go[key]=value;raw['go']=c.canonical(go)
            with self.subTest(key=key),self.assertRaises(ValueError):validate(self.prep,raw)
        for target in ('go','review','native-review'):
            raw=deepcopy(self.raw);raw[target]=raw['source-go']
            with self.subTest(target=target),self.assertRaises(ValueError):validate(self.prep,raw)
    def test_external_digest_duplicate_keys_and_bool_integer_denied(self):
        with self.assertRaises(ValueError):gate.validate(self.prep,self.raw['go'],'a'*64,self.raw['review'],self.hashes['review'],
            self.raw['prepared-review'],self.hashes['prepared-review'],self.raw['native-review'],self.hashes['native-review'])
        with self.assertRaises(ValueError):c.exact_object(b'{"x":1,"x":2}')
        raw=deepcopy(self.raw);go=c.exact_object(raw['go']);go['requested_worker_count']=True;raw['go']=c.canonical(go)
        with self.assertRaises(ValueError):validate(self.prep,raw)
    def test_old_source_loaded_or_ducktype_inputs_never_admit(self):
        import high365_admission as a
        for value in (None,object(),{'year':2023},config.cells()[0]):
            with self.subTest(value=type(value).__name__),self.assertRaises(ValueError):a.CapturedMinuteProvider(2023,value)
        with patch.object(c,'exact',side_effect=AssertionError('NO_READ')),self.assertRaisesRegex(ValueError,'SOURCE_GUARD_REQUIRED'):
            loader.load_year('/GENERATED',expected_preparation_sha256='a'*64,year=2023,
                source_go_raw=b'{}',expected_source_go_sha256='a'*64,source_review_raw=b'{}',expected_source_review_sha256='b'*64,
                financial_go_raw=b'{}',expected_financial_go_sha256='c'*64,financial_review_raw=b'{}',expected_financial_review_sha256='d'*64,
                prepared_review_raw=b'{}',expected_prepared_review_sha256='e'*64,native_review_raw=b'{}',expected_native_review_sha256='f'*64)
    def test_authority_failure_before_lease_claim_or_spawn(self):
        import run_high365
        with patch.object(run_high365,'wires',side_effect=ValueError('GENERATED_DENIED')),patch.object(r,'controller_lease') as lease,\
             patch.object(r,'claim_launch') as claim,patch.object(r.subprocess,'Popen') as spawn:
            with self.assertRaisesRegex(ValueError,'GENERATED_DENIED'):run_high365.controller(object())
        lease.assert_not_called();claim.assert_not_called();spawn.assert_not_called()
    def test_out_of_scope_claims_denied_before_lease(self):
        for cell in ('2023_STATIC50_OLD_NO_REEXPANSION_LOW_D_INTRINSIC_LOWER_ONLY_V1',
                     '2026_STATIC50_HIGH365_REFERENCE_HOLD_LOW_D_INTRINSIC_LOWER_ONLY_V1'):
            with self.subTest(cell=cell),self.assertRaisesRegex(ValueError,'ALL15'):claims.reserve(cell_id=cell,metadata={},go={})
        for cell in config.cells():
            with self.subTest(cell=cell['cell_id']),self.assertRaisesRegex(ValueError,'EXACT_NEW_ORIGINAL_HIGH365'):
                claims.reserve(cell_id=cell['cell_id'],metadata={},go={})
    def test_manifest_has_no_CS_claim_or_recovery_dependency(self):
        m=c.exact_object((c.HERE/'FINANCIAL_CODE_MANIFEST.json').read_bytes())
        self.assertFalse(any('/EXECUTION_CLAIMS/' in n or 'FAILED_ATTEMPT' in n or 'SUPERSESSION' in n or n.startswith('original_cs_mom21_D_20261015_v5') for n in m['dependencies']))
        self.assertEqual(entry.code_identity(),gate.SOURCE_CODE_SHA256)

class ClaimAndResourceTests(unittest.TestCase):
    def test_nonblocking_shared_lock_and_permanent_legacy_claim(self):
        with tempfile.TemporaryDirectory(prefix='LEGACY_GENERATED_CLAIM_ONLY_') as td:
            root=Path(td);shared=root/'FAKE_SHARED_CPU45.lock';shared.touch();registry=root/'EXECUTION_CLAIMS'
            held=os.open(shared,os.O_RDWR);fcntl.flock(held,fcntl.LOCK_EX|fcntl.LOCK_NB)
            with patch.object(r,'shared_resource_lease_path',return_value=shared),self.assertRaisesRegex(RuntimeError,'SHARED_CS_CPU45'):
                with r.controller_lease(registry):self.fail('OVERLAP')
            self.assertFalse(registry.exists());os.close(held)
            with patch.object(r,'shared_resource_lease_path',return_value=shared),patch.object(claims,'registry_root',return_value=registry):
                with r.controller_lease(registry):
                    cell=entry.tranche_cells(entry.ALL15)[0]
                    go=dict(separate_fresh_genesis_claim_namespace=claims.STABLE_REGISTRY_REL,shared_CS_CPU45_lease=gate.SHARED_CPU_LEASE,
                            shared_CPU45_lease_nonblocking=True,fresh_genesis_only=True,automatic_retry_authorized=False)
                    path=claims.reserve(cell_id=cell,metadata={'generated_claim_only':True},go=go)
                    before=path.read_bytes()
                    with self.assertRaisesRegex(RuntimeError,'PERMANENT'):claims.reserve(cell_id=cell,metadata={},go=go)
                    self.assertEqual(path.read_bytes(),before)
                    second=os.open(shared,os.O_RDWR)
                    try:
                        with self.assertRaises(BlockingIOError):fcntl.flock(second,fcntl.LOCK_EX|fcntl.LOCK_NB)
                    finally:os.close(second)
            self.assertIsNone(r._CONTROLLER_LEASE_FD);self.assertIsNone(r._SHARED_RESOURCE_LEASE_FD)
    def test_exact_limits_distinct_cpu_and_serial_pressure_fallback(self):
        observation=dict(allowed_CPUs=[4,5],MemAvailable_bytes=5_000_000_000,cgroup_observations={})
        self.assertEqual(r.choose_worker_count(2,[4,5],observation),2)
        observation['MemAvailable_bytes']=3_000_000_000
        self.assertEqual(r.choose_worker_count(2,[4,5],observation),1)
        for cpus in ([4,4],[7,8],[4], [True,5]):
            with self.assertRaises(ValueError):r.choose_worker_count(2,cpus,observation)

class NPZAndTerminalTests(unittest.TestCase):
    def test_hostile_source_headers_deny_before_np_load(self):
        import high365_codec as codec
        for shape,dtype,fortran in (((10**12,5),'<f8',False),((365,5),'|O',False),((365,5),'<f4',False),((365,5),'<f8',True)):
            header=BytesIO();np.lib.format.write_array_header_1_0(header,dict(shape=shape,descr=dtype,fortran_order=fortran))
            archive=BytesIO()
            with zipfile.ZipFile(archive,'w') as z:z.writestr('x.npy',header.getvalue())
            with patch.object(np,'load',side_effect=AssertionError('NO_ALLOCATION')) as load,self.assertRaises(ValueError):codec.npz(archive.getvalue(),{'x':((365,5),'float64')})
            load.assert_not_called()
    def test_exact_paid_flat_and_tiny_cash_debt_margin_corruptions(self):
        import high365_native_generated as g
        from saved_native_reconciliation import reconcile_saved_native
        e=g.native_reference()
        with g.generated_fixture(days=1) as f:
            targets=g.project_generated(f);sim,guard=g.construct_generated_case(targets,'LOW')
            while sim.cursor<sim.end and sim.stop is None:sim.advance_day()
            result=e.case_result(sim,guard);result.pop('minute');result['targets']=result['targets'].to_dicts()
            result=e.V2.OWNED.export_tree(result);audit=e.V2.OWNED.export_tree(sim.account.snapshot())
            self.assertTrue(reconcile_saved_native(audit,result)['passed'])
            for key in ('free_cash','unpaid_liability'):
                bad=deepcopy(audit)
                with localcontext() as ctx:
                    ctx.prec=100;bad[key]=str(e.DEC(bad[key])+e.DEC('1e-38'))
                with self.subTest(key=key),self.assertRaises(ValueError):reconcile_saved_native(bad,result)
            bad=deepcopy(audit);s=e.S[0]
            with localcontext() as ctx:
                ctx.prec=100;bad['positions'][s]['isolated_balance']=str(e.DEC(bad['positions'][s]['isolated_balance'])+e.DEC('1e-38'))
            with self.assertRaises(ValueError):reconcile_saved_native(bad,result)
            bad=deepcopy(result);bad['economics']['actual_paid_market_flat']=not bad['economics']['actual_paid_market_flat']
            with self.assertRaises(ValueError):r.classify_terminal(audit,bad,calendar=[sim.start,sim.end],completed_minutes=sim.rows_written,stop_us=sim.stop)


class SavedSchemaTests(unittest.TestCase):
    def fake_guard(self):
        from high365_source_guard import SourceOnlyGuard
        zeros=dict.fromkeys(SourceOnlyGuard.CATEGORIES,0)
        return dict(schema='OBSERVED_HIGH365_INTRINSIC_SOURCE_GUARD_V1',status='PASS_FINANCIAL_WORKER_SOURCE_ONLY_RECAPTURE',
            forbidden_attempts=zeros,error=None,attempted_targets=[],guard_active=False,historical_execution_authorized=False,
            financial_execution_authorized=False,source_scopes_revoked=True,native_source_scopes_revoked=True,saved_targets_and_covariance_rebuilt=False,
            observed_workspace_read_paths={'/GENERATED_METADATA_ONLY.py':1},checkpoints=[dict(label=x,attempts=deepcopy(zeros)) for x in (
                'FRESH_WORKER_ORIGINAL_HIGH365_SOURCE_RECAPTURE_BEFORE_FINANCE_IMPORT','EXACT_SAVED_ORIGINAL_HIGH365_TARGETS_LOADED_WITHOUT_REGENERATION')])
    def test_guard_observed_categories_types_and_phase_labels(self):
        saved.saved_source_guard(self.fake_guard())
        for key,value in (('forbidden_attempts',{}),('error','CAUGHT'),('guard_active',True),('source_scopes_revoked',False),
                          ('attempted_targets',[{}]),('checkpoints',[]),('observed_workspace_read_paths',{})):
            bad=self.fake_guard();bad[key]=value
            with self.subTest(key=key),self.assertRaises(ValueError):saved.saved_source_guard(bad)
        bad=self.fake_guard();bad['forbidden_attempts']['financial_GO_writes']=False
        with self.assertRaises(ValueError):saved.saved_source_guard(bad)
    def test_saved_profile_and_tier_metadata_without_account_construction(self):
        from dataclasses import fields
        import high365_native_generated as generated
        native=generated.native_reference();engine=native.V2.ENGINE
        profile=c.exact_object((c.ROOT/'bounded_account_continuation_20261015/QUANTITY_PROFILE.json').read_bytes())
        for tier in config.TIERS:
            cfg=engine.PerpetualConfig(initial_cash='10000',max_gross_weight=str(config.TIER_GROSS_CAPS[tier]),max_asset_weight='.30',leverage='1',half_spread_bps='4',slippage_bps='4')
            profiles={s:engine.InstrumentProfile(quantity_step=profile['rows'][s]['quantity_step'],min_notional='10').metadata() for s in native.S}
            binding={'GENERATED_METADATA_ONLY':True}
            contract=dict(symbols=list(native.S),bound_nominal_tier=tier,free_cash_floor='1000',total_isolated_ceiling='8500',leverage=1,
                nominal_roundtrip_bps=27.,taker_fee_bps_per_side=5.5,topup_enabled=False,policy_variant='GUARD50_EXIT_ONLY',
                quantity_profile_binding='FROZEN_COARSE_RESEARCH_PROFILE',historical_execution_admitted=True,generated_only=False,
                closing_min_notional_exempt=True,instrument_profiles=profiles,scope_binding=binding)
            audit=dict(transfer_journal=[],symbols=list(native.S),positions=dict.fromkeys(native.S),marks=dict.fromkeys(native.S),config={f.name:str(getattr(cfg,f.name)) for f in fields(cfg)},
                instrument_profiles=profiles,closing_min_notional_exempt=True,cost_context=None,bound_nominal_tier=tier,
                historical_execution_admitted=True,contract=contract,historical_execution_scope=binding)
            common=dict(tier=tier,gross_ceiling=config.TIER_GROSS_CAPS[tier],asset_ceiling=.30,annual_covariance_volatility_ceiling=config.TIER_BUDGETS[tier],
                initial_cash='10000',free_cash_increase_floor='1000',actual_isolated_margin_ceiling='8500',automatic_topup=False,policy_variant='GUARD50_EXIT_ONLY',historical_execution_admitted=True)
            saved.saved_account_contract(audit,{'common_execution_policy':common},tier)
            for key,value in (('symbols',list(reversed(native.S))),('cost_context',{}),('closing_min_notional_exempt',False),('transfer_journal',[{'generated_unrequested_transfer':True}])):
                bad=deepcopy(audit);bad[key]=value
                with self.subTest(tier=tier,key=key),self.assertRaises(ValueError):saved.saved_account_contract(bad,{'common_execution_policy':common},tier)
            bad=deepcopy(audit);bad['instrument_profiles']['BTCUSDT']['quantity_step']='.00001'
            with self.assertRaises(ValueError):saved.saved_account_contract(bad,{'common_execution_policy':common},tier)
    def test_saved_minute_C_and_F_float64_preserve_values(self):
        expected=np.arange(12,dtype=np.float64).reshape(4,3)
        for value in (np.ascontiguousarray(expected),np.asfortranarray(expected)):
            stream=BytesIO();np.savez_compressed(stream,values=value,columns=np.array(['a','b','c']))
            actual,names=saved.saved_minute(stream.getvalue(),4,cell_id=entry.tranche_cells(entry.ALL15)[0])
            self.assertEqual(actual.dtype,np.dtype('float64'));self.assertTrue(np.array_equal(actual,expected))
            self.assertEqual(names,['a','b','c'])
    def test_saved_minute_header_bounds_before_allocation(self):
        for shape,dtype,fortran in (((10**12,2),'<f8',False),((3,2),'<f4',False),((3,2),'|O',False)):
            header=BytesIO();np.lib.format.write_array_header_1_0(header,dict(shape=shape,descr=dtype,fortran_order=fortran))
            cols=BytesIO();np.save(cols,np.array(['a','b']),allow_pickle=False);archive=BytesIO()
            with zipfile.ZipFile(archive,'w') as z:z.writestr('values.npy',header.getvalue());z.writestr('columns.npy',cols.getvalue())
            with patch.object(np,'load',side_effect=AssertionError('NO_ALLOCATION')) as load,self.assertRaises(ValueError):saved.saved_minute(archive.getvalue(),3,cell_id=entry.tranche_cells(entry.ALL15)[0])
            load.assert_not_called()

if __name__=='__main__':unittest.main()
