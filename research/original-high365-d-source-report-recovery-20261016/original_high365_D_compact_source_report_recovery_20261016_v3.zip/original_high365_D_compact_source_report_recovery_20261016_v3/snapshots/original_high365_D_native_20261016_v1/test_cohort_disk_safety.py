"""Generated disk floor/cap and owned-worker stop tests; no actual workers."""
from pathlib import Path
import os
import tempfile
import unittest
from unittest.mock import patch
import high365_process_runtime as r
from test_runtime_model import Model


def observed(*,free=10_000_000_000,used=0):
    return dict(free_bytes=free,cohort_output_log_temporary_bytes=used,**r.COHORT_DISK_POLICY)


class DiskSafetyTests(unittest.TestCase):
    def test_refused_drained_pause_final_report_preserves_compact_fields_and_chain(self):
        import json
        import run_high365 as runner
        from test_runtime_model import d
        report=dict(saved_validation_errors=[dict(cell_id='A',error='GENERATED_SAVED_VALIDATION_ERROR')],
            pending_not_launched=['C'],large_observation_report='invented'*10000)
        original=d.SavedValidationPause(report);raw=r.body(report)
        # The full report cannot fit, while the compact RESOURCE receipt can.
        space=observed(used=2800000000-len(raw)+1)
        with tempfile.TemporaryDirectory(prefix='GENERATED_DRAINED_PAUSE_WRITE_') as td:
            root=Path(td);large=root/'LARGE_REPORT.json';small=root/'RESOURCE_PAUSE.json'
            with patch.object(r,'cohort_disk_observation',return_value=space):
                try:
                    try:raise original
                    except d.SavedValidationPause as saved_error:
                        try:r.save_cohort_controller(large,report)
                        except r.CohortDiskResourceStop as disk_error:
                            runner.preserve_compact_saved_pause(saved_error,disk_error)
                            self.assertTrue(r.save_bounded_resource_stop(small,disk_error))
                            raise disk_error from saved_error
                except r.CohortDiskResourceStop as error:
                    self.assertIs(error.__cause__,original)
                    self.assertEqual(error.saved_validation_errors,report['saved_validation_errors'])
                    self.assertEqual(error.pending_not_launched,['C'])
                    self.assertTrue(error.original_pause_preserved)
                else:self.fail('FINAL_REPORT_DISK_FORECAST_MUST_REFUSE')
            self.assertFalse(large.exists());self.assertLessEqual(small.stat().st_size,65536)
            receipt=json.loads(small.read_bytes())
            self.assertEqual(receipt['saved_validation_errors'],report['saved_validation_errors'])
            self.assertEqual(receipt['pending_not_launched'],['C'])
            self.assertTrue(receipt['original_pause_preserved']);self.assertEqual(receipt['failure_classification'],'RESOURCE')
            self.assertNotIn('large_observation_report',receipt)

    def test_exact_thresholds_and_boundary_values_are_resource_not_economic(self):
        self.assertEqual(r.COHORT_DISK_POLICY['minimum_free_bytes'],1610612736)
        self.assertEqual(r.COHORT_DISK_POLICY['maximum_cohort_output_log_temporary_bytes'],2800000000)
        self.assertFalse(r.COHORT_DISK_POLICY['external_disk_writers_guaranteed'])
        with patch.object(r,'cohort_disk_observation',return_value=observed(free=1610612736,used=2800000000)):
            r.check_cohort_disk('/INVENTED')
        for value,reason in ((observed(free=1610612735),'FREE_SPACE_FLOOR'),
                (observed(used=2800000001),'OUTPUT_LOG_TEMPORARY_CAP')):
            with self.subTest(reason=reason),patch.object(r,'cohort_disk_observation',return_value=value):
                with self.assertRaisesRegex(r.CohortDiskResourceStop,reason) as caught:r.check_cohort_disk('/INVENTED')
                self.assertEqual(caught.exception.failure_classification,'RESOURCE')
                self.assertFalse(caught.exception.economic_halt)

    def test_whole_cohort_counts_case_outputs_root_logs_hidden_temporaries_once(self):
        with tempfile.TemporaryDirectory(prefix='GENERATED_COHORT_DISK_') as td:
            root=Path(td);(root/'A').mkdir()
            for name,n in (('A/result.json',11),('A.log',13),('.controller.atomic.tmp',17)):
                (root/name).write_bytes(b'x'*n)
            os.link(root/'.controller.atomic.tmp',root/'same_inode_published.json')
            value=r.cohort_disk_observation(root)
            self.assertEqual(value['cohort_output_log_temporary_bytes'],41)
            self.assertGreater(value['free_bytes'],0)

    def test_prospective_serialized_controller_body_and_atomic_temporary_are_budgeted(self):
        with tempfile.TemporaryDirectory(prefix='GENERATED_CONTROLLER_BUDGET_') as td:
            root=Path(td);path=root/'CONTROLLER_RECEIPT.json';value={'report':['invented']*1024};raw=r.body(value)
            for space,reason in ((observed(free=1610612736+len(raw)-1),'FREE_SPACE_FLOOR'),
                    (observed(used=2800000000-len(raw)+1),'OUTPUT_LOG_TEMPORARY_CAP')):
                with self.subTest(reason=reason),patch.object(r,'cohort_disk_observation',return_value=space),patch.object(r,'write_bytes') as write:
                    with self.assertRaisesRegex(r.CohortDiskResourceStop,reason):r.save_cohort_controller(path,value)
                    write.assert_not_called();self.assertFalse(path.exists())
            link=os.link;seen=[]
            def publish(src,dst):
                self.assertTrue(Path(src).name.startswith('.CONTROLLER_RECEIPT.json.'))
                seen.append(r.own_bytes(root));return link(src,dst)
            with patch.object(r.os,'link',side_effect=publish):r.save_cohort_controller(path,value)
            self.assertEqual(seen,[len(raw)]);self.assertEqual(path.read_bytes(),raw)
            self.assertEqual(r.own_bytes(root),len(raw))

    def test_bounded_resource_receipt_never_embeds_the_large_report_or_forces_a_write(self):
        with tempfile.TemporaryDirectory(prefix='GENERATED_RESOURCE_STOP_') as td:
            path=Path(td)/'RESOURCE_PAUSE.json'
            error=r.CohortDiskResourceStop('OUTPUT_LOG_TEMPORARY_CAP',observed(used=2800000001))
            error.saved_validation_errors=[{'error':'x'*100000}];error.original_pause_preserved=True
            self.assertTrue(r.save_bounded_resource_stop(path,error));self.assertLessEqual(path.stat().st_size,65536)
            other=Path(td)/'NO_BUDGET.json'
            with patch.object(r,'cohort_disk_observation',return_value=observed(free=1610612735)):
                self.assertFalse(r.save_bounded_resource_stop(other,error));self.assertFalse(other.exists())

    def model(self,root,**kwargs):return Model(root,**kwargs)

    def test_floor_or_cap_before_launch_cannot_claim_or_spawn(self):
        for observation in (observed(free=1610612735),observed(used=2800000001)):
            with tempfile.TemporaryDirectory(prefix='GENERATED_DISK_PRELAUNCH_') as td:
                model=self.model(td,fail=())
                with patch.object(r,'cohort_disk_observation',return_value=observation),self.assertRaises(r.CohortDiskResourceStop):model.run()
                self.assertEqual(model.spawned,[]);self.assertEqual(model.claims,[]);self.assertEqual(model.killed,[])
                self.assertIsNone(r._CONTROLLER_LEASE_FD);self.assertIsNone(r._SHARED_RESOURCE_LEASE_FD)

    def test_poll_floor_or_cap_stops_only_active_owned_workers_and_no_pending_launch(self):
        for fault in ('floor','cap'):
            with tempfile.TemporaryDirectory(prefix='GENERATED_DISK_LIVE_') as td:
                model=self.model(td,fail=())
                def observation(_):
                    return observed(free=1610612735) if fault=='floor' and model.now>=100.1 else observed(used=2800000001) if fault=='cap' and model.now>=100.1 else observed()
                with patch.object(r,'cohort_disk_observation',side_effect=observation),self.assertRaises(r.CohortDiskResourceStop):model.run()
                self.assertEqual(model.spawned,['A','B']);self.assertEqual(model.claims,['A','B'])
                self.assertEqual(set(model.killed),set(model.processes));self.assertEqual(model.validated,[])
                self.assertTrue(all(model.lock_checks));self.assertFalse((Path(td)/'output'/'C').exists())

    def test_disk_breach_during_saved_validation_drain_preserves_original_pause(self):
        for fault in ('floor','cap'):
            with tempfile.TemporaryDirectory(prefix='GENERATED_DISK_DRAIN_') as td:
                model=self.model(td)
                def observation(_):
                    return observed(free=1610612735) if fault=='floor' and model.validated else observed(used=2800000001) if fault=='cap' and model.validated else observed()
                with patch.object(r,'cohort_disk_observation',side_effect=observation),self.assertRaises(r.CohortDiskResourceStop) as caught:model.run()
                self.assertTrue(caught.exception.original_pause_preserved)
                self.assertEqual(caught.exception.saved_validation_errors[0]['cell_id'],'A')
                self.assertEqual(caught.exception.pending_not_launched,['C'])
                self.assertEqual(model.spawned,['A','B']);self.assertEqual(model.validated,['A'])
                self.assertEqual(model.killed,[model.processes[90001].pid]);self.assertTrue(all(model.lock_checks))

    def test_after_launch_hook_recheck_refuses_spawn_and_keeps_existing_claim(self):
        with tempfile.TemporaryDirectory(prefix='GENERATED_DISK_AFTER_HOOK_') as td:
            model=self.model(td,fail=())
            def observation(_):return observed(free=1610612735) if model.claims else observed()
            with patch.object(r,'cohort_disk_observation',side_effect=observation),self.assertRaises(r.CohortDiskResourceStop):model.run()
            self.assertEqual(model.claims,['A']);self.assertEqual(model.spawned,[])
            self.assertTrue((Path(td)/'A.generated_claim.json').is_file())

    def test_success_report_records_observed_disk_limits_and_unchanged_case_caps(self):
        with tempfile.TemporaryDirectory(prefix='GENERATED_DISK_SUCCESS_') as td:
            model=self.model(td,fail=())
            with patch.object(r,'cohort_disk_observation',return_value=observed()):report=model.run()
            self.assertEqual(report['status'],'ALL_ADMITTED_ORDERED_CELLS_TERMINAL')
            self.assertGreater(report['cohort_disk_safety']['checks'],3)
            self.assertEqual(report['limits']['per_case_output_bytes'],250000000)
            self.assertEqual(report['limits'],r.LIMITS)


if __name__=='__main__':unittest.main(verbosity=2)
