"""All15 exact saved selections and original365 Boolean-mask regressions.

Only invented year-shaped tapes are decoded. No native account, historical
scope, provider or actual prepared numerical artifact is admitted here.
"""
import ast
from copy import deepcopy
from io import BytesIO
import unittest
from unittest.mock import patch
import numpy as np
import high365_native_bootstrap
import high365_native_common as c
import high365_config as config
import high365_source_entry as entry
import high365_loader as frozen_loader
import high365_signal as signal
import high365_admission as admission
import high365_claims as claims
import high365_finance_gate as gate
import high365_saved as saved
from generated_financial_fixture import installed_fixture


def pack(arrays):
    stream=BytesIO();np.savez_compressed(stream,**arrays);return stream.getvalue()


class SavedMaskTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.context=installed_fixture()
        cls.prep,cls.artifacts,cls.captured=cls.context.__enter__()
        cls.metadata=entry.validate_preparation_metadata(cls.prep)
        cls.decoded={year:frozen_loader.decode_saved(cls.prep,cls.artifacts,year)
            for year in entry.tranche_years(entry.ALL15)}

    @classmethod
    def tearDownClass(cls):cls.context.__exit__(None,None,None)

    def changed_target_artifact(self,year,arrays):
        artifacts=dict(self.artifacts);metadata=deepcopy(self.metadata)
        name=str(year)+'/TARGETS.npz';raw=pack(arrays);artifacts[name]=raw
        metadata['artifacts'][name]=dict(SHA256=c.sha(raw),bytes=len(raw))
        return c.canonical(metadata),artifacts

    def test_all15_actual_selector_exact_saved_tier_bytes_and_complete_bindings(self):
        seen=[];rows=[]
        for cell_id in entry.tranche_cells(entry.ALL15):
            cell=config.cell_named(cell_id);year=cell['year'];arrays,inputs=self.decoded[year]
            info=self.metadata['years'][str(year)];days=cell['calendar_days']
            selected=admission.select_saved_target(arrays,cell_id=cell_id,year=year)
            expected=arrays[cell['recipe']+'_'+cell['tier']]
            self.assertIs(selected,expected)
            self.assertEqual(selected.shape,(days,5));self.assertFalse(selected.flags.writeable)
            identity=signal.array_byte_identity(selected)
            self.assertEqual(c.canonical(identity),c.canonical(info['array_identities'][cell['recipe']+'_'+cell['tier']]))
            binding=entry.binding_from_info(cell,info,self.metadata['source_stage_GO_SHA256'],self.metadata['source_review_SHA256'])
            self.assertEqual(c.jsha(binding),self.metadata['cells'][cell_id]['input_binding_SHA256'])
            self.assertEqual(c.canonical(binding),c.canonical(self.metadata['cells'][cell_id]['input_binding']))
            self.assertEqual(binding['code_manifest_SHA256'],gate.SOURCE_CODE_SHA256)
            self.assertEqual(binding['pure_signal_code_manifest_SHA256'],'2423efc89fb0002c62dc44623c4cf290eb932717f9c782b16e5ed7164ca5811d')
            self.assertEqual(binding['target_prefix_metadata'],info['target_prefix_metadata'])
            mask=arrays['HIGH365_CURRENT_ELIGIBLE']
            self.assertEqual(mask.dtype,np.dtype('bool'));self.assertEqual(mask.shape,(days,5));self.assertFalse(mask.flags.writeable)
            self.assertEqual(c.canonical(signal.array_byte_identity(mask)),c.canonical(info['array_identities']['HIGH365_CURRENT_ELIGIBLE']))
            self.assertTrue((mask.sum(axis=1)==3).any());self.assertTrue((mask.sum(axis=1)==4).any());self.assertTrue((mask.sum(axis=1)==5).any())
            self.assertEqual(arrays['decision_us'][0],cell['start_us'])
            self.assertEqual(arrays['decision_us'][-1],cell['end_exclusive_us']-config.DAY)
            self.assertEqual(len(inputs['close_available_us']),days+199)
            self.assertGreater(info['target_prefix_metadata']['selected_rows'],days+364)
            rows.append(dict(cell_id=cell_id,year=year,tier=cell['tier'],days=days,
                selected_target_identity=identity,mask_identity=signal.array_byte_identity(mask),
                input_binding_SHA256=c.jsha(binding),canonical_execution_warmup=199,
                original_prefix_rows=info['target_prefix_metadata']['selected_rows']))
            seen.append((year,cell['tier']))
        self.assertEqual(len(seen),15);self.assertEqual(len(set(seen)),15)
        self.assertEqual({(r['year'],r['days']) for r in rows},{(2021,274),(2022,365),(2023,365),(2024,366),(2025,365)})
        (c.HERE/'GENERATED_ALL15_SAVED_SELECTION_RECEIPT.json').write_bytes(c.canonical(dict(
            schema='HIGH365_ALL15_INVENTED_SAVED_TARGET_MASK_SELECTION_V1',status='PASS',rows=rows,
            source_code_manifest_SHA256=gate.SOURCE_CODE_SHA256,actual_prepared_arrays_read=False,
            actual_accounts_or_scopes_or_providers=0,all15_exact_selector_and_binding_checks=True)))

    def test_financial_saved_decode_never_rebuilds_targets_or_covariance(self):
        with patch.object(signal,'build_target_grid',side_effect=AssertionError('NO_REGENERATION')) as build:
            for year in entry.tranche_years(entry.ALL15):
                checked,_=frozen_loader.decode_saved(self.prep,self.artifacts,year)
                for key,value in checked.items():
                    self.assertEqual(value.tobytes(),self.decoded[year][0][key].tobytes())
            build.assert_not_called()

    def test_hostile_boolean_mask_dtype_and_shape_deny_before_allocation(self):
        for year in (2021,2024):
            original=self.decoded[year][0];mask=original['HIGH365_CURRENT_ELIGIBLE']
            for bad in (mask.astype('float64'),mask.astype('int64'),mask.astype('uint8'),mask[:-1],mask[:,:4]):
                arrays=dict(original);arrays['HIGH365_CURRENT_ELIGIBLE']=bad
                prep,artifacts=self.changed_target_artifact(year,arrays)
                with self.subTest(year=year,dtype=bad.dtype.str,shape=bad.shape):
                    with patch.object(np,'load',side_effect=AssertionError('NO_ALLOCATION')) as load,self.assertRaises(ValueError):
                        frozen_loader.decode_saved(prep,artifacts,year)
                    load.assert_not_called()

    def test_individual_mask_bits_and_one_ulp_tier_change_reject_even_with_new_container_pin(self):
        for year in (2021,2024):
            original=self.decoded[year][0]
            for point in ((0,2),(-1,0)):
                arrays=dict(original);mask=arrays['HIGH365_CURRENT_ELIGIBLE'].copy();mask[point]=not mask[point]
                arrays['HIGH365_CURRENT_ELIGIBLE']=mask;prep,artifacts=self.changed_target_artifact(year,arrays)
                with self.subTest(year=year,point=point),self.assertRaisesRegex(ValueError,'EXACT_FINITE_TARGET'):
                    frozen_loader.decode_saved(prep,artifacts,year)
            key=config.RECIPES[0]+'_MID';arrays=dict(original);target=arrays[key].copy()
            target[0,0]=np.nextafter(target[0,0],np.inf);arrays[key]=target
            prep,artifacts=self.changed_target_artifact(year,arrays)
            with self.subTest(year=year,change='ONE_ULP'),self.assertRaisesRegex(ValueError,'EXACT_FINITE_TARGET'):
                frozen_loader.decode_saved(prep,artifacts,year)

    def test_namespace_no_old_source_financial_prepared_rule_alias(self):
        arrays=self.decoded[2021][0]
        for cell in ('2021_STATIC50_HALF_SMA200_LOW_D_INTRINSIC_LOWER_ONLY_V1',
                '2021_STATIC50_OLD_NO_REEXPANSION_LOW_D_INTRINSIC_LOWER_ONLY_V1',
                '2026_STATIC50_HIGH365_REFERENCE_HOLD_LOW_D_INTRINSIC_LOWER_ONLY_V1'):
            with self.assertRaises(ValueError):admission.select_saved_target(arrays,cell_id=cell,year=2021)
        cell=entry.tranche_cells(entry.ALL15)[0]
        with self.assertRaises(ValueError):admission.select_saved_target(arrays,cell_id=cell,year=2021)
        self.assertEqual(claims.STABLE_REGISTRY_REL,'original_high365_D_native_20261016_v1/EXECUTION_CLAIMS')
        self.assertEqual(claims.SCOPE_SHA,entry.manifest_sha())
        self.assertIn('HIGH365',gate.PREPARED_REVIEW_SCHEMA);self.assertIn('HIGH365',gate.NATIVE_REVIEW_SCHEMA)
        self.assertNotEqual(gate.GO_SCHEMA,entry.SOURCE_SCHEMA)
        policy=gate.base(self.prep)
        self.assertEqual(policy['independent_prepared_source_audit_SHA256'],gate.PREPARED_SOURCE_AUDIT_SHA256)
        self.assertEqual(set(policy['current365_eligibility_mask_identities_by_year']),set(self.metadata['years']))

    def test_saved_terminal_uses_the_exact_boolean_source_schema(self):
        tree=ast.parse((c.HERE/'high365_saved.py').read_text())
        function=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='validate_saved_terminal')
        specs=next(n for n in ast.walk(function) if isinstance(n,ast.Assign)
            and any(isinstance(t,ast.Name) and t.id=='specs' for t in n.targets))
        self.assertEqual(ast.unparse(specs.value),"source_entry.array_specs(cell['year'])")


if __name__=='__main__':unittest.main(verbosity=2)
