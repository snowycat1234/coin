"""Invented four-year native byte tapes; no historical files or authority."""
from copy import deepcopy
from dataclasses import asdict
from io import BytesIO
import numpy as np
import high365_native_bootstrap
import high365_native_common as c
import high365_config as config
import high365_native_codec as codec
import high365_native_quality as quality
import high365_native_source_scope as e
import high365_signal as signal
import high365_native_source as source

def pack(**arrays):
    out = BytesIO(); np.savez_compressed(out, **arrays); return out.getvalue()

def prices(clocks):
    x = (clocks - config.utc('2020-01-01')) / config.DAY
    return np.column_stack([100 + j * 20 + x * (.02 + j * .003)
        + np.sin(x / (7 + j) + j) * .4 for j in range(5)])

def fake_daily(year):
    rows, first, last = codec.STORED_DAILY[year]
    clocks = np.arange(first, last + config.DAY, config.DAY, dtype=np.int64)
    arrays = dict(close_available_us=clocks, close=prices(clocks))
    if year in (2021,2022):
        arrays['symbol_order'] = np.array(signal.SYMBOLS)
    if year==2021:arrays['unselected_later_DEV'] = np.array([float('nan')])
    daily = None
    if year in (2023,2025):
        d = np.arange(config.period_named(year)['start'], config.period_named(year)['end'], config.DAY, dtype=np.int64)
        p = prices(d)
        daily = c.canonical([dict(symbol=s, close_us=int(at), close=float(p[i,j]))
            for i, at in enumerate(d) for j,s in enumerate(signal.SYMBOLS)])
    return arrays, daily

def fake_events(year):
    start = config.utc('2021-01-01') if year == 2021 else config.period_named(year)['start']
    days = 365 if year == 2021 else config.period_named(year)['days']
    rows = [dict(symbol=s, event_us=start+i*8*60*codec.MINUTE,
        raw_rate=float((1 if i%2 else -1)*(j+1)*.000013), reported_interval_hours=8.)
        for i in range(days*3) for j,s in enumerate(sorted(signal.SYMBOLS))]
    if year == 2021:
        for row in rows:
            row['raw_rate_unit']='UNCONFIRMED'
            row['strict_prior_mark']=dict(mark_available_us=row['event_us']-1, strict_prior_age_us=1)
    return rows

def fake_month(year, rec, close_clocks, close):
    times=np.arange(rec['start'],rec['start']+rec['count']*codec.MINUTE,codec.MINUTE,dtype=np.int64)
    arrays=dict(times=times)
    if year in (2021,2022): arrays['available_us']=times+codec.MINUTE
    for j,s in enumerate(signal.SYMBOLS):
        for field in codec.FIELDS:
            arrays[s+'_'+field]=np.full(rec['count'],100.+j,dtype=np.float64)
        for at in range(rec['start']+config.DAY,rec['start']+rec['count']*codec.MINUTE+1,config.DAY):
            k=int(np.searchsorted(close_clocks,at))
            if k<len(close_clocks) and close_clocks[k]==at:
                arrays[s+'_close'][(at-rec['start'])//codec.MINUTE-1]=close[k,j]
    return arrays

def fake_source(year):
    if year==2022:return fake_source_2022()
    contract=deepcopy(e.contracts()['years'][str(year)])
    warm,daily=fake_daily(year); warm_raw=pack(**warm)
    clocks,close,decisions=codec.daily_inputs(year,warm_raw,daily)
    months=[]; final=None; mark_hashes={}
    for rec in contract['months']:
        a=fake_month(year,rec,clocks,close); raw=pack(**a)
        rec['hash']=c.sha(raw); rec['size']=len(raw)
        months.append((rec['path'],raw)); final=a
        if year==2024 and rec['start']<=1723456920000000<rec['start']+rec['count']*codec.MINUTE:
            projected,_=codec.month_arrays(year,raw,rec['start'],rec['count'])
            mark_hashes={s:c.sha(projected[s+'_mark'].tobytes()) for s in signal.SYMBOLS}
    endpoint={s:float(final[s+'_close'][-1]) for s in signal.SYMBOLS}
    sidecar=dict(final_endpoint_close=endpoint,arrival_status='UNKNOWN_NOT_CERTIFIED',
        certifies_liquidation=False,certifies_no_liquidation=False)
    qualification_raw=None
    if year==2021:
        sidecar.pop('final_endpoint_close')
        sidecar.update(schema='GENUINE_2021_PARTIAL_NATIVE_MARK_PROVENANCE_V1',
            source_end_plus_one_witness_is_not_execution_authority=True)
        quotes=[]
        period=config.period_named(year)
        for kind,at in (('fresh_start',period['start']),('terminal_flat_quote',period['end'])):
            for symbol in signal.SYMBOLS:
                quotes.append(dict(symbol=symbol,kind=kind,open_us=at-codec.MINUTE,available_us=at,
                    execution_clock_if_later_admitted_us=at+1,available_before_proposed_execution=True,
                    actual_trade_close=float(final[symbol+'_close'][-1]),actual_mark_close=float(final[symbol+'_mark'][-1])))
        qualification_raw=c.canonical(dict(schema='CORE5_2021_APR_DEC_SOURCE_QUALIFICATION_V1',
            symbol_order=list(signal.SYMBOLS),actual_endpoint_quotes=quotes))
        contract['qualification'].update(SHA256=c.sha(qualification_raw),bytes=len(qualification_raw))
        sidecar['qualification_SHA256']=c.sha(qualification_raw)
    if year==2024: sidecar['causal_estimate_mark_array_SHA256']=mark_hashes
    if year==2023:sidecar['original200_quality']=contract['quality_summary']
    events=fake_events(year)
    for row in events:
        row['event_us']+=15001
        if year==2021:row['strict_prior_mark']['mark_available_us']=row['event_us']-1
    contract['events']['stored_events']=len(events)
    period=config.source_year(year)
    contract['events']['selected_events']=sum(period['start']<=r['event_us']<period['end'] for r in events)
    inputs=(year,warm_raw,daily,c.canonical(events),c.canonical(sidecar),tuple(months),contract,qualification_raw)
    return inputs


def fake_source_2022():
    year=2022;contract=deepcopy(e.contracts()['years']['2022'])
    warm,_=fake_daily(year);warm_raw=pack(**warm);clocks,close,decisions=codec.daily_inputs(year,warm_raw)
    points=tuple(tuple(row) for row in contract['exact_mark_absent_open_points_us']);missing=set(points)
    rows=[];old=quality.original_quality()
    for symbol,at in points:
        anchor=at-codec.MINUTE
        while (symbol,anchor) in missing:anchor-=codec.MINUTE
        j=signal.SYMBOLS.index(symbol)
        rows.append(asdict(old.QualityCell(symbol,at,at+codec.MINUTE,at+codec.MINUTE,str(100.+j),
            anchor,anchor+codec.MINUTE,anchor+codec.MINUTE,anchor+codec.MINUTE,anchor+codec.MINUTE,'a'*64,
            'GENERATED_GENUINE_MARK:'+symbol+':'+str(anchor))))
    contract['normalized_quality_cells_SHA256']=c.jsha(rows)
    sidecar=dict(quality='UNKNOWN_OR_DERIVED',arrival_status='UNKNOWN_NOT_CERTIFIED',derived_mark_cells=27,
        certifies_liquidation=False,certifies_no_liquidation=False,actual_publication_arrival_installation='UNKNOWN_NOT_CERTIFIED',
        actual_event_impacts='PENDING_ACTUAL_SAVED_EVIDENCE',cells=rows)
    months=[];final=None
    for rec in contract['months']:
        arrays=fake_month(year,rec,clocks,close)
        for symbol,at in points:
            if rec['start']<=at<rec['start']+rec['count']*codec.MINUTE:
                arrays[symbol+'_mark'][(at-rec['start'])//codec.MINUTE]=np.nan
        raw=pack(**arrays);rec['hash']=c.sha(raw);rec['size']=len(raw);months.append((rec['path'],raw));final=arrays
    sidecar['final_endpoint_close']={symbol:float(final[symbol+'_close'][-1]) for symbol in signal.SYMBOLS}
    start=config.source_year(year)['start']
    events=[dict(symbol=symbol,event_us=start+15001,raw_rate=(-1 if j%2 else 1)*.00013,
        reported_interval_hours=(2,4,8,2,8)[j],raw_rate_unit='UNCONFIRMED') for j,symbol in enumerate(signal.SYMBOLS)]
    contract['events']['selected_events']=len(events)
    return (year,warm_raw,None,c.canonical(events),c.canonical(sidecar),tuple(months),contract,None)
