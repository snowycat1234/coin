"""Guarded recapture of unchanged source and loading of immutable saved targets.

Financial authority is verified before guard entry and consumed as an opaque,
one-use binding. No executable financial object is serialized under the guard.
"""
from dataclasses import dataclass,field
from pathlib import Path
from types import MappingProxyType
import numpy as np
import high365_native_bootstrap
import high365_native_common as c
import high365_config as config
import high365_source_entry as entry
import high365_source as source
import high365_loader as frozen_loader
import high365_signal as signal
import high365_verified_wires as verified

_SEAL=object()
_LIVE={}

@dataclass(frozen=True,slots=True)
class LoadedInputs:
    year:int
    preparation_raw:bytes=field(repr=False)
    source:object=field(repr=False)
    arrays:object=field(repr=False)
    captured_artifacts:object=field(repr=False)
    financial_GO_SHA256:str
    verified_cell_id:str
    _token:object=field(repr=False)
    _seal:object=field(repr=False)
    def __post_init__(self):
        if self._seal is not _SEAL:raise ValueError('ENTRY_OWNED_NEW_LEGACY_FINANCIAL_LOADED_INPUTS_REQUIRED')
    def validate(self):
        if _LIVE.get(self._token) is not self or self._seal is not _SEAL:
            raise ValueError('LIVE_NEW_ORIGINAL_HIGH365_LOADED_INPUTS_REQUIRED')
        p=entry.validate_preparation_metadata(self.preparation_raw);info=p['years'][str(self.year)]
        if (type(self.year) is not int or self.year not in (2021,2022,2023,2024,2025) or self.verified_cell_id not in p['ordered_cells']
                or set(self.arrays)!=set(entry.array_specs(self.year))):raise ValueError('EXACT_ALL15_2021_2022_2024_2025_ARRAY_AND_CELL_SCOPE_REQUIRED')
        for k,v in self.arrays.items():
            if v.flags.writeable or c.canonical(signal.array_byte_identity(v))!=c.canonical(info['array_identities'][k]):
                raise ValueError('EXACT_IMMUTABLE_LEGACY_TARGET_COVARIANCE_BITS_REQUIRED')
        if set(self.captured_artifacts)!=set(p['artifacts']):raise ValueError('EXACT_CAPTURED_ARTIFACT_NAMESPACE_REQUIRED')
        for name,raw in self.captured_artifacts.items():
            pin=p['artifacts'][name]
            if c.sha(raw)!=pin['SHA256'] or len(raw)!=pin['bytes']:raise ValueError('EXACT_CAPTURED_PREPARATION_ARTIFACT_BITS_REQUIRED')
        if (c.jsha(self.source['source_rows'])!=info['source_rows_SHA256']
                or c.jsha(self.source['events'])!=info['funding_events_SHA256']
                or c.sha(self.source['sidecar_raw'])!=info['source_quality_sidecar_SHA256']):
            raise ValueError('EXACT_LIVE_SOURCE_ROWS_LITERAL_FUNDING_QUALITY_REQUIRED')
        for cell_id in p['ordered_cells']:
            cell=config.cell_named(cell_id)
            if cell['year']!=self.year:continue
            binding=entry.binding_from_info(cell,info,p['source_stage_GO_SHA256'],p['source_review_SHA256'])
            if c.jsha(binding)!=p['cells'][cell_id]['input_binding_SHA256']:
                raise ValueError('EXACT_RECIPE_TIER_INTRINSIC_SAVED_TARGET_BINDING_REQUIRED')
        if self.source['source_identity']!=info['source_identity']:
            raise ValueError('EXACT_FRESH_NATIVE_SOURCE_IDENTITY_REQUIRED')
        for rec,(name,raw) in zip(self.source['contract']['months'],self.source['months'],strict=True):
            if name!=rec['path'] or c.sha(raw)!=rec['hash'] or len(raw)!=rec['size']:
                raise ValueError('EXACT_CAPTURED_NATIVE_MONTH_BYTES_REQUIRED')
        return True


def load_year(preparation_root,*,expected_preparation_sha256,year,
              source_go_raw,expected_source_go_sha256,source_review_raw,expected_source_review_sha256,
              financial_go_raw,expected_financial_go_sha256,financial_review_raw,expected_financial_review_sha256,
              prepared_review_raw,expected_prepared_review_sha256,native_review_raw,expected_native_review_sha256,verified_binding=None):
    from high365_source_guard import current_guard
    guard=current_guard()
    if guard is None or not guard.active:raise ValueError('WHOLE_INVOCATION_UNCHANGED_LEGACY_SOURCE_GUARD_REQUIRED')
    config.source_year(year)
    entry.validate_source_authority_metadata(source_go_raw,expected_source_go_sha256,source_review_raw,expected_source_review_sha256)
    root=Path(preparation_root).absolute()
    if root.is_symlink() or any(x.is_symlink() for x in root.parents):raise ValueError('ORDINARY_EXACT_PREPARATION_DIRECTORY_REQUIRED')
    raw=c.exact(root/'PREPARATION.json',expected_preparation_sha256);p=entry.validate_preparation_metadata(raw)
    wires={'go':financial_go_raw,'review':financial_review_raw,'prepared-review':prepared_review_raw,'native-review':native_review_raw,
           'source-go':source_go_raw,'source-review':source_review_raw}
    sha=verified.consume(verified_binding,preparation_raw=raw,year=year,supplied=wires)
    expected={'go':expected_financial_go_sha256,'review':expected_financial_review_sha256,
              'prepared-review':expected_prepared_review_sha256,'native-review':expected_native_review_sha256,
              'source-go':expected_source_go_sha256,'source-review':expected_source_review_sha256}
    if sha!=expected_financial_go_sha256 or dict(verified_binding.hashes)!=expected:
        raise ValueError('EXACT_EXTERNALLY_PREVERIFIED_FINANCIAL_WIRE_DIGESTS_REQUIRED')
    artifacts={name:c.exact(root/c.relative(name),pin['SHA256'],pin['bytes']) for name,pin in p['artifacts'].items()}
    if (artifacts['SOURCE_STAGE_AUTHORIZATION.json']!=source_go_raw or artifacts['SOURCE_INDEPENDENT_REVIEW.json']!=source_review_raw
            or p['source_stage_GO_SHA256']!=expected_source_go_sha256 or p['source_review_SHA256']!=expected_source_review_sha256):
        raise ValueError('EXACT_FRESH_LEGACY_SOURCE_GO_REVIEW_LINEAGE_REQUIRED')
    # Header/schema validation precedes allocation, capture, account/provider.
    arrays,inputs=frozen_loader.decode_saved(raw,artifacts,year)
    import high365_native_source_scope as native_scope
    import high365_native_source as native_source
    with native_scope.admit_capture(verified_binding,year=year) as scope:
        captured=native_source.capture_year(year,scope)
    if native_scope._LIVE:raise ValueError('NATIVE_SOURCE_CAPTURE_SCOPES_NOT_REVOKED')
    prefix=str(year)+'/'
    if (arrays['decision_us'].tobytes()!=captured['decisions'].tobytes()
            or inputs['close_available_us'].tobytes()!=captured['clocks'].tobytes()
            or inputs['close'].tobytes()!=captured['close'].tobytes()
            or artifacts[prefix+'MINUTE_MARK_PROVENANCE.json']!=captured['sidecar_raw']
            or c.object_json(artifacts[prefix+'RAW_EVENTS.json'])!=c.plain(captured['events'])
            or c.object_json(artifacts[prefix+'SOURCE_ROWS.json'])!=c.plain(captured['source_rows'])):
        raise ValueError('EXACT_CURRENT_SOURCE_CALENDAR_LITERAL_FUNDING_QUALITY_BITS_REQUIRED')
    if year==2022 and c.canonical(c.object_json(artifacts[prefix+'NORMALIZATION_EQUIVALENCE.json']))!=c.canonical(captured['normalization_equivalence']):
        raise ValueError('EXACT2022_SOURCE_TO_NORMALIZED_NUMERIC_BITS_WITNESS_REQUIRED')
    token=object();value=LoadedInputs(year,raw,c.immutable(captured),MappingProxyType(arrays),MappingProxyType(artifacts),sha,
                                    verified_binding.cell_id,token,_SEAL)
    _LIVE[token]=value
    try:value.validate();return value
    except BaseException:_LIVE.pop(token,None);raise


def revoke(value):
    if type(value) is not LoadedInputs or _LIVE.get(value._token) is not value:raise ValueError('LIVE_NEW_ORIGINAL_HIGH365_LOADED_INPUTS_REQUIRED')
    _LIVE.pop(value._token)
