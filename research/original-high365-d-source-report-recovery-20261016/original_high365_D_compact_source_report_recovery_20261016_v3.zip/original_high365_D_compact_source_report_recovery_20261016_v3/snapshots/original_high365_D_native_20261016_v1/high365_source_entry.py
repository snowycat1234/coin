"""Private additive alias to the untouched source-only entry module."""
import high365_native_bootstrap
import sys
import high365_entry
sys.modules[__name__]=high365_entry
