"""CPU6/7 generated process model. No actual worker4/5 processes."""
import os
from generated_test_runtime import selected_cpu
from contextlib import contextmanager
import fcntl
from pathlib import Path
from types import SimpleNamespace
import sys
import tempfile
import unittest
from unittest.mock import patch
import high365_native_bootstrap
import high365_process_runtime as frozen
HERE=Path(__file__).resolve().parent
REPAIR=HERE.parent/'cs_saved_minute_reporting_repair_20261015_v2'
if str(REPAIR) not in sys.path:sys.path.insert(0,str(REPAIR))
import bounded_drain as d
class Model:
    def __init__(self, root, *, fault=None, fail=('A',), durations=None):
        self.root=Path(root);self.now=100.;self.processes={};self.spawned=[];self.killed=[]
        self.claims=[];self.validated=[];self.lock_checks=[];self.fault=fault;self.fail=set(fail)
        self.durations=durations or {'A':.2,'B':.7,'C':.1};self.fd=None
        self.runtime=SimpleNamespace(**{k:getattr(frozen,k) for k in
            ('LIMITS','HERE','utc','sha','save','own_bytes','environment')})
        self.runtime.choose_worker_count=lambda requested,cpus,obs:2
        self.runtime.process_observation=self.observation
        self.runtime.host_observation=lambda:{'generated_model_only':True}
        self.runtime._CONTROLLER_LEASE_FD=None

    def lock_held(self):
        assert self.fd is not None
        p=self.root/'registry'/frozen.MANIFEST_SHA256/'CONTROLLER_LEASE.lock'
        with p.open('r+') as stream:
            try:fcntl.flock(stream.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
            except BlockingIOError:self.lock_checks.append(True);return
            fcntl.flock(stream.fileno(),fcntl.LOCK_UN)
            raise AssertionError('LEASE_LOST_DURING_DRAIN')

    def observation(self,pid):
        if self.fd is not None:self.lock_held()
        p=self.processes.get(pid)
        if not p:return None
        rss=1000
        if self.fault=='AGGREGATE':rss=1_800_000_000
        if self.now>=100.4:
            if self.fault=='RSS':rss=2_000_000_001
        cpu=p.cpu
        if self.fault=='AFFINITY' and self.now>=100.4:cpu=8
        return dict(PID=pid,RSS_bytes=rss,CPU_affinity=[cpu],tasks=[dict(CPU_affinity=[cpu])],process_start_ticks=str(pid))

    def popen(self,command,**kwargs):
        # Simulated workers only: logical labels never select a real CPU.
        cpu=int(command[4]);directory=Path(command[5]);cell=directory.name
        self.assert_lease(kwargs)
        pid=90000+len(self.spawned)
        self.spawned.append(cell)
        model=self
        class Process:
            def __init__(self):
                self.pid=pid;self.cpu=cpu;self.start=model.now;self.directory=directory;self.dead=False
            def poll(self):
                if self.dead:return -9
                if model.fault=='WALL' and cell=='B':return None
                if model.fault=='BOOTSTRAP' and cell=='B':return None
                if model.now-self.start<model.durations[cell]-1e-8:return None
                if model.fault=='PROCESS' and cell=='B':return 7
                if not (directory/'TERMINAL_CHECKPOINT.json').exists():
                    frozen.save(directory/'TERMINAL_CHECKPOINT.json',dict(generated=True,cell=cell))
                return 0
            def wait(self):self.dead=True;return -9
        p=Process();self.processes[pid]=p
        if not (self.fault=='BOOTSTRAP' and cell=='B'):
            frozen.save(directory/'BOOTSTRAP_READY.json',dict(generated=True))
        return p

    def assert_lease(self,kwargs):
        assert kwargs['pass_fds']==(self.fd,frozen._SHARED_RESOURCE_LEASE_FD)
        assert kwargs['env']['LEGACY_SHARED_CPU45_LEASE_FD']==str(frozen._SHARED_RESOURCE_LEASE_FD)
        assert kwargs['env']['MATRIX_CONTROLLER_LEASE_FD']==str(self.fd)
        self.lock_held()

    def kill(self,pid,sig):self.killed.append(pid);self.processes[pid].dead=True
    def sleep(self,seconds):
        self.now+=200. if self.fault=='WALL' and 'A' in self.validated else seconds
        if self.fault=='OUTPUT' and self.now>=100.4:
            b=self.root/'output'/'B'/'oversized.generated'
            with b.open('wb') as stream:stream.truncate(250_000_001)
    def validator(self,directory,cell):
        self.validated.append(cell)
        if cell in self.fail:raise ValueError('GENERATED_SAVED_VALIDATOR_FAIL:'+cell)
        self.lock_held();return dict(status='GENERATED_TERMINAL')
    def before(self,cell,directory,cpu):
        self.claims.append(cell);frozen.save(self.root/(cell+'.generated_claim.json'),dict(cell=cell,generated_only=True))
    def run(self):
        jobs=[(c,lambda directory,cpu,c=c:['generated-no-real-process',c]) for c in ('A','B','C')]
        shared=self.root/'GENERATED_SHARED_CPU45.lock';shared.touch()
        @contextmanager
        def fake_envelope(cpus):
            assert cpus==[4,5];assert sorted(os.sched_getaffinity(0))==[selected_cpu()];yield
        with patch.object(frozen,'shared_resource_lease_path',return_value=shared):
            with frozen.controller_lease(self.root/'registry') as fd:
                self.fd=fd;self.runtime._CONTROLLER_LEASE_FD=fd
                with patch.object(d.subprocess,'Popen',self.popen),patch.object(d.os,'killpg',self.kill),patch.object(d.time,'monotonic',lambda:self.now),patch.object(d.time,'sleep',self.sleep),patch.object(frozen,'choose_worker_count',self.runtime.choose_worker_count),patch.object(frozen,'process_observation',self.observation),patch.object(frozen,'cpu_envelope',fake_envelope):
                    return frozen.run_pool(jobs,self.root/'output',requested_workers=2,cpus=[4,5],validator=self.validator,observation_callback=self.runtime.host_observation,before_launch=self.before)


class RuntimeModelTests(unittest.TestCase):

    def model(self, **kwargs):
        temp = tempfile.TemporaryDirectory(prefix='generated_model_', dir=HERE)
        self.addCleanup(temp.cleanup)
        return Model(temp.name, **kwargs)

    def test_saved_failure_drains_peer_preserves_pause_no_C_spawn_no_retry(self):
        m = self.model()
        with self.assertRaises(d.SavedValidationPause) as caught:
            m.run()
        report = caught.exception.report
        self.assertEqual(m.spawned, ['A', 'B'])
        self.assertEqual(m.claims, ['A', 'B'])
        self.assertEqual(m.validated, ['A', 'B'])
        self.assertEqual(m.killed, [])
        self.assertEqual(report['pending_not_launched'], ['C'])
        self.assertEqual(report['cases'][0]['cell_id'], 'B')
        self.assertEqual(report['status'], 'SAVED_VALIDATION_PAUSE_DRAINED_NO_RETRY')
        self.assertTrue(report['original_pause_preserved'])
        self.assertTrue(report['no_automatic_retry'])
        self.assertTrue(all(m.lock_checks))
        self.assertGreater(len(m.lock_checks), 4)
        self.assertFalse((m.root / 'output' / 'C').exists())

    def test_both_saved_validators_fail_original_nonzero_pause_retained(self):
        m = self.model(fail=('A', 'B'))
        with self.assertRaises(d.SavedValidationPause) as caught:
            m.run()
        self.assertEqual([r['cell_id'] for r in caught.exception.report['saved_validation_errors']], ['A', 'B'])
        self.assertEqual(m.spawned, ['A', 'B'])
        self.assertEqual(m.killed, [])

    def test_resource_faults_during_drain_immediately_stop_peer(self):
        for fault, expected in [('RSS', 'WORKER_RSS_LIMIT'), ('AFFINITY', 'WORKER_AFFINITY_LIMIT'), ('OUTPUT', 'WORKER_OUTPUT_LIMIT'), ('WALL', 'WORKER_WALL_LIMIT'), ('BOOTSTRAP', 'WORKER_BOOTSTRAP_STARTUP_LIMIT'), ('PROCESS', 'WORKER_FAILED_EXECUTION')]:
            with self.subTest(fault=fault):
                m = self.model(fault=fault)
                with self.assertRaisesRegex(RuntimeError, expected) as caught:
                    m.run()
                self.assertNotIsInstance(caught.exception, d.SavedValidationPause)
                self.assertEqual(m.spawned, ['A', 'B'])
                self.assertEqual(m.claims, ['A', 'B'])
                self.assertTrue(caught.exception.original_pause_preserved)
                self.assertEqual(caught.exception.saved_validation_errors[0]['cell_id'], 'A')
                if fault != 'PROCESS':
                    self.assertTrue(m.killed)

    def test_initial_saved_failure_never_spawns_pending(self):
        m = self.model()
        p = m.root / 'output' / 'A'
        p.mkdir(parents=True)
        frozen.save(p / 'TERMINAL_CHECKPOINT.json', dict(generated=True))
        with self.assertRaisesRegex(ValueError, 'GENERATED_SAVED_VALIDATOR_FAIL:A'):
            m.run()
        self.assertEqual(m.spawned, [])
        self.assertEqual(m.claims, [])
        self.assertFalse((m.root / 'output' / 'B').exists())

    def test_aggregate_RSS_fault_kills_immediately_before_saved_pause(self):
        m = self.model(fault='AGGREGATE')
        with self.assertRaisesRegex(RuntimeError, 'AGGREGATE_LIVE_RSS_LIMIT'):
            m.run()
        self.assertEqual(m.spawned, ['A', 'B'])
        self.assertEqual(len(m.killed), 2)
        self.assertEqual(m.validated, [])

    def test_drain_does_not_reapply_new_launch_memory_admission(self):
        m = self.model()

        def capacity(*args):
            if m.validated:
                raise AssertionError('NEW_LAUNCH_ADMISSION_USED_DURING_PAUSE')
            return 2
        m.runtime.choose_worker_count = capacity
        with self.assertRaises(d.SavedValidationPause):
            m.run()
        self.assertEqual(m.validated, ['A', 'B'])

    def test_unfinished_existing_directory_not_retried(self):
        m = self.model()
        (m.root / 'output' / 'A').mkdir(parents=True)
        with self.assertRaisesRegex(RuntimeError, 'EXISTING_UNFINISHED_CASE_PAUSE_NO_RETRY'):
            m.run()
        self.assertEqual(m.spawned, [])

    def test_happy_path_all_jobs_once(self):
        m = self.model(fail=())
        report = m.run()
        self.assertEqual(m.spawned, ['A', 'B', 'C'])
        self.assertEqual(m.claims, ['A', 'B', 'C'])
        self.assertEqual(report['status'], 'ALL_ADMITTED_ORDERED_CELLS_TERMINAL')
        self.assertEqual(report['saved_validation_errors'], [])

    def test_exact_runtime_limits_CPU7_only_and_no_live_leases_after_model(self):
        self.assertEqual(frozen.LIMITS,d.EXACT_LIMITS)
        self.assertEqual(sorted(os.sched_getaffinity(0)),[selected_cpu()])
        self.assertIsNone(frozen._CONTROLLER_LEASE_FD);self.assertIsNone(frozen._SHARED_RESOURCE_LEASE_FD)
