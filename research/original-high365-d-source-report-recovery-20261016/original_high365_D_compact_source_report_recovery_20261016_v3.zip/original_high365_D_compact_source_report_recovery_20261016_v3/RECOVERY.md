# Recovery and trust boundary

1. Obtain the exact outer ZIP SHA256 and run_isolated_cold.py SHA256 from an
   independently trusted final handoff. A manifest inside an unauthenticated
   archive is not an independent trust root. Do not run a substituted/repacked
   archive under an old receipt.
2. Authenticate the separately supplied launcher, then run with Python 3.12+
   standard library only, a fresh receipt destination and at least 1.5 GiB free:

   python -I -S -B run_isolated_cold.py PACKET.zip --trusted-zip-sha256 TRUSTED_SHA256 --receipt NEW_COLD_RECEIPT.json

   The launcher checks outer identity and member safety before executing included
   code. It bounds ZIP bytes/members/expansion, rejects traversal, duplicate/case
   collisions and special files, clears credentials from inherited environment,
   disables bytecode writes and restricts later reads to the fresh extraction
   plus standard library. It blocks external reads, historical/nonstdlib imports,
   historical code execution, network/process actions and non-receipt mutations.
   Five actual negative boundary controls and generated metadata controls run.
   The tiny extraction is deliberately retained and its path reported.
3. Inspect exact JSON/CSV, final review aggregate, public original expert pin,
   source snapshots, diagnostic history, omitted-evidence pins and dependency
   classifications. The cold checker establishes included-byte/report integrity
   and cross-bindings only. Prior native40 PASS proof receipts are immutable
   earlier results, not a fresh reconstruction by this checker.
4. For optional generated packaging tests after authenticated safe extraction,
   run python -S -B test_packet.py in the packet root. These use generated tiny
   ZIPs and metadata only. Do not execute the inert historical scripts under
   snapshots/ or results/ as part of compact verification.
5. Recover complete historical context only by separately obtaining the exact
   omitted raw market/source-prefix/source-row/target/covariance/funding/minute,
   full account/event/result and controller bodies listed in the included
   preparation, checkpoint and artifact-binding metadata. Verify exact saved
   pins before any separately reviewed recovery step. Hashes do not retrieve
   bodies. Private actual authorities/claims are intentionally unavailable here.
   Any source capture, target regeneration, provider/account construction,
   financial replay or publication requires separately admitted inputs and fresh
   appropriate authorization. No such commands, bypasses or authority are supplied.

build_packet.py is authoring provenance. It reconstructs this selection only
when the separately restored original study and packaging files exist under
their historical sibling names. It is not a portable financial rerun tool.
