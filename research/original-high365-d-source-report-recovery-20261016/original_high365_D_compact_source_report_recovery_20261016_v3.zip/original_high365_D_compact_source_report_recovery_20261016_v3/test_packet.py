"""Generated stdlib-only tests for the compact integrity checker and ZIP gate."""
import hashlib
from pathlib import Path
import tempfile
import unittest
import zipfile
import run_isolated_cold as cold
import verify_packet as packet

class GeneratedTests(unittest.TestCase):
    def test_metadata_and_JSON_controls(self):
        self.assertEqual(packet.generated_checks()['rejected_metadata_controls'],12)

    def test_included_reviews_and_contradictory_dependency_flags(self):
        self.assertEqual(packet.generated_dependency_checks()['rejected_contradictory_dependency_controls'],8)

    def archive(self,names,external_attr=None):
        temporary=tempfile.TemporaryDirectory(prefix='high365_packet_generated_')
        self.addCleanup(temporary.cleanup)
        path=Path(temporary.name)/'generated.zip'
        with zipfile.ZipFile(path,'x') as handle:
            for name in names:
                info=zipfile.ZipInfo(name)
                info.external_attr=external_attr if external_attr is not None else 0o100644<<16
                handle.writestr(info,b'GENERATED_ONLY')
        return path,hashlib.sha256(path.read_bytes()).hexdigest()

    def test_positive_members(self):
        p,h=self.archive([packet.NAME+'/generated.txt'])
        self.assertEqual(len(cold.archive_members(p,h)),1)

    def test_wrong_outer_hash(self):
        p,_=self.archive([packet.NAME+'/generated.txt'])
        with self.assertRaisesRegex(ValueError,'SHA256_MISMATCH'):
            cold.archive_members(p,'0'*64)

    def test_no_archive_import_before_authentication(self):
        p,_=self.archive([packet.NAME+'/verify_packet.py'])
        with self.assertRaisesRegex(ValueError,'TRUSTED_SHA256_REQUIRED'):
            cold.archive_members(p,'untrusted')

    def test_parent_traversal(self):
        p,h=self.archive([packet.NAME+'/../escape'])
        with self.assertRaisesRegex(ValueError,'UNSAFE_MEMBER_PATH'):
            cold.archive_members(p,h)

    def test_absolute_path(self):
        p,h=self.archive(['/escape'])
        with self.assertRaisesRegex(ValueError,'UNSAFE_MEMBER_PATH'):
            cold.archive_members(p,h)

    def test_case_collision(self):
        p,h=self.archive([packet.NAME+'/A',packet.NAME+'/a'])
        with self.assertRaisesRegex(ValueError,'COLLIDING_MEMBER'):
            cold.archive_members(p,h)

    def test_symlink(self):
        p,h=self.archive([packet.NAME+'/link'],0o120777<<16)
        with self.assertRaisesRegex(ValueError,'NONREGULAR_MEMBER'):
            cold.archive_members(p,h)

    def test_windows_separator(self):
        p,h=self.archive([packet.NAME+'/a\\b'])
        with self.assertRaisesRegex(ValueError,'UNSAFE_MEMBER_PATH'):
            cold.archive_members(p,h)

    def test_wrong_root(self):
        p,h=self.archive(['other_packet/generated.txt'])
        with self.assertRaisesRegex(ValueError,'UNSAFE_MEMBER_PATH'):
            cold.archive_members(p,h)

    def test_expansion_bound(self):
        p,h=self.archive([packet.NAME+'/a',packet.NAME+'/b'])
        before=cold.MAX_TOTAL
        try:
            cold.MAX_TOTAL=25
            with self.assertRaisesRegex(ValueError,'ARCHIVE_BOUND'):
                cold.archive_members(p,h)
        finally:
            cold.MAX_TOTAL=before

if __name__=='__main__':
    unittest.main()
