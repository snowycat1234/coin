"""Build one additive compact metadata/source packet. No historical imports.

Authoring requires the existing immutable local study; no network, source-array
read, account/provider construction, financial run, claim or GO is performed.
"""
import hashlib
import json
import os
from pathlib import Path
import shutil
import zipfile

P = Path(__file__).resolve().parent
W = P.parent
NAME = 'original_high365_D_compact_source_report_recovery_20261016_v3'
OUT = W/NAME
SIGNAL = 'original_high365_signal_20261016_v1'
SOURCE = 'original_high365_D_source_20261016_v1'
NATIVE = 'original_high365_D_native_20261016_v1'
SAVED = 'original_high365_D_saved_independent_review_20261016_v1'
MATRIX = 'original_high365_D_saved_matrix_20261016_v1'
COHORT = NATIVE+'/financial_attempts/ACTUAL_ALL15_attempt001'
PREP = SOURCE+'/source_attempts/ACTUAL_ALL15_SOURCE_TARGET_ONLY_attempt001'
FLOOR = 1610612736
MAX_TOTAL = 5_000_000
read_log = {}
mapping = {}
written_bytes = 0

def require(ok,message):
    if not ok:
        raise ValueError(message)

def body(value):
    return (json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()

def bytepin(data):
    return {'SHA256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}

def safe_read(path):
    path = Path(path)
    require(path.is_file() and not path.is_symlink() and path.stat().st_size < 1_000_000,'BOUNDED_REGULAR_METADATA_OR_CODE_REQUIRED:'+str(path))
    require(path.suffix not in ('.npz','.npy','.parquet','.zip','.pyc') and path.name not in ('RAW_EVENTS.json','SOURCE_ROWS.json','TARGET_PROOFS.json','NATIVE_RESULT.json','ACCOUNT_FINANCIAL_AUDIT.json','ADMISSION_GO.json','LAUNCH_CLAIM.json','SOURCE_STAGE_AUTHORIZATION.json'),'FORBIDDEN_BODY_READ')
    data = path.read_bytes()
    read_log[str(path.relative_to(W))] = bytepin(data)
    return data

def read_json(rel):
    return json.loads(safe_read(W/rel))

def put(rel,data):
    global written_bytes
    require(written_bytes+len(data)<MAX_TOTAL,'PACKET_BYTE_BUDGET')
    require(shutil.disk_usage(W).free >= FLOOR+len(data),'FREE_DISK_FLOOR')
    target = OUT/rel
    target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('xb') as handle:
        handle.write(data)
    written_bytes += len(data)

def write(rel,value):
    put(rel,body(value))

def copy(original,rel,category):
    data = safe_read(W/original)
    put(rel,data)
    mapping[rel] = dict(original_path=original,original_pin=bytepin(data),transformation='EXACT_EXISTING_BYTES',category=category)

def inventory():
    return {str(p.relative_to(OUT)):bytepin(p.read_bytes()) for p in sorted(OUT.rglob('*')) if p.is_file() and p.name!='MANIFEST.json'}

def main():
    require(not OUT.exists() and not OUT.with_suffix('.zip').exists(),'ADDITIVE_NEW_OUTPUT_REQUIRED')
    require(sorted(os.sched_getaffinity(0)) == [7],'AUTHOR_CPU7_REQUIRED')
    require(all(os.environ.get(k)=='1' for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS')),'AUTHOR_POOLS1_REQUIRED')
    require(shutil.disk_usage(W).free >= FLOOR+20_000_000,'FREE_DISK_FLOOR')
    OUT.mkdir()
    required = {
        NATIVE+'/FINANCIAL_CODE_MANIFEST.json':('96dac961eec4d01353feae6d542eb90c87f73c903833089068ce6eaf7432f640',44905),
        COHORT+'/ROOT_OBSERVED_EXIT_CONFIRMED.json':('2c02b42c420e0a6e5ec726fcf5803c70a22badb302a64dfdb5a27a538fe69459',100),
        MATRIX+'/COST_MDD_EXPOSURE_MATRIX.json':('2a2bf85958ebd692f8997955e3555de6117ffdb28673fc09e131850620ae0ba2',79039),
        MATRIX+'/COST_MDD_EXPOSURE_MATRIX.csv':('b1ac7fc299d6a3fbc2f95341c282d233dceaa5163ad676b3d0f65f979d724a64',22486),
        MATRIX+'/build_saved_matrix.py':('e03bb0034c562eed936ab718b5844f6c57aea863e479ab9cfd7506288ca6f249',13035),
        MATRIX+'/ORIGINAL37_COMPLETION_DELTA.json':('c9d1963c58b9fbcfd71f105acb6f6da8bc3dce4fd336daf5affef1f6afac9b51',11973),
        SAVED+'/FINAL_BINDING.json':('ba2b7b7767814bb320fc335567c1ff2aee3bbbf95645750325236afe54b3aa28',9804),
        SAVED+'/CONTROLLER_AND_FINAL_ARTIFACT_BINDING.json':('1af67bd0e8bd2a09c3d26a20d50d1c051845ba7754cab738b22767d6a18435f3',118373),
        SAVED+'/FINAL_MATRIX_INDEPENDENT_REVIEW.json':('ccf075f2b29cc45084b957e1da9602b95077513575303dc53110a1a740f661cb',6608),
        SAVED+'/SOURCE_QUALITY_SAVED_SUPPLEMENT.json':('1ed2aa91abe0802d9149448cf1bb03144c2207d64ad7a3b7178899ed94ddd70e',16739),
        SAVED+'/FINAL_INDEPENDENT_SAVED_AUDIT.json':('d5b6ec882caf7e0a8bc4e26708c10c742394add2424442e3627716ca09691fde',10433),
    }
    for original,(sha,size) in required.items():
        require(bytepin(safe_read(W/original)) == dict(SHA256=sha,bytes=size),'FINAL_INPUT_PIN:'+original)
    # Every file covered by the three final source-code manifests is exact,
    # inert recovery data. Dependencies outside those snapshots remain hash-only.
    manifests = {}
    for folder,manifest_name in ((SIGNAL,'CODE_MANIFEST.json'),(SOURCE,'CODE_MANIFEST.json'),(NATIVE,'FINANCIAL_CODE_MANIFEST.json')):
        manifest = read_json(folder+'/'+manifest_name)
        manifests[folder] = manifest
        copy(folder+'/'+manifest_name,'snapshots/'+folder+'/'+manifest_name,'INERT_FINAL_CODE_MANIFEST')
        for rel,pin in manifest['files'].items():
            original = folder+'/'+rel
            require(bytepin(safe_read(W/original)) == dict(SHA256=pin['SHA256'],bytes=pin['bytes']),'FROZEN_CODE_IDENTITY:'+original)
            copy(original,'snapshots/'+original,'INERT_EXACT_HISTORICAL_CODE_OR_CODE_METADATA')
    extras = {
        SIGNAL:['README.md','CURRENT37_ACCOUNT_SOURCE_STATUS.json','CURRENT37_ACCOUNT_SOURCE_STATUS.csv','DECISION_METADATA_INPUT_PINS.json','FROZEN_FIFTEEN_CELL_MANIFEST.json','HIGH365_NEXT_MINIMAL_ADAPTER_PLAN.json','GENERATED_TESTS.log','CONFIG_GENERATED_TESTS.log'],
        SOURCE:['SOURCE_GENERATED_TEST_RECEIPT.json','SOURCE_GENERATED_BOUNDARY_RECEIPTS.json','SOURCE_GENERATED_TESTS.log'],
        NATIVE:['AUTHOR_CPU7_FINANCIAL_GENERATED_TEST_RECEIPT.json','AUTHOR_CPU7_DISK_DELTA_FINAL_RECEIPT.json','AUTHOR_AUDITOR_LOOKUP_FAILURE_RECEIPT.json','AUTHOR_AUDITOR_LOOKUP_FAILURE.log','GENERATED_ALL15_SAVED_SELECTION_RECEIPT.json'],
    }
    for folder,names in extras.items():
        for name in names:
            if 'snapshots/'+folder+'/'+name not in mapping:
                copy(folder+'/'+name,'snapshots/'+folder+'/'+name,'EXACT_PRE_RUN_OR_GENERATED_HISTORY_METADATA')
    for name in ('PREPARATION.json','OBSERVED_SOURCE_TARGET_GUARD_RECEIPT.json','RECORDING_ONLY_METADATA_RECEIPT.json','SOURCE_INDEPENDENT_REVIEW.json'):
        copy(PREP+'/'+name,'provenance/source_preparation/'+name,'PREPARED_IDENTITY_METADATA_NO_ARRAY_BODIES')
    reviews = {
        'original_high365_signal_independent_review_20261016_v1':['REVIEW.json','REVIEW.md','ARTIFACT_PINS.json'],
        'original_high365_D_source_independent_review_20261016_v1':['REVIEW.json','REVIEW.md','EVIDENCE.json'],
        'original_high365_D_prepared_independent_review_20261016_v1':['PREPARED_INDEPENDENT_REVIEW.json','VERIFIED_ARTIFACT_PINS.json','SOURCE_ONLY_AUDIT_DETAIL.json','REPORTING_ASSUMPTION_FAILURE.json','REPORTING_ASSUMPTION_FAILURE.log'],
        'original_high365_D_native_independent_review_20261016_v1':['FINAL_REVIEW_RECEIPT.json','FINAL_STATIC_AUDIT.json','INDEPENDENT_FINANCIAL_ADMISSION_REVIEW.json','INDEPENDENT_NATIVE_GENERATED_ADMISSION_REVIEW.json','DISK_DELTA_INDEPENDENT_REVIEW.json','ADDITIVE_PREPARED_SOURCE_TARGET_CONSUMER_BINDING.json'],
        SAVED:['INITIAL_BINDING.json','FINAL_BINDING.json','CONTROLLER_AND_FINAL_ARTIFACT_BINDING.json','FINAL_MATRIX_INDEPENDENT_REVIEW.json','MATRIX_TRANSFORM_GENERATED_REVIEW.json','SOURCE_QUALITY_SAVED_SUPPLEMENT.json','FINAL_INDEPENDENT_SAVED_AUDIT.json'],
        'original_high365_D_compact_source_report_independent_review_20261016_v2':['FIRST_FAILED_DEPENDENCY_CLASSIFICATION.log','check_saved_content_first_failed.py'],
    }
    aggregate = read_json(SAVED+'/FINAL_INDEPENDENT_SAVED_AUDIT.json')
    cells = sorted(aggregate['per_cell_reviews'],key=lambda c:(int(c[:4]),('LOW','MID','HIGH').index(c.split('_HOLD_')[1].split('_')[0])))
    require(len(cells)==15 and aggregate['root_observed_exit_code']==0,'FINAL_AGGREGATE_REQUIRED')
    reviews[SAVED] += [c+'.review.json' for c in cells]
    for folder,names in reviews.items():
        for name in names:
            copy(folder+'/'+name,'reviews/'+folder+'/'+name,'EXACT_INDEPENDENT_REVIEW_PROVENANCE_NOT_NEW_CERTIFICATION')
    for name in ('COST_MDD_EXPOSURE_MATRIX.json','COST_MDD_EXPOSURE_MATRIX.csv','ORIGINAL37_COMPLETION_DELTA.json','build_saved_matrix.py','test_saved_matrix.py'):
        copy(MATRIX+'/'+name,'results/'+name,'EXACT_SAVED_REPORT_OR_INERT_REPORTING_SOURCE')
    copy(COHORT+'/ROOT_OBSERVED_EXIT_CONFIRMED.json','receipts/ROOT_OBSERVED_EXIT_CONFIRMED.json','ROOT_OBSERVED_PROCESS_EXIT_RECEIPT')
    selected_case_files = ('CASE_RECEIPT.json','TERMINAL_CHECKPOINT.json','ACTUAL_HELD_RISK_REPORT.json','NATIVE40_RECONSTRUCTION_PROOF.json','PRIMARY_FINANCIAL_RECONCILIATION.json','LEGACY_PRIMARY_FINANCIAL_RECONCILIATION.json','CAUSAL_MARK_QUALITY.json')
    case_map = {}
    for cell in cells:
        case_map[cell] = {}
        for name in selected_case_files:
            rel = 'cases/'+cell+'/'+name
            copy(COHORT+'/'+cell+'/'+name,rel,'EXACT_SMALL_SAVED_CASE_SUMMARY_OR_PROOF_RECEIPT_NO_EVENT_RECONSTRUCTION')
            case_map[cell][name] = dict(packet_path=rel,**mapping[rel]['original_pin'])
    write('CASE_FILE_MAP.json',dict(cells=case_map,raw_account_events_included=False,proof_receipts_are_prior_results_not_new_reconstruction=True))
    dependencies = {}
    included_identities = inventory()
    for folder,manifest in manifests.items():
        for original,pin in manifest.get('dependencies',{}).items():
            matches = sorted(rel for rel,ref in included_identities.items() if ref == pin)
            dependencies[original] = dict(original_pin=pin,body_in_packet=bool(matches),classification='INCLUDED_EXACT_DEPENDENCY_BODY' if matches else 'EXTERNAL_RUNTIME_OR_SOURCE_DEPENDENCY_HASH_ONLY',included_packet_paths=matches,hash_restores_bytes=False)
    write('DEPENDENCY_CLASSIFICATION.json',dict(dependencies=dependencies,external_dependencies_executed=False))
    artifact_binding = read_json(SAVED+'/CONTROLLER_AND_FINAL_ARTIFACT_BINDING.json')
    omitted = {}
    for cell,record in artifact_binding['checked_case_artifacts'].items():
        for name,ref in record['files'].items():
            if name not in selected_case_files:
                category = 'PRIVATE_AUTHORITY_OR_CLAIM_BODY_OMITTED' if name in ('ADMISSION_GO.json','LAUNCH_CLAIM.json','WORKER_AUTHORITY_VERIFIED.json') else 'BULKY_SAVED_EVENTS_OR_ARRAYS_OR_OTHER_RUNTIME_METADATA_OMITTED'
                omitted[ref['path']] = dict(original_pin={k:ref[k] for k in ('SHA256','bytes')},classification=category,body_in_packet=False,pin_source=SAVED+'/CONTROLLER_AND_FINAL_ARTIFACT_BINDING.json',omitted_body_rehashed_by_packet_builder=False)
    omitted[artifact_binding['controller_terminal']['path']] = dict(original_pin={k:artifact_binding['controller_terminal'][k] for k in ('SHA256','bytes')},classification='LARGE_CONTROLLER_TRACE_HASH_ONLY',body_in_packet=False,omitted_body_rehashed_by_packet_builder=False)
    write('OMITTED_EVIDENCE_PINS.json',dict(files=omitted,prepared_array_and_source_input_pins='provenance/source_preparation/PREPARATION.json and reviews/original_high365_D_prepared_independent_review_20261016_v1/VERIFIED_ARTIFACT_PINS.json',hashes_restore_omitted_bytes=False))
    write('FINAL_INPUT_PINS.json',dict(required_exact_inputs={p:dict(SHA256=s,bytes=n) for p,(s,n) in required.items()},pins_received_from_root=True,network_verification_performed=False))
    write('PUBLIC_SOURCE_REFERENCE.json',dict(repository='snowycat1234/coin',commit='1bbc51212c9cf7b7569c1a252efd0e923c2e70c5',path='research/high-reference-expert-20261012/expert.py',expert_SHA256='0b913cc772d059175cc0c9e1e19af47c27d351bd032c1bae6f1ba885d08a76cd',expert_GitBlobSHA1='3acfc60517f51637c37cfeecde1e1dadc49bdc96',url='https://github.com/snowycat1234/coin/blob/1bbc51212c9cf7b7569c1a252efd0e923c2e70c5/research/high-reference-expert-20261012/expert.py',network_retrieval_by_packager=False,exact_local_pinned_bytes_included=True))
    write('SCOPE_AND_LIMITS.json',dict(case_count=15,ordered_cells=cells,completed_minutes=7495200,calendar_days_by_year={'2021':274,'2022':365,'2023':365,'2024':366,'2025':365},all15_complete_for_declared_calendars=True,each_case_finished_actual_paid_market_flat=True,positions_were_held_during_runs=True,root_observed_exit_code=0,fresh_independent_wallet_USDT='10000',annual_wallets_compounded=False,partial2021_return_annualized=False,all_seen_DEV=True,OOS_or_live_certification=False,nominal_tiers_are_exact_realized_risk_matching=False,publication_performed=False,source_or_financial_execution_authorized=False,financial_history_self_contained=False,saved_event_reconstruction_self_contained=False,hashes_restore_omitted_bytes=False,historical_code_imported_by_cold_checker=False,arrays_decoded_by_cold_checker=False,source_arrival_funding_units_publication_venue_filters_and_native_liquidation_uncertified=True,UNKNOWN_asset_minutes_with_nonzero_positions={'2022':27,'2024':10},zero_interval_trades_or_funding_certify_zero_valuation_impact=False,free_disk_floor_bytes=FLOOR,author_CPU_affinity=[7],author_numerical_pools=1))
    write('DIAGNOSTIC_HISTORY.json',dict(successful_actual_financial_run='One authorized ACTUAL_ALL15_attempt001 completed with root-observed EXIT0 and final independent PASS. The following are pre-freeze/generated/test/reporting diagnostics, not failed actual financial runs.',items=[
        dict(stage='SOURCE_GENERATED_TESTS',issue='Initial system Python lacked Polars.',resolution='Generated/source test environment corrected before final freeze; immutable final source test/review receipts retained.'),
        dict(stage='SOURCE_GENERATED_NAMESPACE',issue='Generated CPU namespace loophole.',resolution='Fixed before final frozen source; final source-code identity and independent review retained.'),
        dict(stage='PREPARED_REPORTING_ASSERTION',issue='Reporting-only duplicate-target assertion assumed a duplicate.',resolution='Corrected reporting assertion because all15 actual targets are exact-distinct. Failure JSON/log remain included; no targets or actual financial histories repaired.'),
        dict(stage='NATIVE_PRE_FINAL_GENERATED',issue='Generated bootstrap ZIP lookup diagnostics.',resolution='Fixed/independently checked before final financial-code identity; author lookup failure receipt/log retained.'),
        dict(stage='SAVED_MATRIX_GENERATED',issue='Sparse-halt matrix presentation edge.',resolution='Reporting transform fixed and 13 author plus two independent generated tests passed; current15 results unaffected. Exact builder/test bytes retained.')],unfavorable_2022_and_2025_results_preserved=True,originals_edited_or_deleted=False))
    write('PREDECESSOR_PACKET_DIAGNOSTIC.json',dict(predecessor='original_high365_D_compact_source_report_recovery_20261016_v1.zip',predecessor_SHA256='062bc938a2537b88f38f437d923743494eb469417328a0d9b38db870731b2c46',status='AUTHOR_COLD_CHECK_FAILED_PACKAGING_ONLY_QUALITY_ALL15_ASSUMPTION',issue='The source-quality supplement contains six 2021/2022 rows. The v1 packaging checker incorrectly required 15 supplement rows. 2024 findings live in the existing per-cell reviews and final aggregate.',resolution='Additive v2 checks exact six-row supplement coverage and all15 per-cell reviews, with 2022/2024 counts and the aggregate 2024 position finding.',original_code_reports_reviews_and_financial_history_changed=False,failed_v1_preserved_locally=True,new_source_or_financial_run=False))
    write('V2_DEPENDENCY_CLASSIFICATION_CORRECTION.json',dict(predecessor='original_high365_D_compact_source_report_recovery_20261016_v2.zip',predecessor_SHA256='e2238138c7b15848d3a85315889446f1d365760e69397b3fee48cf1cd04baee6',independent_failure_log='reviews/original_high365_D_compact_source_report_independent_review_20261016_v2/FIRST_FAILED_DEPENDENCY_CLASSIFICATION.log',independent_failing_check='reviews/original_high365_D_compact_source_report_independent_review_20261016_v2/check_saved_content_first_failed.py',status='FROZEN_V2_METADATA_DEFECT_CORRECTED_ADDITIVELY',issue='Two exact prepared-review bodies were present under reviews/ but declared hash-only because the classifier checked only snapshots/+original.',resolution='All dependencies now match exact SHA256 and byte count across all actual included file locations. Included flags, classification and exact locations are verified for every dependency; generated included-review and contradictory-flag regressions run under normal and optimized cold verification.',original_source_financial_report_and_review_bytes_unchanged=True,v1_and_v2_preserved_locally=True,new_source_or_financial_execution=False))
    write('READMAP.json',dict(report='results/COST_MDD_EXPOSURE_MATRIX.json',CSV='results/COST_MDD_EXPOSURE_MATRIX.csv',completion_delta='results/ORIGINAL37_COMPLETION_DELTA.json',latest_final_review='reviews/'+SAVED+'/FINAL_INDEPENDENT_SAVED_AUDIT.json',exact_source_snapshots='snapshots/',case_summary_map='CASE_FILE_MAP.json',exact_original_to_packet_map='PROVENANCE_FILE_MAP.json',omissions='OMITTED_EVIDENCE_PINS.json',dependencies='DEPENDENCY_CLASSIFICATION.json',scope='SCOPE_AND_LIMITS.json',recovery='RECOVERY.md',BOM='BILL_OF_MATERIALS.json',trust='Independently authenticate outer ZIP and this launcher before execution. Embedded hashes do not authenticate an attacker-repacked packet.'))
    put('README.md',b'''# Original HIGH365: compact source, report and provenance recovery

LOCAL PREPARATION ONLY. This thin packet preserves exact frozen original signal,
source-only adapter and final native code as inert bytes, the exact all15 saved
cost/MDD/exposure JSON and CSV, small case summaries/proof receipts, original37
completion delta and the independent review chain. No Git, network, upload,
publication, new source/financial run, authority or claim is performed here.

All 15 cases completed their declared calendars, totaling 7,495,200 simulated
minutes, and each finished actual paid market-flat. Positions were held during
the runs. Each uses a separate fresh 10000-USDT wallet, with no year/tier
compounding. 2021 is April 2 to December 31, 274 days, and its paid return is
unannualized. Annualized daily volatility remains an observed-sample diagnostic
over those 274 days. The 2022 and 2025 unfavorable outcomes remain visible.

Everything is seen DEVELOPMENT. No OOS/live certification, original execution
replication, superiority, exact realized-risk matching or continuous risk-cap
guarantee is claimed. Nominal lower-only tier budgets differ from observed risk.
Signed funding, fees and combined adverse spread/slippage remain separate and
unchanged; embedded execution cost is not deducted again. Source arrival, raw
funding units/publication, venue filters/risk tiers and liquidation remain
uncertified. Nonzero positions span 27 UNKNOWN asset-minutes in 2022 and 10 in
2024. Zero interval trades/funding does not establish zero valuation impact.

Start with READMAP.json and RECOVERY.md. Authenticate the outer ZIP and launcher
through a separate trusted receipt. The cold checker verifies included bytes,
manifest/source/report/review cross-bindings and generated metadata controls.
It does not repeat native40 ledger/event reconstruction. Included proof receipts
record that earlier independent review; their required full account/event/minute
bodies are omitted and hash-bound. Historical modules are never imported.

Older immutable pre-run metadata and provisional reviews can say authority is
false or root-exit binding is pending. The additive final aggregate and exact
root EXIT0 receipt give the completed status; no frozen byte was rewritten.
DIAGNOSTIC_HISTORY.json separates pre-freeze/generated/reporting failures from
the successful one-shot actual financial run. The additive original37 delta
leaves the frozen definitions and pre-run overlay unchanged: 105 original
adaptation cells plus 15 extra pure-CS cells equals 120 saved annual cells;
450 disposition-dependent nominal slots remain. These are not 555 runnable jobs,
unique signals or independent-alpha counts.

Code keeps historical filesystem literals as inert source data. No credentials,
private actual GO/claim/authorization bodies, raw market arrays, account-event
bulk or large controller trace are included. Hashes preserve identity but cannot
restore omitted bytes. Complete historical financial reproduction needs the
exact separately admitted omitted inputs, runtime dependencies and fresh
authorization. This compact packet alone cannot reproduce that financial history.
''')
    put('RECOVERY.md',b'''# Recovery and trust boundary

1. Obtain the exact outer ZIP SHA256 and run_isolated_cold.py SHA256 from an
   independently trusted final handoff. A manifest inside an unauthenticated
   archive is not an independent trust root. Do not run a substituted/repacked
   archive under an old receipt.
2. Authenticate the separately supplied launcher, then run with Python 3.12+
   standard library only, a fresh receipt destination and at least 1.5 GiB free:

   python -I -S -B run_isolated_cold.py PACKET.zip --trusted-zip-sha256 TRUSTED_SHA256 --receipt NEW_COLD_RECEIPT.json

   The launcher checks outer identity and member safety before executing included
   code. It bounds ZIP bytes/members/expansion, rejects traversal, duplicate/case
   collisions and special files, clears credentials from inherited environment,
   disables bytecode writes and restricts later reads to the fresh extraction
   plus standard library. It blocks external reads, historical/nonstdlib imports,
   historical code execution, network/process actions and non-receipt mutations.
   Five actual negative boundary controls and generated metadata controls run.
   The tiny extraction is deliberately retained and its path reported.
3. Inspect exact JSON/CSV, final review aggregate, public original expert pin,
   source snapshots, diagnostic history, omitted-evidence pins and dependency
   classifications. The cold checker establishes included-byte/report integrity
   and cross-bindings only. Prior native40 PASS proof receipts are immutable
   earlier results, not a fresh reconstruction by this checker.
4. For optional generated packaging tests after authenticated safe extraction,
   run python -S -B test_packet.py in the packet root. These use generated tiny
   ZIPs and metadata only. Do not execute the inert historical scripts under
   snapshots/ or results/ as part of compact verification.
5. Recover complete historical context only by separately obtaining the exact
   omitted raw market/source-prefix/source-row/target/covariance/funding/minute,
   full account/event/result and controller bodies listed in the included
   preparation, checkpoint and artifact-binding metadata. Verify exact saved
   pins before any separately reviewed recovery step. Hashes do not retrieve
   bodies. Private actual authorities/claims are intentionally unavailable here.
   Any source capture, target regeneration, provider/account construction,
   financial replay or publication requires separately admitted inputs and fresh
   appropriate authorization. No such commands, bypasses or authority are supplied.

build_packet.py is authoring provenance. It reconstructs this selection only
when the separately restored original study and packaging files exist under
their historical sibling names. It is not a portable financial rerun tool.
''')
    for name in ('build_packet.py','verify_packet.py','test_packet.py','run_isolated_cold.py'):
        put(name,safe_read(P/name))
    write('PROVENANCE_FILE_MAP.json',dict(all_copies_exact_original_bytes=True,files=mapping,generated_wrapper_files_are_separate=True,no_originals_modified=True))
    # Freeze an explicit small-body read inventory. No array or bulky event body
    # has been opened by this builder. Omitted pins came from saved metadata.
    write('AUTHOR_READ_INVENTORY.json',dict(files=read_log,source_arrays_read=False,large_event_or_controller_bodies_read=False,private_authority_or_claim_bodies_read=False,CPU_affinity=[7],numerical_pools=1))
    bom = inventory()
    write('BILL_OF_MATERIALS.json',dict(schema='HIGH365_COMPACT_BOM_V1',self_and_outer_MANIFEST_excluded=True,files={rel:dict(**ref,category=mapping.get(rel,{}).get('category','NEW_WRAPPER_OR_SAVED_ONLY_VALIDATION_SOURCE')) for rel,ref in bom.items()}))
    write('MANIFEST.json',dict(schema='HIGH365_COMPACT_SOURCE_REPORT_RECOVERY_V1',files=inventory(),ordered_cells=cells,case_count=15,external_outer_SHA256_required=True,publication_performed=False))
    # Original metadata/code snapshots must still match after building.
    for original,ref in list(read_log.items()):
        require(bytepin(safe_read(W/original)) == ref,'ORIGINAL_CHANGED_DURING_PACKAGING:'+original)
    archive = OUT.with_suffix('.zip')
    require(shutil.disk_usage(W).free >= FLOOR+written_bytes+200000,'ARCHIVE_FREE_DISK_FLOOR')
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_STORED) as handle:
        for path in sorted(OUT.rglob('*')):
            if path.is_file():
                info=zipfile.ZipInfo(NAME+'/'+str(path.relative_to(OUT)),date_time=(2026,10,16,0,0,0))
                info.compress_type=zipfile.ZIP_STORED
                info.external_attr=0o100644<<16
                handle.writestr(info,path.read_bytes())
    require(archive.stat().st_size < MAX_TOTAL,'OUTER_ARCHIVE_SIZE_BOUND')
    receipt=dict(status='LOCAL_PREPARATION_FROZEN_AWAITING_INDEPENDENT_COLD_REVIEW',packet=str(OUT.relative_to(W)),archive=archive.name,archive_pin=bytepin(archive.read_bytes()),manifest_pin=bytepin((OUT/'MANIFEST.json').read_bytes()),launcher_pin=bytepin((OUT/'run_isolated_cold.py').read_bytes()),builder_pin=bytepin((P/'build_packet.py').read_bytes()),packet_logical_bytes=written_bytes,file_count=len(inventory())+1,CPU_affinity=[7],numerical_pools=1,free_disk_bytes=shutil.disk_usage(W).free,originals_modified=False,network_actions=0,publication_performed=False,financial_or_source_execution=False)
    with (P/'STAGING_RECEIPT.json').open('x') as handle:
        json.dump(receipt,handle,sort_keys=True,indent=2);handle.write('\n')
    print(json.dumps(receipt,sort_keys=True),flush=True)

if __name__=='__main__':
    main()
