import copy
import unittest
import build_saved_matrix as m


def fixture():
    cell = dict(cell_id='GENERATED_CELL', year=1971, tier='LOW', calendar_days=274,
                start_UTC='1971-04-02', end_exclusive_UTC='1972-01-01', initial_cash_USDT='10000')
    receipt = dict(cell_id=cell['cell_id'], strategy=m.STRATEGY, tier='LOW', year=1971,
                   root_GO_SHA256=m.GO_SHA, financial_code_manifest_SHA256=m.CODE_SHA,
                   preparation_SHA256=m.PREP_SHA, scope_manifest_SHA256=m.SCOPE_SHA,
                   completed_minutes=274*1440, required_minutes=274*1440, status='FULL_PAID',
                   max_RSS_bytes=100, CPU_seconds=2.0, total_wall_seconds=3.0)
    ds = dict(NAV='10001.2345678901234567890123456789', net_PnL='1.2345678901234567890123456789',
              gross_PnL_same_quantities='6.2345678901234567890123456789')
    summary = dict(decimal_strings=ds, trade_legs=10, funding_account_applied_events=2,
                   maximum_actual_gross_weight=.31)
    economics = dict(paid_net_return=.00012345678901234568, marked_net_return=.00012345678901234568,
                     halted_prefix_return=None, actual_paid_market_flat=True, full_calendar=True,
                     all_observation_max_drawdown=.02, fees_USDT='2', execution_cost_USDT='2',
                     funding_USDT='-1', actual_paid_market_turnover_USDT='100', actual_liquidation_fills=0,
                     conditional_position_settlements=0, conditional_NAV_adjustment_USDT='0', unpaid_liability='0')
    result = dict(summary=summary, economics=economics)
    risk = dict(status='ACTUAL_HELD_MINUTE_OBSERVATIONS', observation_count=274*1440, omitted_nonpositive_or_later_minutes=0,
                gross_exposure_mean=.2, gross_exposure_max=.31, actual_net_signed_weight_mean=.1,
                asset_exposure_absolute_max=.1, forecast_annual_volatility_mean=.04,
                forecast_annual_volatility_max=.11, nominal_annual_volatility_budget=.05,
                forecast_volatility_breach_minutes=123, realized_daily_simple_return_annual_volatility=.06,
                raw_target_gross_mean=.25, raw_target_gross_max=.3,
                positive_raw_target_minus_actual_gross_mean=.05, minimum_observed_free_cash_USDT=7000,
                maximum_observed_isolated_margin_USDT=3000, minutes_observed_free_cash_below1000=0,
                minutes_observed_margin_above8500=0, actual_absolute_weight_max_by_symbol={'S':.1},
                asset_exposure_absolute_mean_by_symbol={'S':.05}, guard_selection_counts={'1':2})
    review = dict(cell_id=cell['cell_id'], status='PASS_SAVED_ONLY', real_frozen_saved_validator_passed=True,
                  native40_reconstruction_status='PASS_EXACT_EVERY_NATIVE40_EVENT_STATE',
                  financial_code_manifest_SHA256=m.CODE_SHA, completed_minutes=274*1440,
                  terminal_status='FULL_PAID', exact_NAV=ds['NAV'], fees_USDT='2', funding_USDT='-1',
                  execution_cost_USDT='2', quality=dict(interval_count=1, quality_block_rows=2))
    return cell, receipt, result, risk, review


class GeneratedMatrixTests(unittest.TestCase):
    def test_exact_decimal_and_signed_costs(self):
        row=m.metrics(*fixture())
        self.assertEqual(row['paid_net_return'], '0.00012345678901234567890123456789')
        self.assertEqual(row['signed_funding_cash_USDT'], '-1')
        self.assertEqual(row['combined_spread_slippage_cost_USDT'], '2')

    def test_partial_is_not_annualized_or_full_year(self):
        row=m.metrics(*fixture())
        self.assertFalse(row['full_year'])
        self.assertEqual(row['calendar_days'],274)

    def test_no_paid_return_synthesized_for_halt(self):
        values=fixture()
        values[2]['economics']['paid_net_return']=None
        values[2]['economics']['actual_paid_market_flat']=False
        self.assertIsNone(m.metrics(*values)['paid_net_return'])

    def test_drift_breaches_are_preserved(self):
        row=m.metrics(*fixture())
        self.assertEqual(row['forecast_vol_breach_minutes'],123)
        self.assertGreater(row['forecast_annual_vol_max'],row['nominal_annual_vol_budget'])

    def test_review_required(self):
        values=fixture(); values[4]['status']='PENDING'
        with self.assertRaisesRegex(ValueError,'REVIEW_PASS'): m.metrics(*values)

    def test_wrong_go_rejected(self):
        values=fixture(); values[1]['root_GO_SHA256']='0'*64
        with self.assertRaisesRegex(ValueError,'AUTHORITY_PINS'): m.metrics(*values)

    def test_money_mismatch_rejected(self):
        values=fixture(); values[4]['funding_USDT']='1'
        with self.assertRaisesRegex(ValueError,'MONEY_REVIEW_MATCH'): m.metrics(*values)

    def test_observation_prefix_consistency(self):
        values=fixture(); values[3]['observation_count']-=1
        with self.assertRaisesRegex(ValueError,'OBSERVATION_COUNT'): m.metrics(*values)

    def test_sparse_zero_completed_risk_is_explicitly_unknown(self):
        values=list(fixture())
        values[1]['completed_minutes']=values[4]['completed_minutes']=0
        values[3]=dict(status='NOT_EVALUABLE_NO_COMPLETED_NATIVE_MINUTES', observation_count=0)
        row=m.metrics(*values)
        self.assertEqual(row['risk_observation_count'],0)
        self.assertEqual(row['risk_omitted_nonpositive_or_later_minutes'],0)
        self.assertIsNone(row['mean_minute_gross_exposure'])
        self.assertIsNone(row['forecast_vol_breach_minutes'])

    def test_sparse_nonpositive_nav_retains_omitted_rows(self):
        values=list(fixture())
        values[3]=dict(status='NOT_EVALUABLE_NONPOSITIVE_NAV', observation_count=0,
                       omitted_nonpositive_or_later_minutes=274*1440)
        row=m.metrics(*values)
        self.assertEqual(row['risk_omitted_nonpositive_or_later_minutes'],274*1440)
        self.assertIsNone(row['max_minute_gross_exposure'])

    def test_sparse_nonpositive_cannot_default_missing_omitted(self):
        values=list(fixture())
        values[3]=dict(status='NOT_EVALUABLE_NONPOSITIVE_NAV', observation_count=0)
        with self.assertRaises(KeyError):m.metrics(*values)

    def test_full_risk_remains_strict(self):
        values=fixture();del values[3]['gross_exposure_mean']
        with self.assertRaises(KeyError):m.metrics(*values)

    def test_unknown_risk_status_rejected(self):
        values=fixture();values[3]['status']='UNKNOWN'
        with self.assertRaisesRegex(ValueError,'RISK_STATUS'):m.metrics(*values)


if __name__ == '__main__':unittest.main()
