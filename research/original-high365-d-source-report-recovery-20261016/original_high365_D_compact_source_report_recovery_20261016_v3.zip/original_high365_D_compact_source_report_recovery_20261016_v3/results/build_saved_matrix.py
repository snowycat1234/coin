"""Small stdlib-only view of reviewed, immutable HIGH365 saved evidence.

No source arrays, account classes, simulations or execution entry points are used.
This is a presentation transform, not a new reconciliation authority.
"""
from __future__ import annotations

import csv
import hashlib
import io
import json
import os
from decimal import Decimal, localcontext
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
HERE = Path(__file__).resolve().parent
NATIVE = ROOT / 'original_high365_D_native_20261016_v1'
COHORT = NATIVE / 'financial_attempts/ACTUAL_ALL15_attempt001'
REVIEWS = ROOT / 'original_high365_D_saved_independent_review_20261016_v1'
GO_SHA = '3e4c709ec2174beca290f0169ea0c7ca322bcd231020c9b8c7e004cc65b40280'
CODE_SHA = '96dac961eec4d01353feae6d542eb90c87f73c903833089068ce6eaf7432f640'
SCOPE_SHA = '1e036a22f1b79752509032f67aa0a555d8ed84fd940468852566f343e52b9144'
PREP_SHA = 'c0e9771a1f90588fe38d45d14b37ca5bda6e8bfb1f6484a98080be9bc219ff08'
STRATEGY = 'STATIC50_HIGH365_REFERENCE_HOLD'


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def read_json(path):
    raw = path.read_bytes()
    return json.loads(raw), {'path': str(path.relative_to(ROOT)),
                             'bytes': len(raw), 'SHA256': digest(raw)}


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def exact_ratio(value, denominator='10000'):
    with localcontext() as ctx:
        ctx.prec = 100
        return str(Decimal(value) / Decimal(denominator))


def metrics(cell, receipt, result, risk, review):
    """Only select saved values. Preserve original monetary decimal strings."""
    s, e = result['summary'], result['economics']
    require(receipt['cell_id'] == review['cell_id'] == cell['cell_id'], 'CELL_ID')
    require(receipt['strategy'] == STRATEGY and receipt['tier'] == cell['tier']
            and receipt['year'] == cell['year'], 'STRATEGY_YEAR_TIER')
    require(receipt['root_GO_SHA256'] == GO_SHA
            and receipt['financial_code_manifest_SHA256'] == CODE_SHA
            and receipt['preparation_SHA256'] == PREP_SHA
            and receipt['scope_manifest_SHA256'] == SCOPE_SHA, 'AUTHORITY_PINS')
    require(review['status'] == 'PASS_SAVED_ONLY'
            and review['real_frozen_saved_validator_passed'] is True
            and review['native40_reconstruction_status'] == 'PASS_EXACT_EVERY_NATIVE40_EVENT_STATE'
            and review['financial_code_manifest_SHA256'] == CODE_SHA, 'REVIEW_PASS')
    require(receipt['completed_minutes'] == review['completed_minutes']
            and receipt['required_minutes'] == cell['calendar_days'] * 1440, 'MINUTES')
    require(receipt['status'] == review['terminal_status'], 'TERMINAL_STATUS')
    risk_status = risk['status']
    sparse = risk_status in ('NOT_EVALUABLE_NO_COMPLETED_NATIVE_MINUTES', 'NOT_EVALUABLE_NONPOSITIVE_NAV')
    if sparse:
        require(risk['observation_count'] == 0, 'SPARSE_NONZERO_OBSERVATIONS')
        if receipt['completed_minutes'] == 0:
            omitted = risk.get('omitted_nonpositive_or_later_minutes', 0)
        else:
            require(risk_status == 'NOT_EVALUABLE_NONPOSITIVE_NAV', 'SPARSE_NONZERO_COMPLETED_ROWS')
            omitted = risk['omitted_nonpositive_or_later_minutes']
    else:
        require(risk_status in ('ACTUAL_HELD_MINUTE_OBSERVATIONS', 'POSITIVE_NAV_PREFIX_ONLY'), 'RISK_STATUS')
        omitted = risk['omitted_nonpositive_or_later_minutes']
    require(risk['observation_count'] == receipt['completed_minutes'] - omitted, 'OBSERVATION_COUNT')
    def rv(key):
        return None if sparse else risk[key]
    ds = s['decimal_strings']
    require(ds['NAV'] == review['exact_NAV']
            and e['fees_USDT'] == review['fees_USDT']
            and e['funding_USDT'] == review['funding_USDT']
            and e['execution_cost_USDT'] == review['execution_cost_USDT'], 'MONEY_REVIEW_MATCH')
    paid_return = exact_ratio(ds['net_PnL']) if e['paid_net_return'] is not None else None
    return dict(
        cell_id=cell['cell_id'], year=cell['year'], tier=cell['tier'],
        start_UTC=cell['start_UTC'], end_exclusive_UTC=cell['end_exclusive_UTC'],
        calendar_days=cell['calendar_days'], full_year=cell['calendar_days'] in (365, 366),
        status='REVIEWED', terminal_status=receipt['status'],
        completed_minutes=receipt['completed_minutes'], required_minutes=receipt['required_minutes'],
        independent_fresh_cash_USDT=cell['initial_cash_USDT'],
        terminal_NAV_USDT=ds['NAV'], net_PnL_USDT=ds['net_PnL'], paid_net_return=paid_return,
        marked_net_return=e['marked_net_return'], halted_prefix_return=e['halted_prefix_return'],
        paid_market_flat=e['actual_paid_market_flat'], full_calendar=e['full_calendar'],
        all_observation_max_drawdown=e['all_observation_max_drawdown'],
        gross_same_quantity_PnL_USDT=ds['gross_PnL_same_quantities'],
        fees_USDT=e['fees_USDT'], combined_spread_slippage_cost_USDT=e['execution_cost_USDT'],
        signed_funding_cash_USDT=e['funding_USDT'],
        gross_paid_fill_turnover_USDT=e['actual_paid_market_turnover_USDT'],
        turnover_over_initial_cash=exact_ratio(e['actual_paid_market_turnover_USDT']),
        trade_legs=s['trade_legs'], funding_applied_events=s['funding_account_applied_events'],
        liquidation_fills=e['actual_liquidation_fills'],
        conditional_position_settlements=e['conditional_position_settlements'],
        conditional_NAV_adjustment_USDT=e['conditional_NAV_adjustment_USDT'],
        unpaid_liability_USDT=e['unpaid_liability'],
        risk_status=risk_status, risk_observation_count=risk['observation_count'],
        risk_omitted_nonpositive_or_later_minutes=omitted,
        mean_minute_gross_exposure=rv('gross_exposure_mean'),
        max_minute_gross_exposure=rv('gross_exposure_max'),
        max_all_observation_gross_exposure=s['maximum_actual_gross_weight'],
        mean_minute_net_signed_exposure=rv('actual_net_signed_weight_mean'),
        max_minute_absolute_asset_exposure=rv('asset_exposure_absolute_max'),
        forecast_annual_vol_mean=rv('forecast_annual_volatility_mean'),
        forecast_annual_vol_max=rv('forecast_annual_volatility_max'),
        nominal_annual_vol_budget=rv('nominal_annual_volatility_budget'),
        forecast_vol_breach_minutes=rv('forecast_volatility_breach_minutes'),
        realized_daily_return_annual_vol=rv('realized_daily_simple_return_annual_volatility'),
        raw_target_gross_mean=rv('raw_target_gross_mean'),
        raw_target_gross_max=rv('raw_target_gross_max'),
        positive_raw_target_minus_actual_gross_mean=rv('positive_raw_target_minus_actual_gross_mean'),
        min_minute_free_cash_USDT=rv('minimum_observed_free_cash_USDT'),
        max_minute_isolated_margin_USDT=rv('maximum_observed_isolated_margin_USDT'),
        minutes_free_cash_below1000=rv('minutes_observed_free_cash_below1000'),
        minutes_margin_above8500=rv('minutes_observed_margin_above8500'),
        actual_absolute_weight_max_by_symbol=rv('actual_absolute_weight_max_by_symbol'),
        actual_absolute_weight_mean_by_symbol=rv('asset_exposure_absolute_mean_by_symbol'),
        guard_selection_counts=rv('guard_selection_counts'),
        quality_intervals=review['quality']['interval_count'],
        quality_block_rows=review['quality']['quality_block_rows'],
        max_RSS_bytes=receipt['max_RSS_bytes'], CPU_seconds=receipt['CPU_seconds'],
        wall_seconds=receipt['total_wall_seconds'])


def collect():
    scope, scope_pin = read_json(NATIVE / 'FROZEN_FIFTEEN_CELL_MANIFEST.json')
    require(scope_pin['SHA256'] == SCOPE_SHA and scope['cell_count'] == 15, 'SCOPE')
    rows, pins = [], [scope_pin]
    for cell in sorted(scope['cells'], key=lambda c: (c['year'], ('LOW', 'MID', 'HIGH').index(c['tier']))):
        directory, review_path = COHORT / cell['cell_id'], REVIEWS / (cell['cell_id'] + '.review.json')
        checkpoint = directory / 'TERMINAL_CHECKPOINT.json'
        if not checkpoint.is_file() or not review_path.is_file():
            rows.append(dict(cell_id=cell['cell_id'], year=cell['year'], tier=cell['tier'],
                             status='PENDING_SAVED_REVIEW' if checkpoint.is_file() else 'PENDING_TERMINAL'))
            continue
        terminal, terminal_pin = read_json(checkpoint)
        review, review_pin = read_json(review_path)
        require(terminal_pin['SHA256'] == review['terminal_checkpoint']['SHA256'], 'REVIEW_TERMINAL_PIN')
        require(terminal['cell_id'] == cell['cell_id'] and terminal['fresh_scope_revoked'] is True,
                'TERMINAL_IDENTITY_OR_SCOPE')
        selected = {}
        for name in ('CASE_RECEIPT.json', 'NATIVE_RESULT.json', 'ACTUAL_HELD_RISK_REPORT.json'):
            value, pin = read_json(directory / name)
            require(pin['SHA256'] == terminal['files'][name], 'SAVED_FILE_PIN_' + name)
            selected[name] = value
            pins.append(pin)
        row = metrics(cell, selected['CASE_RECEIPT.json'], selected['NATIVE_RESULT.json'],
                      selected['ACTUAL_HELD_RISK_REPORT.json'], review)
        row['terminal_checkpoint_SHA256'] = terminal_pin['SHA256']
        row['independent_saved_review_SHA256'] = review_pin['SHA256']
        rows.append(row)
        pins += [terminal_pin, review_pin]
    return rows, pins


def build():
    rows, pins = collect()
    reviewed = sum(r['status'] == 'REVIEWED' for r in rows)
    output = dict(schema='HIGH365_REVIEWED_SAVED_COST_MDD_EXPOSURE_MATRIX_V1',
        status='ALL15_REVIEWED' if reviewed == 15 else 'PARTIAL_REVIEWED_SNAPSHOT',
        reviewed_count=reviewed, total_count=15, root_GO_SHA256=GO_SHA,
        builder_SHA256=digest(Path(__file__).read_bytes()),
        native_code_manifest_SHA256=CODE_SHA, source_preparation_SHA256=PREP_SHA,
        saved_only=True, new_financial_execution=False, source_arrays_read=False,
        annual_wallets_compounded=False, rows=rows, input_pins=pins,
        definitions=dict(paid_net_return='Exact saved native40 net_PnL / independent initial10000, only when paid return exists.',
            partial2021='April2-Dec31,274 days; raw period return is not annualized.',
            drawdown='Saved all-observation NAV peak drawdown including observed minute marks/fills/funding; not unknown intraminute extrema.',
            execution_cost='Combined BASE27 adverse spread+slippage, already embedded in realized PnL and never subtracted again here. Separate realized spread/slippage ledgers are not identifiable; configured halfspread4bp and slippage4bp per side. Fees are5.5bp on actual fill notional.',
            funding='Signed cash: positive received, negative paid; raw-as-fraction/event-time conditional, units/publication uncertified.',
            exposures='Minute-close post-transition observations unless field explicitly says all-observation; means are not continuous-time guarantees.',
            risk='Nominal tier ceilings, lower-only intrinsic signal; observed forecast/realized risk can differ and drift breaches are retained.',
            realized_volatility='std(ddof1, complete daily NAV simple returns including initial10000)*sqrt365;2021 is an annualized daily-vol diagnostic over274 days, while its paid period return remains unannualized.',
            capital='Compact receipts cannot identify exact capital-binding counts or attribute exposure shortfall to capital alone.'),
        limitations=['Seen DEV only; no untouched-OOS or candidate qualification claim.',
            'Historical exchange filters, source arrival, funding publication/units and native liquidation are uncertified.',
            'Financial ledger/reconciliation authority remains the independent frozen saved validator, not this selection transform.',
            'Filesystem disk guard polls are operational safeguards and cannot guarantee external writers.'])
    data = (json.dumps(output, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()
    columns = list(dict.fromkeys(k for row in rows for k in row))
    buf = io.StringIO(newline='')
    writer = csv.DictWriter(buf, fieldnames=columns)
    writer.writeheader()
    for row in rows:
        writer.writerow({k: json.dumps(v, sort_keys=True) if isinstance(v, dict) else v for k, v in row.items()})
    csv_data = buf.getvalue().encode()
    require(len(data) + len(csv_data) <= 500_000, 'SMALL_PACKET_LIMIT')
    require(os.statvfs(HERE).f_bavail * os.statvfs(HERE).f_frsize >= 1610612736 + len(data) + len(csv_data),
            'DISK_FLOOR_NO_MATRIX_WRITE')
    for name, raw in [('COST_MDD_EXPOSURE_MATRIX.json', data), ('COST_MDD_EXPOSURE_MATRIX.csv', csv_data)]:
        path = HERE / name
        temporary = path.with_suffix(path.suffix + '.tmp')
        temporary.write_bytes(raw)
        temporary.replace(path)
    print(json.dumps(dict(status=output['status'], reviewed=reviewed, total=15,
                          JSON_SHA256=digest(data), CSV_SHA256=digest(csv_data))))


if __name__ == '__main__':
    build()
