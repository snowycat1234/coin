Finite 2024 source/target gate. No actual 2024 financial account has been constructed or advanced by this work.

Scope
- Unchanged frozen nine-cell V3, CORE5 order, BASE27, three nominal tiers, quantity sensitivity profile, partial ladder, fresh-flat unknown-prior cold start, paid terminal60 and financial methods.
- All 366 daily target/covariance arrays are built by unchanged frozen_grid.build_target_grid.
- Exact pre-return execution reuse only within the same tier and full source/code/cost/covariance identity. Actual 2024 target paths require all nine canonical jobs. Tiny STATIC50/H090 differences are not independent alpha.
- Label: OFFLINE PROXY WITH COARSE QUANTITY SENSITIVITY. Derived SOL1/XRP100/DOGE1000 steps are not exchange filters. No exchange-native execution, publication/arrival, funding-unit, margin, or liquidation certification.
- Warmup export contains 566x5=2830 actual source closes. The union actually consumed by 366 completed 200-close decision windows is 565x5=2825; these counts must not be conflated.

Original interpolated marks are never execution-admitted
Exactly ten original mark cells, at opens 2024-08-12 10:02 and 10:03 UTC across CORE5, are TIME_LINEAR_PRIOR_CLOSE_TO_NEXT_OPEN derivatives. They depend on a future endpoint. Original source index, overlay, and normalized month bytes are preserved and hash-pinned.

Separate causal adapter
missing_mark_adapter_2024.project_month changes only those ten projected mark values to the last genuine 10:01-bar close, known at 10:02. Sidecars preserve genuine source availability 10:02, estimated valuation times 10:03/10:04, age, missing/derived/stale flags, and absence of current venue mark certification. Missingness is not used early at 10:02.

causal_mark_quality.CausalMarkQualityGuard installs inside the frozen PartialTierGuard.original_attempt. It blocks planned positive non-reduce requests from 10:03 until the next genuine close is installed at 10:05; earliest actual resume fill is 10:05:00.000001. Native known-ID duplicate/conflict handling, true paid reductions, retries, and HALTs retain their native path. Full-day prefetch/decompression does not advance quality state. Recovery also checks actual installed account mark clocks, not merely event time.

Preparation
Use coin_partial_restore_20261014/.venv/bin/python with OPENBLAS_NUM_THREADS=1 and OMP_NUM_THREADS=1. Import annual_entry_2024 and call prepare_source_only(source_root, new_exclusive_output_directory). This writes targets, proofs, pre-return equality, source qualifications, the explicit adapter receipt, and PREPARATION.json. It never constructs an account or computes annual financial outcomes.

Admission
validate_annual_inputs validates the exact finite 2024 preparation/source/code/target/covariance/artifact/GO scope and returns immutable-captured, lazily decoded source data. All month/daily/events/warmup/proof/overlay bytes are captured at admission; no unchecked source path is reopened during iteration. It grants no account GO.

make_annual_case additionally requires separately supplied exact independent-review bytes/hash and new exact external root GO bytes/hash, both binding the same preparation/code/source/artifacts/policy. It constructs but never dispatches an account. Tests reach only a mocked native constructor returning pure stand-ins, then install the actual quality guard on those stand-ins. No actual 2024 account is created by those tests. A source-only review is not root GO. General historical NO_GO remains unchanged.

No actual 2024 execution, outcomes, fitting, other-year evaluation, locked/OOS consumption, downloads, or publication is authorized by these files.
