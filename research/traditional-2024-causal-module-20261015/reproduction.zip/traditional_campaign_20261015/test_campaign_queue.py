"""Generated queue mutations and saved-only planning checks; never launch."""
from copy import deepcopy
import json
from pathlib import Path
import tempfile
import unittest
import campaign_queue as q


class CampaignQueueTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.queue=q.build_queue()
    def altered(self):return deepcopy(self.queue)
    def test_core27_first_batch_not_full_expanded_campaign(self):
        self.assertEqual(len(self.queue['cells']),27)
        self.assertEqual(self.queue['core_first_batch_requested_cells'],27)
        self.assertEqual(self.queue['expanded_inventory']['status'],'PENDING_SOURCE_BACKED_VARIANT_INVENTORY_REVIEW')
        self.assertTrue(all(not c['launchable'] for c in self.queue['cells']))
    def test_completed2023_reuses_nine_exact_saved_results(self):
        cells=[c for c in self.queue['cells'] if c['year']==2023]
        self.assertEqual(len(cells),9)
        self.assertTrue(all(c['do_not_rerun'] and c['result']['completed_minutes']==525600 for c in cells))
        self.assertTrue(all(c['review_receipt_SHA256'] for c in cells))
    def test_duplicate_cell_id_fails(self):
        v=self.altered();v['cells'][1]['cell_id']=v['cells'][0]['cell_id']
        with self.assertRaisesRegex(ValueError,'DUPLICATE'):q.validate_queue(v)
    def test_bad_calendar_tier_or_parameter_fingerprint_fails(self):
        for key,value in [('calendar',[0,1]),('year',2026),('tier','ULTRA'),('parameter_fingerprint','0'*64)]:
            v=self.altered();v['cells'][0][key]=value
            with self.subTest(key=key),self.assertRaises(ValueError):q.validate_queue(v)
    def test_completed_or_blocked_or_unbound_cannot_launch(self):
        for index in [0,3,6]:
            v=self.altered();v['cells'][index]['launchable']=True
            with self.assertRaises(ValueError):q.validate_queue(v)
    def test_2025_block_cannot_be_silently_changed_to_ready(self):
        v=self.altered();cell=next(c for c in v['cells'] if c['year']==2025);cell['status']='READY'
        with self.assertRaisesRegex(ValueError,'2025_SOURCE_BLOCK'):q.validate_queue(v)
    def test_batch_requires_exact_three_risk_cells_and_completion(self):
        for mutation in ['missing','unready']:
            v=self.altered();batch=v['batches'][0 if mutation=='missing' else 1]
            if mutation=='missing':batch['cell_ids'].pop()
            else:batch['ready_for_saved_evidence_publication']=True
            with self.subTest(mutation=mutation),self.assertRaises(ValueError):q.validate_queue(v)
    def test_three_completed_2023_batches_are_publication_ready_not_claimed_published(self):
        ready=[b for b in self.queue['batches'] if b['ready_for_saved_evidence_publication']]
        self.assertEqual(len(ready),3)
        self.assertTrue(all(b['publication_commit'] is None for b in ready))
    def test_exclusive_atomic_snapshot_never_overwrites(self):
        with tempfile.TemporaryDirectory() as temp:
            out=Path(temp)/'snapshot';digest=q.write_snapshot(out,self.queue)
            self.assertEqual(digest,q.sha((out/'CAMPAIGN.json').read_bytes()))
            self.assertFalse((out/'CAMPAIGN.json.partial').exists())
            with self.assertRaises(FileExistsError):q.write_snapshot(out,self.queue)
    def test_unpinned_subversion_registry_is_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            f=Path(temp)/'registry.json';f.write_text(json.dumps({'schema':'SOURCE_BACKED_TRADITIONAL_VARIANT_REGISTRY_V1',
                'variants':[{'variant_id':'FAKE','category':'TARGET_POLICY','definition_fingerprint':'x','sizing_semantics':'x','source_files':[{}]}]}))
            with self.assertRaisesRegex(ValueError,'SOURCE_PIN'):q.optional_registry(f)
    def test_alias_or_invalid_implementation_does_not_inflate_variants(self):
        with tempfile.TemporaryDirectory() as temp:
            f=Path(temp)/'registry.json';f.write_text(json.dumps({'schema':'SOURCE_BACKED_TRADITIONAL_VARIANT_REGISTRY_V1',
                'variants':[{'variant_id':'ALIAS','is_alias':True},{'variant_id':'BUG','known_invalid':True}]}))
            variants,_=q.optional_registry(f)
            self.assertEqual(variants,[])

    def test_versioned_inventory_preserves_definition_and_universe_blocks(self):
        registry=q.ROOT/'traditional_variant_inventory_20261015/VARIANT_REGISTRY.json'
        full=q.build_queue(variant_registry=registry)
        values=json.loads(registry.read_bytes())['variants']
        expected=sum(v.get('category')=='TARGET_POLICY' and not v.get('is_alias') and not v.get('known_invalid') for v in values)
        self.assertEqual(full['total_requested_cells'],expected*9)
        self.assertEqual(len(full['variants']),expected)
        self.assertEqual(sum(c['status'].startswith('COMPLETED_') for c in full['cells']),9)
        self.assertTrue(all(not c['launchable'] for c in full['cells']))
        finite=[c for c in full['cells'] if c['variant_id']=='H090_FINITE_BTC_REPLACE10' and c['year']!=2025]
        self.assertTrue(all(c['status']=='BLOCKED_VARIANT_DEFINITION' and c['tier_mapping'] for c in finite))
        ten=[c for c in full['cells'] if c['input_universe']=='LIQUIDITY_TEN' and c['year']!=2025]
        self.assertTrue(ten)
        self.assertTrue(all(c['status']=='BLOCKED_ORIGINAL_UNIVERSE_SOURCE_AND_ADAPTER' and c['universe_requires_new_source'] for c in ten))
        old=next(c for c in full['cells'] if c['variant_id']=='STATIC50_OLD_NO_REEXPANSION')
        self.assertTrue(old['tier_mapping']['no_reexpansion'])
        self.assertEqual(old['adapter_status'],'PENDING_SOURCE_PRESERVING_COMMON_ADAPTER_REVIEW')


if __name__=='__main__':unittest.main(verbosity=2)
