"""Saved-only campaign planning/checkpointing; this file never launches a job.

The first core batch has27 requested cells, not27 independent strategies and
not the entire expanded subversion campaign. Missing source/adapter/GO pins
are explicit blockers. Completed2023 jobs are referenced, never re-executed.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
from datetime import datetime, timezone

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
CORE=ROOT/'traditional_three_tier_freeze_20261015'
STRATEGIES=('STATIC50','H090','VOL_MANAGED_HOLD')
YEARS=(2023,2024,2025)
TIERS={'LOW':(.30,.05),'MID':(.60,.10),'HIGH':(.90,.15)}
PREP2023='43c715123c2be9a1398bd5242bc86da27efaf1cd30927117d9d835a3bcaebb43'
GO2023={'pilot':'6930d9450279f652db8f6b644ec00043a6cedb166410191859c2f666d62f37ef',
    'remaining':'c46cc26b8039c372ec973557a9b6a2fd8b4b0f80f354612795b1da9eb60489e0'}
LIMITS={'per_case_wall_seconds':600,'CPU_threads':1,'RSS_stop_bytes':2000000000,
    'AS_bytes':4000000000,'output_bytes':250000000,'maximum_simultaneous_financial_jobs':1}


def sha(raw):return hashlib.sha256(raw).hexdigest()
def fingerprint(value):return sha(json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode())
def read(path):return json.loads(Path(path).read_bytes())
def epoch(year):return int(datetime(year,1,1,tzinfo=timezone.utc).timestamp()*1000000)


def parameter_spec(tier):
    gross,vol=TIERS[tier]
    return dict(tier=tier,gross_ceiling=gross,asset_ceiling=.30,annual_volatility_target=vol,
        annualization_days=365,initial_cash_USDT='10000',leverage=1,cost='BASE27',
        free_cash_increase_floor_USDT='1000',actual_isolated_margin_ceiling_USDT='8500',
        partial_ladder=['1','.75','.5','.25','0'],paid_terminal_minutes=60,
        quantity_profile_SHA256='94b2238b25ed345a24a1fa148c6f35523b8efe9bf47496958028844432cb8ebf',
        coldstart='FRESH_FLAT_IGNORE_PRIOR_DEFER_FIRST_REAL_COMPLETED_MINUTE',
        classification='NATIVE_ACCOUNT_OFFLINE_PROXY_WITH_COARSE_QUANTITY_SENSITIVITY')


def core_definitions(prep):
    kinds={'STATIC50':'CANONICAL_PORTFOLIO_RISK_RETARGETED',
        'H090':'ONCE1P5_STATIC50_CLIP_GROSS_VOL_ORDER_THEN_COMMON_TIER',
        'VOL_MANAGED_HOLD':'ORIGINAL_CONSTANT_LONG_CORE5_VOL_MANAGED_NOT_INVERSE_VOL'}
    definitions=[]
    for strategy in STRATEGIES:
        value=dict(variant_id=strategy,strategy_family=strategy,category='TARGET_POLICY',
            sizing_semantics=kinds[strategy],frozen_grid_SHA256=prep['code_identity']['frozen_grid.py'],
            source_provenance_SHA256=prep['code_identity']['SOURCE_PROVENANCE.json'],
            frozen_spec_SHA256=prep['code_identity']['FROZEN_SPEC.json'],
            source_locator='PUBLIC_V3_SOURCE_PROVENANCE_AND_EXACT_ORIGINAL_FUNCTIONS',
            is_alias=False,known_invalid=False,adapter_status='FROZEN_CORE_ADAPTER',
            independent_alpha_claim=False)
        value['definition_fingerprint']=fingerprint(value)
        definitions.append(value)
    return definitions


def checked_completed_2023(config,prep):
    role='pilot' if config=='STATIC50_MID' else 'remaining'
    folder=CORE/('actual_2023_pilot_attempt001' if role=='pilot' else 'actual_2023_remaining_attempt001')
    go_raw=(folder/'ROOT_GO.json').read_bytes();go=json.loads(go_raw)
    path=folder/config;r=read(path/'CASE_RECEIPT.json');o=read(path/'RESULT.json')
    if (sha(go_raw)!=GO2023[role] or config not in go['permitted_configs']
            or r['root_GO_SHA256']!=sha(go_raw) or r['preparation_SHA256']!=PREP2023
            or r['code_identity']!=prep['code_identity'] or r['config']!=config
            or r['calendar']!=[epoch(2023),epoch(2024)]
            or r['completed_minutes']!=525600 or not r['paid_comparison_eligible']
            or not o['economics']['paid_flat'] or o['economics']['residual_marked_notional']!=0
            or o['economics']['unpaid_liability']!='0'
            or o['target_meta']['source_target_identity']!=prep['target_identity']['SHA256_by_config'][config]):
        raise ValueError('COMPLETED2023_IDENTITY_OR_PAID_SCOPE_MISMATCH:'+config)
    return dict(case_directory=str(path.relative_to(ROOT)),root_GO_SHA256=sha(go_raw),
        receipt_SHA256=sha((path/'CASE_RECEIPT.json').read_bytes()),
        result_SHA256=sha((path/'RESULT.json').read_bytes()),
        minute_parent_SHA256=sha((path/'MINUTE.npz').read_bytes()),
        target_fingerprint=prep['target_identity']['SHA256_by_config'][config],
        status='COMPLETED_PAID_FULL_YEAR_INDEPENDENTLY_REVIEWED',
        completed_minutes=525600,financial_rerun_required=False)


def optional_registry(path):
    if path is None:return [],dict(status='PENDING_SOURCE_BACKED_VARIANT_INVENTORY_REVIEW',path=None,SHA256=None)
    raw=Path(path).read_bytes();registry=json.loads(raw)
    if registry.get('schema')!='SOURCE_BACKED_TRADITIONAL_VARIANT_REGISTRY_V1':
        raise ValueError('EXACT_REVIEWED_VARIANT_REGISTRY_SCHEMA_REQUIRED')
    extra=[]
    for value in registry['variants']:
        if value.get('is_core') or value.get('is_alias') or value.get('known_invalid'):continue
        if value.get('category')!='TARGET_POLICY':continue
        if (not value.get('variant_id') or not value.get('definition_fingerprint')
                or not value.get('source_files') or not value.get('sizing_semantics')):
            raise ValueError('SOURCE_BACKED_INTRINSIC_VARIANT_DEFINITION_REQUIRED')
        for source in value['source_files']:
            if not all(source.get(k) for k in ('repository','path','commit','SHA256')):
                raise ValueError('EXACT_VARIANT_SOURCE_PIN_REQUIRED')
        extra.append(value)
    return extra,dict(status='SOURCE_BACKED_REGISTRY_INCLUDED_ADAPTERS_STILL_REQUIRE_REVIEW',
        path=str(Path(path)),SHA256=sha(raw))


def build_queue(*,variant_registry=None):
    ppath=CORE/'annual_2023_source_preparation_attempt003/PREPARATION.json'
    praw=ppath.read_bytes()
    if sha(praw)!=PREP2023:raise ValueError('EXACT_FROZEN2023_PREPARATION_REQUIRED')
    prep=json.loads(praw);variants=core_definitions(prep)
    review_path=ROOT/'traditional_three_tier_independent_review_20261015/ANNUAL_MATRIX_FINAL_SAVED_REVIEW.json'
    review_raw=review_path.read_bytes();review=json.loads(review_raw)
    if (review['status']!='PASS_ALL_NINE_SAVED_FINANCIAL_AND_OPENING_EVIDENCE'
            or review['preparation_SHA256']!=PREP2023):
        raise ValueError('EXACT_REVIEWED_CORE2023_COMPLETION_REQUIRED')
    additional,inventory=optional_registry(variant_registry);variants+=additional
    ids=[v['variant_id'] for v in variants]
    if len(ids)!=len(set(ids)):raise ValueError('DUPLICATE_VARIANT_ID')
    source2024=ROOT/'native_2024_source_restore_20261015/public_recovery_package/RECOVERY_MANIFEST.json'
    source2025=ROOT/'native_2025_source_restore_20261015/BLOCKED_RECOVERY_RECEIPT.json'
    p2024raw=(CORE/'annual_2024_source_preparation_attempt002/PREPARATION.json').read_bytes()
    if sha(p2024raw)!='657317bb8c025d8ab926e66a57078bfcf2a8d684be6dcc40a0ac8e7502b29b46':
        raise ValueError('EXACT_REVIEWED2024_SOURCE_PREPARATION_REQUIRED')
    p2024=json.loads(p2024raw)
    source_refs={2023:dict(source_fingerprint=prep['source_identity'],preparation_SHA256=PREP2023),
        2024:dict(original_recovery_manifest_SHA256=sha(source2024.read_bytes()),
            public_commit='b3de53d613489ec90f9c70874cdf712cf70db5a8',
            source_fingerprint=p2024['source_identity'],preparation_SHA256=sha(p2024raw),
            source_only_review_SHA256='493683d02e060a1e0015df0963e66effa11eddb95582b17cd43b9e7463b942bd',
            causal_adapter_artifact=p2024['artifacts']['CAUSAL_MARK_ADAPTER.json'],
            original_interpolated_mark_execution_admitted=False,
            blocker='SOURCE_AND_CAUSAL_ADAPTER_REVIEW_PASS_WAIT_DRIVER_REVIEW_AND_EXACT_ROOT_GO'),
        2025:dict(original_source_index_SHA256='8a0235e428902f7a0ea4ec1893343abae6ccc23715080771796b54fb58f1f3c4',
            public_commit='af6d8e1426c663f3d5afb2da311755487681c232',
            blocker_receipt_SHA256=sha(source2025.read_bytes()),source_fingerprint=None,
            preparation_SHA256=None,blocker='ESSENTIAL_SOURCE_PART_HTTP403_STOP_NO_RETRY_OR_ALTERNATE_ROUTE')}
    cells=[]
    for variant in variants:
        for year in YEARS:
            for tier in TIERS:
                config=variant['variant_id']+'_'+tier
                cell=dict(cell_id=f'TRADITIONAL__{variant["variant_id"]}__{tier}__Y{year}__BASE27__1X',
                    phase='CORE_FIRST_BATCH' if variant['variant_id'] in STRATEGIES else 'EXPANDED_SOURCE_BACKED_SUBVERSIONS',
                    year=year,calendar=[epoch(year),epoch(year+1)],variant_id=variant['variant_id'],tier=tier,
                    definition_fingerprint=variant['definition_fingerprint'],parameters=parameter_spec(tier),
                    parameter_fingerprint=fingerprint(parameter_spec(tier)),source=source_refs[year],
                    execution_fingerprint=prep['execution_identity'] if year==2023 and variant['variant_id'] in STRATEGIES else None,
                    target_fingerprint=None,root_GO_SHA256=None,review_receipt_SHA256=None,
                    adapter_status=variant['adapter_status'],
                    input_universe=variant.get('input_universe','CORE5'),
                    universe_requires_new_source=variant.get('universe_requires_new_source',False),
                    input_mask=variant.get('input_mask'),tier_mapping=variant.get('tier_mapping'),
                    common_execution_comparability=variant.get('common_execution_comparability'),
                    original_execution=variant.get('original_execution'),
                    result=None,launchable=False)
                if year==2023 and variant['variant_id'] in STRATEGIES:
                    result=checked_completed_2023(config,prep)
                    cell.update(status=result['status'],result=result,target_fingerprint=result['target_fingerprint'],
                        root_GO_SHA256=result['root_GO_SHA256'],review_receipt_SHA256=sha(review_raw),
                        do_not_rerun=True)
                elif year==2025:cell.update(status='BLOCKED_SOURCE_HTTP403',do_not_rerun=False)
                elif variant['variant_id'] not in STRATEGIES:
                    block=('BLOCKED_VARIANT_DEFINITION' if str(variant.get('tier_mapping',{}).get('mode','')).startswith('BLOCKED_DEFINITION')
                        or 'BLOCKED_TIER_DEFINITION' in variant['adapter_status'] else
                        'BLOCKED_ORIGINAL_UNIVERSE_SOURCE_AND_ADAPTER' if cell['universe_requires_new_source'] else
                        'BLOCKED_VARIANT_RECOVERY_AND_INTEGRATION' if variant['adapter_status'].startswith('BLOCKED') else
                        'WAIT_INTRINSIC_VARIANT_ADAPTER_PREPARATION_REVIEW_AND_EXACT_ROOT_GO')
                    cell.update(status=block,do_not_rerun=False,
                        definition_and_source_blockers=dict(adapter_status=variant['adapter_status'],
                            tier_mapping=variant.get('tier_mapping'),
                            input_universe=variant.get('input_universe','CORE5'),
                            universe_requires_new_source=cell['universe_requires_new_source']))
                else:cell.update(status='WAIT_CAUSAL2024_FEED_GUARD_SOURCE_TARGET_PREPARATION_REVIEW_AND_EXACT_ROOT_GO',do_not_rerun=False)
                cells.append(cell)
    batches=[]
    for variant in variants:
        for year in YEARS:
            group=[c for c in cells if c['variant_id']==variant['variant_id'] and c['year']==year]
            batches.append(dict(batch_id=f'{variant["variant_id"]}__Y{year}__THREE_RISK_CELLS',
                cell_ids=[c['cell_id'] for c in group],required_cells=3,
                ready_for_saved_evidence_publication=all(c['status'].startswith('COMPLETED_') for c in group),
                publication_status='PENDING_EXACT_REMOTE_PUBLICATION_PROOF',publication_commit=None))
    queue=dict(schema='FINITE_EXPANDED_TRADITIONAL_CAMPAIGN_QUEUE_V1',
        created_UTC=datetime.now(timezone.utc).isoformat(),core_first_batch_requested_cells=27,
        total_requested_cells=len(cells),expanded_inventory=inventory,variants=variants,cells=cells,batches=batches,
        fixed_years=list(YEARS),resource_limits=LIMITS,
        scheduling='SERIAL_READY_CASES_ONLY_AFTER_EXACT_SOURCE_ADAPTER_REVIEW_AND_ROOT_GO; NO_JOB_IS_LAUNCHED_BY_THIS_MODULE',
        result_persistence='EXCLUSIVE_CASE_OUTPUTS_AND_ATOMIC_MANIFEST_CHECKPOINT_PER_TERMINAL; PRESERVE_FAILURES_AND_NEGATIVE_RESULTS',
        failure_policy='STOP_ON_ACTUAL_ERROR_OR_LIMIT_NO_AUTOMATIC_RETRY',
        publication_policy='PUBLISH_EACH_REVIEWED_VARIANT_YEAR_THREE_RISK_BATCH_WHILE_OTHER_READY_JOBS_RUN',
        routine_user_reconfirmation_required=False,exact_technical_root_GO_required=True,
        duplicate2023_runs_authorized=False,source2025_runnable=False,
        riskmatched_excess_method='NOT_PREREGISTERED_NOT_CLAIMED',
        economic_identity_note='STATIC50/H090 are not independent alpha; all2023 paired economic paths are exactly equal, but nine requested jobs were executed separately.',
        known_invalid_old_smoke='Attempt001V2 is preserved engineering failure evidence, not a strategy variant or annual campaign result.')
    validate_queue(queue)
    queue['candidate_set_fingerprint']=fingerprint([dict(variant_id=v['variant_id'],definition_fingerprint=v['definition_fingerprint']) for v in variants])
    return queue


def validate_queue(queue):
    cells=queue['cells'];ids=[c['cell_id'] for c in cells]
    if len(ids)!=len(set(ids)):raise ValueError('DUPLICATE_CAMPAIGN_CELL_ID')
    if queue['core_first_batch_requested_cells']!=27 or queue['total_requested_cells']!=len(cells):
        raise ValueError('REQUESTED_CELL_COUNT_MISMATCH')
    for cell in cells:
        if cell['year'] not in YEARS or cell['tier'] not in TIERS or cell['calendar']!=[epoch(cell['year']),epoch(cell['year']+1)]:
            raise ValueError('FINITE_YEAR_TIER_SCOPE_REQUIRED')
        if cell['parameter_fingerprint']!=fingerprint(cell['parameters']):raise ValueError('PARAMETER_FINGERPRINT_CHANGED')
        if cell.get('launchable'):
            required=(cell.get('execution_fingerprint'),cell.get('target_fingerprint'),cell.get('root_GO_SHA256'),
                cell['source'].get('source_fingerprint'),cell['source'].get('preparation_SHA256'),
                cell.get('review_receipt_SHA256'))
            if (cell['status'].startswith(('COMPLETED','BLOCKED','WAIT')) or cell.get('do_not_rerun') or not all(required)):
                raise ValueError('BLOCKED_OR_COMPLETED_OR_UNBOUND_CELL_CANNOT_LAUNCH')
        if cell['year']==2025 and (cell['status']!='BLOCKED_SOURCE_HTTP403' or cell.get('launchable')):
            raise ValueError('2025_SOURCE_BLOCK_CANNOT_BE_SILENTLY_BYPASSED')
        if (cell.get('universe_requires_new_source') and cell.get('launchable')
                or str((cell.get('tier_mapping') or {}).get('mode','')).startswith('BLOCKED_DEFINITION') and cell.get('launchable')):
            raise ValueError('ORIGINAL_UNIVERSE_OR_TIER_DEFINITION_BLOCK_CANNOT_BE_BYPASSED')
    for batch in queue['batches']:
        group=[c for c in cells if c['cell_id'] in batch['cell_ids']]
        if len(group)!=3 or len({c['year'] for c in group})!=1 or len({c['variant_id'] for c in group})!=1:
            raise ValueError('EXACT_THREE_RISK_VARIANT_YEAR_BATCH_REQUIRED')
        if batch['ready_for_saved_evidence_publication']!=all(c['status'].startswith('COMPLETED_') for c in group):
            raise ValueError('UNFINISHED_BATCH_CANNOT_CLAIM_READY')
    return True


def write_snapshot(output,queue):
    validate_queue(queue)
    directory=Path(output);directory.mkdir(exist_ok=False)
    body=(json.dumps(queue,indent=2,allow_nan=False)+'\n').encode()
    temporary=directory/'CAMPAIGN.json.partial'
    with temporary.open('xb') as handle:handle.write(body);handle.flush();os.fsync(handle.fileno())
    temporary.rename(directory/'CAMPAIGN.json')
    (directory/'CAMPAIGN_SHA256.txt').write_text(sha(body)+'\n')
    return sha(body)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',required=True);p.add_argument('--variant-registry')
    args=p.parse_args();print(write_snapshot(args.output,build_queue(variant_registry=args.variant_registry)))
