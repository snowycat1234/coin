"""Generated metadata, temporary files and mocked subprocesses only.

No actual 2024 source account is constructed or run. The source-only review
receipt is read to verify the explicit immutable chain, never rewritten.
"""
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
from unittest.mock import patch,Mock
from copy import deepcopy
import hashlib,json,subprocess,sys,unittest,numpy as np
ROOT=Path(__file__).resolve().parent.parent;BUILD=ROOT/'traditional_three_tier_freeze_20261015';HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(BUILD))
import annual_entry_2024 as a
import run_actual_2024 as driver
import annual_reporting as report
PREP=BUILD/'annual_2024_source_preparation_attempt002'
SOURCE_REVIEW=HERE/'SOURCE_2024_FINAL_INDEPENDENT_REVIEW_RECEIPT.json'
SOURCE_REVIEW_SHA='493683d02e060a1e0015df0963e66effa11eddb95582b17cd43b9e7463b942bd'
raw=lambda value:json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
sha=lambda body:hashlib.sha256(body).hexdigest()


def fixture(configs=('STATIC50_MID',)):
 preparation=(PREP/'PREPARATION.json').read_bytes();prep=json.loads(preparation)
 source=SOURCE_REVIEW.read_bytes();assert sha(source)==SOURCE_REVIEW_SHA
 review={**json.loads(source),'controller_reporting_identity':driver.reporting_identity(),
  'source_review_receipt_SHA256':SOURCE_REVIEW_SHA,'generated_test_metadata_only_not_account_authorization':True}
 rb=raw(review)
 go=dict(schema='ROOT_GO_FIXED_FINITE_FULL2024_GRID_V1',action='RUN_FRESH_APPROVED_2024_CANONICAL_JOBS_ONLY',
  preparation_SHA256=sha(preparation),calendar=[a.START,a.END],cost='BASE27',code_identity=prep['code_identity'],
  source_identity=prep['source_identity'],artifacts=prep['artifacts'],resource_limits=driver.LIMITS,
  permitted_configs=list(configs),locked_or_holdout_consumed=False,other_years_authorized=False,
  original_interpolated_mark_execution_admitted=False,coldstart_policy=prep['coldstart_policy'],
  mark_feed_adapter_version=a.m.VERSION,mark_quality_guard_version=a.q.VERSION,
  independent_review_SHA256=sha(rb),source_review_receipt_SHA256=SOURCE_REVIEW_SHA,
  controller_reporting_identity=driver.reporting_identity(),serial_execution=True)
 return preparation,go,rb


def case_receipt(config,go,review_sha):
 prep=json.loads((PREP/'PREPARATION.json').read_bytes())
 return dict(schema='FINITE_FULL2024_CASE_RECEIPT_V1',status='COMPLETED_NATIVE_PATH',config=config,
  preparation_SHA256=go['preparation_SHA256'],root_GO_SHA256=sha(raw(go)),
  independent_review_SHA256=review_sha,source_review_receipt_SHA256=SOURCE_REVIEW_SHA,
  code_identity=prep['code_identity'],source_identity=prep['source_identity'],
  source_quality_adapter=prep['artifacts']['CAUSAL_MARK_ADAPTER.json'],controller_reporting_identity=driver.reporting_identity(),
  limits=driver.LIMITS,calendar=[a.START,a.END],completed_minutes=527040,required_minutes=527040,
  actual_complete_calendar_days=366,account_stop_us=None,paid_comparison_eligible=True,
  original_interpolated_mark_execution_admitted=False,stale_mark_block_count=0,
  execution_label='NATIVE_ACCOUNT_OFFLINE_PROXY_WITH_COARSE_QUANTITY_SENSITIVITY',
  total_wall_seconds=.1,CPU_seconds=.1,max_RSS_bytes=1000000,observed_output_bytes=0)


def args_for(temp,go,review):
 go_path=temp/'GENERATED_NOT_AUTHORIZATION_GO.json';review_path=temp/'GENERATED_COMBINED_REVIEW.json'
 go_path.write_bytes(raw(go));review_path.write_bytes(review)
 return SimpleNamespace(preparation=str(PREP),go=str(go_path),go_sha=sha(raw(go)),review=str(review_path),
  review_sha=sha(review),output=str(temp/'output'),source=str(ROOT/'native_2024_source_restore_20261015'))


class Independent2024Driver(unittest.TestCase):
 def test_actual_quality_class_is_attached_and_composed_before_advance(self):
  class Account:
   def execute_fill(self,*args,**kwargs):raise AssertionError('NO_FINANCIAL_FILL')
  class Sim:
   def __init__(self):self.account=Account();self.symbols=a.g.SYMBOLS;self.meta={}
   def inner(self,*args):raise AssertionError('NO_NATIVE_ATTEMPT')
  prep=json.loads((PREP/'PREPARATION.json').read_bytes());sim=Sim();partial=object.__new__(a.n.PartialTierGuard)
  partial.sim=sim;partial._installed=True;partial.original_attempt=sim.inner;sim.attempt=partial.attempt
  interval=a.q.StaleMarkInterval(a.m.FIRST_MISSING_KNOWN,a.m.RESUME_AVAILABLE,a.m.LAST_GENUINE_AVAILABLE,a.g.SYMBOLS)
  quality=a.q.CausalMarkQualityGuard(partial,intervals=(interval,),source_sidecar_sha256=prep['artifacts']['CAUSAL_MARK_ADAPTER.json']['SHA256']).install()
  partial.causal_mark_quality_guard=quality;sim.meta['mark_quality_policy_identity']=quality.policy_sha256
  self.assertIs(driver.validate_installed_quality(sim,partial,prep),quality)
  for owner,key,value in [(quality,'_installed',False),(partial,'original_attempt',sim.inner),(sim,'attempt',sim.inner),(quality,'source_sidecar_sha256','0'*64),(quality,'policy_sha256','0'*64)]:
   old=getattr(owner,key);setattr(owner,key,value)
   with self.subTest(field=key),self.assertRaisesRegex(ValueError,'BEFORE_ADVANCE'):driver.validate_installed_quality(sim,partial,prep)
   setattr(owner,key,old)
  quality.identity['NEW_UNREVIEWED_POLICY_FIELD']=True
  with self.assertRaisesRegex(ValueError,'BEFORE_ADVANCE'):driver.validate_installed_quality(sim,partial,prep)

 def test_case_with_missing_quality_layer_cannot_advance_any_clock(self):
  prepared,go,review=fixture()
  with TemporaryDirectory(prefix='generated-2024-pre-advance-') as tmp:
   temp=Path(tmp);args=args_for(temp,go,review);args.case_output=str(temp/'GENERATED_FAKE_CASE');args.config='STATIC50_MID'
   advance=Mock(side_effect=AssertionError('NEVER_ADVANCE'))
   sim=SimpleNamespace(account=SimpleNamespace(snapshot=lambda:dict(GENERATED_FAKE_ACCOUNT_NOT_FINANCIAL=True)),cursor=a.START,end=a.END,stop=None,rows_written=0,advance_day=advance)
   partial=SimpleNamespace(receipts=[])
   with patch.object(driver,'limits'),patch.object(driver.threading,'Thread',return_value=Mock()),patch.object(a,'make_annual_case',return_value=(sim,partial)),patch.object(a.n,'runtime',side_effect=AssertionError('NO_FINANCIAL_RUNTIME')) as runtime:
    with self.assertRaisesRegex(ValueError,'BEFORE_ADVANCE'):driver.case(args)
   advance.assert_not_called();runtime.assert_not_called()
   failure=json.loads((Path(args.case_output)/'CASE_FAILURE.json').read_bytes())
   self.assertIn('BEFORE_ADVANCE',failure['error'])

 def test_go_rejects_empty_duplicate_configs_wrong_year_review_and_resource_bypass(self):
  prepared,base,review=fixture()
  driver.validate_controller_go(prepared,raw(base),sha(raw(base)),review,sha(review))
  changes=[('permitted_configs',[]),('permitted_configs',None),('permitted_configs',['STATIC50_MID','STATIC50_MID']),
   ('calendar',[a.START,a.END+a.g.DAY]),('serial_execution',False),('controller_reporting_identity',{}),
   ('source_review_receipt_SHA256','0'*64),('resource_limits',{**driver.LIMITS,'per_case_wall_seconds':601}),
   ('independent_review_SHA256','0'*64),('mark_quality_guard_version','NONE')]
  for key,value in changes:
   body=raw({**base,key:value})
   with self.subTest(field=key),self.assertRaises(ValueError):driver.validate_controller_go(prepared,body,sha(body),review,sha(review))
  with self.assertRaises(ValueError):driver.validate_controller_go(prepared,raw(base),'0'*64,review,sha(review))
  with self.assertRaises(ValueError):driver.validate_controller_go(prepared,raw(base),sha(raw(base)),review,'0'*64)

 def test_source_review_is_immutable_and_combined_wrapper_chain_is_explicit(self):
  prepared,go,review=fixture();self.assertEqual(sha(SOURCE_REVIEW.read_bytes()),SOURCE_REVIEW_SHA)
  broken=raw({**json.loads(review),'source_review_receipt_SHA256':'f'*64});go={**go,'independent_review_SHA256':sha(broken)}
  body=raw(go)
  with self.assertRaises(ValueError):driver.validate_controller_go(prepared,body,sha(body),broken,sha(broken))
  self.assertEqual(sha(SOURCE_REVIEW.read_bytes()),SOURCE_REVIEW_SHA)

 def test_single_mid_pilot_launch_is_only_one_mocked_child_with_exact_review_and_limits(self):
  prepared,go,review=fixture()
  with TemporaryDirectory(prefix='generated-2024-controller-') as tmp:
   temp=Path(tmp);args=args_for(temp,go,review)
   def launch(command,**kwargs):
    config=command[command.index('--config')+1];output=Path(command[command.index('--case-output')+1]);output.mkdir()
    receipt=case_receipt(config,go,sha(review));body=raw(receipt);(output/'CASE_RECEIPT.json').write_bytes(body)
    (output/'TERMINAL_CHECKPOINT.json').write_bytes(raw(dict(config=config,case_receipt_SHA256=sha(body),paid_comparison_eligible=True,completed_minutes=527040,all_evidence_fsynced_before_checkpoint=True)))
    return SimpleNamespace(pid=901,wait=lambda timeout:0)
   with patch.object(driver.subprocess,'Popen',side_effect=launch) as popen:driver.controller(args)
   self.assertEqual(popen.call_count,1);command=popen.call_args.args[0]
   self.assertEqual(command[command.index('--config')+1],'STATIC50_MID')
   self.assertEqual(command[command.index('--review-sha')+1],sha(review));self.assertEqual(command[command.index('--go-sha')+1],sha(raw(go)))
   self.assertEqual(popen.call_args.kwargs['preexec_fn'],driver.limits)
   for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','POLARS_MAX_THREADS'):self.assertEqual(popen.call_args.kwargs['env'][key],'1')
   receipt=json.loads((temp/'output/CONTROLLER_RECEIPT.json').read_bytes());self.assertEqual(receipt['approved_job_count'],1)
   self.assertFalse(list((temp/'output').glob('BATCH_COMPUTED_*.json')))

 def test_timeout_kills_mocked_child_preserves_failure_and_never_launches_second(self):
  prepared,go,review=fixture(('STATIC50_MID','STATIC50_HIGH'))
  with TemporaryDirectory(prefix='generated-2024-timeout-') as tmp:
   temp=Path(tmp);args=args_for(temp,go,review);process=Mock(pid=902);process.wait.side_effect=[subprocess.TimeoutExpired('GENERATED_ONLY',600),-9]
   with patch.object(driver.subprocess,'Popen',return_value=process) as popen:
    with self.assertRaisesRegex(RuntimeError,'failed, retained, no retry'):driver.controller(args)
   self.assertEqual(popen.call_count,1);process.kill.assert_called_once();self.assertEqual(process.wait.call_args_list[0].kwargs,{'timeout':600})
   failure=json.loads((temp/'output/CONTROLLER_FAILURE.json').read_bytes());self.assertEqual(failure['cases'][0]['exit_code'],124)
   self.assertFalse((temp/'output/CONTROLLER_RECEIPT.json').exists())

 def test_prior_case_is_canonical_disjoint_and_exact_same_policy(self):
  prepared,go,review=fixture(('STATIC50_LOW','STATIC50_HIGH'))
  with TemporaryDirectory(prefix='generated-2024-prior-') as tmp:
   temp=Path(tmp);path=temp/'GENERATED_PRIOR_CASE.json';base=case_receipt('STATIC50_MID',go,sha(review));prior_go={**go,'permitted_configs':['STATIC50_MID']};prior_path=temp/'GENERATED_PRIOR_ROOT_GO.json';prior_path.write_bytes(raw(prior_go));base['root_GO_SHA256']=sha(raw(prior_go))
   def check_receipt(receipt):
    body=raw(receipt);path.write_bytes(body)
    scoped={**go,'prior_completed_cases':[dict(case_receipt_path=str(path),case_receipt_SHA256=sha(body),root_GO_SHA256=receipt['root_GO_SHA256'],root_GO_path=str(prior_path))]}
    return driver.prior_completed(scoped,prepared)
   self.assertIn('STATIC50_MID',check_receipt(base))
   changes=[('config','UNKNOWN_MID'),('config','STATIC50_LOW'),('status','FAILED'),('completed_minutes',525600),
    ('required_minutes',525600),('actual_complete_calendar_days',365),('account_stop_us',a.START),
    ('source_identity','0'*64),('code_identity',{}),('controller_reporting_identity',{}),
    ('independent_review_SHA256','0'*64),('original_interpolated_mark_execution_admitted',True),
    ('source_quality_adapter',{}),('limits',{})]
   for key,value in changes:
    with self.subTest(field=key),self.assertRaises(ValueError):check_receipt({**base,key:value})

 def test_atomic_exclusive_checkpoint_preserves_old_file_and_retains_failed_partial(self):
  with TemporaryDirectory(prefix='generated-2024-checkpoint-') as tmp:
   temp=Path(tmp);path=temp/'checkpoint.json';driver.write_bytes(path,b'FIRST')
   self.assertEqual(path.read_bytes(),b'FIRST');self.assertFalse(path.with_name(path.name+'.partial').exists())
   with self.assertRaises(FileExistsError):driver.write_bytes(path,b'SECOND')
   self.assertEqual(path.read_bytes(),b'FIRST')
   failed=temp/'failed.json'
   with patch.object(driver.os,'link',side_effect=RuntimeError('GENERATED_INSTALL_FAILURE')):
    with self.assertRaisesRegex(RuntimeError,'GENERATED_INSTALL_FAILURE'):driver.write_bytes(failed,b'PARTIAL_EVIDENCE')
   self.assertFalse(failed.exists());self.assertEqual(failed.with_name(failed.name+'.partial').read_bytes(),b'PARTIAL_EVIDENCE')

 def test_nonzero366day_report_keeps_preregistered365annualization(self):
  names=['nav','free_cash','isolated_balance','gross_weight','close_us']+[s+'_signed_weight' for s in a.g.SYMBOLS]
  returns=np.where(np.arange(366)%2, -.001,.001);daily=10000*np.cumprod(1+returns)
  data=np.zeros((527040,len(names)));data[:,0]=np.repeat(daily,1440);data[:,1]=data[:,0]
  data[:,4]=np.arange(a.START+a.n.MINUTE,a.END+a.n.MINUTE,a.n.MINUTE)
  before=hashlib.sha256(data.tobytes()).hexdigest()
  result=report.risk_diagnostics(data,names,np.arange(a.START,a.END,a.g.DAY,dtype=np.int64),np.zeros((366,5,5)),np.zeros((366,5)),'MID',[])
  self.assertEqual(result['complete_calendar_days'],366);self.assertEqual(result['observation_count'],527040)
  self.assertAlmostEqual(result['realized_daily_simple_return_annual_volatility'],float(returns.std(ddof=1)*np.sqrt(365)),places=14)
  self.assertEqual(hashlib.sha256(data.tobytes()).hexdigest(),before)

 def test_limits_and_completed_batches_have_exact_bounded_semantics(self):
  with patch.object(driver.resource,'setrlimit') as set_limit,patch.object(driver.os,'sched_getaffinity',return_value={3,7}),patch.object(driver.os,'sched_setaffinity') as affinity:
   driver.limits()
  self.assertEqual([call.args for call in set_limit.call_args_list],[(driver.resource.RLIMIT_AS,(4000000000,4000000000)),(driver.resource.RLIMIT_CPU,(600,600)),(driver.resource.RLIMIT_RSS,(2000000000,2000000000))])
  affinity.assert_called_once_with(0,{3})
  self.assertEqual(driver.completed_batches(['STATIC50_LOW','STATIC50_MID']),[])
  self.assertEqual(driver.completed_batches(['STATIC50_LOW','STATIC50_MID','STATIC50_HIGH']),['STATIC50'])

if __name__=='__main__':unittest.main(verbosity=2)
