"""Generated source projection and fake-state quality tests; no financial account."""
from pathlib import Path
from types import SimpleNamespace,MethodType
from decimal import Decimal as D,ROUND_FLOOR
from copy import deepcopy
import sys,unittest,numpy as np
ROOT=Path(__file__).resolve().parent.parent;BUILD=ROOT/'traditional_three_tier_freeze_20261015'
sys.path.insert(0,str(BUILD))
import missing_mark_adapter_2024 as m
import causal_mark_quality as q

S=m.SYMBOLS

def marks(at,available=None):
 return {s:[dict(price=D('100'),close_us=at,available_us=at if available is None else available)] for s in S}

def fixture():
 times=np.arange(m.LAST_GENUINE_OPEN-m.MINUTE,m.RESUME_AVAILABLE+3*m.MINUTE,m.MINUTE,dtype=np.int64)
 arrays={'times':times}
 for i,s in enumerate(S):
  arrays[s+'_mark']=np.arange(len(times),dtype=np.float64)+100+i
  arrays[s+'_mark'][2:4]=[99999,88888]
  for name in ('open','close','quote_volume'):arrays[s+'_'+name]=np.full(len(times),100.+i)
 return arrays

def guard(mark_at=None):
 account=SimpleNamespace(marks=marks(mark_at or m.LAST_GENUINE_AVAILABLE),fill_requests={},status='ACTIVE')
 sim=SimpleNamespace(account=account,symbols=S)
 partial=SimpleNamespace(sim=sim)
 interval=q.StaleMarkInterval(m.FIRST_MISSING_KNOWN,m.RESUME_AVAILABLE,m.LAST_GENUINE_AVAILABLE,S)
 quality=q.CausalMarkQualityGuard(partial,intervals=(interval,),source_sidecar_sha256='1'*64)
 return quality,account


class IndependentCausalQuality(unittest.TestCase):
 def test_future_endpoint_changes_cannot_change_any_pre_recovery_projection(self):
  arrays=fixture();before={k:v.tobytes() for k,v in arrays.items()};projected,sidecar=m.project_month(arrays)
  altered={k:v.copy() for k,v in arrays.items()}
  for s in S:altered[s+'_mark'][2:]*=333
  changed,changed_sidecar=m.project_month(altered)
  before_recovery=arrays['times']+m.MINUTE<m.RESUME_AVAILABLE
  for s in S:
   np.testing.assert_array_equal(projected[s+'_mark'][before_recovery],changed[s+'_mark'][before_recovery])
   self.assertEqual(projected[s+'_mark'][2],arrays[s+'_mark'][1]);self.assertEqual(projected[s+'_mark'][3],arrays[s+'_mark'][1])
   self.assertFalse(projected[s+'_mark'].flags.writeable)
   self.assertTrue(np.array_equal(projected[s+'_open'],arrays[s+'_open']))
  self.assertEqual(sidecar,changed_sidecar)
  self.assertEqual(len(sidecar),10)
  self.assertEqual({k:v.tobytes() for k,v in arrays.items()},before)
  self.assertTrue(all(x['last_genuine_source_available_us']==m.LAST_GENUINE_AVAILABLE and x['stale'] is True and x['derived'] is True and x['is_actual_current_venue_mark'] is False for x in sidecar))

 def test_projected_values_resume_only_at_the_following_genuine_close(self):
  arrays=fixture();projected,sidecar=m.project_month(arrays)
  self.assertEqual([x['stale_age_us'] for x in sidecar[:2]],[m.MINUTE,2*m.MINUTE])
  for s in S:self.assertEqual(projected[s+'_mark'][4],arrays[s+'_mark'][4])
  self.assertEqual(m.FIRST_MISSING_KNOWN,m.MISSING_OPENS[0]+m.MINUTE)
  self.assertEqual(m.RESUME_AVAILABLE,m.MISSING_OPENS[-1]+2*m.MINUTE)

 def test_no_preemptive_outage_use_and_no_prefetch_based_recovery(self):
  quality,account=guard()
  self.assertIsNone(quality.quality_witness(m.FIRST_MISSING_KNOWN-1))
  self.assertIsNotNone(quality.quality_witness(m.FIRST_MISSING_KNOWN))
  account.marks=marks(m.RESUME_AVAILABLE-m.MINUTE)
  quality.sim.prefetched_future_mark_rows=marks(m.RESUME_AVAILABLE+100*m.MINUTE)
  self.assertIsNotNone(quality.quality_witness(m.RESUME_AVAILABLE+1))
  self.assertIsNotNone(quality.quality_witness(m.RESUME_AVAILABLE+100*m.MINUTE))
  account.marks=marks(m.RESUME_AVAILABLE)
  self.assertIsNone(quality.quality_witness(m.RESUME_AVAILABLE+1))

 def test_future_publication_or_one_unrecovered_symbol_keeps_increases_blocked(self):
  quality,account=guard();event=m.RESUME_AVAILABLE+1
  account.marks=marks(m.RESUME_AVAILABLE)
  account.marks[S[-1]]=marks(m.RESUME_AVAILABLE-m.MINUTE)[S[-1]]
  self.assertIsNotNone(quality.quality_witness(event))
  account.marks=marks(m.RESUME_AVAILABLE,m.RESUME_AVAILABLE+m.MINUTE)
  self.assertIsNotNone(quality.quality_witness(event))
  account.marks=marks(m.RESUME_AVAILABLE+m.MINUTE)
  self.assertIsNotNone(quality.quality_witness(event))

 def _attempt(self,request,*,known=False,conflict=False):
  quality,account=guard();quality._installed=True;calls=[]
  account._floor=lambda symbol,value:(value/D('1')).to_integral_value(rounding=ROUND_FLOOR)
  if known:account.fill_requests={'ID':object()}
  def captured(_account,*args,**kwargs):
   calls.append((args,kwargs))
   if conflict:raise ValueError('NATIVE_ID_CONFLICT')
   return dict(status='NATIVE_DELEGATED',request=args)
  saved=MethodType(captured,account);account.execute_fill=saved
  def native(open_us,market):
   return account.execute_fill(S[0],'BUY',request['quantity'],open_us+1,open_us-m.MINUTE,'ID',
    available_quantity=request.get('available',D('100')),reduce_only=request.get('reduce_only',False))
  quality.original_attempt=native
  return quality,account,saved,calls,native

 def test_stale_new_increase_rejection_is_detached_and_restores_outer_interceptor(self):
  quality,account,saved,calls,_=self._attempt(dict(quantity=D('2')))
  before=dict(vars(account));receipt=quality.attempt(m.FIRST_MISSING_KNOWN,{})
  self.assertEqual(receipt['reason'],q.REJECTION);self.assertEqual(calls,[])
  self.assertEqual(vars(account),before);self.assertIs(account.execute_fill,saved)
  self.assertEqual(len(quality.receipts),1)

 def test_paid_reduction_and_zero_lot_delegate_unchanged_while_stale(self):
  for request in [dict(quantity=D('2'),reduce_only=True),dict(quantity=D('.2')),dict(quantity=D('2'),available=D('.2'))]:
   quality,account,saved,calls,_=self._attempt(request)
   result=quality.attempt(m.FIRST_MISSING_KNOWN,{})
   self.assertEqual(result['status'],'NATIVE_DELEGATED');self.assertEqual(len(calls),1)
   self.assertEqual(quality.receipts,[]);self.assertIs(account.execute_fill,saved)

 def test_known_fill_replay_and_conflict_delegate_before_quality(self):
  quality,account,saved,calls,_=self._attempt(dict(quantity=D('2')),known=True)
  result=quality.attempt(m.FIRST_MISSING_KNOWN,{})
  self.assertEqual(result['status'],'NATIVE_DELEGATED');self.assertEqual(len(calls),1);self.assertEqual(quality.receipts,[])
  quality,account,saved,calls,_=self._attempt(dict(quantity=D('2')),known=True,conflict=True)
  with self.assertRaisesRegex(ValueError,'NATIVE_ID_CONFLICT'):quality.attempt(m.FIRST_MISSING_KNOWN,{})
  self.assertIs(account.execute_fill,saved);self.assertEqual(quality.receipts,[])

 def test_existing_native_halt_identity_precedes_stale_quality(self):
  quality,account,saved,calls,_=self._attempt(dict(quantity=D('2')),conflict=True)
  account.status='LIQUIDATION_REQUIRED_HALT'
  with self.assertRaisesRegex(ValueError,'NATIVE_ID_CONFLICT'):quality.attempt(m.FIRST_MISSING_KNOWN,{})
  self.assertIs(account.execute_fill,saved);self.assertEqual(quality.receipts,[])

 def test_quality_interval_schema_and_overlap_fail_closed(self):
  with self.assertRaises(ValueError):q.StaleMarkInterval(2,1,0,S)
  quality,account=guard();interval=quality.intervals[0]
  with self.assertRaises(ValueError):q.CausalMarkQualityGuard(quality.guard,intervals=[interval],source_sidecar_sha256='1'*64)
  with self.assertRaises(ValueError):q.CausalMarkQualityGuard(quality.guard,intervals=(interval,interval),source_sidecar_sha256='1'*64)
  with self.assertRaises(ValueError):q.CausalMarkQualityGuard(quality.guard,intervals=(interval,),source_sidecar_sha256='NOT_A_HASH')

if __name__=='__main__':unittest.main(verbosity=2)
