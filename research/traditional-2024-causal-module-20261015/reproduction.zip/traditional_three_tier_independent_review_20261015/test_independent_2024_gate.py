"""Independent source-only leap-year admission tests; actual constructor mocked."""
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
from unittest.mock import patch
from copy import deepcopy
from io import BytesIO
import hashlib,json,shutil,sys,unittest,numpy as np
from numpy.testing import assert_array_equal
ROOT=Path(__file__).resolve().parent.parent;BUILD=ROOT/'traditional_three_tier_freeze_20261015'
sys.path.insert(0,str(BUILD))
import annual_entry_2024 as a
SOURCE=ROOT/'native_2024_source_restore_20261015'
raw=lambda v:json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
sha=lambda b:hashlib.sha256(b).hexdigest()

def metadata(preparation,configs=('STATIC50_MID',)):
 p=json.loads(preparation)
 review=dict(schema='INDEPENDENT_FINITE2024_CAUSAL_ADAPTER_REVIEW_V1',status='PASS_SOURCE_ONLY_AND_GENERATED_GATES_NO_ACCOUNT_GO',preparation_SHA256=sha(preparation),code_identity=p['code_identity'],source_identity=p['source_identity'],artifacts=p['artifacts'],execution_identity=p['execution_identity'],mark_feed_adapter_version=a.m.VERSION,mark_quality_guard_version=a.q.VERSION,original_interpolated_mark_execution_admitted=False,actual_2024_accounts_constructed=0,actual_2024_financial_runs=0)
 rb=raw(review)
 go=dict(schema='ROOT_GO_FIXED_FINITE_FULL2024_GRID_V1',action='RUN_FRESH_APPROVED_2024_CANONICAL_JOBS_ONLY',preparation_SHA256=sha(preparation),calendar=[a.START,a.END],cost='BASE27',code_identity=p['code_identity'],source_identity=p['source_identity'],artifacts=p['artifacts'],resource_limits=p['resource_limits'],permitted_configs=list(configs),locked_or_holdout_consumed=False,other_years_authorized=False,original_interpolated_mark_execution_admitted=False,coldstart_policy=p['coldstart_policy'],mark_feed_adapter_version=a.m.VERSION,mark_quality_guard_version=a.q.VERSION,independent_review_SHA256=sha(rb))
 return go,rb


class Independent2024Gate(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.temp=TemporaryDirectory(prefix='independent2024-source-only-',dir=Path(__file__).resolve().parent)
  cls.prepared=Path(cls.temp.name)/'prepared'
  with patch.object(a.n,'_construct_case',side_effect=AssertionError('NO_2024_ACCOUNT')),patch.object(a.n,'runtime',side_effect=AssertionError('NO_FINANCIAL_RUNTIME')):
   cls.prep=a.prepare_source_only(SOURCE,cls.prepared)
  cls.preparation=(cls.prepared/'PREPARATION.json').read_bytes()
 @classmethod
 def tearDownClass(cls):cls.temp.cleanup()
 def inputs(self,prepared=None,preparation=None,config='STATIC50_MID'):
  prepared=prepared or self.prepared;preparation=preparation or self.preparation;go,_=metadata(preparation,(config,));body=raw(go)
  with patch.object(a.n,'_construct_case',side_effect=AssertionError('NO_2024_ACCOUNT')),patch.object(a.n,'runtime',side_effect=AssertionError('NO_FINANCIAL_RUNTIME')):
   return a.validate_annual_inputs(SOURCE,prepared,body,sha(body),config=config)

 def test_independent_preparation_reproduces_exact_stable_builder_bytes(self):
  expected=BUILD/'annual_2024_source_preparation_attempt002/PREPARATION.json'
  self.assertEqual(self.preparation,expected.read_bytes())
  self.assertEqual(sha(self.preparation),'657317bb8c025d8ab926e66a57078bfcf2a8d684be6dcc40a0ac8e7502b29b46')

 def test_generated_missing_malformed_or_nonfinite_market_cells_fail_closed(self):
  arrays={'times':np.arange(a.START,a.START+3*a.n.MINUTE,a.n.MINUTE,dtype=np.int64)}
  for symbol in a.g.SYMBOLS:
   for field in ('open','close','quote_volume','mark'):arrays[symbol+'_'+field]=np.ones(3,dtype=np.float64)
  for key,kind in [('BTCUSDT_mark','nan'),('ETHUSDT_close','float32'),('SOLUSDT_open','negative'),('DOGEUSDT_quote_volume','shape'),('XRPUSDT_mark','missing')]:
   bad={key:value.copy() for key,value in arrays.items()}
   if kind=='nan':bad[key][0]=np.nan
   elif kind=='float32':bad[key]=bad[key].astype(np.float32)
   elif kind=='negative':bad[key][0]=-1
   elif kind=='shape':bad[key]=bad[key][:-1]
   else:bad.pop(key)
   buffer=BytesIO();np.savez_compressed(buffer,**bad)
   with self.subTest(field=key),self.assertRaises(ValueError):a._month_arrays(buffer.getvalue(),a.START,3)

 def test_source_only_targets_and_year_scope_preserve_full_leap_calendar(self):
  self.assertEqual(self.prep['accounts_created'],0);self.assertFalse(self.prep['annual_returns_computed'])
  self.assertEqual((self.prep['days'],self.prep['required_minutes']),(366,527040))
  self.assertEqual(self.prep['code_identity'],a.code_identity())
  self.assertEqual(self.prep['unique_execution_jobs'],9)
  self.assertFalse(self.prep['original_interpolated_mark_execution_admitted'])
  self.assertFalse(self.prep['coldstart_policy']['available_prior_source_used'])
  self.assertEqual(self.prep['original200_quality']['used_window_union_cells'],2825)
  _,window,rows,d,target,captured=self.inputs()
  np.testing.assert_array_equal(d,np.arange(a.START,a.END,a.g.DAY,dtype=np.int64))
  feb29=1709164800000000;self.assertIn(feb29,d)
  self.assertEqual(target.shape,(366,5));self.assertEqual(len(rows),2825)
  self.assertEqual(len(window['daily']),1830);self.assertEqual(len(window['events']),5490)
  self.assertNotIn('previous_quote',window);self.assertNotIn('initial_prior',window)

 def test_captured_all_year_blocks_remain_readable_with_every_late_path_open_forbidden(self):
  _,window,_,_,_,captured=self.inputs();count=0;expected=a.START;modified=0
  with patch.object(Path,'read_bytes',side_effect=AssertionError('LATE_PATH_READ')),patch.object(Path,'open',side_effect=AssertionError('LATE_PATH_OPEN')):
   for block in window['minute_blocks']():
    np.testing.assert_array_equal(block['times'],np.arange(expected,expected+a.g.DAY,a.n.MINUTE,dtype=np.int64));count+=1
    for s,fields in block['market'].items():
     self.assertEqual(set(fields),{'open','close','quote_volume','mark'})
     for value in fields.values():self.assertFalse(value.flags.writeable)
    if int(block['times'][0])<=a.m.MISSING_OPENS[0]<int(block['times'][-1]):
     with np.load(BytesIO(captured['prepared_2024/months/2024-08.npz']),allow_pickle=False) as z:
      for s in a.g.SYMBOLS:
       prior=z[s+'_mark'][np.searchsorted(z['times'],a.m.LAST_GENUINE_OPEN)]
       for at in a.m.MISSING_OPENS:
        i=np.searchsorted(block['times'],at);self.assertEqual(block['market'][s]['mark'][i],prior);modified+=1
    expected+=a.g.DAY
  self.assertEqual((count,expected,modified),(366,a.END,10))

 def test_positive_constructor_returns_fake_and_installs_real_inner_quality_layer(self):
  class FakeAccount:
   def execute_fill(self,*args,**kwargs):raise AssertionError('NO_FINANCIAL_FILL')
  class FakeSim:
   def __init__(self):self.account=FakeAccount();self.symbols=a.g.SYMBOLS;self.meta={}
   def inner(self,*args):raise AssertionError('NO_NATIVE_ATTEMPT')
  sim=FakeSim();partial=object.__new__(a.n.PartialTierGuard);partial.sim=sim;partial._installed=True;partial.original_attempt=sim.inner;sim.attempt=partial.attempt
  go,review=metadata(self.preparation);body=raw(go)
  with patch.object(a.n,'_construct_case',return_value=(sim,partial)) as construct,patch.object(a.n,'runtime',side_effect=AssertionError('NO_FINANCIAL_RUNTIME')):
   result=a.make_annual_case(SOURCE,self.prepared,body,sha(body),config='STATIC50_MID',review_raw=review,expected_review_sha256=sha(review))
  self.assertEqual(result,(sim,partial));self.assertEqual(construct.call_count,1)
  layer=partial.original_attempt.__self__;self.assertIsInstance(layer,a.q.CausalMarkQualityGuard)
  self.assertIs(partial.causal_mark_quality_guard,layer)
  self.assertEqual(layer.source_sidecar_sha256,self.prep['artifacts']['CAUSAL_MARK_ADAPTER.json']['SHA256'])
  self.assertEqual(sim.meta['mark_quality_policy_identity'],layer.policy_sha256)
  self.assertFalse(sim.meta['original_interpolated_mark_execution_admitted']);self.assertFalse(sim.meta['initial_prior_source_used'])
  self.assertNotIn('execute_fill',vars(sim.account));self.assertEqual(construct.call_args.args[3].shape,(366,5))

 def test_empty_jobs_unapproved_config_extra_year_and_interpolation_reentry_fail(self):
  base,_=metadata(self.preparation)
  changes=[('permitted_configs',[]),('permitted_configs',['STATIC50_LOW']),('permitted_configs',['STATIC50_MID','STATIC50_MID']),('calendar',[a.START,a.END+a.g.DAY]),('original_interpolated_mark_execution_admitted',True),('coldstart_policy',{**base['coldstart_policy'],'available_prior_source_used':True}),('mark_feed_adapter_version','ORIGINAL'),('mark_quality_guard_version','NONE'),('resource_limits',{**a.RESOURCE_LIMITS,'per_case_wall_seconds':601}),('other_years_authorized',True),('locked_or_holdout_consumed',True)]
  for key,value in changes:
   with self.subTest(field=key,value=value):
    body=raw({**base,key:value})
    with self.assertRaises(ValueError):a.validate_root_go(self.preparation,body,sha(body),config='STATIC50_MID')

 def test_missing_or_forged_independent_review_never_reaches_account(self):
  go,review=metadata(self.preparation);body=raw(go)
  with patch.object(a.n,'_construct_case',side_effect=AssertionError('NO_2024_ACCOUNT')) as constructor,patch.object(a,'_source',side_effect=AssertionError('NO_SOURCE_BEFORE_REVIEW')):
   for reviewed,digest in [(None,None),(review,'0'*64),(raw({**json.loads(review),'actual_2024_accounts_constructed':1}),sha(raw({**json.loads(review),'actual_2024_accounts_constructed':1})))]:
    with self.assertRaises(ValueError):a.make_annual_case(SOURCE,self.prepared,body,sha(body),config='STATIC50_MID',review_raw=reviewed,expected_review_sha256=digest)
   constructor.assert_not_called()

 def test_every_prepared_artifact_tamper_fails_before_source(self):
  for index,name in enumerate(a.ARTIFACTS):
   copied=Path(self.temp.name)/('tamper%d'%index);shutil.copytree(self.prepared,copied)
   with (copied/name).open('ab') as out:out.write(b'GENERATED_TAMPER')
   with self.subTest(artifact=name),patch.object(a,'_source',side_effect=AssertionError('NO_SOURCE_AFTER_BAD_ARTIFACT')):
    with self.assertRaisesRegex(ValueError,'HASH_OR_SIZE'):self.inputs(copied)

 def test_false_cross_tier_dedup_and_false_estimate_sidecar_rejected(self):
  for label in ('dedup','sidecar'):
   copied=Path(self.temp.name)/label;shutil.copytree(self.prepared,copied);prep=deepcopy(self.prep)
   if label=='dedup':prep['execution_groups'][0].append('STATIC50_MID');prep['execution_groups'].pop(1)
   else:
    path=copied/'CAUSAL_MARK_ADAPTER.json';artifact=json.loads(path.read_bytes());artifact['sidecar'][0]['last_genuine_source_available_us']+=a.n.MINUTE;changed=raw(artifact);path.write_bytes(changed);prep['artifacts']['CAUSAL_MARK_ADAPTER.json']={'SHA256':sha(changed),'bytes':len(changed)}
   prepared=raw(prep);(copied/'PREPARATION.json').write_bytes(prepared)
   with self.subTest(label=label),self.assertRaisesRegex(ValueError,'DEDUP_OR_SOURCE_QUALIFICATION'):self.inputs(copied,prepared,config='STATIC50_LOW')

 def test_unused_next_year_close_cannot_affect_any_2024_target_or_covariance(self):
  _,_,t,p,_,_,_=a._source(SOURCE);p=p.copy();p[t>=a.END]*=17
  with np.load(self.prepared/'TARGETS.npz',allow_pickle=False) as z:
   decisions=z['decision_us'].copy();cov=z['annual_covariance'].copy();expected={key:z[key].copy() for key in self.prep['configs']}
  _,actual,newcov,_=a.g.build_target_grid(p,t,t.copy(),decisions)
  self.assertEqual(newcov.tobytes(),cov.tobytes())
  for key in expected:self.assertEqual(actual[key].tobytes(),expected[key].tobytes())

if __name__=='__main__':unittest.main(verbosity=2)
