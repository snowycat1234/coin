"""Apply unchanged expert recipes to additional source history; no fitting."""
from pathlib import Path
import json,hashlib,importlib.util
import numpy as np,polars as pl
from modules.temporal_july_transfer.data import recipe,RISK_SOURCES,SHORT_SOURCE_SHA
from modules.temporal_two_expert.inputs import CORE5,DAY_US
R=Path(__file__).resolve().parent;O=R/'features2025';repo=Path.cwd()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for p,h in RISK_SOURCES.items():assert sha(repo/p)==h,p
shortpath=repo/'modules/temporal_april_transfer/upstream/momentum_short_pool_target.py';assert sha(shortpath)==SHORT_SOURCE_SHA
spec=importlib.util.spec_from_file_location('_unchanged2025short',shortpath);short=importlib.util.module_from_spec(spec);spec.loader.exec_module(short)
z=np.load(O/'FEATURES.npz');t=z['completed_day_available_us'];close=z['close'];dec=np.load(R/'economics2025/ECONOMICS.npz')['decision_us'];r=recipe();bars=r.bar_frame(O,CORE5).filter(pl.col('available_us')<=int(dec[-1]))
a=[r.existing_targets(dict(recipe=n,mechanism=n),bars,dec,close,t,CORE5) for n in ('CASH','VOL_MANAGED_HOLD','CSMOM21')]
sf,sm=short.fixed_targets(bars,dec,symbols=CORE5);st=sf['target_weight'].to_numpy().reshape(len(dec),1,5);se=(sf['eligibility_reason'].to_numpy().reshape(len(dec),1,5)=='ELIGIBLE').any(2)
target=np.concatenate([np.stack([v[0] for v in a],axis=1),st],axis=1);eligible=np.concatenate([np.stack([v[2] for v in a],axis=1),se],axis=1)
ix=np.searchsorted(t,dec);np.testing.assert_array_equal(t[ix],dec);past=np.stack([np.diff(close[i-30:i+1],axis=0)/close[i-30:i] for i in ix]);assert np.isfinite(past).all();assert target.shape==(365,4,5);assert np.isfinite(target).all();assert (abs(target).sum(2)<=.60000001).all();assert (abs(target)<=.30000001).all()
# Output prefix invariance: later observations cannot alter earlier expert allocations.
cut=180;prefixbars=bars.filter(pl.col('available_us')<=int(dec[cut-1]));pt=t[t<=dec[cut-1]];pc=close[:len(pt)]
for j,n in enumerate(('CASH','VOL_MANAGED_HOLD','CSMOM21')):
 b=r.existing_targets(dict(recipe=n,mechanism=n),prefixbars,dec[:cut],pc,pt,CORE5);np.testing.assert_array_equal(b[0],target[:cut,j]);np.testing.assert_array_equal(b[2],eligible[:cut,j])
b,_=short.fixed_targets(prefixbars,dec[:cut],symbols=CORE5);np.testing.assert_array_equal(b['target_weight'].to_numpy().reshape(cut,5),target[:cut,3])
np.savez_compressed(O/'EXPERTS.npz',decision_us=dec,expert_targets=target,expert_eligible=eligible,past_returns30=past,symbol_order=CORE5,expert_order=['CASH','VOL_MANAGED_HOLD','CSMOM21','MOMENTUM30_SHORT'])
report={'status':'UNCHANGED_EXPERT_RECIPES_AND_PREFIX_INVARIANCE_PASSED_NO_MODEL_FIT','decision_count':365,'active_intervals':364,'expert_order':['CASH','VOL_MANAGED_HOLD','CSMOM21','MOMENTUM30_SHORT'],'eligible_decisions':eligible.sum(0).tolist(),'prefix_decisions_checked':cut,'risk_sources':RISK_SOURCES,'short_source_SHA256':SHORT_SOURCE_SHA,'artifact_SHA256':sha(O/'EXPERTS.npz'),'terminal_close_required':True,'data_role':'additional development history; no untouched-OOS claim'}
(O/'EXPERT_REPORT.json').write_text(json.dumps(report,indent=2)+'\n');print(report)
