"""Fixed full2025 CORE5 official minute archives, serial and resumable."""
import argparse,json,hashlib,zipfile,shutil
from pathlib import Path
import requests
R=Path(__file__).parent;BASE='https://data.binance.vision/';SYMS=['BTCUSDT','ETHUSDT','SOLUSDT','XRPUSDT','DOGEUSDT'];BUDGET=400*2**20
p=argparse.ArgumentParser();p.add_argument('action',choices=['inventory','download']);a=p.parse_args();s=requests.Session();meta=R/'minute-metadata';meta.mkdir(exist_ok=True)
if a.action=='inventory':
 rows=[]
 for sym in SYMS:
  for family in ['klines','markPriceKlines']:
   for m in range(1,13):
    name=f'{sym}-1m-2025-{m:02d}.zip';key=f'data/futures/um/monthly/{family}/{sym}/1m/{name}';path=meta/f'{sym}_{family}_{m:02d}.json'
    if path.exists():row=json.loads(path.read_text())
    else:
     u=BASE+key;c=s.get(u+'.CHECKSUM',timeout=30);c.raise_for_status();assert c.url.startswith(BASE) and len(c.content)<1000;parts=c.text.split();assert len(parts)==2 and parts[1]==name
     h=s.head(u,timeout=30);h.raise_for_status();assert h.url.startswith(BASE);length=int(h.headers['Content-Length']);assert 0<length<10*2**20
     row={'symbol':sym,'family':family,'month':f'2025-{m:02d}','key':key,'url':u,'SHA256':parts[0],'bytes':length,'checksum_text':c.text,'last_modified':h.headers.get('Last-Modified')};path.write_text(json.dumps(row,indent=2)+'\n')
    rows.append(row)
   print(sym,family,len(rows),flush=True)
 assert len(rows)==120;total=sum(x['bytes'] for x in rows);assert total<=BUDGET
 (R/'MINUTE_PLAN.json').write_text(json.dumps({'status':'WITHIN_BUDGET','archive_count':len(rows),'expected_bytes':total,'body_cap':BUDGET,'period':'fullcalendar2025 independent of outcomes','records':rows,'reuse':'No2025minute archives in the inspected working research cache; preserve any matching completed download. Existing2020–2024 not redownloaded.','access':'Official data host direct objects; no S3 LIST or trading API calls.'},indent=2)+'\n');print('PLAN',total,flush=True)
else:
 inv=json.loads((R/'MINUTE_PLAN.json').read_text());assert inv['status']=='WITHIN_BUDGET' and inv['expected_bytes']<=BUDGET;raw=R/'minute-archives';raw.mkdir(exist_ok=True);receipts=R/'minute-receipts';receipts.mkdir(exist_ok=True);records=[]
 for i,x in enumerate(inv['records']):
  name=x['symbol']+'_'+x['family']+'_'+x['month']+'.zip';dest=raw/name;proof=receipts/(name+'.json');reused=dest.exists();assert shutil.disk_usage(R).free>2*2**30
  if not reused:
   temp=dest.with_suffix('.partial');assert not temp.exists(),'Retain and inspect prior partial before retry'
   with s.get(x['url'],stream=True,timeout=45) as response:
    response.raise_for_status();assert response.url.startswith(BASE);assert int(response.headers['Content-Length'])==x['bytes'];n=0
    with temp.open('xb') as f:
     for b in response.iter_content(1<<20):
      n+=len(b);assert n<=x['bytes'];f.write(b)
   assert n==x['bytes'];assert hashlib.sha256(temp.read_bytes()).hexdigest()==x['SHA256'];temp.rename(dest)
  assert dest.stat().st_size==x['bytes'] and hashlib.sha256(dest.read_bytes()).hexdigest()==x['SHA256'];z=zipfile.ZipFile(dest);assert len(z.namelist())==1 and z.testzip() is None;assert z.getinfo(z.namelist()[0]).file_size<25*2**20
  row=dict(x,local_name=name,CRC_verified=True);proof.write_text(json.dumps(row,indent=2)+'\n');records.append(row)
  (R/'MINUTE_PROGRESS.json').write_text(json.dumps({'verified':len(records),'expected':120,'bytes':sum(v['bytes'] for v in records)},indent=2)+'\n');print('verified',i+1,name,flush=True)
 (R/'MINUTE_ACQUIRED.json').write_text(json.dumps({'complete':True,'records':records,'bytes':sum(v['bytes'] for v in records),'not_yet_economic_training_ready':True},indent=2)+'\n')
