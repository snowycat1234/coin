"""Independent generated-only source gate review. Never admits a source scope."""
from contextlib import contextmanager, ExitStack
from copy import deepcopy
from io import BytesIO, StringIO
import json
import os
from pathlib import Path
import sys
from types import SimpleNamespace
import unittest
from unittest.mock import patch

HERE = Path(__file__).absolute().parent
AUTHOR = HERE.parent / 'legacy_intrinsic_D_20261015_v1'
sys.path.insert(0, str(AUTHOR))
import prepare_legacy_source as cli
import numpy as np
import legacy_common as c
import legacy_config as cfg
import legacy_entry as entry
import legacy_generated as gen
import legacy_loader as loader
import legacy_signal as signal
import legacy_source as source
from legacy_source_guard import SourceOnlyGuard, SourceBoundaryViolation

CLI_OBSERVATIONS = []


class VirtualOutput:
    def __init__(self, root):
        self.root = root
        self.files = {}
        self.directories = set()
        self.original_open = __import__('io').open
        self.original_exists = Path.exists
        self.original_read = Path.read_bytes
        self.original_rglob = Path.rglob
        self.original_mkdir = os.mkdir

    def inside(self, path):
        if isinstance(path, int):
            return False
        path = Path(path).absolute()
        return path == self.root or self.root in path.parents

    def open(self, path, mode='r', *args, **kwargs):
        if self.inside(path):
            path = Path(path).absolute()
            if 'x' in mode and path in self.files:
                raise FileExistsError(str(path))
            if not any(ch in mode for ch in 'wax+'):
                raw = self.files[path]
                return BytesIO(raw) if 'b' in mode else StringIO(raw.decode())
            owner = self
            kind = BytesIO if 'b' in mode else StringIO
            class SavedBuffer(kind):
                def close(self):
                    if not self.closed:
                        raw = self.getvalue()
                        owner.files[path] = raw.encode() if isinstance(raw, str) else raw
                    super().close()
            return SavedBuffer()
        return self.original_open(path, mode, *args, **kwargs)

    def mkdir(self, path, *args, **kwargs):
        path = Path(path).absolute()
        if self.inside(path) or path == self.root.parent:
            self.directories.add(path)
            return None
        return self.original_mkdir(path, *args, **kwargs)

    def exists(self, path):
        if self.inside(path):
            return path in self.files or path in self.directories
        return self.original_exists(path)

    def rglob(self, path, pattern):
        if path == self.root:
            return [SimpleNamespace(is_file=lambda: True, stat=lambda n=len(raw): SimpleNamespace(st_size=n))
                    for raw in self.files.values()]
        return self.original_rglob(path, pattern)


class IndependentSourceReview(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.prep, cls.artifacts, cls.arrays = gen.fixture()
        cls.go, cls.go_sha, cls.review, cls.review_sha = gen.authority()

    def test_exact_fixed30_plan_and_only_first6_enabled(self):
        plan = c.exact_object(c.ordinary(c.ROOT / 'overnight_legacy_variant_queue_plan_20261015/NEXT_TRANCHE30.json'))
        actual = cfg.cells()
        self.assertEqual([r['cell_id'] for r in actual], [r['proposed_cell_id'] for r in plan['rows']])
        self.assertEqual(len(actual), 30)
        self.assertEqual(set(entry.tranche_cells(entry.FIRST6)), {r['cell_id'] for r in actual if r['year'] == 2023})
        self.assertFalse(entry.manifest()['financial_entry_implemented'])
        for cell in actual:
            self.assertTrue(cell['downward_only'])
            self.assertFalse(cell['original_execution_unchanged'])
            self.assertFalse(cell['financial_reuse_allowed'])

    def test_exact_default_prefix_and_original_intrinsic_bytes(self):
        a = gen.daily()
        clocks, close = a['close_available_us'][:-1], a['close'][:-1]
        pure = signal.reviewed_signal()
        direct = pure.build_generated_projection(close, clocks, clocks, self.arrays['decision_us'])
        wrapped, _ = signal.build_target_grid(close, clocks, clocks, self.arrays['decision_us'])
        self.assertEqual(direct.decisions.tobytes(), wrapped['decision_us'].tobytes())
        self.assertEqual(direct.covariance.tobytes(), wrapped['annual_covariance'].tobytes())
        for key, value in direct.downward_tiers.items():
            self.assertEqual(value.tobytes(), wrapped[key].tobytes())
        for recipe, value in direct.intrinsic_original.items():
            self.assertEqual(value.tobytes(), wrapped['intrinsic_' + recipe].tobytes())
        self.assertEqual(pure._legacy_math().HERE, c.ROOT / 'legacy_intrinsic_D_signal_20261015/pinned')
        self.assertEqual(pure.verify_code_pins()['schema'], 'LEGACY_INTRINSIC_PURE_SIGNAL_CODE_PINMAP_V1')

    def test_plain_identity_exact_descriptor_raw_byte_semantics(self):
        a = np.arange(8, dtype='float64').reshape(2, 4)
        for value in (a, a.T, np.asfortranarray(a), a.astype('>f8'), a.astype('int64'), a.reshape(4, 2)):
            got = signal.array_byte_identity(value)
            descriptor = dict(dtype=value.dtype.str, shape=list(value.shape), order='C')
            self.assertEqual(got['raw_bytes_SHA256'], c.sha(value.tobytes(order='C')))
            self.assertEqual(got['descriptor_and_bytes_SHA256'], c.sha(c.canonical(descriptor) + b'\0' + value.tobytes(order='C')))
        self.assertEqual(signal.array_byte_identity(a), signal.array_byte_identity(np.asfortranarray(a)))
        for dtype in ('V16', object, [('a','f8'),('b','i8')], 'u8', 'f4', 'c16'):
            with self.assertRaises(ValueError):
                signal.array_byte_identity(np.zeros(2, dtype=dtype))

    def test_exact_source_contract_metadata_unchanged_from_pinned_cs(self):
        original=c.exact_object(c.ordinary(c.ROOT/'original_cs_mom21_D_20261015_v4/SOURCE_CONTRACT_MAP.json'))
        self.assertEqual(c.canonical(entry.contracts()['years']['2023']),c.canonical(original['years']['2023']))

    def test_generated_prefix_future_suffix_cannot_change_prior_targets(self):
        a=gen.daily(); clocks=a['close_available_us'][:-1]; close=a['close'][:-1]
        decisions=self.arrays['decision_us'][:40]
        last=int(np.searchsorted(clocks,decisions[-1]))+1
        prefix,_=signal.build_target_grid(close[:last],clocks[:last],clocks[:last],decisions)
        future=close.copy(); future[last:]*=np.linspace(1.,8.,len(future)-last)[:,None]
        suffix,_=signal.build_target_grid(future,clocks,clocks,decisions)
        for key,value in prefix.items():
            self.assertEqual(value.tobytes(),suffix[key].tobytes())
            self.assertEqual(value.tobytes(),self.arrays[key][:40].tobytes())

    def test_root_review_and_go_extra_authority_exact_rejection(self):
        for which in ('go', 'review'):
            for key, value in (('extra', True), ('financial_GO_authorized', True), ('source_native_financial_approval', True)):
                go, review = c.exact_object(self.go), c.exact_object(self.review)
                target = go if which == 'go' else review
                target[key] = value
                go, review = c.canonical(go), c.canonical(review)
                with self.assertRaises(ValueError):
                    entry.validate_source_authority_metadata(go, c.sha(go), review, c.sha(review))
        with self.assertRaises(ValueError):
            c.exact_object(b'{"a":1,"a":2}')

    def test_preparation_extra_authority_namespace_closed(self):
        for path in ((), ('years','2023'), ('cells',entry.tranche_cells(entry.FIRST6)[0])):
            value = deepcopy(self.prep)
            target = value
            for part in path:
                target = target[part]
            target['financial_execution_authorized'] = True
            with self.assertRaises(ValueError):
                entry.validate_preparation_metadata(c.canonical(value))

    def test_source_artifact_schema_path_and_digest_negatives(self):
        for name in ('2023/EXTRA_AUTHORITY.json', '../escape', '/outside'):
            value = deepcopy(self.prep)
            value['artifacts'][name] = dict(SHA256='a'*64, bytes=1)
            with self.assertRaises(ValueError):
                entry.validate_preparation_metadata(c.canonical(value))
        value = deepcopy(self.prep)
        value['years']['2023']['source_quality_sidecar_SHA256'] = 'b'*64
        with self.assertRaises(ValueError):
            entry.validate_preparation_metadata(c.canonical(value))
        changed = dict(self.artifacts)
        changed['2023/SOURCE_INPUTS.npz'] += b'X'
        with self.assertRaises(ValueError):
            loader.decode_saved(c.canonical(self.prep), changed)

    def test_recording_callback_failure_revokes_each_scope(self):
        seen = []
        def callback(scope):
            seen.append(scope)
            scope.validate_current()
            if len(seen) == 3:
                raise RuntimeError('GENERATED_CALLBACK_STOP')
        with self.assertRaisesRegex(RuntimeError, 'GENERATED_CALLBACK_STOP'):
            entry.record_metadata_bindings(self.prep, callback)
        self.assertFalse(entry._ACTIVE_RECORDING)
        for scope in seen:
            with self.assertRaises(ValueError):
                scope.validate_current()
        self.assertFalse(entry._ACTIVE_SOURCE)

    def test_generated_real_scope_normal_and_exception_lifecycle_no_source_reads(self):
        retained = []
        for fails in (False, True):
            guard = SourceOnlyGuard(read_paths=gen.read_paths())
            def run():
                with guard:
                    with entry.admit_source_stage(self.go,self.go_sha,self.review,self.review_sha) as scope:
                        retained.append(scope)
                        self.assertTrue(scope.validate_current(year=2023))
                        with self.assertRaises(ValueError):
                            scope.validate_current(year=2024)
                        with self.assertRaises(ValueError):
                            scope.read_source(2023,'GENERATED_NOT_A_SOURCE_PATH','a'*64)
                        if fails:
                            raise RuntimeError('GENERATED_SCOPE_EXCEPTION')
                    guard.checkpoint('GENERATED_ONLY_EPHEMERAL_SCOPE_REVOKED')
            if fails:
                with self.assertRaisesRegex(RuntimeError,'GENERATED_SCOPE_EXCEPTION'):
                    run()
            else:
                run()
            self.assertFalse(any(guard.attempts.values()))
            self.assertFalse(entry._ACTIVE_SOURCE)
            with self.assertRaises(ValueError):
                retained[-1].validate_current()
        self.assertFalse(loader._LIVE)

    def cli_run(self, fail=False):
        output = c.HERE / 'source_attempts/GENERATED_INDEPENDENT_VIRTUAL_ONLY'
        virtual = VirtualOutput(output)
        go_path, review_path = c.HERE/'GENERATED_GO_MEMORY_ONLY', c.HERE/'GENERATED_REVIEW_MEMORY_ONLY'
        a = gen.daily()
        clocks, close = a['close_available_us'][:-1], a['close'][:-1]
        contract = entry.contracts()['years']['2023']
        fake = dict(year=2023, period=cfg.source_year(2023), clocks=clocks, close=close,
                    decisions=self.arrays['decision_us'], source_rows=c.object_json(self.artifacts['2023/SOURCE_ROWS.json']),
                    events=[], sidecar_raw=self.artifacts['2023/MINUTE_MARK_PROVENANCE.json'],
                    source_identity=contract['source_identity'], contract=contract)
        captures, sentinel_calls = [], []
        @contextmanager
        def sentinel_admit(*args):
            entry.validate_source_authority_metadata(*args)
            sentinel_calls.append(True)
            yield object()
        def capture(year, sentinel):
            self.assertEqual(year, 2023)
            self.assertFalse(entry._ACTIVE_SOURCE)
            captures.append(year)
            if fail:
                raise RuntimeError('GENERATED_CAPTURE_STOP')
            return fake
        def read_bytes(path):
            if path == go_path:
                return self.go
            if path == review_path:
                return self.review
            return virtual.original_read(path)
        original_exact = c.exact
        def exact_metadata_bytes(path, expected_sha, expected_bytes=None):
            if Path(path) in (go_path, review_path):
                raw = self.go if Path(path) == go_path else self.review
                self.assertEqual(c.sha(raw), expected_sha)
                return raw
            return original_exact(path, expected_sha, expected_bytes)
        argv = ['prepare_legacy_source.py', '--cpu','0','--output',str(output),
                '--source-go',str(go_path),'--source-go-sha',self.go_sha,
                '--source-review',str(review_path),'--source-review-sha',self.review_sha]
        actual_affinity = sorted(os.sched_getaffinity(0))
        out = StringIO()
        with ExitStack() as stack:
            for obj, name, value in ((__import__('io'),'open',virtual.open), (os,'mkdir',virtual.mkdir),
                    (Path,'exists',lambda p:virtual.exists(p)), (Path,'rglob',lambda p,pat:virtual.rglob(p,pat)),
                    (Path,'read_bytes',read_bytes), (c,'exact',exact_metadata_bytes), (entry,'admit_source_stage',sentinel_admit),
                    (source,'capture_year',capture), (sys,'argv',argv),
                    (os,'sched_setaffinity',lambda *args:None), (os,'sched_getaffinity',lambda *args:{0}),
                    (cli.resource,'setrlimit',lambda *args:None), (cli.signal,'signal',lambda *args:None),
                    (cli.signal,'alarm',lambda *args:None), (sys,'stdout',out)):
                stack.enter_context(patch.object(obj,name,value))
            if fail:
                with self.assertRaisesRegex(RuntimeError, 'GENERATED_CAPTURE_STOP'):
                    cli.main()
            else:
                cli.main()
        self.assertEqual(actual_affinity, [3])
        self.assertEqual(captures,[2023])
        self.assertEqual(sentinel_calls,[True])
        self.assertFalse(entry._ACTIVE_SOURCE)
        self.assertFalse(entry._ACTIVE_RECORDING)
        receipt_name = 'STOP_SOURCE_TARGET_PREPARATION.json' if fail else 'OBSERVED_SOURCE_TARGET_GUARD_RECEIPT.json'
        receipt = c.exact_object(virtual.files[output/receipt_name])
        self.assertFalse(any(receipt['forbidden_attempts'].values()),receipt)
        self.assertTrue(receipt['source_scopes_revoked'])
        self.assertTrue(receipt['recording_scopes_revoked'])
        CLI_OBSERVATIONS.append(dict(mode='STOP' if fail else 'POSITIVE', status=receipt['status'],
            actual_CPU_affinity=actual_affinity, resource_hooks_mocked=True, source_admission_sentinel=True,
            registered_source_scopes=0, actual_source_body_reads=0, stored_output_files=0,
            virtual_files=len(virtual.files), forbidden_attempts=receipt['forbidden_attempts']))
        if not fail:
            prep = entry.validate_preparation_metadata(virtual.files[output/'PREPARATION.json'])
            artifacts = {name:virtual.files[output/name] for name in prep['artifacts']}
            arrays, inputs = loader.decode_saved(virtual.files[output/'PREPARATION.json'], artifacts)
            for key,value in arrays.items():
                self.assertEqual(value.tobytes(), self.arrays[key].tobytes())
            self.assertEqual(inputs['close'].tobytes(),close.tobytes())
        return receipt

    def test_positive_cli_guard_complete_generated_source_free_storage(self):
        self.cli_run()

    def test_cli_stop_persists_original_generated_failure_without_scopes(self):
        receipt = self.cli_run(fail=True)
        self.assertIn('GENERATED_CAPTURE_STOP',receipt['error'])

    def test_public_saved_loader_generated_virtual_storage_lifecycle(self):
        root=c.HERE/'GENERATED_NO_FILES_SAVED_LOADER'
        raw=c.canonical(self.prep)
        memory={root/'PREPARATION.json':raw}
        memory.update({root/name:value for name,value in self.artifacts.items()})
        original=c.exact
        def memory_exact(path,digest,expected_bytes=None):
            path=Path(path).absolute()
            if path in memory:
                value=memory[path]
                if c.sha(value)!=digest or expected_bytes is not None and len(value)!=expected_bytes:
                    raise ValueError('GENERATED_EXACT_ARTIFACT_BYTES_REQUIRED')
                return value
            return original(path,digest,expected_bytes)
        guard=SourceOnlyGuard(read_paths=gen.read_paths())
        with guard,patch.object(c,'exact',memory_exact):
            loaded=loader.load_year(root,expected_preparation_sha256=c.sha(raw),year=2023,
                source_go_raw=self.go,expected_source_go_sha256=self.go_sha,
                source_review_raw=self.review,expected_source_review_sha256=self.review_sha)
            self.assertTrue(loaded.validate())
            self.assertEqual(loaded.year,2023)
            self.assertFalse(entry._ACTIVE_SOURCE)
            loader.revoke(loaded)
            with self.assertRaises(ValueError):
                loaded.validate()
            with self.assertRaises(ValueError):
                loader.load_year(root,expected_preparation_sha256=c.sha(raw),year=2024,
                    source_go_raw=self.go,expected_source_go_sha256=self.go_sha,
                    source_review_raw=self.review,expected_source_review_sha256=self.review_sha)
            guard.checkpoint('GENERATED_PUBLIC_SAVED_LOADER_REVOKED')
        self.assertFalse(loader._LIVE)
        self.assertFalse(any(guard.attempts.values()))


if __name__ == '__main__':
    unittest.main(verbosity=2)
