"""Exact qualified 2023 legacy sidecar seam; no CS quality authority."""
import legacy_bootstrap
import legacy_native_common as c

def validate_2023(sidecar,source_identity,calendar):
    if (sidecar.get('schema')!='LEGACY_INTRINSIC_REUSED_QUALIFIED_2023_SOURCE_QUALITY_V1'
            or sidecar.get('year')!=2023 or c.plain(sidecar.get('calendar'))!=list(calendar)
            or sidecar.get('qualified_source_identity')!=source_identity
            or sidecar.get('arrival_status')!='UNKNOWN_NOT_CERTIFIED'
            or sidecar.get('original_source_age_and_arrival_flags_preserved') is not True
            or c.plain(sidecar.get('cells'))!=[] or c.plain(sidecar.get('quality_intervals'))!=[]
            or type(sidecar.get('derived_mark_cells')) is not int or sidecar['derived_mark_cells']!=0
            or sidecar.get('actual_legacy_event_and_position_impacts')!='PENDING_NEW_LEGACY_SAVED_EXECUTION_NOT_INHERITED_FROM_D'
            or sidecar.get('certifies_liquidation') is not False or sidecar.get('certifies_no_liquidation') is not False
            or sidecar.get('funding_rate_unit')!='UNCONFIRMED_PRESERVED_NO_RESCALE'):
        raise ValueError('EXACT_FROZEN_2023_LEGACY_SOURCE_QUALITY_REQUIRED')
    return True
