"""Invented in-memory bytes for financial wire and real CLI regression tests."""
from copy import deepcopy
import legacy_bootstrap
import legacy_native_common as c
import legacy_config as config
import legacy_source_entry as entry
import legacy_source as source
import legacy_codec as codec
import legacy_generated as generated
import legacy_finance_gate as gate


def fixture():
    prep,artifacts,targets=generated.fixture()
    inputs=codec.npz(artifacts['2023/SOURCE_INPUTS.npz'],{'close_available_us':((564,),'int64'),'close':((564,5),'float64')})
    period=config.source_year(2023)
    quality=dict(schema='LEGACY_INTRINSIC_REUSED_QUALIFIED_2023_SOURCE_QUALITY_V1',year=2023,
        calendar=[period['start'],period['end']],qualified_source_identity=prep['years']['2023']['source_identity'],
        original_quality_sidecar_SHA256='a'*64,original_quality_sidecar={'generated_only':True},cells=[],quality_intervals=[],
        derived_mark_cells=0,final_endpoint_close={s:100. for s in config.SYMBOLS},source_completion_is_not_arrival_certification=True,
        arrival_status='UNKNOWN_NOT_CERTIFIED',original_source_age_and_arrival_flags_preserved=True,
        actual_legacy_event_and_position_impacts='PENDING_NEW_LEGACY_SAVED_EXECUTION_NOT_INHERITED_FROM_D',
        certifies_liquidation=False,certifies_no_liquidation=False,
        funding_ownership='CURRENT_NATIVE_ACTUAL_QUANTITY_ONLY_AFTER_PAID_FILLS',funding_rate_unit='UNCONFIRMED_PRESERVED_NO_RESCALE')
    sidecar=c.canonical(quality)+b'\n';artifacts['2023/MINUTE_MARK_PROVENANCE.json']=sidecar
    prep['artifacts']['2023/MINUTE_MARK_PROVENANCE.json']=dict(SHA256=c.sha(sidecar),bytes=len(sidecar))
    prep['years']['2023']['source_quality_sidecar_SHA256']=c.sha(sidecar)
    for cell_id in prep['ordered_cells']:
        binding=entry.binding_from_info(config.cell_named(cell_id),prep['years']['2023'],prep['source_stage_GO_SHA256'],prep['source_review_SHA256'])
        prep['cells'][cell_id]['input_binding']=binding;prep['cells'][cell_id]['input_binding_SHA256']=c.jsha(binding)
    captured=dict(year=2023,period=config.source_year(2023),clocks=inputs['close_available_us'],close=inputs['close'],
        decisions=targets['decision_us'],source_rows=c.object_json(artifacts['2023/SOURCE_ROWS.json']),events=(),months=(),
        quality_cells=(),quality_intervals=(),sidecar=c.object_json(artifacts['2023/MINUTE_MARK_PROVENANCE.json']),
        sidecar_raw=artifacts['2023/MINUTE_MARK_PROVENANCE.json'],source_identity=prep['years']['2023']['source_identity'],
        contract=entry.contracts()['years']['2023'])
    return c.canonical(prep),artifacts,captured


def bundle(preparation_raw):
    p=entry.validate_preparation_metadata(preparation_raw)
    prepared=c.exact_object(c.ordinary(c.HERE/'PREPARED_REVIEW_SCHEMA_TEMPLATE.json'))
    prepared.update(array_identities=p['years']['2023']['array_identities'],cell_bindings=p['cells'],
        preparation=dict(SHA256=c.sha(preparation_raw),bytes=len(preparation_raw)),
        source_stage_GO_SHA256=p['source_stage_GO_SHA256'],source_generated_review_SHA256=p['source_review_SHA256'])
    for name in prepared['source_artifacts']:
        suffix=name.split('/source_attempts/FIRST6_2023_attempt001/',1)[1]
        if suffix in p['artifacts']:prepared['source_artifacts'][name]=p['artifacts'][suffix]
        if suffix=='PREPARATION.json':prepared['source_artifacts'][name]=prepared['preparation']
    pr=c.canonical(prepared);nr=c.canonical(gate.native_policy('0'*64))
    rr=c.canonical(gate.review_policy(preparation_raw,c.sha(pr),c.sha(nr)))
    go=c.canonical(gate.policy(preparation_raw,c.sha(rr),c.sha(pr),c.sha(nr),[4,5]))
    sg,_,sr,_=generated.authority()
    raw={'go':go,'review':rr,'prepared-review':pr,'native-review':nr,'source-go':sg,'source-review':sr}
    return raw,{k:c.sha(v) for k,v in raw.items()}


def validate(prep,raw):
    return gate.validate(prep,raw['go'],c.sha(raw['go']),raw['review'],c.sha(raw['review']),
        raw['prepared-review'],c.sha(raw['prepared-review']),raw['native-review'],c.sha(raw['native-review']))
