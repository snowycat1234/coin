"""Bind the exact frozen legacy source graph without modifying or copying it."""
from pathlib import Path
import sys
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
SOURCE=ROOT/'legacy_intrinsic_D_20261015_v1'
if str(SOURCE) not in sys.path:sys.path.insert(0,str(SOURCE))
import legacy_common,legacy_config,legacy_codec,legacy_entry,legacy_signal,legacy_source,legacy_loader,legacy_source_guard
for name in ('legacy_common','legacy_config','legacy_codec','legacy_entry','legacy_signal','legacy_source','legacy_loader','legacy_source_guard'):
    if Path(sys.modules[name].__file__).resolve()!=SOURCE/(name+'.py'):
        raise ValueError('EXACT_FROZEN_LEGACY_SOURCE_MODULE_IDENTITY_REQUIRED:'+name)
