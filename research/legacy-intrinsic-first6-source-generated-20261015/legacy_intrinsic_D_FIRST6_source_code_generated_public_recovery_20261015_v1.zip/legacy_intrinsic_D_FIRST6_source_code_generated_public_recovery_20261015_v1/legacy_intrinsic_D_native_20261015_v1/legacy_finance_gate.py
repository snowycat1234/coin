"""Separate legacy financial admission. No CS or plain-V3 authority is reused."""
from pathlib import Path
import legacy_bootstrap
import legacy_native_common as c
import legacy_source_entry as source_entry
import legacy_config as config

SOURCE_CODE_SHA256='fd365011ea371e7f75965b23628bb8e0b04a85214d3c62ba162013c9e021c5c7'
REVIEW_SCHEMA='INDEPENDENT_LEGACY_FIRST6_FINANCIAL_ADMISSION_V1'
GO_SCHEMA='ROOT_FINANCIAL_LEGACY_FIRST6_INTRINSIC_CURRENT_D_V1'
PREPARED_REVIEW_SCHEMA='INDEPENDENT_LEGACY_INTRINSIC_PREPARED_TARGET_REVIEW_V1'
NATIVE_REVIEW_SCHEMA='INDEPENDENT_LEGACY_FIRST6_NATIVE_GENERATED_ADMISSION_V1'
CLAIM_NAMESPACE='legacy_intrinsic_D_native_20261015_v1/EXECUTION_CLAIMS'
SHARED_CPU_LEASE='original_cs_mom21_D_20261015_v4/EXECUTION_CLAIMS/9a5ef547d61272d5eb0bfb1b61fef8005a752d82f4e0007d18cbe65f06445a8a/CONTROLLER_LEASE.lock'


def code_identity():
    here=Path(__file__).resolve().parent
    if c.HERE!=here or Path(source_entry.__file__).resolve()!=legacy_bootstrap.SOURCE/'legacy_entry.py':
        raise ValueError('EXACT_NEW_FINANCE_AND_FROZEN_SOURCE_MODULE_IDENTITIES_REQUIRED')
    if source_entry.code_identity()!=SOURCE_CODE_SHA256:raise ValueError('FROZEN_LEGACY_SOURCE_IDENTITY_CHANGED')
    raw=c.ordinary(here/'FINANCIAL_CODE_MANIFEST.json');m=c.exact_object(raw)
    if (set(m)!={'schema','status','source_code_manifest_SHA256','files','dependencies','runtime_dependency_exclusions'}
            or m['schema']!='ADDITIVE_LEGACY_FIRST6_NATIVE_FINANCIAL_CODE_V1'
            or m['source_code_manifest_SHA256']!=SOURCE_CODE_SHA256
            or m['runtime_dependency_exclusions']!=['CS_FAILED_CLAIMS','CS_SUPERSESSION_PACKETS','CS_ROOT_GO','PLAIN_V3_ROOT_GO']):
        raise ValueError('EXACT_LEGACY_FINANCIAL_CODE_MANIFEST_REQUIRED')
    for name,pin in m['files'].items():c.exact(here/c.relative(name),pin['SHA256'],pin['bytes'])
    for name,pin in m['dependencies'].items():c.exact(c.ROOT/c.relative(name),pin['SHA256'],pin['bytes'])
    return c.sha(raw)


def base(preparation_raw):
    p=source_entry.validate_preparation_metadata(preparation_raw)
    return dict(source_code_manifest_SHA256=SOURCE_CODE_SHA256,financial_code_manifest_SHA256=code_identity(),
        scope_manifest_SHA256=source_entry.manifest_sha(),source_contract_map_SHA256=source_entry.contract_sha(),
        tranche=source_entry.FIRST6,ordered_cells=list(source_entry.tranche_cells(source_entry.FIRST6)),years=[2023],
        preparation_SHA256=c.sha(preparation_raw),source_stage_GO_SHA256=p['source_stage_GO_SHA256'],
        source_independent_review_SHA256=p['source_review_SHA256'],
        per_cell_input_binding_SHA256={k:v['input_binding_SHA256'] for k,v in p['cells'].items()})


def policy(preparation_raw,review_sha,prepared_review_sha,native_review_sha,worker_cpus):
    if type(worker_cpus) is not list or worker_cpus!=[4,5] or any(type(x) is not int for x in worker_cpus):
        raise ValueError('EXACT_MAX2_DISTINCT_CPU4_5_WORKERS_REQUIRED')
    return dict(base(preparation_raw),schema=GO_SCHEMA,status='APPROVED_FRESH_EXACT_FIRST6',
        action='RUN_FRESH_LEGACY_TWO_ORIGINAL_INTRINSIC_RECIPES_FIRST6_2023_CURRENT_D_ONLY',
        requested_worker_count=2,worker_CPUs=[4,5],resource_limits=dict(per_case_wall_seconds=600,per_case_CPU_seconds=600,
            per_case_RSS_stop_bytes=2000000000,per_case_AS_bytes=4000000000,per_case_output_bytes=250000000,
            aggregate_live_worker_RSS_stop_bytes=3500000000,compute_pool_threads_max=1),
        global_inherited_flock_required=True,permanent_cross_output_cell_claim_required=True,
        separate_fresh_genesis_claim_namespace=CLAIM_NAMESPACE,shared_CS_CPU45_lease=SHARED_CPU_LEASE,
        shared_CPU45_lease_nonblocking=True,other_controller_overlap_authorized=False,
        target_financial_independent_review_SHA256=c.digest(review_sha),
        prepared_source_target_review_SHA256=c.digest(prepared_review_sha),native_generated_review_SHA256=c.digest(native_review_sha),
        policy_variant='GUARD50_EXIT_ONLY',cost='BASE27',initial_cash_USDT='10000',free_cash_floor_USDT='1000',
        isolated_margin_ceiling_USDT='8500',quantity_profile_SHA256='94b2238b25ed345a24a1fa148c6f35523b8efe9bf47496958028844432cb8ebf',
        source_recapture='EXACT_FROZEN_LEGACY_2023_CAPTURE_UNCHANGED_SOURCE_GUARD_BEFORE_FINANCE_IMPORT',
        generated_resource_probe_binding='EXACT_HASH_IN_EXTERNALLY_BOUND_NATIVE_GENERATED_REVIEW',
        complete_original_intrinsic_signal_preserved=True,downward_only_tier_ceilings=True,reexpansion_authorized=False,
        literal_funding_event_clocks_preserved=True,funding_clock_rounding_authorized=False,funding_rate_rescale_authorized=False,
        saved_targets_rebuilt_during_finance=False,covariance_rebuilt_during_finance=False,
        actual_provider_iteration_authorized=True,account_construction_authorized=True,financial_execution_authorized=True,
        fresh_genesis_only=True,automatic_retry_authorized=False,halted_snapshot_resume_authorized=False,
        internal_margin_transfers_authorized=False,topup_authorized=False,new_capital_authorized=False,debt_forgiveness_authorized=False,
        old_CS_D_or_plain_V3_GO_reused_as_authority=False,old_financial_scope_or_LoadedInputs_reused=False,
        other24_cells_authorized=False,publication_authorized=False)


def prepared_review(preparation_raw,raw,expected_sha):
    p=source_entry.validate_preparation_metadata(preparation_raw);info=p['years']['2023'];r=c.checked_external(raw,expected_sha)
    template=c.exact_object(c.ordinary(c.HERE/'PREPARED_REVIEW_SCHEMA_TEMPLATE.json'))
    dynamic={'array_identities','cell_bindings','audit_details','audit_guard_receipt','exact_target_identity','preparation',
             'source_artifacts','source_stage_GO_SHA256','source_generated_review_SHA256'}
    if set(r)!=set(template) or any(c.canonical(r[k])!=c.canonical(v) for k,v in template.items() if k not in dynamic):
        raise ValueError('EXACT_LEGACY_PREPARED_REVIEW_SCHEMA_AND_NONAUTHORITY_POLICY_REQUIRED')
    wanted=dict(array_identities=info['array_identities'],cell_bindings=p['cells'],
        preparation=dict(SHA256=c.sha(preparation_raw),bytes=len(preparation_raw)),
        source_stage_GO_SHA256=p['source_stage_GO_SHA256'],source_generated_review_SHA256=p['source_review_SHA256'])
    if any(c.canonical(r[k])!=c.canonical(v) for k,v in wanted.items()):
        raise ValueError('EXACT_LEGACY_PREPARED_SOURCE_TARGET_BINDINGS_REQUIRED')
    def pin(value):
        if type(value) is not dict or set(value)!={'SHA256','bytes'} or type(value['bytes']) is not int or value['bytes']<0:
            raise ValueError('EXACT_REVIEW_BYTE_PIN_REQUIRED')
        c.digest(value['SHA256'])
    pin(r['audit_details']);pin(r['audit_guard_receipt'])
    if type(r['source_artifacts']) is not dict or set(r['source_artifacts'])!=set(template['source_artifacts']):
        raise ValueError('EXACT_REVIEW_SOURCE_ARTIFACT_NAMESPACE_REQUIRED')
    for name,value in r['source_artifacts'].items():
        c.relative(name);pin(value)
        suffix=name.split('/source_attempts/FIRST6_2023_attempt001/',1)[1]
        expected=p['artifacts'].get(suffix, wanted['preparation'] if suffix=='PREPARATION.json' else None)
        if expected is not None and c.canonical(value)!=c.canonical(expected):raise ValueError('EXACT_PREPARED_ARTIFACT_REVIEW_PIN_REQUIRED')
    ident=r['exact_target_identity'];shape=template['exact_target_identity']
    if (type(ident) is not dict or set(ident)!=set(shape) or set(ident['SHA256_by_config'])!=set(shape['SHA256_by_config'])
            or any(c.canonical(ident[k])!=c.canonical(v) for k,v in shape.items() if k!='SHA256_by_config')):
        raise ValueError('EXACT_REVIEW_SIX_TARGET_IDENTITY_SCHEMA_REQUIRED')
    for value in ident['SHA256_by_config'].values():c.digest(value)
    return c.immutable(r)


def native_policy(resource_probe_sha):
    return dict(schema=NATIVE_REVIEW_SCHEMA,status='PASS',source_code_manifest_SHA256=SOURCE_CODE_SHA256,
        financial_code_manifest_SHA256=code_identity(),scope_manifest_SHA256=source_entry.manifest_sha(),
        tranche=source_entry.FIRST6,ordered_cells=list(source_entry.tranche_cells(source_entry.FIRST6)),years=[2023],
        native_financial_gate_reviewed=True,financial_execution_authorized=False,actual_source_or_target_bodies_read=False,
        old_CS_D_or_plain_V3_GO_reused_as_authority=False,generated_two_worker_probe_passed=True,worker_CPUs=[4,5],
        maximum_observed_live_workers=2,generated_resource_probe_SHA256=c.digest(resource_probe_sha),
        shared_CPU45_lease_exclusion_reviewed=True,real_CLI_generated_GO_guard_integration_reviewed=True,
        separate_legacy_claim_namespace_reviewed=True)


def native_review(raw,expected_sha):
    r=c.checked_external(raw,expected_sha)
    if c.canonical(r)!=c.canonical(native_policy(r.get('generated_resource_probe_SHA256'))):
        raise ValueError('EXACT_SEPARATE_LEGACY_NATIVE_GENERATED_REVIEW_REQUIRED')
    return c.immutable(r)


def review_policy(preparation_raw,prepared_review_sha,native_review_sha):
    return dict(base(preparation_raw),schema=REVIEW_SCHEMA,status='PASS',
        prepared_source_target_review_SHA256=c.digest(prepared_review_sha),native_generated_review_SHA256=c.digest(native_review_sha),
        native_financial_gate_reviewed=True,financial_execution_authorized=False,
        real_CLI_generated_GO_guard_integration_reviewed=True,shared_CPU45_lease_exclusion_reviewed=True,
        separate_legacy_fresh_genesis_claims_reviewed=True,old_CS_D_or_plain_V3_GO_reused_as_authority=False,
        other24_cells_authorized=False)


def validate(preparation_raw,go_raw,expected_go_sha,review_raw,expected_review_sha,
             prepared_review_raw,expected_prepared_review_sha,native_review_raw,expected_native_review_sha):
    prepared_review(preparation_raw,prepared_review_raw,expected_prepared_review_sha)
    native_review(native_review_raw,expected_native_review_sha)
    r=c.checked_external(review_raw,expected_review_sha)
    if c.canonical(r)!=c.canonical(review_policy(preparation_raw,expected_prepared_review_sha,expected_native_review_sha)):
        raise ValueError('EXACT_NEW_LEGACY_NATIVE_FINANCIAL_REVIEW_REQUIRED')
    go=c.checked_external(go_raw,expected_go_sha)
    if c.canonical(go)!=c.canonical(policy(preparation_raw,expected_review_sha,expected_prepared_review_sha,expected_native_review_sha,go.get('worker_CPUs'))):
        raise ValueError('EXACT_NEW_LEGACY_ROOT_FINANCIAL_AUTHORITY_REQUIRED')
    return c.immutable(go)
