"""Instrumented sealed-native/fake-metadata suite; no actual source or finance."""
import os
THREAD_ENV = ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS',
              'NUMEXPR_NUM_THREADS', 'POLARS_MAX_THREADS', 'VECLIB_MAXIMUM_THREADS', 'BLIS_NUM_THREADS')
for key in THREAD_ENV:
    os.environ[key] = '1'
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'

import legacy_bootstrap
import builtins
from contextlib import ExitStack
import io
import json
from pathlib import Path
import resource
import socket
import subprocess
import sys
import time
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
observed = dict(actual_source_body_read_attempts=0, old_private_GO_body_read_attempts=0,
                external_process_launch_attempts=0, network_attempts=0)


def check(file):
    if isinstance(file, int) or not isinstance(file, (str, bytes, os.PathLike)):
        return
    path = Path(os.path.abspath(os.fsdecode(file)))
    if path.suffix.lower() in ('.npz', '.npy', '.csv', '.tsv', '.parquet', '.arrow', '.ipc', '.zip'):
        observed['actual_source_body_read_attempts'] += 1
        raise AssertionError('NO_STORED_ARRAY_OR_MARKET_BODY_READS_IN_GENERATED_SUITE:' + str(path))
    if ('annual_go' in path.parts or path.name.startswith(('ROOT_GO_APPROVED','ROOT_SOURCE_FIRST6_APPROVED'))
            or path.name in ('ROOT_GO.json', 'ROOT_GO_FINANCIAL.json') or ('source_attempts' in path.parts and path.suffix.lower() not in ('.py','.md'))):
        observed['old_private_GO_body_read_attempts'] += 1
        raise AssertionError('NO_PRIVATE_OLD_GO_BODY_READS:' + str(path))


def wrapped(original):
    def opened(file, mode='r', *args, **kwargs):
        if 'r' in mode or '+' in mode:
            check(file)
        return original(file, mode, *args, **kwargs)
    return opened


original_os_open = os.open


def os_open(path, flags, *args, **kwargs):
    if not flags & os.O_WRONLY:
        check(path)
    return original_os_open(path, flags, *args, **kwargs)


def main():
    os.sched_setaffinity(0, {min(os.sched_getaffinity(0))})
    began = time.monotonic()
    import legacy_source_entry as entry
    import legacy_source as source
    import legacy_admission as admission
    import legacy_input_loader as loader
    import legacy_native_generated as generated
    native = generated.native_reference()
    for key in ('actual_source_scope_mint_attempts', 'actual_historical_scope_mint_attempts',
                'actual_capture_or_target_attempts', 'actual_provider_call_attempts'):
        observed[key] = 0
    with ExitStack() as stack:
        for obj, name, fn in ((builtins, 'open', wrapped(builtins.open)),
                              (io, 'open', wrapped(io.open)), (os, 'open', os_open)):
            stack.enter_context(patch.object(obj, name, fn))
        def denied(category, target):
            def fail(*args, **kwargs):
                observed[category] += 1
                raise AssertionError('GENERATED_ONLY_EXTERNAL_ACTION_FORBIDDEN:' + target)
            return fail
        for obj, names, category in (
            (subprocess, ('Popen', 'run', 'call', 'check_call', 'check_output'), 'external_process_launch_attempts'),
            (os, ('system', 'fork', 'forkpty', 'posix_spawn', 'posix_spawnp', 'execv', 'execve', 'execvp', 'execvpe'),
             'external_process_launch_attempts'),
            (socket.socket, ('connect', 'connect_ex', 'sendto', 'send', 'sendall'), 'network_attempts')):
            for name in names:
                if hasattr(obj, name):
                    stack.enter_context(patch.object(obj, name, denied(category, name)))
        for obj, name, category in (
            (entry.LegacySourcePreparationScope, '__post_init__', 'actual_source_scope_mint_attempts'),
            (admission.FreshHistoricalExecutionScope, '__post_init__', 'actual_historical_scope_mint_attempts'),
            (source, 'capture_year', 'actual_capture_or_target_attempts'),
            (source, 'project_targets', 'actual_capture_or_target_attempts'),
            (admission.CapturedMinuteProvider, '__call__', 'actual_provider_call_attempts')):
            stack.enter_context(patch.object(obj, name, denied(category, name)))
        suite = unittest.defaultTestLoader.loadTestsFromNames(['test_legacy_native', 'test_legacy_finance'])
        result = unittest.TextTestRunner(verbosity=2).run(suite)
    receipt = dict(schema='LEGACY_FIRST6_FINANCIAL_SEALED_NATIVE_AND_FAKE_METADATA_RECEIPT_V1',
        status='PASS' if result.wasSuccessful() and not any(observed.values()) else 'FAIL',
        tests=result.testsRun, failures=len(result.failures), errors=len(result.errors), observed=observed,
        CPU_affinity=sorted(os.sched_getaffinity(0)),
        all_TID_affinities=[sorted(os.sched_getaffinity(int(t))) for t in os.listdir('/proc/self/task')],
        numerical_environment={key: os.environ[key] for key in THREAD_ENV},
        elapsed_wall_seconds=time.monotonic() - began,
        peak_RSS_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024,
        worker_processes_launched=0, maximum_generated_processes=1,
        actual_source_body_reads=0, actual_targets_generated=0, actual_financial_runs=0,
        actual_claims_written=0, source_admission_GO_written=0, financial_GO_written=0,
        provider_or_history_calls=0, publication_actions=0, holdout_reads=0,
        raw_and_original_sized_and_common_tier_arrays='GENERATED_IN_MEMORY_ONLY_NOT_ACTUAL_TARGET_ARTIFACTS')
    from legacy_source_entry import code_identity,manifest_sha,contract_sha
    from legacy_finance_gate import code_identity as financial_code_identity
    receipt.update(financial_code_manifest_SHA256=financial_code_identity(),
        loaded_input_seals_remaining=len(loader._LIVE), actual_financial_scope_seals_remaining=len(admission._LIVE),
        internally_generated_native_input_seals_remaining=len(generated._LIVE_NATIVE_INPUTS))
    receipt.update(source_code_manifest_SHA256=code_identity(),scope_manifest_SHA256=manifest_sha(),
        source_contract_map_SHA256=contract_sha(),actual_source_scopes_minted=0,historical_scopes_minted=0,
        source_authority_domain='GENERATED_NATIVE_AND_FAKE_FINANCIAL_METADATA_ONLY_NO_ACTUAL_ADMISSION')
    (HERE / 'FINANCIAL_GENERATED_TEST_RECEIPT.json').write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
    return 0 if receipt['status'] == 'PASS' else 1


if __name__ == '__main__':
    raise SystemExit(main())
