"""Seal code/metadata only; never read stored arrays, source bodies, or claims."""
from hashlib import sha256
import json
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
SOURCE=ROOT/'legacy_intrinsic_D_20261015_v1'
def pin(path):
    raw=path.read_bytes();return dict(SHA256=sha256(raw).hexdigest(),bytes=len(raw))
def seal():
    src=json.loads((SOURCE/'CODE_MANIFEST.json').read_bytes())
    # Inherited finance primitives only. Explicitly exclude CS recovery lineage.
    old=json.loads((ROOT/'original_cs_mom21_D_20261015_v5/FINANCIAL_CODE_MANIFEST.json').read_bytes())
    deps={n:p for n,p in old['dependencies'].items() if not n.startswith('original_cs_')}
    deps.update(src['dependencies'])
    deps.update({'legacy_intrinsic_D_20261015_v1/'+n:p for n,p in src['files'].items()})
    deps['legacy_intrinsic_D_20261015_v1/CODE_MANIFEST.json']=pin(SOURCE/'CODE_MANIFEST.json')
    deps['cs_saved_minute_reporting_repair_20261015_v2/bounded_drain.py']=pin(ROOT/'cs_saved_minute_reporting_repair_20261015_v2/bounded_drain.py')
    deps['cs_saved_minute_reporting_repair_independent_review_20261015/INDEPENDENT_REPORTING_AND_DRAIN_REPAIR_REVIEW.json']=pin(ROOT/'cs_saved_minute_reporting_repair_independent_review_20261015/INDEPENDENT_REPORTING_AND_DRAIN_REPAIR_REVIEW.json')
    for name,expected in deps.items():
        if Path(name).suffix not in ('.py','.json','.md') or pin(ROOT/name)!=expected:
            raise ValueError('EXACT_CODE_METADATA_DEPENDENCY_REQUIRED:'+name)
    names={p.name for p in HERE.glob('*.py')}|{'FROZEN_THIRTY_CELL_MANIFEST.json','PREPARED_REVIEW_SCHEMA_TEMPLATE.json','NATIVE_PROCESS_PROVENANCE.json'}
    value=dict(schema='ADDITIVE_LEGACY_FIRST6_NATIVE_FINANCIAL_CODE_V1',
        status='CODE_GENERATED_ONLY_REQUIRES_INDEPENDENT_REVIEW_AND_FRESH_FINANCIAL_GO',
        source_code_manifest_SHA256='fd365011ea371e7f75965b23628bb8e0b04a85214d3c62ba162013c9e021c5c7',
        files={n:pin(HERE/n) for n in sorted(names)},dependencies=deps,
        runtime_dependency_exclusions=['CS_FAILED_CLAIMS','CS_SUPERSESSION_PACKETS','CS_ROOT_GO','PLAIN_V3_ROOT_GO'])
    (HERE/'FINANCIAL_CODE_MANIFEST.json').write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')
    print(pin(HERE/'FINANCIAL_CODE_MANIFEST.json'))
if __name__=='__main__':seal()
