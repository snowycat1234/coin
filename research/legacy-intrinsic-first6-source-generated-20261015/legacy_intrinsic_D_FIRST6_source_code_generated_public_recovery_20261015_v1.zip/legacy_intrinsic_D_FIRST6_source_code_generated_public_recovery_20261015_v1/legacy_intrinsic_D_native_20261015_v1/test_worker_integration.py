"""Fresh-process real CLI + real executable GO + unchanged guard regression.

Only invented fixture storage, recording source-context/capture and the post-
guard native constructor sentinel are substituted. Real loader, wire verifier,
code pin checks, NPZ codec, binding validation and CLI dispatch all execute.
No runtime generated flag exists. This is not an annual-history execution.
"""
from contextlib import contextmanager
from copy import deepcopy
from io import BytesIO
import json
import os
from pathlib import Path
import sys
import tempfile
import types
from unittest.mock import patch

import numpy as np
import legacy_bootstrap
import legacy_native_common as c
import legacy_codec as codec
import legacy_config as config
import legacy_source_entry as entry
import legacy_finance_gate as gate
import legacy_input_loader as loader
import legacy_source as source
import legacy_verified_wires as verified
import run_legacy
from legacy_source_guard import current_guard, SourceOnlyGuard, SourceBoundaryViolation
from generated_financial_fixture import fixture,bundle


class StopBeforeNative(Exception):pass


def main():
    mode=sys.argv[1] if len(sys.argv)>1 else 'positive'
    prep,artifacts,captured=fixture();raw,hashes=bundle(prep);events=[];captured_calls=[]
    # Negative authority serialization still fails under the unchanged guard.
    guard=SourceOnlyGuard()
    try:
        with guard:c.canonical(c.exact_object(raw['go']))
    except SourceBoundaryViolation:pass
    else:raise AssertionError('EXECUTABLE_GO_WRITE_WAS_ALLOWED')
    assert guard.attempts['financial_GO_writes']==1
    # Positive one-use metadata checks are recording-only and revoke on failures.
    cell=sys.argv[2] if len(sys.argv)>2 else entry.tranche_cells(entry.FIRST6)[0]
    claim=c.canonical(dict(cell_id=cell,root_GO_SHA256=hashes['go'],preparation_SHA256=c.sha(prep),code_identity=gate.code_identity()))
    for negative in ('wrongyear','wrongprep','wronggo','wrongcode','replay','revoked','wrongcell'):
        with verified.verify(preparation_raw=prep,cell_id=cell,raw=raw,hashes=hashes,claim_raw=claim) as token:
            kwargs=dict(preparation_raw=prep,year=2023,supplied=dict(raw))
            if negative=='wrongyear':kwargs['year']=2022
            if negative=='wrongprep':kwargs['preparation_raw']=prep+b' '
            if negative=='wronggo':kwargs['supplied']['go']=b'{}'
            if negative=='revoked':verified._LIVE.pop(token._token)
            if negative=='wrongcell':object.__setattr__(token,'cell_id',next(v for v in entry.tranche_cells(entry.FIRST6) if v!=cell))
            if negative=='replay':token.consume(**kwargs)
            try:
                if negative=='wrongcode':
                    with patch.object(gate,'code_identity',return_value='a'*64):token.consume(**kwargs)
                else:token.consume(**kwargs)
            except ValueError:pass
            else:raise AssertionError('TOKEN_NEGATIVE_ALLOWED:'+negative)
        assert not verified._LIVE
    with verified.verify(preparation_raw=prep,cell_id=cell,raw=raw,hashes=hashes,claim_raw=claim):
        try:
            with verified.verify(preparation_raw=prep,cell_id=cell,raw=raw,hashes=hashes,claim_raw=claim):pass
        except ValueError as error:assert 'CONFLICTING' in str(error)
        else:raise AssertionError('DUPLICATE_LIVE_CLAIM_TOKEN_ALLOWED')
    assert not verified._LIVE
    with tempfile.TemporaryDirectory(prefix='LEGACY_GENERATED_CLI_ONLY_') as td:
        base=Path(td);preproot=base/'preparation';preproot.mkdir();caseout=base/'case';caseout.mkdir()
        (preproot/'PREPARATION.json').write_bytes(prep)
        for key,value in artifacts.items():
            path=preproot/key;path.parent.mkdir(exist_ok=True);path.write_bytes(value)
        argv=['run_legacy.py','--case','--cell-id',cell,'--cpu',str(min(os.sched_getaffinity(0))),'--case-output',str(caseout),
              '--preparation',str(preproot),'--preparation-sha',c.sha(prep)]
        for key,value in raw.items():
            path=base/(key+'.json');path.write_bytes(value);argv+=['--'+key,str(path),'--'+key+'-sha',hashes[key]]
        original_save=run_legacy.r.save
        @contextmanager
        def recording_source_context(*args):
            assert current_guard() is not None;events.append('recording_source_context');yield object()
        def capture(year,scope):
            assert current_guard() is not None and year==2023;captured_calls.append(year);events.append('fake_source_capture')
            if mode=='capture_failure':raise ValueError('GENERATED_CAPTURE_FAILURE')
            return captured
        @contextmanager
        def stop_native(*args,**kwargs):
            assert current_guard() is None and not verified._LIVE;events.append('post_guard_native_constructor_sentinel')
            raise StopBeforeNative('GENERATED_STOP_BEFORE_ANY_NATIVE_ACCOUNT_SCOPE_OR_PROVIDER')
            yield
        def storage_save(path,value):
            original_save(path,value)
            if Path(path).name=='WORKER_AUTHORITY_VERIFIED.json':events.append('real_GO_verified_before_guard')
            if Path(path).name=='WORKER_SOURCE_ACCEPTED_BEFORE_ACCOUNT.json':
                events.append('source_accepted_guard_exited')
                m=types.ModuleType('legacy_admission');m.admit_case=stop_native;sys.modules['legacy_admission']=m
                sys.modules['legacy_native']=types.ModuleType('legacy_native')
                m=types.ModuleType('saved_native_reconciliation');m.reconcile_saved_native=lambda *a:None;m.checker_sha256=lambda:None
                sys.modules['saved_native_reconciliation']=m
        claim=c.canonical(dict(schema='GENERATED_RECORDING_STORAGE_CLAIM_ONLY',cell_id=cell,root_GO_SHA256=hashes['go'],preparation_SHA256=c.sha(prep),code_identity=gate.code_identity()))
        from contextlib import ExitStack
        original_guard_exit=SourceOnlyGuard.__exit__
        def fail_exit(self,*args):
            result=original_guard_exit(self,*args)
            if mode=='guard_exit_failure':raise ValueError('GENERATED_GUARD_EXIT_FAILURE')
            return result
        with ExitStack() as stack:
            if mode=='loaded_validation_failure':stack.enter_context(patch.object(loader.LoadedInputs,'validate',side_effect=ValueError('GENERATED_LOADED_VALIDATION_FAILURE')))
            if mode=='guard_exit_failure':stack.enter_context(patch.object(SourceOnlyGuard,'__exit__',fail_exit))
            stack.enter_context(patch.object(sys,'argv',argv));stack.enter_context(patch.object(run_legacy,'worker_claim',return_value=claim))
            stack.enter_context(patch.object(entry,'admit_source_stage',recording_source_context));stack.enter_context(patch.object(source,'capture_year',capture))
            stack.enter_context(patch.object(run_legacy.r,'save',storage_save))
            try:run_legacy.main()
            except (StopBeforeNative,ValueError) as error:
                if mode=='positive':assert isinstance(error,StopBeforeNative)
                else:assert 'GENERATED_' in str(error)
            else:raise AssertionError('EXPECTED_BOUNDED_SENTINEL_NOT_REACHED')
        for name in ('legacy_admission','legacy_native','saved_native_reconciliation'):sys.modules.pop(name,None)
        receipt_name='SOURCE_RECAPTURE_GUARD_RECEIPT.json' if mode=='positive' else 'FAILED_SOURCE_RECAPTURE_GUARD_RECEIPT.json'
        receipt=c.exact_object((caseout/receipt_name).read_bytes())
        assert all(v==0 for v in receipt['forbidden_attempts'].values()),receipt
        assert captured_calls==[2023] and not verified._LIVE and not loader._LIVE
        if mode=='positive':assert events==['real_GO_verified_before_guard','recording_source_context','fake_source_capture','source_accepted_guard_exited','post_guard_native_constructor_sentinel'],events
        else:assert events==['real_GO_verified_before_guard','recording_source_context','fake_source_capture'],events
    print(json.dumps(dict(status='PASS_REAL_FRESH_CLI_GENERATED_EXECUTABLE_GO_UNCHANGED_GUARD', mode=mode, events=events,
        token_negative_cases=8, authority_serialization_negative_counter=1, positive_guard_counters=receipt['forbidden_attempts'],
        seams=['invented_fixture_storage','worker_claim_recording_storage_callback','recording_source_context_and_capture','post_guard_native_constructor_sentinel'],
        actual_source_reads=0,actual_source_scopes=0,historical_scopes=0,providers=0,accounts=0,claims=0,
        runtime_generated_bypass_present=False,annual_history_execution_certified=False),sort_keys=True))

if __name__=='__main__':main()

