"""Generated-only convenience names over untouched intrinsic source routines."""
import legacy_bootstrap
from legacy_signal import *
from legacy_config import DAY
from legacy_bootstrap import ROOT
