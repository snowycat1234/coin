"""Private additive alias to the untouched source-only entry module."""
import legacy_bootstrap
import sys
import legacy_entry
sys.modules[__name__]=legacy_entry
