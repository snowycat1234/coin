"""Two original matched CORE5 signals, followed only by downward tier caps.

Pure target construction. This module has no account, native run, source download,
fit, outcome, publication, or financial execution entry. Exact original function
ASTs are loaded from the pinned public six-reference closure.
"""
from __future__ import annotations
from dataclasses import dataclass
import hashlib
import importlib.util
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent
DAY = 86_400_000_000
SYMBOLS = ('BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'XRPUSDT', 'DOGEUSDT')
STRATEGIES = ('STATIC50_OLD_NO_REEXPANSION', 'HOLD_CORE5_VOL_MATCHED_NOREEXP')
VERSION = 'SOURCE_MATCHED_CORE5_TWO_SIGNAL_LOWER_ONLY_V1'
SOURCE_PINS_SHA256 = '9d58cf27fdea63bffa25874489d1f8053bd2a77cce55011f27e71ca785d4d983'

@dataclass(frozen=True)
class Tier:
    name: str
    gross_cap: float
    annual_vol_ceiling: float
    asset_cap: float = .30

TIERS = (Tier('LOW', .30, .05), Tier('MID', .60, .10), Tier('HIGH', .90, .15))
CONFIGS = tuple((strategy, tier.name) for strategy in STRATEGIES for tier in TIERS)

def tier_named(name):
    for tier in TIERS:
        if name == tier.name:
            return tier
    raise ValueError('EXACT_FIXED_LOW_MID_HIGH_TIER_REQUIRED')

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def verify_sources(root=HERE):
    root = Path(root)
    manifest = root / 'SOURCE_PINS.json'
    if manifest.is_symlink() or sha(manifest.read_bytes()) != SOURCE_PINS_SHA256:
        raise ValueError('EXACT_EIGHT_FILE_PUBLIC_SOURCE_CLOSURE_REQUIRED')
    records = json.loads(manifest.read_bytes())
    if len(records) != 8:
        raise ValueError('EXACT_EIGHT_FILE_PUBLIC_SOURCE_CLOSURE_REQUIRED')
    for record in records:
        path = root / record['path']
        if path.is_symlink() or any(p.is_symlink() for p in path.parents) or not path.is_file():
            raise ValueError('ORDINARY_PINNED_SOURCE_REQUIRED')
        raw = path.read_bytes()
        blob = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
        if (len(raw) != record['bytes'] or sha(raw) != record['SHA256']
                or blob != record['GitBlobSHA1']):
            raise ValueError('EXACT_ORIGINAL_SOURCE_BYTES_CHANGED:' + record['path'])
    return records

_ORIGINALS = None

def originals():
    global _ORIGINALS
    verify_sources()
    if _ORIGINALS is None:
        path = HERE / 'sources/original_functions.py'
        spec = importlib.util.spec_from_file_location('_legacy_matched_original_ASTs', path)
        loader = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(loader)
        _ORIGINALS = loader.load_originals(HERE / 'sources')
    return _ORIGINALS

def covariance_checked(covariance):
    c = np.asarray(covariance, dtype=np.float64)
    if c.shape != (5, 5) or not np.isfinite(c).all():
        raise ValueError('FINITE_ORDERED_CORE5_COVARIANCE_REQUIRED')
    if not np.allclose(c, c.T, rtol=0, atol=1e-14):
        raise ValueError('SYMMETRIC_COVARIANCE_REQUIRED')
    if np.linalg.eigvalsh(c).min() < -1e-12:
        raise ValueError('NON_PSD_COVARIANCE')
    return c

def lower_only(weight, covariance, tier_name):
    """Never scale above intrinsic weights, including zero/singular-risk intent.

    Volatility is a ceiling, not a request to use released budget. Singular PSD
    covariance is allowed: the original match function defines zero-common-risk
    behavior, and this adapter must preserve it rather than invent exposure.
    """
    tier = tier_named(tier_name)
    w = np.asarray(weight, dtype=np.float64)
    c = covariance_checked(covariance)
    if (w.shape != (5,) or not np.isfinite(w).all()
            or np.abs(w).max() > .30 + 1e-12 or np.abs(w).sum() > .60 + 1e-12):
        raise ValueError('FINITE_ORIGINAL_CORE5_INTRINSIC_ENVELOPE_REQUIRED')
    gross = float(np.abs(w).sum())
    largest = float(np.abs(w).max())
    variance = float(w @ c @ w)
    if not np.isfinite(variance) or variance < -1e-15:
        raise ValueError('INVALID_COVARIANCE_RISK')
    sigma = float(np.sqrt(max(0., variance)))
    if gross == 0:
        return w.copy(), dict(factor=1., raw_sigma=sigma, post_sigma=sigma,
            gross=0., largest=0., binding=['INTRINSIC_CASH'], reexpanded=False,
            annual_vol_ceiling=tier.annual_vol_ceiling,
            shortfall=tier.annual_vol_ceiling, risk_ceiling_met=True)
    factors = {'INTRINSIC_NO_REEXPANSION': 1., 'GROSS_CEILING': tier.gross_cap/gross,
        'ASSET_CEILING': tier.asset_cap/largest}
    if sigma > 0:
        factors['VOL_CEILING'] = tier.annual_vol_ceiling/sigma
    factor = min(factors.values())
    # No tolerance can turn a true downward adjustment into reexpansion.
    out = w.copy() if factor == 1. else w*factor
    post = float(np.sqrt(max(0., out @ c @ out)))
    if (not np.isfinite(out).all() or not np.isfinite(post) or not 0 <= factor <= 1
            or np.any(np.abs(out) > np.abs(w) + 1e-15)
            or np.abs(out).sum() > tier.gross_cap + 1e-12
            or np.abs(out).max() > tier.asset_cap + 1e-12
            or post > tier.annual_vol_ceiling + 1e-12):
        raise ValueError('LOWER_ONLY_POSTCONDITION_FAILED')
    return out, dict(factor=float(factor), raw_sigma=sigma, post_sigma=post,
        gross=float(np.abs(out).sum()), largest=float(np.abs(out).max()),
        binding=[key for key, value in factors.items() if value == factor],
        reexpanded=False, annual_vol_ceiling=tier.annual_vol_ceiling,
        shortfall=max(0., tier.annual_vol_ceiling-post), risk_ceiling_met=True)

def _clock(value):
    a = np.asarray(value)
    if (a.ndim != 1 or a.dtype.kind not in 'iu' or not len(a)
            or np.any(a < 0) or np.any(a > np.iinfo(np.int64).max)
            or np.any(a % DAY) or np.any(np.diff(a.astype(np.int64)) != DAY)):
        raise ValueError('COMPLETE_UTC_DAILY_INTEGER_CLOCKS_REQUIRED')
    return a.astype(np.int64)

def build_target_grid(close, close_us, available_us, decisions, *, symbols=SYMBOLS,
                      sma_finite_mask=None):
    """Full-five original 200-close admission, exact match, six lower-only paths.

    The original HOLD expert uses SMA only as a finite-readiness mask, never its
    sign. For this common-execution adaptation the default readiness projection
    is full 200 finite positive completed closes. An explicitly supplied Boolean
    mask is also honored; unready full-five windows fail closed. This is a new
    common-execution variant, not literal replication of legacy feature/account
    metadata. No membership is inferred or substituted. Future suffix prices
    cannot enter any selected decision's source functions or proof.
    """
    if tuple(symbols) != SYMBOLS:
        raise ValueError('EXACT_CORE5_ORDER_REQUIRED')
    p = np.asarray(close, dtype=np.float64)
    t, a, d = (_clock(value) for value in (close_us, available_us, decisions))
    if p.shape != (len(t), 5) or a.shape != t.shape or not np.array_equal(a, t):
        raise ValueError('EXACT_COMPLETED_CLOSE_AVAILABILITY_NAMESPACE_REQUIRED')
    ids = np.searchsorted(t, d)
    if np.any(ids >= len(t)) or not np.array_equal(t[ids], d) or np.any(ids < 199):
        raise ValueError('ORIGINAL_FULL_FIVE_200_COMPLETED_CLOSE_ADMISSION')
    if sma_finite_mask is not None:
        mask = np.asarray(sma_finite_mask)
        if mask.dtype != np.dtype(bool) or mask.shape != p.shape:
            raise ValueError('EXPLICIT_BOOLEAN_ORDERED_SMA_FINITE_MASK_REQUIRED')
    else:
        mask = None
    # Ignore rows strictly after the final requested decision, even if invalid.
    end = int(ids[-1])+1
    p, t = p[:end].copy(), t[:end].copy()
    hold_ready = np.zeros(p.shape, dtype=bool)
    for k in range(199, len(t)):
        hold_ready[k] = np.all(np.isfinite(p[k-199:k+1]) & (p[k-199:k+1] > 0), axis=0)
    if mask is not None:
        hold_ready &= mask[:end]
    if not hold_ready[ids].all():
        raise ValueError('ORIGINAL_FULL_FIVE_200_CLOSE_AND_SMA_FINITE_ADMISSION')
    # signed_intents uses this array solely for HOLD finite membership. We do
    # not claim to restore the legacy SMA direction feature or execute that arm.
    sma_gate = np.where(hold_ready, 1., np.nan)
    o = originals()
    expert = o.signed_intents(p, sma_gate, t, SYMBOLS)
    hold = np.asarray(expert[ids, 2, :], dtype=np.float64)
    components, match_proofs, states, diagnostic = o.match(t, p, d, hold, hold_ready[ids])
    if (len(match_proofs) != len(d) or any(x['status'] != 'READY' for x in match_proofs)
            or np.asarray(diagnostic['current_eligible'], dtype=bool).shape != (len(d), 5)
            or not np.asarray(diagnostic['current_eligible'], dtype=bool).all()):
        raise ValueError('EXACT_ORIGINAL_CS_AND_64_CLOCK_MATCH_ADMISSION')
    intrinsic = {STRATEGIES[0]: .5*components['CS_MATCHED'] + .5*components['VOL_MATCHED'],
                 STRATEGIES[1]: components['VOL_MATCHED'].copy()}
    out = {strategy+'_'+tier: np.empty((len(d), 5), dtype=np.float64)
        for strategy, tier in CONFIGS}
    covariance, proofs = [], []
    for i, (at, k) in enumerate(zip(d, ids)):
        past = p[k-30:k+1]
        r = np.diff(past, axis=0)/past[:-1]
        c = covariance_checked(np.cov(r, rowvar=False, ddof=1)*365)
        proof = dict(decision_us=int(at), oldest_completed_close_us=int(t[k-199]),
            last_completed_close_us=int(t[k]), completed_close_count=200,
            HOLD_200_finite_mask=hold_ready[k].tolist(),
            CS_current_eligible=diagnostic['current_eligible'][i],
            CS_weekly_rank_us=int(diagnostic['rank_us'][i]),
            source_match=match_proofs[i], descriptive_source_state=str(states[i]),
            intrinsic={key: value[i].tolist() for key, value in intrinsic.items()}, tiers={})
        for strategy, tier in CONFIGS:
            key = strategy+'_'+tier
            out[key][i], proof['tiers'][key] = lower_only(intrinsic[strategy][i], c, tier)
        covariance.append(c)
        proofs.append(proof)
    return d.copy(), out, np.stack(covariance), proofs

def target_identities(decisions, targets):
    d = _clock(decisions)
    expected = {strategy+'_'+tier for strategy, tier in CONFIGS}
    if set(targets) != expected:
        raise ValueError('EXACT_SIX_TARGET_KEYS_REQUIRED')
    namespace = json.dumps(list(SYMBOLS), separators=(',', ':')).encode()+d.astype('<i8').tobytes()
    identities, representatives, groups = {}, {}, {}
    for key in sorted(targets):
        w = np.asarray(targets[key])
        if w.dtype != np.dtype('float64') or w.shape != (len(d), 5) or not np.isfinite(w).all():
            raise ValueError('EXACT_FINITE_FLOAT64_SIX_PATHS_REQUIRED')
        digest = sha(namespace+w.astype('<f8').tobytes())
        identities[key] = digest
        group = representatives.setdefault(digest, key)
        groups.setdefault(group, []).append(key)
    return dict(SHA256_by_config=identities, exact_target_equality_groups=list(groups.values()),
        distinct_target_paths=len(groups), execution_reuse_authorized=False,
        independent_alpha_families_claimed=False)
