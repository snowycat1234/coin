# Original legacy intrinsic signals: code + GENERATED only

Status: author-generated checks pass; independent review pending. This is an additive pure-signal deliverable. It reads pinned Python source and metadata, and operates on caller-supplied arrays. It has no historical data reader, provider, account, native-history entry, source-admission token, financial GO or financial launcher. No actual source/target application was performed.

## Exact recipes and math

Only these original recipes are included:

- STATIC50_OLD_NO_REEXPANSION = .5 × original CS_MATCHED + .5 × original VOL_MATCHED
- HOLD_CORE5_VOL_MATCHED_NOREEXP = original VOL_MATCHED

The complete original intrinsic target is constructed first. Only then does the unchanged legacy adapter apply f = min(1, tier_vol / original_sigma, tier_gross / original_gross, .30 / original_maxabs), omitting zero denominators according to its original policy. LOW/MID/HIGH volatility ceilings are .05/.10/.15, gross ceilings .30/.60/.90, and each asset ceiling .30. There is no re-expansion, redistribution, retargeting, new predictor or new risk filter. Original cash and smaller caps remain intact.

Pinned original public_targets keeps its default short_absolute_confirmation=False, fixed weekly anchor and stable tie/rank ownership. Original signed_intents supplies HOLD through the existing 200-completed-positive-close and finite-readiness mask, with the original 30-return sample covariance ×365. The original match uses both CS and HOLD risk; matched HOLD can become cash when CS has no risk/signal. It is not replaced by constant-long or current retargeted HOLD. The optional SMA argument is the old Boolean finite-readiness mask, never a new HOLD trend-sign rule.

legacy_signal.py extracts the unchanged legacy implementation AST from the pinned source copy. Only its HERE binding is supplied for the new snapshot. It preloads the unchanged original AST loader directly from verified source bytes so that an unpinned .pyc is never executed as original recipe code. No research runner or model/fitting code is imported. Existing numerical tolerances and rejection policies come from the pinned adapter; no new threshold is introduced.

## Interface and immutable evidence

build_generated_projection returns decisions, intrinsic_original, downward_tiers, covariance, proofs and provenance separately. Returned arrays are backed by immutable bytes, and nested proof/provenance mappings are read-only. Inputs are not mutated. No actual source qualification is inferred from calling a pure function: future historical application needs separately authorized, reviewed source code and qualified inputs.

array_byte_identity binds exact dtype/endian, shape and C-order bytes. A one-ULP difference creates a different identity. Same target bytes across tiers do not establish the same account budget or execution path and never authorize financial reuse. Pure target math does not prove original-native or current Guard50 D execution conformity, quantities, fills, funding, costs, paid exits or terminal behavior.

## Generated checks

Run from the workspace root:

    PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 taskset -c 0 python legacy_intrinsic_D_signal_20261015/run_generated_checks.py

The 29 tests compare all six paths byte-for-byte with the unchanged old adapter for five deterministic fake-price modes: varied, constant, stable ties, coarse prices and common-return ties. They cover original intrinsic match equations, zero-CS/zero-HOLD behavior, 200-close warmup, finite masks, missing/unordered CORE5, malformed clocks, nonfinite history, prefix/weekly-state/future-suffix causality, immutable output, exact identities and 900 adversarial tier checks. Downward target weights imply downward unrounded absolute quantity at fixed positive prices/NAV; no native-order claim is made.

The launcher records observed Python I/O events and prohibits network/child-process starts or workspace data/archive reads. It allows standard temporary-directory cleanup opens whose audit event omits dir_fd. This observation is evidence about this generated test process, not an unbypassable sandbox for future callers. Logs and GENERATED_RECEIPT.json are author evidence only.

## Fixed future metadata, unchanged boundaries

FUTURE_CELL_MANIFEST30.json is a byte-exact copy of the finalized plan. It fixes two recipes × five periods × three tiers, ordered by source feasibility: 2023, 2024, 2025, partial 2021, 2022. Its first engineering slice has six 2023 descriptors; a future authorized LOW pilot would be one of the 30, never an extra rerun. All launch/reuse flags remain false.

All years are seen development. Partial 2021 remains April 2–December 31, 274 days, unannualized, with no continuous CAGR. Full 2022 needs a future separately qualified source retaining all 27 UNKNOWN carry cells and genuine recovery/anchor evidence; none is read, synthesized or qualified here. Keep 2024 causal-unknown provenance, 2023 zero-derived quality and genuine empty 2025 quality. Holdouts stay closed.

MASTER45 remains 45 actual D cells, including its 15 post-hoc STATIC/H090 duplicate groups. The old catalogue remains 555 statuses: 45 done and 510 not done. The 15 pure-CS COMMON cells are separate. The pre-existing six full-2023 legacy baselines used plain V3, not Guard50 D: zero D reuse and zero new D completion here.

PHASE_PLAN.json lists only the required future review/permission boundaries. No source/native/admission/pool/cache framework or financial stubs are provided. Any future source, admission or financial implementation/planning requires independent review and root GO. Existing old legacy/current core/CS files are not edited.

## Files

- legacy_signal.py: thin pure-signal wrapper and immutable output
- test_legacy_signal.py / run_generated_checks.py: generated tests and observed-run receipt
- ORIGINAL_SOURCE_PINMAP.json / pinned/: exact old adapter, original source/provenance and AST hashes
- INPUT_PLAN_PINS.json: finalized plan, 37-readiness, 30-cell and source-receipt identities
- FUTURE_CELL_MANIFEST30.json / PHASE_PLAN.json: metadata only
- GENERATED_TEST_LOG.txt / GENERATED_RECEIPT.json: author-generated results
- FILES.json / FINAL_SIGNAL_RECEIPT.json: final deliverable hashes
