"""Generated-only tests: no market/archive/model/raw-array reads or execution."""
import ast
from dataclasses import FrozenInstanceError
from datetime import date
import hashlib
import json
from pathlib import Path
import shutil
import sys
import tempfile
from types import ModuleType
import unittest

import numpy as np
import legacy_signal as a

OLD = a.HERE.parent / 'legacy_core_extension_20261015'


def reference():
    path = OLD / 'legacy_core_adapter.py'
    assert hashlib.sha256(path.read_bytes()).hexdigest() == '89d0add7439beb3e1f56bfae3a745aa0e74186717148208fe5a6c7219bf93e95'
    module = ModuleType('_legacy_intrinsic_D_test_reference')
    module.__file__ = str(path)
    sys.modules[module.__name__] = module
    exec(compile(path.read_bytes(), str(path), 'exec'), module.__dict__)
    # Compile pinned source directly, avoiding any pre-existing bytecode cache.
    loader = ModuleType('_legacy_intrinsic_D_direct_original_test_loader')
    loader_path = OLD / 'sources/original_functions.py'
    loader.__file__ = str(loader_path)
    exec(compile(loader_path.read_bytes(), str(loader_path), 'exec'), loader.__dict__)
    module._ORIGINALS = loader.load_originals(OLD / 'sources')
    return module


BASE = reference()


def fixture(n=285, mode='varied'):
    t=(19000+np.arange(n,dtype=np.int64))*a.DAY
    rng=np.random.default_rng(441209)
    changes=rng.normal(0,.007,(n,5))+np.array([.002,.001,-.0015,-.0007,.0003])
    p=100*np.exp(np.cumsum(changes,axis=0))
    if mode=='constant': p[:]=100.
    if mode=='ties': p[:,1]=p[:,0]; p[:,4]=p[:,3]
    if mode=='coarse': p=np.round(p*8)/8
    if mode=='same_return': p=np.repeat((100*np.exp(np.arange(n)*.001))[:,None],5,axis=1)
    return tuple(a.immutable_array(v) for v in (p,t,t[205:270]))


def ordinary(value):
    if isinstance(value,dict) or hasattr(value,'items'):
        return {key:ordinary(v) for key,v in value.items()}
    if isinstance(value,tuple): return [ordinary(v) for v in value]
    return value


def assert_exact(test, x, y):
    x,y=np.asarray(x),np.asarray(y)
    test.assertEqual(x.dtype.str,y.dtype.str)
    test.assertEqual(x.shape,y.shape)
    test.assertEqual(x.tobytes(),y.tobytes())


class CodePinsTests(unittest.TestCase):
    def test_exact_source_closure_and_AST_inventory(self):
        pins=a.verify_code_pins();self.assertEqual(len(pins['records']),10)
        math=a._legacy_math();math.verify_sources()
        self.assertEqual(set(vars(math.originals())),{'require','symbol_order','signed_risk_weights',
            'market_neutral','public_targets','signed_intents','match','scale','allocate'})
        for rec in pins['records']:
            self.assertEqual((a.HERE/rec['local_locator']).read_bytes(),Path(a.HERE.parent/rec['source_locator']).read_bytes())
        names=('Tier','lower_only','covariance_checked','_clock','build_target_grid','target_identities')
        old={n.name:ast.dump(n,include_attributes=False) for n in ast.parse((OLD/'legacy_core_adapter.py').read_bytes()).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
        new={n.name:ast.dump(n,include_attributes=False) for n in ast.parse((a.HERE/'pinned/legacy_core_adapter.py').read_bytes()).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
        for name in names:self.assertEqual(old[name],new[name])

    def _copy(self,tmp):
        dest=Path(tmp)/'case';shutil.copytree(a.HERE/'pinned',dest/'pinned')
        shutil.copy2(a.HERE/'ORIGINAL_SOURCE_PINMAP.json',dest)
        return dest

    def test_changed_original_code_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=self._copy(tmp);p=root/'pinned/sources/reference/match_core.py';p.write_bytes(p.read_bytes()+b'\n')
            with self.assertRaisesRegex(ValueError,'BYTES_CHANGED'):a.verify_code_pins(root)

    def test_changed_legacy_math_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=self._copy(tmp);p=root/'pinned/legacy_core_adapter.py';p.write_bytes(p.read_bytes()+b'\n')
            with self.assertRaisesRegex(ValueError,'BYTES_CHANGED'):a._legacy_math(root)

    def test_pinmap_mutation_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=self._copy(tmp);p=root/'ORIGINAL_SOURCE_PINMAP.json';p.write_bytes(p.read_bytes()+b' ')
            with self.assertRaisesRegex(ValueError,'PINMAP'):a.verify_code_pins(root)

    def test_missing_dependency_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=self._copy(tmp);(root/'pinned/sources/reference/portfolio.py').unlink()
            with self.assertRaisesRegex(ValueError,'ORDINARY'):a.verify_code_pins(root)

    def test_file_and_directory_symlinks_rejected(self):
        for directory in (False,True):
            with self.subTest(directory=directory),tempfile.TemporaryDirectory() as tmp:
                root=self._copy(tmp)
                p=root/('pinned/sources/reference' if directory else 'pinned/sources/reference/portfolio.py')
                target=Path(tmp)/'saved';p.rename(target);p.symlink_to(target,target_is_directory=directory)
                with self.assertRaisesRegex(ValueError,'ORDINARY'):a.verify_code_pins(root)

    def test_no_runner_financial_or_network_imports(self):
        denied=('polars','sklearn','subprocess','socket','native_runtime','cs_signal','guard50_exit')
        before=set(sys.modules)
        math=a._legacy_math();math.originals()
        newly_loaded=set(sys.modules)-before
        for name in denied:self.assertNotIn(name,newly_loaded)
        for name in ('polars','sklearn','native_runtime','cs_signal','guard50_exit'):
            self.assertNotIn(name,sys.modules)
        tree=ast.parse((a.HERE/'legacy_signal.py').read_bytes())
        imports=[n.module for n in ast.walk(tree) if isinstance(n,ast.ImportFrom)]
        imports += [v.name for n in ast.walk(tree) if isinstance(n,ast.Import) for v in n.names]
        self.assertFalse(any(any(d in imp for d in denied) for imp in imports if imp))
        self.assertFalse(any((a.HERE/x).exists() for x in ('legacy_source.py','legacy_entry.py','legacy_loader.py','legacy_admission.py','legacy_native.py','run_legacy.py')))


class ExactProjectionTests(unittest.TestCase):
    def test_exact_equivalence_all_tiers_and_generated_shapes(self):
        for mode in ('varied','constant','ties','coarse','same_return'):
            with self.subTest(mode=mode):
                p,t,d=fixture(mode=mode);result=a.build_generated_projection(p,t,t,d)
                bd,bw,bc,bp=BASE.build_target_grid(p,t,t,d)
                assert_exact(self,result.decisions,bd);assert_exact(self,result.covariance,bc)
                self.assertEqual(ordinary(result.proofs),bp)
                for recipe in a.RECIPES:
                    intrinsic=np.array([r['intrinsic'][recipe] for r in bp],dtype=np.float64)
                    assert_exact(self,result.intrinsic_original[recipe],intrinsic)
                for key,value in bw.items():assert_exact(self,result.downward_tiers[key],value)

    def test_complete_intrinsic_original_match_equation_before_caps(self):
        p,t,d=fixture();result=a.build_generated_projection(p,t,t,d)
        o=BASE.originals();end=int(np.searchsorted(t,d[-1]))+1
        gate=np.full((end,5),np.nan);gate[199:]=1.
        hold=o.signed_intents(p[:end],gate,t[:end],a.SYMBOLS)[np.searchsorted(t,d),2,:]
        parts,proof,_,diag=o.match(t[:end],p[:end],d,hold,np.ones((len(d),5),bool))
        assert_exact(self,result.intrinsic_original[a.RECIPES[0]],.5*parts['CS_MATCHED']+.5*parts['VOL_MATCHED'])
        assert_exact(self,result.intrinsic_original[a.RECIPES[1]],parts['VOL_MATCHED'])
        self.assertEqual([x['source_match'] for x in ordinary(result.proofs)],proof)
        self.assertEqual([x['CS_weekly_rank_us'] for x in result.proofs],diag['rank_us'])
        self.assertTrue(np.any(parts['CS_ORIGINAL']<0))
        self.assertTrue(np.any(parts['VOL_ORIGINAL']!=parts['VOL_MATCHED']))
        self.assertNotIn('short_confirmation',diag)
        self.assertFalse(o.public_targets.__kwdefaults__['short_absolute_confirmation'])

    def test_200_close_warmup_exact_boundary(self):
        p,t,_=fixture();a.build_generated_projection(p,t,t,t[199:202])
        for k in (31,63,198):
            with self.assertRaisesRegex(ValueError,'200_COMPLETED'):a.build_generated_projection(p,t,t,t[k:k+2])

    def test_explicit_finite_mask_only_not_hold_direction_gate(self):
        p,t,d=fixture();mask=np.ones(p.shape,bool)
        r=a.build_generated_projection(p,t,t,d,sma_finite_mask=mask)
        old=BASE.build_target_grid(p,t,t,d,sma_finite_mask=mask)
        for k,v in old[1].items():assert_exact(self,r.downward_tiers[k],v)
        mask[205,2]=False
        with self.assertRaisesRegex(ValueError,'SMA_FINITE'):a.build_generated_projection(p,t,t,d,sma_finite_mask=mask)
        with self.assertRaisesRegex(ValueError,'BOOLEAN'):a.build_generated_projection(p,t,t,d,sma_finite_mask=mask.astype(int))

    def test_original_zero_CS_matching_controls_HOLD_cash(self):
        p,t,d=fixture(mode='same_return');r=a.build_generated_projection(p,t,t,d)
        for values in r.intrinsic_original.values():self.assertTrue(np.all(values==0))
        self.assertTrue(all(x['source_match']['common_sigma']==0 for x in r.proofs))
        hold=BASE.originals().signed_intents(p,np.ones(p.shape),t,a.SYMBOLS)[np.searchsorted(t,d),2,:]
        self.assertTrue(np.any(hold!=0))

    def test_original_zero_HOLD_matching_controls_both(self):
        p,t,d=fixture();zero=np.zeros((len(d),5));ready=np.ones(zero.shape,bool)
        o=a._legacy_math().originals();parts,proof,_,_=o.match(t,p,d,zero,ready)
        self.assertTrue(np.any(parts['CS_ORIGINAL']!=0))
        for key in ('CS_MATCHED','VOL_MATCHED'):self.assertTrue(np.all(parts[key]==0))
        self.assertTrue(all(x['common_sigma']==0 for x in proof))

    def test_constant_zero_variance_original_semantics(self):
        p,t,d=fixture(mode='constant');r=a.build_generated_projection(p,t,t,d)
        self.assertTrue(np.all(r.covariance==0))
        for value in r.downward_tiers.values():self.assertTrue(np.all(value==0))

    def test_future_suffix_influence_absent(self):
        p,t,d=fixture();r=a.build_generated_projection(p,t,t,d)
        changed=p.copy();cut=240;changed[cut:]*=np.exp(np.linspace(.1,2,len(p)-cut))[:,None]
        s=a.build_generated_projection(changed,t,t,d);keep=d<t[cut]
        for key in r.downward_tiers:assert_exact(self,r.downward_tiers[key][keep],s.downward_tiers[key][keep])
        for key in r.intrinsic_original:assert_exact(self,r.intrinsic_original[key][keep],s.intrinsic_original[key][keep])
        assert_exact(self,r.covariance[keep],s.covariance[keep])
        self.assertEqual(ordinary(r.proofs[:sum(keep)]),ordinary(s.proofs[:sum(keep)]))
        self.assertTrue(any(np.any(r.downward_tiers[k][~keep]!=s.downward_tiers[k][~keep]) for k in r.downward_tiers))

    def test_invalid_strict_future_suffix_ignored(self):
        p,t,d=fixture();d=d[:12];r=a.build_generated_projection(p,t,t,d)
        changed=p.copy();changed[np.searchsorted(t,d[-1])+1:]=np.nan
        s=a.build_generated_projection(changed,t,t,d)
        for k in r.downward_tiers:assert_exact(self,r.downward_tiers[k],s.downward_tiers[k])
        self.assertEqual(ordinary(r.proofs),ordinary(s.proofs))

    def test_prefix_matches_longer_decision_window(self):
        p,t,d=fixture();r=a.build_generated_projection(p,t,t,d[:17]);s=a.build_generated_projection(p,t,t,d)
        for k in r.downward_tiers:assert_exact(self,r.downward_tiers[k],s.downward_tiers[k][:17])
        self.assertEqual(ordinary(r.proofs),ordinary(s.proofs[:17]))

    def test_period_start_preserves_weekly_rank_state(self):
        p,t,d=fixture();r=a.build_generated_projection(p,t,t,d)
        for start in (1,2,5,11):
            tail=a.build_generated_projection(p,t,t,d[start:])
            for k in r.downward_tiers:assert_exact(self,r.downward_tiers[k][start:],tail.downward_tiers[k])
            # rank_events metadata differs by selected window; per-decision source proofs do not.
            self.assertEqual(ordinary(r.proofs[start:]),ordinary(tail.proofs))

    def test_malformed_CORE5_inputs_and_calendar_fail_closed(self):
        p,t,d=fixture()
        cases=[(p,t,t,d,{'symbols':a.SYMBOLS[::-1]}),(p[:,:4],t,t,d,{}),
               (p,t,t,d,{'symbols':a.SYMBOLS[:-1]}),(p,t,t+a.DAY,d,{}),
               (p,t.astype(float),t,d,{}),(p,t,t,d[::2],{}),(p,t,t,d.astype(bool),{}),
               (p,t,t,d[::-1],{}),(p,t,t,np.array([],dtype=np.int64),{})]
        for args in cases:
            with self.subTest(case=str(args[4])),self.assertRaises(ValueError):a.build_generated_projection(*args[:4],**args[4])
        for value in (np.nan,np.inf,0.,-1.):
            changed=p.copy();changed[20,1]=value
            with self.subTest(value=value),self.assertRaises(ValueError):a.build_generated_projection(changed,t,t,d)
        broken=t.copy();broken[220]+=1
        with self.assertRaises(ValueError):a.build_generated_projection(p,broken,broken,d)

    def test_immutable_inputs_and_results_and_no_mutation(self):
        p,t,d=fixture();before=(p.tobytes(),t.tobytes(),d.tobytes());r=a.build_generated_projection(p,t,t,d)
        self.assertEqual(before,(p.tobytes(),t.tobytes(),d.tobytes()))
        for array in (p,t,d,r.decisions,r.covariance,*r.intrinsic_original.values(),*r.downward_tiers.values()):
            self.assertFalse(array.flags.writeable)
            with self.assertRaises(ValueError):array.setflags(write=True)
        with self.assertRaises(TypeError):r.intrinsic_original['new']=None
        with self.assertRaises(TypeError):r.proofs[0]['source_match']['common_sigma']=123
        with self.assertRaises(TypeError):r.provenance['source_admitted']=True
        with self.assertRaises(FrozenInstanceError):r.decisions=None
        self.assertFalse(r.provenance['source_admitted']);self.assertFalse(r.provenance['financial_authorized'])
        self.assertFalse(r.provenance['native_D_conformity_proved'])


class LowerOnlyTests(unittest.TestCase):
    def test_every_tier_exact_legacy_equivalence_and_coarse_ULP_edges(self):
        weights=[np.zeros(5),np.array([.15,-.15,0,0,0]),np.full(5,.12),
                 np.array([np.nextafter(.30,np.inf),0,0,0,0]),
                 np.array([np.nextafter(.15,0),np.nextafter(-.15,-np.inf),0,0,0])]
        for w in weights:
            for c in (np.zeros((5,5)),np.eye(5)*.01,np.eye(5)*2,np.ones((5,5))):
                for name,_,_,_ in a.TIER_CEILINGS:
                    out,pf=a.lower_only(w,c,name);bo,bp=BASE.lower_only(w,c,name)
                    assert_exact(self,out,bo);self.assertEqual(ordinary(pf),bp)
                    self.assertTrue(np.all(np.abs(out)<=np.abs(w)))
                    self.assertLessEqual(np.abs(out).sum(),np.abs(w).sum())
                    self.assertLessEqual(pf['factor'],1.)

    def test_generated_adversarial_300_weights_three_tiers_downward_only(self):
        rng=np.random.default_rng(991747)
        math=a._legacy_math()
        for _ in range(300):
            w=rng.uniform(-1,1,5);w*=rng.uniform(0,.6)/np.abs(w).sum()
            w*=min(1.,.3/max(np.abs(w)))
            w[rng.integers(0,5)]=0
            z=rng.normal(size=(5,5));c=z@z.T*rng.uniform(0,10)
            for name,gross,vol,asset in a.TIER_CEILINGS:
                # The pinned legacy AST is the same primitive used by the public wrapper.
                out,pf=math.lower_only(w,c,name);f=pf['factor']
                self.assertTrue(0<=f<=1);self.assertTrue(np.all(np.abs(out)<=np.abs(w)))
                self.assertLessEqual(np.abs(out).sum(),np.abs(w).sum())
                self.assertTrue(np.all(out[w==0]==0));self.assertTrue(np.all(np.sign(out)==np.sign(w)))
                self.assertLessEqual(np.abs(out).sum(),gross+1e-12)
                self.assertLessEqual(max(np.abs(out)),asset+1e-12)
                self.assertLessEqual(pf['post_sigma'],vol+1e-12)
                self.assertLessEqual(pf['post_sigma'],pf['raw_sigma']+1e-12)
                # Exact uniform scaling proves no absolute quantity expansion for any fixed NAV/price.
                expected=w.copy() if f==1 else w*f;assert_exact(self,out,expected)
                for price in (1.,2.,128.):
                    self.assertTrue(np.all(np.abs(out)*10000/price<=np.abs(w)*10000/price))

    def test_smaller_intrinsic_caps_cash_and_singular_risk_retained(self):
        for w,c in ((np.array([.02,.03,-.01,0,.02]),np.eye(5)*.01),
                    (np.array([.15,-.15,0,0,0]),np.ones((5,5))),
                    (np.zeros(5),np.zeros((5,5)))):
            for name,_,_,_ in a.TIER_CEILINGS:
                out,pf=a.lower_only(w,c,name);assert_exact(self,out,w)
                self.assertEqual(pf['factor'],1.);self.assertFalse(pf['reexpanded'])

    def test_no_1_ULP_shrink_rounded_back_to_one(self):
        w=np.array([np.nextafter(.30,np.inf),0,0,0,0]);out,pf=a.lower_only(w,np.eye(5)*.001,'HIGH')
        self.assertLess(pf['factor'],1.);self.assertLess(out[0],w[0]);self.assertEqual(out[0],.3)

    def test_bad_covariance_intent_tier_preserves_old_rejection(self):
        nonsym=np.eye(5);nonsym[0,1]=.01
        for c in (-np.eye(5),np.zeros((4,4)),np.full((5,5),np.nan),nonsym):
            with self.assertRaises(ValueError):a.lower_only(np.full(5,.1),c,'MID')
        for w in (np.full(5,.2),np.ones(4),np.array([.31,0,0,0,0]),np.full(5,np.nan)):
            with self.assertRaises(ValueError):a.lower_only(w,np.eye(5),'MID')
        with self.assertRaises(ValueError):a.lower_only(np.zeros(5),np.eye(5),'CUSTOM')


class IdentityAndManifestTests(unittest.TestCase):
    def test_exact_identity_distinguishes_ULP_endian_dtype_shape_clock(self):
        w=np.array([[.1,.2,0,0,0]],dtype='<f8');identity=a.array_byte_identity(w)
        changed=w.copy();changed[0,0]=np.nextafter(changed[0,0],np.inf)
        for value in (changed,w.astype('>f8'),w.astype('<f4'),w.reshape(5)):
            self.assertNotEqual(identity['descriptor_and_bytes_SHA256'],a.array_byte_identity(value)['descriptor_and_bytes_SHA256'])
        clocks=np.array([19000*a.DAY],dtype=np.int64)
        self.assertNotEqual(a.array_byte_identity(clocks),a.array_byte_identity(clocks+a.DAY))
        with self.assertRaises(ValueError):a.array_byte_identity(np.array(['a'],dtype=object))

    def test_equal_targets_remain_distinct_tier_contexts_without_reuse(self):
        p,t,d=fixture();r=a.build_generated_projection(p,t,t,d)
        key=a.RECIPES[0];mid=r.downward_tiers[key+'_MID'];high=r.downward_tiers[key+'_HIGH']
        assert_exact(self,mid,high)
        self.assertNotEqual(a.TIER_CEILINGS[1],a.TIER_CEILINGS[2])
        self.assertFalse(r.provenance['execution_reuse_authorized'])
        self.assertTrue(r.provenance['same_target_bytes_do_not_prove_execution_identity'])

    def test_30_cell_manifest_byte_equal_to_frozen_plan(self):
        path=a.HERE/'FUTURE_CELL_MANIFEST30.json';original=a.HERE.parent/'overnight_legacy_variant_queue_plan_20261015/NEXT_TRANCHE30.json'
        self.assertEqual(path.read_bytes(),original.read_bytes())
        v=json.loads(path.read_bytes());rows=v['rows'];self.assertEqual(len(rows),30)
        self.assertEqual([r['queue_ordinal'] for r in rows],list(range(1,31)))
        self.assertEqual(len({r['proposed_cell_id'] for r in rows}),30)
        self.assertEqual([rows[i]['year'] for i in range(0,30,6)],[2023,2024,2025,2021,2022])
        for row in rows:
            self.assertIn(row['registry_variant_id'],a.RECIPES)
            self.assertIn(row['tier'],[x[0] for x in a.TIER_CEILINGS])
            self.assertFalse(row['financial_launch_authorized']);self.assertFalse(row['financial_reuse_allowed_now'])
            self.assertEqual((date.fromisoformat(row['end_exclusive_UTC'])-date.fromisoformat(row['start_inclusive_UTC'])).days,row['days'])
            self.assertEqual(row['days'],274 if row['year']==2021 else 366 if row['year']==2024 else 365)
        self.assertEqual(v['sequential_first_pilot'],rows[0]['proposed_cell_id'])
        self.assertEqual(v['first_small_period_slice'],[r['proposed_cell_id'] for r in rows[:6]])
        self.assertEqual(v['finance_reuse_proved_cells'],0)

    def test_phase_plan_contains_no_source_or_financial_authority(self):
        v=json.loads((a.HERE/'PHASE_PLAN.json').read_bytes())
        for key in ('source_admission_implemented','financial_entry_implemented','provider_or_cache_framework_implemented'):
            self.assertFalse(v[key])
        for key in ('runnable_financial_cells','actual_data_reads','actual_target_generations','financial_runs','new_D_completion'):
            self.assertEqual(v[key],0)
        self.assertEqual(v['master45_unchanged'],45)


if __name__=='__main__':unittest.main()
