"""Pinned original intrinsic recipe math plus downward-only GENERATED projections.

This module has no market reader, provider, account, native constructor, source
admission, financial authority or launcher. Caller-supplied arrays are only pure
math inputs, never evidence of admitted historical data. See README.md.
"""
from __future__ import annotations

import ast
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import sys
from types import MappingProxyType, ModuleType
from collections.abc import Mapping

import numpy as np

HERE = Path(__file__).absolute().parent
VERSION = 'LEGACY_INTRINSIC_D_PURE_SIGNAL_GENERATED_V1'
PINMAP_SHA256 = 'da168e84e33ac5f9607eb56aea45554de12e1991137a4cdceec9c83a98fe5287'
DAY = 86_400_000_000
SYMBOLS = ('BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'XRPUSDT', 'DOGEUSDT')
RECIPES = ('STATIC50_OLD_NO_REEXPANSION', 'HOLD_CORE5_VOL_MATCHED_NOREEXP')
TIER_CEILINGS = (('LOW', .30, .05, .30), ('MID', .60, .10, .30), ('HIGH', .90, .15, .30))


def _sha(raw):
    return hashlib.sha256(raw).hexdigest()


def _ordinary_file(path):
    if path.is_symlink() or any(p.is_symlink() for p in path.parents) or not path.is_file():
        raise ValueError('ORDINARY_PINNED_CODE_FILE_REQUIRED:' + str(path))
    return path.read_bytes()


def verify_code_pins(root=HERE):
    """Read literal local Python/metadata only; reject changed/missing/symlink code."""
    root = Path(root).absolute()
    raw = _ordinary_file(root / 'ORIGINAL_SOURCE_PINMAP.json')
    if _sha(raw) != PINMAP_SHA256:
        raise ValueError('EXACT_ORIGINAL_CODE_PINMAP_REQUIRED')
    pinmap = json.loads(raw)
    for record in pinmap['records']:
        rel = Path(record['local_locator'])
        if rel.is_absolute() or '..' in rel.parts or rel.parts[0] != 'pinned':
            raise ValueError('PINNED_CODE_PATH_NAMESPACE_REQUIRED')
        data = _ordinary_file(root / rel)
        blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        if (len(data) != record['bytes'] or _sha(data) != record['SHA256']
                or blob != record['GitBlobSHA1']):
            raise ValueError('EXACT_PINNED_CODE_BYTES_CHANGED:' + str(rel))
    return pinmap


def _legacy_math(root=HERE):
    """Extract unchanged legacy implementation AST; never import research runners.

    Only HERE is supplied for the private pinned snapshot. All original function,
    class, default and constant ASTs remain unchanged. This fresh namespace is
    not a source/admission cache and cannot hold an execution scope.
    """
    root = Path(root).absolute()
    verify_code_pins(root)
    path = root / 'pinned/legacy_core_adapter.py'
    tree = ast.parse(_ordinary_file(path), filename=str(path))
    body = [node for node in tree.body if not (
        isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'HERE'
                                             for t in node.targets))]
    name = '_legacy_intrinsic_D_exact_math'
    module = ModuleType(name)
    module.__dict__.update(HERE=root / 'pinned', __file__=str(path))
    previous = sys.modules.get(name)
    sys.modules[name] = module
    try:
        exec(compile(ast.Module(body=body, type_ignores=[]), str(path), 'exec'), module.__dict__)
    finally:
        if previous is None:
            sys.modules.pop(name, None)
        else:
            sys.modules[name] = previous
    # Preload the exact original AST closure directly from pinned source bytes.
    # The unchanged originals() then uses its existing private namespace, never
    # an unpinned pre-existing .pyc accepted by importlib's timestamp fast path.
    loader_path = root / 'pinned/sources/original_functions.py'
    loader = ModuleType('_legacy_intrinsic_D_exact_original_loader')
    loader.__file__ = str(loader_path)
    exec(compile(_ordinary_file(loader_path), str(loader_path), 'exec'), loader.__dict__)
    module._ORIGINALS = loader.load_originals(root / 'pinned/sources')
    return module


def immutable_array(value):
    """C-order byte-owned view; WRITEABLE cannot be re-enabled by the caller."""
    value = np.asarray(value)
    if value.dtype.hasobject:
        raise ValueError('NUMERIC_OR_BOOLEAN_ARRAY_REQUIRED')
    return np.frombuffer(value.tobytes(order='C'), dtype=value.dtype).reshape(value.shape)


def _freeze(value):
    if isinstance(value, Mapping):
        return MappingProxyType({key: _freeze(item) for key, item in value.items()})
    if isinstance(value, (tuple, list)):
        return tuple(_freeze(item) for item in value)
    if isinstance(value, np.ndarray):
        return immutable_array(value)
    return value


def array_byte_identity(value):
    """Exact dtype/endian/shape/raw bytes; never an approximate or execution alias."""
    value = np.asarray(value)
    if value.dtype.hasobject:
        raise ValueError('NUMERIC_OR_BOOLEAN_ARRAY_REQUIRED')
    descriptor = dict(dtype=value.dtype.str, shape=list(value.shape), order='C')
    header = json.dumps(descriptor, sort_keys=True, separators=(',', ':')).encode()
    return dict(**descriptor, raw_bytes_SHA256=_sha(value.tobytes(order='C')),
                descriptor_and_bytes_SHA256=_sha(header+b'\0'+value.tobytes(order='C')))


@dataclass(frozen=True)
class GeneratedProjection:
    """Immutable pure-math output, with original intrinsic and tiers separate."""
    decisions: np.ndarray
    intrinsic_original: Mapping
    downward_tiers: Mapping
    covariance: np.ndarray
    proofs: tuple
    provenance: Mapping


def lower_only(weight, covariance, tier_name):
    """Exact legacy lower_only AST, including its pre-existing zero-risk policy."""
    out, proof = _legacy_math().lower_only(weight, covariance, tier_name)
    return immutable_array(out), _freeze(proof)


def build_generated_projection(close, close_us, available_us, decisions, *,
                               symbols=SYMBOLS, sma_finite_mask=None):
    """Apply unchanged legacy math to caller arrays for GENERATED engineering use.

    No data is read here beyond pinned source-code files. A Python call does not
    establish that arrays are synthetic or historically qualified. Historical
    application remains unauthorized and needs separate future reviewed code.
    The optional SMA input is exactly the old finite-readiness mask, not a new
    HOLD trend rule or absolute short confirmation.
    """
    math = _legacy_math()
    clocks, targets, covariance, proofs = math.build_target_grid(
        close, close_us, available_us, decisions, symbols=symbols,
        sma_finite_mask=sma_finite_mask)
    intrinsic = {recipe: np.array([row['intrinsic'][recipe] for row in proofs], dtype=np.float64)
                 for recipe in RECIPES}
    target_ids = {key: array_byte_identity(value) for key, value in targets.items()}
    provenance = dict(version=VERSION, stage='GENERATED_PURE_MATH_ONLY',
        source_code_pinmap_SHA256=PINMAP_SHA256,
        original_legacy_adapter_version=math.VERSION,
        source_recipe_order=RECIPES, symbols=SYMBOLS,
        tier_ceilings=TIER_CEILINGS,
        decisions=array_byte_identity(clocks), covariance=array_byte_identity(covariance),
        intrinsic_original={key: array_byte_identity(value) for key, value in intrinsic.items()},
        downward_tiers=target_ids,
        same_target_bytes_do_not_prove_execution_identity=True,
        source_admitted=False, financial_authorized=False, native_D_conformity_proved=False,
        execution_reuse_authorized=False,
        historical_source_qualification='NOT_ESTABLISHED_BY_PURE_MATH')
    return GeneratedProjection(immutable_array(clocks), _freeze(intrinsic), _freeze(targets),
                               immutable_array(covariance), _freeze(proofs), _freeze(provenance))
