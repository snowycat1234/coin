"""Run generated-only author checks, with an observed Python I/O boundary log.

This test launcher has no historical case entry and grants no authority. It runs
only local generated unit tests. The audit hook is evidence for this process,
not a security sandbox or proof about future callers of the pure math function.
"""
from pathlib import Path
import hashlib
import json
import os
import sys
import time
import unittest

HERE=Path(__file__).absolute().parent
WORKSPACE=HERE.parent
OLD=WORKSPACE/'legacy_core_extension_20261015'
PLAN=WORKSPACE/'overnight_legacy_variant_queue_plan_20261015'
allowed_old={OLD/'legacy_core_adapter.py',OLD/'SOURCE_PINS.json',OLD/'sources/ORIGINAL_REFERENCE.json',
             OLD/'sources/original_functions.py',*(OLD/'sources/reference'/x for x in (
             'public_sma_perpetual.py','public_cross_section_momentum.py','match_core.py',
             'joint_expert_information.py','risk_budget.py','portfolio.py'))}
allowed_plan={PLAN/'NEXT_TRANCHE30.json'}
observed=dict(network_calls=0,process_starts=0,rejected_noncode_read_attempts=0,
              actual_source_applications=0,financial_account_constructions=0,
              rejected_events=[],workspace_read_paths=set(),relative_cleanup_directory_opens=0)


def audit(event,args):
    if event.startswith('socket.') or event in ('urllib.Request','http.client.connect'):
        observed['network_calls']+=1;observed['rejected_events'].append(event)
        raise RuntimeError('GENERATED_TEST_NETWORK_PROHIBITED:'+event)
    if event in ('subprocess.Popen','os.system','os.posix_spawn','os.exec','os.fork'):
        observed['process_starts']+=1;observed['rejected_events'].append(event)
        raise RuntimeError('GENERATED_TEST_PROCESS_PROHIBITED:'+event)
    if event=='open' and args and isinstance(args[0],(str,bytes,os.PathLike)):
        raw_path=Path(os.fsdecode(args[0]))
        mode=args[1] if len(args)>1 else None
        flags=args[2] if len(args)>2 else 0
        # shutil's fd-relative temporary-directory cleanup opens directory names
        # with O_NONBLOCK. The audit event omits dir_fd; no file bytes are read.
        if not raw_path.is_absolute() and isinstance(flags,int) and flags & os.O_NONBLOCK:
            observed['relative_cleanup_directory_opens']+=1
            return
        path=raw_path.absolute()
        writing=(isinstance(mode,str) and any(x in mode for x in 'wax+')) or (isinstance(flags,int) and flags & (os.O_WRONLY|os.O_RDWR))
        if path.is_relative_to(WORKSPACE):
            if writing:
                if not path.is_relative_to(HERE):
                    observed['rejected_events'].append('workspace_write:'+str(path))
                    raise RuntimeError('OUTSIDE_NEW_FOLDER_WRITE_PROHIBITED')
            else:
                observed['workspace_read_paths'].add(str(path.relative_to(WORKSPACE)))
                if not (path.is_relative_to(HERE) or path in allowed_old or path in allowed_plan):
                    observed['rejected_noncode_read_attempts']+=1
                    observed['rejected_events'].append('workspace_read:'+str(path))
                    raise RuntimeError('OUTSIDE_CODE_METADATA_READ_PROHIBITED:'+str(path))
                if path.suffix in ('.npy','.npz','.parquet','.csv','.pkl','.pickle','.gz','.zip'):
                    observed['rejected_noncode_read_attempts']+=1
                    raise RuntimeError('ACTUAL_ARRAY_ARCHIVE_READ_PROHIBITED')


sys.addaudithook(audit)
started=time.monotonic()
suite=unittest.defaultTestLoader.discover(str(HERE),pattern='test_legacy_signal.py')
result=unittest.TextTestRunner(verbosity=2).run(suite)
import legacy_signal as signal
import numpy as np
from test_legacy_signal import fixture, ordinary
synthetic=[]
for mode in ('varied','constant','ties','coarse','same_return'):
    p,t,d=fixture(mode=mode)
    projection=signal.build_generated_projection(p,t,t,d)
    synthetic.append(dict(mode=mode,fixture='DETERMINISTIC_GENERATED_NO_MARKET_READ',
        close=signal.array_byte_identity(p),close_clock=signal.array_byte_identity(t),
        provenance=ordinary(projection.provenance)))
(HERE/'GENERATED_SYNTHETIC_SIGNAL_IDENTITIES.json').write_text(json.dumps(synthetic,indent=2)+'\n')
receipt=dict(schema='LEGACY_INTRINSIC_D_SIGNAL_GENERATED_AUTHOR_RECEIPT_V1',
    status='PASS_AUTHOR_GENERATED_ONLY_NOT_INDEPENDENT_REVIEW' if result.wasSuccessful() else 'FAIL',
    version=signal.VERSION,tests_run=result.testsRun,failures=len(result.failures),errors=len(result.errors),
    generated_adversarial_weights=300,generated_adversarial_tier_checks=900,
    exact_original_legacy_projection_modes=['varied','constant','ties','coarse','same_return'],
    elapsed_seconds=round(time.monotonic()-started,6),
    CPU_affinity=sorted(os.sched_getaffinity(0)),
    numerical_pool_environment={key:os.environ.get(key) for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS')},
    python_version=sys.version.split()[0],numpy_version=np.__version__,
    actual_data_reads=0,actual_target_generations=0,provider_iterations=0,account_constructions=0,
    native_history_runs=0,financial_runs=0,financial_GO_minted=0,source_admissions_minted=0,
    market_downloads=0,network_requests=observed['network_calls'],child_process_starts=observed['process_starts'],
    publication=False,new_D_completed=0,MASTER45=45,old555_done=45,old555_not_done=510,
    original_code_pinmap_SHA256=signal.PINMAP_SHA256,
    code_SHA256={name:hashlib.sha256((HERE/name).read_bytes()).hexdigest() for name in
        ('legacy_signal.py','test_legacy_signal.py','run_generated_checks.py','PHASE_PLAN.json','FUTURE_CELL_MANIFEST30.json','INPUT_PLAN_PINS.json')},
    observed_Python_audit={**observed,'workspace_read_paths':sorted(observed['workspace_read_paths'])},
    limitations=['Author-generated tests only; independent review pending.',
      'I/O audit is observed Python events in this process, not an unbypassable sandbox.',
      'Pure math accepts caller arrays; their historical qualification is not established.',
      'Audit paths include attempted import-cache opens; original recipe execution compiles verified source directly.',
      'No original-native or current-D execution conformity is proved by pure signal math.'])
(HERE/'GENERATED_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
raise SystemExit(0 if result.wasSuccessful() else 1)
