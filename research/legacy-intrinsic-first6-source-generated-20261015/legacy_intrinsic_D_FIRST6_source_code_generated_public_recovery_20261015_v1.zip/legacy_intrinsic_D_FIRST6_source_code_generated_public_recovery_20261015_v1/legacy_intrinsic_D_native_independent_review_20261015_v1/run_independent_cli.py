"""Nine isolated real-CLI tests with explicitly fake source/storage/native seams."""
import json,os,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent;MODULE=ROOT/'legacy_intrinsic_D_native_20261015_v1';OUT=Path(__file__).resolve().parent
os.sched_setaffinity(0,{6});sys.path.insert(0,str(MODULE))
import legacy_bootstrap
import legacy_source_entry as entry
cases=[('positive_cell'+str(i),'positive',cell) for i,cell in enumerate(entry.tranche_cells(entry.FIRST6),1)]+[(mode,mode,entry.tranche_cells(entry.FIRST6)[0]) for mode in ('capture_failure','loaded_validation_failure','guard_exit_failure')]
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',**{key:'1' for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','POLARS_MAX_THREADS','VECLIB_MAXIMUM_THREADS','BLIS_NUM_THREADS')})
reports=[]
for name,mode,cell in cases:
    began=time.monotonic();p=subprocess.run([sys.executable,'-B',str(MODULE/'test_worker_integration.py'),mode,cell],cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=120)
    (OUT/('CLI_'+name+'.stdout')).write_text(p.stdout);(OUT/('CLI_'+name+'.stderr')).write_text(p.stderr)
    if p.returncode:raise RuntimeError((name,p.returncode,p.stderr))
    result=json.loads(p.stdout)
    assert result['status']=='PASS_REAL_FRESH_CLI_GENERATED_EXECUTABLE_GO_UNCHANGED_GUARD'
    assert not any(result[k] for k in ('actual_source_reads','actual_source_scopes','historical_scopes','providers','accounts','claims'))
    assert result['runtime_generated_bypass_present'] is False
    reports.append(dict(name=name,cell=cell,result=result,elapsed_seconds=time.monotonic()-began))
(OUT/'INDEPENDENT_REAL_CLI_RECEIPT.json').write_text(json.dumps(dict(status='PASS',scenarios=reports,CPU_affinity=sorted(os.sched_getaffinity(0)),actual_source_reads=0,actual_source_scopes=0,historical_scopes=0,providers=0,accounts=0,actual_claims=0,actual_financial_GO_issued=0,generated_fake_authorities_only=True),sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(status='PASS',scenarios=len(reports),CPU_affinity=sorted(os.sched_getaffinity(0)))))
