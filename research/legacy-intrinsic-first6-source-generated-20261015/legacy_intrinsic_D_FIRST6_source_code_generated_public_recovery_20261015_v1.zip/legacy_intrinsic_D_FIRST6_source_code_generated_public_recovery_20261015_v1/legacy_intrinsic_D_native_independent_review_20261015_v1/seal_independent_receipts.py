"""Seal exact independent reviews only; never create a financial root GO."""
import json,os,sys
from pathlib import Path
from hashlib import sha256
ROOT=Path(__file__).resolve().parent.parent;MODULE=ROOT/'legacy_intrinsic_D_native_20261015_v1';OUT=Path(__file__).resolve().parent
os.sched_setaffinity(0,{6});sys.path.insert(0,str(MODULE))
import legacy_bootstrap,legacy_finance_gate as gate,legacy_native_common as c

def store(name,value):
    path=OUT/name;raw=(json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
    with path.open('xb') as stream:stream.write(raw);stream.flush();os.fsync(stream.fileno())
    path.chmod(0o444)
    return raw,dict(path=str(path.relative_to(ROOT)),SHA256=sha256(raw).hexdigest(),bytes=len(raw))
assert gate.code_identity()=='9bdae8ee2af3de16c457d8b79a06d012da587d1dcaf23cf313fe893def7c463d'
probe='8af9c2afb09713762af3165d545e61d2d44f355ffdd741b90ca1e91bcedf01e7'
for name in ('FINAL_CHECKPOINT_AND_PROBE_AUDIT.json','REFRESH_AND_HANDOFF_AUDIT.json','INDEPENDENT_REAL_CLI_RECEIPT.json','FINANCIAL_GENERATED_TEST_RECEIPT.json','INDEPENDENT_ADDITIONAL_SEAMS.json'):
    assert json.loads((OUT/name).read_bytes())['status']=='PASS',name
native_raw,native_pin=store('INDEPENDENT_NATIVE_GENERATED_ADMISSION_REVIEW.json',gate.native_policy(probe))
gate.native_review(native_raw,native_pin['SHA256'])
prep=(ROOT/'legacy_intrinsic_D_20261015_v1/source_attempts/FIRST6_2023_attempt001/PREPARATION.json').read_bytes()
assert sha256(prep).hexdigest()=='e162ec6a039ba43ff302f55601e589d0508de17fc8077d3a7e3fa895ce302edc'
financial=gate.review_policy(prep,'d045ce2502f384a6414636ccf7136b5cfb29e26db6f9749c522a2ee27e08d1fb',native_pin['SHA256'])
financial_raw,financial_pin=store('INDEPENDENT_FINANCIAL_ADMISSION_REVIEW.json',financial)
assert c.canonical(c.exact_object(financial_raw))==c.canonical(financial)
print(json.dumps(dict(status='PASS_EXACT_NONAUTHORIZING_INDEPENDENT_RECEIPTS',native=native_pin,financial=financial_pin,actual_financial_GO_issued=0),sort_keys=True))
