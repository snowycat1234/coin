"""Code/metadata + saved synthetic probe verification only, no historical arrays."""
from pathlib import Path
from hashlib import sha256
import json,os,sys
ROOT=Path(__file__).resolve().parent.parent;MODULE=ROOT/'legacy_intrinsic_D_native_20261015_v1';OUT=Path(__file__).resolve().parent
os.sched_setaffinity(0,{6});sys.path.insert(0,str(MODULE))
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','POLARS_MAX_THREADS','VECLIB_MAXIMUM_THREADS','BLIS_NUM_THREADS'):os.environ[k]='1'
import legacy_bootstrap,legacy_finance_gate as gate,legacy_process_runtime as runtime
import profile_legacy_generated as profile

def read(path):
    assert path.suffix in ('.py','.md','.json','.txt','.log','.lock'),str(path)
    return path.read_bytes()
def pin(path):
    raw=read(path);return dict(path=str(path.relative_to(ROOT)),SHA256=sha256(raw).hexdigest(),bytes=len(raw))
def exact(path,expected):
    p=pin(path);assert {k:p[k] for k in ('SHA256','bytes')}==expected,(p,expected)
manifest_path=MODULE/'FINANCIAL_CODE_MANIFEST.json';manifest=json.loads(read(manifest_path))
assert sha256(read(manifest_path)).hexdigest()=='9bdae8ee2af3de16c457d8b79a06d012da587d1dcaf23cf313fe893def7c463d'
for name,want in manifest['files'].items():exact(MODULE/name,want)
for name,want in manifest['dependencies'].items():exact(ROOT/name,want)
assert gate.code_identity()==sha256(read(manifest_path)).hexdigest()
assert sha256(read(ROOT/'legacy_intrinsic_D_20261015_v1/CODE_MANIFEST.json')).hexdigest()==gate.SOURCE_CODE_SHA256
assert not any('/EXECUTION_CLAIMS/' in p or 'FAILED_ATTEMPT' in p or 'SUPERSESSION' in p for p in manifest['dependencies'])
for p in manifest['dependencies']:
    if p.startswith('original_cs_'):assert p.startswith('original_cs_mom21_D_20261015_v4/') and p.endswith(('CODE_MANIFEST.json','FINANCIAL_CODE_MANIFEST.json','SOURCE_CONTRACT_MAP.json','cs_codec.py','cs_source.py','cs_source_guard.py')),p
assert manifest['dependencies']['cs_saved_minute_reporting_repair_20261015_v2/bounded_drain.py']['SHA256']=='226b1efc7ebe0b4b607b34237240a75a9a6823a74a39345158e18b4abdeced3a'
assert manifest['dependencies']['cs_saved_minute_reporting_repair_independent_review_20261015/INDEPENDENT_REPORTING_AND_DRAIN_REPAIR_REVIEW.json']['SHA256']=='06605d2e59923d5d36349ee3ab81b2f4108d50af780844e995a660fbf71c80be'
prepared=ROOT/'legacy_intrinsic_D_prepared_source_independent_review_20261015/PREPARED_TARGET_REVIEW.json';prepared_final=prepared.parent/'FINAL_REVIEW_RECEIPT.json'
assert pin(prepared)['SHA256']=='d045ce2502f384a6414636ccf7136b5cfb29e26db6f9749c522a2ee27e08d1fb'
assert pin(prepared_final)['SHA256']=='bc2ce641c1192015de8a6e9520dc3369882d48294efa5993402a0b3f1696513b'
prep=ROOT/'legacy_intrinsic_D_20261015_v1/source_attempts/FIRST6_2023_attempt001/PREPARATION.json'
assert pin(prep)['SHA256']=='e162ec6a039ba43ff302f55601e589d0508de17fc8077d3a7e3fa895ce302edc'
gate.prepared_review(read(prep),read(prepared),pin(prepared)['SHA256'])
probe=MODULE/'GENERATED_POOL_PROBE_003';report=json.loads(read(probe/'GENERATED_POOL_PROFILE.json'))
assert pin(probe/'GENERATED_POOL_PROFILE.json')['SHA256']=='8af9c2afb09713762af3165d545e61d2d44f355ffdd741b90ca1e91bcedf01e7'
assert report['status']=='ALL_ADMITTED_ORDERED_CELLS_TERMINAL' and report['maximum_observed_live_workers']==2
assert report['compute_thread_pools_maximum']==1 and report['coordinator_CPU_affinity']==[4,5]
assert report['limits']==runtime.LIMITS and report['both_own_and_shared_lease_FDs_inherited_and_inode_bound'] is True
assert report['annual_resource_envelope_certified'] is False and report['host_quota_guaranteed'] is False
assert not any(report[k] for k in ('historical_account_objects_constructed','historical_financial_runs','actual_source_bodies_read','actual_claims_created','actual_targets_generated','automatic_claim_clears'))
receipts=[]
for case in report['cases']:
    path=probe/case['cell_id'];checkpoint=json.loads(read(path/'TERMINAL_CHECKPOINT.json'))
    assert pin(path/'TERMINAL_CHECKPOINT.json')['SHA256']==case['checkpoint_SHA256']
    for name,h in checkpoint['files'].items():assert pin(path/name)['SHA256']==h
    receipt=profile.validate(path,case['cell_id']);boot=json.loads(read(path/'BOOTSTRAP_READY.json'));owner=json.loads(read(path/'PROCESS_OWNERSHIP.json'))
    assert receipt['status']=='PASS_ACTIVE_GENERATED_LEGACY_NATIVE' and receipt['generated_minutes']==2880
    assert receipt['financial_code_manifest_SHA256']==gate.code_identity() and receipt['source_code_manifest_SHA256']==gate.SOURCE_CODE_SHA256
    assert receipt['actual_affinity']==[case['CPU']] and all(x==[case['CPU']] for x in receipt['all_TID_affinities'])
    assert receipt['PID']==case['PID']==boot['PID']==owner['PID'] and boot['requested_CPU']==case['CPU']==owner['CPU']
    assert owner['controller_PID']==report['coordinator_thread_observation']['PID']
    assert boot['thread_environment']==receipt['thread_environment']=={k:'1' for k in runtime.THREAD_ENV}
    assert boot['actual_affinity']==[case['CPU']]
    assert boot['limits']==dict(AS=[4000000000]*2,CPU=[600]*2,RSS=[2000000000]*2)
    assert receipt['limits']==runtime.LIMITS and receipt['paid_trade_rows']>0
    assert receipt['max_RSS_bytes']<2000000000 and receipt['CPU_seconds']<600 and receipt['wall_seconds']<600
    assert runtime.own_bytes(path)+(probe/(case['cell_id']+'.log')).stat().st_size<250000000
    assert receipt['shared_lease_inode']==report['temporary_shared_lease_inode']==(probe/'GENERATED_SHARED_CPU45.lock').stat().st_ino
    assert receipt['lease_inode']==(probe/'GENERATED_ONLY_TEMP_LEASE_REGISTRY'/runtime.MANIFEST_SHA256/'CONTROLLER_LEASE.lock').stat().st_ino
    receipts.append(receipt)
assert {x['CPU'] for x in report['cases']}=={4,5}
assert max(len(x['workers']) for x in report['observations'])==2
assert max(x['aggregate_live_RSS_bytes'] for x in report['observations'])<3500000000
assert all(x['aggregate_live_RSS_bytes']==sum(y['RSS_bytes'] for y in x['workers']) for x in report['observations'])
assert not report['saved_validation_errors'] and not report['pending_not_launched']
for x in report['observations']:
    assert len(x['workers'])<=2
    for worker in x['workers']:
        assert set(worker['CPU_affinity'])<={4,5}
        assert all(set(t['CPU_affinity'])<={4,5} for t in worker['tasks'])
result=dict(schema='INDEPENDENT_LEGACY_FINAL_CHECKPOINT_AND_SAVED_GENERATED_PROBE_AUDIT_V1',status='PASS',CPU_affinity=[6],numerical_pools=1,financial_code_manifest=pin(manifest_path),generated_probe=pin(probe/'GENERATED_POOL_PROFILE.json'),prepared_review=pin(prepared),prepared_final=pin(prepared_final),preparation=pin(prep),code_and_metadata_pins_checked=len(manifest['files'])+len(manifest['dependencies']),generated_probe_cases=receipts,maximum_observed_live_workers=2,maximum_observed_aggregate_RSS_bytes=max(x['aggregate_live_RSS_bytes'] for x in report['observations']),historical_arrays_read=0,actual_source_capture=0,actual_accounts=0,actual_provider_iterations=0,actual_claims=0,actual_GO_issued=0,processes_launched=0,annual_resource_envelope_certified=False,host_quota_certified=False,source_graph_old_CS_code_metadata_only=True,new_private_CS_failed_claim_dependency=False)
(OUT/'FINAL_CHECKPOINT_AND_PROBE_AUDIT.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(status='PASS',pins_checked=result['code_and_metadata_pins_checked'],maximum_observed_aggregate_RSS_bytes=result['maximum_observed_aggregate_RSS_bytes'])))
