# Independent legacy FIRST6 native/admission review

Result: PASS for the exact generated/code/admission review scope. These receipts do not authorize an actual financial launch.

## Exact reviewed checkpoint

- Current financial manifest: 9bdae8ee2af3de16c457d8b79a06d012da587d1dcaf23cf313fe893def7c463d
- Current tiny generated two-worker probe: GENERATED_POOL_PROBE_003/GENERATED_POOL_PROFILE.json, 8af9c2afb09713762af3165d545e61d2d44f355ffdd741b90ca1e91bcedf01e7
- Original source manifest remains fd365011ea371e7f75965b23628bb8e0b04a85214d3c62ba162013c9e021c5c7
- Actual preparation metadata remains e162ec6a039ba43ff302f55601e589d0508de17fc8077d3a7e3fa895ce302edc
- Prepared-source review reused at d045ce2502f384a6414636ccf7136b5cfb29e26db6f9749c522a2ee27e08d1fb and final receipt bc2ce641c1192015de8a6e9520dc3369882d48294efa5993402a0b3f1696513b. No actual source or target array bodies were reparsed by this reviewer.

## Independently verified

The reviewer reran all 28 authored generated-only tests on CPU 6 with all numerical pools set to 1. All observed forbidden-action counters were zero. All three live input/scope-seal categories were empty after testing. The first wrapper invocation used the default Python, which lacked polars and stopped before testing; the successful rerun used the existing project virtual environment. No installation or environment change was needed.

Nine separate real-CLI subprocess scenarios passed with explicitly invented temporary storage, recording source-context/capture callbacks, fake claim storage, and a post-guard native sentinel. Six cover the exact six cells; three cover capture failure, loaded validation failure, and guard exit failure. The exact wire validator, one-use metadata binding, CLI dispatch, loader, guarded NPZ path, and original source guard executed. Eight token negatives and forbidden executable-GO serialization under the source guard were checked in each scenario. Every scenario ended with zero actual source scopes, historical scopes, providers, historical accounts, or actual claims. These tests stop before historical financial construction.

Two additional independent tests cover all-tier conditional settlement versus actual paid-market flat and hostile saved-minute archives. A synthetic mark-first liquidation remains conditional settlement, never paid-market flat; there are no margin transfers or top-ups. Forged paid-flat flags fail classification. Nonfinite matrices, duplicate/mismatched columns, extra archive members, objects, surplus payload bytes, and invalid row bounds remain denied.

All 154 current code/metadata file and dependency pins were verified. The narrow helper refresh changes only runtime helper path, freezer pins, and provenance. Parser, native rules, admission, loader, gate, driver and all other original financial primitives retain their exact previous bytes. The independently approved bounded-drain v2 hash is 226b1efc7ebe0b4b607b34237240a75a9a6823a74a39345158e18b4abdeced3a, separately reviewed by receipt 06605d2e59923d5d36349ee3ab81b2f4108d50af780844e995a660fbf71c80be. Saved-data errors after a newly EXIT0 child stop new launches and drain active peers, then remain non-success. Actual process/resource/cancellation faults remain immediate-stop; no retry or claim clearing is introduced.

The predecessor exact manifest is retained in PRE_HELPER_V2_CHECKPOINT, SHA 7c018618db4a51bfa450bc19deccf7f1277a8652e4bcbb4d79d13389c6a9a6f1. Its restoration by reversing only the three declared changed files is disclosed. Original PROBE001 and PROBE002 remain retained; PROBE002's SHA remains 158264d68c0d18876200172d004294deec0ce9827fbbe88f1c9bce04b5431fcb. Neither predecessor checkpoint nor predecessor probe is the approved current probe.

The reviewer independently validated PROBE003's saved native40 reconstructions, exact saved checkpoints, two worker bootstrap/ownership/PID bindings, own and shared inherited lock inodes, affinity and all TID affinities, pool settings, resource limits, and paid synthetic activity. Both workers completed 2,880 invented 1971 minutes. Maximum live workers was 2 on distinct CPUs 4 and 5. Maximum observed aggregate live RSS was 208,105,472 bytes. The original 600-second wall/CPU, 2 GB RSS, 4 GB AS, 250 MB output, and 3.5 GB aggregate RSS limits remain exact.

## Scope and financial invariants

Only 2023 STATIC50_OLD_NO_REEXPANSION and HOLD_CORE5_VOL_MATCHED_NOREEXP, each LOW/MID/HIGH, can enter this gate. Other 24 frozen cells remain closed. The original complete intrinsic signal/sizing and saved target/covariance identities are retained, with downward-only tier ceilings and no reexpansion. Old plain-V3 target equality supplies no financial reuse or financial authority.

The actual path requires exact externally pinned source/prepared/native/financial reviews and a fresh root financial GO, then a new permanent legacy claim and both inherited resource leases. All executable financial wire validation occurs before source-guard entry. The unchanged source guard covers recapture and strict immutable saved-input loading, exits, and revokes the one-use binding before any historical financial scope/provider/account construction. The new legacy historical scope is exact-type, live-sealed, year/cell/recipe/tier/input-bound, and revoked on exit. Old CS, plain-V3 and source-only authority cannot substitute.

The shared CS CPU4/5 lock is an exclusion mutex only. No CS failed-claim, supersession, root GO, claim consumption or recovery packet is a new runtime dependency. The older source graph's exact pinned CS code/metadata dependencies remain read-only source dependencies. The new permanent claims use only the legacy namespace and remain blocked after failure; workers inherit both locked open file descriptions.

Native D's shared 10,000 wallet, 1,000 floor, 8,500 isolated ceiling, BASE27 paid costs, coarse quantity profiles, tier/asset/volatility caps, mark-first risk, same-clock complete funding batches, source-quality behavior, latency, shared capacity, five-open renewal and 32 detached charged preview corners are retained. Native financial operations and D warning/transfer-prohibition code objects remain identical. Conditional settlement remains distinct from actual paid-market flat, with debt and halts retained.

Literal funding event clocks, including the reviewed 0 to 29 ms offsets across 5,475 actual source events, remain unrounded and unscaled. This review reuses the independent prepared-source finding rather than rereading those bodies. Generated timing tests preserve the exact integer offsets. Funding publication, rate units, source arrival and exchange execution are not certified.

Native40 chronological reconstruction is authoritative. Raw100 delta residual diagnostics remain explicitly unmodified, even if their legacy passed field is false. Tiny 1e-38 saved cash/debt/margin corruptions fail exact native reconciliation. No epsilon or tolerance is substituted into financial proof.

## Boundaries

This reviewer issued no actual financial GO, constructed no historical account or historical scope, captured no actual source, iterated no actual provider, rebuilt no actual target/covariance grid, reserved no actual claim, ran no actual financial case and published nothing. The tiny generated probe does not certify annual historical resources or a host quota. Actual completion and financial outcomes remain unobserved. Root alone controls any separately authorized future launch.

## Final handoff

The finalized author delivery manifest is a7c78ea4b90a7080cdd3c28560fd9e5a0f80f169ab88b72ff3d61298319137db. Every entry was independently rehashed. FINAL_AUTHOR_HANDOFF_PIN_AUDIT.json supersedes the preliminary handoff pins in REFRESH_AND_HANDOFF_AUDIT.json; the latter remains evidence of the unchanged helper-only code delta. The final invalid root template and launch command bind these exact independent reviews while retaining a fresh-root-GO placeholder and false financial/account/provider authority. The probe handoff identifies accepted PROBE003 and uses a new-exclusive-output placeholder for any separately authorized generated rerun.
