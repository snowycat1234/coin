"""Read-only final author delivery pin and invalid launch handoff audit."""
import json,os,sys
from hashlib import sha256
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent;MODULE=ROOT/'legacy_intrinsic_D_native_20261015_v1';OUT=Path(__file__).resolve().parent
os.sched_setaffinity(0,{6});sys.path.insert(0,str(MODULE))
import legacy_bootstrap,legacy_finance_gate as gate,legacy_native_common as c

def pin(path):
    raw=path.read_bytes();return dict(path=str(path.relative_to(ROOT)),SHA256=sha256(raw).hexdigest(),bytes=len(raw))
def write(name,value):
    raw=(json.dumps(value,sort_keys=True,indent=2)+'\n').encode()
    with (OUT/name).open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
    return pin(OUT/name)
deliverable=json.loads((MODULE/'DELIVERABLE_PINS.json').read_bytes())
assert pin(MODULE/'DELIVERABLE_PINS.json')['SHA256']=='a7c78ea4b90a7080cdd3c28560fd9e5a0f80f169ab88b72ff3d61298319137db'
for name,want in deliverable['files'].items():
    got=pin(MODULE/name);assert {k:got[k] for k in ('SHA256','bytes')}==want,name
assert deliverable['financial_code_manifest_SHA256']==gate.code_identity()=='9bdae8ee2af3de16c457d8b79a06d012da587d1dcaf23cf313fe893def7c463d'
hand=json.loads((MODULE/'INDEPENDENT_REVIEW_HANDOFF.json').read_bytes())
assert pin(MODULE/'INDEPENDENT_REVIEW_HANDOFF.json')['SHA256']=='2d575b07d6fcd4a557989a7b36e01179caf753943f8d967be800958d6cdfda08'
native=OUT/'INDEPENDENT_NATIVE_GENERATED_ADMISSION_REVIEW.json';finance=OUT/'INDEPENDENT_FINANCIAL_ADMISSION_REVIEW.json'
assert hand['native_independent_review_SHA256']==pin(native)['SHA256']=='ae39dd97a77cad74af7b737651c57e58af48ffa3d15aa988281351a80a2643ab'
assert hand['financial_independent_review_SHA256']==pin(finance)['SHA256']=='e58cdfd97bfea6dd5dc1adb1da09f54249a77ee8053ff668f3c5fe6ea62bc025'
assert hand['financial_execution_authorized'] is False and hand['other24_cells_authorized'] is False
root=json.loads((MODULE/'ROOT_FINANCIAL_GO_INVALID_TEMPLATE.json').read_bytes())
assert root['status']=='INVALID_NOT_ROOT_AUTHORIZATION' and root['action']=='INVALID_TEMPLATE_NOT_ROOT_AUTHORIZATION'
assert root['financial_execution_authorized'] is False and root['account_construction_authorized'] is False and root['actual_provider_iteration_authorized'] is False
assert root['target_financial_independent_review_SHA256']==pin(finance)['SHA256'] and root['native_generated_review_SHA256']==pin(native)['SHA256']
launch=(MODULE/'LAUNCH_FIRST6_FINANCIAL_COMMAND_INVALID.txt').read_text()
assert 'INVALID HANDOFF' in launch and 'taskset -c 4,5' in launch and '--go-sha REPLACE_WITH_FRESH_ROOT_GO_SHA256' in launch
assert str(finance) in launch and str(native) in launch and pin(finance)['SHA256'] in launch and pin(native)['SHA256'] in launch
resource=(MODULE/'GENERATED_RESOURCE_PROBE_HANDOFF.txt').read_text()
assert 'GENERATED_POOL_PROBE_003/GENERATED_POOL_PROFILE.json' in resource and '8af9c2afb09713762af3165d545e61d2d44f355ffdd741b90ca1e91bcedf01e7' in resource
assert '--output /ABSOLUTE/PATH/TO/NEW_EXCLUSIVE_GENERATED_OUTPUT_DIRECTORY' in resource
assert pin(MODULE/'GENERATED_RESOURCE_PROBE_HANDOFF.txt')['SHA256']=='421d9425a0e841f67f882ab04814ebf7a3e0cdbb1a88ab59a8b357b4f4de57b4'
prep=(ROOT/'legacy_intrinsic_D_20261015_v1/source_attempts/FIRST6_2023_attempt001/PREPARATION.json').read_bytes()
gate.native_review(native.read_bytes(),pin(native)['SHA256'])
assert c.canonical(c.exact_object(finance.read_bytes()))==c.canonical(gate.review_policy(prep,'d045ce2502f384a6414636ccf7136b5cfb29e26db6f9749c522a2ee27e08d1fb',pin(native)['SHA256']))
files=('DELIVERABLE_PINS.json','INDEPENDENT_REVIEW_HANDOFF.json','LAUNCH_FIRST6_FINANCIAL_COMMAND_INVALID.txt','ROOT_FINANCIAL_GO_INVALID_TEMPLATE.json','NATIVE_REVIEW_INVALID_TEMPLATE.json','FINANCIAL_REVIEW_INVALID_TEMPLATE.json','GENERATED_RESOURCE_PROBE_HANDOFF.txt')
receipt=dict(schema='INDEPENDENT_FINAL_LEGACY_AUTHOR_HANDOFF_PIN_AUDIT_V1',status='PASS',author_deliverable_pins_checked=len(deliverable['files']),final_author_handoff={n:pin(MODULE/n) for n in files},native_review=pin(native),financial_review=pin(finance),exact_gate_compatible_independent_receipts=True,invalid_root_GO_template_remains_non_authority=True,fresh_root_GO_not_written_or_issued=True,reviewer_actual_source_capture=0,reviewer_actual_financial_runs=0,reviewer_actual_claims=0,reviewer_actual_GO=0,CPU_affinity=[6],numerical_pools=1)
print(json.dumps(write('FINAL_AUTHOR_HANDOFF_PIN_AUDIT.json',receipt),sort_keys=True))
