"""Verify the exact narrow helper delta and explicitly non-authorizing handoff."""
import difflib,json,os,sys
from hashlib import sha256
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent;MODULE=ROOT/'legacy_intrinsic_D_native_20261015_v1';OUT=Path(__file__).resolve().parent
os.sched_setaffinity(0,{6});sys.path.insert(0,str(MODULE))
import legacy_bootstrap,legacy_finance_gate as gate,legacy_native_common as common

def pin(path):
    raw=path.read_bytes();return dict(path=str(path.relative_to(ROOT)),SHA256=sha256(raw).hexdigest(),bytes=len(raw))
oldroot=MODULE/'PRE_HELPER_V2_CHECKPOINT';oldpath=oldroot/'FINANCIAL_CODE_MANIFEST.json';old=json.loads(oldpath.read_bytes());new=json.loads((MODULE/'FINANCIAL_CODE_MANIFEST.json').read_bytes())
assert pin(oldpath)['SHA256']=='7c018618db4a51bfa450bc19deccf7f1277a8652e4bcbb4d79d13389c6a9a6f1'
assert set(old['files'])==set(new['files'])
changed=[n for n in old['files'] if old['files'][n]!=new['files'][n]]
assert set(changed)=={'legacy_process_runtime.py','freeze_financial_checkpoint.py','NATIVE_PROCESS_PROVENANCE.json'},changed
for n in changed:
    p=pin(oldroot/n);assert {k:p[k] for k in ('SHA256','bytes')}==old['files'][n]
    (OUT/('HELPER_V2_DELTA_'+n+'.diff')).write_text(''.join(difflib.unified_diff((oldroot/n).read_text().splitlines(True),(MODULE/n).read_text().splitlines(True),fromfile='pre_helper_v2/'+n,tofile='current/'+n)))
olddeps=set(old['dependencies']);newdeps=set(new['dependencies'])
assert olddeps-newdeps=={'cs_saved_minute_reporting_repair_20261015_v1/bounded_drain.py'}
assert newdeps-olddeps=={'cs_saved_minute_reporting_repair_20261015_v2/bounded_drain.py','cs_saved_minute_reporting_repair_independent_review_20261015/INDEPENDENT_REPORTING_AND_DRAIN_REPAIR_REVIEW.json'}
assert all(old['dependencies'][n]==new['dependencies'][n] for n in olddeps&newdeps)
runtime_delta=(oldroot/'legacy_process_runtime.py').read_text().replace('cs_saved_minute_reporting_repair_20261015_v1','cs_saved_minute_reporting_repair_20261015_v2')
assert runtime_delta==(MODULE/'legacy_process_runtime.py').read_text()
assert pin(MODULE/'GENERATED_POOL_PROBE_002/GENERATED_POOL_PROFILE.json')['SHA256']=='158264d68c0d18876200172d004294deec0ce9827fbbe88f1c9bce04b5431fcb'
hand=json.loads((MODULE/'INDEPENDENT_REVIEW_HANDOFF.json').read_bytes())
assert hand['financial_code_manifest_SHA256']==gate.code_identity()
assert hand['generated_two_worker_probe_SHA256']=='8af9c2afb09713762af3165d545e61d2d44f355ffdd741b90ca1e91bcedf01e7'
assert hand['operational_repair_SHA256']=='226b1efc7ebe0b4b607b34237240a75a9a6823a74a39345158e18b4abdeced3a'
assert hand['operational_repair_independent_review_SHA256']=='06605d2e59923d5d36349ee3ab81b2f4108d50af780844e995a660fbf71c80be'
for name in ('NATIVE_REVIEW_INVALID_TEMPLATE.json','FINANCIAL_REVIEW_INVALID_TEMPLATE.json','ROOT_FINANCIAL_GO_INVALID_TEMPLATE.json'):
    m=json.loads((MODULE/name).read_bytes());assert m['financial_execution_authorized'] is False and m['financial_code_manifest_SHA256']==gate.code_identity()
    assert 'INVALID' in m['status'],name
    if name.startswith('NATIVE_'):
        try:gate.native_review((MODULE/name).read_bytes(),pin(MODULE/name)['SHA256'])
        except ValueError:pass
        else:raise AssertionError('INVALID_NATIVE_TEMPLATE_ADMITTED')
launch=(MODULE/'LAUNCH_FIRST6_FINANCIAL_COMMAND_INVALID.txt').read_text()
assert 'INVALID HANDOFF' in launch and 'taskset -c 4,5' in launch and '--go-sha REPLACE_WITH_FRESH_ROOT_GO_SHA256' in launch
assert '--native-review-sha REPLACE_WITH_NATIVE_REVIEW_SHA256' in launch and '--review-sha REPLACE_WITH_FINANCIAL_REVIEW_SHA256' in launch
files=['INDEPENDENT_REVIEW_HANDOFF.json','LAUNCH_FIRST6_FINANCIAL_COMMAND_INVALID.txt','ROOT_FINANCIAL_GO_INVALID_TEMPLATE.json','FINANCIAL_REVIEW_INVALID_TEMPLATE.json','NATIVE_REVIEW_INVALID_TEMPLATE.json','NATIVE_PROCESS_PROVENANCE.json','DELIVERABLE_PINS.json','PRE_HELPER_V2_CHECKPOINT/CHECKPOINT_EXACT_BYTES_RECEIPT.json']
result=dict(status='PASS',schema='INDEPENDENT_NARROW_HELPER_DELTA_AND_NONAUTHORIZING_HANDOFF_V1',exact_old_manifest=pin(oldpath),changed_files=changed,only_runtime_change_is_v1_to_v2_helper_path=True,parser_native_admission_loader_gate_driver_unchanged=True,unchanged_common_dependencies=True,new_dependency_paths=sorted(newdeps-olddeps),removed_dependency_paths=sorted(olddeps-newdeps),old_probe002=pin(MODULE/'GENERATED_POOL_PROBE_002/GENERATED_POOL_PROFILE.json'),handoff_pins={n:pin(MODULE/n) for n in files},invalid_native_template_denied=True,root_GO_template_is_not_authority=True,actual_root_GO_issued=0,actual_claims=0,actual_finance=0,CPU_affinity=[6],numerical_pools=1)
(OUT/'REFRESH_AND_HANDOFF_AUDIT.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(status='PASS',changed_files=changed)))
