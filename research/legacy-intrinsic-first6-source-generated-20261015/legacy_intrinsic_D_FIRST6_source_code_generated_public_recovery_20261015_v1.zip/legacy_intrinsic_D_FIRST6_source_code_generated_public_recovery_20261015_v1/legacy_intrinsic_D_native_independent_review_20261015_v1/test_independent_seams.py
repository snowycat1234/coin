"""Extra invented-data seams; never construct a historical scope or account."""
from copy import deepcopy
from decimal import Decimal as D
from io import BytesIO
import json,os,sys,unittest,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent;MODULE=ROOT/'legacy_intrinsic_D_native_20261015_v1';OUT=Path(__file__).resolve().parent
os.sched_setaffinity(0,{6});sys.path.insert(0,str(MODULE))
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','POLARS_MAX_THREADS','VECLIB_MAXIMUM_THREADS','BLIS_NUM_THREADS'):os.environ[k]='1'
import legacy_bootstrap,legacy_native_generated as generated,legacy_saved as saved,legacy_process_runtime as runtime
import numpy as np
EVIDENCE={}

def marks(a,at,price):
    base=(50000,2000,20,.5,.05)
    return a.update_marks(at,{s:dict(price=str(price if j==0 else base[j]),close_us=at,available_us=at) for j,s in enumerate(a.symbols)})

class IndependentSeams(unittest.TestCase):
    def test_gap_settlement_is_never_paid_market_flat_all_tiers(self):
        e=generated.native_reference();rows=[]
        for tier in ('LOW','MID','HIGH'):
            plain=e.V2.grid.make_account(tier,'BASE27')
            a=e.ExpansionAccount(plain.config,symbols=e.S,instrument_profiles=plain.instrument_profiles,generated_scope=e.GENERATED,tier_name=tier)
            marks(a,e.MINUTE,50000)
            a.execute_fill('BTCUSDT','SELL','.02',e.MINUTE+1,0,'INVENTED_SETTLEMENT',execution_mid_price='50000',quote_available_us=e.MINUTE,available_quantity='.02')
            marks(a,2*e.MINUTE,100000)
            self.assertEqual(len(a.settlement_journal),1);a.monitor('MONITOR:'+str(2*e.MINUTE),2*e.MINUTE)
            report=a.economic_report();self.assertFalse(report['paid_flat']);self.assertTrue(report['settled_flat_under_declared_model'])
            self.assertFalse(a.transfer_journal);self.assertFalse(a.topup_enabled);self.assertFalse(a.pending_exits)
            self.assertEqual(a.positions['BTCUSDT'].quantity,0)
            audit=e.V2.OWNED.export_tree(a.snapshot());nav=str(a.nav());net=float(a.nav()/D(10000)-1)
            result=dict(summary=dict(decimal_strings=dict(NAV=nav),completed_minutes=1,stop_us=None),economics=dict(full_calendar=True,paid_flat=False,actual_paid_market_flat=False,conditional_settled_flat=True,comparable_full_calendar_return=net,paid_net_return=None,conditional_model_net_return=net))
            self.assertEqual(runtime.classify_terminal(audit,result,calendar=[e.MINUTE,2*e.MINUTE],completed_minutes=1,stop_us=None),'FULL_CALENDAR_CONDITIONAL_SETTLED_FLAT')
            for key in ('paid_flat','actual_paid_market_flat'):
                bad=deepcopy(result);bad['economics'][key]=True
                with self.assertRaises(ValueError):runtime.classify_terminal(audit,bad,calendar=[e.MINUTE,2*e.MINUTE],completed_minutes=1,stop_us=None)
            rows.append(dict(tier=tier,settlements=len(a.settlement_journal),paid_flat=report['paid_flat'],settled_flat_under_declared_model=report['settled_flat_under_declared_model'],transfers=len(a.transfer_journal),actual_historical_scope=a._execution_scope is not None,classification='FULL_CALENDAR_CONDITIONAL_SETTLED_FLAT'))
        EVIDENCE['conditional_settlement']=rows
    def test_saved_minute_payload_finiteness_namespace_and_columns(self):
        values=np.arange(6,dtype=np.float64).reshape(3,2);names=np.array(['a','b'])
        variants=[]
        def archive(vals=values,columns=names,extra=None):
            stream=BytesIO();np.savez_compressed(stream,values=vals,columns=columns)
            if extra:
                with zipfile.ZipFile(stream,'a') as z:z.writestr(*extra)
            return stream.getvalue()
        for label,raw in [('nonfinite',archive(np.array([[np.nan,0.],[1.,2.],[3.,4.]]))),('duplicate_columns',archive(columns=np.array(['a','a']))),('extra_member',archive(extra=('extra.npy',b'x'))),('object_values',archive(np.array([[object(),1],[2,3],[4,5]],dtype=object))),('wrong_column_count',archive(columns=np.array(['a'])))]:
            with self.subTest(label=label),self.assertRaises(ValueError):saved.saved_minute(raw,3)
            variants.append(label)
        original=archive();source=zipfile.ZipFile(BytesIO(original));stream=BytesIO()
        with zipfile.ZipFile(stream,'w') as z:
            for info in source.infolist():z.writestr(info.filename,source.read(info.filename)+(b'x' if info.filename=='values.npy' else b''))
        with self.assertRaises(ValueError):saved.saved_minute(stream.getvalue(),3)
        variants.append('surplus_payload_byte')
        for rows in (-1,True,525601):
            with self.assertRaises(ValueError):saved.saved_minute(original,rows)
        EVIDENCE['hostile_saved_minute']=variants+['negative_rows','bool_rows','unbounded_rows']

if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(IndependentSeams))
    (OUT/'INDEPENDENT_ADDITIONAL_SEAMS.json').write_text(json.dumps(dict(status='PASS' if result.wasSuccessful() else 'FAIL',tests=result.testsRun,evidence=EVIDENCE,CPU_affinity=[6],numerical_pools=1,actual_source_capture=0,actual_historical_scopes=0,actual_accounts=0,actual_provider_iterations=0,actual_claims=0,actual_financial_GO=0),sort_keys=True,indent=2)+'\n')
    raise SystemExit(0 if result.wasSuccessful() else 1)
