"""Immutable independent evidence package; no source or financial execution."""
from datetime import datetime,timezone
from hashlib import sha256
import json,os
from pathlib import Path
OUT=Path(__file__).resolve().parent;ROOT=OUT.parent;MODULE=ROOT/'legacy_intrinsic_D_native_20261015_v1'
os.sched_setaffinity(0,{6})
def pin(path):
    raw=path.read_bytes();return dict(path=str(path.relative_to(ROOT)),SHA256=sha256(raw).hexdigest(),bytes=len(raw))
def write(path,value):
    with path.open('xb') as f:f.write((json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n').encode());f.flush();os.fsync(f.fileno())
    return pin(path)
for name in ('FINAL_CHECKPOINT_AND_PROBE_AUDIT.json','REFRESH_AND_HANDOFF_AUDIT.json','FINAL_AUTHOR_HANDOFF_PIN_AUDIT.json','FINANCIAL_GENERATED_TEST_RECEIPT.json','INDEPENDENT_REAL_CLI_RECEIPT.json','INDEPENDENT_ADDITIONAL_SEAMS.json'):
    assert json.loads((OUT/name).read_bytes())['status']=='PASS'
assert pin(MODULE/'FINANCIAL_CODE_MANIFEST.json')['SHA256']=='9bdae8ee2af3de16c457d8b79a06d012da587d1dcaf23cf313fe893def7c463d'
assert pin(MODULE/'GENERATED_POOL_PROBE_003/GENERATED_POOL_PROFILE.json')['SHA256']=='8af9c2afb09713762af3165d545e61d2d44f355ffdd741b90ca1e91bcedf01e7'
assert pin(MODULE/'DELIVERABLE_PINS.json')['SHA256']=='a7c78ea4b90a7080cdd3c28560fd9e5a0f80f169ab88b72ff3d61298319137db'
manifest=write(OUT/'REVIEW_EVIDENCE_MANIFEST.json',dict(schema='INDEPENDENT_LEGACY_NATIVE_REVIEW_EVIDENCE_MANIFEST_V1',status='IMMUTABLE_NONAUTHORIZING_REVIEW_EVIDENCE',files={str(p.relative_to(OUT)):pin(p) for p in sorted(OUT.rglob('*')) if p.is_file() and p.name not in ('REVIEW_EVIDENCE_MANIFEST.json','FINAL_REVIEW_RECEIPT.json','FINALIZE_REVIEW.log')}))
final=dict(schema='INDEPENDENT_LEGACY_FIRST6_NATIVE_AND_FINANCIAL_ADMISSION_FINAL_REVIEW_V1',status='PASS_EXACT_CODE_GENERATED_AND_ADMISSION_REVIEW_ONLY',created_UTC=datetime.now(timezone.utc).isoformat(),CPU_affinity=[6],numerical_pools=1,blockers_in_review_scope=[],financial_execution_authorized=False,fresh_root_financial_GO_required=True,other24_cells_authorized=False,publication_authorized=False,actual_source_or_target_array_bodies_read=0,actual_source_captures=0,actual_target_covariance_rebuilds=0,actual_historical_scopes=0,actual_historical_accounts=0,actual_provider_iterations=0,actual_claims_reserved=0,actual_financial_runs=0,actual_financial_GO_issued=0,reviewer_frozen_module_writes=0,generated_real_CLI_subprocess_scenarios=9,author_generated_tests_independently_rerun=28,additional_independent_generated_seam_tests=2,final_code_metadata_pins_checked=154,review_evidence_manifest=manifest,native_generated_admission_review=pin(OUT/'INDEPENDENT_NATIVE_GENERATED_ADMISSION_REVIEW.json'),financial_admission_review=pin(OUT/'INDEPENDENT_FINANCIAL_ADMISSION_REVIEW.json'),financial_code_manifest=pin(MODULE/'FINANCIAL_CODE_MANIFEST.json'),generated_probe=pin(MODULE/'GENERATED_POOL_PROBE_003/GENERATED_POOL_PROFILE.json'),author_deliverable_manifest=pin(MODULE/'DELIVERABLE_PINS.json'),final_author_handoff_audit=pin(OUT/'FINAL_AUTHOR_HANDOFF_PIN_AUDIT.json'),readable_report=pin(OUT/'REVIEW_REPORT.md'),exact_original_source_preserved=True,source_and_target_review_reused_without_array_reparse=True,helper_v2_only_runtime_delta=True,no_new_private_CS_failed_claim_dependency=True,legacy_own_and_shared_CS_resource_leases_inherited=True,maximum_observed_live_probe_workers=2,probe_worker_CPUs=[4,5],maximum_observed_aggregate_probe_RSS_bytes=208105472,native40_authoritative_raw100_residual_unchanged=True,financial_tolerance_or_epsilon_introduced=False,conditional_settlement_separate_from_actual_paid_market_flat=True,literal_funding_clocks_unrounded_unscaled=True,annual_historical_resource_envelope_certified=False,host_quota_certified=False,preliminary_handoff_pin_audit_superseded_by_final_author_handoff_audit=True,required_next_step='ROOT_ALONE_MAY_ISSUE_SEPARATELY_AUTHORIZED_FRESH_EXACT_FINANCIAL_GO_AND_DECIDE_WHEN_CPU45_LEASE_IS_AVAILABLE_NO_LAUNCH_FROM_THIS_RECEIPT')
receipt=write(OUT/'FINAL_REVIEW_RECEIPT.json',final)
for p in OUT.rglob('*'):
    if p.is_file():p.chmod(0o444)
print(json.dumps(dict(status=final['status'],final_review=receipt,evidence_manifest=manifest,native=final['native_generated_admission_review'],financial=final['financial_admission_review']),sort_keys=True))
