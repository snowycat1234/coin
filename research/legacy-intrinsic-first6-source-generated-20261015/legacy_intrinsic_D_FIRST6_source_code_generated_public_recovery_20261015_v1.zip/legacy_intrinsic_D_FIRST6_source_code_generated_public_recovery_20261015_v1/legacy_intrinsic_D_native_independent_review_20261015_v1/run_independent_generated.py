"""Independent rerun wrapper; all generated outputs remain outside frozen module."""
import os
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parent.parent
MODULE=ROOT/'legacy_intrinsic_D_native_20261015_v1'
sys.path.insert(0,str(MODULE))
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','POLARS_MAX_THREADS','VECLIB_MAXIMUM_THREADS','BLIS_NUM_THREADS'):os.environ[key]='1'
os.sched_setaffinity(0,{6})
import run_financial_generated as suite
suite.HERE=Path(__file__).resolve().parent
raise SystemExit(suite.main())
