"""Synthetic in-memory fixtures only. Never source-admitted or financial-ready."""
from io import BytesIO
import numpy as np
import legacy_common as c
import legacy_config as config
import legacy_entry as entry
import legacy_signal as signal
import legacy_source as source


observed_generated_scope_lifecycle=dict(minted=0,revoked=0,actual_body_read_blocks=0)
observed_guard_receipts=[]


def pack(**arrays):
    stream=BytesIO();np.savez_compressed(stream,**arrays);return stream.getvalue()


def authority():
    review=c.canonical(entry.review_policy(entry.FIRST6))
    review_sha=c.sha(review)
    go=c.canonical(entry.source_policy(entry.FIRST6,review_sha))
    return go,c.sha(go),review,review_sha


def daily():
    first,last=1655337600000000,1704067200000000
    clocks=np.arange(first,last+config.DAY,config.DAY,dtype=np.int64)
    x=np.arange(len(clocks),dtype=np.float64)
    close=np.column_stack([100+j*20+x*(.02+j*.003)+np.sin(x/(7+j)+j)*.4 for j in range(5)])
    return dict(close_available_us=clocks,close=close)


def fixture():
    # These are new synthetic arrays. No stored NPZ, target or price body is read.
    original=daily(); clocks=original['close_available_us'][:-1];close=original['close'][:-1]
    period=config.source_year(2023);decisions=np.arange(period['start'],period['end'],config.DAY,dtype=np.int64)
    arrays,proofs=signal.build_target_grid(close,clocks,clocks,decisions)
    rows=tuple(dict(symbol=symbol,close_us=int(at),available_us=int(at),close=float(close[i,j]))
        for i,at in enumerate(clocks) for j,symbol in enumerate(config.SYMBOLS))
    sidecar=c.canonical(dict(schema='GENERATED_IN_MEMORY_ONLY',cells=[],derived_mark_cells=0))+b'\n'
    inputs=pack(close_available_us=clocks,close=close)
    fake=dict(source_identity=entry.contracts()['years']['2023']['source_identity'],
        contract=entry.contracts()['years']['2023'],period=period,source_rows=rows,events=[],sidecar_raw=sidecar)
    info=source.year_info(fake,arrays,inputs)
    go,go_sha,review,review_sha=authority()
    artifacts={'2023/TARGETS.npz':pack(**arrays),'2023/SOURCE_INPUTS.npz':inputs,
        '2023/SOURCE_ROWS.json':c.canonical(rows)+b'\n','2023/RAW_EVENTS.json':b'[]\n',
        '2023/MINUTE_MARK_PROVENANCE.json':sidecar,'2023/TARGET_PROOFS.json':c.canonical(proofs)+b'\n',
        'SOURCE_STAGE_AUTHORIZATION.json':go,'SOURCE_INDEPENDENT_REVIEW.json':review}
    cells={}
    for cell_id in entry.tranche_cells(entry.FIRST6):
        descriptor=config.cell_named(cell_id);binding=entry.binding_from_info(descriptor,info,go_sha,review_sha)
        cells[cell_id]=dict(descriptor=descriptor,input_binding=binding,input_binding_SHA256=c.jsha(binding))
    prep=dict(schema=entry.PREPARATION_SCHEMA,candidate=config.CANDIDATE,adaptation_version=config.VERSION,
        tranche=entry.FIRST6,ordered_cells=list(entry.tranche_cells(entry.FIRST6)),years={'2023':info},cells=cells,
        code_manifest_SHA256=entry.code_identity(),scope_manifest_SHA256=entry.manifest_sha(),
        source_contract_map_SHA256=entry.contract_sha(),source_stage_GO_SHA256=go_sha,source_review_SHA256=review_sha,
        artifacts={name:dict(SHA256=c.sha(raw),bytes=len(raw)) for name,raw in artifacts.items()},
        historical_admission=False,financial_runs=0,accounts_created=0,accounts_advanced=0,
        provider_iterations=0,process_launches=0,canonical_claims_created=0,real_financial_GO_written=0,publication_actions=0)
    return prep,artifacts,arrays


def read_paths():
    record=c.exact_object((c.HERE/'CODE_MANIFEST.json').read_bytes())
    return ([c.HERE/name for name in record['files']]+[c.ROOT/name for name in record['dependencies']]
        +[c.HERE/'CODE_MANIFEST.json'])
