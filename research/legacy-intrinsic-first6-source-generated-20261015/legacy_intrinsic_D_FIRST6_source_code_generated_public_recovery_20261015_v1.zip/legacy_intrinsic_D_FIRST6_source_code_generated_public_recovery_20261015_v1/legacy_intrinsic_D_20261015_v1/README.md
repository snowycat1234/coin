# Legacy intrinsic D: FIRST6 source-only checkpoint

Additive new namespace. This checkpoint implements source/target preparation code and generated tests for exactly the six 2023 cells of the fixed thirty-cell plan. Other 24 cells are closed. No actual historical source body, target, admission, provider, account, financial process, canonical claim, real GO or publication is created by the author checks. Two explicitly generated ephemeral source-scope lifecycle cases are minted and revoked under a code-only guard; a deliberately attempted actual-body read is stopped before opening the body. No runtime root GO file is created.

The complete original STATIC50_OLD_NO_REEXPANSION and HOLD_CORE5_VOL_MATCHED_NOREEXP implementations are executed from the exact reviewed pure adapter and its original pinned AST closure. All masks, matching clocks, weekly signal ownership, intrinsic sizing and cash behavior remain unchanged. Only downward LOW/MID/HIGH ceilings follow each complete recipe. No CS-common projection or re-expansion is imported. The plain V3 2023 baseline contributes zero D reuse.

The generic I-01 structured-dtype weakness is closed at this new boundary: identity first rejects structured, subarray, void, object and every unsupported dtype. Only plain bool, int64 and float64 are accepted; exact endian, shape and C-order bytes remain distinct. Target schemas require native float64/int64 explicitly.

Source bytes may be read only through a new sealed LegacySourcePreparationScope, a fresh exact source review and root source GO, and SourceOnlyGuard. The authority binds this code manifest, all thirty recipe/cell descriptors, the six-cell subset, exact 2023 source contract, pure-signal review, independent source review and fresh GO bytes. CS scopes, loaded types and GO schemas are not accepted. Recording callbacks are metadata-only and revoke immediately. LoadedLegacyInputs can validate saved source/target artifacts without any financial import or token.

The 2023 schema preserves original raw signed funding with exactly 8-hour reported intervals, same-clock alphabetical order, unconfirmed units, zero derived marks, complete 365-day decision calendar and exact daily/native price bits. Source completion does not certify publication arrival, venue, funding units, liquidation or new legacy position/funding impacts.

2021 is a closed partial 274-day period, 2024 is a closed leap 366-day period; full 2022 and 2025 are closed. Future 2022 work must separately preserve all 27 UNKNOWN carried-mark cells, original anchor age and eight genuine recovery rows and measure new actual ownership/funding impacts. No future source is opened here. All periods are seen development, not untouched out-of-sample.

Run generated checks on CPU0 with numerical pools1:

    PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 taskset -c 0 python legacy_intrinsic_D_20261015_v1/run_source_generated.py
    PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 taskset -c 0 python legacy_intrinsic_D_20261015_v1/test_cold_generated_zip.py
    PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 taskset -c 0 python legacy_intrinsic_D_20261015_v1/test_cold_generated_zip.py --expect-cold-stop

The fresh-process tests verify production preloading of cp437 and utf_8_sig before the guard for ASCII flag0 DEFLATED ZIP and literal BOM payloads. The negative control demonstrates the cold codec import is caught without opening any stored ZIP.

SOURCE_STAGE_GO_TEMPLATE_INVALID.json and SOURCE_STAGE_COMMAND_INVALID.txt are deliberately unusable. Independent code/generated review is next. Actual preparation requires separately authorized exact FIRST6 source/target GO, followed by independent prepared-target review. No finance is implemented or authorized. Do not infer native D conformity from these source/math checks.
