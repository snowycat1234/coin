"""Thin source-preserving adapter over the exact reviewed pure legacy closure.

No market I/O, account, provider or CS-common projection. The I-01 boundary
rejects unsupported descriptors before calling the existing generic identity.
"""
from types import ModuleType
import sys
import numpy as np
import legacy_common as c
from legacy_config import RECIPES, SYMBOLS, TIERS

PURE_PATH = 'legacy_intrinsic_D_signal_20261015/legacy_signal.py'
PURE_SHA = 'c6c0d985098fc976da06f561ada2ac5d75d6d1b8f6aa95bad9b2bd5620ff4838'


def reviewed_signal():
    path = c.ROOT / PURE_PATH
    raw = c.exact(path, PURE_SHA)
    module = ModuleType('_legacy_source_reviewed_pure_adapter')
    module.__file__ = str(path)
    previous = sys.modules.get(module.__name__)
    sys.modules[module.__name__] = module
    try:
        exec(compile(raw, str(path), 'exec'), module.__dict__)
    finally:
        if previous is None:
            sys.modules.pop(module.__name__, None)
        else:
            sys.modules[module.__name__] = previous
    return module


def supported_array(value):
    value = np.asarray(value)
    dtype = value.dtype
    if (dtype.fields is not None or dtype.subdtype is not None or dtype.hasobject
            or (dtype.kind, dtype.itemsize) not in (('b',1),('i',8),('f',8))):
        raise ValueError('PLAIN_BOOL_INT64_FLOAT64_ONLY_NO_STRUCTURED_VOID_OBJECT_OR_UNSUPPORTED_DTYPE')
    return value


def array_byte_identity(value):
    value = supported_array(value)  # Mandatory before the reviewed generic helper.
    return reviewed_signal().array_byte_identity(value)


def immutable_array(value):
    value = supported_array(value)
    return np.frombuffer(value.tobytes(order='C'),dtype=value.dtype).reshape(value.shape)


def build_target_grid(close, close_us, available_us, decisions):
    arrays = [supported_array(v) for v in (close, close_us, available_us, decisions)]
    if (arrays[0].dtype != np.dtype('float64')
            or any(v.dtype != np.dtype('int64') for v in arrays[1:])):
        raise ValueError('EXACT_PLAIN_FLOAT64_PRICES_INT64_CLOCKS_REQUIRED')
    # Calling the original complete intrinsic implementation preserves every
    # mask, matching clock, weekly ownership and original cash behavior.
    clocks, targets, covariance, proofs = reviewed_signal()._legacy_math().build_target_grid(
        *arrays, symbols=SYMBOLS)
    intrinsic = {recipe:np.asarray([row['intrinsic'][recipe] for row in proofs],dtype=np.float64)
                 for recipe in RECIPES}
    result = dict(decision_us=clocks, annual_covariance=covariance)
    result.update({'intrinsic_' + recipe:value for recipe,value in intrinsic.items()})
    result.update(targets)
    return {key:immutable_array(value) for key,value in result.items()}, c.plain(proofs)


def target_key(cell):
    return cell['recipe'] + '_' + cell['tier']
