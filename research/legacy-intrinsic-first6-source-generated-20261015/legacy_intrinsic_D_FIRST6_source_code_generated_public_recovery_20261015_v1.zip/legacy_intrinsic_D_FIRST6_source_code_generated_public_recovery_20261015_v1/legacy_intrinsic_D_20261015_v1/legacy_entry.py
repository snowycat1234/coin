"""Separate legacy source-only authority. No financial constructor or token exists.

Validators are pure metadata checks. An actual source scope additionally needs a
fresh exact review, a fresh root source GO, and the whole-invocation source guard.
The other twenty-four manifest cells remain closed at this checkpoint.
"""
from contextlib import contextmanager
from dataclasses import dataclass, field
import legacy_common as c
import legacy_config as config

FIRST6 = 'FIRST6_2023_TWO_RECIPES_ALL_THREE_TIERS'
SOURCE_SCHEMA = 'ROOT_SOURCE_TARGET_LEGACY_INTRINSIC_LOWER_ONLY_V1'
SOURCE_REVIEW_SCHEMA = 'INDEPENDENT_LEGACY_INTRINSIC_SOURCE_GENERATED_REVIEW_V1'
PREPARATION_SCHEMA = 'PREPARED_LEGACY_INTRINSIC_SOURCE_TARGET_ONLY_V1'
MANIFEST_NAME = 'FROZEN_THIRTY_CELL_MANIFEST.json'
_SIGNAL_REVIEW = '9a519d8bd8d409cf6ee221c74f2da1f20a6eeb22bc2e1e04f8823a03c5763500'
_SOURCE_SEAL, _RECORD_SEAL = object(), object()
_ACTIVE_SOURCE, _ACTIVE_RECORDING = {}, set()


def manifest():
    value = c.exact_object(c.ordinary(c.HERE / MANIFEST_NAME))
    fixed = dict(schema=config.VERSION, candidate=config.CANDIDATE, cell_count=30,
        cells=list(config.cells()),source_checkpoint=FIRST6,
        source_enabled_cells=[cell['cell_id'] for cell in config.cells() if cell['year']==2023],
        other24_source_entry_enabled=False,financial_entry_implemented=False,
        original_execution_replication=False,financial_reuse_allowed=False)
    if c.canonical(value) != c.canonical(fixed):
        raise ValueError('EXACT_FROZEN_LEGACY_THIRTY_CELL_MANIFEST_REQUIRED')
    return value


def manifest_sha():
    manifest()
    return c.sha(c.ordinary(c.HERE / MANIFEST_NAME))


def tranche_cells(tranche):
    if tranche != FIRST6:
        raise ValueError('ONLY_FIRST6_2023_LEGACY_SOURCE_CHECKPOINT_ENABLED')
    return tuple(cell['cell_id'] for cell in config.cells() if cell['year']==2023)


def tranche_years(tranche):
    tranche_cells(tranche)
    return (2023,)


def contracts():
    raw = c.ordinary(c.HERE/'SOURCE_CONTRACT_MAP.json')
    value = c.exact_object(raw)
    if (set(value.get('years',{})) != {'2023'}
            or value.get('schema') != 'LEGACY_INTRINSIC_FIRST6_2023_SOURCE_CONTRACT_MAP_V1'):
        raise ValueError('EXACT_SEPARATE_LEGACY_2023_SOURCE_CONTRACT_REQUIRED')
    # CODE_MANIFEST binds this file's exact bytes before admission.
    return value


def contract_sha():
    contracts()
    return c.sha(c.ordinary(c.HERE/'SOURCE_CONTRACT_MAP.json'))


def code_identity():
    raw = c.ordinary(c.HERE/'CODE_MANIFEST.json')
    record = c.exact_object(raw)
    if record.get('schema') != 'LEGACY_INTRINSIC_SOURCE_ONLY_CODE_IDENTITY_V1':
        raise ValueError('EXACT_LEGACY_SOURCE_CODE_MANIFEST_REQUIRED')
    for name,pin in record['files'].items():
        c.exact(c.HERE/c.relative(name),pin['SHA256'],pin['bytes'])
    pins = c.exact_object(c.ordinary(c.HERE/'DEPENDENCY_PINS.json'))['files']
    if c.canonical(record['dependencies']) != c.canonical(pins):
        raise ValueError('EXACT_REVIEWED_LEGACY_SOURCE_DEPENDENCIES_REQUIRED')
    for name,pin in pins.items():
        path=c.ROOT/c.relative(name)
        if path.suffix not in ('.py','.json','.md'):
            raise ValueError('CODE_METADATA_DEPENDENCY_ONLY')
        c.exact(path,pin['SHA256'],pin['bytes'])
    return c.sha(raw)


def review_policy(tranche):
    return dict(schema=SOURCE_REVIEW_SCHEMA,status='PASS',candidate=config.CANDIDATE,
        adaptation_version=config.VERSION,tranche=tranche,ordered_cells=list(tranche_cells(tranche)),
        years=list(tranche_years(tranche)),code_manifest_SHA256=code_identity(),
        scope_manifest_SHA256=manifest_sha(),source_contract_map_SHA256=contract_sha(),
        pure_signal_review_SHA256=_SIGNAL_REVIEW,I01_unsupported_dtype_gate_reviewed=True,
        source_native_financial_approval=False,old_CS_core_D_or_legacy_baseline_authority_reused=False)


def source_policy(tranche,review_sha):
    return dict(schema=SOURCE_SCHEMA,status='APPROVED_SOURCE_TARGET_ONLY',
        action='PREPARE_EXACT_'+tranche+'_LEGACY_SOURCE_TARGETS_ONLY',
        candidate=config.CANDIDATE,adaptation_version=config.VERSION,tranche=tranche,
        ordered_cells=list(tranche_cells(tranche)),years=list(tranche_years(tranche)),
        code_manifest_SHA256=code_identity(),scope_manifest_SHA256=manifest_sha(),
        source_contract_map_SHA256=contract_sha(),independent_review_SHA256=c.digest(review_sha),
        pure_signal_review_SHA256=_SIGNAL_REVIEW,
        source_identities={'2023':contracts()['years']['2023']['source_identity']},
        canonical_source_capture_authorized=True,target_generation_authorized=True,
        other24_cells_source_authorized=False,old_CS_core_D_or_legacy_baseline_authority_reused=False,
        historical_execution_authorized=False,financial_execution_authorized=False,
        account_construction_authorized=False,provider_iteration_authorized=False,
        process_launch_authorized=False,canonical_claims_authorized=False,
        financial_GO_authorized=False,publication_authorized=False,
        source_limits=dict(CPU=0,CPU_seconds=900,wall_seconds=1800,AS_bytes=3000000000,
            output_bytes=1073741824,process_count=1,numerical_pools=1))


def validate_source_authority_metadata(go_raw,expected_go_sha256,review_raw,expected_review_sha256):
    go=c.checked_external(go_raw,expected_go_sha256)
    review=c.checked_external(review_raw,expected_review_sha256)
    if go.get('tranche') != FIRST6:
        raise ValueError('ONLY_FIRST6_2023_LEGACY_SOURCE_CHECKPOINT_ENABLED')
    if c.canonical(review) != c.canonical(review_policy(FIRST6)):
        raise ValueError('EXACT_NEW_INDEPENDENT_LEGACY_SOURCE_REVIEW_REQUIRED')
    if c.canonical(go) != c.canonical(source_policy(FIRST6,expected_review_sha256)):
        raise ValueError('EXACT_NEW_ROOT_LEGACY_SOURCE_ONLY_AUTHORITY_REQUIRED')
    return c.immutable(dict(policy=go,root_go_SHA256=expected_go_sha256,review_SHA256=expected_review_sha256))


@dataclass(frozen=True,slots=True)
class LegacySourcePreparationScope:
    tranche:str
    source_go_sha256:str
    review_sha256:str
    raw_go:bytes=field(repr=False)
    raw_review:bytes=field(repr=False)
    _code:str=field(repr=False)
    _token:object=field(repr=False)
    _seal:object=field(repr=False)

    def __post_init__(self):
        if self._seal is not _SOURCE_SEAL:
            raise ValueError('FRESH_SEPARATE_LEGACY_SOURCE_SCOPE_SEAL_REQUIRED')

    def validate_current(self,*,year=None):
        if _ACTIVE_SOURCE.get(self._token) is not self or self._code != code_identity():
            raise ValueError('LIVE_CURRENT_LEGACY_SOURCE_SCOPE_REQUIRED')
        validate_source_authority_metadata(self.raw_go,self.source_go_sha256,self.raw_review,self.review_sha256)
        if year is not None:
            config.source_year(year)
        from legacy_source_guard import current_guard
        guard=current_guard()
        if guard is None or not guard.active:
            raise ValueError('WHOLE_INVOCATION_LEGACY_SOURCE_ONLY_GUARD_REQUIRED')
        guard.checkpoint('SOURCE_SCOPE_CHECK')
        return True

    def read_source(self,year,name,expected_sha256,expected_bytes=None):
        self.validate_current(year=year)
        name=c.relative(name)
        pin=contracts()['years'][str(year)]['read_files'].get(name)
        if (pin is None or pin['SHA256'] != expected_sha256
                or expected_bytes is not None and (type(expected_bytes) is not int or expected_bytes != pin['bytes'])):
            raise ValueError('EXACT_LEGACY_QUALIFIED_2023_SOURCE_READ_ALLOWLIST_REQUIRED')
        return c.exact(c.ROOT/name,expected_sha256,pin['bytes'])


@contextmanager
def admit_source_stage(go_raw,expected_go_sha256,review_raw,expected_review_sha256):
    value=validate_source_authority_metadata(go_raw,expected_go_sha256,review_raw,expected_review_sha256)
    from legacy_source_guard import current_guard
    guard=current_guard()
    if guard is None or not guard.active:
        raise ValueError('WHOLE_INVOCATION_LEGACY_SOURCE_ONLY_GUARD_REQUIRED')
    token=object()
    scope=LegacySourcePreparationScope(value['policy']['tranche'],expected_go_sha256,expected_review_sha256,
        go_raw,review_raw,code_identity(),token,_SOURCE_SEAL)
    _ACTIVE_SOURCE[token]=scope
    try:
        scope.validate_current()
        yield scope
    finally:
        _ACTIVE_SOURCE.pop(token,None)


def array_specs():
    days=config.source_year(2023)['days']
    return dict(decision_us=((days,),'int64'),annual_covariance=((days,5,5),'float64'),
        **{'intrinsic_'+recipe:((days,5),'float64') for recipe in config.RECIPES},
        **{recipe+'_'+tier:((days,5),'float64') for recipe in config.RECIPES for tier in config.TIERS})


def checked_array_identities(identities):
    import numpy as np
    if type(identities) is not dict or set(identities) != set(array_specs()):
        raise ValueError('EXACT_INTRINSIC_TARGET_COVARIANCE_ARRAY_NAMESPACE_REQUIRED')
    for key,(shape,dtype) in array_specs().items():
        identity=identities[key]
        if (type(identity) is not dict or set(identity) != {'dtype','shape','order','raw_bytes_SHA256','descriptor_and_bytes_SHA256'}
                or identity['dtype'] != np.dtype(dtype).str or identity['shape'] != list(shape) or identity['order']!='C'):
            raise ValueError('EXACT_PLAIN_DTYPE_ENDIAN_SHAPE_CBYTES_ARRAY_IDENTITY_REQUIRED')
        c.digest(identity['raw_bytes_SHA256']);c.digest(identity['descriptor_and_bytes_SHA256'])
    return identities


def binding_from_info(cell,info,source_go_sha,source_review_sha):
    if cell.get('cell_id') not in tranche_cells(FIRST6) or c.canonical(cell)!=c.canonical(config.cell_named(cell['cell_id'])):
        raise ValueError('EXACT_FIRST6_LEGACY_CELL_DESCRIPTOR_REQUIRED')
    contract=contracts()['years']['2023']; key=cell['recipe']+'_'+cell['tier']
    identities=checked_array_identities(info['array_identities'])
    return dict(schema='EXACT_LEGACY_INTRINSIC_CELL_SOURCE_TARGET_BINDING_V1',
        cell_id=cell['cell_id'],recipe=cell['recipe'],adaptation_version=config.VERSION,
        year=cell['year'],tier=cell['tier'],calendar=[cell['start_us'],cell['end_exclusive_us']],
        code_manifest_SHA256=code_identity(),scope_manifest_SHA256=manifest_sha(),
        source_contract_map_SHA256=contract_sha(),source_identity=contract['source_identity'],
        source_contract_SHA256=c.jsha(contract),pure_signal_review_SHA256=_SIGNAL_REVIEW,
        source_stage_GO_SHA256=c.digest(source_go_sha),source_review_SHA256=c.digest(source_review_sha),
        source_rows_SHA256=info['source_rows_SHA256'],funding_events_SHA256=info['funding_events_SHA256'],
        source_inputs_SHA256=info['source_inputs_SHA256'],
        source_quality_sidecar_SHA256=info['source_quality_sidecar_SHA256'],quality_cells_SHA256=c.jsha([]),
        provider_months=[[rec['path'],rec['start'],rec['count'],rec['hash'],rec['size'],rec['lo'],rec['hi']] for rec in contract['months']],
        decision_identity=identities['decision_us'],covariance_identity=identities['annual_covariance'],
        original_intrinsic_identity=identities['intrinsic_'+cell['recipe']],selected_target_identity=identities[key],
        preserves_complete_original_intrinsic_signal=True,downward_only=True,
        original_execution_unchanged=False,financial_reuse_allowed=False,
        cost='BASE27',policy_variant='GUARD50_EXIT_ONLY')


def validate_preparation_metadata(raw):
    value=c.exact_object(raw); ordered=tranche_cells(value.get('tranche'))
    fixed=dict(schema=PREPARATION_SCHEMA,candidate=config.CANDIDATE,adaptation_version=config.VERSION,
        ordered_cells=list(ordered),code_manifest_SHA256=code_identity(),scope_manifest_SHA256=manifest_sha(),
        source_contract_map_SHA256=contract_sha(),historical_admission=False,financial_runs=0,
        accounts_created=0,accounts_advanced=0,provider_iterations=0,process_launches=0,
        canonical_claims_created=0,real_financial_GO_written=0,publication_actions=0)
    allowed=set(fixed)|{'tranche','years','cells','source_stage_GO_SHA256','source_review_SHA256','artifacts'}
    if set(value)!=allowed:
        raise ValueError('EXACT_PREPARATION_TOP_LEVEL_SCHEMA_NO_EXTRA_AUTHORITY_FIELDS_REQUIRED')
    if any(c.canonical(value.get(k)) != c.canonical(v) for k,v in fixed.items()):
        raise ValueError('EXACT_SEPARATE_LEGACY_SOURCE_ONLY_PREPARATION_REQUIRED')
    if set(value.get('years',{})) != {'2023'} or set(value.get('cells',{})) != set(ordered):
        raise ValueError('EXACT_FIRST6_ONLY_YEAR_CELL_BINDINGS_REQUIRED')
    go=c.digest(value.get('source_stage_GO_SHA256')); review=c.digest(value.get('source_review_SHA256'))
    artifacts=value.get('artifacts')
    needed={'SOURCE_STAGE_AUTHORIZATION.json','SOURCE_INDEPENDENT_REVIEW.json'}|{
        '2023/'+n for n in ('TARGETS.npz','SOURCE_INPUTS.npz','SOURCE_ROWS.json','RAW_EVENTS.json','MINUTE_MARK_PROVENANCE.json','TARGET_PROOFS.json')}
    if type(artifacts) is not dict or set(artifacts) != needed:
        raise ValueError('EXACT_LEGACY_SOURCE_TARGET_ARTIFACT_NAMESPACE_REQUIRED')
    for name,pin in artifacts.items():
        c.relative(name)
        if type(pin) is not dict or set(pin) != {'SHA256','bytes'} or type(pin['bytes']) is not int or pin['bytes']<0:
            raise ValueError('EXACT_ARTIFACT_BYTE_PIN_REQUIRED')
        c.digest(pin['SHA256'])
    if (artifacts['SOURCE_STAGE_AUTHORIZATION.json']['SHA256']!=go
            or artifacts['SOURCE_INDEPENDENT_REVIEW.json']['SHA256']!=review):
        raise ValueError('EXACT_FRESH_SOURCE_GO_REVIEW_ARTIFACT_LINEAGE_REQUIRED')
    info=value['years']['2023']; period=config.source_year(2023); contract=contracts()['years']['2023']
    wanted=dict(source_identity=contract['source_identity'],source_contract_SHA256=c.jsha(contract),
        days=365,calendar=[period['start'],period['end']],quality_cells_SHA256=c.jsha([]),
        provider_months_source='EXISTING_PINNED_CANONICAL_MONTHS',all_legacy_position_and_event_impacts_pending=True)
    info_keys=set(wanted)|{'source_quality_sidecar_SHA256','source_inputs_SHA256','source_rows_SHA256','funding_events_SHA256','array_identities'}
    if type(info) is not dict or set(info)!=info_keys:
        raise ValueError('EXACT_YEAR_INFORMATION_SCHEMA_NO_EXTRA_AUTHORITY_FIELDS_REQUIRED')
    if any(c.canonical(info.get(k)) != c.canonical(v) for k,v in wanted.items()):
        raise ValueError('EXACT_2023_LEGACY_SOURCE_CALENDAR_QUALITY_LINEAGE_REQUIRED')
    checked_array_identities(info.get('array_identities'))
    for name,file in (('source_quality_sidecar_SHA256','MINUTE_MARK_PROVENANCE.json'),('source_inputs_SHA256','SOURCE_INPUTS.npz')):
        if c.digest(info.get(name)) != artifacts['2023/'+file]['SHA256']:
            raise ValueError('EXACT_SOURCE_INPUT_AND_QUALITY_ARTIFACT_BINDING_REQUIRED')
    for name in ('source_rows_SHA256','funding_events_SHA256'):
        c.digest(info.get(name))
    for cell_id in ordered:
        cell=value['cells'][cell_id];descriptor=config.cell_named(cell_id)
        if type(cell) is not dict or set(cell)!={'descriptor','input_binding','input_binding_SHA256'}:
            raise ValueError('EXACT_CELL_INFORMATION_SCHEMA_NO_EXTRA_AUTHORITY_FIELDS_REQUIRED')
        binding=binding_from_info(descriptor,info,go,review)
        if (c.canonical(cell.get('descriptor')) != c.canonical(descriptor)
                or c.canonical(cell.get('input_binding')) != c.canonical(binding)
                or c.jsha(binding) != cell.get('input_binding_SHA256')):
            raise ValueError('EXACT_RECIPE_YEAR_TIER_SOURCE_TARGET_REVIEW_GO_BINDING_REQUIRED')
    return value


@dataclass(frozen=True,slots=True)
class LegacyRecordingScope:
    cell_id:str
    binding_SHA256:str
    _token:object=field(repr=False)
    _seal:object=field(repr=False)

    def __post_init__(self):
        if self._seal is not _RECORD_SEAL:
            raise ValueError('ENTRY_OWNED_LEGACY_RECORDING_SCOPE_ONLY')

    def validate_current(self):
        if self._token not in _ACTIVE_RECORDING:
            raise ValueError('LEGACY_RECORDING_SCOPE_REVOKED')
        return True


def record_metadata_bindings(preparation,callback):
    preparation=validate_preparation_metadata(c.canonical(preparation))
    if not callable(callback):
        raise ValueError('EXPLICIT_SOURCE_ONLY_METADATA_CALLBACK_REQUIRED')
    returned=[]
    for cell_id in tranche_cells(preparation['tranche']):
        token=object();_ACTIVE_RECORDING.add(token)
        scope=LegacyRecordingScope(cell_id,preparation['cells'][cell_id]['input_binding_SHA256'],token,_RECORD_SEAL)
        try:
            scope.validate_current();callback(scope);returned.append(cell_id)
        finally:
            _ACTIVE_RECORDING.discard(token)
    return dict(ordered_cells=returned,metadata_scopes_revoked=not _ACTIVE_RECORDING,
        actual_source_scopes_created=0,historical_scopes_created=0,actual_provider_iterations=0,accounts_created=0)
