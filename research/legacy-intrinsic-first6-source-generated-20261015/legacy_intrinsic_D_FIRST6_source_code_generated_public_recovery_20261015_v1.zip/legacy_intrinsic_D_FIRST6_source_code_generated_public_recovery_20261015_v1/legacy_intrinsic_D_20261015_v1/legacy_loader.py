"""Source-only saved artifacts; no finance imports, token, provider or recapture."""
from dataclasses import dataclass, field
from pathlib import Path
from types import MappingProxyType
import numpy as np
import legacy_common as c
import legacy_codec as codec
import legacy_config as config
import legacy_entry as entry
import legacy_signal as signal

_SEAL=object()
_LIVE={}


@dataclass(frozen=True,slots=True)
class LoadedLegacyInputs:
    year:int
    preparation_raw:bytes=field(repr=False)
    arrays:object=field(repr=False)
    source_arrays:object=field(repr=False)
    captured_artifacts:object=field(repr=False)
    _token:object=field(repr=False)
    _seal:object=field(repr=False)

    def __post_init__(self):
        if self._seal is not _SEAL:
            raise ValueError('ENTRY_OWNED_SOURCE_ONLY_LOADED_LEGACY_INPUTS_REQUIRED')

    def validate(self):
        if _LIVE.get(self._token) is not self:
            raise ValueError('LIVE_SOURCE_ONLY_LOADED_LEGACY_INPUTS_REQUIRED')
        prep=entry.validate_preparation_metadata(self.preparation_raw);info=prep['years']['2023']
        if set(self.arrays)!=set(entry.array_specs()):
            raise ValueError('EXACT_SAVED_TARGET_ARRAY_NAMESPACE_REQUIRED')
        for key,value in self.arrays.items():
            if value.flags.writeable or c.canonical(signal.array_byte_identity(value))!=c.canonical(info['array_identities'][key]):
                raise ValueError('EXACT_IMMUTABLE_TARGET_DTYPE_ENDIAN_SHAPE_CBYTES_REQUIRED')
        for name,raw in self.captured_artifacts.items():
            pin=prep['artifacts'][name]
            if c.sha(raw)!=pin['SHA256'] or len(raw)!=pin['bytes']:
                raise ValueError('EXACT_IMMUTABLE_PREPARATION_ARTIFACTS_REQUIRED')
        if set(self.source_arrays)!={'close_available_us','close'}:
            raise ValueError('EXACT_SAVED_SOURCE_ARRAY_NAMESPACE_REQUIRED')
        if any(value.flags.writeable for value in self.source_arrays.values()):
            raise ValueError('IMMUTABLE_SAVED_SOURCE_ARRAYS_REQUIRED')
        saved=codec.npz(self.captured_artifacts['2023/SOURCE_INPUTS.npz'],{
            'close_available_us':((564,),'int64'),'close':((564,5),'float64')})
        if any(c.canonical(signal.array_byte_identity(saved[k]))!=c.canonical(signal.array_byte_identity(v)) for k,v in self.source_arrays.items()):
            raise ValueError('EXACT_CURRENT_SAVED_SOURCE_BITS_REQUIRED')
        return True


def decode_saved(preparation_raw,artifacts):
    """Pure generated/actual bytes validator; mints no loaded or actual scope."""
    prep=entry.validate_preparation_metadata(preparation_raw)
    if set(artifacts)!=set(prep['artifacts']):
        raise ValueError('EXACT_SAVED_ARTIFACT_NAMESPACE_REQUIRED')
    for name,raw in artifacts.items():
        pin=prep['artifacts'][name]
        if type(raw) is not bytes or c.sha(raw)!=pin['SHA256'] or len(raw)!=pin['bytes']:
            raise ValueError('EXACT_SAVED_SOURCE_TARGET_ARTIFACT_BYTES_REQUIRED')
    arrays=codec.npz(artifacts['2023/TARGETS.npz'],entry.array_specs())
    info=prep['years']['2023']
    for key,value in arrays.items():
        if not np.isfinite(value).all() or c.canonical(signal.array_byte_identity(value))!=c.canonical(info['array_identities'][key]):
            raise ValueError('EXACT_FINITE_TARGET_DTYPE_ENDIAN_SHAPE_RAW_BITS_REQUIRED')
    inputs=codec.npz(artifacts['2023/SOURCE_INPUTS.npz'],{'close_available_us':((564,),'int64'),'close':((564,5),'float64')})
    period=config.source_year(2023)
    if (not np.array_equal(inputs['close_available_us'],np.arange(period['warmup_start'],period['end'],config.DAY,dtype=np.int64))
            or not np.array_equal(arrays['decision_us'],np.arange(period['start'],period['end'],config.DAY,dtype=np.int64))
            or not np.isfinite(inputs['close']).all() or (inputs['close']<=0).any()):
        raise ValueError('EXACT_FULL_CALENDAR_PAST_ONLY_SOURCE_CLOSURE_REQUIRED')
    rows=c.object_json(artifacts['2023/SOURCE_ROWS.json']);events=c.object_json(artifacts['2023/RAW_EVENTS.json'])
    if c.jsha(rows)!=info['source_rows_SHA256'] or c.jsha(events)!=info['funding_events_SHA256']:
        raise ValueError('EXACT_SOURCE_ROWS_AND_FUNDING_BITS_REQUIRED')
    expected_rows=[dict(symbol=symbol,close_us=int(at),available_us=int(at),close=float(inputs['close'][i,j]))
        for i,at in enumerate(inputs['close_available_us']) for j,symbol in enumerate(config.SYMBOLS)]
    if c.canonical(rows)!=c.canonical(expected_rows):
        raise ValueError('EXACT_SAVED_DAILY_ARRAY_SOURCE_ROW_PARITY_REQUIRED')
    return arrays,inputs


def load_year(preparation_root,*,expected_preparation_sha256,year,source_go_raw,expected_source_go_sha256,
              source_review_raw,expected_source_review_sha256):
    config.source_year(year)
    entry.validate_source_authority_metadata(source_go_raw,expected_source_go_sha256,source_review_raw,expected_source_review_sha256)
    from legacy_source_guard import current_guard
    guard=current_guard()
    if guard is None or not guard.active:
        raise ValueError('WHOLE_INVOCATION_LEGACY_SOURCE_ONLY_GUARD_REQUIRED')
    root=Path(preparation_root).absolute()
    if root.is_symlink() or any(p.is_symlink() for p in root.parents):
        raise ValueError('ORDINARY_NOFOLLOW_LEGACY_PREPARATION_DIRECTORY_REQUIRED')
    raw=c.exact(root/'PREPARATION.json',expected_preparation_sha256)
    prep=entry.validate_preparation_metadata(raw)
    if (prep['source_stage_GO_SHA256']!=expected_source_go_sha256 or prep['source_review_SHA256']!=expected_source_review_sha256):
        raise ValueError('EXACT_EXTERNAL_FRESH_LEGACY_SOURCE_LINEAGE_REQUIRED')
    artifacts={name:c.exact(root/c.relative(name),pin['SHA256'],pin['bytes']) for name,pin in prep['artifacts'].items()}
    if artifacts['SOURCE_STAGE_AUTHORIZATION.json']!=source_go_raw or artifacts['SOURCE_INDEPENDENT_REVIEW.json']!=source_review_raw:
        raise ValueError('EXACT_SOURCE_GO_AND_REVIEW_BODY_BINDING_REQUIRED')
    arrays,inputs=decode_saved(raw,artifacts)
    token=object();loaded=LoadedLegacyInputs(year,raw,MappingProxyType(arrays),MappingProxyType(inputs),MappingProxyType(artifacts),token,_SEAL)
    _LIVE[token]=loaded
    try:
        loaded.validate()
    except BaseException:
        _LIVE.pop(token,None)
        raise
    return loaded


def revoke(loaded):
    if type(loaded) is not LoadedLegacyInputs or _LIVE.get(loaded._token) is not loaded:
        raise ValueError('LIVE_SOURCE_ONLY_LOADED_LEGACY_INPUTS_REQUIRED')
    _LIVE.pop(loaded._token)
