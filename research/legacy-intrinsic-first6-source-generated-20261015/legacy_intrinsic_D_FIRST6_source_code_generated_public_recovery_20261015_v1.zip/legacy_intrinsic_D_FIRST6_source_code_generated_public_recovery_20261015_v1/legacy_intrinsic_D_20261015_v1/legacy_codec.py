"""Shared pure generated/actual source codecs; no filename/provider API."""
from io import BytesIO
import stat
from types import MappingProxyType
import zipfile

import numpy as np

import legacy_common as c
from legacy_config import source_year as period_named, DAY
from legacy_config import SYMBOLS as S

MINUTE = 60_000_000
FIELDS = ('open', 'close', 'quote_volume', 'mark')


def frozen_array(a):
    a = np.asarray(a)
    from legacy_signal import supported_array
    a = supported_array(a)
    return np.frombuffer(a.tobytes(order='C'), dtype=a.dtype).reshape(a.shape)


def npz(raw, specs, *, allow_unselected=False):
    """Bound and validate selected NPY headers before allocating a payload."""
    if type(raw) is not bytes or type(allow_unselected) is not bool:
        raise ValueError('EXACT_NUMERIC_CONTAINER_BYTES_REQUIRED')
    try:
        with zipfile.ZipFile(BytesIO(raw)) as archive:
            infos = archive.infolist(); names = [row.filename for row in infos]
            selected = {key + '.npy' for key in specs}
            if (len(names) != len(set(names)) or not selected <= set(names)
                    or not allow_unselected and selected != set(names)):
                raise ValueError('EXACT_ARRAY_MEMBER_NAMESPACE_REQUIRED')
            for info in infos:
                if (info.is_dir() or info.flag_bits & 1 or stat.S_ISLNK(info.external_attr >> 16)
                        or '/' in info.filename or '\\' in info.filename or not info.filename.endswith('.npy')):
                    raise ValueError('ORDINARY_FLAT_NUMERIC_MEMBERS_REQUIRED')
                if info.filename not in selected:
                    continue  # Never decompress unrelated stored DEV members.
                key = info.filename[:-4]; shape, dtype_spec = specs[key]
                if info.file_size > 8 * 1024 * 1024:
                    raise ValueError('BOUNDED_NUMERIC_MEMBER_REQUIRED')
                with archive.open(info) as stream:
                    version = np.lib.format.read_magic(stream)
                    if version not in ((1, 0), (2, 0)):
                        raise ValueError('SUPPORTED_NPY_HEADER_REQUIRED')
                    reader = np.lib.format.read_array_header_1_0 if version == (1, 0) else np.lib.format.read_array_header_2_0
                    actual_shape, fortran, dtype = reader(stream, max_header_size=4096)
                    valid_dtype = (dtype.kind == 'U' and 0 < dtype.itemsize <= 128
                                   if dtype_spec == 'SYMBOLS' else dtype == np.dtype(dtype_spec))
                    if actual_shape != shape or dtype.fields is not None or dtype.subdtype is not None or dtype.hasobject or fortran or not valid_dtype:
                        raise ValueError('EXACT_NUMERIC_HEADER_SCHEMA_REQUIRED')
                    if stream.tell() + int(np.prod(shape)) * dtype.itemsize != info.file_size:
                        raise ValueError('EXACT_NUMERIC_PAYLOAD_LENGTH_REQUIRED')
        with np.load(BytesIO(raw), allow_pickle=False) as arrays:
            return {key: (np.frombuffer(arrays[key].tobytes(order='C'), dtype=arrays[key].dtype).reshape(arrays[key].shape)
                          if specs[key][1] == 'SYMBOLS' else frozen_array(arrays[key])) for key in specs}
    except (zipfile.BadZipFile, EOFError, OSError) as exc:
        raise ValueError('VALID_NUMERIC_ARCHIVE_REQUIRED') from exc


STORED_DAILY = {2023:(565,1655337600000000,1704067200000000)}


def daily_inputs(year,warm_raw,daily_raw=None):
    period=period_named(year);rows,first,last=STORED_DAILY[year]
    a=npz(warm_raw,{'close_available_us':((rows,),'int64'),'close':((rows,5),'float64')})
    times,close=a['close_available_us'],a['close']
    if not np.array_equal(times,np.arange(first,last+DAY,DAY,dtype=np.int64)):
        raise ValueError('EXACT_ORIGINAL_2023_DAILY_CLOCK_REQUIRED')
    # Preserve existing 2023 codec: the stored end-boundary row is excluded
    # before any target, covariance or other strategy statistic.
    use=(times>=period['warmup_start'])&(times<period['end'])
    times,close=times[use],close[use]
    expected=np.arange(period['warmup_start'],period['end'],DAY,dtype=np.int64)
    if (not np.array_equal(times,expected) or close.shape!=(period['days']+199,5)
            or not np.isfinite(close).all() or (close<=0).any()):
        raise ValueError('EXACT_COMPLETE_PAST_ONLY_200_CLOSE_UNION_REQUIRED')
    decisions=np.arange(period['start'],period['end'],DAY,dtype=np.int64)
    return tuple(frozen_array(value) for value in (times,close,decisions))


def month_arrays(year,raw,start,count,quality_cells=()):
    period_named(year)
    if type(start) is not int or type(count) is not int or not 0<count<=44640:
        raise ValueError('BOUNDED_NATIVE_MONTH_CLOCK_REQUIRED')
    if quality_cells:
        raise ValueError('NO_2023_DERIVED_MARK_CELLS_ALLOWED')
    specs={'times':((count,),'int64')}
    specs.update({symbol+'_'+field:((count,),'float64') for symbol in S for field in FIELDS})
    a=npz(raw,specs)
    if not np.array_equal(a['times'],np.arange(start,start+count*MINUTE,MINUTE,dtype=np.int64)):
        raise ValueError('EXACT_NATIVE_OPEN_AND_COMPLETION_CLOCKS_REQUIRED')
    for symbol in S:
        for field in FIELDS:
            value=a[symbol+'_'+field]
            if (not np.isfinite(value).all() or (value<0).any()
                    or field!='quote_volume' and (value<=0).any()):
                raise ValueError('POSITIVE_GENUINE_2023_NATIVE_VALUES_REQUIRED')
    return MappingProxyType(a),()
