"""Generated-only source, exact recipe gate, mutation and callback negatives."""
from copy import deepcopy
from io import BytesIO
import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest.mock import patch
import zipfile
import numpy as np
import legacy_common as c
import legacy_codec as codec
import legacy_config as config
import legacy_entry as entry
import legacy_generated as generated
import legacy_loader as loader
import legacy_signal as signal
import legacy_source as source
from legacy_source_guard import SourceOnlyGuard,SourceBoundaryViolation


class SourceCodecTests(unittest.TestCase):
    def test_2023_exact_daily_namespace_and_endpoint_exclusion(self):
        a=generated.daily();t,p,d=codec.daily_inputs(2023,generated.pack(**a))
        self.assertEqual((len(t),len(d)),(564,365));self.assertFalse(p.flags.writeable)
        a['close'][-1]*=2
        tt,pp,dd=codec.daily_inputs(2023,generated.pack(**a))
        for left,right in ((t,tt),(p,pp),(d,dd)):
            self.assertEqual(left.tobytes(),right.tobytes())

    def test_closed_other24_and_holdout_years(self):
        self.assertEqual(len(config.cells()),30);self.assertEqual(len(entry.tranche_cells(entry.FIRST6)),6)
        for year in (2021,2022,2024,2025,2026,2017,True,'2023'):
            with self.assertRaises(ValueError): codec.daily_inputs(year,b'')
            with self.assertRaises(ValueError): source.funding_events(year,b'[]',{})
        self.assertEqual(config.period_named(2021)['days'],274)
        self.assertEqual(config.period_named(2024)['days'],366)

    def test_wrong_numeric_header_clock_and_nonfinite(self):
        a=generated.daily()
        for key,value in (('close',a['close'].astype('float32')),('close_available_us',a['close_available_us'].astype('uint64')),
                          ('close',a['close'].astype('>f8'))):
            b=dict(a);b[key]=value
            with self.assertRaises(ValueError):codec.daily_inputs(2023,generated.pack(**b))
        for field,offset in (('close',np.nan),('close_available_us',1)):
            b={k:v.copy() for k,v in a.items()};b[field].flat[3]=offset
            with self.assertRaises(ValueError):codec.daily_inputs(2023,generated.pack(**b))

    def test_unsupported_dtypes_reject_before_generic_identity_I01(self):
        dtypes=[object,'V16',[('x','f8'),('y','f8')],[('x','i8'),('y','i8')], 'f4','c16','U4','M8[ns]','u8']
        with patch.object(signal,'reviewed_signal',side_effect=AssertionError('GENERIC_IDENTITY_MUST_NOT_RUN')):
            for dtype in dtypes:
                with self.subTest(dtype=dtype):
                    with self.assertRaisesRegex(ValueError,'UNSUPPORTED_DTYPE'):signal.array_byte_identity(np.zeros(3,dtype=dtype))

    def test_identity_preserves_exact_endian_shape_cbytes_and_signed_zero(self):
        a=np.array([1.,-0.],dtype='<f8');b=a.astype('>f8')
        self.assertNotEqual(signal.array_byte_identity(a),signal.array_byte_identity(b))
        self.assertNotEqual(signal.array_byte_identity(a),signal.array_byte_identity(a.reshape(1,2)))
        self.assertNotEqual(signal.array_byte_identity(a),signal.array_byte_identity(np.array([1.,0.])))
        z=signal.immutable_array(a)
        with self.assertRaises(ValueError):z.setflags(write=True)

    def test_zip_duplicate_member_truncation_structured_and_fortran_reject_before_payload(self):
        for value in (np.zeros(4,dtype='V16'),np.zeros(4,dtype=[('x','f8'),('y','f8')]),
                      np.zeros(4,dtype=object),np.asfortranarray(np.ones((2,2)))):
            with patch.object(np,'load',side_effect=AssertionError('HEADER_FIRST')):
                with self.assertRaises(ValueError):codec.npz(generated.pack(x=value),{'x':((4,),'float64')})
        out=BytesIO();np.save(out,np.ones(4),allow_pickle=False)
        for payloads in ((out.getvalue(),out.getvalue()),(out.getvalue()[:-1],)):
            z=BytesIO()
            with zipfile.ZipFile(z,'w') as archive:
                for raw in payloads:archive.writestr('x.npy',raw)
            with patch.object(np,'load',side_effect=AssertionError('HEADER_FIRST')):
                with self.assertRaises(ValueError):codec.npz(z.getvalue(),{'x':((4,),'float64')})

    def test_funding_exact_schema_signed_raw_interval_and_order(self):
        start=config.source_year(2023)['start'];contract={'events':{'selected_events':2}}
        rows=[dict(symbol=s,event_us=start,raw_rate=r,reported_interval_hours=8) for s,r in (('BTCUSDT',-.0001),('ETHUSDT',.0002))]
        out=source.funding_events(2023,c.canonical(rows),contract)
        self.assertEqual(out[0]['raw_rate'],-.0001)
        for field,value in (('reported_interval_hours',True),('reported_interval_hours',float('inf')),
            ('reported_interval_hours',0),('reported_interval_hours',-8),('reported_interval_hours','8'),
            ('reported_interval_hours',4),('raw_rate',True),('raw_rate',float('nan')),('event_us',True),('symbol','BNBUSDT')):
            bad=deepcopy(rows);bad[0][field]=value
            with self.assertRaises(ValueError):source.funding_events(2023,json.dumps(bad).encode(),contract)
        for bad in (rows[::-1],[rows[0],rows[0]],rows+[dict(rows[0])]):
            with self.assertRaises(ValueError):source.funding_events(2023,c.canonical(bad),contract)
        bad=deepcopy(rows);bad[0]['raw_rate_unit']='CERTIFIED'
        with self.assertRaises(ValueError):source.funding_events(2023,c.canonical(bad),contract)

    def test_2023_month_shapes_immutability_and_nonpositive_mark(self):
        start=config.source_year(2023)['start'];count=4
        a={'times':np.arange(start,start+count*codec.MINUTE,codec.MINUTE,dtype='int64')}
        a.update({s+'_'+f:np.ones(count,dtype='float64') for s in config.SYMBOLS for f in codec.FIELDS})
        projected,missing=codec.month_arrays(2023,generated.pack(**a),start,count)
        self.assertFalse(missing)
        for value in projected.values():
            with self.assertRaises(ValueError):value.setflags(write=True)
        a['BTCUSDT_mark'][0]=np.nan
        with self.assertRaises(ValueError):codec.month_arrays(2023,generated.pack(**a),start,count)


class GateAndTargetTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.prep,cls.artifacts,cls.arrays=generated.fixture()
        cls.go,cls.go_sha,cls.review,cls.review_sha=generated.authority()

    def test_metadata_only_first6_source_authority_and_full30_cells(self):
        entry.validate_source_authority_metadata(self.go,self.go_sha,self.review,self.review_sha)
        self.assertEqual(len(entry.manifest()['cells']),30)
        self.assertFalse(entry._ACTIVE_SOURCE)

    def test_old_CS_core_plain_baseline_review_or_GO_wrong_namespace_reject(self):
        go=c.exact_object(self.go);review=c.exact_object(self.review)
        for schema in ('ROOT_SOURCE_TARGET_CSMOM21_COMMON_TIER_V2','ROOT_FINANCIAL_CSMOM21_COMMON_TIER_V2','ROOT_GO_LEGACY_BASELINE','ROOT_CORE_D'):
            bad=dict(go,schema=schema);raw=c.canonical(bad)
            with self.assertRaises(ValueError):entry.validate_source_authority_metadata(raw,c.sha(raw),self.review,self.review_sha)
            raw=c.canonical(dict(review,schema=schema))
            with self.assertRaises(ValueError):entry.validate_source_authority_metadata(self.go,self.go_sha,raw,c.sha(raw))

    def test_wrong_external_digest_recipe_year_cell_review_and_permissions_reject(self):
        with self.assertRaises(ValueError):entry.validate_source_authority_metadata(self.go,'0'*64,self.review,self.review_sha)
        with self.assertRaises(ValueError):entry.validate_source_authority_metadata(self.go,self.go_sha,self.review,'0'*64)
        go=c.exact_object(self.go)
        for key,value in (('years',[2024]),('ordered_cells',go['ordered_cells'][:-1]),
            ('candidate','CSMOM21_COMMON_TIER'),('adaptation_version','PLAIN_V3'),
            ('historical_execution_authorized',True),('account_construction_authorized',True),
            ('financial_execution_authorized',True),('other24_cells_source_authorized',True),
            ('old_CS_core_D_or_legacy_baseline_authority_reused',True)):
            raw=c.canonical(dict(go,**{key:value}))
            with self.assertRaises(ValueError):entry.validate_source_authority_metadata(raw,c.sha(raw),self.review,self.review_sha)

    def test_no_source_scope_without_guard_and_no_foreign_scope_or_forged_seal(self):
        with self.assertRaisesRegex(ValueError,'GUARD'):
            with entry.admit_source_stage(self.go,self.go_sha,self.review,self.review_sha):pass
        with self.assertRaises(ValueError):source.capture_year(2023,object())
        with self.assertRaises(ValueError):entry.LegacySourcePreparationScope(entry.FIRST6,self.go_sha,self.review_sha,self.go,self.review,entry.code_identity(),object(),object())
        self.assertFalse(entry._ACTIVE_SOURCE)

    def test_preparation_and_all_six_source_only_callbacks_revoke(self):
        entry.validate_preparation_metadata(c.canonical(self.prep));seen=[]
        result=entry.record_metadata_bindings(self.prep,lambda scope:(scope.validate_current(),seen.append(scope)))
        self.assertEqual(result['ordered_cells'],list(entry.tranche_cells(entry.FIRST6)))
        self.assertEqual(len(seen),6);self.assertFalse(entry._ACTIVE_SOURCE);self.assertFalse(entry._ACTIVE_RECORDING)
        for scope in seen:
            with self.assertRaises(ValueError):scope.validate_current()

    def test_missing_callback_and_callback_error_revoke(self):
        with self.assertRaises(ValueError):entry.record_metadata_bindings(self.prep,None)
        with self.assertRaisesRegex(RuntimeError,'CALLBACK_STOP'):
            entry.record_metadata_bindings(self.prep,lambda scope:(_ for _ in ()).throw(RuntimeError('CALLBACK_STOP')))
        self.assertFalse(entry._ACTIVE_RECORDING)

    def test_preparation_cell_recipe_year_tier_source_review_hash_target_identity_mutations(self):
        cell_id=entry.tranche_cells(entry.FIRST6)[0]
        paths=[('cells',cell_id,'descriptor','recipe'),('cells',cell_id,'descriptor','tier'),
            ('cells',cell_id,'descriptor','year'),('cells',cell_id,'input_binding','source_review_SHA256'),
            ('cells',cell_id,'input_binding','source_stage_GO_SHA256'),
            ('cells',cell_id,'input_binding','source_identity'),('cells',cell_id,'input_binding_SHA256'),
            ('years','2023','array_identities','annual_covariance','dtype'),
            ('years','2023','array_identities','annual_covariance','shape')]
        for path in paths:
            bad=deepcopy(self.prep);obj=bad
            for key in path[:-1]:obj=obj[key]
            obj[path[-1]]='MUTATED'
            with self.assertRaises(ValueError):entry.validate_preparation_metadata(c.canonical(bad))

    def test_pure_saved_decoding_target_bytes_dtype_and_quality_mutation_reject(self):
        arrays,inputs=loader.decode_saved(c.canonical(self.prep),self.artifacts)
        self.assertEqual(set(arrays),set(entry.array_specs()));self.assertFalse(inputs['close'].flags.writeable)
        for name in ('2023/TARGETS.npz','2023/MINUTE_MARK_PROVENANCE.json','SOURCE_INDEPENDENT_REVIEW.json'):
            bad=dict(self.artifacts);bad[name]+=b'X'
            with self.assertRaises(ValueError):loader.decode_saved(c.canonical(self.prep),bad)
        # Even self-consistent container pins cannot replace bound target raw identity.
        changed={k:v.copy() for k,v in self.arrays.items()};key=config.RECIPES[0]+'_LOW';changed[key][0,0]=np.nextafter(changed[key][0,0],1.)
        bad=dict(self.artifacts);bad['2023/TARGETS.npz']=generated.pack(**changed)
        prep=deepcopy(self.prep);prep['artifacts']['2023/TARGETS.npz']=dict(SHA256=c.sha(bad['2023/TARGETS.npz']),bytes=len(bad['2023/TARGETS.npz']))
        with self.assertRaisesRegex(ValueError,'RAW_BITS'):loader.decode_saved(c.canonical(prep),bad)

    def test_generated_targets_exact_original_intrinsic_and_lower_only(self):
        a=generated.daily();clocks=a['close_available_us'][:-1];close=a['close'][:-1]
        math=signal.reviewed_signal()._legacy_math()
        d,targets,cov,proofs=math.build_target_grid(close,clocks,clocks,self.arrays['decision_us'],symbols=config.SYMBOLS)
        self.assertEqual(cov.tobytes(),self.arrays['annual_covariance'].tobytes())
        for key,value in targets.items():self.assertEqual(value.tobytes(),self.arrays[key].tobytes())
        for recipe in config.RECIPES:
            intrinsic=np.asarray([p['intrinsic'][recipe] for p in proofs],dtype='float64')
            self.assertEqual(intrinsic.tobytes(),self.arrays['intrinsic_'+recipe].tobytes())
            for tier in config.TIERS:
                self.assertTrue((np.abs(self.arrays[recipe+'_'+tier])<=np.abs(intrinsic)+1e-15).all())
                self.assertTrue((self.arrays[recipe+'_'+tier][intrinsic==0]==0).all())

    def test_generated_projection_under_guard_zero_forbidden_attempts(self):
        a=generated.daily();t=a['close_available_us'][:-1];close=a['close'][:-1]
        guard=SourceOnlyGuard(read_paths=generated.read_paths())
        with guard:
            signal.build_target_grid(close,t,t,self.arrays['decision_us'][:2])
            entry.record_metadata_bindings(self.prep,lambda scope:scope.validate_current())
            guard.checkpoint('GENERATED_ONLY_CALLBACKS')
        self.assertFalse(any(guard.attempts.values()));self.assertFalse(entry._ACTIVE_SOURCE)
        generated.observed_guard_receipts.append(guard.receipt('PASS_CLEAN_GENERATED_GUARDED_RUN'))

    def test_wrong_output_no_capture_and_exact_path_symlink_bytes(self):
        guard=SourceOnlyGuard(read_paths=generated.read_paths())
        with guard,patch.object(source,'capture_year',side_effect=AssertionError('NO_CAPTURE')):
            for output in (c.HERE/'wrong','/tmp/not_legacy_attempt'):
                with self.assertRaises(ValueError):source.prepare_source_only(output,source_go_raw=self.go,
                    expected_source_go_sha256=self.go_sha,review_raw=self.review,expected_review_sha256=self.review_sha)
        with tempfile.TemporaryDirectory(dir=c.HERE) as td:
            td=Path(td);p=td/'CODE.py';p.write_bytes(b'code');link=td/'link';link.symlink_to(p)
            with self.assertRaises(ValueError):c.exact(link,c.sha(b'code'))
            with self.assertRaises(ValueError):c.exact(p,'0'*64)
            with self.assertRaises(ValueError):c.exact(p,c.sha(b'code'),99)
        for name in ('../escape','/abs','a/../b','a\\b','a//b'):
            with self.assertRaises(ValueError):c.relative(name)


class BoundaryTests(unittest.TestCase):
    def forbidden(self,fn,category):
        guard=SourceOnlyGuard(read_paths=generated.read_paths(),write_roots=(c.HERE/'GENERATED_WRITE_ONLY',))
        with self.assertRaises(SourceBoundaryViolation):
            with guard:fn(guard)
        self.assertGreater(guard.attempts[category],0)
        generated.observed_guard_receipts.append(guard.receipt('EXPECTED_NEGATIVE_CONTROL'))
        return guard

    def test_process_network_claim_and_financial_GO_write_blocks(self):
        import subprocess,socket,fcntl
        for fn,category in ((lambda g:subprocess.run(['false']),'process_launches'),
            (lambda g:os.system('false'),'process_launches'),
            (lambda g:socket.getaddrinfo('example.com',443),'network_calls'),
            (lambda g:fcntl.flock(0,fcntl.LOCK_EX),'canonical_financial_claims_or_leases'),
            (lambda g:(c.HERE/'EXECUTION_CLAIMS'/'x').open('w'),'canonical_financial_claims_or_leases'),
            (lambda g:(c.HERE/'GENERATED_WRITE_ONLY'/'FINANCIAL_GO.json').open('w'),'financial_GO_writes'),
            (lambda g:json.dumps(dict(schema='ROOT_FINANCIAL_AUTHORIZATION',financial_execution_authorized=True)),'financial_GO_writes'),
            (lambda g:(c.HERE/'not_allowlisted').read_bytes(),'nonallowlisted_file_reads')):
            self.forbidden(fn,category)

    def test_financial_import_direct_loader_and_foreign_CS_scope_blocks(self):
        for name in ('legacy_native','run_legacy','cs_entry','cs_admission','cs_loader','traditional_D_full2022_20261015_v2'):
            self.forbidden(lambda g,name=name:__import__(name),'financial_imports')
        self.forbidden(lambda g:importlib.util.spec_from_file_location('x','/tmp/x.py'),'financial_imports')

    def test_preloaded_captured_finance_provider_and_historical_scope_stop(self):
        for name in ('FakeAccount','FakeSimulator','FakeProvider','FreshHistoricalExecutionScope'):
            fake=types.ModuleType('_generated_boundary');fake.__source_guard_fixture__=True
            setattr(fake,name,type(name,(),{}));sys.modules[fake.__name__]=fake
            try:
                self.forbidden(lambda g:None,'financial_imports')
            finally:sys.modules.pop(fake.__name__,None)

    def test_dynamic_constructor_advance_provider_historical_and_simulator_blockers(self):
        # Register fixture only after clean entry; no actual implementation imported.
        fake=types.ModuleType('_generated_boundary');fake.__source_guard_fixture__=True
        for name,method,category in (('FakeAccount','__init__','financial_constructors'),
            ('FakeAccount','advance_day','financial_account_advance'),
            ('FakeSimulator','__init__','native_simulator_construct_or_advance'),
            ('FakeProvider','__iter__','actual_provider_calls'),
            ('FreshHistoricalExecutionScope','__init__','historical_scope_mints')):
            cls=type(name,(),{method:lambda *a,**k:None});setattr(fake,name,cls)
            def attempt(guard):
                sys.modules[fake.__name__]=fake
                guard._discover_loaded_boundaries()
                getattr(cls,method)(object())
            try:self.forbidden(attempt,category)
            finally:
                sys.modules.pop(fake.__name__,None);delattr(fake,name)

    def test_caught_attempt_remains_fatal_and_scope_mints_stay_zero(self):
        def attempt(guard):
            try:__import__('legacy_native')
            except SourceBoundaryViolation:pass
        self.forbidden(attempt,'financial_imports')
        self.assertFalse(entry._ACTIVE_SOURCE);self.assertFalse(entry._ACTIVE_RECORDING);self.assertFalse(loader._LIVE)


class GeneratedAssemblyAndLoaderTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.prep,cls.artifacts,cls.arrays=generated.fixture()

    def synthetic_annual_source(self):
        period=config.source_year(2023)
        clock=np.arange(period['warmup_start'],period['end']+config.DAY,config.DAY,dtype='int64')
        warm=generated.pack(close_available_us=clock,close=np.tile(np.arange(100.,105.),(len(clock),1)))
        daily=[dict(symbol=s,close_us=int(at),close=100.+j) for at in clock[199:-1] for j,s in enumerate(config.SYMBOLS)]
        month_count=365*1440
        # Bounded pure assembly fixture splits the full calendar into 365 one-day
        # containers. No source path is opened and no scope is minted.
        recs=[];months=[]
        for i,at in enumerate(clock[199:-1]):
            a={'times':np.arange(at,at+config.DAY,codec.MINUTE,dtype='int64')}
            a.update({s+'_'+f:np.full(1440,100.+j,dtype='float64') for j,s in enumerate(config.SYMBOLS) for f in codec.FIELDS})
            blob=generated.pack(**a);name=f'GENERATED_DAY_{i:03d}.npz'
            recs.append(dict(path=name,start=int(at),count=1440,lo=0,hi=1440,hash=c.sha(blob),size=len(blob)))
            months.append((name,blob))
        quality={'schema':'GENERATED_ORIGINAL200_ONLY','provider_arrival_certified':False}
        contract=dict(events={'selected_events':0},quality_intervals=[],derived_mark_cells=0,
            quality_summary=quality,source_identity='a'*64,months=recs)
        return warm,c.canonical(daily),b'[]',c.canonical({'original200_quality':quality}),tuple(months),contract

    def test_generated_full_calendar_assembly_no_scope_and_exact_quality(self):
        args=self.synthetic_annual_source()
        inputs=source.assemble_inputs(2023,*args)
        self.assertEqual(len(inputs['decisions']),365);self.assertEqual(inputs['close'].shape,(564,5))
        self.assertEqual(inputs['sidecar']['derived_mark_cells'],0)
        self.assertFalse(inputs['sidecar']['certifies_no_liquidation']);self.assertFalse(entry._ACTIVE_SOURCE)
        bad=list(args);bad[3]=c.canonical({'original200_quality':{'WRONG':True}})
        with self.assertRaisesRegex(ValueError,'QUALITY_LINEAGE'):source.assemble_inputs(2023,*bad)
        bad=list(args);bad[4]=tuple(reversed(args[4]))
        with self.assertRaisesRegex(ValueError,'MONTH_IDENTITY'):source.assemble_inputs(2023,*bad)
        bad=list(args);bad[5]=dict(args[5],derived_mark_cells=1)
        with self.assertRaisesRegex(ValueError,'ZERO_DERIVED'):source.assemble_inputs(2023,*bad)
        bad=list(args);daily=c.object_json(args[1]);daily[5]['close']+=1;bad[1]=c.canonical(daily)
        with self.assertRaisesRegex(ValueError,'BIT_PARITY'):source.assemble_inputs(2023,*bad)

    def test_generated_loaded_type_seal_immutability_revoke_and_target_mutation(self):
        arrays,inputs=loader.decode_saved(c.canonical(self.prep),self.artifacts)
        token=object()
        from types import MappingProxyType
        loaded=loader.LoadedLegacyInputs(2023,c.canonical(self.prep),MappingProxyType(arrays),
            MappingProxyType(inputs),MappingProxyType(self.artifacts),token,loader._SEAL)
        loader._LIVE[token]=loaded
        try:
            self.assertTrue(loaded.validate())
            for value in arrays.values():
                with self.assertRaises(ValueError):value.setflags(write=True)
            changed=dict(arrays);key=config.RECIPES[0]+'_LOW';new=changed[key].copy();new[0,0]=np.nextafter(new[0,0],1.)
            changed[key]=signal.immutable_array(new)
            altered=loader.LoadedLegacyInputs(2023,c.canonical(self.prep),MappingProxyType(changed),
                MappingProxyType(inputs),MappingProxyType(self.artifacts),token,loader._SEAL)
            loader._LIVE[token]=altered
            with self.assertRaisesRegex(ValueError,'CBYTES'):altered.validate()
            loader._LIVE[token]=loaded;loader.revoke(loaded)
            with self.assertRaises(ValueError):loaded.validate()
            with self.assertRaises(ValueError):loader.revoke(loaded)
        finally:loader._LIVE.pop(token,None)
        with self.assertRaises(ValueError):loader.LoadedLegacyInputs(2023,b'',{}, {},{},object(),object())
        self.assertFalse(entry._ACTIVE_SOURCE)

    def test_code_dependency_and_manifest_mutation_symlink_missing_rejection(self):
        manifest=c.exact_object(c.ordinary(c.HERE/'CODE_MANIFEST.json'))
        target=next(iter(manifest['dependencies']))
        original=c.exact
        def changed(path,*args,**kwargs):
            if str(path)==str(c.ROOT/target):raise ValueError('GENERATED_DEPENDENCY_MUTATION')
            return original(path,*args,**kwargs)
        with patch.object(c,'exact',side_effect=changed):
            with self.assertRaisesRegex(ValueError,'DEPENDENCY_MUTATION'):entry.code_identity()
        # Path checks use only brand-new synthetic code files.
        with tempfile.TemporaryDirectory(dir=c.HERE) as td:
            td=Path(td);p=td/'file.py';p.write_bytes(b'x');d=td/'d';d.mkdir();(d/'file.py').write_bytes(b'x')
            link=td/'linked_parent';link.symlink_to(d,target_is_directory=True)
            with self.assertRaises(ValueError):c.exact(link/'file.py',c.sha(b'x'))
            with self.assertRaises(FileNotFoundError):c.exact(td/'missing.py',c.sha(b'x'))

class CliAndScopeSafetyTests(unittest.TestCase):
    def test_cli_generated_stop_persists_receipt_before_any_source_scope(self):
        import prepare_legacy_source as cli
        import shutil
        go,go_sha,review,review_sha=generated.authority()
        output=c.HERE/'source_attempts'/'GENERATED_STOP_TEST_ONLY'
        if output.exists():raise AssertionError('EXCLUSIVE_GENERATED_TEST_OUTPUT_REQUIRED')
        try:
            with tempfile.TemporaryDirectory(dir=c.HERE) as td:
                td=Path(td);gp=td/'GENERATED_AUTHORIZATION.json';rp=td/'GENERATED_REVIEW.json'
                gp.write_bytes(go);rp.write_bytes(review)
                argv=['prepare_legacy_source.py','--output',str(output),'--source-go',str(gp),'--source-go-sha',go_sha,
                    '--source-review',str(rp),'--source-review-sha',review_sha,'--cpu','0']
                with patch.object(sys,'argv',argv),patch.object(cli.resource,'setrlimit'),patch.object(cli.signal,'signal'), \
                    patch.object(cli.signal,'alarm'),patch.object(os,'sched_getaffinity',return_value={0}), \
                    patch.object(os,'sched_setaffinity'),patch.object(source,'prepare_source_only',side_effect=ValueError('GENERATED_STOP_BEFORE_SOURCE')):
                    with self.assertRaisesRegex(ValueError,'GENERATED_STOP_BEFORE_SOURCE'):cli.main()
            stopped=c.exact_object((output/'STOP_SOURCE_TARGET_PREPARATION.json').read_bytes())
            self.assertTrue(stopped['source_scopes_revoked']);self.assertTrue(stopped['recording_scopes_revoked'])
            self.assertFalse(any(stopped['forbidden_attempts'].values()))
            self.assertFalse(entry._ACTIVE_SOURCE)
        finally:
            if output.exists():shutil.rmtree(output)

    def test_source_scope_revoked_wrongyear_and_qualified_read_path_reject_without_mint(self):
        # A seal alone is not registration; generated test never registers scope.
        go,go_sha,review,review_sha=generated.authority()
        scope=entry.LegacySourcePreparationScope(entry.FIRST6,go_sha,review_sha,go,review,entry.code_identity(),object(),entry._SOURCE_SEAL)
        with self.assertRaisesRegex(ValueError,'LIVE_CURRENT'):scope.validate_current()
        with self.assertRaises(ValueError):scope.read_source(2023,'../bad','0'*64)
        with self.assertRaises(ValueError):source.capture_year(2024,scope)
        self.assertFalse(entry._ACTIVE_SOURCE)

    def test_legacy_manifest_matches_exact_original_plan_cell_ids(self):
        raw=c.ordinary(c.ROOT/'overnight_legacy_variant_queue_plan_20261015/NEXT_TRANCHE30.json')
        original=c.exact_object(raw)['rows']
        self.assertEqual([row['proposed_cell_id'] for row in original],[row['cell_id'] for row in config.cells()])
        self.assertEqual([row['registry_variant_id'] for row in original],[row['recipe'] for row in config.cells()])
        self.assertEqual([row['days'] for row in original],[row['calendar_days'] for row in config.cells()])


class ExactPreparationSchemaTests(unittest.TestCase):
    def test_extra_top_year_cell_authority_keys_rejected(self):
        prep,artifacts,arrays=generated.fixture()
        cell_id=entry.tranche_cells(entry.FIRST6)[0]
        for where in ('top','year','cell'):
            for key,value in (('financial_execution_authorized',True),('account_construction_authorized',True),('extra','x')):
                bad=deepcopy(prep)
                target=bad if where=='top' else bad['years']['2023'] if where=='year' else bad['cells'][cell_id]
                target[key]=value
                with self.assertRaises(ValueError):entry.validate_preparation_metadata(c.canonical(bad))


class GeneratedEphemeralSourceScopeTests(unittest.TestCase):
    def test_generated_real_scope_lifecycle_revoke_and_wrong_year_no_actual_read(self):
        go,go_sha,review,review_sha=generated.authority()
        guard=SourceOnlyGuard(read_paths=generated.read_paths())
        captured=None
        with guard:
            with entry.admit_source_stage(go,go_sha,review,review_sha) as scope:
                generated.observed_generated_scope_lifecycle['minted']+=1
                captured=scope
                self.assertTrue(scope.validate_current(year=2023))
                for year in (2021,2022,2024,2025,2026,True):
                    with self.assertRaises(ValueError):scope.validate_current(year=year)
                for name in ('../bad','native_2023_source_restore_20261015/UNQUALIFIED_FILE.json'):
                    with self.assertRaises(ValueError):scope.read_source(2023,name,'0'*64)
                with self.assertRaises(ValueError):scope.read_source(2023,
                    entry.contracts()['years']['2023']['warmup_path'],'0'*64)
                guard.checkpoint('GENERATED_EPHEMERAL_SCOPE_NO_ACTUAL_SOURCE_CALL')
            generated.observed_generated_scope_lifecycle['revoked']+=1
        with self.assertRaisesRegex(ValueError,'LIVE_CURRENT'):captured.validate_current()
        self.assertFalse(any(guard.attempts.values()));self.assertFalse(entry._ACTIVE_SOURCE)
        generated.observed_guard_receipts.append(guard.receipt('PASS_CLEAN_GENERATED_GUARDED_RUN'))

    def test_generated_ephemeral_scope_cannot_read_actual_source_body(self):
        go,go_sha,review,review_sha=generated.authority()
        contract=entry.contracts()['years']['2023'];name=contract['warmup_path'];pin=contract['read_files'][name]
        # Deliberately omit all actual source bodies from the guard allowlist.
        # The read is stopped before os.open; no stored price container opens.
        guard=SourceOnlyGuard(read_paths=generated.read_paths())
        with self.assertRaises(SourceBoundaryViolation):
            with guard:
                with entry.admit_source_stage(go,go_sha,review,review_sha) as scope:
                    generated.observed_generated_scope_lifecycle['minted']+=1
                    try:scope.read_source(2023,name,pin['SHA256'],pin['bytes'])
                    finally:generated.observed_generated_scope_lifecycle['revoked']+=1
        self.assertEqual(guard.attempts['nonallowlisted_file_reads'],1)
        generated.observed_generated_scope_lifecycle['actual_body_read_blocks']+=1
        generated.observed_guard_receipts.append(guard.receipt('EXPECTED_NEGATIVE_ACTUAL_BODY_READ_STOPPED_BEFORE_OPEN'))
        self.assertFalse(entry._ACTIVE_SOURCE)


class AdditionalGuardWriteTests(unittest.TestCase):
    def test_arbitrary_financial_content_chunked_writer_and_outside_writes_block(self):
        with tempfile.TemporaryDirectory(dir=c.HERE) as td:
            td=Path(td)
            guard=SourceOnlyGuard(read_paths=generated.read_paths(),write_roots=(td,))
            with self.assertRaises(SourceBoundaryViolation):
                with guard:
                    with (td/'innocent.txt').open('wb') as stream:
                        stream.write(b'{"financial_execution_authorized":')
                        stream.write(b'true}')
            self.assertEqual(guard.attempts['financial_GO_writes'],1)
            generated.observed_guard_receipts.append(guard.receipt('EXPECTED_NEGATIVE_CHUNKED_FINANCIAL_CONTENT_WRITE'))
            # No complete executable financial JSON was ever written.
            self.assertEqual((td/'innocent.txt').read_bytes(),b'{"financial_execution_authorized":')
            guard=SourceOnlyGuard(read_paths=generated.read_paths(),write_roots=(td,))
            with self.assertRaises(SourceBoundaryViolation):
                with guard:(c.HERE/'OUTSIDE_GENERATED_ROOT.txt').open('w')
            self.assertEqual(guard.attempts['outside_source_writes'],1)
            generated.observed_guard_receipts.append(guard.receipt('EXPECTED_NEGATIVE_OUTSIDE_OR_RAW_WRITE'))
            guard=SourceOnlyGuard(read_paths=generated.read_paths(),write_roots=(td,))
            with self.assertRaises(SourceBoundaryViolation):
                with guard:os.open(td/'raw',os.O_WRONLY|os.O_CREAT)
            self.assertEqual(guard.attempts['outside_source_writes'],1)
            generated.observed_guard_receipts.append(guard.receipt('EXPECTED_NEGATIVE_OUTSIDE_OR_RAW_WRITE'))


if __name__=='__main__':unittest.main()
