"""Thin FIRST6 source capture and complete-intrinsic downward target adapter.

No finance, simulator, historical provider, process, claims or cache. Applying
this to actual source bodies requires the separate fresh source stage authority.
"""
from io import BytesIO
from pathlib import Path
import re
import numpy as np
import legacy_common as c
import legacy_codec as codec
import legacy_config as config
import legacy_entry as entry
import legacy_signal as signal


def finite_number(value):
    if type(value) not in (int,float):
        return False
    try:
        return bool(np.isfinite(float(value)))
    except (OverflowError,ValueError,TypeError):
        return False


def funding_events(year,raw,contract):
    period=config.source_year(year);values=c.object_json(raw)
    fields={'symbol','event_us','raw_rate','reported_interval_hours'}
    if type(values) is not list or len(values)!=contract['events']['selected_events']:
        raise ValueError('EXACT_2023_FUNDING_ARRAY_COUNT_REQUIRED')
    for row in values:
        if (type(row) is not dict or set(row)!=fields or row['symbol'] not in config.SYMBOLS
                or type(row['event_us']) is not int or not period['start']<=row['event_us']<period['end']
                or not finite_number(row['raw_rate'])
                or not finite_number(row['reported_interval_hours']) or row['reported_interval_hours']!=8):
            raise ValueError('EXACT_2023_RAW_UNCERTIFIED_SIGNED_FUNDING_SCHEMA_INTERVAL8_REQUIRED')
    if (len({(r['symbol'],r['event_us']) for r in values})!=len(values)
            or values!=sorted(values,key=lambda r:(r['event_us'],r['symbol']))):
        raise ValueError('EXACT_ORIGINAL_FUNDING_IDENTITY_SAMECLOCK_ORDER_REQUIRED')
    return c.immutable(values)


def assemble_inputs(year,warm_raw,daily_raw,events_raw,sidecar_raw,months,contract):
    """Pure codec/quality checks on caller bytes. Does not mint qualification."""
    period=config.source_year(year)
    clocks,close,decisions=codec.daily_inputs(year,warm_raw,daily_raw)
    sidecar=c.exact_object(sidecar_raw)
    events=funding_events(year,events_raw,contract)
    if contract['quality_intervals'] or contract.get('derived_mark_cells')!=0:
        raise ValueError('EXACT_2023_ZERO_DERIVED_QUALITY_REQUIRED')
    # Existing original200 daily proof is bound by its unchanged source pin.
    if c.canonical(sidecar.get('original200_quality'))!=c.canonical(contract['quality_summary']):
        raise ValueError('EXACT_ORIGINAL200_2023_QUALITY_LINEAGE_REQUIRED')
    daily=c.object_json(daily_raw)
    if type(daily) is not list or len(daily)!=period['days']*5:
        raise ValueError('EXACT_2023_DAILY_CORE5_ROW_COUNT_REQUIRED')
    by={}
    for row in daily:
        if (type(row) is not dict or set(row)!={'symbol','close_us','close'}
                or row['symbol'] not in config.SYMBOLS or type(row['close_us']) is not int
                or not period['start']<=row['close_us']<period['end'] or row['close_us']%config.DAY
                or not finite_number(row['close']) or row['close']<=0):
            raise ValueError('EXACT_2023_DAILY_CORE5_SCHEMA_REQUIRED')
        key=(row['close_us'],row['symbol'])
        if key in by:
            raise ValueError('DUPLICATE_DAILY_SOURCE_CELL')
        by[key]=float(row['close'])
    for at in decisions:
        off=int(np.searchsorted(clocks,at))
        for j,symbol in enumerate(config.SYMBOLS):
            if np.float64(by.get((int(at),symbol),np.nan)).tobytes()!=close[off,j].tobytes():
                raise ValueError('EXACT_2023_WARM_DAILY_CLOSE_BIT_PARITY_REQUIRED')
    if len(months)!=len(contract['months']):
        raise ValueError('EXACT_CANONICAL_MONTH_COUNT_REQUIRED')
    cursor=period['start'];final=None
    for rec,(name,raw) in zip(contract['months'],months,strict=True):
        if (name!=rec['path'] or c.sha(raw)!=rec['hash'] or len(raw)!=rec['size']
                or rec['start']+rec['lo']*codec.MINUTE!=cursor
                or not 0<=rec['lo']<rec['hi']<=rec['count']):
            raise ValueError('EXACT_PINNED_NATIVE_MONTH_IDENTITY_REQUIRED')
        arrays,missing=codec.month_arrays(year,raw,rec['start'],rec['count'])
        if missing:
            raise ValueError('NO_2023_DERIVED_MARK_CELLS_ALLOWED')
        for at in range(rec['start']+config.DAY,rec['start']+rec['count']*codec.MINUTE+1,config.DAY):
            if not period['start']<=at<period['end']:
                continue
            k=int(np.searchsorted(clocks,at));off=(at-rec['start'])//codec.MINUTE-1
            for j,symbol in enumerate(config.SYMBOLS):
                if arrays[symbol+'_close'][off].tobytes()!=close[k,j].tobytes():
                    raise ValueError('EXACT_NATIVE_DAILY_CLOSE_BIT_PARITY_REQUIRED')
        final=arrays;cursor=rec['start']+rec['hi']*codec.MINUTE
    if cursor!=period['end'] or final is None:
        raise ValueError('EXACT_FULL_2023_EXECUTION_AND_CLOSING_CALENDAR_REQUIRED')
    endpoint={symbol:float(final[symbol+'_close'][-1]) for symbol in config.SYMBOLS}
    rows=tuple(dict(symbol=symbol,close_us=int(at),available_us=int(at),close=float(close[i,j]))
               for i,at in enumerate(clocks) for j,symbol in enumerate(config.SYMBOLS))
    quality=dict(schema='LEGACY_INTRINSIC_REUSED_QUALIFIED_2023_SOURCE_QUALITY_V1',year=year,
        calendar=[period['start'],period['end']],qualified_source_identity=contract['source_identity'],
        original_quality_sidecar_SHA256=c.sha(sidecar_raw),original_quality_sidecar=sidecar,
        cells=[],quality_intervals=[],derived_mark_cells=0,final_endpoint_close=endpoint,
        source_completion_is_not_arrival_certification=True,arrival_status='UNKNOWN_NOT_CERTIFIED',
        original_source_age_and_arrival_flags_preserved=True,
        actual_legacy_event_and_position_impacts='PENDING_NEW_LEGACY_SAVED_EXECUTION_NOT_INHERITED_FROM_D',
        certifies_liquidation=False,certifies_no_liquidation=False,
        funding_ownership='CURRENT_NATIVE_ACTUAL_QUANTITY_ONLY_AFTER_PAID_FILLS',
        funding_rate_unit='UNCONFIRMED_PRESERVED_NO_RESCALE')
    return dict(year=year,period=period,clocks=clocks,close=close,decisions=decisions,
        source_rows=c.immutable(rows),events=events,months=tuple(months),quality_cells=(),quality_intervals=(),
        sidecar=c.immutable(quality),sidecar_raw=c.canonical(quality)+b'\n',
        source_identity=contract['source_identity'],contract=c.immutable(contract))


def capture_year(year,source_scope):
    if type(source_scope) is not entry.LegacySourcePreparationScope:
        raise ValueError('EXACT_NEW_LEGACY_SOURCE_SCOPE_REQUIRED_NO_CS_ALIAS')
    source_scope.validate_current(year=year)
    contract=entry.contracts()['years'][str(year)]
    def read(path):
        pin=contract['read_files'][path]
        return source_scope.read_source(year,path,pin['SHA256'],pin['bytes'])
    result=assemble_inputs(year,read(contract['warmup_path']),read(contract['daily_path']),
        read(contract['events_path']),read(contract['quality_sidecar_path']),
        tuple((rec['path'],read(rec['path'])) for rec in contract['months']),contract)
    source_scope.validate_current(year=year)
    return result


def project_targets(source):
    config.source_year(source['year'])
    arrays,proofs=signal.build_target_grid(source['close'],source['clocks'],source['clocks'],source['decisions'])
    return arrays,dict(original_intrinsic_then_downward_only=True,source_recipe_order=config.RECIPES,
        original_execution_unchanged=False,financial_reuse_allowed=False,proofs=proofs)


def target_blob(arrays):
    stream=BytesIO();np.savez_compressed(stream,**arrays);return stream.getvalue()


def year_info(source,targets,source_inputs_raw):
    return dict(source_identity=source['source_identity'],source_contract_SHA256=c.jsha(source['contract']),
        days=source['period']['days'],calendar=[source['period']['start'],source['period']['end']],
        provider_months_source='EXISTING_PINNED_CANONICAL_MONTHS',quality_cells_SHA256=c.jsha([]),
        source_quality_sidecar_SHA256=c.sha(source['sidecar_raw']),source_inputs_SHA256=c.sha(source_inputs_raw),
        source_rows_SHA256=c.jsha(source['source_rows']),funding_events_SHA256=c.jsha(source['events']),
        array_identities={key:signal.array_byte_identity(value) for key,value in targets.items()},
        all_legacy_position_and_event_impacts_pending=True)


def input_binding(cell,source,targets,source_inputs_raw,source_go_sha,source_review_sha):
    return entry.binding_from_info(cell,year_info(source,targets,source_inputs_raw),source_go_sha,source_review_sha)


def prepare_source_only(output_directory,*,source_go_raw,expected_source_go_sha256,review_raw,expected_review_sha256):
    """Exclusive bounded actual stage. No source/body I/O occurs before gate."""
    authority=entry.validate_source_authority_metadata(source_go_raw,expected_source_go_sha256,review_raw,expected_review_sha256)
    from legacy_source_guard import current_guard
    guard=current_guard()
    if guard is None or not guard.active:
        raise ValueError('WHOLE_INVOCATION_LEGACY_SOURCE_ONLY_GUARD_REQUIRED')
    output=Path(output_directory).absolute();base=c.HERE/'source_attempts'
    if (output.parent!=base or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,100}',output.name)
            or output.is_symlink() or any(p.is_symlink() for p in output.parents)):
        raise ValueError('EXACT_NEW_LEGACY_SOURCE_ATTEMPT_OUTPUT_NO_SYMLINK_ANCESTORS_REQUIRED')
    if output.exists():
        raise ValueError('EXCLUSIVE_NEW_LEGACY_SOURCE_PREPARATION_REQUIRED')
    artifacts={};years={};cells={};tranche=authority['policy']['tranche']
    with entry.admit_source_stage(source_go_raw,expected_source_go_sha256,review_raw,expected_review_sha256) as scope:
        source=capture_year(2023,scope);targets,proofs=project_targets(source)
        inputs=target_blob(dict(close_available_us=source['clocks'],close=source['close']))
        artifacts.update({'2023/TARGETS.npz':target_blob(targets),'2023/SOURCE_INPUTS.npz':inputs,
            '2023/SOURCE_ROWS.json':c.canonical(source['source_rows'])+b'\n',
            '2023/RAW_EVENTS.json':c.canonical(source['events'])+b'\n',
            '2023/MINUTE_MARK_PROVENANCE.json':source['sidecar_raw'],
            '2023/TARGET_PROOFS.json':c.canonical(proofs)+b'\n'})
        years['2023']=year_info(source,targets,inputs)
        for cell_id in entry.tranche_cells(tranche):
            cell=config.cell_named(cell_id)
            binding=entry.binding_from_info(cell,years['2023'],expected_source_go_sha256,expected_review_sha256)
            cells[cell_id]=dict(descriptor=cell,input_binding=binding,input_binding_SHA256=c.jsha(binding))
        guard.checkpoint('PREPARED_FIRST6_LEGACY_INTRINSIC_TARGETS_NO_ACCOUNT')
    if entry._ACTIVE_SOURCE:
        raise ValueError('LEGACY_SOURCE_SCOPES_NOT_REVOKED')
    artifacts['SOURCE_STAGE_AUTHORIZATION.json']=source_go_raw
    artifacts['SOURCE_INDEPENDENT_REVIEW.json']=review_raw
    preparation=dict(schema=entry.PREPARATION_SCHEMA,candidate=config.CANDIDATE,adaptation_version=config.VERSION,
        tranche=tranche,ordered_cells=list(entry.tranche_cells(tranche)),years=years,cells=cells,
        code_manifest_SHA256=entry.code_identity(),scope_manifest_SHA256=entry.manifest_sha(),
        source_contract_map_SHA256=entry.contract_sha(),source_stage_GO_SHA256=expected_source_go_sha256,
        source_review_SHA256=expected_review_sha256,
        artifacts={name:dict(SHA256=c.sha(raw),bytes=len(raw)) for name,raw in artifacts.items()},
        historical_admission=False,financial_runs=0,accounts_created=0,accounts_advanced=0,
        provider_iterations=0,process_launches=0,canonical_claims_created=0,real_financial_GO_written=0,publication_actions=0)
    raw=c.canonical(preparation)+b'\n';entry.validate_preparation_metadata(raw)
    output.mkdir(parents=True)
    for name,value in artifacts.items():
        path=output/c.relative(name);path.parent.mkdir(parents=True,exist_ok=True)
        with path.open('xb') as stream:
            stream.write(value)
    with (output/'PREPARATION.json').open('xb') as stream:
        stream.write(raw)
    return preparation
