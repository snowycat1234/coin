"""Refresh this new author code checkpoint only; never runtime admission."""
from pathlib import Path
import hashlib
import json

HERE=Path(__file__).absolute().parent
FILES=('legacy_common.py','legacy_config.py','legacy_signal.py','legacy_codec.py','legacy_entry.py',
    'legacy_source.py','legacy_source_guard.py','legacy_loader.py','prepare_legacy_source.py',
    'legacy_generated.py','test_legacy_source.py','test_cold_generated_zip.py','run_source_generated.py',
    'freeze_checkpoint.py','FROZEN_THIRTY_CELL_MANIFEST.json','SOURCE_CONTRACT_MAP.json','DEPENDENCY_PINS.json',
    'RUNTIME_READ_CLASSIFICATION.json','README.md')


def main():
    def pin(path):
        raw=path.read_bytes();return dict(SHA256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))
    files={name:pin(HERE/name) for name in FILES}
    dependencies=json.loads((HERE/'DEPENDENCY_PINS.json').read_bytes())['files']
    record=dict(schema='LEGACY_INTRINSIC_SOURCE_ONLY_CODE_IDENTITY_V1',status='GENERATED_ONLY_NOT_ACTUAL_ADMISSION',
        files=files,dependencies=dependencies,actual_source_authorized=False,financial_entry_implemented=False)
    (HERE/'CODE_MANIFEST.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')


if __name__=='__main__':main()
