"""Finite generated-only observer. Original source/native/test bytes stay exact.

This observes these enumerated tests. It is not a general-purpose Python sandbox.
"""
from pathlib import Path
import os,sys,json,runpy,unittest,resource,time
ROOT=Path(sys.argv[1]).resolve(); MODE=sys.argv[2]; ARGS=sys.argv[3:]
PACKET=Path(__file__).resolve().parent.parent
SOURCE=ROOT/'legacy_intrinsic_D_20261015_v1';NATIVE=ROOT/'legacy_intrinsic_D_native_20261015_v1';PURE=ROOT/'legacy_intrinsic_D_signal_20261015'
for p in ([PURE] if MODE=='pure' else [SOURCE,NATIVE,ROOT/'legacy_intrinsic_D_source_independent_review_20261015']):sys.path.insert(0,str(p))
observed=dict(external_process_events=0,network_events=0,outside_allowed_file_events=0,unassigned_CPU_affinity_events=0)
allowed=[ROOT,PACKET,Path(os.environ['TMPDIR']).resolve(),Path(sys.prefix),Path(sys.base_prefix),Path('/usr'),Path('/lib'),Path('/lib64'),Path('/etc'),Path('/proc'),Path('/dev')]
def audit(event,args):
 if event in ('subprocess.Popen','os.system','os.fork','os.forkpty','os.posix_spawn','os.exec'):
  observed['external_process_events']+=1;raise AssertionError('GENERATED_TEST_CHILD_PROCESS_DENIED')
 if event in ('socket.connect','socket.connect_ex','socket.sendto','socket.getaddrinfo'):
  observed['network_events']+=1;raise AssertionError('GENERATED_TEST_NETWORK_DENIED')
 if event=='os.sched_setaffinity' and len(args)>1 and set(args[1])!={2}:
  observed['unassigned_CPU_affinity_events']+=1;raise AssertionError('PACKAGING_CPU2_ONLY')
 if event=='open' and args and isinstance(args[0],(str,bytes,os.PathLike)):
  p=Path(os.path.abspath(os.fsdecode(args[0])))
  if not any(p==r or r in p.parents for r in allowed):
   observed['outside_allowed_file_events']+=1;raise AssertionError('GENERATED_TEST_OUTSIDE_READ_OR_WRITE_DENIED')
sys.addaudithook(audit);started=time.monotonic();tests=0;errors=0;failures=0;passed=False
if MODE in ('pure','unit','independent_source'):
 names=ARGS
 if MODE=='pure':names=['test_legacy_signal']
 if MODE=='independent_source':
  import test_independent_source as t
  excluded={'test_positive_cli_guard_complete_generated_source_free_storage','test_cli_stop_persists_original_generated_failure_without_scopes'}
  names=['test_independent_source.IndependentSourceReview.'+n for n in unittest.defaultTestLoader.getTestCaseNames(t.IndependentSourceReview) if n not in excluded]
 result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromNames(names));tests=result.testsRun;errors=len(result.errors);failures=len(result.failures);passed=result.wasSuccessful()
elif MODE=='zip':
 sys.argv=[str(SOURCE/'test_cold_generated_zip.py'),*ARGS];runpy.run_path(sys.argv[0],run_name='__main__');tests=1;passed=True
elif MODE=='cli':
 sys.argv=[str(NATIVE/'test_worker_integration.py'),*ARGS];runpy.run_path(sys.argv[0],run_name='__main__');tests=1;passed=True
elif MODE=='metadata':
 import legacy_bootstrap,legacy_finance_gate as gate,legacy_native_common as c
 prep=(PACKET/'SOURCE_EVIDENCE/PREPARATION_METADATA_EXACT.json').read_bytes()
 pr=(NATIVE/'PREPARED_REVIEW_SCHEMA_TEMPLATE.json').read_bytes();nr=(ROOT/'legacy_intrinsic_D_native_independent_review_20261015_v1/INDEPENDENT_NATIVE_GENERATED_ADMISSION_REVIEW.json').read_bytes();fr=(ROOT/'legacy_intrinsic_D_native_independent_review_20261015_v1/INDEPENDENT_FINANCIAL_ADMISSION_REVIEW.json').read_bytes()
 assert c.sha(prep)=='e162ec6a039ba43ff302f55601e589d0508de17fc8077d3a7e3fa895ce302edc'
 gate.prepared_review(prep,pr,'d045ce2502f384a6414636ccf7136b5cfb29e26db6f9749c522a2ee27e08d1fb');tests+=1
 gate.native_review(nr,'ae39dd97a77cad74af7b737651c57e58af48ffa3d15aa988281351a80a2643ab');tests+=1
 assert c.canonical(c.exact_object(fr))==c.canonical(gate.review_policy(prep,c.sha(pr),c.sha(nr)));tests+=1;passed=True
else:raise ValueError('ENUMERATED_GENERATED_GROUP_REQUIRED')
receipt=dict(schema='LEGACY_FIRST6_EXTRACTED_COLD_GENERATED_GROUP_V1',mode=MODE,arguments=ARGS,tests=tests,errors=errors,failures=failures,passed=passed,observed=observed,CPU_affinity=sorted(os.sched_getaffinity(0)),numerical_pools=1,wall_seconds=time.monotonic()-started,peak_RSS_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,historical_source_or_target_replay=False,actual_historical_scopes=0,actual_providers=0,actual_accounts=0,actual_financial_runs=0,actual_claims_or_GO_bodies_created=0,universal_sandbox_claim=False)
print('COLD_RECEIPT_JSON='+json.dumps(receipt,sort_keys=True));raise SystemExit(0 if passed and not any(observed.values()) and receipt['CPU_affinity']==[2] else 1)
