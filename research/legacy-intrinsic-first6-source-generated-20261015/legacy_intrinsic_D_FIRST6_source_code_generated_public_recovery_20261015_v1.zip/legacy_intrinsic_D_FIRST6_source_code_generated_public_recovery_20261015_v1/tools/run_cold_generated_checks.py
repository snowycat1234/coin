"""Cold-test only extracted packet/parent code with invented data on CPU2/pools1."""
from pathlib import Path
import argparse,subprocess,os,sys,tempfile,json,hashlib,zipfile,datetime
PACKET=Path(__file__).resolve().parent.parent
ENV=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',POLARS_MAX_THREADS='1',VECLIB_MAXIMUM_THREADS='1',BLIS_NUM_THREADS='1')
def pin(p):
 b=p.read_bytes();return dict(SHA256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--parent-zip',required=True,type=Path);ap.add_argument('--evidence',required=True,type=Path);a=ap.parse_args()
 if sorted(os.sched_getaffinity(0))!=[2]:raise ValueError('RUN_PACKAGING_ON_CPU2_ONLY')
 a.evidence.mkdir(parents=True,exist_ok=True)
 before={str(p.relative_to(PACKET)):pin(p) for p in PACKET.rglob('*') if p.is_file() and 'PACKAGING_EVIDENCE' not in p.parts}
 groups=[('pure_signal',['pure']),('source_author',['unit','test_legacy_source']),('source_independent_cpu2_compatible',['independent_source']),('native_fake_metadata',['unit','test_legacy_native','test_legacy_finance']),('fresh_zip_positive',['zip']),('fresh_zip_expected_cold_stop',['zip','--expect-cold-stop']),('actual_metadata_only_compatibility',['metadata'])]
 for k in range(1,7):groups.append(('fresh_cli_positive_cell'+str(k),['cli','positive',json.loads((PACKET/'legacy_intrinsic_D_native_independent_review_20261015_v1/INDEPENDENT_FINANCIAL_ADMISSION_REVIEW.json').read_bytes())['ordered_cells'][k-1]]))
 for mode in ('capture_failure','loaded_validation_failure','guard_exit_failure'):groups.append(('fresh_cli_'+mode,['cli',mode]))
 results=[]
 with tempfile.TemporaryDirectory(prefix='legacy_first6_code_cold_') as td:
  base=Path(td);staging=base/'staging.zip';extract=base/'extracted';recover=base/'recovered';temp=base/'invented';temp.mkdir()
  with zipfile.ZipFile(staging,'w',compression=zipfile.ZIP_DEFLATED) as z:
   for n in sorted(before):z.write(PACKET/n,n)
  with zipfile.ZipFile(staging) as z:z.extractall(extract)
  env=dict(ENV,TMPDIR=str(temp))
  command=[sys.executable,'-B',str(extract/'tools/recover_code_closure.py'),'--parent-zip',str(a.parent_zip.resolve()),'--output',str(recover)]
  p=subprocess.run(command,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=60);(a.evidence/'RECOVERY.log').write_bytes(p.stdout)
  if p.returncode:raise RuntimeError('EXACT_CODE_RECOVERY_FAILED')
  recovery=json.loads(p.stdout)
  recovered_before={str(p.relative_to(recover)):pin(p) for p in recover.rglob('*') if p.is_file()}
  for name,args in groups:
   p=subprocess.run([sys.executable,'-B',str(extract/'tools/cold_generated_inner.py'),str(recover),*args],cwd=recover,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=180)
   log=a.evidence/(name+'.log');log.write_bytes(p.stdout)
   lines=[s for s in p.stdout.decode(errors='replace').splitlines() if s.startswith('COLD_RECEIPT_JSON=')]
   receipt=json.loads(lines[-1].split('=',1)[1]) if lines else None
   results.append(dict(group=name,explicit_arguments=args,exit_code=p.returncode,receipt=receipt,log=pin(log)))
   if p.returncode:break
  recovered_after={n:pin(recover/n) for n in recovered_before}
 after={n:pin(PACKET/n) for n in before}
 report=dict(schema='LEGACY_FIRST6_SOURCE_CODE_GENERATED_EXTRACTED_COLD_CHECKS_V1',created_UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='PASS' if len(results)==len(groups) and all(r['exit_code']==0 for r in results) and before==after and recovered_before==recovered_after else 'FAIL',recovery=recovery,packet_input_files_unchanged=before==after,recovered_exact_code_files_unchanged=recovered_before==recovered_after,groups=results,tests=sum(r['receipt']['tests'] for r in results if r['receipt']),CPU_affinity=sorted(os.sched_getaffinity(0)),numerical_pools=1,interpreter_processes=len(results)+1,actual_source_replay=False,actual_target_construction=False,actual_provider_or_historical_scope_or_account_construction=False,actual_financial_runs=0,actual_claims_or_valid_authority_bodies_created=0,resource_probe_rerun=False,publication_actions=0,universal_sandbox_claim=False,limitations=['Two original independent source CLI tests assert physical CPU3 and are not rerun on assigned CPU2. Their unchanged exact historical review receipts remain evidence only.','The source author tests mock logical source CPU0/resource hooks; public checks do not exercise a full actual source launch path.','The original source generated runner hardcodes CPU0; original independent source runner hardcodes CPU3; original independent native seam runner hardcodes CPU6. None of those runners is executed or edited.','Generated real CLI scenarios use invented storage, recording source context/capture and a post-guard native sentinel. They do not reach any historical/native account or provider.','The exact prior tiny profile003 is evidence only. Annual resource envelope and host quota are not guaranteed.','Historical source entry and actual finance remain unavailable without omitted source bodies and old source wire prerequisites; a fresh financial GO alone is insufficient.'])
 (a.evidence/'COLD_GENERATED_CHECKS.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(status=report['status'],groups=len(results),tests=report['tests'])))
 return 0 if report['status']=='PASS' else 1
if __name__=='__main__':raise SystemExit(main())
