"""Recover exact CODE bytes only from this delta and the pinned public CS archive.

No download, historical source/target replay, authority creation or finance occurs.
"""
from pathlib import Path,PurePosixPath
import argparse,hashlib,json,zipfile
PACKET=Path(__file__).resolve().parent.parent
def sha(raw):return hashlib.sha256(raw).hexdigest()
def relative(name):
 p=PurePosixPath(name)
 if p.is_absolute() or '..' in p.parts or '\\' in name or str(p)!=name:raise ValueError('SAFE_RELATIVE_CODE_PATH_REQUIRED')
 return name
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--parent-zip',required=True,type=Path);ap.add_argument('--output',required=True,type=Path);a=ap.parse_args()
 m=json.loads((PACKET/'RECOVERY_MAP.json').read_bytes());parent=m['parent_archive']
 if sha(a.parent_zip.read_bytes())!=parent['SHA256']:raise ValueError('EXACT_ALREADY_PUBLISHED_PARENT_ZIP_REQUIRED')
 # Exclusive empty destination prevents accidental overwrite of local code or data.
 a.output.mkdir(parents=True,exist_ok=False)
 def put(n,raw,r):
  relative(n)
  if len(raw)!=r['bytes'] or sha(raw)!=r['SHA256']:raise ValueError('EXACT_ORIGINAL_CODE_PIN_REQUIRED:'+n)
  p=a.output/n;p.parent.mkdir(parents=True,exist_ok=True)
  with p.open('xb') as stream:stream.write(raw)
 with zipfile.ZipFile(a.parent_zip) as z:
  names=z.namelist()
  if len(names)!=len(set(names)):raise ValueError('DUPLICATE_PARENT_ARCHIVE_MEMBER')
  for n,r in m['parent_references'].items():put(n,z.read(parent['root']+'/'+relative(r['parent_path'])),r)
 for n,r in m['packet_copies'].items():put(n,(PACKET/relative(n)).read_bytes(),r)
 for n,r in m['local_aliases'].items():put(n,(PACKET/relative(r['packet_path'])).read_bytes(),r)
 checked={}
 for n,r in m['required_code_files'].items():
  raw=(a.output/n).read_bytes()
  if sha(raw)!=r['SHA256'] or len(raw)!=r['bytes']:raise ValueError('RECOVERED_CODE_IDENTITY_CHANGED:'+n)
  checked[n]=r
 print(json.dumps(dict(schema='EXACT_PARENT_DELTA_CODE_RECOVERY_RECEIPT_V1',status='PASS',required_code_files=len(checked),parent_archive_SHA256=parent['SHA256'],parent_code_files=len(m['parent_references']),delta_code_files=len(m['packet_copies']),exact_local_aliases=len(m['local_aliases']),historical_source_or_target_replay=False,valid_authority_bodies_created=0,financial_runs=0,publication_actions=0),sort_keys=True))
if __name__=='__main__':main()
