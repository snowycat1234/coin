"""Separate operational proposal: drain peers after saved-validator failure.

No launch on import. Callers provide their exact frozen runtime and retain the
outer controller_lease context until this function returns or raises. This does
not grant financial admission, clear claims, retry work, or modify saved bytes.
"""
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import json
import re
import zipfile

EXACT_LIMITS = dict(maximum_live_workers=2, threads_per_worker=1,
    per_case_wall_seconds=600, per_case_CPU_seconds=600,
    per_case_RSS_stop_bytes=2_000_000_000, per_case_AS_bytes=4_000_000_000,
    per_case_output_bytes=250_000_000, aggregate_live_worker_RSS_stop_bytes=3_500_000_000)


class SavedValidationPause(RuntimeError):
    """Sticky non-success carrying drained evidence; never a successful pool."""
    def __init__(self, report):
        self.report = report
        super().__init__('SAVED_VALIDATION_PAUSE_NO_NEW_LAUNCH_NO_RETRY:' + report['saved_validation_errors'][0]['cell_id'])


def run_pool(jobs, output, *, runtime, requested_workers, cpus, validator,
             observation_callback=None, before_launch=None, bootstrap_launcher=None,
             inherited_lease_environment=None):
    if runtime.LIMITS != EXACT_LIMITS:
        raise ValueError('EXACT_UNCHANGED_BOUNDED_DRAIN_RESOURCE_LIMITS_REQUIRED')
    with runtime.cpu_envelope(cpus):
        return _run_pool(jobs, output, runtime=runtime, requested_workers=requested_workers,
            cpus=cpus, validator=validator, observation_callback=observation_callback,
            before_launch=before_launch, bootstrap_launcher=bootstrap_launcher,
            inherited_lease_environment=inherited_lease_environment)


def _run_pool(jobs, output, *, runtime, requested_workers, cpus, validator,
              observation_callback=None, before_launch=None, bootstrap_launcher=None,
              inherited_lease_environment=None):
    r = runtime
    if r.LIMITS != EXACT_LIMITS:
        raise ValueError('EXACT_UNCHANGED_BOUNDED_DRAIN_RESOURCE_LIMITS_REQUIRED')
    if observation_callback is None:
        observation_callback = r.host_observation
    launcher = r.HERE/'run_cs.py' if bootstrap_launcher is None else Path(bootstrap_launcher)
    if launcher.parent.resolve() != r.HERE.resolve() or launcher.is_symlink():
        raise ValueError('EXACT_RUNTIME_LOCAL_BOOTSTRAP_LAUNCHER_REQUIRED')
    extra_leases = {} if inherited_lease_environment is None else dict(inherited_lease_environment)
    for key, fd in extra_leases.items():
        if (type(key) is not str or not re.fullmatch(r'[A-Z][A-Z0-9_]{0,127}',key)
                or key == 'MATRIX_CONTROLLER_LEASE_FD' or type(fd) is not int or fd < 0):
            raise ValueError('EXPLICIT_VALID_ADDITIONAL_INHERITED_LEASE_FD_REQUIRED')
        os.fstat(fd)  # Caller already holds each lease; never create or unlock it.
    output = Path(output); output.mkdir(exist_ok=True)
    ids = [cell for cell, _ in jobs]
    if len(set(ids)) != len(ids) or any(not cell or Path(cell).name != cell for cell in ids):
        raise ValueError('UNIQUE_SAFE_CASE_IDS_REQUIRED')
    observations = []; completed = []; pending = []; active = {}; started = r.utc()
    validation_errors = []; paused = False

    def saved_validation(directory, cell, *, pid=None, cpu=None, reused=False):
        nonlocal paused
        try:
            receipt = validator(directory, cell)
            checkpoint_sha = r.sha((directory/'TERMINAL_CHECKPOINT.json').read_bytes())
            status = receipt['status']
        except Exception as error:
            # Only exact ordinary saved-data errors from a newly EXIT0 child
            # may drain peers. Resource/process/cancellation errors fail fast.
            if reused or pid is None or type(error) not in (ValueError, KeyError, TypeError, EOFError, zipfile.BadZipFile):
                raise
            paused = True
            validation_errors.append(dict(cell_id=cell, error=repr(error), UTC=r.utc(),
                reused_saved_terminal=reused, PID=pid, CPU=cpu))
            return
        row = dict(cell_id=cell, status=status, checkpoint_SHA256=checkpoint_sha,
                   reused_saved_terminal=reused)
        if pid is not None: row.update(PID=pid, CPU=cpu)
        completed.append(row)

    for cell, command in jobs:
        directory = output/cell
        if directory.exists():
            if not (directory/'TERMINAL_CHECKPOINT.json').is_file():
                launch = json.loads((directory/'PROCESS_OWNERSHIP.json').read_bytes()) if (directory/'PROCESS_OWNERSHIP.json').is_file() else {}
                live = r.process_observation(launch.get('PID', -1)) if type(launch.get('PID')) is int else None
                state = 'LIVE_OWNED' if live and live.get('process_start_ticks') == launch.get('process_start_ticks') else 'AMBIGUOUS_OR_INTERRUPTED'
                raise RuntimeError('EXISTING_UNFINISHED_CASE_PAUSE_NO_RETRY:'+cell+':'+state)
            saved_validation(directory, cell, reused=True)
        else:
            pending.append((cell, command))
    try:
        while (pending and not paused) or active:
            host = observation_callback()
            # Capacity admission is only relevant to a future launch. On a
            # saved-only pause it must not interrupt already-finalizing peers.
            capacity = 0 if paused else r.choose_worker_count(requested_workers, cpus, host)
            live_rows = [row for pid in active if (row := r.process_observation(pid)) is not None]
            rss = sum(row['RSS_bytes'] for row in live_rows)
            observations.append(dict(UTC=r.utc(), aggregate_live_RSS_bytes=rss,
                workers=live_rows, observed_capacity=capacity, saved_validation_pause=paused))
            reason = None
            if rss > r.LIMITS['aggregate_live_worker_RSS_stop_bytes']: reason = 'AGGREGATE_LIVE_RSS_LIMIT'
            for pid, state in active.items():
                row = next((row for row in live_rows if row['PID'] == pid), None)
                if row and row['RSS_bytes'] > r.LIMITS['per_case_RSS_stop_bytes']: reason = 'WORKER_RSS_LIMIT'
                ready = (state['directory']/'BOOTSTRAP_READY.json').is_file()
                if ready and row and (row['CPU_affinity'] != [state['cpu']] or any(t['CPU_affinity'] != [state['cpu']] for t in row['tasks'])): reason = 'WORKER_AFFINITY_LIMIT'
                if not ready and time.monotonic()-state['began'] > 5: reason = 'WORKER_BOOTSTRAP_STARTUP_LIMIT'
                if time.monotonic()-state['began'] > r.LIMITS['per_case_wall_seconds']: reason = 'WORKER_WALL_LIMIT'
                if r.own_bytes(state['directory']) + state['log_path'].stat().st_size > r.LIMITS['per_case_output_bytes']: reason = 'WORKER_OUTPUT_LIMIT'
            if reason: raise RuntimeError(reason)
            for pid, state in list(active.items()):
                code = state['process'].poll()
                if code is None: continue
                state['log'].close(); del active[pid]
                if code: raise RuntimeError('WORKER_FAILED_EXECUTION_NOT_ECONOMIC_HALT:'+state['cell']+':'+str(code))
                saved_validation(state['directory'], state['cell'], pid=pid, cpu=state['cpu'])
            # The sticky saved pause is checked before touching any pending
            # directory, builder, permanent claim, or process-spawn operation.
            while not paused and pending and len(active) < capacity:
                fresh_capacity = r.choose_worker_count(requested_workers, cpus, observation_callback())
                if len(active) >= fresh_capacity: break
                used = {state['cpu'] for state in active.values()}
                cpu = next(cpu for cpu in cpus if cpu not in used)
                cell, builder = pending.pop(0); directory = output/cell; directory.mkdir(exist_ok=False)
                if before_launch is not None: before_launch(cell, directory, cpu)
                log_path = output/(cell+'.log'); log = log_path.open('xb'); began = time.monotonic()
                command = [sys.executable, '-B', str(launcher), '--bootstrap', str(cpu), str(directory.resolve()), '--'] + builder(directory, cpu)
                try:
                    child_env = r.environment()
                    child_env.update({key:str(fd) for key,fd in extra_leases.items()})
                    if r._CONTROLLER_LEASE_FD is not None:
                        child_env['MATRIX_CONTROLLER_LEASE_FD'] = str(r._CONTROLLER_LEASE_FD)
                    pass_fds=tuple(dict.fromkeys((() if r._CONTROLLER_LEASE_FD is None else (r._CONTROLLER_LEASE_FD,))+tuple(extra_leases.values())))
                    process = subprocess.Popen(command, cwd=r.HERE, env=child_env,
                        stdout=log, stderr=subprocess.STDOUT, start_new_session=True,
                        pass_fds=pass_fds)
                except BaseException:
                    log.close(); raise
                state = dict(cell=cell, cpu=cpu, directory=directory, process=process,
                    began=began, log=log, log_path=log_path)
                active[process.pid] = state
                actual = r.process_observation(process.pid)
                r.save(directory/'PROCESS_OWNERSHIP.json', dict(cell_id=cell, PID=process.pid, CPU=cpu,
                    process_start_ticks=actual['process_start_ticks'] if actual else None,
                    controller_PID=os.getpid(), UTC=r.utc()))
            if active: time.sleep(.1)
        report = dict(status='SAVED_VALIDATION_PAUSE_DRAINED_NO_RETRY' if paused else 'ALL_ADMITTED_ORDERED_CELLS_TERMINAL',
            started_UTC=started, ended_UTC=r.utc(), cases=completed, observations=observations,
            limits=dict(r.LIMITS), host_quota_guaranteed=False,
            quota_visibility='UNVERIFIED_HOST_OBSERVATIONS_ONLY',
            coordinator_CPU_affinity=sorted(os.sched_getaffinity(0)),
            coordinator_thread_observation=r.process_observation(os.getpid()),
            compute_thread_pools_maximum=1, helper_threads_allowed_but_all_affinities_confined=True,
            no_automatic_retry=True, no_financial_snapshot_resume=True,
            saved_validation_errors=validation_errors, pending_not_launched=[cell for cell, _ in pending],
            inherited_controller_lease_FD=r._CONTROLLER_LEASE_FD,
            additional_inherited_lease_environment=extra_leases,
            original_pause_preserved=paused, automatic_claim_clears=0)
        if paused: raise SavedValidationPause(report)
        return report
    except BaseException as error:
        # Actual process/resource failures and asynchronous cancellation remain
        # immediate-stop events. A drained saved pause has no active peers here.
        for state in active.values():
            try: os.killpg(state['process'].pid, signal.SIGKILL)
            except ProcessLookupError: pass
            state['process'].wait(); state['log'].close()
        if paused and not isinstance(error, SavedValidationPause):
            # Preserve the original saved-validation interruption alongside a
            # subsequent genuine resource/process fault during bounded drain.
            error.saved_validation_errors = list(validation_errors)
            error.pending_not_launched = [cell for cell, _ in pending]
            error.original_pause_preserved = True
        raise
