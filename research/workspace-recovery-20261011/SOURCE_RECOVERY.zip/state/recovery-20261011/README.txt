Workspace recovery, 2026-10-11

WORKING AND VERIFIED
Repository ../coin_single_stream reuses the preserved October 8 local Git
objects and read-only official GitHub fetches. Financial checkout is pinned
55434edfb4d6b9e8ba2b0176ce449dd739737231; the prior published own head
3acfcd0fc44907c25e6eb4c0d66776b97ff5f572 remains under refs/recovery.

48 published financial/strategy source hashes match. Native engine:
318a0ae63056775db4e24c09abc1831de0dd166f9117b0ce0240630de6aad585.
Prototype mapper:
46a0ca0b76bf29d50133bdd85b5730f4fd029f05378ce2ef086752b869a8fcab.

25 original account/margin-risk tests and 13 original native terminal/resume
fixtures pass. The latter exercise 1,446 synthetic minutes, paid partial
terminal fills, exact checkpoint restore and retained five-attempt failure.
All 365 published 2025 CS/VOL targets and ramped budgets reproduce bit-for-bit;
all four underlying expert targets/masks and past-30-day returns also match.
See VERIFIED_RECOVERY.json and immutable stage resource receipts.

MINIMUM ACQUISITION
35,237,825 bytes of hash-verified Git ZIP parts and 2,380,563 bytes of complete
small published ZIPs recovered the exact selected sources, daily warmup and
saved 2025 controls. Selected large-archive members pass CRC and their published
member hashes. Whole large-archive SHA/CRC is not claimed because untouched
parts were deliberately not acquired. Original local files are preserved.

CORE5 warmup has 2,192 UTC daily rows from 2020-01-01 through 2025-12-31, with
the original missing/complete flags preserved; completed availability ends
2026-01-01. Published numerical versions are installed in ../coin_runtime.
The resource launcher ../bounded_cloud.py is a reconstruction, not claimed
byte-exact: one CPU/thread, no GPU/swap, 2GB RSS, 4GB address, 8GB host used,
1,200-second stage cap, immutable resource receipts.

PUBLIC Q1/Q2 WARMUP
The clarified recovery authorization covers previously consumed public dates.
30 official Jan-June 2026 trade-minute ZIPs, 52,785,575 bytes, pass published
SHA/CRC and full-grid checks: 1,303,200 asset-minutes and 181 complete daily
price bars per asset. Their original normalizer produces combined 2,373-row
causal price histories, preserving all earlier missing flags. The appended
history leaves all 365 saved 2025 CS/VOL targets/masks unchanged. CS/VOL/CASH
45- and 90-decision causal prefixes match exactly. Price-only reconstructed
2026 expert inputs are labeled RECONSTRUCTED, not original byte recovery.

REMAINING AND STOPPING BOUNDARY
The unpublished Q1/Q2 adapters, marked/funding tapes, ledgers and checkpoints
are not byte-recovered. Previous verified hashes/results remain historical
receipts and are not replaced by reconstructed outputs. The restored price
warmup is not a complete native market tape. Q3 has not run or been downloaded.
The collector's March-August 2026 reserve and AGENTS lock wording are unchanged;
the specific recovery exception applies only to already-consumed public Q1/Q2
tapes. No separately reserved local data was opened. New July/August outcomes
remain closed pending deliberate scope resolution. No GitHub writes, Library
actions, fits or historical financial wallet replays occurred.

FAILED ATTEMPTS RETAINED
A mistyped absent test path caused an initial no-test run. A legacy risk-adapter
test rejects its old source pin on this newer native source; it was not weakened.
The minimal recovery reader's duplicate dict key was fixed locally and resumed
from the already verified ZIP parts. A broad default lint selected unrelated
rules; focused F/E9 checks pass. These failures and receipts remain visible.
