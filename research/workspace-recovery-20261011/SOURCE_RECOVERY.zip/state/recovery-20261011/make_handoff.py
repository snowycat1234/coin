"""Freeze local recoverability evidence and verify a second local backup copy."""
import hashlib
import json
import shutil
import subprocess
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
STATE = ROOT / "coin_single_state"
REPO = ROOT / "coin_single_stream"
SHARED = Path("/workspace/shared")


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_once(path, value):
    with path.open("x") as stream:
        stream.write(json.dumps(value, indent=2, allow_nan=False) + "\n")


def record(path, prefix):
    return dict(path=prefix + "/" + path.relative_to(STATE if prefix == "state" else REPO).as_posix(),
                bytes=path.stat().st_size, sha256=sha(path))


financial_path = REPO / "research/recover-frozen-runner-20261009/april63/ADAPTER_CONTRACT.json"
financial = json.loads(financial_path.read_bytes())
for name, expected in financial["source_sha256"].items():
    assert sha(REPO / name) == expected
warm = STATE / "recovered-public-Q1-Q2-warmup"
verification = json.loads((warm / "VERIFICATION.json").read_bytes())
assert verification["archive_count"] == 30 and verification["new_Q3_outcomes_consumed"] == 0
runtime = subprocess.check_output([str(ROOT / "coin_runtime/bin/python"), "-m", "site"], text=True)
assert "coin_runtime" in runtime
for filename in ("ACCOUNT_UNIT_RESOURCE.json", "NATIVE_TERMINAL_RESUME_RESOURCE.json", "TARGET_REPRODUCTION_RESOURCE.json", "WARMUP_CAUSAL_RESOURCE.json"):
    receipt = json.loads((HERE / filename).read_bytes())
    assert receipt["exit_code"] == 0 and receipt["stop_reason"] is None
lock_source = "modules/collector_research/pipeline/common.py"
lock_hash = sha(REPO / lock_source)
assert lock_hash == "0f24665c50c21fecef4e06f74230bbb113d210d014077068377c67f34fa57390"
bundle_name = "coin_workspace_recovery_20261011_0310.zip"
handoff = dict(
    status="WORKING_NATIVE_CODE_AND_MINIMUM_CAUSAL_PUBLIC_WARMUP_RESTORED",
    repository=str(REPO), state=str(STATE), python=str(ROOT / "coin_runtime/bin/python"),
    guard=str(STATE / "bounded_cloud.py"), guard_sha256=sha(STATE / "bounded_cloud.py"),
    financial_source_commit="55434edfb4d6b9e8ba2b0176ce449dd739737231",
    prior_published_own_head="3acfcd0fc44907c25e6eb4c0d66776b97ff5f572",
    git_route="https://github.com/snowycat1234/coin.git read-only; intact October 8 local Git objects reused",
    native_engine_sha256=financial["engine_sha256"],
    prototype_mapper_sha256=sha(STATE / "v2-proxy-sources/prototype.py"),
    financial_source_files_verified=48, financial_contract=financial["financial_contract"],
    alpha=dict(value=0.4245789652592106, provenance="Previously frozen 1294 paired causal target rows 2020-10-15..2024-04-30; no recalibration in recovery",
               placement="After original availability release, L1 budget ramp, allocated-leg/covariance checks and mapping; before .99*currentNAV*target/completed_daily_close sizing"),
    tests=dict(original_account_margin=25, original_native_terminal_resume=13, historical_wallet_replays=0,
               terminal_fixture_minutes=1446, original_five_attempt_failure_preserved=True),
    saved_2025_reproduction=dict(target_and_budget_rows_per_CS_VOL=365, exact=True,
                                report="recovery-20261011/VERIFIED_RECOVERY.json", sha256=sha(HERE / "VERIFIED_RECOVERY.json")),
    source_warmup=dict(source="Official published USD-M 1m trade archives for already-seen Jan-Jun2026",
                       archives=30, bytes=52785575, asset_minutes=1303200, daily_rows_per_asset=181,
                       combined_price_rows_per_asset=2373, last_price_open_UTC="2026-06-30T00:00:00Z",
                       last_completed_available_UTC="2026-07-01T00:00:00Z", no_gaps=True, no_interpolation=True,
                       no_premium_funding_imputation=True, native_market_ready=False,
                       report="recovered-public-Q1-Q2-warmup/VERIFICATION.json", sha256=sha(warm / "VERIFICATION.json"),
                       causal_prefix_checks=[45, 90], prefix_experts=["CASH", "VOL_MANAGED_HOLD", "CSMOM21"],
                       original_2026_input_byte_identity="UNKNOWN_MISSING_UNPUBLISHED_ORIGINALS"),
    acquisition=dict(selected_published_git_ZIP_part_bytes=35237825, small_published_ZIP_bytes=2380563,
                     official_trade_warmup_ZIP_bytes=52785575, total_archive_bytes=90403963,
                     full_large_git_archive_SHA_CRC_claimed=False, selected_member_SHA_CRC_verified=True),
    unrecovered=["Original unpublished Q1/Q2 adapters", "Q1/Q2 native mark/funding tapes", "Q1/Q2 financial ledgers and terminal checkpoints"],
    previous_report_receipts={
        "Q1": dict(source="Previously reported completed audited run; original bytes not presently recovered", decisions=90, held_intervals=89, scored_minutes=128166,
                   CS_return_percent=-2.951065947571256, VOL_return_percent=-6.918021060231205,
                   CS_RESULT_sha256="5b894eec6ef8ecdf67c4ef9601a83f08e9511a08b42e40619242fe4729d4fb90",
                   VOL_RESULT_sha256="8da79cc15c03be906eb61f09e429757855183601b9336086e5e184d29dbb7f33"),
        "Q2": dict(source="Previously reported completed audited run; original bytes not presently recovered", decisions=91, held_intervals=90, scored_minutes=129606,
                   CS_return_percent=-1.2081336667356004, VOL_return_percent=-6.46808785340701,
                   CS_RESULT_sha256="1cff6d725b895f802be8143d42522f16faf491f604c84342cd7759e4f52a68f5",
                   VOL_RESULT_sha256="b0bfb7fcbb4a790b524de1f93623c485ae80f32cc8a30ac6b4c4dbb2b3caad47")},
    lock=dict(AGENTS_path="coin_single_stream/AGENTS.md:11", AGENTS_sha256=sha(REPO / "AGENTS.md"),
              AGENTS_exact_wording="不读取账户密钥、真钱、Testnet/mainnet发单、付费、规避交易所限制、启封locked或扩预算。`state/dataset_lock.json`仅核SHA，不解析正文。",
              source_path="coin_single_stream/" + lock_source, source_sha256=lock_hash,
              exact_constants="LOCKED_START = date(2026, 3, 1); LOCKED_END = date(2026, 9, 1)",
              exact_error="LOCKED DATA: 2026-03-01..2026-08-31 is not authorized for this collector/research",
              dataset_lock_file_present=(REPO / "state/dataset_lock.json").exists(), dataset_lock_body_parsed=False,
              separate_reserved_dataset_read=False, lock_modified=False,
              exception="Explicit recovery of previously consumed public Q1/Q2 tapes; not pristine holdout",
              Q3="No July/August/September bodies or outcomes acquired; no Q3 wallet. July/August overlap the collector reserve and require deliberate scope resolution"),
    recoverability=dict(manifest="recovery-20261011/FROZEN_RECOVERY_MANIFEST.json",
                        local_bundle="recovery-20261011/" + bundle_name, shared_copy="/workspace/shared/" + bundle_name,
                        external_durability_guaranteed=False, runtime_cache_or_credentials_packaged=False,
                        reader="recovery-20261011/verify_handoff.py"),
    tracked_source_diff=subprocess.check_output(["git", "-C", str(REPO), "status", "--short"], text=True),
    GitHub_writes=0, Library_actions=0, new_fits=0, Q3_financial_runs=0)
assert handoff["tracked_source_diff"] == ""
write_once(HERE / "HANDOFF.json", handoff)
repo_names = set(financial["source_sha256"]) | {
    "AGENTS.md", "pyproject.toml", "tests/test_perpetual_account.py", "tests/test_native_margin_risk_summary.py", "tests/test_q4_native92.py",
    "research/recover-frozen-runner-20261009/requirements.txt", "research/recover-frozen-runner-20261009/requirements-native61.txt",
    "research/recover-frozen-runner-20261009/april63/ADAPTER_CONTRACT.json"}
state_paths = sorted(path for path in STATE.rglob("*") if path.is_file() and "uv-cache" not in path.parts)
records = [record(path, "state") for path in state_paths]
records += [record(REPO / name, "repo") for name in sorted(repo_names)]
manifest = dict(schema="FROZEN_WORKSPACE_RECOVERY_FILES_V1", files=records, members=len(records),
                bytes=sum(r["bytes"] for r in records), historical_original_Q1_Q2_bytes_restored=False,
                excludes="Runtime UV cache, credentials, unrelated WIP, separate reserved datasets")
write_once(HERE / "FROZEN_RECOVERY_MANIFEST.json", manifest)
bundle = HERE / bundle_name
assert not bundle.exists() and not (SHARED / bundle_name).exists()
assert shutil.disk_usage(STATE).free > 15_000_000_000 + manifest["bytes"] * 2
with zipfile.ZipFile(bundle, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=1) as archive:
    for item in records:
        prefix, relative = item["path"].split("/", 1)
        path = (STATE if prefix == "state" else REPO) / relative
        assert sha(path) == item["sha256"]
        archive.write(path, item["path"])
    archive.write(HERE / "FROZEN_RECOVERY_MANIFEST.json", "state/recovery-20261011/FROZEN_RECOVERY_MANIFEST.json")
with zipfile.ZipFile(bundle) as archive:
    assert archive.testzip() is None
    for item in records:
        body = archive.read(item["path"])
        assert len(body) == item["bytes"] and hashlib.sha256(body).hexdigest() == item["sha256"]
shutil.copyfile(bundle, SHARED / bundle_name)
assert sha(bundle) == sha(SHARED / bundle_name)
receipt = dict(status="PASS_FROZEN_RECOVERY_MANIFEST_AND_TWO_LOCAL_BUNDLE_COPIES", members=len(records) + 1,
               bundle_bytes=bundle.stat().st_size, bundle_sha256=sha(bundle),
               handoff_sha256=sha(HERE / "HANDOFF.json"), manifest_sha256=sha(HERE / "FROZEN_RECOVERY_MANIFEST.json"),
               scratch_bundle=str(bundle), shared_bundle=str(SHARED / bundle_name), ZIP_CRC_and_all_member_SHA_verified=True,
               external_durability_guaranteed=False, publication=False)
write_once(HERE / "BUNDLE_RECEIPT.json", receipt)
print(json.dumps(receipt))
