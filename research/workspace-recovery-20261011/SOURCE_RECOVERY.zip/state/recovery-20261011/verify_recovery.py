"""Verify recovered financial sources, source coverage and saved 2025 targets.

No wallet, fit, prediction, provider connection or original artifact writes.
"""
import hashlib
import importlib.util
import json
import os
import sys
from datetime import UTC, datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
STATE = ROOT / "coin_single_state"
REPO = ROOT / "coin_single_stream"
os.environ["QUANT_ROOT"] = str(REPO)
sys.path[:0] = [str(REPO), str(REPO / "src")]
import numpy as np
import polars as pl


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def iso(us):
    return datetime.fromtimestamp(int(us) / 1_000_000, UTC).isoformat()


contract_path = REPO / "research/recover-frozen-runner-20261009/april63/ADAPTER_CONTRACT.json"
contract = json.loads(contract_path.read_bytes())
for name, expected in contract["source_sha256"].items():
    assert sha(REPO / name) == expected, name
assert sha(STATE / "v2-proxy-sources/prototype.py") == "46a0ca0b76bf29d50133bdd85b5730f4fd029f05378ce2ef086752b869a8fcab"
assert sha(HERE / "recipes/conditional_selector_inputs.py") == "9c6658cd7682b6c5470585cbe927c20893e98a3e071cd52e56c5de280e86f207"
load("scripts.research.conditional_selector_core", REPO / "research/recover-frozen-runner-20261009/auxiliary/conditional_selector_core.py")
recipe = load("_recovery_original_recipe", HERE / "recipes/conditional_selector_inputs.py")
prototype = load("_recovery_original_prototype", STATE / "v2-proxy-sources/prototype.py")
symbols = prototype.CORE5
base = STATE / "data-expansion"
with np.load(base / "features2025/EXPERTS.npz", allow_pickle=False) as z:
    expected = {k: z[k].copy() for k in z.files}
with np.load(base / "features2025/FEATURES.npz", allow_pickle=False) as z:
    prices = z["close"].copy()
    clocks = z["completed_day_available_us"].copy()
assert tuple(expected["symbol_order"]) == tuple(symbols)
decisions = expected["decision_us"]
assert len(decisions) == 365 and np.all(np.diff(decisions) == prototype.DAY_US)
bars = recipe.bar_frame(base / "features2025", symbols).filter(pl.col("available_us") <= int(decisions[-1]))
regenerated = []
masks = []
for slot, name in enumerate(("CASH", "VOL_MANAGED_HOLD", "CSMOM21")):
    result = recipe.existing_targets(dict(recipe=name, mechanism=name), bars, decisions, prices, clocks, symbols)
    np.testing.assert_array_equal(result[0], expected["expert_targets"][:, slot])
    np.testing.assert_array_equal(result[2], expected["expert_eligible"][:, slot])
    regenerated.append(result[0])
    masks.append(result[2])
from scripts.investment import momentum_short_pool_target as short
short_frame, _ = short.fixed_targets(bars, decisions, symbols=symbols)
short_targets = short_frame["target_weight"].to_numpy().reshape(365, 5)
short_masks = (short_frame["eligibility_reason"].to_numpy().reshape(365, 5) == "ELIGIBLE").any(1)
np.testing.assert_array_equal(short_targets, expected["expert_targets"][:, 3])
np.testing.assert_array_equal(short_masks, expected["expert_eligible"][:, 3])
indices = np.searchsorted(clocks, decisions)
np.testing.assert_array_equal(clocks[indices], decisions)
past = np.stack([np.diff(prices[i - 30:i + 1], axis=0) / prices[i - 30:i] for i in indices])
np.testing.assert_array_equal(past, expected["past_returns30"])
contexts = []
for i, stamp in enumerate(decisions):
    targets = np.zeros((5, 5))
    eligible = np.zeros(5, bool)
    targets[[0, 1, 3, 4]] = expected["expert_targets"][i]
    eligible[[0, 1, 3, 4]] = expected["expert_eligible"][i]
    contexts.append(prototype.Context(int(stamp), int(stamp), targets, eligible, past[i],
                                      np.zeros(13), np.full(5, stamp, dtype=np.int64)))
mapped = {}
for name in ("CS", "VOL"):
    source = HERE / "daily-controls-reference/controls2025" / (name + "_PATH.npz")
    with np.load(source, allow_pickle=False) as z:
        request, expected_targets, expected_budgets = z["request"], z["targets"], z["budget"]
    targets, records = prototype.mapped_path(request, contexts)
    budgets = np.stack([r["budget"] for r in records])
    np.testing.assert_array_equal(targets, expected_targets)
    np.testing.assert_array_equal(budgets, expected_budgets)
    mapped[name] = dict(decisions=len(decisions), targets_bit_identical=True, budgets_bit_identical=True,
                        target_f64_sha256=hashlib.sha256(targets.tobytes()).hexdigest(),
                        budget_f64_sha256=hashlib.sha256(budgets.tobytes()).hexdigest())
coverage = []
for symbol in symbols:
    path = base / "features2025/daily_features" / (symbol + ".parquet")
    frame = pl.read_parquet(path)
    times = frame["dt"].dt.epoch("us").to_numpy()
    assert np.all(np.diff(times) == prototype.DAY_US)
    coverage.append(dict(symbol=symbol, rows=len(times), open_UTC_first=iso(times[0]),
                         open_UTC_last=iso(times[-1]), last_completed_available_UTC=iso(times[-1] + prototype.DAY_US),
                         file_sha256=sha(path), complete_kline_rows=int(frame["complete_kline"].sum()),
                         complete_funding_rows=int(frame["complete_funding"].sum())))
result = dict(status="PASS_EXACT_FINANCIAL_SOURCES_AND_SAVED_2025_TARGET_BUDGET_REPRODUCTION",
              financial_source_files_verified=len(contract["source_sha256"]),
              financial_contract_SHA256=sha(contract_path), financial_contract=contract["financial_contract"],
              native_engine_SHA256=contract["engine_sha256"],
              prototype_mapper_SHA256=sha(STATE / "v2-proxy-sources/prototype.py"),
              restored_producer_SHA256=sha(base / "build_targets2025.py"),
              all_four_raw_expert_targets_and_masks_bit_identical=True, past30_returns_bit_identical=True,
              causal_input_clocks_verified=True, saved_mapping_reproduction=mapped, warmup_coverage=coverage,
              wallets_run=0, fits=0, provider_downloads=0,
              unpublished_Q1_Q2_adapter_checkpoint_identity="NOT_RECOVERED",
              resource_guard_identity="RECONSTRUCTED_POLICY_NOT_KNOWN_OLD_BYTES")
with (HERE / "VERIFIED_RECOVERY.json").open("x") as stream:
    stream.write(json.dumps(result, indent=2, allow_nan=False) + "\n")
print(json.dumps(dict(status=result["status"], source_files=result["financial_source_files_verified"],
                     target_decisions=len(decisions), mapping=mapped, coverage=coverage)))
