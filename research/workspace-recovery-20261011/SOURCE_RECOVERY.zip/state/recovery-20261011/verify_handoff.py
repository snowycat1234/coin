"""Read-only verification of frozen recovery files and both local backup copies."""
import hashlib
import json
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
STATE = ROOT / "coin_single_state"
REPO = ROOT / "coin_single_stream"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


manifest = json.loads((HERE / "FROZEN_RECOVERY_MANIFEST.json").read_bytes())
receipt = json.loads((HERE / "BUNDLE_RECEIPT.json").read_bytes())
assert sha(HERE / "HANDOFF.json") == receipt["handoff_sha256"]
assert sha(HERE / "FROZEN_RECOVERY_MANIFEST.json") == receipt["manifest_sha256"]
for item in manifest["files"]:
    prefix, relative = item["path"].split("/", 1)
    path = (STATE if prefix == "state" else REPO) / relative
    assert path.stat().st_size == item["bytes"] and sha(path) == item["sha256"], item["path"]
for name in ("scratch_bundle", "shared_bundle"):
    path = Path(receipt[name])
    assert path.stat().st_size == receipt["bundle_bytes"] and sha(path) == receipt["bundle_sha256"]
with zipfile.ZipFile(receipt["shared_bundle"]) as archive:
    assert archive.testzip() is None
    for item in manifest["files"]:
        body = archive.read(item["path"])
        assert len(body) == item["bytes"] and hashlib.sha256(body).hexdigest() == item["sha256"]
handoff = json.loads((HERE / "HANDOFF.json").read_bytes())
assert handoff["Q3_financial_runs"] == 0 and handoff["lock"]["lock_modified"] is False
assert handoff["source_warmup"]["native_market_ready"] is False
print(json.dumps(dict(status="PASS_FROZEN_RECOVERY_READBACK_NO_DATA_ACQUISITION_OR_WALLET_ADVANCE",
                      manifest_members=len(manifest["files"]), bundle_members=receipt["members"],
                      handoff_sha256=receipt["handoff_sha256"], manifest_sha256=receipt["manifest_sha256"],
                      bundle_sha256=receipt["bundle_sha256"], two_local_copies_verified=True,
                      external_durability_guaranteed=False)))
