"""Source-bound warmup and causal-prefix verification; no account or model run."""
import hashlib
import importlib.util
import json
import os
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
STATE = ROOT / "coin_single_state"
REPO = ROOT / "coin_single_stream"
WORK = STATE / "recovered-public-Q1-Q2-warmup"
os.environ["QUANT_ROOT"] = str(REPO)
sys.path[:0] = [str(REPO), str(REPO / "src")]
import numpy as np
import pandas as pd
import polars as pl


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def save_json(path, value):
    with path.open("x") as stream:
        stream.write(json.dumps(value, indent=2, allow_nan=False) + "\n")


baseline = json.loads((HERE / "VERIFIED_RECOVERY.json").read_bytes())
assert baseline["status"].startswith("PASS_")
financial = json.loads((REPO / "research/recover-frozen-runner-20261009/april63/ADAPTER_CONTRACT.json").read_bytes())
for name, digest in financial["source_sha256"].items():
    assert sha(REPO / name) == digest
load("scripts.research.conditional_selector_core", REPO / "research/recover-frozen-runner-20261009/auxiliary/conditional_selector_core.py")
recipe = load("_warmup_original_recipe", HERE / "recipes/conditional_selector_inputs.py")
prototype = load("_warmup_original_prototype", STATE / "v2-proxy-sources/prototype.py")
assert sha(STATE / "v2-proxy-sources/prototype.py") == baseline["prototype_mapper_SHA256"]
source_plan = json.loads((WORK / "SOURCE_PLAN.json").read_bytes())
assert len(source_plan["records"]) == 30 and source_plan["expected_bytes"] == 52785575
assert all(r["month"] in [f"2026-{m:02d}" for m in range(1, 7)] for r in source_plan["records"])
symbols = prototype.CORE5
out = WORK / "causal-price-inputs"
(out / "daily_features").mkdir(parents=True, exist_ok=True)
coverage = []
close = []
clocks = None
for symbol in symbols:
    acquired = json.loads((WORK / (symbol + "_ACQUIRED.json")).read_bytes())
    normalized = json.loads((WORK / (symbol + "_NORMALIZED.json")).read_bytes())
    assert len(acquired["records"]) == 6 and normalized["days"] == 181 and normalized["minutes"] == 260640
    for record in acquired["records"]:
        path = STATE / record["relative_path"]
        assert sha(path) == record["sha256"] and path.stat().st_size == record["bytes"]
    new_path = STATE / normalized["artifact"]["path"]
    assert sha(new_path) == normalized["artifact"]["sha256"]
    old_path = STATE / "data-expansion/features2025/daily_features" / (symbol + ".parquet")
    assert sha(old_path) == next(r["file_sha256"] for r in baseline["warmup_coverage"] if r["symbol"] == symbol)
    columns = ["dt", "open", "high", "low", "close", "volume", "quote_volume", "symbol", "complete_kline"]
    old = pd.read_parquet(old_path)[columns]
    new = pd.read_parquet(new_path)[columns]
    assert not old.dt.isin(new.dt).any()
    merged = pd.concat([old, new], ignore_index=True).sort_values("dt").reset_index(drop=True)
    times = pd.DatetimeIndex(merged.dt).as_unit("us").asi8 + prototype.DAY_US
    assert len(times) == 2373 and not merged.dt.duplicated().any()
    np.testing.assert_array_equal(np.diff(times), prototype.DAY_US)
    if clocks is None:
        clocks = times
    else:
        np.testing.assert_array_equal(times, clocks)
    close.append(merged.close.to_numpy(float))
    path = out / "daily_features" / (symbol + ".parquet")
    assert not path.exists(), "Preserve completed combined warmup artifacts"
    merged.to_parquet(path, index=False)
    pd.testing.assert_frame_equal(pd.read_parquet(path), merged)
    coverage.append(dict(symbol=symbol, price_rows=len(merged), existing_rows=len(old), recovered_rows=len(new),
                         last_completed_available_us=int(times[-1]), sha256=sha(path),
                         incomplete_old_kline_rows=int((~old.complete_kline).sum()),
                         new_complete_kline_rows=int(new.complete_kline.sum()),
                         missing_new_minutes=0, original_flags_preserved=True))
prices = np.column_stack(close)
with np.load(STATE / "data-expansion/features2025/FEATURES.npz", allow_pickle=False) as z:
    np.testing.assert_array_equal(clocks[:2192], z["completed_day_available_us"])
    np.testing.assert_array_equal(prices[:2192], z["close"])
with np.load(STATE / "data-expansion/features2025/EXPERTS.npz", allow_pickle=False) as z:
    saved = {k:z[k].copy() for k in z.files}
bars = recipe.bar_frame(out, symbols)
for slot, name in enumerate(("CASH", "VOL_MANAGED_HOLD", "CSMOM21")):
    full = recipe.existing_targets(dict(recipe=name, mechanism=name), bars, saved["decision_us"], prices, clocks, symbols)
    np.testing.assert_array_equal(full[0], saved["expert_targets"][:, slot])
    np.testing.assert_array_equal(full[2], saved["expert_eligible"][:, slot])
decisions = np.arange(1767225600000000, 1782864000000000, prototype.DAY_US, dtype=np.int64)
assert len(decisions) == 181
targets = []
eligible = []
for name in ("CASH", "VOL_MANAGED_HOLD", "CSMOM21"):
    result = recipe.existing_targets(dict(recipe=name, mechanism=name), bars, decisions, prices, clocks, symbols)
    targets.append(result[0])
    eligible.append(result[2])
    for count in (45, 90):
        last = int(decisions[count - 1])
        mask = clocks <= last
        prefix = recipe.existing_targets(dict(recipe=name, mechanism=name), bars.filter(pl.col("available_us") <= last),
                                         decisions[:count], prices[mask], clocks[mask], symbols)
        np.testing.assert_array_equal(prefix[0], result[0][:count])
        np.testing.assert_array_equal(prefix[2], result[2][:count])
from scripts.investment import momentum_short_pool_target as short
short_frame, _ = short.fixed_targets(bars, decisions, symbols=symbols)
targets.append(short_frame["target_weight"].to_numpy().reshape(181, 5))
eligible.append((short_frame["eligibility_reason"].to_numpy().reshape(181, 5) == "ELIGIBLE").any(1))
targets = np.stack(targets, axis=1)
eligible = np.stack(eligible, axis=1)
indices = np.searchsorted(clocks, decisions)
np.testing.assert_array_equal(clocks[indices], decisions)
past = np.stack([np.diff(prices[i - 30:i + 1], axis=0) / prices[i - 30:i] for i in indices])
assert np.isfinite(targets).all() and np.isfinite(past).all()
np.savez_compressed(out / "EXPERTS_Q1_Q2_RECONSTRUCTED.npz", decision_us=decisions, expert_targets=targets,
                    expert_eligible=eligible, past_returns30=past, symbol_order=symbols,
                    expert_order=("CASH", "VOL_MANAGED_HOLD", "CSMOM21", "MOMENTUM30_SHORT"))
report = dict(status="PASS_RECOVERED_ALREADY_SEEN_PUBLIC_PRICE_WARMUP_AND_CAUSAL_PREFIX", archive_count=30,
              archive_bytes=52785575, asset_minutes_verified=1303200, per_asset_days=181,
              source_plan_sha256=sha(WORK / "SOURCE_PLAN.json"), coverage=coverage,
              original_2025_price_history_and_target_masks_unchanged=True,
              original_2025_CS_VOL_targets_365_rows_bit_identical_after_2026_append=True,
              causal_prefix_checks=[45, 90], prefix_targets_and_eligibility_exact=True,
              reconstructed_target_decisions=181, reconstructed_target_period="2026-01-01..2026-06-30 decisions inclusive",
              reconstructed_targets_sha256=sha(out / "EXPERTS_Q1_Q2_RECONSTRUCTED.npz"),
              known_original_2026_target_byte_identity="UNKNOWN_ORIGINAL_UNPUBLISHED_BYTES_MISSING",
              price_only=True, premium_or_funding_features_imputed=False, full_native_market_ready=False,
              collector_lock_unchanged=True, reserved_dataset_reads=0, new_Q3_outcomes_consumed=0,
              native_historical_wallet_runs=0, fits=0,
              unrecovered="Original unpublished Q1/Q2 adapters, marked/funding tapes, ledgers and terminal checkpoints; no replacement of their reported financial results")
save_json(WORK / "VERIFICATION.json", report)
print(json.dumps(dict(status=report["status"], archive_count=30, bytes=52785575, asset_minutes=1303200,
                     combined_rows_per_asset=2373, causal_prefix_checks=[45, 90], prior_2025_targets_unchanged=True,
                     report_sha256=sha(WORK / "VERIFICATION.json"))))
