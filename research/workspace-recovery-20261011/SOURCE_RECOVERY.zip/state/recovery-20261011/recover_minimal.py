"""Recover pinned minimal sources/warmup using only necessary verified ZIP parts.

Selected members are bound by published manifests and checked by ZIP member CRC.
Untouched ZIP parts are not acquired; full concatenated archive SHA/CRC is NOT
claimed unless the complete small standalone archive is obtained and checked.
"""
import argparse
import hashlib
import io
import json
import shutil
import subprocess
import zipfile
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parents[2]
REPO = ROOT / "coin_single_stream"
STATE = ROOT / "coin_single_state"
HERE = Path(__file__).resolve().parent
COMMIT = "55434edfb4d6b9e8ba2b0176ce449dd739737231"
OLD = "d69e9ac94478c5be54cb46c622afec7aaf3c61f7"
DAILY = "be48f5519c23f0e64eb4d75f8b8358915c254f7b"
CEILING = 60 * 1024 * 1024
SYMBOLS = ("BTCUSDT", "ETHUSDT", "SOLUSDT", "XRPUSDT", "DOGEUSDT")


def sha(data):
    return hashlib.sha256(data).hexdigest()


def save(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == data, f"Existing recovery bytes differ: {path}"
    else:
        with path.open("xb") as stream:
            stream.write(data)


def git(commit, path):
    return subprocess.check_output(["git", "-C", str(REPO), "show", commit + ":" + path], timeout=180)


def safe(root, name):
    path = PurePosixPath(name)
    assert not path.is_absolute() and ".." not in path.parts
    out = root.joinpath(*path.parts)
    assert out.resolve().is_relative_to(root.resolve())
    return out


class Parts(io.RawIOBase):
    def __init__(self, spec):
        self.spec = spec
        self.parts = spec["parts"]
        self.size = sum(p["bytes"] for p in self.parts)
        self.offsets = []
        offset = 0
        for part in self.parts:
            self.offsets.append(offset)
            offset += part["bytes"]
        self.pos = 0
        self.used = {}

    def seekable(self):
        return True

    def tell(self):
        return self.pos

    def seek(self, offset, whence=0):
        self.pos = (offset if whence == 0 else self.pos + offset if whence == 1 else self.size + offset)
        assert 0 <= self.pos <= self.size
        return self.pos

    def get(self, i):
        part = self.parts[i]
        out = HERE / "selected-git-parts" / self.spec["id"] / part["path"]
        if not out.exists():
            completed_bytes = sum(p.stat().st_size for p in (HERE / "selected-git-parts").rglob("*.bytepart*")) if (HERE / "selected-git-parts").exists() else 0
            assert completed_bytes + part["bytes"] <= CEILING, "Minimal recovery part budget exceeded"
            assert shutil.disk_usage(STATE).free > 15_000_000_000 + part["bytes"]
            save(out, git(self.spec["commit"], self.spec["base"] + "/" + part["path"]))
        data = out.read_bytes()
        assert len(data) == part["bytes"] and sha(data) == part["sha256"]
        if "git_blob_sha1" in part:
            assert hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest() == part["git_blob_sha1"]
        self.used[i] = dict(relative_state_path=str(out.relative_to(STATE)), **part)
        return data

    def read(self, size=-1):
        end = self.size if size < 0 else min(self.size, self.pos + size)
        blocks = []
        for i, offset in enumerate(self.offsets):
            stop = offset + self.parts[i]["bytes"]
            if offset < end and stop > self.pos:
                blocks.append(self.get(i)[max(0, self.pos - offset):min(stop, end) - offset])
        self.pos = end
        return b"".join(blocks)


def freeze():
    specs = []
    for key in ("e5_h1_tail_coverage_pair", "e5_bear_recovery"):
        base = f"research_artifacts/{key}_20261008"
        raw = git(OLD, base + "/INDEX.json")
        save(HERE / "metadata" / key / "INDEX.json", raw)
        index = json.loads(raw)
        specs.append(dict(id=key, commit=OLD, base=base, metadata_sha256=sha(raw),
                          full_archive_bytes=index["original_bytes"], full_archive_sha256=index["original_sha256"],
                          parts=[dict(path=p["file_name"], bytes=p["bytes"], sha256=p["sha256"], git_blob_sha1=p["git_blob_sha1"]) for p in index["parts"]]))
    base = "research/recover-frozen-runner-20261009/temporal-v2-native61-results"
    artifact = git(COMMIT, base + "/ARTIFACT.json")
    manifest = git(COMMIT, base + "/RESULT_MEMBER_HASHES.json")
    a = json.loads(artifact)
    assert sha(manifest) == a["member_manifest_sha256"]
    save(HERE / "metadata/prototype/ARTIFACT.json", artifact)
    save(HERE / "metadata/prototype/MANIFEST.json", manifest)
    specs.append(dict(id="prototype", commit=COMMIT, base=base, metadata_sha256=sha(artifact),
                      member_manifest_sha256=sha(manifest), full_archive_bytes=a["bytes"],
                      full_archive_sha256=a["sha256"], parts=a["parts"]))
    small = []
    for key, filename in (("core5-2025-consumer-20261010", "CONSUMER.zip"),
                          ("core5-2025-controls-20261010", "CONTROLS.zip")):
        base = "research/" + key
        raw = git(DAILY, base + "/MANIFEST.json")
        save(HERE / "metadata" / key / "MANIFEST.json", raw)
        index = json.loads(raw)
        small.append(dict(id=key, commit=DAILY, base=base, filename=filename,
                          metadata_sha256=sha(raw), archive_bytes=index.get("archive_bytes", index.get("bytes")),
                          archive_sha256=index.get("archive_SHA256", index.get("SHA256", index.get("sha256")))))
    plan = dict(schema="MINIMUM_PINNED_SOURCE_WARMUP_RECOVERY_V1", parts=specs, small_archives=small,
                selected_part_bytes_ceiling=CEILING, member_selection="ONLY_PINNED_MAPPER_TEACHER_PROTOTYPE_H1_CONTEXT_AND_CORE5_DAILY_WARMUP;SMALL2025PRODUCER_CONTROL_ARCHIVES",
                no_financial_runs=True, full_large_archive_verified=False,
                provenance="Published part hashes plus published selected member hashes and member CRC; all original local files preserved")
    save(HERE / "MINIMUM_SOURCE_PLAN.json", (json.dumps(plan, indent=2) + "\n").encode())
    print(json.dumps(dict(status="MINIMUM_SOURCE_RECOVERY_PLAN_FROZEN", parts_ceiling=CEILING,
                         metadata=[dict(id=s["id"], full_archive_bytes=s["full_archive_bytes"]) for s in specs],
                         small_archives=small)))


def recover():
    plan = json.loads((HERE / "MINIMUM_SOURCE_PLAN.json").read_bytes())
    records = []
    for spec in plan["parts"]:
        reader = Parts(spec)
        with zipfile.ZipFile(reader) as archive:
            if spec["id"] == "prototype":
                raw = (HERE / "metadata/prototype/MANIFEST.json").read_bytes()
                assert sha(raw) == spec["member_manifest_sha256"]
                manifest = json.loads(raw)["files"]
                selected = {"proxy-inputs/prototype.py", "proxy-inputs/H1_VALIDATE.npz"}
                destination = STATE / "v2-proxy-sources"
            else:
                raw = archive.read("MANIFEST_SHA256.json")
                if spec["id"] == "e5_h1_tail_coverage_pair":
                    assert sha(raw) == "b29686555f9691252f832af373ad71b1c0d11fc70639589cf9ada1ad9786d6df"
                    selected = {"source_increment/modules/native_action/e5_inputs.py", "h1_market/inputs/H1_E5_INPUTS.npz"}
                    selected |= {f"h1_market/data/normalized/{s}_daily.parquet" for s in SYMBOLS}
                    selected |= {"h1_market/reports/SOURCE_IDENTITY.json", "h1_market/reports/DATASET_MANIFEST.json"}
                    destination = STATE / "h1_validation/original"
                else:
                    selected = {"source_increment/modules/native_action/e5_teacher.py"}
                    destination = STATE / "e5-bear-original"
                manifest = json.loads(raw)["members"]
            by_name = {m.get("path", m.get("name")): m for m in manifest}
            assert selected <= set(by_name), sorted(selected - set(by_name))
            members = []
            for name in sorted(selected):
                data = archive.read(name)
                item = by_name[name]
                assert len(data) == item["bytes"] and sha(data) == item["sha256"]
                output_name = name.removeprefix("proxy-inputs/") if spec["id"] == "prototype" else name
                save(safe(destination, output_name), data)
                members.append(dict(name=name, bytes=len(data), sha256=sha(data), destination=str((destination / output_name).relative_to(STATE))))
        record = dict(id=spec["id"], verified_parts=list(reader.used.values()), selected_members=members,
                      full_archive_sha256_verified=False, full_archive_CRC_verified=False, selected_member_CRC_verified=True)
        records.append(record)
        save(HERE / (spec["id"] + "_RECOVERY.json"), (json.dumps(record, indent=2) + "\n").encode())
        print(json.dumps(dict(id=spec["id"], verified_part_bytes=sum(p["bytes"] for p in reader.used.values()), selected_members=len(members))), flush=True)
    for spec in plan["small_archives"]:
        assert spec["archive_bytes"] is not None and spec["archive_sha256"] is not None, "Complete published small ZIP binding required"
        path = HERE / "small-git-archives" / spec["filename"]
        if not path.exists():
            save(path, git(spec["commit"], spec["base"] + "/" + spec["filename"]))
        data = path.read_bytes()
        assert len(data) == spec["archive_bytes"] and sha(data) == spec["archive_sha256"]
        manifest_raw = (HERE / "metadata" / spec["id"] / "MANIFEST.json").read_bytes()
        assert sha(manifest_raw) == spec["metadata_sha256"]
        manifest = json.loads(manifest_raw)
        files = manifest.get("members", manifest.get("files"))
        destination = STATE / "data-expansion" if "consumer" in spec["id"] else HERE / "daily-controls-reference"
        members = []
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            assert archive.testzip() is None
            for item in files:
                name = item["path"]
                if name.endswith(".parquet") and "daily_features" in name and PurePosixPath(name).stem not in SYMBOLS:
                    continue
                body = archive.read(name)
                assert sha(body) == item["SHA256"]
                if "bytes" in item:
                    assert len(body) == item["bytes"]
                save(safe(destination, name), body)
                members.append(dict(name=name, bytes=len(body), sha256=sha(body)))
        records.append(dict(id=spec["id"], archive_bytes=len(data), archive_sha256=sha(data), selected_members=members, full_archive_CRC_verified=True))
        print(json.dumps(dict(id=spec["id"], archive_bytes=len(data), selected_members=len(members))), flush=True)
    save(HERE / "MINIMUM_SOURCE_RECOVERY.json", (json.dumps(dict(status="PASS_PINNED_MINIMUM_SOURCE_RECOVERY", plan_sha256=sha((HERE / "MINIMUM_SOURCE_PLAN.json").read_bytes()), records=records), indent=2) + "\n").encode())


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=("freeze", "recover"))
    command = parser.parse_args().command
    freeze() if command == "freeze" else recover()
