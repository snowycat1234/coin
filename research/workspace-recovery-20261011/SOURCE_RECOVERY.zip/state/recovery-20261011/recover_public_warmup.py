"""Reacquire only already-consumed Jan-Jun 2026 CORE5 public trade warmup.

No reserved local data is read. The collector lock is retained unchanged.
No July/August/September object, funding approximation, model or wallet run.
"""
import argparse
import hashlib
import json
import os
import re
import shutil
import sys
import zipfile
from pathlib import Path
from urllib.parse import urlparse

import requests

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
STATE = ROOT / "coin_single_state"
REPO = ROOT / "coin_single_stream"
OUT = STATE / "recovered-public-Q1-Q2-warmup"
BASE = "https://data.binance.vision/"
SYMBOLS = ("BTCUSDT", "ETHUSDT", "SOLUSDT", "XRPUSDT", "DOGEUSDT")
CEILING = 60 * 1024 * 1024


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == data, "Existing recovery bytes differ"
    else:
        with path.open("xb") as stream:
            stream.write(data)


def encode(value):
    return (json.dumps(value, indent=2, allow_nan=False) + "\n").encode()


def freeze():
    objects = []
    for symbol in SYMBOLS:
        for month in range(1, 7):
            name = f"{symbol}-1m-2026-{month:02d}.zip"
            key = f"data/futures/um/monthly/klines/{symbol}/1m/{name}"
            objects.append(dict(symbol=symbol, family="klines", month=f"2026-{month:02d}",
                                filename=name, key=key, url=BASE + key))
    plan = dict(schema="PREVIOUSLY_CONSUMED_PUBLIC_Q1_Q2_PRICE_WARMUP_RECOVERY_V1",
                objects=objects, required_objects=30, body_bytes_ceiling=CEILING,
                source_dates="2026-01-01T00:00Z..2026-07-01T00:00Z exclusive",
                data_role="Already-consumed official public Q1/Q2 source recovery; cannot be pristine holdout",
                allowed_purpose="Restore causal completed daily OHLC/close history for original CORE5 strategies",
                excluded="No new July/August outcomes, no separate reserved collector dataset, no model/financial replay",
                complete_feature_or_native_market_ready_claim=False,
                parser_sources={p:sha(REPO / p) for p in (
                    "modules/collector_research/pipeline/normalize.py", "modules/collector_research/pipeline/common.py")},
                collector_lock_unchanged=True,
                collector_lock_overlap="March-June public archives overlap legacy March1-September1 2026 collector reserve; specific recovery authorization applies only to previously consumed public tapes",
                access="Official public direct objects and published checksums; 403/451 stop, no alternative denial bypass",
                financial_recipe_SHA256=sha(HERE / "VERIFIED_RECOVERY.json"),
                authorization_message="Parent explicit recovery scope 2026-10-11T03:02UTC with user transcript evidence")
    save(OUT / "RECIPE.json", encode(plan))
    print(json.dumps(dict(status="PRICE_ONLY_WARMUP_RECIPE_FROZEN", objects=30, body_ceiling=CEILING,
                         recipe_sha256=sha(OUT / "RECIPE.json"))))


def approved(response):
    if response.status_code in (403, 451):
        raise RuntimeError(f"OFFICIAL_ACCESS_DENIED_STOP {response.status_code} {response.url}")
    response.raise_for_status()
    assert urlparse(response.url).hostname == "data.binance.vision" and response.url.startswith(BASE)


def inventory():
    recipe = json.loads((OUT / "RECIPE.json").read_bytes())
    rows = []
    with requests.Session() as session:
        for obj in recipe["objects"]:
            path = OUT / "metadata" / (obj["filename"] + ".json")
            if path.exists():
                row = json.loads(path.read_bytes())
            else:
                checksum = session.get(obj["url"] + ".CHECKSUM", timeout=30)
                approved(checksum)
                assert len(checksum.content) < 1000
                tokens = checksum.text.split()
                assert len(tokens) == 2 and tokens[1] == obj["filename"] and re.fullmatch("[0-9a-f]{64}", tokens[0])
                head = session.head(obj["url"], timeout=30)
                approved(head)
                size = int(head.headers["Content-Length"])
                assert 0 < size < 10 * 1024 * 1024
                row = dict(obj, bytes=size, sha256=tokens[0], checksum_text=checksum.text,
                           last_modified=head.headers.get("Last-Modified"))
                save(path, encode(row))
            assert all(row[k] == v for k, v in obj.items())
            rows.append(row)
            if len(rows) % 6 == 0:
                print(json.dumps(dict(metadata_verified=len(rows), total_objects=30)), flush=True)
    total = sum(r["bytes"] for r in rows)
    assert len(rows) == 30 and total <= CEILING
    plan = dict(status="OFFICIAL_CHECKSUM_HEAD_AND_DUPLICATE_PREFLIGHT_PASS", recipe_sha256=sha(OUT / "RECIPE.json"),
                records=rows, expected_bytes=total, body_ceiling=CEILING, archives_acquired=0)
    save(OUT / "SOURCE_PLAN.json", encode(plan))
    print(json.dumps(dict(status=plan["status"], objects=len(rows), expected_bytes=total)))


def download(symbol):
    plan = json.loads((OUT / "SOURCE_PLAN.json").read_bytes())
    assert plan["recipe_sha256"] == sha(OUT / "RECIPE.json") and plan["expected_bytes"] <= CEILING
    assert symbol in SYMBOLS
    receipt_path = OUT / (symbol + "_ACQUIRED.json")
    if receipt_path.exists():
        receipt = json.loads(receipt_path.read_bytes())
        assert receipt["source_plan_sha256"] == sha(OUT / "SOURCE_PLAN.json")
        assert len(receipt["records"]) == 6
        for obj in receipt["records"]:
            path = STATE / obj["relative_path"]
            assert path.stat().st_size == obj["bytes"] and sha(path) == obj["sha256"]
            with zipfile.ZipFile(path) as archive:
                assert archive.testzip() is None
        print(json.dumps(dict(symbol=symbol, status="REUSED_VERIFIED_COMPLETED_ACQUISITION", archives=6)))
        return
    rows = []
    with requests.Session() as session:
        for obj in (r for r in plan["records"] if r["symbol"] == symbol):
            path = OUT / "raw" / obj["filename"]
            reused = path.exists()
            if not reused:
                assert shutil.disk_usage(STATE).free > 15_000_000_000 + obj["bytes"]
                path.parent.mkdir(parents=True, exist_ok=True)
                partial = path.with_suffix(".partial")
                assert not partial.exists(), "Retain any incomplete body for explicit inspection before retry"
                with session.get(obj["url"], stream=True, timeout=45) as response:
                    approved(response)
                    assert int(response.headers["Content-Length"]) == obj["bytes"]
                    count = 0
                    with partial.open("xb") as stream:
                        for block in response.iter_content(1024 * 1024):
                            count += len(block)
                            assert count <= obj["bytes"]
                            stream.write(block)
                assert count == obj["bytes"] and sha(partial) == obj["sha256"]
                partial.rename(path)
            assert path.stat().st_size == obj["bytes"] and sha(path) == obj["sha256"]
            with zipfile.ZipFile(path) as archive:
                assert len(archive.infolist()) == 1 and archive.testzip() is None
                info = archive.infolist()[0]
                assert not info.is_dir() and info.file_size < 30 * 1024 * 1024
            rows.append(dict(obj, relative_path=str(path.relative_to(STATE)), reused=reused, ZIP_CRC_verified=True))
            print(json.dumps(dict(verified=obj["filename"], bytes=obj["bytes"], reused=reused)), flush=True)
    save(receipt_path, encode(dict(source_plan_sha256=sha(OUT / "SOURCE_PLAN.json"), records=rows)))


def normalize(symbol):
    assert symbol in SYMBOLS
    recipe = json.loads((OUT / "RECIPE.json").read_bytes())
    for path, expected in recipe["parser_sources"].items():
        assert sha(REPO / path) == expected
    os.environ["WORK_DIR"] = str(OUT / "normalizer_work")
    sys.path[:0] = [str(REPO), str(REPO / "src")]
    import numpy as np
    import pandas as pd
    from modules.collector_research.pipeline import normalize as original
    record = json.loads((OUT / (symbol + "_ACQUIRED.json")).read_bytes())
    assert record["source_plan_sha256"] == sha(OUT / "SOURCE_PLAN.json")
    report_path = OUT / (symbol + "_NORMALIZED.json")
    if report_path.exists():
        report = json.loads(report_path.read_bytes())
        assert report["source_plan_sha256"] == sha(OUT / "SOURCE_PLAN.json")
        assert report["parser_sources"] == recipe["parser_sources"]
        artifact = report["artifact"]
        path = STATE / artifact["path"]
        assert path.stat().st_size == artifact["bytes"] and sha(path) == artifact["sha256"]
        print(json.dumps(dict(symbol=symbol, status="REUSED_VERIFIED_COMPLETED_NORMALIZATION", days=181)))
        return
    days = []
    receipts = []
    for obj in record["records"]:
        path = STATE / obj["relative_path"]
        assert sha(path) == obj["sha256"] and path.stat().st_size == obj["bytes"]
        year, month = map(int, obj["month"].split("-"))
        left, right = original.month_limits(year, month)
        frame = original.numeric_csv(path)
        frame, duplicate_count = original.validate_price(frame, "klines", left, right)
        assert duplicate_count == 0
        np.testing.assert_array_equal(frame.timestamp_ms.to_numpy(), np.arange(left, right, 60000, dtype=np.int64))
        daily = original.aggregate_price(frame, "klines")
        assert daily.complete.all()
        days.append(daily)
        receipts.append(dict(month=obj["month"], minutes=len(frame), days=len(daily), no_missing_minutes=True,
                             original_archive_sha256=obj["sha256"], schema="ORIGINAL_USDM_MILLISECOND_12COLUMN_CSV"))
    merged = pd.concat(days).sort_index()
    assert len(merged) == 181 and not merged.index.duplicated().any()
    np.testing.assert_array_equal(np.diff(merged.index.as_unit("us").asi8), 86_400_000_000)
    price = merged[["open", "high", "low", "close", "volume", "quote_volume"]].reset_index()
    price["symbol"] = symbol
    price["complete_kline"] = True
    output = OUT / "daily_prices" / (symbol + ".parquet")
    output.parent.mkdir(parents=True, exist_ok=True)
    assert not output.exists(), "Do not overwrite completed warmup artifact"
    price.to_parquet(output, index=False)
    pd.testing.assert_frame_equal(pd.read_parquet(output), price)
    report = dict(symbol=symbol, status="COMPLETE_ACTUAL_PRICE_ONLY_DAILY_WARMUP", days=181, minutes=260640,
                  first_open_UTC=str(price.dt.iloc[0]), last_open_UTC=str(price.dt.iloc[-1]),
                  source_plan_sha256=sha(OUT / "SOURCE_PLAN.json"), parser_sources=recipe["parser_sources"],
                  months=receipts, artifact=dict(path=str(output.relative_to(STATE)), sha256=sha(output), bytes=output.stat().st_size),
                  full_feature_or_native_market_ready=False, funding_or_premium_imputed=False,
                  wallet_runs=0, fits=0, reserve_dataset_reads=0)
    save(report_path, encode(report))
    print(json.dumps(dict(symbol=symbol, days=181, minutes=260640, artifact=report["artifact"])))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=("freeze", "inventory", "download", "normalize"))
    parser.add_argument("--symbol", choices=SYMBOLS)
    args = parser.parse_args()
    if args.command == "freeze":
        freeze()
    elif args.command == "inventory":
        inventory()
    elif args.command == "download":
        download(args.symbol)
    else:
        normalize(args.symbol)
